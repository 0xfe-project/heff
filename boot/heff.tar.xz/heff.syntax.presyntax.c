// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_ExplicitParam 63083
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_IntWord 51777
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_RuneWord 42901
#define TAG_SetField 47531
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StringWord 15530
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define TAG_TypeWord 10401
#define LBL_args 9498020
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_end 310101
#define LBL_head 9693863
#define LBL_start 311115900
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2ealtOf(V, V);
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eannLamOf(V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eappOf(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_clo;
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(V, V, V);
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_clo;
V g_heff_2esyntax_2epresyntax_2eargOf(V, V);
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_clo;
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V);
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void);
V g_heff_2esyntax_2epresyntax_2eclassify_get(void);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V);
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V, V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2edoFrom(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoFrom_clo;
V g_heff_2esyntax_2epresyntax_2edoStep(V, V, V);
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edoStep_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf(V, V);
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo;
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V);
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_clo;
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V, V);
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo;
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V);
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf(V, V);
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf(V, V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo;
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V);
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo;
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V);
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2epresyntax_2etoInferable(V);
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo;
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V, V);
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo;
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V);
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf(V, V);
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo;
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(V);
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_clo;
V g_heff_2esyntax_2epresyntax_2ewatchOf(V);
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo;
V g_heff_2esyntax_2epresyntax_2ewordOf(V, V);
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1150457979x1978067071(V);
V g_list_2emap_24s1150457979x1978067071_entry(V self, V *a);
extern Clo g_list_2emap_24s1150457979x1978067071_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1253308387x88241051(V);
V g_list_2emap_24s1253308387x88241051_entry(V self, V *a);
extern Clo g_list_2emap_24s1253308387x88241051_clo;
V g_list_2emap_24s1374235278x875430684(V);
V g_list_2emap_24s1374235278x875430684_entry(V self, V *a);
extern Clo g_list_2emap_24s1374235278x875430684_clo;
V g_list_2emap_24s1688457226x2006118782(V);
V g_list_2emap_24s1688457226x2006118782_entry(V self, V *a);
extern Clo g_list_2emap_24s1688457226x2006118782_clo;
V g_list_2emap_24s1729787689x465380098(V);
V g_list_2emap_24s1729787689x465380098_entry(V self, V *a);
extern Clo g_list_2emap_24s1729787689x465380098_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1992667171x110340492(V);
V g_list_2emap_24s1992667171x110340492_entry(V self, V *a);
extern Clo g_list_2emap_24s1992667171x110340492_clo;
V g_list_2emap_24s2081626528x1476576812(V);
V g_list_2emap_24s2081626528x1476576812_entry(V self, V *a);
extern Clo g_list_2emap_24s2081626528x1476576812_clo;
V g_list_2emap_24s244350250x1728178626(V);
V g_list_2emap_24s244350250x1728178626_entry(V self, V *a);
extern Clo g_list_2emap_24s244350250x1728178626_clo;
V g_list_2emap_24s249042484x1701682908(V);
V g_list_2emap_24s249042484x1701682908_entry(V self, V *a);
extern Clo g_list_2emap_24s249042484x1701682908_clo;
V g_list_2emap_24s386875578x1005587669(V);
V g_list_2emap_24s386875578x1005587669_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_clo;
V g_list_2emap_24s474585387x1072098790(V);
V g_list_2emap_24s474585387x1072098790_entry(V self, V *a);
extern Clo g_list_2emap_24s474585387x1072098790_clo;
V g_list_2emap_24s503326960x1200444853(V);
V g_list_2emap_24s503326960x1200444853_entry(V self, V *a);
extern Clo g_list_2emap_24s503326960x1200444853_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s539093115x379698116(V);
V g_list_2emap_24s539093115x379698116_entry(V self, V *a);
extern Clo g_list_2emap_24s539093115x379698116_clo;
V g_list_2emap_24s79542405x478516404(V);
V g_list_2emap_24s79542405x478516404_entry(V self, V *a);
extern Clo g_list_2emap_24s79542405x478516404_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2esyntax_2epresyntax_2elastOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2elastOr_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2elastOr(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_z_240);
      return heff_dup(v_x_242);
    }
    case TAG_Cons: {
      V t_0 = v_z_240;
      V t_1 = v_x22_243;
      v_z_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2elastOr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2epresyntax_2eapp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eapp_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eapp(V v_f_240, V v_args_241) {
top: ;
  switch (heff_tag_of(v_args_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_At: {
      V v_f1_244 = heff_dup(heff_field(v_f_240, 0));
      V v_sp_245 = heff_dup(heff_field(v_f_240, 1));
      switch (heff_tag_of(v_f1_244)) {
      case TAG_EVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_249;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_f_240, 1));
          v_a_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2410 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2413;
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x1_2410, 1);
          heff_take_n(v_x1_2410, 2ULL, 2);
          v_b_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_x1_2410);
        }
        V v_t_2414 = ({ V rv_1 = heff_get_n(v_b_2413, 1, 2); V rr_ = heff_rec_reuse_n(v_a_249, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2414});
      }
      case TAG_EImplicitVar: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2418;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2417 = heff_dup(heff_field(v_f_240, 1));
          v_a_2418 = v_s_2417;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2422;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_field(v_x1_2419, 1);
          heff_take_n(v_x1_2419, 2ULL, 2);
          v_b_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        V v_t_2423 = ({ V rv_1 = heff_get_n(v_b_2422, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2418, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2423});
      }
      case TAG_ETag: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2427;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_f_240, 1));
          v_a_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2428 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2431;
        switch (heff_tag_of(v_x1_2428)) {
        case TAG_At: {
          V v_s_2430 = heff_field(v_x1_2428, 1);
          heff_take_n(v_x1_2428, 2ULL, 2);
          v_b_2431 = v_s_2430;
          break;
        }
        default: heff_nomatch(v_x1_2428);
        }
        V v_t_2432 = ({ V rv_1 = heff_get_n(v_b_2431, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2427, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2432});
      }
      case TAG_EInt: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2436;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_f_240, 1));
          v_a_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2437 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2440;
        switch (heff_tag_of(v_x1_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_field(v_x1_2437, 1);
          heff_take_n(v_x1_2437, 2ULL, 2);
          v_b_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_x1_2437);
        }
        V v_t_2441 = ({ V rv_1 = heff_get_n(v_b_2440, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2436, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2441});
      }
      case TAG_EFloat: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2445;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2444 = heff_dup(heff_field(v_f_240, 1));
          v_a_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2446 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2449;
        switch (heff_tag_of(v_x1_2446)) {
        case TAG_At: {
          V v_s_2448 = heff_field(v_x1_2446, 1);
          heff_take_n(v_x1_2446, 2ULL, 2);
          v_b_2449 = v_s_2448;
          break;
        }
        default: heff_nomatch(v_x1_2446);
        }
        V v_t_2450 = ({ V rv_1 = heff_get_n(v_b_2449, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2445, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2450});
      }
      case TAG_EString: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2454;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_f_240, 1));
          v_a_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2455 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2458;
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_field(v_x1_2455, 1);
          heff_take_n(v_x1_2455, 2ULL, 2);
          v_b_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_x1_2455);
        }
        V v_t_2459 = ({ V rv_1 = heff_get_n(v_b_2458, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2454, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2459});
      }
      case TAG_ERune: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2463;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2462 = heff_dup(heff_field(v_f_240, 1));
          v_a_2463 = v_s_2462;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2464 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2467;
        switch (heff_tag_of(v_x1_2464)) {
        case TAG_At: {
          V v_s_2466 = heff_field(v_x1_2464, 1);
          heff_take_n(v_x1_2464, 2ULL, 2);
          v_b_2467 = v_s_2466;
          break;
        }
        default: heff_nomatch(v_x1_2464);
        }
        V v_t_2468 = ({ V rv_1 = heff_get_n(v_b_2467, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2463, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2468});
      }
      case TAG_EWord: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2472;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2471 = heff_dup(heff_field(v_f_240, 1));
          v_a_2472 = v_s_2471;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2473 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2476;
        switch (heff_tag_of(v_x1_2473)) {
        case TAG_At: {
          V v_s_2475 = heff_field(v_x1_2473, 1);
          heff_take_n(v_x1_2473, 2ULL, 2);
          v_b_2476 = v_s_2475;
          break;
        }
        default: heff_nomatch(v_x1_2473);
        }
        V v_t_2477 = ({ V rv_1 = heff_get_n(v_b_2476, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2472, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2477});
      }
      case TAG_EApp: {
        V v_h_2478 = heff_field(v_f1_244, 0);
        V v_xs_2479 = heff_field(v_f1_244, 1);
        V v_ru_24f1_244_24EApp = heff_take_reuse_n(v_f1_244, 3ULL, 2);
        heff_drop_tag(v_f_240, 2);
        V v_t_2480 = heff_tag_at_n(v_ru_24f1_244_24EApp, TAG_EApp, 2, (V[]){heff_dup(v_h_2478), (g_prelude_2e_2b_2b(v_xs_2479, heff_dup(v_args_241)))});
        V v_x1_2481 = ({ V a_0 = v_h_2478; V a_1 = v_args_241; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_args_241, 2); r_; });
        V v_b_2484;
        switch (heff_tag_of(v_x1_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_field(v_x1_2481, 1);
          heff_take_n(v_x1_2481, 2ULL, 2);
          v_b_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_x1_2481);
        }
        V v_t_2485 = ({ V rv_1 = heff_get_n(v_b_2484, 1, 2); V rr_ = heff_rec_reuse_n(v_sp_245, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){v_t_2480, v_t_2485});
      }
      case TAG_EProject: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2489;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_f_240, 1));
          v_a_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_2490 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_2493;
        switch (heff_tag_of(v_x1_2490)) {
        case TAG_At: {
          V v_s_2492 = heff_field(v_x1_2490, 1);
          heff_take_n(v_x1_2490, 2ULL, 2);
          v_b_2493 = v_s_2492;
          break;
        }
        default: heff_nomatch(v_x1_2490);
        }
        V v_t_2494 = ({ V rv_1 = heff_get_n(v_b_2493, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2489, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_2494});
      }
      case TAG_ENamed: {
        V v_ru_24f1_244_24ENamed = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_2499;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_f_240, 1));
          v_a_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24100 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24103;
        switch (heff_tag_of(v_x1_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_field(v_x1_24100, 1);
          heff_take_n(v_x1_24100, 2ULL, 2);
          v_b_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_x1_24100);
        }
        V v_t_24104 = ({ V rv_1 = heff_get_n(v_b_24103, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2499, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24104});
      }
      case TAG_EPi: {
        V v_ru_24f1_244_24EPi = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24109;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24108 = heff_dup(heff_field(v_f_240, 1));
          v_a_24109 = v_s_24108;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24110 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24113;
        switch (heff_tag_of(v_x1_24110)) {
        case TAG_At: {
          V v_s_24112 = heff_field(v_x1_24110, 1);
          heff_take_n(v_x1_24110, 2ULL, 2);
          v_b_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_x1_24110);
        }
        V v_t_24114 = ({ V rv_1 = heff_get_n(v_b_24113, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24109, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24114});
      }
      case TAG_ELam: {
        V v_ru_24f1_244_24ELam = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24119;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_f_240, 1));
          v_a_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24120 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24123;
        switch (heff_tag_of(v_x1_24120)) {
        case TAG_At: {
          V v_s_24122 = heff_field(v_x1_24120, 1);
          heff_take_n(v_x1_24120, 2ULL, 2);
          v_b_24123 = v_s_24122;
          break;
        }
        default: heff_nomatch(v_x1_24120);
        }
        V v_t_24124 = ({ V rv_1 = heff_get_n(v_b_24123, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24119, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24124});
      }
      case TAG_EAnn: {
        V v_ru_24f1_244_24EAnn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24129;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_f_240, 1));
          v_a_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24130 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24133;
        switch (heff_tag_of(v_x1_24130)) {
        case TAG_At: {
          V v_s_24132 = heff_field(v_x1_24130, 1);
          heff_take_n(v_x1_24130, 2ULL, 2);
          v_b_24133 = v_s_24132;
          break;
        }
        default: heff_nomatch(v_x1_24130);
        }
        V v_t_24134 = ({ V rv_1 = heff_get_n(v_b_24133, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24129, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24134});
      }
      case TAG_ESpec: {
        heff_take_n(v_f1_244, 0ULL, 4);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24141;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24140 = heff_dup(heff_field(v_f_240, 1));
          v_a_24141 = v_s_24140;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24142 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24145;
        switch (heff_tag_of(v_x1_24142)) {
        case TAG_At: {
          V v_s_24144 = heff_field(v_x1_24142, 1);
          heff_take_n(v_x1_24142, 2ULL, 2);
          v_b_24145 = v_s_24144;
          break;
        }
        default: heff_nomatch(v_x1_24142);
        }
        V v_t_24146 = ({ V rv_1 = heff_get_n(v_b_24145, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24141, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24146});
      }
      case TAG_ESig: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24150;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24149 = heff_dup(heff_field(v_f_240, 1));
          v_a_24150 = v_s_24149;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24151 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24154;
        switch (heff_tag_of(v_x1_24151)) {
        case TAG_At: {
          V v_s_24153 = heff_field(v_x1_24151, 1);
          heff_take_n(v_x1_24151, 2ULL, 2);
          v_b_24154 = v_s_24153;
          break;
        }
        default: heff_nomatch(v_x1_24151);
        }
        V v_t_24155 = ({ V rv_1 = heff_get_n(v_b_24154, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24150, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24155});
      }
      case TAG_ESum: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24159;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24158 = heff_dup(heff_field(v_f_240, 1));
          v_a_24159 = v_s_24158;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24160 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24163;
        switch (heff_tag_of(v_x1_24160)) {
        case TAG_At: {
          V v_s_24162 = heff_field(v_x1_24160, 1);
          heff_take_n(v_x1_24160, 2ULL, 2);
          v_b_24163 = v_s_24162;
          break;
        }
        default: heff_nomatch(v_x1_24160);
        }
        V v_t_24164 = ({ V rv_1 = heff_get_n(v_b_24163, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24159, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24164});
      }
      case TAG_EStruct: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24168;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24167 = heff_dup(heff_field(v_f_240, 1));
          v_a_24168 = v_s_24167;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24169 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24172;
        switch (heff_tag_of(v_x1_24169)) {
        case TAG_At: {
          V v_s_24171 = heff_field(v_x1_24169, 1);
          heff_take_n(v_x1_24169, 2ULL, 2);
          v_b_24172 = v_s_24171;
          break;
        }
        default: heff_nomatch(v_x1_24169);
        }
        V v_t_24173 = ({ V rv_1 = heff_get_n(v_b_24172, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24168, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24173});
      }
      case TAG_EMatch: {
        V v_ru_24f1_244_24EMatch = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24178;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24177 = heff_dup(heff_field(v_f_240, 1));
          v_a_24178 = v_s_24177;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24179 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24182;
        switch (heff_tag_of(v_x1_24179)) {
        case TAG_At: {
          V v_s_24181 = heff_field(v_x1_24179, 1);
          heff_take_n(v_x1_24179, 2ULL, 2);
          v_b_24182 = v_s_24181;
          break;
        }
        default: heff_nomatch(v_x1_24179);
        }
        V v_t_24183 = ({ V rv_1 = heff_get_n(v_b_24182, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24178, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24183});
      }
      case TAG_ELetIn: {
        V v_ru_24f1_244_24ELetIn = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24188;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_f_240, 1));
          v_a_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24189 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24192;
        switch (heff_tag_of(v_x1_24189)) {
        case TAG_At: {
          V v_s_24191 = heff_field(v_x1_24189, 1);
          heff_take_n(v_x1_24189, 2ULL, 2);
          v_b_24192 = v_s_24191;
          break;
        }
        default: heff_nomatch(v_x1_24189);
        }
        V v_t_24193 = ({ V rv_1 = heff_get_n(v_b_24192, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24188, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24193});
      }
      case TAG_EDo: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24197;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24196 = heff_dup(heff_field(v_f_240, 1));
          v_a_24197 = v_s_24196;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24198 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24201;
        switch (heff_tag_of(v_x1_24198)) {
        case TAG_At: {
          V v_s_24200 = heff_field(v_x1_24198, 1);
          heff_take_n(v_x1_24198, 2ULL, 2);
          v_b_24201 = v_s_24200;
          break;
        }
        default: heff_nomatch(v_x1_24198);
        }
        V v_t_24202 = ({ V rv_1 = heff_get_n(v_b_24201, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24197, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24202});
      }
      case TAG_ELocal: {
        V v_ru_24f1_244_24ELocal = heff_take_reuse_n(v_f1_244, 0ULL, 2);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24207;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24206 = heff_dup(heff_field(v_f_240, 1));
          v_a_24207 = v_s_24206;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24208 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24211;
        switch (heff_tag_of(v_x1_24208)) {
        case TAG_At: {
          V v_s_24210 = heff_field(v_x1_24208, 1);
          heff_take_n(v_x1_24208, 2ULL, 2);
          v_b_24211 = v_s_24210;
          break;
        }
        default: heff_nomatch(v_x1_24208);
        }
        V v_t_24212 = ({ V rv_1 = heff_get_n(v_b_24211, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24207, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_at_n(v_ru_24f1_244_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24212});
      }
      case TAG_EInvalid: {
        heff_take_n(v_f1_244, 0ULL, 1);
        heff_drop_rec(v_sp_245, 2);
        V v_a_24216;
        switch (heff_tag_of(v_f_240)) {
        case TAG_At: {
          V v_s_24215 = heff_dup(heff_field(v_f_240, 1));
          v_a_24216 = v_s_24215;
          break;
        }
        default: heff_nomatch(v_f_240);
        }
        V v_x1_24217 = (g_heff_2esyntax_2epresyntax_2elastOr(heff_dup(v_f_240), v_args_241));
        V v_b_24220;
        switch (heff_tag_of(v_x1_24217)) {
        case TAG_At: {
          V v_s_24219 = heff_field(v_x1_24217, 1);
          heff_take_n(v_x1_24217, 2ULL, 2);
          v_b_24220 = v_s_24219;
          break;
        }
        default: heff_nomatch(v_x1_24217);
        }
        V v_t_24221 = ({ V rv_1 = heff_get_n(v_b_24220, 1, 2); V rr_ = heff_rec_reuse_n(v_a_24216, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_args_241}), v_t_24221});
      }
      default: return heff_nomatch(v_f1_244);
      }
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_args_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eapp(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2espineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2espineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2espineOf(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EFloat: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EString: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ERune: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EWord: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EApp: {
      V v_h_2411 = heff_field(v_e1_241, 0);
      V v_xs_2412 = heff_field(v_e1_241, 1);
      heff_take_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_2411, v_xs_2412});
    }
    case TAG_EProject: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ENamed: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EPi: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EAnn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESig: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ESum: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EStruct: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELetIn: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EDo: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_ELocal: {
      heff_take_n(v_e1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    case TAG_EInvalid: {
      heff_take_n(v_e1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_e_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2espineOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epatSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epatSpineOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PatTag, 3, (V[]){v_t_244, heff_dup(v_tsp_245), NTAG(TAG_Nil)});
      return heff_rec_n(2, shape_head__args, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_tsp_245}), v_ps_246});
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_241, 0);
      V v_xsp_249 = heff_field(v_p1_241, 1);
      V v_ps_2410 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_248}), v_xsp_249});
      return heff_rec_n(2, shape_head__args, (V[]){v_t_2411, v_ps_2410});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatRecord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    case TAG_PatAs: {
      heff_take_n(v_p1_241, 0ULL, 3);
      return heff_rec_n(2, shape_head__args, (V[]){v_p_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epatSpineOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfSpineOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfSpineOf(V v_i_240) {
top: ;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_i1_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_i1_241)) {
    case TAG_IVar: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInt: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IFloat: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IString: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IRune: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IApp: {
      V v_h_248 = heff_field(v_i1_241, 0);
      V v_xs_249 = heff_field(v_i1_241, 1);
      heff_take_n(v_i1_241, 3ULL, 2);
      heff_drop_tag(v_i_240, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_h_248, v_xs_249});
    }
    case TAG_IAnn: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ISpec: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IAnnLam: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_IInvalid: {
      heff_take_n(v_i1_241, 0ULL, 2);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_INominal: {
      heff_take_n(v_i1_241, 0ULL, 1);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    case TAG_ILitEq: {
      heff_take_n(v_i1_241, 0ULL, 4);
      return heff_rec_n(2, shape_head__args, (V[]){v_i_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_i1_241);
    }
  }
  default: return heff_nomatch(v_i_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfSpineOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str0, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str1, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2edoStep_str2, 1, "_");
Clo g_heff_2esyntax_2epresyntax_2edoStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoStep_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2edoStep(V v_sp_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_x22_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_StmtBind: {
      V v_x_245 = heff_field(v_x21_243, 0);
      V v_xsp_246 = heff_field(v_x21_243, 1);
      V v_e_247 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 7ULL, 3);
      heff_drop_rec(v_x22_244, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str0)}), v_sp_240});
      V v_t_249 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){v_x_245, heff_dup(v_xsp_246)}), heff_dup(v_rest_242)});
      V v_b_2412;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_b_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2413 = ({ V rv_1 = heff_get_n(v_b_2412, 1, 2); V rr_ = heff_rec_reuse_n(v_xsp_246, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2413}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_e_247, v_t_2414})));
    }
    case TAG_StmtLet: {
      V v_p_2415 = heff_field(v_x21_243, 0);
      V v_rhs_2416 = heff_field(v_x21_243, 1);
      V v_ru_24x21_243_24StmtLet = heff_take_reuse_n(v_x21_243, 3ULL, 2);
      heff_drop_rec(v_sp_240, 2);
      V v_a_2419;
      switch (heff_tag_of(v_p_2415)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_p_2415, 1));
        v_a_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_p_2415);
      }
      V v_b_2422;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_rest_242, 1));
        v_b_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2423 = ({ V rv_1 = heff_get_n(v_b_2422, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2419, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2415, heff_dup(v_rest_242)}), v_t_2423});
      V v_t_2427;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2428 = ({ V rv_1 = heff_get_n(v_t_2427, 1, 2); V rr_ = heff_rec_reuse_n(v_x22_244, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x21_243_24StmtLet, TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_2416, v_t_2424}), v_t_2428});
    }
    case TAG_StmtExpr: {
      V v_e_2429 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_rec(v_x22_244, 2);
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str1)}), heff_dup(v_sp_240)});
      V v_t_2431 = heff_tag_n(TAG_ELam, 2, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2epresyntax_2edoStep_str2), heff_dup(v_sp_240)}), heff_dup(v_rest_242)});
      V v_b_2434;
      switch (heff_tag_of(v_rest_242)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_rest_242, 1);
        heff_take_n(v_rest_242, 2ULL, 2);
        v_b_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_rest_242);
      }
      V v_t_2435 = ({ V rv_1 = heff_get_n(v_b_2434, 1, 2); V rr_ = heff_rec_reuse_n(v_sp_240, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_t_2435}), NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2430, heff_tag_n(TAG_Cons, 2, (V[]){v_e_2429, v_t_2436})));
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2edoStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edoStep(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2edoFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edoFrom_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2edoFrom(V v_sp_240, V v_x2_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    return v_e_242;
  }
  case TAG_Cons: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2edoFrom(heff_dup(v_sp_240), v_rest_244, v_e_242));
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2edoStep(v_sp_240, heff_dup(v_s_243), v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2edoFrom_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epresyntax_2edoFrom(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str0, 48, "this notation must be put in a checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str1, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str2, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str3, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str4, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str5, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str6, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str7, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str8, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str9, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str10, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str11, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str12, 54, "a type used as an element must be in checking position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etoInferable_str13, 54, "a type used as an element must be in checking position");
Clo g_heff_2esyntax_2epresyntax_2etoInferable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etoInferable_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etoInferable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_i_241);
  }
  case TAG_IsCheckable: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_sp_245;
    switch (heff_tag_of(v_c_242)) {
    case TAG_At: {
      V v_s_244 = heff_field(v_c_242, 1);
      v_sp_245 = heff_dup(v_s_244);
      break;
    }
    default: heff_nomatch(v_c_242);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str0)}), v_sp_245});
  }
  case TAG_IsType: {
    V v_x11_246 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_At: {
      V v_x111_247 = heff_field(v_x11_246, 0);
      V v_sp_248 = heff_field(v_x11_246, 1);
      switch (heff_tag_of(v_x111_247)) {
      case TAG_TPi: {
        V v_sp_2413;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2412 = heff_field(v_x11_246, 1);
          v_sp_2413 = heff_dup(v_s_2412);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str1)}), v_sp_2413});
      }
      case TAG_TSig: {
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str2)}), heff_dup(v_sp_248)});
      }
      case TAG_TSum: {
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str3)}), heff_dup(v_sp_248)});
      }
      case TAG_TType: {
        V v_sp_2418;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2417 = heff_field(v_x11_246, 1);
          v_sp_2418 = heff_dup(v_s_2417);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str4)}), v_sp_2418});
      }
      case TAG_TInt: {
        V v_sp_2421;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2420 = heff_field(v_x11_246, 1);
          v_sp_2421 = heff_dup(v_s_2420);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str5)}), v_sp_2421});
      }
      case TAG_TFloat: {
        V v_sp_2424;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2423 = heff_field(v_x11_246, 1);
          v_sp_2424 = heff_dup(v_s_2423);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str6)}), v_sp_2424});
      }
      case TAG_TString: {
        V v_sp_2427;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2426 = heff_field(v_x11_246, 1);
          v_sp_2427 = heff_dup(v_s_2426);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str7)}), v_sp_2427});
      }
      case TAG_TRune: {
        V v_sp_2430;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2429 = heff_field(v_x11_246, 1);
          v_sp_2430 = heff_dup(v_s_2429);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str8)}), v_sp_2430});
      }
      case TAG_TArray: {
        V v_sp_2434;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2433 = heff_field(v_x11_246, 1);
          v_sp_2434 = heff_dup(v_s_2433);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str9)}), v_sp_2434});
      }
      case TAG_TFixed: {
        V v_sp_2438;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2437 = heff_field(v_x11_246, 1);
          v_sp_2438 = heff_dup(v_s_2437);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str10)}), v_sp_2438});
      }
      case TAG_TInf: {
        V v_sp_2442;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2441 = heff_field(v_x11_246, 1);
          v_sp_2442 = heff_dup(v_s_2441);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str11)}), v_sp_2442});
      }
      case TAG_TChk: {
        V v_sp_2446;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2445 = heff_field(v_x11_246, 1);
          v_sp_2446 = heff_dup(v_s_2445);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str12)}), v_sp_2446});
      }
      case TAG_TNominal: {
        V v_sp_2450;
        switch (heff_tag_of(v_x11_246)) {
        case TAG_At: {
          V v_s_2449 = heff_field(v_x11_246, 1);
          v_sp_2450 = heff_dup(v_s_2449);
          break;
        }
        default: heff_nomatch(v_x11_246);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2etoInferable_str13)}), v_sp_2450});
      }
      default: return heff_nomatch(v_x111_247);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etoInferable_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epresyntax_2etoInferable(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewordOf_str0, 22, "`Array` takes one type");
Clo g_heff_2esyntax_2epresyntax_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewordOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ewordOf(V v_x1_240, V v_sp_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_TypeWord: {
    V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TType), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_242});
  }
  case TAG_IntWord: {
    V v_t_243 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TInt), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_243});
  }
  case TAG_FloatWord: {
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TFloat), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_244});
  }
  case TAG_StringWord: {
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TString), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_245});
  }
  case TAG_RuneWord: {
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_TRune), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_246});
  }
  case TAG_ArrayWord: {
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2ewordOf_str0)}), heff_dup(v_sp_241)});
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_t_247}), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_248});
  }
  case TAG_AbandonWord: {
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_241});
    return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_249});
  }
  case TAG_FixedWord: {
    V v_w_2410 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24FixedWord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24FixedWord, TAG_TFixed, 1, (V[]){v_w_2410}), v_sp_241});
    return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewordOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eargOf(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EVar, 1);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      V v_t_2418;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2415}), v_t_2418});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EImplicitVar, 1);
        v_t_2430 = v_c_2425;
        break;
      }
      case TAG_IsType: {
        V v_t_2426 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      V v_t_2433;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2430}), v_t_2433});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2445;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_IsInferable: {
        V v_i_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2439;
        switch (heff_tag_of(v_i_2436)) {
        case TAG_At: {
          V v_s_2438 = heff_dup(heff_field(v_i_2436, 1));
          v_t_2439 = v_s_2438;
          break;
        }
        default: heff_nomatch(v_i_2436);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_CInf, 1, (V[]){v_i_2436}), v_t_2439});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2440 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ETag, 1);
        v_t_2445 = v_c_2440;
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        V v_t_2444;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_s_2443 = heff_dup(heff_field(v_t_2441, 1));
          v_t_2444 = v_s_2443;
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_CType, 1, (V[]){v_t_2441}), v_t_2444});
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2448;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2445}), v_t_2448});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2460;
      switch (heff_tag_of(v_x1_2450)) {
      case TAG_IsInferable: {
        V v_i_2451 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2454;
        switch (heff_tag_of(v_i_2451)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_i_2451, 1));
          v_t_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_i_2451);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_CInf, 1, (V[]){v_i_2451}), v_t_2454});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2455 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EInt, 1);
        v_t_2460 = v_c_2455;
        break;
      }
      case TAG_IsType: {
        V v_t_2456 = heff_field(v_x1_2450, 0);
        heff_take_n(v_x1_2450, 1ULL, 1);
        V v_t_2459;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_At: {
          V v_s_2458 = heff_dup(heff_field(v_t_2456, 1));
          v_t_2459 = v_s_2458;
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_CType, 1, (V[]){v_t_2456}), v_t_2459});
        break;
      }
      default: heff_nomatch(v_x1_2450);
      }
      V v_t_2463;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2462 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2460}), v_t_2463});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2475;
      switch (heff_tag_of(v_x1_2465)) {
      case TAG_IsInferable: {
        V v_i_2466 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2469;
        switch (heff_tag_of(v_i_2466)) {
        case TAG_At: {
          V v_s_2468 = heff_dup(heff_field(v_i_2466, 1));
          v_t_2469 = v_s_2468;
          break;
        }
        default: heff_nomatch(v_i_2466);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_CInf, 1, (V[]){v_i_2466}), v_t_2469});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2470 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EFloat, 1);
        v_t_2475 = v_c_2470;
        break;
      }
      case TAG_IsType: {
        V v_t_2471 = heff_field(v_x1_2465, 0);
        heff_take_n(v_x1_2465, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_t_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_CType, 1, (V[]){v_t_2471}), v_t_2474});
        break;
      }
      default: heff_nomatch(v_x1_2465);
      }
      V v_t_2478;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2477 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2475}), v_t_2478});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2480 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_2490;
      switch (heff_tag_of(v_x1_2480)) {
      case TAG_IsInferable: {
        V v_i_2481 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2484;
        switch (heff_tag_of(v_i_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_i_2481, 1));
          v_t_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_i_2481);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_CInf, 1, (V[]){v_i_2481}), v_t_2484});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2485 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EString, 1);
        v_t_2490 = v_c_2485;
        break;
      }
      case TAG_IsType: {
        V v_t_2486 = heff_field(v_x1_2480, 0);
        heff_take_n(v_x1_2480, 1ULL, 1);
        V v_t_2489;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_At: {
          V v_s_2488 = heff_dup(heff_field(v_t_2486, 1));
          v_t_2489 = v_s_2488;
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_CType, 1, (V[]){v_t_2486}), v_t_2489});
        break;
      }
      default: heff_nomatch(v_x1_2480);
      }
      V v_t_2493;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_2492 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2490}), v_t_2493});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_2495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24105;
      switch (heff_tag_of(v_x1_2495)) {
      case TAG_IsInferable: {
        V v_i_2496 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_2499;
        switch (heff_tag_of(v_i_2496)) {
        case TAG_At: {
          V v_s_2498 = heff_dup(heff_field(v_i_2496, 1));
          v_t_2499 = v_s_2498;
          break;
        }
        default: heff_nomatch(v_i_2496);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_CInf, 1, (V[]){v_i_2496}), v_t_2499});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24100 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ERune, 1);
        v_t_24105 = v_c_24100;
        break;
      }
      case TAG_IsType: {
        V v_t_24101 = heff_field(v_x1_2495, 0);
        heff_take_n(v_x1_2495, 1ULL, 1);
        V v_t_24104;
        switch (heff_tag_of(v_t_24101)) {
        case TAG_At: {
          V v_s_24103 = heff_dup(heff_field(v_t_24101, 1));
          v_t_24104 = v_s_24103;
          break;
        }
        default: heff_nomatch(v_t_24101);
        }
        v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_CType, 1, (V[]){v_t_24101}), v_t_24104});
        break;
      }
      default: heff_nomatch(v_x1_2495);
      }
      V v_t_24108;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24107 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24108 = v_s_24107;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24105}), v_t_24108});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24110 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24120;
      switch (heff_tag_of(v_x1_24110)) {
      case TAG_IsInferable: {
        V v_i_24111 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24114;
        switch (heff_tag_of(v_i_24111)) {
        case TAG_At: {
          V v_s_24113 = heff_dup(heff_field(v_i_24111, 1));
          v_t_24114 = v_s_24113;
          break;
        }
        default: heff_nomatch(v_i_24111);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_CInf, 1, (V[]){v_i_24111}), v_t_24114});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24115 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EWord, 1);
        v_t_24120 = v_c_24115;
        break;
      }
      case TAG_IsType: {
        V v_t_24116 = heff_field(v_x1_24110, 0);
        heff_take_n(v_x1_24110, 1ULL, 1);
        V v_t_24119;
        switch (heff_tag_of(v_t_24116)) {
        case TAG_At: {
          V v_s_24118 = heff_dup(heff_field(v_t_24116, 1));
          v_t_24119 = v_s_24118;
          break;
        }
        default: heff_nomatch(v_t_24116);
        }
        v_t_24120 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_CType, 1, (V[]){v_t_24116}), v_t_24119});
        break;
      }
      default: heff_nomatch(v_x1_24110);
      }
      V v_t_24123;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24122 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24123 = v_s_24122;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24120}), v_t_24123});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24126 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24136;
      switch (heff_tag_of(v_x1_24126)) {
      case TAG_IsInferable: {
        V v_i_24127 = heff_field(v_x1_24126, 0);
        heff_take_n(v_x1_24126, 1ULL, 1);
        V v_t_24130;
        switch (heff_tag_of(v_i_24127)) {
        case TAG_At: {
          V v_s_24129 = heff_dup(heff_field(v_i_24127, 1));
          v_t_24130 = v_s_24129;
          break;
        }
        default: heff_nomatch(v_i_24127);
        }
        v_t_24136 = heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24127}), v_t_24130});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24131 = heff_field(v_x1_24126, 0);
        heff_take_n(v_x1_24126, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EApp, 2);
        v_t_24136 = v_c_24131;
        break;
      }
      case TAG_IsType: {
        V v_t_24132 = heff_field(v_x1_24126, 0);
        heff_take_n(v_x1_24126, 1ULL, 1);
        V v_t_24135;
        switch (heff_tag_of(v_t_24132)) {
        case TAG_At: {
          V v_s_24134 = heff_dup(heff_field(v_t_24132, 1));
          v_t_24135 = v_s_24134;
          break;
        }
        default: heff_nomatch(v_t_24132);
        }
        v_t_24136 = heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24132}), v_t_24135});
        break;
      }
      default: heff_nomatch(v_x1_24126);
      }
      V v_t_24139;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24138 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24139 = v_s_24138;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24136}), v_t_24139});
    }
    case TAG_EProject: {
      V v_x_24140 = heff_field(v_e1_242, 0);
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_tag(v_e_241, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_ArgProject, 1, (V[]){v_x_24140}), v_sp_243});
    }
    case TAG_ENamed: {
      V v_x_24141 = heff_field(v_e1_242, 0);
      V v_e12_24142 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_x1_24143 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e12_24142}));
      V v_t_24153;
      switch (heff_tag_of(v_x1_24143)) {
      case TAG_IsInferable: {
        V v_i_24144 = heff_field(v_x1_24143, 0);
        heff_take_n(v_x1_24143, 1ULL, 1);
        V v_t_24147;
        switch (heff_tag_of(v_i_24144)) {
        case TAG_At: {
          V v_s_24146 = heff_dup(heff_field(v_i_24144, 1));
          v_t_24147 = v_s_24146;
          break;
        }
        default: heff_nomatch(v_i_24144);
        }
        v_t_24153 = heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24144}), v_t_24147});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24148 = heff_field(v_x1_24143, 0);
        heff_take_n(v_x1_24143, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ENamed, 2);
        v_t_24153 = v_c_24148;
        break;
      }
      case TAG_IsType: {
        V v_t_24149 = heff_field(v_x1_24143, 0);
        heff_take_n(v_x1_24143, 1ULL, 1);
        V v_t_24152;
        switch (heff_tag_of(v_t_24149)) {
        case TAG_At: {
          V v_s_24151 = heff_dup(heff_field(v_t_24149, 1));
          v_t_24152 = v_s_24151;
          break;
        }
        default: heff_nomatch(v_t_24149);
        }
        v_t_24153 = heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24149}), v_t_24152});
        break;
      }
      default: heff_nomatch(v_x1_24143);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24141, v_t_24153}), v_sp_243});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24156 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24166;
      switch (heff_tag_of(v_x1_24156)) {
      case TAG_IsInferable: {
        V v_i_24157 = heff_field(v_x1_24156, 0);
        heff_take_n(v_x1_24156, 1ULL, 1);
        V v_t_24160;
        switch (heff_tag_of(v_i_24157)) {
        case TAG_At: {
          V v_s_24159 = heff_dup(heff_field(v_i_24157, 1));
          v_t_24160 = v_s_24159;
          break;
        }
        default: heff_nomatch(v_i_24157);
        }
        v_t_24166 = heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24157}), v_t_24160});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24161 = heff_field(v_x1_24156, 0);
        heff_take_n(v_x1_24156, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EPi, 2);
        v_t_24166 = v_c_24161;
        break;
      }
      case TAG_IsType: {
        V v_t_24162 = heff_field(v_x1_24156, 0);
        heff_take_n(v_x1_24156, 1ULL, 1);
        V v_t_24165;
        switch (heff_tag_of(v_t_24162)) {
        case TAG_At: {
          V v_s_24164 = heff_dup(heff_field(v_t_24162, 1));
          v_t_24165 = v_s_24164;
          break;
        }
        default: heff_nomatch(v_t_24162);
        }
        v_t_24166 = heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24162}), v_t_24165});
        break;
      }
      default: heff_nomatch(v_x1_24156);
      }
      V v_t_24169;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24168 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24169 = v_s_24168;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24166}), v_t_24169});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24172 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24182;
      switch (heff_tag_of(v_x1_24172)) {
      case TAG_IsInferable: {
        V v_i_24173 = heff_field(v_x1_24172, 0);
        heff_take_n(v_x1_24172, 1ULL, 1);
        V v_t_24176;
        switch (heff_tag_of(v_i_24173)) {
        case TAG_At: {
          V v_s_24175 = heff_dup(heff_field(v_i_24173, 1));
          v_t_24176 = v_s_24175;
          break;
        }
        default: heff_nomatch(v_i_24173);
        }
        v_t_24182 = heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24173}), v_t_24176});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24177 = heff_field(v_x1_24172, 0);
        heff_take_n(v_x1_24172, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELam, 2);
        v_t_24182 = v_c_24177;
        break;
      }
      case TAG_IsType: {
        V v_t_24178 = heff_field(v_x1_24172, 0);
        heff_take_n(v_x1_24172, 1ULL, 1);
        V v_t_24181;
        switch (heff_tag_of(v_t_24178)) {
        case TAG_At: {
          V v_s_24180 = heff_dup(heff_field(v_t_24178, 1));
          v_t_24181 = v_s_24180;
          break;
        }
        default: heff_nomatch(v_t_24178);
        }
        v_t_24182 = heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24178}), v_t_24181});
        break;
      }
      default: heff_nomatch(v_x1_24172);
      }
      V v_t_24185;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24184 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24185 = v_s_24184;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24182}), v_t_24185});
    }
    case TAG_EAnn: {
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24188 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24198;
      switch (heff_tag_of(v_x1_24188)) {
      case TAG_IsInferable: {
        V v_i_24189 = heff_field(v_x1_24188, 0);
        heff_take_n(v_x1_24188, 1ULL, 1);
        V v_t_24192;
        switch (heff_tag_of(v_i_24189)) {
        case TAG_At: {
          V v_s_24191 = heff_dup(heff_field(v_i_24189, 1));
          v_t_24192 = v_s_24191;
          break;
        }
        default: heff_nomatch(v_i_24189);
        }
        v_t_24198 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24189}), v_t_24192});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24193 = heff_field(v_x1_24188, 0);
        heff_take_n(v_x1_24188, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EAnn, 2);
        v_t_24198 = v_c_24193;
        break;
      }
      case TAG_IsType: {
        V v_t_24194 = heff_field(v_x1_24188, 0);
        heff_take_n(v_x1_24188, 1ULL, 1);
        V v_t_24197;
        switch (heff_tag_of(v_t_24194)) {
        case TAG_At: {
          V v_s_24196 = heff_dup(heff_field(v_t_24194, 1));
          v_t_24197 = v_s_24196;
          break;
        }
        default: heff_nomatch(v_t_24194);
        }
        v_t_24198 = heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24194}), v_t_24197});
        break;
      }
      default: heff_nomatch(v_x1_24188);
      }
      V v_t_24201;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24200 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24201 = v_s_24200;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24198}), v_t_24201});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_sp_243);
      V v_x1_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24216;
      switch (heff_tag_of(v_x1_24206)) {
      case TAG_IsInferable: {
        V v_i_24207 = heff_field(v_x1_24206, 0);
        V v_ru_24x1_24206_24IsInferable = heff_take_reuse_n(v_x1_24206, 1ULL, 1);
        V v_t_24210;
        switch (heff_tag_of(v_i_24207)) {
        case TAG_At: {
          V v_s_24209 = heff_dup(heff_field(v_i_24207, 1));
          v_t_24210 = v_s_24209;
          break;
        }
        default: heff_nomatch(v_i_24207);
        }
        v_t_24216 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24206_24IsInferable, TAG_CInf, 1, (V[]){v_i_24207}), v_t_24210});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24211 = heff_field(v_x1_24206, 0);
        heff_take_n(v_x1_24206, 1ULL, 1);
        v_t_24216 = v_c_24211;
        break;
      }
      case TAG_IsType: {
        V v_t_24212 = heff_field(v_x1_24206, 0);
        V v_ru_24x1_24206_24IsType = heff_take_reuse_n(v_x1_24206, 1ULL, 1);
        V v_t_24215;
        switch (heff_tag_of(v_t_24212)) {
        case TAG_At: {
          V v_s_24214 = heff_dup(heff_field(v_t_24212, 1));
          v_t_24215 = v_s_24214;
          break;
        }
        default: heff_nomatch(v_t_24212);
        }
        v_t_24216 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24206_24IsType, TAG_CType, 1, (V[]){v_t_24212}), v_t_24215});
        break;
      }
      default: heff_nomatch(v_x1_24206);
      }
      V v_t_24219;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24218 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24219 = v_s_24218;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24216}), v_t_24219});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24221 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24231;
      switch (heff_tag_of(v_x1_24221)) {
      case TAG_IsInferable: {
        V v_i_24222 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        V v_t_24225;
        switch (heff_tag_of(v_i_24222)) {
        case TAG_At: {
          V v_s_24224 = heff_dup(heff_field(v_i_24222, 1));
          v_t_24225 = v_s_24224;
          break;
        }
        default: heff_nomatch(v_i_24222);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_CInf, 1, (V[]){v_i_24222}), v_t_24225});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24226 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ESig, 1);
        v_t_24231 = v_c_24226;
        break;
      }
      case TAG_IsType: {
        V v_t_24227 = heff_field(v_x1_24221, 0);
        heff_take_n(v_x1_24221, 1ULL, 1);
        V v_t_24230;
        switch (heff_tag_of(v_t_24227)) {
        case TAG_At: {
          V v_s_24229 = heff_dup(heff_field(v_t_24227, 1));
          v_t_24230 = v_s_24229;
          break;
        }
        default: heff_nomatch(v_t_24227);
        }
        v_t_24231 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_CType, 1, (V[]){v_t_24227}), v_t_24230});
        break;
      }
      default: heff_nomatch(v_x1_24221);
      }
      V v_t_24234;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24233 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24234 = v_s_24233;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24231}), v_t_24234});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24236 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24246;
      switch (heff_tag_of(v_x1_24236)) {
      case TAG_IsInferable: {
        V v_i_24237 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24240;
        switch (heff_tag_of(v_i_24237)) {
        case TAG_At: {
          V v_s_24239 = heff_dup(heff_field(v_i_24237, 1));
          v_t_24240 = v_s_24239;
          break;
        }
        default: heff_nomatch(v_i_24237);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_CInf, 1, (V[]){v_i_24237}), v_t_24240});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24241 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ESum, 1);
        v_t_24246 = v_c_24241;
        break;
      }
      case TAG_IsType: {
        V v_t_24242 = heff_field(v_x1_24236, 0);
        heff_take_n(v_x1_24236, 1ULL, 1);
        V v_t_24245;
        switch (heff_tag_of(v_t_24242)) {
        case TAG_At: {
          V v_s_24244 = heff_dup(heff_field(v_t_24242, 1));
          v_t_24245 = v_s_24244;
          break;
        }
        default: heff_nomatch(v_t_24242);
        }
        v_t_24246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_CType, 1, (V[]){v_t_24242}), v_t_24245});
        break;
      }
      default: heff_nomatch(v_x1_24236);
      }
      V v_t_24249;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24248 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24249 = v_s_24248;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24246}), v_t_24249});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24261;
      switch (heff_tag_of(v_x1_24251)) {
      case TAG_IsInferable: {
        V v_i_24252 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24255;
        switch (heff_tag_of(v_i_24252)) {
        case TAG_At: {
          V v_s_24254 = heff_dup(heff_field(v_i_24252, 1));
          v_t_24255 = v_s_24254;
          break;
        }
        default: heff_nomatch(v_i_24252);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_CInf, 1, (V[]){v_i_24252}), v_t_24255});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24256 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EStruct, 1);
        v_t_24261 = v_c_24256;
        break;
      }
      case TAG_IsType: {
        V v_t_24257 = heff_field(v_x1_24251, 0);
        heff_take_n(v_x1_24251, 1ULL, 1);
        V v_t_24260;
        switch (heff_tag_of(v_t_24257)) {
        case TAG_At: {
          V v_s_24259 = heff_dup(heff_field(v_t_24257, 1));
          v_t_24260 = v_s_24259;
          break;
        }
        default: heff_nomatch(v_t_24257);
        }
        v_t_24261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_CType, 1, (V[]){v_t_24257}), v_t_24260});
        break;
      }
      default: heff_nomatch(v_x1_24251);
      }
      V v_t_24264;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24263 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24264 = v_s_24263;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24261}), v_t_24264});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24267 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24277;
      switch (heff_tag_of(v_x1_24267)) {
      case TAG_IsInferable: {
        V v_i_24268 = heff_field(v_x1_24267, 0);
        heff_take_n(v_x1_24267, 1ULL, 1);
        V v_t_24271;
        switch (heff_tag_of(v_i_24268)) {
        case TAG_At: {
          V v_s_24270 = heff_dup(heff_field(v_i_24268, 1));
          v_t_24271 = v_s_24270;
          break;
        }
        default: heff_nomatch(v_i_24268);
        }
        v_t_24277 = heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24268}), v_t_24271});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24272 = heff_field(v_x1_24267, 0);
        heff_take_n(v_x1_24267, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EMatch, 2);
        v_t_24277 = v_c_24272;
        break;
      }
      case TAG_IsType: {
        V v_t_24273 = heff_field(v_x1_24267, 0);
        heff_take_n(v_x1_24267, 1ULL, 1);
        V v_t_24276;
        switch (heff_tag_of(v_t_24273)) {
        case TAG_At: {
          V v_s_24275 = heff_dup(heff_field(v_t_24273, 1));
          v_t_24276 = v_s_24275;
          break;
        }
        default: heff_nomatch(v_t_24273);
        }
        v_t_24277 = heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24273}), v_t_24276});
        break;
      }
      default: heff_nomatch(v_x1_24267);
      }
      V v_t_24280;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24279 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24280 = v_s_24279;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24277}), v_t_24280});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24283 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24293;
      switch (heff_tag_of(v_x1_24283)) {
      case TAG_IsInferable: {
        V v_i_24284 = heff_field(v_x1_24283, 0);
        heff_take_n(v_x1_24283, 1ULL, 1);
        V v_t_24287;
        switch (heff_tag_of(v_i_24284)) {
        case TAG_At: {
          V v_s_24286 = heff_dup(heff_field(v_i_24284, 1));
          v_t_24287 = v_s_24286;
          break;
        }
        default: heff_nomatch(v_i_24284);
        }
        v_t_24293 = heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24284}), v_t_24287});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24288 = heff_field(v_x1_24283, 0);
        heff_take_n(v_x1_24283, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELetIn, 2);
        v_t_24293 = v_c_24288;
        break;
      }
      case TAG_IsType: {
        V v_t_24289 = heff_field(v_x1_24283, 0);
        heff_take_n(v_x1_24283, 1ULL, 1);
        V v_t_24292;
        switch (heff_tag_of(v_t_24289)) {
        case TAG_At: {
          V v_s_24291 = heff_dup(heff_field(v_t_24289, 1));
          v_t_24292 = v_s_24291;
          break;
        }
        default: heff_nomatch(v_t_24289);
        }
        v_t_24293 = heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24289}), v_t_24292});
        break;
      }
      default: heff_nomatch(v_x1_24283);
      }
      V v_t_24296;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24295 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24296 = v_s_24295;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24293}), v_t_24296});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24298 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24308;
      switch (heff_tag_of(v_x1_24298)) {
      case TAG_IsInferable: {
        V v_i_24299 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24302;
        switch (heff_tag_of(v_i_24299)) {
        case TAG_At: {
          V v_s_24301 = heff_dup(heff_field(v_i_24299, 1));
          v_t_24302 = v_s_24301;
          break;
        }
        default: heff_nomatch(v_i_24299);
        }
        v_t_24308 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_CInf, 1, (V[]){v_i_24299}), v_t_24302});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24303 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EDo, 1);
        v_t_24308 = v_c_24303;
        break;
      }
      case TAG_IsType: {
        V v_t_24304 = heff_field(v_x1_24298, 0);
        heff_take_n(v_x1_24298, 1ULL, 1);
        V v_t_24307;
        switch (heff_tag_of(v_t_24304)) {
        case TAG_At: {
          V v_s_24306 = heff_dup(heff_field(v_t_24304, 1));
          v_t_24307 = v_s_24306;
          break;
        }
        default: heff_nomatch(v_t_24304);
        }
        v_t_24308 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_CType, 1, (V[]){v_t_24304}), v_t_24307});
        break;
      }
      default: heff_nomatch(v_x1_24298);
      }
      V v_t_24311;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24310 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24311 = v_s_24310;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24308}), v_t_24311});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_sp_243);
      V v_x1_24314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24324;
      switch (heff_tag_of(v_x1_24314)) {
      case TAG_IsInferable: {
        V v_i_24315 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24318;
        switch (heff_tag_of(v_i_24315)) {
        case TAG_At: {
          V v_s_24317 = heff_dup(heff_field(v_i_24315, 1));
          v_t_24318 = v_s_24317;
          break;
        }
        default: heff_nomatch(v_i_24315);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24315}), v_t_24318});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24319 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24ELocal, 2);
        v_t_24324 = v_c_24319;
        break;
      }
      case TAG_IsType: {
        V v_t_24320 = heff_field(v_x1_24314, 0);
        heff_take_n(v_x1_24314, 1ULL, 1);
        V v_t_24323;
        switch (heff_tag_of(v_t_24320)) {
        case TAG_At: {
          V v_s_24322 = heff_dup(heff_field(v_t_24320, 1));
          v_t_24323 = v_s_24322;
          break;
        }
        default: heff_nomatch(v_t_24320);
        }
        v_t_24324 = heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24320}), v_t_24323});
        break;
      }
      default: heff_nomatch(v_x1_24314);
      }
      V v_t_24327;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24326 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24327 = v_s_24326;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24324}), v_t_24327});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_sp_243);
      V v_x1_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){heff_dup(v_e_241)}));
      V v_t_24339;
      switch (heff_tag_of(v_x1_24329)) {
      case TAG_IsInferable: {
        V v_i_24330 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24333;
        switch (heff_tag_of(v_i_24330)) {
        case TAG_At: {
          V v_s_24332 = heff_dup(heff_field(v_i_24330, 1));
          v_t_24333 = v_s_24332;
          break;
        }
        default: heff_nomatch(v_i_24330);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_CInf, 1, (V[]){v_i_24330}), v_t_24333});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24334 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_242_24EInvalid, 1);
        v_t_24339 = v_c_24334;
        break;
      }
      case TAG_IsType: {
        V v_t_24335 = heff_field(v_x1_24329, 0);
        heff_take_n(v_x1_24329, 1ULL, 1);
        V v_t_24338;
        switch (heff_tag_of(v_t_24335)) {
        case TAG_At: {
          V v_s_24337 = heff_dup(heff_field(v_t_24335, 1));
          v_t_24338 = v_s_24337;
          break;
        }
        default: heff_nomatch(v_t_24335);
        }
        v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_CType, 1, (V[]){v_t_24335}), v_t_24338});
        break;
      }
      default: heff_nomatch(v_x1_24329);
      }
      V v_t_24342;
      switch (heff_tag_of(v_e_241)) {
      case TAG_At: {
        V v_s_24341 = heff_field(v_e_241, 1);
        heff_take_n(v_e_241, 2ULL, 2);
        v_t_24342 = v_s_24341;
        break;
      }
      default: heff_nomatch(v_e_241);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24339}), v_t_24342});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_str1, 22, "`Array` takes one type");
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eappOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_entry, 4, 0};

V g_heff_2esyntax_2epresyntax_2eappOf(V v_r_240, V v_h_241, V v_args_242, V v_sp_243) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_At: {
    V v_h1_244 = heff_dup(heff_field(v_h_241, 0));
    V v_tsp_245 = heff_dup(heff_field(v_h_241, 1));
    switch (heff_tag_of(v_h1_244)) {
    case TAG_EVar: {
      V v_ru_24h1_244_24EVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_247); r_; });
      V v_t_249 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2410 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, (g_list_2emap(v_t_249, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EVar, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_243})});
    }
    case TAG_EImplicitVar: {
      V v_ru_24h1_244_24EImplicitVar = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2412); r_; });
      V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2415 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, (g_list_2emap(v_t_2414, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EImplicitVar, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_243})});
    }
    case TAG_ETag: {
      V v_t_2416 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24ETag = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      heff_drop_tag(v_h_241, 2);
      V v_t_2428 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_2416, v_tsp_245, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2eappOf_lam0, 1, 1, (V[]){v_r_240}), v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2428, v_sp_243})});
    }
    case TAG_EInt: {
      V v_ru_24h1_244_24EInt = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2431 = ({ V a_0 = v_t_2430; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2430); r_; });
      V v_t_2432 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2433 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2431, (g_list_2emap(v_t_2432, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EInt, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, v_sp_243})});
    }
    case TAG_EFloat: {
      V v_ru_24h1_244_24EFloat = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2435); r_; });
      V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2438 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, (g_list_2emap(v_t_2437, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EFloat, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_243})});
    }
    case TAG_EString: {
      V v_ru_24h1_244_24EString = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2440 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2440); r_; });
      V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2443 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2441, (g_list_2emap(v_t_2442, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EString, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_sp_243})});
    }
    case TAG_ERune: {
      V v_ru_24h1_244_24ERune = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_2446 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2445); r_; });
      V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_2448 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2446, (g_list_2emap(v_t_2447, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24ERune, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_243})});
    }
    case TAG_EWord: {
      V v_h11_2449 = heff_field(v_h1_244, 0);
      V v_ru_24h1_244_24EWord = heff_take_reuse_n(v_h1_244, 1ULL, 1);
      heff_drop(v_tsp_245);
      switch (heff_tag_of(v_h11_2449)) {
      case TAG_TypeWord: {
        V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2451 = ({ V a_0 = v_t_2450; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2450); r_; });
        V v_t_2452 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2453 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2451, (g_list_2emap(v_t_2452, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2453, v_sp_243})});
      }
      case TAG_IntWord: {
        V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2455 = ({ V a_0 = v_t_2454; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2454); r_; });
        V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2457 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2455, (g_list_2emap(v_t_2456, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2457, v_sp_243})});
      }
      case TAG_FloatWord: {
        V v_t_2458 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2459 = ({ V a_0 = v_t_2458; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2458); r_; });
        V v_t_2460 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2461 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2459, (g_list_2emap(v_t_2460, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2461, v_sp_243})});
      }
      case TAG_StringWord: {
        V v_t_2462 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2463 = ({ V a_0 = v_t_2462; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2462); r_; });
        V v_t_2464 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2465 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2463, (g_list_2emap(v_t_2464, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2465, v_sp_243})});
      }
      case TAG_RuneWord: {
        V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2467 = ({ V a_0 = v_t_2466; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2466); r_; });
        V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2469 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2467, (g_list_2emap(v_t_2468, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_sp_243})});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_241, 2);
        switch (heff_tag_of(v_args_242)) {
        case TAG_Nil: {
          heff_drop_rec(v_r_240, 2);
          V v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str0)}), heff_dup(v_sp_243)});
          V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_t_2470}), v_sp_243});
          return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2471});
        }
        case TAG_Cons: {
          V v_a_2472 = heff_field(v_args_242, 0);
          V v_args2_2473 = heff_field(v_args_242, 1);
          V v_ru_24args_242_24Cons = heff_take_reuse_n(v_args_242, 3ULL, 2);
          switch (heff_tag_of(v_args2_2473)) {
          case TAG_Nil: {
            V v_x1_2474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_2472}));
            V v_t_2484;
            switch (heff_tag_of(v_x1_2474)) {
            case TAG_IsInferable: {
              V v_i_2475 = heff_field(v_x1_2474, 0);
              heff_take_n(v_x1_2474, 1ULL, 1);
              V v_t_2478;
              switch (heff_tag_of(v_i_2475)) {
              case TAG_At: {
                V v_s_2477 = heff_dup(heff_field(v_i_2475, 1));
                v_t_2478 = v_s_2477;
                break;
              }
              default: heff_nomatch(v_i_2475);
              }
              v_t_2484 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_i_2475}), v_t_2478});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2479 = heff_field(v_x1_2474, 0);
              heff_take_n(v_x1_2474, 1ULL, 1);
              V v_t_2482;
              switch (heff_tag_of(v_c_2479)) {
              case TAG_At: {
                V v_s_2481 = heff_dup(heff_field(v_c_2479, 1));
                v_t_2482 = v_s_2481;
                break;
              }
              default: heff_nomatch(v_c_2479);
              }
              v_t_2484 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TChk, 1, (V[]){v_c_2479}), v_t_2482});
              break;
            }
            case TAG_IsType: {
              V v_t_2483 = heff_field(v_x1_2474, 0);
              heff_take_n(v_x1_2474, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_244_24EWord, 1);
              heff_drop_cell(v_ru_24args_242_24Cons, 2);
              v_t_2484 = v_t_2483;
              break;
            }
            default: heff_nomatch(v_x1_2474);
            }
            V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2484}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2485});
          }
          case TAG_Cons: {
            V v_ru_24args2_2473_24Cons = heff_take_reuse_n(v_args2_2473, 0ULL, 2);
            heff_drop_rec(v_r_240, 2);
            heff_drop(v_a_2472);
            V v_t_2488 = heff_tag_at_n(v_ru_24args_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_str1)}), heff_dup(v_sp_243)});
            V v_t_2489 = heff_tag_at_n(v_ru_24args2_2473_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_TInf, 1, (V[]){v_t_2488}), v_sp_243});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2489});
          }
          default: return heff_nomatch(v_args2_2473);
          }
        }
        default: return heff_nomatch(v_args_242);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2490 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2491 = ({ V a_0 = v_t_2490; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2490); r_; });
        V v_t_2492 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2493 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2491, (g_list_2emap(v_t_2492, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2493, v_sp_243})});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2449, 0ULL, 1);
        V v_t_2495 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
        V v_t_2496 = ({ V a_0 = v_t_2495; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2495); r_; });
        V v_t_2497 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
        V v_t_2498 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2496, (g_list_2emap(v_t_2497, v_args_242))});
        return heff_tag_at_n(v_ru_24h1_244_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2498, v_sp_243})});
      }
      default: return heff_nomatch(v_h11_2449);
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_244_24EApp = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24101 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24102 = ({ V a_0 = v_t_24101; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24101); r_; });
      V v_t_24103 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24104 = heff_tag_at_n(v_ru_24h1_244_24EApp, TAG_IApp, 2, (V[]){v_t_24102, (g_list_2emap(v_t_24103, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24104, v_sp_243})});
    }
    case TAG_EProject: {
      V v_ru_24h1_244_24EProject = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24106 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24107 = ({ V a_0 = v_t_24106; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24106); r_; });
      V v_t_24108 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24109 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24107, (g_list_2emap(v_t_24108, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24109, v_sp_243})});
    }
    case TAG_ENamed: {
      V v_ru_24h1_244_24ENamed = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24112 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24113 = ({ V a_0 = v_t_24112; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24112); r_; });
      V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24115 = heff_tag_at_n(v_ru_24h1_244_24ENamed, TAG_IApp, 2, (V[]){v_t_24113, (g_list_2emap(v_t_24114, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24115, v_sp_243})});
    }
    case TAG_EPi: {
      V v_ru_24h1_244_24EPi = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24118 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24119 = ({ V a_0 = v_t_24118; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24118); r_; });
      V v_t_24120 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24121 = heff_tag_at_n(v_ru_24h1_244_24EPi, TAG_IApp, 2, (V[]){v_t_24119, (g_list_2emap(v_t_24120, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24121, v_sp_243})});
    }
    case TAG_ELam: {
      V v_ru_24h1_244_24ELam = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24124 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24125 = ({ V a_0 = v_t_24124; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24124); r_; });
      V v_t_24126 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24127 = heff_tag_at_n(v_ru_24h1_244_24ELam, TAG_IApp, 2, (V[]){v_t_24125, (g_list_2emap(v_t_24126, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24127, v_sp_243})});
    }
    case TAG_EAnn: {
      V v_ru_24h1_244_24EAnn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24130 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24131 = ({ V a_0 = v_t_24130; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24130); r_; });
      V v_t_24132 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24133 = heff_tag_at_n(v_ru_24h1_244_24EAnn, TAG_IApp, 2, (V[]){v_t_24131, (g_list_2emap(v_t_24132, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24133, v_sp_243})});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_244, 0ULL, 4);
      heff_drop(v_tsp_245);
      V v_t_24138 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24139 = ({ V a_0 = v_t_24138; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24138); r_; });
      V v_t_24140 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24141 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24139, (g_list_2emap(v_t_24140, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24141, v_sp_243})});
    }
    case TAG_ESig: {
      V v_ru_24h1_244_24ESig = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24143 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24144 = ({ V a_0 = v_t_24143; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24143); r_; });
      V v_t_24145 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24146 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24144, (g_list_2emap(v_t_24145, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24ESig, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24146, v_sp_243})});
    }
    case TAG_ESum: {
      V v_ru_24h1_244_24ESum = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24148 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24149 = ({ V a_0 = v_t_24148; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24148); r_; });
      V v_t_24150 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24151 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24149, (g_list_2emap(v_t_24150, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24ESum, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24151, v_sp_243})});
    }
    case TAG_EStruct: {
      V v_ru_24h1_244_24EStruct = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24153 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24154 = ({ V a_0 = v_t_24153; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24153); r_; });
      V v_t_24155 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24156 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24154, (g_list_2emap(v_t_24155, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EStruct, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24156, v_sp_243})});
    }
    case TAG_EMatch: {
      V v_ru_24h1_244_24EMatch = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24159 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24160 = ({ V a_0 = v_t_24159; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24159); r_; });
      V v_t_24161 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24162 = heff_tag_at_n(v_ru_24h1_244_24EMatch, TAG_IApp, 2, (V[]){v_t_24160, (g_list_2emap(v_t_24161, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24162, v_sp_243})});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_244_24ELetIn = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24165 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24166 = ({ V a_0 = v_t_24165; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24165); r_; });
      V v_t_24167 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24168 = heff_tag_at_n(v_ru_24h1_244_24ELetIn, TAG_IApp, 2, (V[]){v_t_24166, (g_list_2emap(v_t_24167, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24168, v_sp_243})});
    }
    case TAG_EDo: {
      V v_ru_24h1_244_24EDo = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24170 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24171 = ({ V a_0 = v_t_24170; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24170); r_; });
      V v_t_24172 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24173 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24171, (g_list_2emap(v_t_24172, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24173, v_sp_243})});
    }
    case TAG_ELocal: {
      V v_ru_24h1_244_24ELocal = heff_take_reuse_n(v_h1_244, 0ULL, 2);
      heff_drop(v_tsp_245);
      V v_t_24176 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24177 = ({ V a_0 = v_t_24176; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24176); r_; });
      V v_t_24178 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24179 = heff_tag_at_n(v_ru_24h1_244_24ELocal, TAG_IApp, 2, (V[]){v_t_24177, (g_list_2emap(v_t_24178, v_args_242))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24179, v_sp_243})});
    }
    case TAG_EInvalid: {
      V v_ru_24h1_244_24EInvalid = heff_take_reuse_n(v_h1_244, 0ULL, 1);
      heff_drop(v_tsp_245);
      V v_t_24181 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_241}));
      V v_t_24182 = ({ V a_0 = v_t_24181; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24181); r_; });
      V v_t_24183 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eargOf_clo), 1, (V[]){v_r_240}));
      V v_t_24184 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24182, (g_list_2emap(v_t_24183, v_args_242))});
      return heff_tag_at_n(v_ru_24h1_244_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24184, v_sp_243})});
    }
    default: return heff_nomatch(v_h1_244);
    }
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epresyntax_2eappOf_lam0(V self, V *args) {
  V v_e_2417 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2417}));
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_IsInferable: {
    V v_i_2419 = heff_field(v_x1_2418, 0);
    V v_ru_24x1_2418_24IsInferable = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_i_2419)) {
    case TAG_At: {
      V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
      v_t_2422 = v_s_2421;
      break;
    }
    default: heff_nomatch(v_i_2419);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2418_24IsInferable, TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
  }
  case TAG_IsCheckable: {
    V v_c_2423 = heff_field(v_x1_2418, 0);
    heff_take_n(v_x1_2418, 1ULL, 1);
    return v_c_2423;
  }
  case TAG_IsType: {
    V v_t_2424 = heff_field(v_x1_2418, 0);
    V v_ru_24x1_2418_24IsType = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
      v_t_2427 = v_s_2426;
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2418_24IsType, TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
  }
  default: return heff_nomatch(v_x1_2418);
  }
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xsp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_x1_245 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_244}));
    V v_t_2415;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsInferable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_dup(heff_field(v_i_246, 1));
        v_t_249 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsInferable, TAG_TInf, 1, (V[]){v_i_246}), v_t_249});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2410 = heff_field(v_x1_245, 0);
      V v_ru_24x1_245_24IsCheckable = heff_take_reuse_n(v_x1_245, 1ULL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_c_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_dup(heff_field(v_c_2410, 1));
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_c_2410);
      }
      v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_245_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2410}), v_t_2413});
      break;
    }
    case TAG_IsType: {
      V v_t_2414 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_2415 = v_t_2414;
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_242, v_xsp_243, v_t_2415});
  }
  case TAG_PiImplicit: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    V v_xsp_2417 = heff_field(v_x2_241, 1);
    V v_bsp_2418 = heff_field(v_x2_241, 2);
    V v_t_2419 = heff_field(v_x2_241, 3);
    V v_d_2420 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_x1_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2419}));
    V v_t_2431;
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_IsInferable: {
      V v_i_2422 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsInferable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2425;
      switch (heff_tag_of(v_i_2422)) {
      case TAG_At: {
        V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
        v_t_2425 = v_s_2424;
        break;
      }
      default: heff_nomatch(v_i_2422);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsInferable, TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2426 = heff_field(v_x1_2421, 0);
      V v_ru_24x1_2421_24IsCheckable = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_c_2426)) {
      case TAG_At: {
        V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
        v_t_2429 = v_s_2428;
        break;
      }
      default: heff_nomatch(v_c_2426);
      }
      v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2421_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
      break;
    }
    case TAG_IsType: {
      V v_t_2430 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 1);
      v_t_2431 = v_t_2430;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
    V v_t_2444;
    switch (heff_tag_of(v_d_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 2);
      v_t_2444 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2432 = heff_field(v_d_2420, 0);
      V v_ru_24d_2420_24Just = heff_take_reuse_n(v_d_2420, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_2420_24Just, TAG_CInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24d_2420_24Just, 1);
        v_t_2443 = v_c_2438;
        break;
      }
      case TAG_IsType: {
        V v_t_2439 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2442;
        switch (heff_tag_of(v_t_2439)) {
        case TAG_At: {
          V v_s_2441 = heff_dup(heff_field(v_t_2439, 1));
          v_t_2442 = v_s_2441;
          break;
        }
        default: heff_nomatch(v_t_2439);
        }
        v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_2420_24Just, TAG_CType, 1, (V[]){v_t_2439}), v_t_2442});
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      v_t_2444 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_d_2420);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2416, v_xsp_2417, v_bsp_2418, v_t_2431, v_t_2444});
  }
  case TAG_PiInstance: {
    V v_x_2445 = heff_field(v_x2_241, 0);
    V v_xsp_2446 = heff_field(v_x2_241, 1);
    V v_bsp_2447 = heff_field(v_x2_241, 2);
    V v_t_2448 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_x1_2449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2448}));
    V v_t_2459;
    switch (heff_tag_of(v_x1_2449)) {
    case TAG_IsInferable: {
      V v_i_2450 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsInferable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2453;
      switch (heff_tag_of(v_i_2450)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_i_2450);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsInferable, TAG_TInf, 1, (V[]){v_i_2450}), v_t_2453});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2454 = heff_field(v_x1_2449, 0);
      V v_ru_24x1_2449_24IsCheckable = heff_take_reuse_n(v_x1_2449, 1ULL, 1);
      V v_t_2457;
      switch (heff_tag_of(v_c_2454)) {
      case TAG_At: {
        V v_s_2456 = heff_dup(heff_field(v_c_2454, 1));
        v_t_2457 = v_s_2456;
        break;
      }
      default: heff_nomatch(v_c_2454);
      }
      v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2449_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2454}), v_t_2457});
      break;
    }
    case TAG_IsType: {
      V v_t_2458 = heff_field(v_x1_2449, 0);
      heff_take_n(v_x1_2449, 1ULL, 1);
      v_t_2459 = v_t_2458;
      break;
    }
    default: heff_nomatch(v_x1_2449);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2445, v_xsp_2446, v_bsp_2447, v_t_2459});
  }
  case TAG_PiAnon: {
    V v_t_2460 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_2461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2460}));
    V v_t_2471;
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_IsInferable: {
      V v_i_2462 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      V v_t_2465;
      switch (heff_tag_of(v_i_2462)) {
      case TAG_At: {
        V v_s_2464 = heff_dup(heff_field(v_i_2462, 1));
        v_t_2465 = v_s_2464;
        break;
      }
      default: heff_nomatch(v_i_2462);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_TInf, 1, (V[]){v_i_2462}), v_t_2465});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2466 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      V v_t_2469;
      switch (heff_tag_of(v_c_2466)) {
      case TAG_At: {
        V v_s_2468 = heff_dup(heff_field(v_c_2466, 1));
        v_t_2469 = v_s_2468;
        break;
      }
      default: heff_nomatch(v_c_2466);
      }
      v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_TChk, 1, (V[]){v_c_2466}), v_t_2469});
      break;
    }
    case TAG_IsType: {
      V v_t_2470 = heff_field(v_x1_2461, 0);
      heff_take_n(v_x1_2461, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24PiAnon, 1);
      v_t_2471 = v_t_2470;
      break;
    }
    default: heff_nomatch(v_x1_2461);
    }
    return heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2471});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkAlt = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_245}));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_at_n(v_ru_24x21_242_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_2416}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclareField = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2431;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 2);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_x_2419}));
        V v_t_2430;
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_IsInferable: {
          V v_i_2421 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_i_2421)) {
          case TAG_At: {
            V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
            v_t_2424 = v_s_2423;
            break;
          }
          default: heff_nomatch(v_i_2421);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_247_24Just, TAG_CInf, 1, (V[]){v_i_2421}), v_t_2424});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2425 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          heff_drop_cell(v_ru_24d_247_24Just, 1);
          v_t_2430 = v_c_2425;
          break;
        }
        case TAG_IsType: {
          V v_t_2426 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 1);
          V v_t_2429;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_At: {
            V v_s_2428 = heff_dup(heff_field(v_t_2426, 1));
            v_t_2429 = v_s_2428;
            break;
          }
          default: heff_nomatch(v_t_2426);
          }
          v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_247_24Just, TAG_CType, 1, (V[]){v_t_2426}), v_t_2429});
          break;
        }
        default: heff_nomatch(v_x1_2420);
        }
        v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_244, v_xsp_245, v_t_2418, v_t_2431}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2432 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldDecl = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2432}));
      V v_t_2443;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_IsInferable: {
        V v_i_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_i_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_i_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_i_2434);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2434}), v_t_2437});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2438 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_c_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_c_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_c_2438);
        }
        v_t_2443 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2438}), v_t_2441});
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2443 = v_t_2442;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2443}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_e_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24SetField = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24SetField, TAG_SetField, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_BadFieldSet: {
      V v_e_2418 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadFieldSet = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2418}));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2429}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_TagVariant: {
      V v_t_244 = heff_field(v_x21_242, 0);
      V v_tsp_245 = heff_field(v_x21_242, 1);
      V v_args_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24TagVariant = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_t_2418 = heff_tag_at_n(v_ru_24x21_242_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_244, v_tsp_245, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epresyntax_2evariantOf_lam0, 1, 1, (V[]){v_r_240}), v_args_246))});
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_243});
    }
    case TAG_BadVariant: {
      V v_e_2419 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24BadVariant = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_x1_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2419}));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2430}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2evariantOf_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_IsInferable: {
    V v_i_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsInferable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_i_249)) {
    case TAG_At: {
      V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
      v_t_2412 = v_s_2411;
      break;
    }
    default: heff_nomatch(v_i_249);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsInferable, TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
  }
  case TAG_IsCheckable: {
    V v_c_2413 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24IsCheckable = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_c_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_c_2413);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_248_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
  }
  case TAG_IsType: {
    V v_t_2417 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    return v_t_2417;
  }
  default: return heff_nomatch(v_x1_248);
  }
}
Clo g_heff_2esyntax_2epresyntax_2eannLamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eannLamOf_entry, 5, 0};

V g_heff_2esyntax_2epresyntax_2eannLamOf(V v_x_240, V v_xsp_241, V v_t_242, V v_b_243, V v_sp_244) {
top: ;
  switch (heff_tag_of(v_b_243)) {
  case TAG_IsInferable: {
    V v_b1_245 = heff_field(v_b_243, 0);
    V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_b1_245}), v_sp_244});
    return heff_tag_at_n(v_ru_24b_243_24IsInferable, TAG_IsInferable, 1, (V[]){v_t_246});
  }
  case TAG_IsCheckable: {
    V v_t_2417;
    switch (heff_tag_of(v_b_243)) {
    case TAG_IsInferable: {
      V v_i_248 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_i_248)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_i_248);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2412 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      v_t_2417 = v_c_2412;
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsType = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_At: {
        V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
        v_t_2416 = v_s_2415;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsType, TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2417}), v_sp_244});
    return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2418});
  }
  case TAG_IsType: {
    V v_t_2429;
    switch (heff_tag_of(v_b_243)) {
    case TAG_IsInferable: {
      V v_i_2420 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsInferable = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2423;
      switch (heff_tag_of(v_i_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_i_2420);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsInferable, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2424 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      v_t_2429 = v_c_2424;
      break;
    }
    case TAG_IsType: {
      V v_t_2425 = heff_field(v_b_243, 0);
      V v_ru_24b_243_24IsType = heff_take_reuse_n(v_b_243, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24b_243_24IsType, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CAnnLam, 4, (V[]){v_x_240, v_xsp_241, v_t_242, v_t_2429}), v_sp_244});
    return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_b_243);
  }
}
V g_heff_2esyntax_2epresyntax_2eannLamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eannLamOf(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_245 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_244}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EVar, TAG_IsInferable, 1, (V[]){v_t_245});
    }
    case TAG_EImplicitVar: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EImplicitVar = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_246}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_247});
    }
    case TAG_ETag: {
      V v_t_248 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ETag = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_249 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_248, heff_dup(v_sp_243), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_242_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_249, v_sp_243})});
    }
    case TAG_EInt: {
      V v_i_2410 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInt = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_2410}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EInt, TAG_IsInferable, 1, (V[]){v_t_2411});
    }
    case TAG_EFloat: {
      V v_x_2412 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EFloat = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IFloat, 1, (V[]){v_x_2412}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2413});
    }
    case TAG_EString: {
      V v_x_2414 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EString = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EString, TAG_IsInferable, 1, (V[]){v_t_2415});
    }
    case TAG_ERune: {
      V v_c_2416 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ERune = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2416}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24ERune, TAG_IsInferable, 1, (V[]){v_t_2417});
    }
    case TAG_EWord: {
      V v_w_2418 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      HEFF_LAST return g_heff_2esyntax_2epresyntax_2ewordOf(v_w_2418, v_sp_243);
    }
    case TAG_EApp: {
      V v_h_2419 = heff_field(v_x21_242, 0);
      V v_args_2420 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2eappOf(v_r_240, v_h_2419, v_args_2420, v_sp_243));
    }
    case TAG_EProject: {
      V v_ru_24x21_242_24EProject = heff_take_reuse_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_2422 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str0)}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EProject, TAG_IsInferable, 1, (V[]){v_t_2422});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 2);
      V v_t_2425 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str1)}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2425});
    }
    case TAG_EPi: {
      V v_b_2426 = heff_field(v_x21_242, 0);
      V v_cod_2427 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EPi = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2428 = (g_heff_2esyntax_2epresyntax_2epiBinderOf(heff_dup(v_r_240), v_b_2426));
      V v_x1_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_cod_2427}));
      V v_t_2439;
      switch (heff_tag_of(v_x1_2429)) {
      case TAG_IsInferable: {
        V v_i_2430 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 1);
        V v_t_2433;
        switch (heff_tag_of(v_i_2430)) {
        case TAG_At: {
          V v_s_2432 = heff_dup(heff_field(v_i_2430, 1));
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_i_2430);
        }
        v_t_2439 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2430}), v_t_2433});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2434 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 1);
        V v_t_2437;
        switch (heff_tag_of(v_c_2434)) {
        case TAG_At: {
          V v_s_2436 = heff_dup(heff_field(v_c_2434, 1));
          v_t_2437 = v_s_2436;
          break;
        }
        default: heff_nomatch(v_c_2434);
        }
        v_t_2439 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2434}), v_t_2437});
        break;
      }
      case TAG_IsType: {
        V v_t_2438 = heff_field(v_x1_2429, 0);
        heff_take_n(v_x1_2429, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2439 = v_t_2438;
        break;
      }
      default: heff_nomatch(v_x1_2429);
      }
      V v_t_2440 = heff_tag_at_n(v_ru_24x21_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2428, v_t_2439}), v_sp_243});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2440});
    }
    case TAG_ELam: {
      V v_x211_2441 = heff_field(v_x21_242, 0);
      V v_body_2442 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELam = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      switch (heff_tag_of(v_x211_2441)) {
      case TAG_LamName: {
        V v_x_2443 = heff_field(v_x211_2441, 0);
        V v_xsp_2444 = heff_field(v_x211_2441, 1);
        heff_take_n(v_x211_2441, 3ULL, 2);
        V v_x1_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2442}));
        V v_t_2455;
        switch (heff_tag_of(v_x1_2445)) {
        case TAG_IsInferable: {
          V v_i_2446 = heff_field(v_x1_2445, 0);
          heff_take_n(v_x1_2445, 1ULL, 1);
          V v_t_2449;
          switch (heff_tag_of(v_i_2446)) {
          case TAG_At: {
            V v_s_2448 = heff_dup(heff_field(v_i_2446, 1));
            v_t_2449 = v_s_2448;
            break;
          }
          default: heff_nomatch(v_i_2446);
          }
          v_t_2455 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2446}), v_t_2449});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2450 = heff_field(v_x1_2445, 0);
          heff_take_n(v_x1_2445, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2455 = v_c_2450;
          break;
        }
        case TAG_IsType: {
          V v_t_2451 = heff_field(v_x1_2445, 0);
          heff_take_n(v_x1_2445, 1ULL, 1);
          V v_t_2454;
          switch (heff_tag_of(v_t_2451)) {
          case TAG_At: {
            V v_s_2453 = heff_dup(heff_field(v_t_2451, 1));
            v_t_2454 = v_s_2453;
            break;
          }
          default: heff_nomatch(v_t_2451);
          }
          v_t_2455 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2451}), v_t_2454});
          break;
        }
        default: heff_nomatch(v_x1_2445);
        }
        V v_t_2456 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2443, v_xsp_2444, v_t_2455}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2456});
      }
      case TAG_LamImplicit: {
        V v_x_2457 = heff_field(v_x211_2441, 0);
        V v_xsp_2458 = heff_field(v_x211_2441, 1);
        heff_take_n(v_x211_2441, 3ULL, 2);
        V v_x1_2459 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2442}));
        V v_t_2469;
        switch (heff_tag_of(v_x1_2459)) {
        case TAG_IsInferable: {
          V v_i_2460 = heff_field(v_x1_2459, 0);
          heff_take_n(v_x1_2459, 1ULL, 1);
          V v_t_2463;
          switch (heff_tag_of(v_i_2460)) {
          case TAG_At: {
            V v_s_2462 = heff_dup(heff_field(v_i_2460, 1));
            v_t_2463 = v_s_2462;
            break;
          }
          default: heff_nomatch(v_i_2460);
          }
          v_t_2469 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2460}), v_t_2463});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2464 = heff_field(v_x1_2459, 0);
          heff_take_n(v_x1_2459, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2469 = v_c_2464;
          break;
        }
        case TAG_IsType: {
          V v_t_2465 = heff_field(v_x1_2459, 0);
          heff_take_n(v_x1_2459, 1ULL, 1);
          V v_t_2468;
          switch (heff_tag_of(v_t_2465)) {
          case TAG_At: {
            V v_s_2467 = heff_dup(heff_field(v_t_2465, 1));
            v_t_2468 = v_s_2467;
            break;
          }
          default: heff_nomatch(v_t_2465);
          }
          v_t_2469 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2465}), v_t_2468});
          break;
        }
        default: heff_nomatch(v_x1_2459);
        }
        V v_t_2470 = heff_tag_at_n(v_ru_24x21_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2457, v_xsp_2458, v_t_2469}), v_sp_243});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2470});
      }
      case TAG_LamAnn: {
        V v_x_2471 = heff_field(v_x211_2441, 0);
        V v_xsp_2472 = heff_field(v_x211_2441, 1);
        V v_t_2473 = heff_field(v_x211_2441, 2);
        heff_take_n(v_x211_2441, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_242_24ELam, 2);
        V v_x1_2474 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2473}));
        V v_t_2484;
        switch (heff_tag_of(v_x1_2474)) {
        case TAG_IsInferable: {
          V v_i_2475 = heff_field(v_x1_2474, 0);
          heff_take_n(v_x1_2474, 1ULL, 1);
          V v_t_2478;
          switch (heff_tag_of(v_i_2475)) {
          case TAG_At: {
            V v_s_2477 = heff_dup(heff_field(v_i_2475, 1));
            v_t_2478 = v_s_2477;
            break;
          }
          default: heff_nomatch(v_i_2475);
          }
          v_t_2484 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2475}), v_t_2478});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2479 = heff_field(v_x1_2474, 0);
          heff_take_n(v_x1_2474, 1ULL, 1);
          V v_t_2482;
          switch (heff_tag_of(v_c_2479)) {
          case TAG_At: {
            V v_s_2481 = heff_dup(heff_field(v_c_2479, 1));
            v_t_2482 = v_s_2481;
            break;
          }
          default: heff_nomatch(v_c_2479);
          }
          v_t_2484 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2479}), v_t_2482});
          break;
        }
        case TAG_IsType: {
          V v_t_2483 = heff_field(v_x1_2474, 0);
          heff_take_n(v_x1_2474, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          v_t_2484 = v_t_2483;
          break;
        }
        default: heff_nomatch(v_x1_2474);
        }
        V v_t_2485 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2442}));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2471, v_xsp_2472, v_t_2484, v_t_2485, v_sp_243));
      }
      default: return heff_nomatch(v_x211_2441);
      }
    }
    case TAG_EAnn: {
      V v_a_2486 = heff_field(v_x21_242, 0);
      V v_t_2487 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EAnn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_2486}));
      V v_t_2498;
      switch (heff_tag_of(v_x1_2488)) {
      case TAG_IsInferable: {
        V v_i_2489 = heff_field(v_x1_2488, 0);
        heff_take_n(v_x1_2488, 1ULL, 1);
        V v_t_2492;
        switch (heff_tag_of(v_i_2489)) {
        case TAG_At: {
          V v_s_2491 = heff_dup(heff_field(v_i_2489, 1));
          v_t_2492 = v_s_2491;
          break;
        }
        default: heff_nomatch(v_i_2489);
        }
        v_t_2498 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2489}), v_t_2492});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2493 = heff_field(v_x1_2488, 0);
        heff_take_n(v_x1_2488, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2498 = v_c_2493;
        break;
      }
      case TAG_IsType: {
        V v_t_2494 = heff_field(v_x1_2488, 0);
        heff_take_n(v_x1_2488, 1ULL, 1);
        V v_t_2497;
        switch (heff_tag_of(v_t_2494)) {
        case TAG_At: {
          V v_s_2496 = heff_dup(heff_field(v_t_2494, 1));
          v_t_2497 = v_s_2496;
          break;
        }
        default: heff_nomatch(v_t_2494);
        }
        v_t_2498 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2494}), v_t_2497});
        break;
      }
      default: heff_nomatch(v_x1_2488);
      }
      V v_x1_2499 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2487}));
      V v_t_24109;
      switch (heff_tag_of(v_x1_2499)) {
      case TAG_IsInferable: {
        V v_i_24100 = heff_field(v_x1_2499, 0);
        heff_take_n(v_x1_2499, 1ULL, 1);
        V v_t_24103;
        switch (heff_tag_of(v_i_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_dup(heff_field(v_i_24100, 1));
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_i_24100);
        }
        v_t_24109 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_24100}), v_t_24103});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24104 = heff_field(v_x1_2499, 0);
        heff_take_n(v_x1_2499, 1ULL, 1);
        V v_t_24107;
        switch (heff_tag_of(v_c_24104)) {
        case TAG_At: {
          V v_s_24106 = heff_dup(heff_field(v_c_24104, 1));
          v_t_24107 = v_s_24106;
          break;
        }
        default: heff_nomatch(v_c_24104);
        }
        v_t_24109 = heff_tag_at_n(v_ru_24x21_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24104}), v_t_24107});
        break;
      }
      case TAG_IsType: {
        V v_t_24108 = heff_field(v_x1_2499, 0);
        heff_take_n(v_x1_2499, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_242_24EAnn, 2);
        v_t_24109 = v_t_24108;
        break;
      }
      default: heff_nomatch(v_x1_2499);
      }
      V v_t_24110 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2498, v_t_24109}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24110});
    }
    case TAG_ESpec: {
      V v_a_24111 = heff_field(v_x21_242, 0);
      V v_x_24112 = heff_field(v_x21_242, 1);
      V v_fsp_24113 = heff_field(v_x21_242, 2);
      V v_v_24114 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24ESpec = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_24115 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24111}));
      V v_t_24116 = ({ V a_0 = v_t_24115; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24115); r_; });
      V v_x1_24117 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_24114}));
      V v_t_24127;
      switch (heff_tag_of(v_x1_24117)) {
      case TAG_IsInferable: {
        V v_i_24118 = heff_field(v_x1_24117, 0);
        heff_take_n(v_x1_24117, 1ULL, 1);
        V v_t_24121;
        switch (heff_tag_of(v_i_24118)) {
        case TAG_At: {
          V v_s_24120 = heff_dup(heff_field(v_i_24118, 1));
          v_t_24121 = v_s_24120;
          break;
        }
        default: heff_nomatch(v_i_24118);
        }
        v_t_24127 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24118}), v_t_24121});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24122 = heff_field(v_x1_24117, 0);
        heff_take_n(v_x1_24117, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24127 = v_c_24122;
        break;
      }
      case TAG_IsType: {
        V v_t_24123 = heff_field(v_x1_24117, 0);
        heff_take_n(v_x1_24117, 1ULL, 1);
        V v_t_24126;
        switch (heff_tag_of(v_t_24123)) {
        case TAG_At: {
          V v_s_24125 = heff_dup(heff_field(v_t_24123, 1));
          v_t_24126 = v_s_24125;
          break;
        }
        default: heff_nomatch(v_t_24123);
        }
        v_t_24127 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24123}), v_t_24126});
        break;
      }
      default: heff_nomatch(v_x1_24117);
      }
      V v_t_24128 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ESpec, TAG_ISpec, 4, (V[]){v_t_24116, v_x_24112, v_fsp_24113, v_t_24127}), v_sp_243});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24128});
    }
    case TAG_ESig: {
      V v_fs_24129 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESig = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24130 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo), 1, (V[]){v_r_240}));
      V v_t_24131 = heff_tag_at_n(v_ru_24x21_242_24ESig, TAG_TSig, 1, (V[]){(g_list_2emap(v_t_24130, v_fs_24129))});
      return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24131, v_sp_243})});
    }
    case TAG_ESum: {
      V v_vs_24132 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24ESum = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24133 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2evariantOf_clo), 1, (V[]){v_r_240}));
      V v_t_24134 = heff_tag_at_n(v_ru_24x21_242_24ESum, TAG_TSum, 1, (V[]){(g_list_2emap(v_t_24133, v_vs_24132))});
      return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24134, v_sp_243})});
    }
    case TAG_EStruct: {
      V v_fs_24135 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EStruct = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24136 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2efieldSetOf_clo), 1, (V[]){v_r_240}));
      V v_t_24137 = heff_tag_at_n(v_ru_24x21_242_24EStruct, TAG_CStruct, 1, (V[]){(g_list_2emap(v_t_24136, v_fs_24135))});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_24137, v_sp_243})});
    }
    case TAG_EMatch: {
      V v_s_24138 = heff_field(v_x21_242, 0);
      V v_alts_24139 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24EMatch = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24140 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24138}));
      V v_t_24141 = ({ V a_0 = v_t_24140; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24140); r_; });
      V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2ealtOf_clo), 1, (V[]){v_r_240}));
      V v_t_24143 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_CMatch, 2, (V[]){v_t_24141, (g_list_2emap(v_t_24142, v_alts_24139))});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x21_242_24EMatch, TAG_At, 2, (V[]){v_t_24143, v_sp_243})});
    }
    case TAG_ELetIn: {
      V v_rhs_24144 = heff_field(v_x21_242, 0);
      V v_a_24145 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELetIn = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_24146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rhs_24144}));
      V v_t_24147 = ({ V a_0 = v_t_24146; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24146); r_; });
      V v_t_24163;
      switch (heff_tag_of(v_a_24145)) {
      case TAG_At: {
        V v_x21_24148 = heff_field(v_a_24145, 0);
        V v_sp_24149 = heff_field(v_a_24145, 1);
        heff_take_n(v_a_24145, 3ULL, 2);
        switch (heff_tag_of(v_x21_24148)) {
        case TAG_MkAlt: {
          V v_p_24150 = heff_field(v_x21_24148, 0);
          V v_b_24151 = heff_field(v_x21_24148, 1);
          heff_take_n(v_x21_24148, 3ULL, 2);
          V v_x1_24152 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_24151}));
          V v_t_24162;
          switch (heff_tag_of(v_x1_24152)) {
          case TAG_IsInferable: {
            V v_i_24153 = heff_field(v_x1_24152, 0);
            heff_take_n(v_x1_24152, 1ULL, 1);
            V v_t_24156;
            switch (heff_tag_of(v_i_24153)) {
            case TAG_At: {
              V v_s_24155 = heff_dup(heff_field(v_i_24153, 1));
              v_t_24156 = v_s_24155;
              break;
            }
            default: heff_nomatch(v_i_24153);
            }
            v_t_24162 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24153}), v_t_24156});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24157 = heff_field(v_x1_24152, 0);
            heff_take_n(v_x1_24152, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            v_t_24162 = v_c_24157;
            break;
          }
          case TAG_IsType: {
            V v_t_24158 = heff_field(v_x1_24152, 0);
            heff_take_n(v_x1_24152, 1ULL, 1);
            V v_t_24161;
            switch (heff_tag_of(v_t_24158)) {
            case TAG_At: {
              V v_s_24160 = heff_dup(heff_field(v_t_24158, 1));
              v_t_24161 = v_s_24160;
              break;
            }
            default: heff_nomatch(v_t_24158);
            }
            v_t_24162 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24158}), v_t_24161});
            break;
          }
          default: heff_nomatch(v_x1_24152);
          }
          v_t_24163 = heff_tag_at_n(v_ru_24x21_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24150, v_t_24162}), v_sp_24149});
          break;
        }
        default: heff_nomatch(v_x21_24148);
        }
        break;
      }
      default: heff_nomatch(v_a_24145);
      }
      V v_t_24164 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24147, v_t_24163}), v_sp_243});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24164});
    }
    case TAG_EDo: {
      V v_stmts_24165 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EDo = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_24166 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24165));
      switch (heff_tag_of(v_t_24166)) {
      case TAG_Nil: {
        heff_drop_rec(v_r_240, 2);
        V v_t_24167 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str2)}), v_sp_243});
        return heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_IsInferable, 1, (V[]){v_t_24167});
      }
      case TAG_Cons: {
        V v_last_24168 = heff_field(v_t_24166, 0);
        V v_init_24169 = heff_field(v_t_24166, 1);
        heff_take_n(v_t_24166, 3ULL, 2);
        V v_init_24170 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_init_24169));
        V v_t_24179;
        switch (heff_tag_of(v_last_24168)) {
        case TAG_At: {
          V v_x31_24171 = heff_field(v_last_24168, 0);
          heff_take_n(v_last_24168, 1ULL, 2);
          switch (heff_tag_of(v_x31_24171)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24171, 0ULL, 3);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            heff_drop(v_init_24170);
            v_t_24179 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24171, 0ULL, 2);
            heff_drop_cell(v_ru_24x21_242_24EDo, 1);
            heff_drop(v_init_24170);
            v_t_24179 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24178 = heff_field(v_x31_24171, 0);
            heff_take_n(v_x31_24171, 1ULL, 1);
            v_t_24179 = heff_tag_at_n(v_ru_24x21_242_24EDo, TAG_Just, 1, (V[]){({ V a_0 = heff_dup(v_sp_243); V a_1 = v_init_24170; V a_2 = v_e_24178; V r_ = (g_heff_2esyntax_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24170); r_; })});
            break;
          }
          default: heff_nomatch(v_x31_24171);
          }
          break;
        }
        default: heff_nomatch(v_last_24168);
        }
        switch (heff_tag_of(v_t_24179)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 2);
          V v_t_24180 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_str3)}), v_sp_243});
          return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24180});
        }
        case TAG_Just: {
          V v_e_27_24181 = heff_field(v_t_24179, 0);
          heff_take_n(v_t_24179, 1ULL, 1);
          heff_drop(v_sp_243);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_27_24181});
        }
        default: return heff_nomatch(v_t_24179);
        }
      }
      default: return heff_nomatch(v_t_24166);
      }
    }
    case TAG_ELocal: {
      V v_body_24182 = heff_field(v_x21_242, 0);
      V v_ds_24183 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24ELocal = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_x1_24184 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 1, (V[]){v_body_24182}));
      V v_t_24194;
      switch (heff_tag_of(v_x1_24184)) {
      case TAG_IsInferable: {
        V v_i_24185 = heff_field(v_x1_24184, 0);
        heff_take_n(v_x1_24184, 1ULL, 1);
        V v_t_24188;
        switch (heff_tag_of(v_i_24185)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_i_24185, 1));
          v_t_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_i_24185);
        }
        v_t_24194 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24185}), v_t_24188});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24189 = heff_field(v_x1_24184, 0);
        heff_take_n(v_x1_24184, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_24194 = v_c_24189;
        break;
      }
      case TAG_IsType: {
        V v_t_24190 = heff_field(v_x1_24184, 0);
        heff_take_n(v_x1_24184, 1ULL, 1);
        V v_t_24193;
        switch (heff_tag_of(v_t_24190)) {
        case TAG_At: {
          V v_s_24192 = heff_dup(heff_field(v_t_24190, 1));
          v_t_24193 = v_s_24192;
          break;
        }
        default: heff_nomatch(v_t_24190);
        }
        v_t_24194 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24190}), v_t_24193});
        break;
      }
      default: heff_nomatch(v_x1_24184);
      }
      V v_t_24195 = heff_tag_at_n(v_ru_24x21_242_24ELocal, TAG_CLocal, 2, (V[]){v_t_24194, (g_list_2emap(heff_get_n(v_r_240, 1, 2), v_ds_24183))});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24195, v_sp_243})});
    }
    case TAG_EInvalid: {
      V v_why_24196 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24EInvalid = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      heff_drop_rec(v_r_240, 2);
      V v_t_24197 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), v_why_24196}), v_sp_243});
      return heff_tag_at_n(v_ru_24x21_242_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24197});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ExplicitParam: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_xsp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ExplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_244, v_xsp_245, v_t_2417}), v_sp_243});
    }
    case TAG_ImplicitParam: {
      V v_x_2418 = heff_field(v_x21_242, 0);
      V v_xsp_2419 = heff_field(v_x21_242, 1);
      V v_t_2420 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24ImplicitParam = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2420}));
      V v_t_2431;
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_IsInferable: {
        V v_i_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2425;
        switch (heff_tag_of(v_i_2422)) {
        case TAG_At: {
          V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
          v_t_2425 = v_s_2424;
          break;
        }
        default: heff_nomatch(v_i_2422);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2422}), v_t_2425});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2426 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_c_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_c_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_c_2426);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2426}), v_t_2429});
        break;
      }
      case TAG_IsType: {
        V v_t_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2431 = v_t_2430;
        break;
      }
      default: heff_nomatch(v_x1_2421);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2418, v_xsp_2419, v_t_2431}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24MkEquation = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_c_2413;
        break;
      }
      case TAG_IsType: {
        V v_t_2414 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2417;
        switch (heff_tag_of(v_t_2414)) {
        case TAG_At: {
          V v_s_2416 = heff_dup(heff_field(v_t_2414, 1));
          v_t_2417 = v_s_2416;
          break;
        }
        default: heff_nomatch(v_t_2414);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2414}), v_t_2417});
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2418}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str0, 54, "a watch must say what type it has: write `>>> (e : T)`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2ewatchOf_str1, 54, "a watch must say what type it has: write `>>> (e : T)`");
Clo g_heff_2esyntax_2epresyntax_2ewatchOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ewatchOf_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ewatchOf(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_IsInferable: {
    V v_i_241 = heff_field(v_c_240, 0);
    V v_ru_24c_240_24IsInferable = heff_take_reuse_n(v_c_240, 1ULL, 1);
    V v_t_244;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_s_243 = heff_dup(heff_field(v_i_241, 1));
      v_t_244 = v_s_243;
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24c_240_24IsInferable, TAG_CInf, 1, (V[]){v_i_241}), v_t_244});
  }
  case TAG_IsCheckable: {
    V v_sp_2415;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_246 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_246)) {
      case TAG_At: {
        V v_s_248 = heff_field(v_i_246, 1);
        heff_take_n(v_i_246, 2ULL, 2);
        v_sp_2415 = v_s_248;
        break;
      }
      default: heff_nomatch(v_i_246);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_249 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_s_2411 = heff_field(v_c_249, 1);
        heff_take_n(v_c_249, 2ULL, 2);
        v_sp_2415 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2412 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_t_2412, 1);
        heff_take_n(v_t_2412, 2ULL, 2);
        v_sp_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str0)}), v_sp_2415});
    V v_t_2426;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2417 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2417)) {
      case TAG_At: {
        V v_s_2419 = heff_field(v_i_2417, 1);
        heff_take_n(v_i_2417, 2ULL, 2);
        v_t_2426 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_i_2417);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2420 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_c_2420, 1);
        heff_take_n(v_c_2420, 2ULL, 2);
        v_t_2426 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_c_2420);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2423 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_field(v_t_2423, 1);
        heff_take_n(v_t_2423, 2ULL, 2);
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2416}), v_t_2426});
  }
  case TAG_IsType: {
    V v_sp_2437;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2428 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_i_2428)) {
      case TAG_At: {
        V v_s_2430 = heff_field(v_i_2428, 1);
        heff_take_n(v_i_2428, 2ULL, 2);
        v_sp_2437 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_i_2428);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2431 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_c_2431)) {
      case TAG_At: {
        V v_s_2433 = heff_field(v_c_2431, 1);
        heff_take_n(v_c_2431, 2ULL, 2);
        v_sp_2437 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_c_2431);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2434 = heff_dup(heff_field(v_c_240, 0));
      switch (heff_tag_of(v_t_2434)) {
      case TAG_At: {
        V v_s_2436 = heff_field(v_t_2434, 1);
        heff_take_n(v_t_2434, 2ULL, 2);
        v_sp_2437 = v_s_2436;
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(0LL), ((V)&g_heff_2esyntax_2epresyntax_2ewatchOf_str1)}), v_sp_2437});
    V v_t_2448;
    switch (heff_tag_of(v_c_240)) {
    case TAG_IsInferable: {
      V v_i_2439 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_i_2439)) {
      case TAG_At: {
        V v_s_2441 = heff_field(v_i_2439, 1);
        heff_take_n(v_i_2439, 2ULL, 2);
        v_t_2448 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_i_2439);
      }
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2442 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_c_2442)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_c_2442, 1);
        heff_take_n(v_c_2442, 2ULL, 2);
        v_t_2448 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_c_2442);
      }
      break;
    }
    case TAG_IsType: {
      V v_t_2445 = heff_field(v_c_240, 0);
      heff_take_n(v_c_240, 1ULL, 1);
      switch (heff_tag_of(v_t_2445)) {
      case TAG_At: {
        V v_s_2447 = heff_field(v_t_2445, 1);
        heff_take_n(v_t_2445, 2ULL, 2);
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_t_2445);
      }
      break;
    }
    default: heff_nomatch(v_c_240);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2438}), v_t_2448});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ewatchOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ewatchOf(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ty_246 = heff_field(v_x21_242, 2);
      V v_eqs_247 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclEquations = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_ty_246}));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      V v_t_2419 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eequationOf_clo), 1, (V[]){v_r_240}));
      V v_t_2420 = heff_tag_at_n(v_ru_24x21_242_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_244, v_fsp_245, v_t_2418, (g_list_2emap(v_t_2419, v_eqs_247))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_242, 0);
      V v_xsp_2422 = heff_field(v_x21_242, 1);
      V v_ps_2423 = heff_field(v_x21_242, 2);
      V v_u_2424 = heff_field(v_x21_242, 3);
      V v_body_2425 = heff_field(v_x21_242, 4);
      V v_ru_24x21_242_24DeclDefine = heff_take_reuse_n(v_x21_242, 31ULL, 5);
      V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eparamOf_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2427 = (g_list_2emap(v_t_2426, v_ps_2423));
      V v_x1_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_u_2424}));
      V v_t_2438;
      switch (heff_tag_of(v_x1_2428)) {
      case TAG_IsInferable: {
        V v_i_2429 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        V v_t_2432;
        switch (heff_tag_of(v_i_2429)) {
        case TAG_At: {
          V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
          v_t_2432 = v_s_2431;
          break;
        }
        default: heff_nomatch(v_i_2429);
        }
        v_t_2438 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2433 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_c_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_c_2433);
        }
        v_t_2438 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        break;
      }
      case TAG_IsType: {
        V v_t_2437 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2438 = v_t_2437;
        break;
      }
      default: heff_nomatch(v_x1_2428);
      }
      V v_x1_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2425}));
      V v_t_2449;
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_IsInferable: {
        V v_i_2440 = heff_field(v_x1_2439, 0);
        V v_ru_24x1_2439_24IsInferable = heff_take_reuse_n(v_x1_2439, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_i_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_i_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_i_2440);
        }
        v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2439_24IsInferable, TAG_CInf, 1, (V[]){v_i_2440}), v_t_2443});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2444 = heff_field(v_x1_2439, 0);
        heff_take_n(v_x1_2439, 1ULL, 1);
        v_t_2449 = v_c_2444;
        break;
      }
      case TAG_IsType: {
        V v_t_2445 = heff_field(v_x1_2439, 0);
        V v_ru_24x1_2439_24IsType = heff_take_reuse_n(v_x1_2439, 1ULL, 1);
        V v_t_2448;
        switch (heff_tag_of(v_t_2445)) {
        case TAG_At: {
          V v_s_2447 = heff_dup(heff_field(v_t_2445, 1));
          v_t_2448 = v_s_2447;
          break;
        }
        default: heff_nomatch(v_t_2445);
        }
        v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2439_24IsType, TAG_CType, 1, (V[]){v_t_2445}), v_t_2448});
        break;
      }
      default: heff_nomatch(v_x1_2439);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2421, v_xsp_2422, v_t_2427, v_t_2438, v_t_2449}), v_sp_243});
    }
    case TAG_DeclTheory: {
      V v_x_2450 = heff_field(v_x21_242, 0);
      V v_xsp_2451 = heff_field(v_x21_242, 1);
      V v_ps_2452 = heff_field(v_x21_242, 2);
      V v_body_2453 = heff_field(v_x21_242, 3);
      V v_ru_24x21_242_24DeclTheory = heff_take_reuse_n(v_x21_242, 15ULL, 4);
      V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2esyntax_2epresyntax_2eparamOf_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2455 = (g_list_2emap(v_t_2454, v_ps_2452));
      V v_x1_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_body_2453}));
      V v_t_2466;
      switch (heff_tag_of(v_x1_2456)) {
      case TAG_IsInferable: {
        V v_i_2457 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 1);
        V v_t_2460;
        switch (heff_tag_of(v_i_2457)) {
        case TAG_At: {
          V v_s_2459 = heff_dup(heff_field(v_i_2457, 1));
          v_t_2460 = v_s_2459;
          break;
        }
        default: heff_nomatch(v_i_2457);
        }
        v_t_2466 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2457}), v_t_2460});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2461 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2466 = v_c_2461;
        break;
      }
      case TAG_IsType: {
        V v_t_2462 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 1);
        V v_t_2465;
        switch (heff_tag_of(v_t_2462)) {
        case TAG_At: {
          V v_s_2464 = heff_dup(heff_field(v_t_2462, 1));
          v_t_2465 = v_s_2464;
          break;
        }
        default: heff_nomatch(v_t_2462);
        }
        v_t_2466 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2462}), v_t_2465});
        break;
      }
      default: heff_nomatch(v_x1_2456);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2450, v_xsp_2451, v_t_2455, v_t_2466}), v_sp_243});
    }
    case TAG_DeclPrimitive: {
      V v_x_2467 = heff_field(v_x21_242, 0);
      V v_xsp_2468 = heff_field(v_x21_242, 1);
      V v_t_2469 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24DeclPrimitive = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      V v_x1_2470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2469}));
      V v_t_2480;
      switch (heff_tag_of(v_x1_2470)) {
      case TAG_IsInferable: {
        V v_i_2471 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_i_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_i_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_i_2471);
        }
        v_t_2480 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2471}), v_t_2474});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2475 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 1);
        V v_t_2478;
        switch (heff_tag_of(v_c_2475)) {
        case TAG_At: {
          V v_s_2477 = heff_dup(heff_field(v_c_2475, 1));
          v_t_2478 = v_s_2477;
          break;
        }
        default: heff_nomatch(v_c_2475);
        }
        v_t_2480 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2475}), v_t_2478});
        break;
      }
      case TAG_IsType: {
        V v_t_2479 = heff_field(v_x1_2470, 0);
        heff_take_n(v_x1_2470, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        v_t_2480 = v_t_2479;
        break;
      }
      default: heff_nomatch(v_x1_2470);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2467, v_xsp_2468, v_t_2480}), v_sp_243});
    }
    case TAG_DeclTest: {
      V v_x_2481 = heff_field(v_x21_242, 0);
      V v_xsp_2482 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_rec(v_r_240, 2);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2481, v_xsp_2482}), v_sp_243});
    }
    case TAG_DeclWatch: {
      V v_e_2483 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24DeclWatch = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_2484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2483}));
      V v_t_2485 = heff_tag_at_n(v_ru_24x21_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){(g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2484))});
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){v_t_2485, v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF(a[0], a[1]);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam0, 1, 0};
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args); static Clo g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifier_lam1, 1, 0};

static V g_heff_2esyntax_2epresyntax_2eclassifier_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassifier_st;
static V g_heff_2esyntax_2epresyntax_2eclassifier_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam0_clo), ((V)&g_heff_2esyntax_2epresyntax_2eclassifier_lam1_clo)});
}
V g_heff_2esyntax_2epresyntax_2eclassifier_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassifier_st)) return g_heff_2esyntax_2epresyntax_2eclassifier_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassifier_val, &g_heff_2esyntax_2epresyntax_2eclassifier_st, g_heff_2esyntax_2epresyntax_2eclassifier_init);
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyTermF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_e_240));
}
V g_heff_2esyntax_2epresyntax_2eclassifier_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2epresyntax_2eclassifyDeclF(heff_dup(g_heff_2esyntax_2epresyntax_2eclassifier_get()), v_d_241));
}
Clo g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_241 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_241)) {
    case TAG_EVar: {
      V v_ru_24e1_241_24EVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2414;
      switch (heff_tag_of(v_x1_244)) {
      case TAG_IsInferable: {
        V v_i_245 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        V v_t_248;
        switch (heff_tag_of(v_i_245)) {
        case TAG_At: {
          V v_s_247 = heff_dup(heff_field(v_i_245, 1));
          v_t_248 = v_s_247;
          break;
        }
        default: heff_nomatch(v_i_245);
        }
        v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EVar, TAG_CInf, 1, (V[]){v_i_245}), v_t_248});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_249 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EVar, 1);
        v_t_2414 = v_c_249;
        break;
      }
      case TAG_IsType: {
        V v_t_2410 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 1);
        V v_t_2413;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_At: {
          V v_s_2412 = heff_dup(heff_field(v_t_2410, 1));
          v_t_2413 = v_s_2412;
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EVar, TAG_CType, 1, (V[]){v_t_2410}), v_t_2413});
        break;
      }
      default: heff_nomatch(v_x1_244);
      }
      V v_t_2417;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2414}), v_t_2417});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_241_24EImplicitVar = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2429;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_IsInferable: {
        V v_i_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2423;
        switch (heff_tag_of(v_i_2420)) {
        case TAG_At: {
          V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
          v_t_2423 = v_s_2422;
          break;
        }
        default: heff_nomatch(v_i_2420);
        }
        v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EImplicitVar, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2424 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EImplicitVar, 1);
        v_t_2429 = v_c_2424;
        break;
      }
      case TAG_IsType: {
        V v_t_2425 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EImplicitVar, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V v_t_2432;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2431 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2432 = v_s_2431;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2429}), v_t_2432});
    }
    case TAG_ETag: {
      V v_ru_24e1_241_24ETag = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2434 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2444;
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_IsInferable: {
        V v_i_2435 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        V v_t_2438;
        switch (heff_tag_of(v_i_2435)) {
        case TAG_At: {
          V v_s_2437 = heff_dup(heff_field(v_i_2435, 1));
          v_t_2438 = v_s_2437;
          break;
        }
        default: heff_nomatch(v_i_2435);
        }
        v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_CInf, 1, (V[]){v_i_2435}), v_t_2438});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2439 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ETag, 1);
        v_t_2444 = v_c_2439;
        break;
      }
      case TAG_IsType: {
        V v_t_2440 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        V v_t_2443;
        switch (heff_tag_of(v_t_2440)) {
        case TAG_At: {
          V v_s_2442 = heff_dup(heff_field(v_t_2440, 1));
          v_t_2443 = v_s_2442;
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ETag, TAG_CType, 1, (V[]){v_t_2440}), v_t_2443});
        break;
      }
      default: heff_nomatch(v_x1_2434);
      }
      V v_t_2447;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2446 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2447 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2444}), v_t_2447});
    }
    case TAG_EInt: {
      V v_ru_24e1_241_24EInt = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2449 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2459;
      switch (heff_tag_of(v_x1_2449)) {
      case TAG_IsInferable: {
        V v_i_2450 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        V v_t_2453;
        switch (heff_tag_of(v_i_2450)) {
        case TAG_At: {
          V v_s_2452 = heff_dup(heff_field(v_i_2450, 1));
          v_t_2453 = v_s_2452;
          break;
        }
        default: heff_nomatch(v_i_2450);
        }
        v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInt, TAG_CInf, 1, (V[]){v_i_2450}), v_t_2453});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2454 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EInt, 1);
        v_t_2459 = v_c_2454;
        break;
      }
      case TAG_IsType: {
        V v_t_2455 = heff_field(v_x1_2449, 0);
        heff_take_n(v_x1_2449, 1ULL, 1);
        V v_t_2458;
        switch (heff_tag_of(v_t_2455)) {
        case TAG_At: {
          V v_s_2457 = heff_dup(heff_field(v_t_2455, 1));
          v_t_2458 = v_s_2457;
          break;
        }
        default: heff_nomatch(v_t_2455);
        }
        v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInt, TAG_CType, 1, (V[]){v_t_2455}), v_t_2458});
        break;
      }
      default: heff_nomatch(v_x1_2449);
      }
      V v_t_2462;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2461 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2462 = v_s_2461;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2459}), v_t_2462});
    }
    case TAG_EFloat: {
      V v_ru_24e1_241_24EFloat = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2464 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2474;
      switch (heff_tag_of(v_x1_2464)) {
      case TAG_IsInferable: {
        V v_i_2465 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        V v_t_2468;
        switch (heff_tag_of(v_i_2465)) {
        case TAG_At: {
          V v_s_2467 = heff_dup(heff_field(v_i_2465, 1));
          v_t_2468 = v_s_2467;
          break;
        }
        default: heff_nomatch(v_i_2465);
        }
        v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EFloat, TAG_CInf, 1, (V[]){v_i_2465}), v_t_2468});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2469 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EFloat, 1);
        v_t_2474 = v_c_2469;
        break;
      }
      case TAG_IsType: {
        V v_t_2470 = heff_field(v_x1_2464, 0);
        heff_take_n(v_x1_2464, 1ULL, 1);
        V v_t_2473;
        switch (heff_tag_of(v_t_2470)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_t_2470, 1));
          v_t_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_t_2470);
        }
        v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EFloat, TAG_CType, 1, (V[]){v_t_2470}), v_t_2473});
        break;
      }
      default: heff_nomatch(v_x1_2464);
      }
      V v_t_2477;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2477 = v_s_2476;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2474}), v_t_2477});
    }
    case TAG_EString: {
      V v_ru_24e1_241_24EString = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2479 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_2489;
      switch (heff_tag_of(v_x1_2479)) {
      case TAG_IsInferable: {
        V v_i_2480 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        V v_t_2483;
        switch (heff_tag_of(v_i_2480)) {
        case TAG_At: {
          V v_s_2482 = heff_dup(heff_field(v_i_2480, 1));
          v_t_2483 = v_s_2482;
          break;
        }
        default: heff_nomatch(v_i_2480);
        }
        v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EString, TAG_CInf, 1, (V[]){v_i_2480}), v_t_2483});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2484 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EString, 1);
        v_t_2489 = v_c_2484;
        break;
      }
      case TAG_IsType: {
        V v_t_2485 = heff_field(v_x1_2479, 0);
        heff_take_n(v_x1_2479, 1ULL, 1);
        V v_t_2488;
        switch (heff_tag_of(v_t_2485)) {
        case TAG_At: {
          V v_s_2487 = heff_dup(heff_field(v_t_2485, 1));
          v_t_2488 = v_s_2487;
          break;
        }
        default: heff_nomatch(v_t_2485);
        }
        v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EString, TAG_CType, 1, (V[]){v_t_2485}), v_t_2488});
        break;
      }
      default: heff_nomatch(v_x1_2479);
      }
      V v_t_2492;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_2489}), v_t_2492});
    }
    case TAG_ERune: {
      V v_ru_24e1_241_24ERune = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_2494 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24104;
      switch (heff_tag_of(v_x1_2494)) {
      case TAG_IsInferable: {
        V v_i_2495 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        V v_t_2498;
        switch (heff_tag_of(v_i_2495)) {
        case TAG_At: {
          V v_s_2497 = heff_dup(heff_field(v_i_2495, 1));
          v_t_2498 = v_s_2497;
          break;
        }
        default: heff_nomatch(v_i_2495);
        }
        v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ERune, TAG_CInf, 1, (V[]){v_i_2495}), v_t_2498});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2499 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ERune, 1);
        v_t_24104 = v_c_2499;
        break;
      }
      case TAG_IsType: {
        V v_t_24100 = heff_field(v_x1_2494, 0);
        heff_take_n(v_x1_2494, 1ULL, 1);
        V v_t_24103;
        switch (heff_tag_of(v_t_24100)) {
        case TAG_At: {
          V v_s_24102 = heff_dup(heff_field(v_t_24100, 1));
          v_t_24103 = v_s_24102;
          break;
        }
        default: heff_nomatch(v_t_24100);
        }
        v_t_24104 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ERune, TAG_CType, 1, (V[]){v_t_24100}), v_t_24103});
        break;
      }
      default: heff_nomatch(v_x1_2494);
      }
      V v_t_24107;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24106 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24107 = v_s_24106;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24104}), v_t_24107});
    }
    case TAG_EWord: {
      V v_ru_24e1_241_24EWord = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24109 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24119;
      switch (heff_tag_of(v_x1_24109)) {
      case TAG_IsInferable: {
        V v_i_24110 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        V v_t_24113;
        switch (heff_tag_of(v_i_24110)) {
        case TAG_At: {
          V v_s_24112 = heff_dup(heff_field(v_i_24110, 1));
          v_t_24113 = v_s_24112;
          break;
        }
        default: heff_nomatch(v_i_24110);
        }
        v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EWord, TAG_CInf, 1, (V[]){v_i_24110}), v_t_24113});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24114 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EWord, 1);
        v_t_24119 = v_c_24114;
        break;
      }
      case TAG_IsType: {
        V v_t_24115 = heff_field(v_x1_24109, 0);
        heff_take_n(v_x1_24109, 1ULL, 1);
        V v_t_24118;
        switch (heff_tag_of(v_t_24115)) {
        case TAG_At: {
          V v_s_24117 = heff_dup(heff_field(v_t_24115, 1));
          v_t_24118 = v_s_24117;
          break;
        }
        default: heff_nomatch(v_t_24115);
        }
        v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EWord, TAG_CType, 1, (V[]){v_t_24115}), v_t_24118});
        break;
      }
      default: heff_nomatch(v_x1_24109);
      }
      V v_t_24122;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24121 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24122 = v_s_24121;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24119}), v_t_24122});
    }
    case TAG_EApp: {
      V v_ru_24e1_241_24EApp = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24125 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24135;
      switch (heff_tag_of(v_x1_24125)) {
      case TAG_IsInferable: {
        V v_i_24126 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24129;
        switch (heff_tag_of(v_i_24126)) {
        case TAG_At: {
          V v_s_24128 = heff_dup(heff_field(v_i_24126, 1));
          v_t_24129 = v_s_24128;
          break;
        }
        default: heff_nomatch(v_i_24126);
        }
        v_t_24135 = heff_tag_at_n(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24126}), v_t_24129});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24130 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EApp, 2);
        v_t_24135 = v_c_24130;
        break;
      }
      case TAG_IsType: {
        V v_t_24131 = heff_field(v_x1_24125, 0);
        heff_take_n(v_x1_24125, 1ULL, 1);
        V v_t_24134;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_At: {
          V v_s_24133 = heff_dup(heff_field(v_t_24131, 1));
          v_t_24134 = v_s_24133;
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        v_t_24135 = heff_tag_at_n(v_ru_24e1_241_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24131}), v_t_24134});
        break;
      }
      default: heff_nomatch(v_x1_24125);
      }
      V v_t_24138;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24137 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24138 = v_s_24137;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24135}), v_t_24138});
    }
    case TAG_EProject: {
      V v_x_24139 = heff_field(v_e1_241, 0);
      V v_ru_24e1_241_24EProject = heff_take_reuse_n(v_e1_241, 1ULL, 1);
      heff_drop_tag(v_e_240, 2);
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EProject, TAG_ArgProject, 1, (V[]){v_x_24139}), v_sp_242});
    }
    case TAG_ENamed: {
      V v_x_24140 = heff_field(v_e1_241, 0);
      V v_e12_24141 = heff_field(v_e1_241, 1);
      V v_ru_24e1_241_24ENamed = heff_take_reuse_n(v_e1_241, 3ULL, 2);
      heff_drop_tag(v_e_240, 2);
      V v_x1_24142 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e12_24141));
      V v_t_24152;
      switch (heff_tag_of(v_x1_24142)) {
      case TAG_IsInferable: {
        V v_i_24143 = heff_field(v_x1_24142, 0);
        heff_take_n(v_x1_24142, 1ULL, 1);
        V v_t_24146;
        switch (heff_tag_of(v_i_24143)) {
        case TAG_At: {
          V v_s_24145 = heff_dup(heff_field(v_i_24143, 1));
          v_t_24146 = v_s_24145;
          break;
        }
        default: heff_nomatch(v_i_24143);
        }
        v_t_24152 = heff_tag_at_n(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24143}), v_t_24146});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24147 = heff_field(v_x1_24142, 0);
        heff_take_n(v_x1_24142, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ENamed, 2);
        v_t_24152 = v_c_24147;
        break;
      }
      case TAG_IsType: {
        V v_t_24148 = heff_field(v_x1_24142, 0);
        heff_take_n(v_x1_24142, 1ULL, 1);
        V v_t_24151;
        switch (heff_tag_of(v_t_24148)) {
        case TAG_At: {
          V v_s_24150 = heff_dup(heff_field(v_t_24148, 1));
          v_t_24151 = v_s_24150;
          break;
        }
        default: heff_nomatch(v_t_24148);
        }
        v_t_24152 = heff_tag_at_n(v_ru_24e1_241_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24148}), v_t_24151});
        break;
      }
      default: heff_nomatch(v_x1_24142);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_x_24140, v_t_24152}), v_sp_242});
    }
    case TAG_EPi: {
      V v_ru_24e1_241_24EPi = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24155 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24165;
      switch (heff_tag_of(v_x1_24155)) {
      case TAG_IsInferable: {
        V v_i_24156 = heff_field(v_x1_24155, 0);
        heff_take_n(v_x1_24155, 1ULL, 1);
        V v_t_24159;
        switch (heff_tag_of(v_i_24156)) {
        case TAG_At: {
          V v_s_24158 = heff_dup(heff_field(v_i_24156, 1));
          v_t_24159 = v_s_24158;
          break;
        }
        default: heff_nomatch(v_i_24156);
        }
        v_t_24165 = heff_tag_at_n(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24156}), v_t_24159});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24160 = heff_field(v_x1_24155, 0);
        heff_take_n(v_x1_24155, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EPi, 2);
        v_t_24165 = v_c_24160;
        break;
      }
      case TAG_IsType: {
        V v_t_24161 = heff_field(v_x1_24155, 0);
        heff_take_n(v_x1_24155, 1ULL, 1);
        V v_t_24164;
        switch (heff_tag_of(v_t_24161)) {
        case TAG_At: {
          V v_s_24163 = heff_dup(heff_field(v_t_24161, 1));
          v_t_24164 = v_s_24163;
          break;
        }
        default: heff_nomatch(v_t_24161);
        }
        v_t_24165 = heff_tag_at_n(v_ru_24e1_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24161}), v_t_24164});
        break;
      }
      default: heff_nomatch(v_x1_24155);
      }
      V v_t_24168;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24167 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24168 = v_s_24167;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24165}), v_t_24168});
    }
    case TAG_ELam: {
      V v_ru_24e1_241_24ELam = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24171 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24181;
      switch (heff_tag_of(v_x1_24171)) {
      case TAG_IsInferable: {
        V v_i_24172 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24175;
        switch (heff_tag_of(v_i_24172)) {
        case TAG_At: {
          V v_s_24174 = heff_dup(heff_field(v_i_24172, 1));
          v_t_24175 = v_s_24174;
          break;
        }
        default: heff_nomatch(v_i_24172);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24172}), v_t_24175});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24176 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELam, 2);
        v_t_24181 = v_c_24176;
        break;
      }
      case TAG_IsType: {
        V v_t_24177 = heff_field(v_x1_24171, 0);
        heff_take_n(v_x1_24171, 1ULL, 1);
        V v_t_24180;
        switch (heff_tag_of(v_t_24177)) {
        case TAG_At: {
          V v_s_24179 = heff_dup(heff_field(v_t_24177, 1));
          v_t_24180 = v_s_24179;
          break;
        }
        default: heff_nomatch(v_t_24177);
        }
        v_t_24181 = heff_tag_at_n(v_ru_24e1_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24177}), v_t_24180});
        break;
      }
      default: heff_nomatch(v_x1_24171);
      }
      V v_t_24184;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24183 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24184 = v_s_24183;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24181}), v_t_24184});
    }
    case TAG_EAnn: {
      V v_ru_24e1_241_24EAnn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24187 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24197;
      switch (heff_tag_of(v_x1_24187)) {
      case TAG_IsInferable: {
        V v_i_24188 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24191;
        switch (heff_tag_of(v_i_24188)) {
        case TAG_At: {
          V v_s_24190 = heff_dup(heff_field(v_i_24188, 1));
          v_t_24191 = v_s_24190;
          break;
        }
        default: heff_nomatch(v_i_24188);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24188}), v_t_24191});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24192 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EAnn, 2);
        v_t_24197 = v_c_24192;
        break;
      }
      case TAG_IsType: {
        V v_t_24193 = heff_field(v_x1_24187, 0);
        heff_take_n(v_x1_24187, 1ULL, 1);
        V v_t_24196;
        switch (heff_tag_of(v_t_24193)) {
        case TAG_At: {
          V v_s_24195 = heff_dup(heff_field(v_t_24193, 1));
          v_t_24196 = v_s_24195;
          break;
        }
        default: heff_nomatch(v_t_24193);
        }
        v_t_24197 = heff_tag_at_n(v_ru_24e1_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24193}), v_t_24196});
        break;
      }
      default: heff_nomatch(v_x1_24187);
      }
      V v_t_24200;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24199 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24200 = v_s_24199;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24197}), v_t_24200});
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_241, 0ULL, 4);
      heff_drop(v_sp_242);
      V v_x1_24205 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24215;
      switch (heff_tag_of(v_x1_24205)) {
      case TAG_IsInferable: {
        V v_i_24206 = heff_field(v_x1_24205, 0);
        V v_ru_24x1_24205_24IsInferable = heff_take_reuse_n(v_x1_24205, 1ULL, 1);
        V v_t_24209;
        switch (heff_tag_of(v_i_24206)) {
        case TAG_At: {
          V v_s_24208 = heff_dup(heff_field(v_i_24206, 1));
          v_t_24209 = v_s_24208;
          break;
        }
        default: heff_nomatch(v_i_24206);
        }
        v_t_24215 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24205_24IsInferable, TAG_CInf, 1, (V[]){v_i_24206}), v_t_24209});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24210 = heff_field(v_x1_24205, 0);
        heff_take_n(v_x1_24205, 1ULL, 1);
        v_t_24215 = v_c_24210;
        break;
      }
      case TAG_IsType: {
        V v_t_24211 = heff_field(v_x1_24205, 0);
        V v_ru_24x1_24205_24IsType = heff_take_reuse_n(v_x1_24205, 1ULL, 1);
        V v_t_24214;
        switch (heff_tag_of(v_t_24211)) {
        case TAG_At: {
          V v_s_24213 = heff_dup(heff_field(v_t_24211, 1));
          v_t_24214 = v_s_24213;
          break;
        }
        default: heff_nomatch(v_t_24211);
        }
        v_t_24215 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_24205_24IsType, TAG_CType, 1, (V[]){v_t_24211}), v_t_24214});
        break;
      }
      default: heff_nomatch(v_x1_24205);
      }
      V v_t_24218;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24217 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24218 = v_s_24217;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24215}), v_t_24218});
    }
    case TAG_ESig: {
      V v_ru_24e1_241_24ESig = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24220 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24230;
      switch (heff_tag_of(v_x1_24220)) {
      case TAG_IsInferable: {
        V v_i_24221 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        V v_t_24224;
        switch (heff_tag_of(v_i_24221)) {
        case TAG_At: {
          V v_s_24223 = heff_dup(heff_field(v_i_24221, 1));
          v_t_24224 = v_s_24223;
          break;
        }
        default: heff_nomatch(v_i_24221);
        }
        v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESig, TAG_CInf, 1, (V[]){v_i_24221}), v_t_24224});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24225 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ESig, 1);
        v_t_24230 = v_c_24225;
        break;
      }
      case TAG_IsType: {
        V v_t_24226 = heff_field(v_x1_24220, 0);
        heff_take_n(v_x1_24220, 1ULL, 1);
        V v_t_24229;
        switch (heff_tag_of(v_t_24226)) {
        case TAG_At: {
          V v_s_24228 = heff_dup(heff_field(v_t_24226, 1));
          v_t_24229 = v_s_24228;
          break;
        }
        default: heff_nomatch(v_t_24226);
        }
        v_t_24230 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESig, TAG_CType, 1, (V[]){v_t_24226}), v_t_24229});
        break;
      }
      default: heff_nomatch(v_x1_24220);
      }
      V v_t_24233;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24232 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24233 = v_s_24232;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24230}), v_t_24233});
    }
    case TAG_ESum: {
      V v_ru_24e1_241_24ESum = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24235 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24245;
      switch (heff_tag_of(v_x1_24235)) {
      case TAG_IsInferable: {
        V v_i_24236 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        V v_t_24239;
        switch (heff_tag_of(v_i_24236)) {
        case TAG_At: {
          V v_s_24238 = heff_dup(heff_field(v_i_24236, 1));
          v_t_24239 = v_s_24238;
          break;
        }
        default: heff_nomatch(v_i_24236);
        }
        v_t_24245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESum, TAG_CInf, 1, (V[]){v_i_24236}), v_t_24239});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24240 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ESum, 1);
        v_t_24245 = v_c_24240;
        break;
      }
      case TAG_IsType: {
        V v_t_24241 = heff_field(v_x1_24235, 0);
        heff_take_n(v_x1_24235, 1ULL, 1);
        V v_t_24244;
        switch (heff_tag_of(v_t_24241)) {
        case TAG_At: {
          V v_s_24243 = heff_dup(heff_field(v_t_24241, 1));
          v_t_24244 = v_s_24243;
          break;
        }
        default: heff_nomatch(v_t_24241);
        }
        v_t_24245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24ESum, TAG_CType, 1, (V[]){v_t_24241}), v_t_24244});
        break;
      }
      default: heff_nomatch(v_x1_24235);
      }
      V v_t_24248;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24247 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24248 = v_s_24247;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24245}), v_t_24248});
    }
    case TAG_EStruct: {
      V v_ru_24e1_241_24EStruct = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24250 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24260;
      switch (heff_tag_of(v_x1_24250)) {
      case TAG_IsInferable: {
        V v_i_24251 = heff_field(v_x1_24250, 0);
        heff_take_n(v_x1_24250, 1ULL, 1);
        V v_t_24254;
        switch (heff_tag_of(v_i_24251)) {
        case TAG_At: {
          V v_s_24253 = heff_dup(heff_field(v_i_24251, 1));
          v_t_24254 = v_s_24253;
          break;
        }
        default: heff_nomatch(v_i_24251);
        }
        v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EStruct, TAG_CInf, 1, (V[]){v_i_24251}), v_t_24254});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24255 = heff_field(v_x1_24250, 0);
        heff_take_n(v_x1_24250, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EStruct, 1);
        v_t_24260 = v_c_24255;
        break;
      }
      case TAG_IsType: {
        V v_t_24256 = heff_field(v_x1_24250, 0);
        heff_take_n(v_x1_24250, 1ULL, 1);
        V v_t_24259;
        switch (heff_tag_of(v_t_24256)) {
        case TAG_At: {
          V v_s_24258 = heff_dup(heff_field(v_t_24256, 1));
          v_t_24259 = v_s_24258;
          break;
        }
        default: heff_nomatch(v_t_24256);
        }
        v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EStruct, TAG_CType, 1, (V[]){v_t_24256}), v_t_24259});
        break;
      }
      default: heff_nomatch(v_x1_24250);
      }
      V v_t_24263;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24262 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24263 = v_s_24262;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24260}), v_t_24263});
    }
    case TAG_EMatch: {
      V v_ru_24e1_241_24EMatch = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24266 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24276;
      switch (heff_tag_of(v_x1_24266)) {
      case TAG_IsInferable: {
        V v_i_24267 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24270;
        switch (heff_tag_of(v_i_24267)) {
        case TAG_At: {
          V v_s_24269 = heff_dup(heff_field(v_i_24267, 1));
          v_t_24270 = v_s_24269;
          break;
        }
        default: heff_nomatch(v_i_24267);
        }
        v_t_24276 = heff_tag_at_n(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24267}), v_t_24270});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24271 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EMatch, 2);
        v_t_24276 = v_c_24271;
        break;
      }
      case TAG_IsType: {
        V v_t_24272 = heff_field(v_x1_24266, 0);
        heff_take_n(v_x1_24266, 1ULL, 1);
        V v_t_24275;
        switch (heff_tag_of(v_t_24272)) {
        case TAG_At: {
          V v_s_24274 = heff_dup(heff_field(v_t_24272, 1));
          v_t_24275 = v_s_24274;
          break;
        }
        default: heff_nomatch(v_t_24272);
        }
        v_t_24276 = heff_tag_at_n(v_ru_24e1_241_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24272}), v_t_24275});
        break;
      }
      default: heff_nomatch(v_x1_24266);
      }
      V v_t_24279;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24278 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24279 = v_s_24278;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24276}), v_t_24279});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_241_24ELetIn = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24282 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24292;
      switch (heff_tag_of(v_x1_24282)) {
      case TAG_IsInferable: {
        V v_i_24283 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24286;
        switch (heff_tag_of(v_i_24283)) {
        case TAG_At: {
          V v_s_24285 = heff_dup(heff_field(v_i_24283, 1));
          v_t_24286 = v_s_24285;
          break;
        }
        default: heff_nomatch(v_i_24283);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24283}), v_t_24286});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24287 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELetIn, 2);
        v_t_24292 = v_c_24287;
        break;
      }
      case TAG_IsType: {
        V v_t_24288 = heff_field(v_x1_24282, 0);
        heff_take_n(v_x1_24282, 1ULL, 1);
        V v_t_24291;
        switch (heff_tag_of(v_t_24288)) {
        case TAG_At: {
          V v_s_24290 = heff_dup(heff_field(v_t_24288, 1));
          v_t_24291 = v_s_24290;
          break;
        }
        default: heff_nomatch(v_t_24288);
        }
        v_t_24292 = heff_tag_at_n(v_ru_24e1_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24288}), v_t_24291});
        break;
      }
      default: heff_nomatch(v_x1_24282);
      }
      V v_t_24295;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24294 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24295 = v_s_24294;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24292}), v_t_24295});
    }
    case TAG_EDo: {
      V v_ru_24e1_241_24EDo = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24297 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24307;
      switch (heff_tag_of(v_x1_24297)) {
      case TAG_IsInferable: {
        V v_i_24298 = heff_field(v_x1_24297, 0);
        heff_take_n(v_x1_24297, 1ULL, 1);
        V v_t_24301;
        switch (heff_tag_of(v_i_24298)) {
        case TAG_At: {
          V v_s_24300 = heff_dup(heff_field(v_i_24298, 1));
          v_t_24301 = v_s_24300;
          break;
        }
        default: heff_nomatch(v_i_24298);
        }
        v_t_24307 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EDo, TAG_CInf, 1, (V[]){v_i_24298}), v_t_24301});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24302 = heff_field(v_x1_24297, 0);
        heff_take_n(v_x1_24297, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EDo, 1);
        v_t_24307 = v_c_24302;
        break;
      }
      case TAG_IsType: {
        V v_t_24303 = heff_field(v_x1_24297, 0);
        heff_take_n(v_x1_24297, 1ULL, 1);
        V v_t_24306;
        switch (heff_tag_of(v_t_24303)) {
        case TAG_At: {
          V v_s_24305 = heff_dup(heff_field(v_t_24303, 1));
          v_t_24306 = v_s_24305;
          break;
        }
        default: heff_nomatch(v_t_24303);
        }
        v_t_24307 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EDo, TAG_CType, 1, (V[]){v_t_24303}), v_t_24306});
        break;
      }
      default: heff_nomatch(v_x1_24297);
      }
      V v_t_24310;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24309 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24310 = v_s_24309;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24307}), v_t_24310});
    }
    case TAG_ELocal: {
      V v_ru_24e1_241_24ELocal = heff_take_reuse_n(v_e1_241, 0ULL, 2);
      heff_drop(v_sp_242);
      V v_x1_24313 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24323;
      switch (heff_tag_of(v_x1_24313)) {
      case TAG_IsInferable: {
        V v_i_24314 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        V v_t_24317;
        switch (heff_tag_of(v_i_24314)) {
        case TAG_At: {
          V v_s_24316 = heff_dup(heff_field(v_i_24314, 1));
          v_t_24317 = v_s_24316;
          break;
        }
        default: heff_nomatch(v_i_24314);
        }
        v_t_24323 = heff_tag_at_n(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24314}), v_t_24317});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24318 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24ELocal, 2);
        v_t_24323 = v_c_24318;
        break;
      }
      case TAG_IsType: {
        V v_t_24319 = heff_field(v_x1_24313, 0);
        heff_take_n(v_x1_24313, 1ULL, 1);
        V v_t_24322;
        switch (heff_tag_of(v_t_24319)) {
        case TAG_At: {
          V v_s_24321 = heff_dup(heff_field(v_t_24319, 1));
          v_t_24322 = v_s_24321;
          break;
        }
        default: heff_nomatch(v_t_24319);
        }
        v_t_24323 = heff_tag_at_n(v_ru_24e1_241_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24319}), v_t_24322});
        break;
      }
      default: heff_nomatch(v_x1_24313);
      }
      V v_t_24326;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24325 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24326 = v_s_24325;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24323}), v_t_24326});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_241_24EInvalid = heff_take_reuse_n(v_e1_241, 0ULL, 1);
      heff_drop(v_sp_242);
      V v_x1_24328 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(heff_dup(v_e_240)));
      V v_t_24338;
      switch (heff_tag_of(v_x1_24328)) {
      case TAG_IsInferable: {
        V v_i_24329 = heff_field(v_x1_24328, 0);
        heff_take_n(v_x1_24328, 1ULL, 1);
        V v_t_24332;
        switch (heff_tag_of(v_i_24329)) {
        case TAG_At: {
          V v_s_24331 = heff_dup(heff_field(v_i_24329, 1));
          v_t_24332 = v_s_24331;
          break;
        }
        default: heff_nomatch(v_i_24329);
        }
        v_t_24338 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInvalid, TAG_CInf, 1, (V[]){v_i_24329}), v_t_24332});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24333 = heff_field(v_x1_24328, 0);
        heff_take_n(v_x1_24328, 1ULL, 1);
        heff_drop_cell(v_ru_24e1_241_24EInvalid, 1);
        v_t_24338 = v_c_24333;
        break;
      }
      case TAG_IsType: {
        V v_t_24334 = heff_field(v_x1_24328, 0);
        heff_take_n(v_x1_24328, 1ULL, 1);
        V v_t_24337;
        switch (heff_tag_of(v_t_24334)) {
        case TAG_At: {
          V v_s_24336 = heff_dup(heff_field(v_t_24334, 1));
          v_t_24337 = v_s_24336;
          break;
        }
        default: heff_nomatch(v_t_24334);
        }
        v_t_24338 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_241_24EInvalid, TAG_CType, 1, (V[]){v_t_24334}), v_t_24337});
        break;
      }
      default: heff_nomatch(v_x1_24328);
      }
      V v_t_24341;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24340 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_24341 = v_s_24340;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_t_24338}), v_t_24341});
    }
    default: return heff_nomatch(v_e1_241);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eargOf_24s1708951253x871321164(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str0, 22, "`Array` takes one type");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str1, 22, "`Array` takes one type");
Clo g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry, 3, 0};

V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(V v_h_240, V v_args_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_At: {
    V v_h1_243 = heff_dup(heff_field(v_h_240, 0));
    V v_tsp_244 = heff_dup(heff_field(v_h_240, 1));
    switch (heff_tag_of(v_h1_243)) {
    case TAG_EVar: {
      V v_ru_24h1_243_24EVar = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_247 = ({ V a_0 = v_t_246; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_246); r_; });
      V v_t_248 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EVar, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_242})});
    }
    case TAG_EImplicitVar: {
      V v_ru_24h1_243_24EImplicitVar = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2411, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EImplicitVar, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_242})});
    }
    case TAG_ETag: {
      V v_t_2413 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24ETag = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      heff_drop_tag(v_h_240, 2);
      V v_t_2414 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_2413, v_tsp_244, (g_list_2emap_24s1844509821x2028168277(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_242})});
    }
    case TAG_EInt: {
      V v_ru_24h1_243_24EInt = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2416 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2416); r_; });
      V v_t_2418 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EInt, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_242})});
    }
    case TAG_EFloat: {
      V v_ru_24h1_243_24EFloat = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2420 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2420); r_; });
      V v_t_2422 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2421, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EFloat, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_242})});
    }
    case TAG_EString: {
      V v_ru_24h1_243_24EString = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2424); r_; });
      V v_t_2426 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2425, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EString, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, v_sp_242})});
    }
    case TAG_ERune: {
      V v_ru_24h1_243_24ERune = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2428 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2429 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2428); r_; });
      V v_t_2430 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24ERune, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2430, v_sp_242})});
    }
    case TAG_EWord: {
      V v_h11_2431 = heff_field(v_h1_243, 0);
      V v_ru_24h1_243_24EWord = heff_take_reuse_n(v_h1_243, 1ULL, 1);
      heff_drop(v_tsp_244);
      switch (heff_tag_of(v_h11_2431)) {
      case TAG_TypeWord: {
        V v_t_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2432); r_; });
        V v_t_2434 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2433, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_sp_242})});
      }
      case TAG_IntWord: {
        V v_t_2435 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2436 = ({ V a_0 = v_t_2435; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2435); r_; });
        V v_t_2437 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2436, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, v_sp_242})});
      }
      case TAG_FloatWord: {
        V v_t_2438 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2438); r_; });
        V v_t_2440 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2439, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_242})});
      }
      case TAG_StringWord: {
        V v_t_2441 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2442 = ({ V a_0 = v_t_2441; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2441); r_; });
        V v_t_2443 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2442, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, v_sp_242})});
      }
      case TAG_RuneWord: {
        V v_t_2444 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2444); r_; });
        V v_t_2446 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2445, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_242})});
      }
      case TAG_ArrayWord: {
        heff_drop_tag(v_h_240, 2);
        switch (heff_tag_of(v_args_241)) {
        case TAG_Nil: {
          V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str0)}), heff_dup(v_sp_242)});
          V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_t_2447}), v_sp_242});
          return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2448});
        }
        case TAG_Cons: {
          V v_a_2449 = heff_field(v_args_241, 0);
          V v_args2_2450 = heff_field(v_args_241, 1);
          V v_ru_24args_241_24Cons = heff_take_reuse_n(v_args_241, 3ULL, 2);
          switch (heff_tag_of(v_args2_2450)) {
          case TAG_Nil: {
            V v_x1_2451 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_2449));
            V v_t_2461;
            switch (heff_tag_of(v_x1_2451)) {
            case TAG_IsInferable: {
              V v_i_2452 = heff_field(v_x1_2451, 0);
              heff_take_n(v_x1_2451, 1ULL, 1);
              V v_t_2455;
              switch (heff_tag_of(v_i_2452)) {
              case TAG_At: {
                V v_s_2454 = heff_dup(heff_field(v_i_2452, 1));
                v_t_2455 = v_s_2454;
                break;
              }
              default: heff_nomatch(v_i_2452);
              }
              v_t_2461 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_i_2452}), v_t_2455});
              break;
            }
            case TAG_IsCheckable: {
              V v_c_2456 = heff_field(v_x1_2451, 0);
              heff_take_n(v_x1_2451, 1ULL, 1);
              V v_t_2459;
              switch (heff_tag_of(v_c_2456)) {
              case TAG_At: {
                V v_s_2458 = heff_dup(heff_field(v_c_2456, 1));
                v_t_2459 = v_s_2458;
                break;
              }
              default: heff_nomatch(v_c_2456);
              }
              v_t_2461 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TChk, 1, (V[]){v_c_2456}), v_t_2459});
              break;
            }
            case TAG_IsType: {
              V v_t_2460 = heff_field(v_x1_2451, 0);
              heff_take_n(v_x1_2451, 1ULL, 1);
              heff_drop_cell(v_ru_24h1_243_24EWord, 1);
              heff_drop_cell(v_ru_24args_241_24Cons, 2);
              v_t_2461 = v_t_2460;
              break;
            }
            default: heff_nomatch(v_x1_2451);
            }
            V v_t_2462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_TArray, 1, (V[]){v_t_2461}), v_sp_242});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2462});
          }
          case TAG_Cons: {
            V v_ru_24args2_2450_24Cons = heff_take_reuse_n(v_args2_2450, 0ULL, 2);
            heff_drop(v_a_2449);
            V v_t_2465 = heff_tag_at_n(v_ru_24args_241_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_str1)}), heff_dup(v_sp_242)});
            V v_t_2466 = heff_tag_at_n(v_ru_24args2_2450_24Cons, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_TInf, 1, (V[]){v_t_2465}), v_sp_242});
            return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2466});
          }
          default: return heff_nomatch(v_args2_2450);
          }
        }
        default: return heff_nomatch(v_args_241);
        }
      }
      case TAG_AbandonWord: {
        V v_t_2467 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2468 = ({ V a_0 = v_t_2467; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2467); r_; });
        V v_t_2469 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2468, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2469, v_sp_242})});
      }
      case TAG_FixedWord: {
        heff_take_n(v_h11_2431, 0ULL, 1);
        V v_t_2471 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
        V v_t_2472 = ({ V a_0 = v_t_2471; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2471); r_; });
        V v_t_2473 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2472, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
        return heff_tag_at_n(v_ru_24h1_243_24EWord, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2473, v_sp_242})});
      }
      default: return heff_nomatch(v_h11_2431);
      }
    }
    case TAG_EApp: {
      V v_ru_24h1_243_24EApp = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2476 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2477 = ({ V a_0 = v_t_2476; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2476); r_; });
      V v_t_2478 = heff_tag_at_n(v_ru_24h1_243_24EApp, TAG_IApp, 2, (V[]){v_t_2477, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2478, v_sp_242})});
    }
    case TAG_EProject: {
      V v_ru_24h1_243_24EProject = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2480 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2481 = ({ V a_0 = v_t_2480; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2480); r_; });
      V v_t_2482 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_2481, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EProject, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2482, v_sp_242})});
    }
    case TAG_ENamed: {
      V v_ru_24h1_243_24ENamed = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2485 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2486 = ({ V a_0 = v_t_2485; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2485); r_; });
      V v_t_2487 = heff_tag_at_n(v_ru_24h1_243_24ENamed, TAG_IApp, 2, (V[]){v_t_2486, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2487, v_sp_242})});
    }
    case TAG_EPi: {
      V v_ru_24h1_243_24EPi = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2490 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2491 = ({ V a_0 = v_t_2490; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2490); r_; });
      V v_t_2492 = heff_tag_at_n(v_ru_24h1_243_24EPi, TAG_IApp, 2, (V[]){v_t_2491, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2492, v_sp_242})});
    }
    case TAG_ELam: {
      V v_ru_24h1_243_24ELam = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2495 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_2496 = ({ V a_0 = v_t_2495; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_2495); r_; });
      V v_t_2497 = heff_tag_at_n(v_ru_24h1_243_24ELam, TAG_IApp, 2, (V[]){v_t_2496, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2497, v_sp_242})});
    }
    case TAG_EAnn: {
      V v_ru_24h1_243_24EAnn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24100 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24101 = ({ V a_0 = v_t_24100; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24100); r_; });
      V v_t_24102 = heff_tag_at_n(v_ru_24h1_243_24EAnn, TAG_IApp, 2, (V[]){v_t_24101, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24102, v_sp_242})});
    }
    case TAG_ESpec: {
      heff_take_n(v_h1_243, 0ULL, 4);
      heff_drop(v_tsp_244);
      V v_t_24107 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24108 = ({ V a_0 = v_t_24107; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24107); r_; });
      V v_t_24109 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24108, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24109, v_sp_242})});
    }
    case TAG_ESig: {
      V v_ru_24h1_243_24ESig = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24111 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24112 = ({ V a_0 = v_t_24111; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24111); r_; });
      V v_t_24113 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24112, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24ESig, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24113, v_sp_242})});
    }
    case TAG_ESum: {
      V v_ru_24h1_243_24ESum = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24115 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24116 = ({ V a_0 = v_t_24115; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24115); r_; });
      V v_t_24117 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24116, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24ESum, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24117, v_sp_242})});
    }
    case TAG_EStruct: {
      V v_ru_24h1_243_24EStruct = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24119 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24120 = ({ V a_0 = v_t_24119; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24119); r_; });
      V v_t_24121 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24120, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EStruct, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24121, v_sp_242})});
    }
    case TAG_EMatch: {
      V v_ru_24h1_243_24EMatch = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24124 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24125 = ({ V a_0 = v_t_24124; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24124); r_; });
      V v_t_24126 = heff_tag_at_n(v_ru_24h1_243_24EMatch, TAG_IApp, 2, (V[]){v_t_24125, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24126, v_sp_242})});
    }
    case TAG_ELetIn: {
      V v_ru_24h1_243_24ELetIn = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24129 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24130 = ({ V a_0 = v_t_24129; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24129); r_; });
      V v_t_24131 = heff_tag_at_n(v_ru_24h1_243_24ELetIn, TAG_IApp, 2, (V[]){v_t_24130, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24131, v_sp_242})});
    }
    case TAG_EDo: {
      V v_ru_24h1_243_24EDo = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24133 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24134 = ({ V a_0 = v_t_24133; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24133); r_; });
      V v_t_24135 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24134, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EDo, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24135, v_sp_242})});
    }
    case TAG_ELocal: {
      V v_ru_24h1_243_24ELocal = heff_take_reuse_n(v_h1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24138 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24139 = ({ V a_0 = v_t_24138; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24138); r_; });
      V v_t_24140 = heff_tag_at_n(v_ru_24h1_243_24ELocal, TAG_IApp, 2, (V[]){v_t_24139, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24140, v_sp_242})});
    }
    case TAG_EInvalid: {
      V v_ru_24h1_243_24EInvalid = heff_take_reuse_n(v_h1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24142 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_h_240));
      V v_t_24143 = ({ V a_0 = v_t_24142; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24142); r_; });
      V v_t_24144 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_24143, (g_list_2emap_24s1688457226x2006118782(v_args_241))});
      return heff_tag_at_n(v_ru_24h1_243_24EInvalid, TAG_IsInferable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24144, v_sp_242})});
    }
    default: return heff_nomatch(v_h1_243);
    }
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xsp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_x1_244 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_243));
    V v_t_2414;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_IsInferable: {
      V v_i_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24IsInferable = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_t_248;
      switch (heff_tag_of(v_i_245)) {
      case TAG_At: {
        V v_s_247 = heff_dup(heff_field(v_i_245, 1));
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_i_245);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_244_24IsInferable, TAG_TInf, 1, (V[]){v_i_245}), v_t_248});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_249 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24IsCheckable = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_c_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_c_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_c_249);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_244_24IsCheckable, TAG_TChk, 1, (V[]){v_c_249}), v_t_2412});
      break;
    }
    case TAG_IsType: {
      V v_t_2413 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      v_t_2414 = v_t_2413;
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_xsp_242, v_t_2414});
  }
  case TAG_PiImplicit: {
    V v_x_2415 = heff_field(v_x2_240, 0);
    V v_xsp_2416 = heff_field(v_x2_240, 1);
    V v_bsp_2417 = heff_field(v_x2_240, 2);
    V v_t_2418 = heff_field(v_x2_240, 3);
    V v_d_2419 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_x1_2420 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2418));
    V v_t_2430;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_IsInferable: {
      V v_i_2421 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24IsInferable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      V v_t_2424;
      switch (heff_tag_of(v_i_2421)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_i_2421);
      }
      v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsInferable, TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2425 = heff_field(v_x1_2420, 0);
      V v_ru_24x1_2420_24IsCheckable = heff_take_reuse_n(v_x1_2420, 1ULL, 1);
      V v_t_2428;
      switch (heff_tag_of(v_c_2425)) {
      case TAG_At: {
        V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_c_2425);
      }
      v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2420_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
      break;
    }
    case TAG_IsType: {
      V v_t_2429 = heff_field(v_x1_2420, 0);
      heff_take_n(v_x1_2420, 1ULL, 1);
      v_t_2430 = v_t_2429;
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    V v_t_2443;
    switch (heff_tag_of(v_d_2419)) {
    case TAG_Nothing: {
      v_t_2443 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2431 = heff_field(v_d_2419, 0);
      V v_ru_24d_2419_24Just = heff_take_reuse_n(v_d_2419, 1ULL, 1);
      V v_x1_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_2431));
      V v_t_2442;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_IsInferable: {
        V v_i_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_i_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_i_2433);
        }
        v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_2419_24Just, TAG_CInf, 1, (V[]){v_i_2433}), v_t_2436});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2437 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        heff_drop_cell(v_ru_24d_2419_24Just, 1);
        v_t_2442 = v_c_2437;
        break;
      }
      case TAG_IsType: {
        V v_t_2438 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2441;
        switch (heff_tag_of(v_t_2438)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_t_2438, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_t_2438);
        }
        v_t_2442 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_2419_24Just, TAG_CType, 1, (V[]){v_t_2438}), v_t_2441});
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2442});
      break;
    }
    default: heff_nomatch(v_d_2419);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_2415, v_xsp_2416, v_bsp_2417, v_t_2430, v_t_2443});
  }
  case TAG_PiInstance: {
    V v_x_2444 = heff_field(v_x2_240, 0);
    V v_xsp_2445 = heff_field(v_x2_240, 1);
    V v_bsp_2446 = heff_field(v_x2_240, 2);
    V v_t_2447 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_x1_2448 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2447));
    V v_t_2458;
    switch (heff_tag_of(v_x1_2448)) {
    case TAG_IsInferable: {
      V v_i_2449 = heff_field(v_x1_2448, 0);
      V v_ru_24x1_2448_24IsInferable = heff_take_reuse_n(v_x1_2448, 1ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_i_2449)) {
      case TAG_At: {
        V v_s_2451 = heff_dup(heff_field(v_i_2449, 1));
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_i_2449);
      }
      v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2448_24IsInferable, TAG_TInf, 1, (V[]){v_i_2449}), v_t_2452});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2453 = heff_field(v_x1_2448, 0);
      V v_ru_24x1_2448_24IsCheckable = heff_take_reuse_n(v_x1_2448, 1ULL, 1);
      V v_t_2456;
      switch (heff_tag_of(v_c_2453)) {
      case TAG_At: {
        V v_s_2455 = heff_dup(heff_field(v_c_2453, 1));
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_c_2453);
      }
      v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2448_24IsCheckable, TAG_TChk, 1, (V[]){v_c_2453}), v_t_2456});
      break;
    }
    case TAG_IsType: {
      V v_t_2457 = heff_field(v_x1_2448, 0);
      heff_take_n(v_x1_2448, 1ULL, 1);
      v_t_2458 = v_t_2457;
      break;
    }
    default: heff_nomatch(v_x1_2448);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2444, v_xsp_2445, v_bsp_2446, v_t_2458});
  }
  case TAG_PiAnon: {
    V v_t_2459 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_x1_2460 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2459));
    V v_t_2470;
    switch (heff_tag_of(v_x1_2460)) {
    case TAG_IsInferable: {
      V v_i_2461 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      V v_t_2464;
      switch (heff_tag_of(v_i_2461)) {
      case TAG_At: {
        V v_s_2463 = heff_dup(heff_field(v_i_2461, 1));
        v_t_2464 = v_s_2463;
        break;
      }
      default: heff_nomatch(v_i_2461);
      }
      v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_TInf, 1, (V[]){v_i_2461}), v_t_2464});
      break;
    }
    case TAG_IsCheckable: {
      V v_c_2465 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      V v_t_2468;
      switch (heff_tag_of(v_c_2465)) {
      case TAG_At: {
        V v_s_2467 = heff_dup(heff_field(v_c_2465, 1));
        v_t_2468 = v_s_2467;
        break;
      }
      default: heff_nomatch(v_c_2465);
      }
      v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_TChk, 1, (V[]){v_c_2465}), v_t_2468});
      break;
    }
    case TAG_IsType: {
      V v_t_2469 = heff_field(v_x1_2460, 0);
      heff_take_n(v_x1_2460, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24PiAnon, 1);
      v_t_2470 = v_t_2469;
      break;
    }
    default: heff_nomatch(v_x1_2460);
    }
    return heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_2470});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclareField = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_245));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      V v_t_2430;
      switch (heff_tag_of(v_d_246)) {
      case TAG_Nothing: {
        v_t_2430 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x_2418 = heff_field(v_d_246, 0);
        V v_ru_24d_246_24Just = heff_take_reuse_n(v_d_246, 1ULL, 1);
        V v_x1_2419 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_2418));
        V v_t_2429;
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_IsInferable: {
          V v_i_2420 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_i_2420)) {
          case TAG_At: {
            V v_s_2422 = heff_dup(heff_field(v_i_2420, 1));
            v_t_2423 = v_s_2422;
            break;
          }
          default: heff_nomatch(v_i_2420);
          }
          v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_246_24Just, TAG_CInf, 1, (V[]){v_i_2420}), v_t_2423});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2424 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          heff_drop_cell(v_ru_24d_246_24Just, 1);
          v_t_2429 = v_c_2424;
          break;
        }
        case TAG_IsType: {
          V v_t_2425 = heff_field(v_x1_2419, 0);
          heff_take_n(v_x1_2419, 1ULL, 1);
          V v_t_2428;
          switch (heff_tag_of(v_t_2425)) {
          case TAG_At: {
            V v_s_2427 = heff_dup(heff_field(v_t_2425, 1));
            v_t_2428 = v_s_2427;
            break;
          }
          default: heff_nomatch(v_t_2425);
          }
          v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d_246_24Just, TAG_CType, 1, (V[]){v_t_2425}), v_t_2428});
          break;
        }
        default: heff_nomatch(v_x1_2419);
        }
        v_t_2430 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2429});
        break;
      }
      default: heff_nomatch(v_d_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_243, v_xsp_244, v_t_2417, v_t_2430}), v_sp_242});
    }
    case TAG_BadFieldDecl: {
      V v_e_2431 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldDecl = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2432 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2431));
      V v_t_2442;
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_IsInferable: {
        V v_i_2433 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_i_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_i_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_i_2433);
        }
        v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2433}), v_t_2436});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2437 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        V v_t_2440;
        switch (heff_tag_of(v_c_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_dup(heff_field(v_c_2437, 1));
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_c_2437);
        }
        v_t_2442 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2437}), v_t_2440});
        break;
      }
      case TAG_IsType: {
        V v_t_2441 = heff_field(v_x1_2432, 0);
        heff_take_n(v_x1_2432, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2442 = v_t_2441;
        break;
      }
      default: heff_nomatch(v_x1_2432);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2442}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclOf_24s807593253x1578108584(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_TagVariant: {
      V v_t_243 = heff_field(v_x21_241, 0);
      V v_tsp_244 = heff_field(v_x21_241, 1);
      V v_args_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24TagVariant = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_t_246 = heff_tag_at_n(v_ru_24x21_241_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_243, v_tsp_244, (g_list_2emap_24s1887874170x1747433177(v_args_245))});
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_246, v_sp_242});
    }
    case TAG_BadVariant: {
      V v_e_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadVariant = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_248 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_247));
      V v_t_2418;
      switch (heff_tag_of(v_x1_248)) {
      case TAG_IsInferable: {
        V v_i_249 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_i_249)) {
        case TAG_At: {
          V v_s_2411 = heff_dup(heff_field(v_i_249, 1));
          v_t_2412 = v_s_2411;
          break;
        }
        default: heff_nomatch(v_i_249);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_249}), v_t_2412});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2413 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_c_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_c_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_c_2413);
        }
        v_t_2418 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2413}), v_t_2416});
        break;
      }
      case TAG_IsType: {
        V v_t_2417 = heff_field(v_x1_248, 0);
        heff_take_n(v_x1_248, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2418 = v_t_2417;
        break;
      }
      default: heff_nomatch(v_x1_248);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2418}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2evariantOf_24s1089609483x145345381(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_SetField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_e_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24SetField = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_c_2411;
        break;
      }
      case TAG_IsType: {
        V v_t_2412 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_t_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_t_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_t_2412);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2412}), v_t_2415});
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24SetField, TAG_SetField, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_BadFieldSet: {
      V v_e_2417 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24BadFieldSet = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_x1_2418 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2417));
      V v_t_2428;
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_IsInferable: {
        V v_i_2419 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2422;
        switch (heff_tag_of(v_i_2419)) {
        case TAG_At: {
          V v_s_2421 = heff_dup(heff_field(v_i_2419, 1));
          v_t_2422 = v_s_2421;
          break;
        }
        default: heff_nomatch(v_i_2419);
        }
        v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2419}), v_t_2422});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2423 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2428 = v_c_2423;
        break;
      }
      case TAG_IsType: {
        V v_t_2424 = heff_field(v_x1_2418, 0);
        heff_take_n(v_x1_2418, 1ULL, 1);
        V v_t_2427;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_At: {
          V v_s_2426 = heff_dup(heff_field(v_t_2424, 1));
          v_t_2427 = v_s_2426;
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        v_t_2428 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2424}), v_t_2427});
        break;
      }
      default: heff_nomatch(v_x1_2418);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2428}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldSetOf_24s1938785661x1170277985(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_b_244 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24MkAlt = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_245 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_b_244));
      V v_t_2415;
      switch (heff_tag_of(v_x1_245)) {
      case TAG_IsInferable: {
        V v_i_246 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_249;
        switch (heff_tag_of(v_i_246)) {
        case TAG_At: {
          V v_s_248 = heff_dup(heff_field(v_i_246, 1));
          v_t_249 = v_s_248;
          break;
        }
        default: heff_nomatch(v_i_246);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_246}), v_t_249});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2410 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2415 = v_c_2410;
        break;
      }
      case TAG_IsType: {
        V v_t_2411 = heff_field(v_x1_245, 0);
        heff_take_n(v_x1_245, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_t_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        v_t_2415 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2411}), v_t_2414});
        break;
      }
      default: heff_nomatch(v_x1_245);
      }
      return heff_tag_at_n(v_ru_24x21_241_24MkAlt, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_243, v_t_2415}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str0, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str1, 19, "unexpected notation");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str2, 36, "a `do` block ends with an expression");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str3, 36, "a `do` block ends with an expression");
Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_243}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EVar, TAG_IsInferable, 1, (V[]){v_t_244});
    }
    case TAG_EImplicitVar: {
      V v_x_245 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EImplicitVar = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_246 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_245}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EImplicitVar, TAG_IsInferable, 1, (V[]){v_t_246});
    }
    case TAG_ETag: {
      V v_t_247 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ETag = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_248 = heff_tag_n(TAG_CTag, 3, (V[]){v_t_247, heff_dup(v_sp_242), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x21_241_24ETag, TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_248, v_sp_242})});
    }
    case TAG_EInt: {
      V v_i_249 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EInt = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_i_249}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EInt, TAG_IsInferable, 1, (V[]){v_t_2410});
    }
    case TAG_EFloat: {
      V v_x_2411 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EFloat = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IFloat, 1, (V[]){v_x_2411}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EFloat, TAG_IsInferable, 1, (V[]){v_t_2412});
    }
    case TAG_EString: {
      V v_x_2413 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EString = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2413}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EString, TAG_IsInferable, 1, (V[]){v_t_2414});
    }
    case TAG_ERune: {
      V v_c_2415 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ERune = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_c_2415}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24ERune, TAG_IsInferable, 1, (V[]){v_t_2416});
    }
    case TAG_EWord: {
      V v_w_2417 = heff_field(v_x21_241, 0);
      heff_take_n(v_x21_241, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2ewordOf(v_w_2417, v_sp_242));
    }
    case TAG_EApp: {
      V v_h_2418 = heff_field(v_x21_241, 0);
      V v_args_2419 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return (g_heff_2esyntax_2epresyntax_2eappOf_24s283103144x935388147(v_h_2418, v_args_2419, v_sp_242));
    }
    case TAG_EProject: {
      V v_ru_24x21_241_24EProject = heff_take_reuse_n(v_x21_241, 0ULL, 1);
      V v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str0)}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EProject, TAG_IsInferable, 1, (V[]){v_t_2421});
    }
    case TAG_ENamed: {
      heff_take_n(v_x21_241, 0ULL, 2);
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str1)}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_2424});
    }
    case TAG_EPi: {
      V v_b_2425 = heff_field(v_x21_241, 0);
      V v_cod_2426 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EPi = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_2427 = (g_heff_2esyntax_2epresyntax_2epiBinderOf_24s542128094x1130689295(v_b_2425));
      V v_x1_2428 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_cod_2426));
      V v_t_2438;
      switch (heff_tag_of(v_x1_2428)) {
      case TAG_IsInferable: {
        V v_i_2429 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        V v_t_2432;
        switch (heff_tag_of(v_i_2429)) {
        case TAG_At: {
          V v_s_2431 = heff_dup(heff_field(v_i_2429, 1));
          v_t_2432 = v_s_2431;
          break;
        }
        default: heff_nomatch(v_i_2429);
        }
        v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2429}), v_t_2432});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2433 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        V v_t_2436;
        switch (heff_tag_of(v_c_2433)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_c_2433, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_c_2433);
        }
        v_t_2438 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2433}), v_t_2436});
        break;
      }
      case TAG_IsType: {
        V v_t_2437 = heff_field(v_x1_2428, 0);
        heff_take_n(v_x1_2428, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2438 = v_t_2437;
        break;
      }
      default: heff_nomatch(v_x1_2428);
      }
      V v_t_2439 = heff_tag_at_n(v_ru_24x21_241_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_2427, v_t_2438}), v_sp_242});
      return heff_tag_n(TAG_IsType, 1, (V[]){v_t_2439});
    }
    case TAG_ELam: {
      V v_x211_2440 = heff_field(v_x21_241, 0);
      V v_body_2441 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELam = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      switch (heff_tag_of(v_x211_2440)) {
      case TAG_LamName: {
        V v_x_2442 = heff_field(v_x211_2440, 0);
        V v_xsp_2443 = heff_field(v_x211_2440, 1);
        heff_take_n(v_x211_2440, 3ULL, 2);
        V v_x1_2444 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2441));
        V v_t_2454;
        switch (heff_tag_of(v_x1_2444)) {
        case TAG_IsInferable: {
          V v_i_2445 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          V v_t_2448;
          switch (heff_tag_of(v_i_2445)) {
          case TAG_At: {
            V v_s_2447 = heff_dup(heff_field(v_i_2445, 1));
            v_t_2448 = v_s_2447;
            break;
          }
          default: heff_nomatch(v_i_2445);
          }
          v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2445}), v_t_2448});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2449 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          v_t_2454 = v_c_2449;
          break;
        }
        case TAG_IsType: {
          V v_t_2450 = heff_field(v_x1_2444, 0);
          heff_take_n(v_x1_2444, 1ULL, 1);
          V v_t_2453;
          switch (heff_tag_of(v_t_2450)) {
          case TAG_At: {
            V v_s_2452 = heff_dup(heff_field(v_t_2450, 1));
            v_t_2453 = v_s_2452;
            break;
          }
          default: heff_nomatch(v_t_2450);
          }
          v_t_2454 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2450}), v_t_2453});
          break;
        }
        default: heff_nomatch(v_x1_2444);
        }
        V v_t_2455 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2442, v_xsp_2443, v_t_2454}), v_sp_242});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2455});
      }
      case TAG_LamImplicit: {
        V v_x_2456 = heff_field(v_x211_2440, 0);
        V v_xsp_2457 = heff_field(v_x211_2440, 1);
        heff_take_n(v_x211_2440, 3ULL, 2);
        V v_x1_2458 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2441));
        V v_t_2468;
        switch (heff_tag_of(v_x1_2458)) {
        case TAG_IsInferable: {
          V v_i_2459 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          V v_t_2462;
          switch (heff_tag_of(v_i_2459)) {
          case TAG_At: {
            V v_s_2461 = heff_dup(heff_field(v_i_2459, 1));
            v_t_2462 = v_s_2461;
            break;
          }
          default: heff_nomatch(v_i_2459);
          }
          v_t_2468 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2459}), v_t_2462});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2463 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          v_t_2468 = v_c_2463;
          break;
        }
        case TAG_IsType: {
          V v_t_2464 = heff_field(v_x1_2458, 0);
          heff_take_n(v_x1_2458, 1ULL, 1);
          V v_t_2467;
          switch (heff_tag_of(v_t_2464)) {
          case TAG_At: {
            V v_s_2466 = heff_dup(heff_field(v_t_2464, 1));
            v_t_2467 = v_s_2466;
            break;
          }
          default: heff_nomatch(v_t_2464);
          }
          v_t_2468 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2464}), v_t_2467});
          break;
        }
        default: heff_nomatch(v_x1_2458);
        }
        V v_t_2469 = heff_tag_at_n(v_ru_24x21_241_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_CImplicitLam, 3, (V[]){v_x_2456, v_xsp_2457, v_t_2468}), v_sp_242});
        return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_2469});
      }
      case TAG_LamAnn: {
        V v_x_2470 = heff_field(v_x211_2440, 0);
        V v_xsp_2471 = heff_field(v_x211_2440, 1);
        V v_t_2472 = heff_field(v_x211_2440, 2);
        heff_take_n(v_x211_2440, 7ULL, 3);
        heff_drop_cell(v_ru_24x21_241_24ELam, 2);
        V v_x1_2473 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2472));
        V v_t_2483;
        switch (heff_tag_of(v_x1_2473)) {
        case TAG_IsInferable: {
          V v_i_2474 = heff_field(v_x1_2473, 0);
          heff_take_n(v_x1_2473, 1ULL, 1);
          V v_t_2477;
          switch (heff_tag_of(v_i_2474)) {
          case TAG_At: {
            V v_s_2476 = heff_dup(heff_field(v_i_2474, 1));
            v_t_2477 = v_s_2476;
            break;
          }
          default: heff_nomatch(v_i_2474);
          }
          v_t_2483 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2474}), v_t_2477});
          break;
        }
        case TAG_IsCheckable: {
          V v_c_2478 = heff_field(v_x1_2473, 0);
          heff_take_n(v_x1_2473, 1ULL, 1);
          V v_t_2481;
          switch (heff_tag_of(v_c_2478)) {
          case TAG_At: {
            V v_s_2480 = heff_dup(heff_field(v_c_2478, 1));
            v_t_2481 = v_s_2480;
            break;
          }
          default: heff_nomatch(v_c_2478);
          }
          v_t_2483 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2478}), v_t_2481});
          break;
        }
        case TAG_IsType: {
          V v_t_2482 = heff_field(v_x1_2473, 0);
          heff_take_n(v_x1_2473, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          v_t_2483 = v_t_2482;
          break;
        }
        default: heff_nomatch(v_x1_2473);
        }
        V v_t_2484 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2441));
        return (g_heff_2esyntax_2epresyntax_2eannLamOf(v_x_2470, v_xsp_2471, v_t_2483, v_t_2484, v_sp_242));
      }
      default: return heff_nomatch(v_x211_2440);
      }
    }
    case TAG_EAnn: {
      V v_a_2485 = heff_field(v_x21_241, 0);
      V v_t_2486 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EAnn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_2487 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_2485));
      V v_t_2497;
      switch (heff_tag_of(v_x1_2487)) {
      case TAG_IsInferable: {
        V v_i_2488 = heff_field(v_x1_2487, 0);
        heff_take_n(v_x1_2487, 1ULL, 1);
        V v_t_2491;
        switch (heff_tag_of(v_i_2488)) {
        case TAG_At: {
          V v_s_2490 = heff_dup(heff_field(v_i_2488, 1));
          v_t_2491 = v_s_2490;
          break;
        }
        default: heff_nomatch(v_i_2488);
        }
        v_t_2497 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2488}), v_t_2491});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2492 = heff_field(v_x1_2487, 0);
        heff_take_n(v_x1_2487, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2497 = v_c_2492;
        break;
      }
      case TAG_IsType: {
        V v_t_2493 = heff_field(v_x1_2487, 0);
        heff_take_n(v_x1_2487, 1ULL, 1);
        V v_t_2496;
        switch (heff_tag_of(v_t_2493)) {
        case TAG_At: {
          V v_s_2495 = heff_dup(heff_field(v_t_2493, 1));
          v_t_2496 = v_s_2495;
          break;
        }
        default: heff_nomatch(v_t_2493);
        }
        v_t_2497 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2493}), v_t_2496});
        break;
      }
      default: heff_nomatch(v_x1_2487);
      }
      V v_x1_2498 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2486));
      V v_t_24108;
      switch (heff_tag_of(v_x1_2498)) {
      case TAG_IsInferable: {
        V v_i_2499 = heff_field(v_x1_2498, 0);
        heff_take_n(v_x1_2498, 1ULL, 1);
        V v_t_24102;
        switch (heff_tag_of(v_i_2499)) {
        case TAG_At: {
          V v_s_24101 = heff_dup(heff_field(v_i_2499, 1));
          v_t_24102 = v_s_24101;
          break;
        }
        default: heff_nomatch(v_i_2499);
        }
        v_t_24108 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2499}), v_t_24102});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24103 = heff_field(v_x1_2498, 0);
        heff_take_n(v_x1_2498, 1ULL, 1);
        V v_t_24106;
        switch (heff_tag_of(v_c_24103)) {
        case TAG_At: {
          V v_s_24105 = heff_dup(heff_field(v_c_24103, 1));
          v_t_24106 = v_s_24105;
          break;
        }
        default: heff_nomatch(v_c_24103);
        }
        v_t_24108 = heff_tag_at_n(v_ru_24x21_241_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_24103}), v_t_24106});
        break;
      }
      case TAG_IsType: {
        V v_t_24107 = heff_field(v_x1_2498, 0);
        heff_take_n(v_x1_2498, 1ULL, 1);
        heff_drop_cell(v_ru_24x21_241_24EAnn, 2);
        v_t_24108 = v_t_24107;
        break;
      }
      default: heff_nomatch(v_x1_2498);
      }
      V v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2497, v_t_24108}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24109});
    }
    case TAG_ESpec: {
      V v_a_24110 = heff_field(v_x21_241, 0);
      V v_x_24111 = heff_field(v_x21_241, 1);
      V v_fsp_24112 = heff_field(v_x21_241, 2);
      V v_v_24113 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24ESpec = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_24114 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_a_24110));
      V v_t_24115 = ({ V a_0 = v_t_24114; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24114); r_; });
      V v_x1_24116 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_v_24113));
      V v_t_24126;
      switch (heff_tag_of(v_x1_24116)) {
      case TAG_IsInferable: {
        V v_i_24117 = heff_field(v_x1_24116, 0);
        heff_take_n(v_x1_24116, 1ULL, 1);
        V v_t_24120;
        switch (heff_tag_of(v_i_24117)) {
        case TAG_At: {
          V v_s_24119 = heff_dup(heff_field(v_i_24117, 1));
          v_t_24120 = v_s_24119;
          break;
        }
        default: heff_nomatch(v_i_24117);
        }
        v_t_24126 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24117}), v_t_24120});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24121 = heff_field(v_x1_24116, 0);
        heff_take_n(v_x1_24116, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_24126 = v_c_24121;
        break;
      }
      case TAG_IsType: {
        V v_t_24122 = heff_field(v_x1_24116, 0);
        heff_take_n(v_x1_24116, 1ULL, 1);
        V v_t_24125;
        switch (heff_tag_of(v_t_24122)) {
        case TAG_At: {
          V v_s_24124 = heff_dup(heff_field(v_t_24122, 1));
          v_t_24125 = v_s_24124;
          break;
        }
        default: heff_nomatch(v_t_24122);
        }
        v_t_24126 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24122}), v_t_24125});
        break;
      }
      default: heff_nomatch(v_x1_24116);
      }
      V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ESpec, TAG_ISpec, 4, (V[]){v_t_24115, v_x_24111, v_fsp_24112, v_t_24126}), v_sp_242});
      return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24127});
    }
    case TAG_ESig: {
      V v_fs_24128 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESig = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24129 = heff_tag_at_n(v_ru_24x21_241_24ESig, TAG_TSig, 1, (V[]){(g_list_2emap_24s1253308387x88241051(v_fs_24128))});
      return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24129, v_sp_242})});
    }
    case TAG_ESum: {
      V v_vs_24130 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24ESum = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24131 = heff_tag_at_n(v_ru_24x21_241_24ESum, TAG_TSum, 1, (V[]){(g_list_2emap_24s503326960x1200444853(v_vs_24130))});
      return heff_tag_n(TAG_IsType, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24131, v_sp_242})});
    }
    case TAG_EStruct: {
      V v_fs_24132 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EStruct = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24133 = heff_tag_at_n(v_ru_24x21_241_24EStruct, TAG_CStruct, 1, (V[]){(g_list_2emap_24s1374235278x875430684(v_fs_24132))});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_24133, v_sp_242})});
    }
    case TAG_EMatch: {
      V v_s_24134 = heff_field(v_x21_241, 0);
      V v_alts_24135 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24EMatch = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24136 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_s_24134));
      V v_t_24137 = ({ V a_0 = v_t_24136; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24136); r_; });
      V v_t_24138 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_CMatch, 2, (V[]){v_t_24137, (g_list_2emap_24s1230969749x2018313496(v_alts_24135))});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_at_n(v_ru_24x21_241_24EMatch, TAG_At, 2, (V[]){v_t_24138, v_sp_242})});
    }
    case TAG_ELetIn: {
      V v_rhs_24139 = heff_field(v_x21_241, 0);
      V v_a_24140 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELetIn = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_t_24141 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_24139));
      V v_t_24142 = ({ V a_0 = v_t_24141; V r_ = (g_heff_2esyntax_2epresyntax_2etoInferable(a_0)); heff_drop(v_t_24141); r_; });
      V v_t_24158;
      switch (heff_tag_of(v_a_24140)) {
      case TAG_At: {
        V v_x21_24143 = heff_field(v_a_24140, 0);
        V v_sp_24144 = heff_field(v_a_24140, 1);
        heff_take_n(v_a_24140, 3ULL, 2);
        switch (heff_tag_of(v_x21_24143)) {
        case TAG_MkAlt: {
          V v_p_24145 = heff_field(v_x21_24143, 0);
          V v_b_24146 = heff_field(v_x21_24143, 1);
          heff_take_n(v_x21_24143, 3ULL, 2);
          V v_x1_24147 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_b_24146));
          V v_t_24157;
          switch (heff_tag_of(v_x1_24147)) {
          case TAG_IsInferable: {
            V v_i_24148 = heff_field(v_x1_24147, 0);
            heff_take_n(v_x1_24147, 1ULL, 1);
            V v_t_24151;
            switch (heff_tag_of(v_i_24148)) {
            case TAG_At: {
              V v_s_24150 = heff_dup(heff_field(v_i_24148, 1));
              v_t_24151 = v_s_24150;
              break;
            }
            default: heff_nomatch(v_i_24148);
            }
            v_t_24157 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24148}), v_t_24151});
            break;
          }
          case TAG_IsCheckable: {
            V v_c_24152 = heff_field(v_x1_24147, 0);
            heff_take_n(v_x1_24147, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_240_24At, 2);
            v_t_24157 = v_c_24152;
            break;
          }
          case TAG_IsType: {
            V v_t_24153 = heff_field(v_x1_24147, 0);
            heff_take_n(v_x1_24147, 1ULL, 1);
            V v_t_24156;
            switch (heff_tag_of(v_t_24153)) {
            case TAG_At: {
              V v_s_24155 = heff_dup(heff_field(v_t_24153, 1));
              v_t_24156 = v_s_24155;
              break;
            }
            default: heff_nomatch(v_t_24153);
            }
            v_t_24157 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24153}), v_t_24156});
            break;
          }
          default: heff_nomatch(v_x1_24147);
          }
          v_t_24158 = heff_tag_at_n(v_ru_24x21_241_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_24145, v_t_24157}), v_sp_24144});
          break;
        }
        default: heff_nomatch(v_x21_24143);
        }
        break;
      }
      default: heff_nomatch(v_a_24140);
      }
      V v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_24142, v_t_24158}), v_sp_242});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){v_t_24159});
    }
    case TAG_EDo: {
      V v_stmts_24160 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EDo = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24161 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_24160));
      switch (heff_tag_of(v_t_24161)) {
      case TAG_Nil: {
        V v_t_24162 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str2)}), v_sp_242});
        return heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_IsInferable, 1, (V[]){v_t_24162});
      }
      case TAG_Cons: {
        V v_last_24163 = heff_field(v_t_24161, 0);
        V v_init_24164 = heff_field(v_t_24161, 1);
        heff_take_n(v_t_24161, 3ULL, 2);
        V v_init_24165 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_init_24164));
        V v_t_24174;
        switch (heff_tag_of(v_last_24163)) {
        case TAG_At: {
          V v_x31_24166 = heff_field(v_last_24163, 0);
          heff_take_n(v_last_24163, 1ULL, 2);
          switch (heff_tag_of(v_x31_24166)) {
          case TAG_StmtBind: {
            heff_take_n(v_x31_24166, 0ULL, 3);
            heff_drop_cell(v_ru_24x21_241_24EDo, 1);
            heff_drop(v_init_24165);
            v_t_24174 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtLet: {
            heff_take_n(v_x31_24166, 0ULL, 2);
            heff_drop_cell(v_ru_24x21_241_24EDo, 1);
            heff_drop(v_init_24165);
            v_t_24174 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_StmtExpr: {
            V v_e_24173 = heff_field(v_x31_24166, 0);
            heff_take_n(v_x31_24166, 1ULL, 1);
            v_t_24174 = heff_tag_at_n(v_ru_24x21_241_24EDo, TAG_Just, 1, (V[]){({ V a_0 = heff_dup(v_sp_242); V a_1 = v_init_24165; V a_2 = v_e_24173; V r_ = (g_heff_2esyntax_2epresyntax_2edoFrom(a_0, a_1, a_2)); heff_drop(v_init_24165); r_; })});
            break;
          }
          default: heff_nomatch(v_x31_24166);
          }
          break;
        }
        default: heff_nomatch(v_last_24163);
        }
        switch (heff_tag_of(v_t_24174)) {
        case TAG_Nothing: {
          V v_t_24175 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(12LL), ((V)&g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_str3)}), v_sp_242});
          return heff_tag_n(TAG_IsInferable, 1, (V[]){v_t_24175});
        }
        case TAG_Just: {
          V v_e_27_24176 = heff_field(v_t_24174, 0);
          heff_take_n(v_t_24174, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop_cell(v_ru_24x2_240_24At, 2);
          V t_0 = v_e_27_24176;
          v_x2_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_t_24174);
        }
      }
      default: return heff_nomatch(v_t_24161);
      }
    }
    case TAG_ELocal: {
      V v_body_24177 = heff_field(v_x21_241, 0);
      V v_ds_24178 = heff_field(v_x21_241, 1);
      V v_ru_24x21_241_24ELocal = heff_take_reuse_n(v_x21_241, 3ULL, 2);
      V v_x1_24179 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_24177));
      V v_t_24189;
      switch (heff_tag_of(v_x1_24179)) {
      case TAG_IsInferable: {
        V v_i_24180 = heff_field(v_x1_24179, 0);
        heff_take_n(v_x1_24179, 1ULL, 1);
        V v_t_24183;
        switch (heff_tag_of(v_i_24180)) {
        case TAG_At: {
          V v_s_24182 = heff_dup(heff_field(v_i_24180, 1));
          v_t_24183 = v_s_24182;
          break;
        }
        default: heff_nomatch(v_i_24180);
        }
        v_t_24189 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24180}), v_t_24183});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_24184 = heff_field(v_x1_24179, 0);
        heff_take_n(v_x1_24179, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_24189 = v_c_24184;
        break;
      }
      case TAG_IsType: {
        V v_t_24185 = heff_field(v_x1_24179, 0);
        heff_take_n(v_x1_24179, 1ULL, 1);
        V v_t_24188;
        switch (heff_tag_of(v_t_24185)) {
        case TAG_At: {
          V v_s_24187 = heff_dup(heff_field(v_t_24185, 1));
          v_t_24188 = v_s_24187;
          break;
        }
        default: heff_nomatch(v_t_24185);
        }
        v_t_24189 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_24185}), v_t_24188});
        break;
      }
      default: heff_nomatch(v_x1_24179);
      }
      V v_t_24190 = heff_tag_at_n(v_ru_24x21_241_24ELocal, TAG_CLocal, 2, (V[]){v_t_24189, (g_list_2emap(heff_dup(heff_rfield(g_heff_2esyntax_2epresyntax_2eclassifier_get(), 1)), v_ds_24178))});
      return heff_tag_n(TAG_IsCheckable, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24190, v_sp_242})});
    }
    case TAG_EInvalid: {
      V v_why_24191 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24EInvalid = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_24192 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(3LL), v_why_24191}), v_sp_242});
      return heff_tag_at_n(v_ru_24x21_241_24EInvalid, TAG_IsInferable, 1, (V[]){v_t_24192});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkEquation: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ps_245 = heff_field(v_x21_241, 2);
      V v_rhs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24MkEquation = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_rhs_246));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_c_2412;
        break;
      }
      case TAG_IsType: {
        V v_t_2413 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_dup(heff_field(v_t_2413, 1));
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2413}), v_t_2416});
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24MkEquation, TAG_MkEquation, 4, (V[]){v_f_243, v_fsp_244, v_ps_245, v_t_2417}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eequationOf_24s1632601941x1713253985(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_xsp_244 = heff_field(v_x21_241, 1);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ExplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_246 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_245));
      V v_t_2416;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_IsInferable: {
        V v_i_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2410;
        switch (heff_tag_of(v_i_247)) {
        case TAG_At: {
          V v_s_249 = heff_dup(heff_field(v_i_247, 1));
          v_t_2410 = v_s_249;
          break;
        }
        default: heff_nomatch(v_i_247);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_247}), v_t_2410});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2411 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        V v_t_2414;
        switch (heff_tag_of(v_c_2411)) {
        case TAG_At: {
          V v_s_2413 = heff_dup(heff_field(v_c_2411, 1));
          v_t_2414 = v_s_2413;
          break;
        }
        default: heff_nomatch(v_c_2411);
        }
        v_t_2416 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2411}), v_t_2414});
        break;
      }
      case TAG_IsType: {
        V v_t_2415 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2416 = v_t_2415;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ExplicitParam, TAG_ExplicitParam, 3, (V[]){v_x_243, v_xsp_244, v_t_2416}), v_sp_242});
    }
    case TAG_ImplicitParam: {
      V v_x_2417 = heff_field(v_x21_241, 0);
      V v_xsp_2418 = heff_field(v_x21_241, 1);
      V v_t_2419 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24ImplicitParam = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_2420 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2419));
      V v_t_2430;
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_IsInferable: {
        V v_i_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2424;
        switch (heff_tag_of(v_i_2421)) {
        case TAG_At: {
          V v_s_2423 = heff_dup(heff_field(v_i_2421, 1));
          v_t_2424 = v_s_2423;
          break;
        }
        default: heff_nomatch(v_i_2421);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2421}), v_t_2424});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2425 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        V v_t_2428;
        switch (heff_tag_of(v_c_2425)) {
        case TAG_At: {
          V v_s_2427 = heff_dup(heff_field(v_c_2425, 1));
          v_t_2428 = v_s_2427;
          break;
        }
        default: heff_nomatch(v_c_2425);
        }
        v_t_2430 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2425}), v_t_2428});
        break;
      }
      case TAG_IsType: {
        V v_t_2429 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2430 = v_t_2429;
        break;
      }
      default: heff_nomatch(v_x1_2420);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24ImplicitParam, TAG_ImplicitParam, 3, (V[]){v_x_2417, v_xsp_2418, v_t_2430}), v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_f_243 = heff_field(v_x21_241, 0);
      V v_fsp_244 = heff_field(v_x21_241, 1);
      V v_ty_245 = heff_field(v_x21_241, 2);
      V v_eqs_246 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclEquations = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_x1_247 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_ty_245));
      V v_t_2417;
      switch (heff_tag_of(v_x1_247)) {
      case TAG_IsInferable: {
        V v_i_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2411;
        switch (heff_tag_of(v_i_248)) {
        case TAG_At: {
          V v_s_2410 = heff_dup(heff_field(v_i_248, 1));
          v_t_2411 = v_s_2410;
          break;
        }
        default: heff_nomatch(v_i_248);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_248}), v_t_2411});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2412 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        V v_t_2415;
        switch (heff_tag_of(v_c_2412)) {
        case TAG_At: {
          V v_s_2414 = heff_dup(heff_field(v_c_2412, 1));
          v_t_2415 = v_s_2414;
          break;
        }
        default: heff_nomatch(v_c_2412);
        }
        v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2412}), v_t_2415});
        break;
      }
      case TAG_IsType: {
        V v_t_2416 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2417 = v_t_2416;
        break;
      }
      default: heff_nomatch(v_x1_247);
      }
      V v_t_2418 = heff_tag_at_n(v_ru_24x21_241_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_243, v_fsp_244, v_t_2417, (g_list_2emap_24s2081626528x1476576812(v_eqs_246))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_242});
    }
    case TAG_DeclDefine: {
      V v_x_2419 = heff_field(v_x21_241, 0);
      V v_xsp_2420 = heff_field(v_x21_241, 1);
      V v_ps_2421 = heff_field(v_x21_241, 2);
      V v_u_2422 = heff_field(v_x21_241, 3);
      V v_body_2423 = heff_field(v_x21_241, 4);
      V v_ru_24x21_241_24DeclDefine = heff_take_reuse_n(v_x21_241, 31ULL, 5);
      V v_t_2424 = (g_list_2emap_24s539093115x379698116(v_ps_2421));
      V v_x1_2425 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_u_2422));
      V v_t_2435;
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_IsInferable: {
        V v_i_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        V v_t_2429;
        switch (heff_tag_of(v_i_2426)) {
        case TAG_At: {
          V v_s_2428 = heff_dup(heff_field(v_i_2426, 1));
          v_t_2429 = v_s_2428;
          break;
        }
        default: heff_nomatch(v_i_2426);
        }
        v_t_2435 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2426}), v_t_2429});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2430 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        V v_t_2433;
        switch (heff_tag_of(v_c_2430)) {
        case TAG_At: {
          V v_s_2432 = heff_dup(heff_field(v_c_2430, 1));
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_c_2430);
        }
        v_t_2435 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2430}), v_t_2433});
        break;
      }
      case TAG_IsType: {
        V v_t_2434 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2435 = v_t_2434;
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
      V v_x1_2436 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2423));
      V v_t_2446;
      switch (heff_tag_of(v_x1_2436)) {
      case TAG_IsInferable: {
        V v_i_2437 = heff_field(v_x1_2436, 0);
        V v_ru_24x1_2436_24IsInferable = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
        V v_t_2440;
        switch (heff_tag_of(v_i_2437)) {
        case TAG_At: {
          V v_s_2439 = heff_dup(heff_field(v_i_2437, 1));
          v_t_2440 = v_s_2439;
          break;
        }
        default: heff_nomatch(v_i_2437);
        }
        v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2436_24IsInferable, TAG_CInf, 1, (V[]){v_i_2437}), v_t_2440});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2441 = heff_field(v_x1_2436, 0);
        heff_take_n(v_x1_2436, 1ULL, 1);
        v_t_2446 = v_c_2441;
        break;
      }
      case TAG_IsType: {
        V v_t_2442 = heff_field(v_x1_2436, 0);
        V v_ru_24x1_2436_24IsType = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
        V v_t_2445;
        switch (heff_tag_of(v_t_2442)) {
        case TAG_At: {
          V v_s_2444 = heff_dup(heff_field(v_t_2442, 1));
          v_t_2445 = v_s_2444;
          break;
        }
        default: heff_nomatch(v_t_2442);
        }
        v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2436_24IsType, TAG_CType, 1, (V[]){v_t_2442}), v_t_2445});
        break;
      }
      default: heff_nomatch(v_x1_2436);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_2419, v_xsp_2420, v_t_2424, v_t_2435, v_t_2446}), v_sp_242});
    }
    case TAG_DeclTheory: {
      V v_x_2447 = heff_field(v_x21_241, 0);
      V v_xsp_2448 = heff_field(v_x21_241, 1);
      V v_ps_2449 = heff_field(v_x21_241, 2);
      V v_body_2450 = heff_field(v_x21_241, 3);
      V v_ru_24x21_241_24DeclTheory = heff_take_reuse_n(v_x21_241, 15ULL, 4);
      V v_t_2451 = (g_list_2emap_24s539093115x379698116(v_ps_2449));
      V v_x1_2452 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_body_2450));
      V v_t_2462;
      switch (heff_tag_of(v_x1_2452)) {
      case TAG_IsInferable: {
        V v_i_2453 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        V v_t_2456;
        switch (heff_tag_of(v_i_2453)) {
        case TAG_At: {
          V v_s_2455 = heff_dup(heff_field(v_i_2453, 1));
          v_t_2456 = v_s_2455;
          break;
        }
        default: heff_nomatch(v_i_2453);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2453}), v_t_2456});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2457 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2462 = v_c_2457;
        break;
      }
      case TAG_IsType: {
        V v_t_2458 = heff_field(v_x1_2452, 0);
        heff_take_n(v_x1_2452, 1ULL, 1);
        V v_t_2461;
        switch (heff_tag_of(v_t_2458)) {
        case TAG_At: {
          V v_s_2460 = heff_dup(heff_field(v_t_2458, 1));
          v_t_2461 = v_s_2460;
          break;
        }
        default: heff_nomatch(v_t_2458);
        }
        v_t_2462 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2458}), v_t_2461});
        break;
      }
      default: heff_nomatch(v_x1_2452);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2447, v_xsp_2448, v_t_2451, v_t_2462}), v_sp_242});
    }
    case TAG_DeclPrimitive: {
      V v_x_2463 = heff_field(v_x21_241, 0);
      V v_xsp_2464 = heff_field(v_x21_241, 1);
      V v_t_2465 = heff_field(v_x21_241, 2);
      V v_ru_24x21_241_24DeclPrimitive = heff_take_reuse_n(v_x21_241, 7ULL, 3);
      V v_x1_2466 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_t_2465));
      V v_t_2476;
      switch (heff_tag_of(v_x1_2466)) {
      case TAG_IsInferable: {
        V v_i_2467 = heff_field(v_x1_2466, 0);
        heff_take_n(v_x1_2466, 1ULL, 1);
        V v_t_2470;
        switch (heff_tag_of(v_i_2467)) {
        case TAG_At: {
          V v_s_2469 = heff_dup(heff_field(v_i_2467, 1));
          v_t_2470 = v_s_2469;
          break;
        }
        default: heff_nomatch(v_i_2467);
        }
        v_t_2476 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_i_2467}), v_t_2470});
        break;
      }
      case TAG_IsCheckable: {
        V v_c_2471 = heff_field(v_x1_2466, 0);
        heff_take_n(v_x1_2466, 1ULL, 1);
        V v_t_2474;
        switch (heff_tag_of(v_c_2471)) {
        case TAG_At: {
          V v_s_2473 = heff_dup(heff_field(v_c_2471, 1));
          v_t_2474 = v_s_2473;
          break;
        }
        default: heff_nomatch(v_c_2471);
        }
        v_t_2476 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_c_2471}), v_t_2474});
        break;
      }
      case TAG_IsType: {
        V v_t_2475 = heff_field(v_x1_2466, 0);
        heff_take_n(v_x1_2466, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24At, 2);
        v_t_2476 = v_t_2475;
        break;
      }
      default: heff_nomatch(v_x1_2466);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_241_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2463, v_xsp_2464, v_t_2476}), v_sp_242});
    }
    case TAG_DeclTest: {
      V v_x_2477 = heff_field(v_x21_241, 0);
      V v_xsp_2478 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclTest, 2, (V[]){v_x_2477, v_xsp_2478}), v_sp_242});
    }
    case TAG_DeclWatch: {
      V v_e_2479 = heff_field(v_x21_241, 0);
      V v_ru_24x21_241_24DeclWatch = heff_take_reuse_n(v_x21_241, 1ULL, 1);
      V v_t_2480 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_e_2479));
      V v_t_2481 = heff_tag_at_n(v_ru_24x21_241_24DeclWatch, TAG_DeclWatch, 1, (V[]){(g_heff_2esyntax_2epresyntax_2ewatchOf(v_t_2480))});
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_At, 2, (V[]){v_t_2481, v_sp_242});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173(a[0]);
}

static V g_heff_2esyntax_2epresyntax_2eclassify_val;
static HEFF_ONCE g_heff_2esyntax_2epresyntax_2eclassify_st;
static V g_heff_2esyntax_2epresyntax_2eclassify_init(void) {
  return ((V)&g_heff_2esyntax_2epresyntax_2eclassifyDeclF_24s318081522x207620173_clo);
}
V g_heff_2esyntax_2epresyntax_2eclassify_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epresyntax_2eclassify_st)) return g_heff_2esyntax_2epresyntax_2eclassify_val;
  return heff_global(&g_heff_2esyntax_2epresyntax_2eclassify_val, &g_heff_2esyntax_2epresyntax_2eclassify_st, g_heff_2esyntax_2epresyntax_2eclassify_init);
}
Clo g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24PiNamed = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_246;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_t_243, 0);
      V v_sp_245 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiNamed, TAG_PiNamed, 3, (V[]){v_x_241, v_sp_242, v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_240, 0);
    V v_sp_248 = heff_field(v_x2_240, 1);
    V v_sp2_249 = heff_field(v_x2_240, 2);
    V v_t_2410 = heff_field(v_x2_240, 3);
    V v_d_2411 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24PiImplicit = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_At: {
      V v_n_2412 = heff_field(v_t_2410, 0);
      V v_sp_2413 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2413, v_n_2412));
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2420;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2415 = heff_field(v_d_2411, 0);
      V v_ru_24d_2411_24Just = heff_take_reuse_n(v_d_2411, 1ULL, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2415)) {
      case TAG_At: {
        V v_n_2416 = heff_field(v_x_2415, 0);
        V v_sp_2417 = heff_field(v_x_2415, 1);
        V v_ru_24x_2415_24At = heff_take_reuse_n(v_x_2415, 3ULL, 2);
        V v_t_2418 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2416));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2415_24At, TAG_At, 2, (V[]){v_t_2418, v_sp_2417});
        break;
      }
      default: heff_nomatch(v_x_2415);
      }
      v_t_2420 = heff_tag_at_n(v_ru_24d_2411_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_x_247, v_sp_248, v_sp2_249, v_t_2414, v_t_2420});
  }
  case TAG_PiInstance: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_sp2_2423 = heff_field(v_x2_240, 2);
    V v_t_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24PiInstance = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_t_2424, 0);
      V v_sp_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2426, v_n_2425));
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiInstance, TAG_PiInstance, 4, (V[]){v_x_2421, v_sp_2422, v_sp2_2423, v_t_2427});
  }
  case TAG_PiAnon: {
    V v_t_2428 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24PiAnon = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2431;
    switch (heff_tag_of(v_t_2428)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_t_2428, 0);
      V v_sp_2430 = heff_field(v_t_2428, 1);
      heff_take_n(v_t_2428, 3ULL, 2);
      v_t_2431 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2430, v_n_2429));
      break;
    }
    default: heff_nomatch(v_t_2428);
    }
    return heff_tag_at_n(v_ru_24x2_240_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2431});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclareField: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_field(v_x2_240, 2);
    V v_d_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclareField = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_t_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_t_243, 0);
      V v_sp_246 = heff_field(v_t_243, 1);
      heff_take_n(v_t_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_t_243);
    }
    V v_t_2413;
    switch (heff_tag_of(v_d_244)) {
    case TAG_Nothing: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_d_244, 0);
      V v_ru_24d_244_24Just = heff_take_reuse_n(v_d_244, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_x_248)) {
      case TAG_At: {
        V v_n_249 = heff_field(v_x_248, 0);
        V v_sp_2410 = heff_field(v_x_248, 1);
        V v_ru_24x_248_24At = heff_take_reuse_n(v_x_248, 3ULL, 2);
        V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_249));
        v_t_2412 = heff_tag_at_n(v_ru_24x_248_24At, TAG_At, 2, (V[]){v_t_2411, v_sp_2410});
        break;
      }
      default: heff_nomatch(v_x_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24d_244_24Just, TAG_Just, 1, (V[]){v_t_2412});
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclareField, TAG_DeclareField, 4, (V[]){v_x_241, v_sp_242, v_t_247, v_t_2413});
  }
  case TAG_BadFieldDecl: {
    V v_e_2414 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24BadFieldDecl = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_e_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_e_2414, 0);
      V v_sp_2416 = heff_field(v_e_2414, 1);
      heff_take_n(v_e_2414, 3ULL, 2);
      v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2416, v_n_2415));
      break;
    }
    default: heff_nomatch(v_e_2414);
    }
    return heff_tag_at_n(v_ru_24x2_240_24BadFieldDecl, TAG_BadFieldDecl, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2efieldDeclN_24s78434380x884811319(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_TPi: {
    V v_b_241 = heff_field(v_n_240, 0);
    V v_cod_242 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24TPi = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2epiN_24s1050215381x343292346(v_b_241));
    V v_t_246;
    switch (heff_tag_of(v_cod_242)) {
    case TAG_At: {
      V v_n_244 = heff_field(v_cod_242, 0);
      V v_sp_245 = heff_field(v_cod_242, 1);
      heff_take_n(v_cod_242, 3ULL, 2);
      v_t_246 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_245, v_n_244));
      break;
    }
    default: heff_nomatch(v_cod_242);
    }
    return heff_tag_at_n(v_ru_24n_240_24TPi, TAG_TPi, 2, (V[]){v_t_243, v_t_246});
  }
  case TAG_TSig: {
    V v_fs_247 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSig = heff_take_reuse_n(v_n_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24n_240_24TSig, TAG_TSig, 1, (V[]){(g_list_2emap_24s1992667171x110340492(v_fs_247))});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TSum = heff_take_reuse_n(v_n_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24n_240_24TSum, TAG_TSum, 1, (V[]){(g_list_2emap_24s513391942x823299088(v_vs_248))});
  }
  case TAG_TType: {
    return v_n_240;
  }
  case TAG_TInt: {
    return v_n_240;
  }
  case TAG_TFloat: {
    return v_n_240;
  }
  case TAG_TString: {
    return v_n_240;
  }
  case TAG_TRune: {
    return v_n_240;
  }
  case TAG_TArray: {
    V v_a_249 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TArray = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_a_249)) {
    case TAG_At: {
      V v_n_2410 = heff_field(v_a_249, 0);
      V v_sp_2411 = heff_field(v_a_249, 1);
      heff_take_n(v_a_249, 3ULL, 2);
      v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2411, v_n_2410));
      break;
    }
    default: heff_nomatch(v_a_249);
    }
    return heff_tag_at_n(v_ru_24n_240_24TArray, TAG_TArray, 1, (V[]){v_t_2412});
  }
  case TAG_TFixed: {
    return v_n_240;
  }
  case TAG_TInf: {
    V v_i_2414 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_i_2414)) {
    case TAG_At: {
      V v_n_2415 = heff_field(v_i_2414, 0);
      V v_sp_2416 = heff_field(v_i_2414, 1);
      V v_ru_24i_2414_24At = heff_take_reuse_n(v_i_2414, 3ULL, 2);
      V v_t_2417 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2415));
      v_t_2418 = heff_tag_at_n(v_ru_24i_2414_24At, TAG_At, 2, (V[]){v_t_2417, v_sp_2416});
      break;
    }
    default: heff_nomatch(v_i_2414);
    }
    return heff_tag_at_n(v_ru_24n_240_24TInf, TAG_TInf, 1, (V[]){v_t_2418});
  }
  case TAG_TChk: {
    V v_c_2419 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24TChk = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_c_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_c_2419, 0);
      V v_sp_2421 = heff_field(v_c_2419, 1);
      V v_ru_24c_2419_24At = heff_take_reuse_n(v_c_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24c_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_c_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24TChk, TAG_TChk, 1, (V[]){v_t_2423});
  }
  case TAG_TNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0, 49, "cannot use descriptive syntax in nominal position");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1, 49, "cannot use descriptive syntax in nominal position");
Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_TSig: {
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str0)}), heff_dup(v_sp_240)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TInf, 1, (V[]){v_t_246}), v_sp_240});
  }
  case TAG_TSum: {
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 0ULL, 1);
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){MK_INT(4LL), ((V)&g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_str1)}), heff_dup(v_sp_240)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TInf, 1, (V[]){v_t_248}), v_sp_240});
  }
  case TAG_TType: {
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2411 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2413 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2417 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TInf: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TChk: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2423 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_IVar: {
    return v_n_240;
  }
  case TAG_IInt: {
    return v_n_240;
  }
  case TAG_IFloat: {
    return v_n_240;
  }
  case TAG_IString: {
    return v_n_240;
  }
  case TAG_IRune: {
    return v_n_240;
  }
  case TAG_IApp: {
    V v_h_246 = heff_field(v_n_240, 0);
    V v_args_247 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IApp = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_h_246)) {
    case TAG_At: {
      V v_n_248 = heff_field(v_h_246, 0);
      V v_sp_249 = heff_field(v_h_246, 1);
      heff_take_n(v_h_246, 3ULL, 2);
      V v_t_2410 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_248));
      v_t_2411 = heff_tag_at_n(v_ru_24n_240_24IApp, TAG_At, 2, (V[]){v_t_2410, v_sp_249});
      break;
    }
    default: heff_nomatch(v_h_246);
    }
    return heff_tag_n(TAG_IApp, 2, (V[]){v_t_2411, (g_list_2emap_24s1150457979x1978067071(v_args_247))});
  }
  case TAG_IAnn: {
    V v_c_2412 = heff_field(v_n_240, 0);
    V v_t_2413 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24IAnn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_c_2412)) {
    case TAG_At: {
      V v_n_2414 = heff_field(v_c_2412, 0);
      V v_sp_2415 = heff_field(v_c_2412, 1);
      heff_take_n(v_c_2412, 3ULL, 2);
      V v_t_2416 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2414));
      v_t_2417 = heff_tag_at_n(v_ru_24n_240_24IAnn, TAG_At, 2, (V[]){v_t_2416, v_sp_2415});
      break;
    }
    default: heff_nomatch(v_c_2412);
    }
    V v_t_2420;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_At: {
      V v_n_2418 = heff_field(v_t_2413, 0);
      V v_sp_2419 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 3ULL, 2);
      v_t_2420 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2419, v_n_2418));
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    return heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2417, v_t_2420});
  }
  case TAG_ISpec: {
    V v_a_2421 = heff_field(v_n_240, 0);
    V v_x_2422 = heff_field(v_n_240, 1);
    V v_sp_2423 = heff_field(v_n_240, 2);
    V v_v_2424 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ISpec = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2428;
    switch (heff_tag_of(v_a_2421)) {
    case TAG_At: {
      V v_n_2425 = heff_field(v_a_2421, 0);
      V v_sp_2426 = heff_field(v_a_2421, 1);
      V v_ru_24a_2421_24At = heff_take_reuse_n(v_a_2421, 3ULL, 2);
      V v_t_2427 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2425));
      v_t_2428 = heff_tag_at_n(v_ru_24a_2421_24At, TAG_At, 2, (V[]){v_t_2427, v_sp_2426});
      break;
    }
    default: heff_nomatch(v_a_2421);
    }
    V v_t_2432;
    switch (heff_tag_of(v_v_2424)) {
    case TAG_At: {
      V v_n_2429 = heff_field(v_v_2424, 0);
      V v_sp_2430 = heff_field(v_v_2424, 1);
      V v_ru_24v_2424_24At = heff_take_reuse_n(v_v_2424, 3ULL, 2);
      V v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2429));
      v_t_2432 = heff_tag_at_n(v_ru_24v_2424_24At, TAG_At, 2, (V[]){v_t_2431, v_sp_2430});
      break;
    }
    default: heff_nomatch(v_v_2424);
    }
    return heff_tag_at_n(v_ru_24n_240_24ISpec, TAG_ISpec, 4, (V[]){v_t_2428, v_x_2422, v_sp_2423, v_t_2432});
  }
  case TAG_IAnnLam: {
    V v_x_2433 = heff_field(v_n_240, 0);
    V v_sp_2434 = heff_field(v_n_240, 1);
    V v_t_2435 = heff_field(v_n_240, 2);
    V v_b_2436 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24IAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2439;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_At: {
      V v_n_2437 = heff_field(v_t_2435, 0);
      V v_sp_2438 = heff_field(v_t_2435, 1);
      heff_take_n(v_t_2435, 3ULL, 2);
      v_t_2439 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2438, v_n_2437));
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    V v_t_2443;
    switch (heff_tag_of(v_b_2436)) {
    case TAG_At: {
      V v_n_2440 = heff_field(v_b_2436, 0);
      V v_sp_2441 = heff_field(v_b_2436, 1);
      V v_ru_24b_2436_24At = heff_take_reuse_n(v_b_2436, 3ULL, 2);
      V v_t_2442 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2440));
      v_t_2443 = heff_tag_at_n(v_ru_24b_2436_24At, TAG_At, 2, (V[]){v_t_2442, v_sp_2441});
      break;
    }
    default: heff_nomatch(v_b_2436);
    }
    return heff_tag_at_n(v_ru_24n_240_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_x_2433, v_sp_2434, v_t_2439, v_t_2443});
  }
  case TAG_IInvalid: {
    return v_n_240;
  }
  case TAG_INominal: {
    return v_n_240;
  }
  case TAG_ILitEq: {
    V v_x_2447 = heff_field(v_n_240, 0);
    V v_sp_2448 = heff_field(v_n_240, 1);
    V v_eq_2449 = heff_field(v_n_240, 2);
    V v_lit_2450 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24ILitEq = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2454;
    switch (heff_tag_of(v_lit_2450)) {
    case TAG_At: {
      V v_n_2451 = heff_field(v_lit_2450, 0);
      V v_sp_2452 = heff_field(v_lit_2450, 1);
      V v_ru_24lit_2450_24At = heff_take_reuse_n(v_lit_2450, 3ULL, 2);
      V v_t_2453 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2451));
      v_t_2454 = heff_tag_at_n(v_ru_24lit_2450_24At, TAG_At, 2, (V[]){v_t_2453, v_sp_2452});
      break;
    }
    default: heff_nomatch(v_lit_2450);
    }
    return heff_tag_at_n(v_ru_24n_240_24ILitEq, TAG_ILitEq, 4, (V[]){v_x_2447, v_sp_2448, v_eq_2449, v_t_2454});
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_DeclEquations: {
    V v_f_241 = heff_field(v_x2_240, 0);
    V v_sp_242 = heff_field(v_x2_240, 1);
    V v_ty_243 = heff_field(v_x2_240, 2);
    V v_eqs_244 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclEquations = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_247;
    switch (heff_tag_of(v_ty_243)) {
    case TAG_At: {
      V v_n_245 = heff_field(v_ty_243, 0);
      V v_sp_246 = heff_field(v_ty_243, 1);
      heff_take_n(v_ty_243, 3ULL, 2);
      v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_246, v_n_245));
      break;
    }
    default: heff_nomatch(v_ty_243);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclEquations, TAG_DeclEquations, 4, (V[]){v_f_241, v_sp_242, v_t_247, (g_list_2emap_24s1782778565x402128078(v_eqs_244))});
  }
  case TAG_DeclDefine: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_249 = heff_field(v_x2_240, 1);
    V v_ps_2410 = heff_field(v_x2_240, 2);
    V v_u_2411 = heff_field(v_x2_240, 3);
    V v_body_2412 = heff_field(v_x2_240, 4);
    V v_ru_24x2_240_24DeclDefine = heff_take_reuse_n(v_x2_240, 31ULL, 5);
    V v_t_2413 = (g_list_2emap_24s474585387x1072098790(v_ps_2410));
    V v_t_2416;
    switch (heff_tag_of(v_u_2411)) {
    case TAG_At: {
      V v_n_2414 = heff_field(v_u_2411, 0);
      V v_sp_2415 = heff_field(v_u_2411, 1);
      heff_take_n(v_u_2411, 3ULL, 2);
      v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2415, v_n_2414));
      break;
    }
    default: heff_nomatch(v_u_2411);
    }
    V v_t_2420;
    switch (heff_tag_of(v_body_2412)) {
    case TAG_At: {
      V v_n_2417 = heff_field(v_body_2412, 0);
      V v_sp_2418 = heff_field(v_body_2412, 1);
      V v_ru_24body_2412_24At = heff_take_reuse_n(v_body_2412, 3ULL, 2);
      V v_t_2419 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2417));
      v_t_2420 = heff_tag_at_n(v_ru_24body_2412_24At, TAG_At, 2, (V[]){v_t_2419, v_sp_2418});
      break;
    }
    default: heff_nomatch(v_body_2412);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_x_248, v_sp_249, v_t_2413, v_t_2416, v_t_2420});
  }
  case TAG_DeclTheory: {
    V v_x_2421 = heff_field(v_x2_240, 0);
    V v_sp_2422 = heff_field(v_x2_240, 1);
    V v_ps_2423 = heff_field(v_x2_240, 2);
    V v_body_2424 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24DeclTheory = heff_take_reuse_n(v_x2_240, 15ULL, 4);
    V v_t_2425 = (g_list_2emap_24s474585387x1072098790(v_ps_2423));
    V v_t_2429;
    switch (heff_tag_of(v_body_2424)) {
    case TAG_At: {
      V v_n_2426 = heff_field(v_body_2424, 0);
      V v_sp_2427 = heff_field(v_body_2424, 1);
      V v_ru_24body_2424_24At = heff_take_reuse_n(v_body_2424, 3ULL, 2);
      V v_t_2428 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2426));
      v_t_2429 = heff_tag_at_n(v_ru_24body_2424_24At, TAG_At, 2, (V[]){v_t_2428, v_sp_2427});
      break;
    }
    default: heff_nomatch(v_body_2424);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_x_2421, v_sp_2422, v_t_2425, v_t_2429});
  }
  case TAG_DeclPrimitive: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2431 = heff_field(v_x2_240, 1);
    V v_t_2432 = heff_field(v_x2_240, 2);
    V v_ru_24x2_240_24DeclPrimitive = heff_take_reuse_n(v_x2_240, 7ULL, 3);
    V v_t_2435;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_At: {
      V v_n_2433 = heff_field(v_t_2432, 0);
      V v_sp_2434 = heff_field(v_t_2432, 1);
      heff_take_n(v_t_2432, 3ULL, 2);
      v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2434, v_n_2433));
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_x_2430, v_sp_2431, v_t_2435});
  }
  case TAG_DeclTest: {
    V v_x_2436 = heff_field(v_x2_240, 0);
    V v_sp_2437 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24DeclTest = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_240_24DeclTest, TAG_DeclTest, 2, (V[]){v_x_2436, v_sp_2437});
  }
  case TAG_DeclWatch: {
    V v_c_2438 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24DeclWatch = heff_take_reuse_n(v_x2_240, 1ULL, 1);
    V v_t_2442;
    switch (heff_tag_of(v_c_2438)) {
    case TAG_At: {
      V v_n_2439 = heff_field(v_c_2438, 0);
      V v_sp_2440 = heff_field(v_c_2438, 1);
      V v_ru_24c_2438_24At = heff_take_reuse_n(v_c_2438, 3ULL, 2);
      V v_t_2441 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2439));
      v_t_2442 = heff_tag_at_n(v_ru_24c_2438_24At, TAG_At, 2, (V[]){v_t_2441, v_sp_2440});
      break;
    }
    default: heff_nomatch(v_c_2438);
    }
    return heff_tag_at_n(v_ru_24x2_240_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_2442});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_CInf: {
    V v_i_241 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CInf = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_241)) {
    case TAG_At: {
      V v_n_242 = heff_field(v_i_241, 0);
      V v_sp_243 = heff_field(v_i_241, 1);
      V v_ru_24i_241_24At = heff_take_reuse_n(v_i_241, 3ULL, 2);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_242));
      v_t_245 = heff_tag_at_n(v_ru_24i_241_24At, TAG_At, 2, (V[]){v_t_244, v_sp_243});
      break;
    }
    default: heff_nomatch(v_i_241);
    }
    return heff_tag_at_n(v_ru_24n_240_24CInf, TAG_CInf, 1, (V[]){v_t_245});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CType = heff_take_reuse_n(v_n_240, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24n_240_24CType, TAG_CType, 1, (V[]){v_t_249});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_240, 0);
    V v_sp_2411 = heff_field(v_n_240, 1);
    V v_b_2412 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2416;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24At = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2413));
      v_t_2416 = heff_tag_at_n(v_ru_24b_2412_24At, TAG_At, 2, (V[]){v_t_2415, v_sp_2414});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24n_240_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_sp_2411, v_t_2416});
  }
  case TAG_CImplicitLam: {
    V v_x_2417 = heff_field(v_n_240, 0);
    V v_sp_2418 = heff_field(v_n_240, 1);
    V v_b_2419 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CImplicitLam = heff_take_reuse_n(v_n_240, 7ULL, 3);
    V v_t_2423;
    switch (heff_tag_of(v_b_2419)) {
    case TAG_At: {
      V v_n_2420 = heff_field(v_b_2419, 0);
      V v_sp_2421 = heff_field(v_b_2419, 1);
      V v_ru_24b_2419_24At = heff_take_reuse_n(v_b_2419, 3ULL, 2);
      V v_t_2422 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2420));
      v_t_2423 = heff_tag_at_n(v_ru_24b_2419_24At, TAG_At, 2, (V[]){v_t_2422, v_sp_2421});
      break;
    }
    default: heff_nomatch(v_b_2419);
    }
    return heff_tag_at_n(v_ru_24n_240_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2417, v_sp_2418, v_t_2423});
  }
  case TAG_CAnnLam: {
    V v_x_2424 = heff_field(v_n_240, 0);
    V v_sp_2425 = heff_field(v_n_240, 1);
    V v_t_2426 = heff_field(v_n_240, 2);
    V v_b_2427 = heff_field(v_n_240, 3);
    V v_ru_24n_240_24CAnnLam = heff_take_reuse_n(v_n_240, 15ULL, 4);
    V v_t_2430;
    switch (heff_tag_of(v_t_2426)) {
    case TAG_At: {
      V v_n_2428 = heff_field(v_t_2426, 0);
      V v_sp_2429 = heff_field(v_t_2426, 1);
      heff_take_n(v_t_2426, 3ULL, 2);
      v_t_2430 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2429, v_n_2428));
      break;
    }
    default: heff_nomatch(v_t_2426);
    }
    V v_t_2434;
    switch (heff_tag_of(v_b_2427)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_b_2427, 0);
      V v_sp_2432 = heff_field(v_b_2427, 1);
      V v_ru_24b_2427_24At = heff_take_reuse_n(v_b_2427, 3ULL, 2);
      V v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2431));
      v_t_2434 = heff_tag_at_n(v_ru_24b_2427_24At, TAG_At, 2, (V[]){v_t_2433, v_sp_2432});
      break;
    }
    default: heff_nomatch(v_b_2427);
    }
    return heff_tag_at_n(v_ru_24n_240_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_x_2424, v_sp_2425, v_t_2430, v_t_2434});
  }
  case TAG_CTag: {
    V v_x_2435 = heff_field(v_n_240, 0);
    V v_sp_2436 = heff_field(v_n_240, 1);
    V v_args_2437 = heff_field(v_n_240, 2);
    V v_ru_24n_240_24CTag = heff_take_reuse_n(v_n_240, 7ULL, 3);
    return heff_tag_at_n(v_ru_24n_240_24CTag, TAG_CTag, 3, (V[]){v_x_2435, v_sp_2436, (g_list_2emap_24s79542405x478516404(v_args_2437))});
  }
  case TAG_CStruct: {
    V v_fs_2438 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24CStruct = heff_take_reuse_n(v_n_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24n_240_24CStruct, TAG_CStruct, 1, (V[]){(g_list_2emap_24s1729787689x465380098(v_fs_2438))});
  }
  case TAG_CMatch: {
    V v_sc_2439 = heff_field(v_n_240, 0);
    V v_alts_2440 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CMatch = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2444;
    switch (heff_tag_of(v_sc_2439)) {
    case TAG_At: {
      V v_n_2441 = heff_field(v_sc_2439, 0);
      V v_sp_2442 = heff_field(v_sc_2439, 1);
      heff_take_n(v_sc_2439, 3ULL, 2);
      V v_t_2443 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2441));
      v_t_2444 = heff_tag_at_n(v_ru_24n_240_24CMatch, TAG_At, 2, (V[]){v_t_2443, v_sp_2442});
      break;
    }
    default: heff_nomatch(v_sc_2439);
    }
    return heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2444, (g_list_2emap_24s244350250x1728178626(v_alts_2440))});
  }
  case TAG_CLetIn: {
    V v_rhs_2445 = heff_field(v_n_240, 0);
    V v_alt_2446 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLetIn = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2450;
    switch (heff_tag_of(v_rhs_2445)) {
    case TAG_At: {
      V v_n_2447 = heff_field(v_rhs_2445, 0);
      V v_sp_2448 = heff_field(v_rhs_2445, 1);
      heff_take_n(v_rhs_2445, 3ULL, 2);
      V v_t_2449 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_2447));
      v_t_2450 = heff_tag_at_n(v_ru_24n_240_24CLetIn, TAG_At, 2, (V[]){v_t_2449, v_sp_2448});
      break;
    }
    default: heff_nomatch(v_rhs_2445);
    }
    V v_t_2460;
    switch (heff_tag_of(v_alt_2446)) {
    case TAG_At: {
      V v_x_2451 = heff_field(v_alt_2446, 0);
      V v_sp_2452 = heff_field(v_alt_2446, 1);
      V v_ru_24alt_2446_24At = heff_take_reuse_n(v_alt_2446, 3ULL, 2);
      V v_t_2459;
      switch (heff_tag_of(v_x_2451)) {
      case TAG_MkAlt: {
        V v_p_2453 = heff_field(v_x_2451, 0);
        V v_b_2454 = heff_field(v_x_2451, 1);
        V v_ru_24x_2451_24MkAlt = heff_take_reuse_n(v_x_2451, 3ULL, 2);
        V v_t_2458;
        switch (heff_tag_of(v_b_2454)) {
        case TAG_At: {
          V v_n_2455 = heff_field(v_b_2454, 0);
          V v_sp_2456 = heff_field(v_b_2454, 1);
          heff_take_n(v_b_2454, 3ULL, 2);
          V v_t_2457 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2455));
          v_t_2458 = heff_tag_at_n(v_ru_24alt_2446_24At, TAG_At, 2, (V[]){v_t_2457, v_sp_2456});
          break;
        }
        default: heff_nomatch(v_b_2454);
        }
        v_t_2459 = heff_tag_at_n(v_ru_24x_2451_24MkAlt, TAG_MkAlt, 2, (V[]){v_p_2453, v_t_2458});
        break;
      }
      default: heff_nomatch(v_x_2451);
      }
      v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){v_t_2459, v_sp_2452});
      break;
    }
    default: heff_nomatch(v_alt_2446);
    }
    return heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_2450, v_t_2460});
  }
  case TAG_CLocal: {
    V v_body_2461 = heff_field(v_n_240, 0);
    V v_ds_2462 = heff_field(v_n_240, 1);
    V v_ru_24n_240_24CLocal = heff_take_reuse_n(v_n_240, 3ULL, 2);
    V v_t_2466;
    switch (heff_tag_of(v_body_2461)) {
    case TAG_At: {
      V v_n_2463 = heff_field(v_body_2461, 0);
      V v_sp_2464 = heff_field(v_body_2461, 1);
      heff_take_n(v_body_2461, 3ULL, 2);
      V v_t_2465 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_2463));
      v_t_2466 = heff_tag_at_n(v_ru_24n_240_24CLocal, TAG_At, 2, (V[]){v_t_2465, v_sp_2464});
      break;
    }
    default: heff_nomatch(v_body_2461);
    }
    return heff_tag_n(TAG_CLocal, 2, (V[]){v_t_2466, (g_list_2emap_24s386875578x1005587669(v_ds_2462))});
  }
  case TAG_CAbandon: {
    return v_n_240;
  }
  case TAG_CNominal: {
    return v_n_240;
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(a[0]);
}
Clo g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_IVar: {
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_244 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_243, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_244, v_sp_240});
  }
  case TAG_IInt: {
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_247 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_IFloat: {
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2410 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_240});
  }
  case TAG_IString: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_IRune: {
    V v_t_2415 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2416 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2416, v_sp_240});
  }
  case TAG_IApp: {
    V v_t_2419 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2420 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_240});
  }
  case TAG_IAnn: {
    V v_c_2421 = heff_field(v_n_241, 0);
    V v_t_2422 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IAnn = heff_take_reuse_n(v_n_241, 3ULL, 2);
    V v_t_2425;
    switch (heff_tag_of(v_c_2421)) {
    case TAG_At: {
      V v_n_2423 = heff_field(v_c_2421, 0);
      V v_sp_2424 = heff_field(v_c_2421, 1);
      heff_take_n(v_c_2421, 3ULL, 2);
      v_t_2425 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2424, v_n_2423));
      break;
    }
    default: heff_nomatch(v_c_2421);
    }
    V v_t_2428;
    switch (heff_tag_of(v_t_2422)) {
    case TAG_At: {
      V v_n_2426 = heff_field(v_t_2422, 0);
      V v_sp_2427 = heff_field(v_t_2422, 1);
      heff_take_n(v_t_2422, 3ULL, 2);
      v_t_2428 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2427, v_n_2426));
      break;
    }
    default: heff_nomatch(v_t_2422);
    }
    return heff_tag_at_n(v_ru_24n_241_24IAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2425, v_t_2428}), v_sp_240});
  }
  case TAG_ISpec: {
    V v_t_2433 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2434 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_sp_240});
  }
  case TAG_IAnnLam: {
    V v_t_2439 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2440 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_sp_240});
  }
  case TAG_IInvalid: {
    V v_code_2441 = heff_field(v_n_241, 0);
    V v_why_2442 = heff_field(v_n_241, 1);
    V v_ru_24n_241_24IInvalid = heff_take_reuse_n(v_n_241, 3ULL, 2);
    return heff_tag_at_n(v_ru_24n_241_24IInvalid, TAG_At, 2, (V[]){heff_tag_n(TAG_IInvalid, 2, (V[]){v_code_2441, v_why_2442}), v_sp_240});
  }
  case TAG_INominal: {
    V v_t_2444 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2445 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_sp_240});
  }
  case TAG_ILitEq: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2einfNode_24s1344112722x1353674805(v_n_241));
    V v_t_2451 = heff_tag_n(TAG_INominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_TPi: {
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_245 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_240});
  }
  case TAG_TSig: {
    V v_fs_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSig = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSig, TAG_TSig, 1, (V[]){v_fs_246})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_247, v_sp_240});
  }
  case TAG_TSum: {
    V v_vs_248 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TSum = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(heff_tag_at_n(v_ru_24n_241_24TSum, TAG_TSum, 1, (V[]){v_vs_248})));
    return heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_240});
  }
  case TAG_TType: {
    V v_t_2410 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2411 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2411, v_sp_240});
  }
  case TAG_TInt: {
    V v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2413 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_sp_240});
  }
  case TAG_TFloat: {
    V v_t_2414 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2415 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_sp_240});
  }
  case TAG_TString: {
    V v_t_2416 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2417 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2416, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_sp_240});
  }
  case TAG_TRune: {
    V v_t_2418 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2419 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_sp_240});
  }
  case TAG_TArray: {
    V v_t_2421 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2422 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_sp_240});
  }
  case TAG_TFixed: {
    V v_t_2424 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2425 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_240});
  }
  case TAG_TInf: {
    V v_i_2426 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2429;
    switch (heff_tag_of(v_i_2426)) {
    case TAG_At: {
      V v_n_2427 = heff_field(v_i_2426, 0);
      V v_sp_2428 = heff_field(v_i_2426, 1);
      heff_take_n(v_i_2426, 3ULL, 2);
      v_t_2429 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_2428, v_n_2427));
      break;
    }
    default: heff_nomatch(v_i_2426);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TInf, TAG_TInf, 1, (V[]){v_t_2429}), v_sp_240});
  }
  case TAG_TChk: {
    V v_c_2430 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24TChk = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_c_2430)) {
    case TAG_At: {
      V v_n_2431 = heff_field(v_c_2430, 0);
      V v_sp_2432 = heff_field(v_c_2430, 1);
      heff_take_n(v_c_2430, 3ULL, 2);
      v_t_2433 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2432, v_n_2431));
      break;
    }
    default: heff_nomatch(v_c_2430);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24TChk, TAG_TChk, 1, (V[]){v_t_2433}), v_sp_240});
  }
  case TAG_TNominal: {
    V v_t_2435 = (g_heff_2esyntax_2epresyntax_2etypNode_24s400326218x777864799(v_n_241));
    V v_t_2436 = heff_tag_n(TAG_TNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2435, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2436, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(a[0], a[1]);
}
Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V v_sp_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_CInf: {
    V v_i_242 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CInf = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_245;
    switch (heff_tag_of(v_i_242)) {
    case TAG_At: {
      V v_n_243 = heff_field(v_i_242, 0);
      V v_sp_244 = heff_field(v_i_242, 1);
      heff_take_n(v_i_242, 3ULL, 2);
      v_t_245 = (g_heff_2esyntax_2epresyntax_2einfDe_24s1518595459x1830515696(v_sp_244, v_n_243));
      break;
    }
    default: heff_nomatch(v_i_242);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_240});
  }
  case TAG_CType: {
    V v_t_246 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CType = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_t_246, 0);
      V v_sp_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      v_t_249 = (g_heff_2esyntax_2epresyntax_2etypDe_24s574808955x1254705690(v_sp_248, v_n_247));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CType, TAG_CType, 1, (V[]){v_t_249}), v_sp_240});
  }
  case TAG_CLam: {
    V v_x_2410 = heff_field(v_n_241, 0);
    V v_xsp_2411 = heff_field(v_n_241, 1);
    V v_b_2412 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2415;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_At: {
      V v_n_2413 = heff_field(v_b_2412, 0);
      V v_sp_2414 = heff_field(v_b_2412, 1);
      heff_take_n(v_b_2412, 3ULL, 2);
      v_t_2415 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2414, v_n_2413));
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CLam, TAG_CLam, 3, (V[]){v_x_2410, v_xsp_2411, v_t_2415}), v_sp_240});
  }
  case TAG_CImplicitLam: {
    V v_x_2416 = heff_field(v_n_241, 0);
    V v_xsp_2417 = heff_field(v_n_241, 1);
    V v_b_2418 = heff_field(v_n_241, 2);
    V v_ru_24n_241_24CImplicitLam = heff_take_reuse_n(v_n_241, 7ULL, 3);
    V v_t_2421;
    switch (heff_tag_of(v_b_2418)) {
    case TAG_At: {
      V v_n_2419 = heff_field(v_b_2418, 0);
      V v_sp_2420 = heff_field(v_b_2418, 1);
      heff_take_n(v_b_2418, 3ULL, 2);
      v_t_2421 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2420, v_n_2419));
      break;
    }
    default: heff_nomatch(v_b_2418);
    }
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n_241_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_x_2416, v_xsp_2417, v_t_2421}), v_sp_240});
  }
  case TAG_CAnnLam: {
    V v_t_2426 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2427 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2427, v_sp_240});
  }
  case TAG_CTag: {
    V v_t_2431 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2432 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2431, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_240});
  }
  case TAG_CStruct: {
    V v_fs_2433 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24CStruct = heff_take_reuse_n(v_n_241, 1ULL, 1);
    V v_t_2434 = heff_tag_at_n(v_ru_24n_241_24CStruct, TAG_CStruct, 1, (V[]){(g_list_2emap_24s249042484x1701682908(v_fs_2433))});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_sp_240});
  }
  case TAG_CMatch: {
    V v_t_2437 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2438 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_240});
  }
  case TAG_CLetIn: {
    V v_t_2441 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2442 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_sp_240});
  }
  case TAG_CLocal: {
    V v_t_2445 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2446 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_240});
  }
  case TAG_CAbandon: {
    V v_t_2447 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2448 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_240});
  }
  case TAG_CNominal: {
    V v_t_2450 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_241));
    V v_t_2451 = heff_tag_n(TAG_CNominal, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2450, heff_dup(v_sp_240)})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2451, v_sp_240});
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(a[0], a[1]);
}