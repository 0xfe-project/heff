// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Catch 6517
#define TAG_Complete 48856
#define TAG_Draw 50003
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Finish 61316
#define TAG_Get 18914
#define TAG_Interactive 42932
#define TAG_Measure 52418
#define TAG_NewChan 9424
#define TAG_Put 28059
#define TAG_RDone 16778
#define TAG_ReadInput 54226
#define TAG_ReadStdin 20528
#define TAG_Recv 61489
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_Sleep 25229
#define TAG_Spawn 10053
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2ebind_24s2023162438x1917167210(V, V, V);
V g_co_2ebind_24s2023162438x1917167210_entry(V self, V *a);
extern Clo g_co_2ebind_24s2023162438x1917167210_clo;
V g_co_2ebind_24s591410632x427349444(V, V, V);
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a);
extern Clo g_co_2ebind_24s591410632x427349444_clo;
V g_co_2eop_24s1424406191x184069130(V, V, V, V, V, V, V);
V g_co_2eop_24s1424406191x184069130_entry(V self, V *a);
extern Clo g_co_2eop_24s1424406191x184069130_clo;
V g_co_2eop_24s1615307314x262795202(V, V, V);
V g_co_2eop_24s1615307314x262795202_entry(V self, V *a);
extern Clo g_co_2eop_24s1615307314x262795202_clo;
V g_co_2eop_24s1676588087x1342415945(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1676588087x1342415945_entry(V self, V *a);
extern Clo g_co_2eop_24s1676588087x1342415945_clo;
V g_co_2eop_24s1938432363x1897732959(V, V, V, V, V, V);
V g_co_2eop_24s1938432363x1897732959_entry(V self, V *a);
extern Clo g_co_2eop_24s1938432363x1897732959_clo;
V g_co_2eop_24s2040132903x129219385(V, V, V);
V g_co_2eop_24s2040132903x129219385_entry(V self, V *a);
extern Clo g_co_2eop_24s2040132903x129219385_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_co_2eop_24s655614836x79419354(V, V, V, V, V, V, V, V);
V g_co_2eop_24s655614836x79419354_entry(V self, V *a);
extern Clo g_co_2eop_24s655614836x79419354_clo;
V g_co_2eop_24s695421809x762051105(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s695421809x762051105_entry(V self, V *a);
extern Clo g_co_2eop_24s695421809x762051105_clo;
V g_co_2eop_24s75967081x1174714853(V, V, V);
V g_co_2eop_24s75967081x1174714853_entry(V self, V *a);
extern Clo g_co_2eop_24s75967081x1174714853_clo;
V g_co_2eop_24s851371283x356629733(V, V, V, V, V);
V g_co_2eop_24s851371283x356629733_entry(V self, V *a);
extern Clo g_co_2eop_24s851371283x356629733_clo;
V g_co_2eop_24s897039307x1692197561(V, V, V, V, V, V);
V g_co_2eop_24s897039307x1692197561_entry(V self, V *a);
extern Clo g_co_2eop_24s897039307x1692197561_clo;
V g_co_2eplus(V, V);
V g_co_2eplus_entry(V self, V *a);
extern Clo g_co_2eplus_clo;
V g_co_2eplus_24s1226459126x1628219458_get(void);
V g_co_2eplus_24s1257879563x1568253915(V);
V g_co_2eplus_24s1257879563x1568253915_entry(V self, V *a);
extern Clo g_co_2eplus_24s1257879563x1568253915_clo;
V g_co_2eplus_24s1493898788x821937431_get(void);
V g_co_2eplus_24s1597160042x1604640811_get(void);
V g_co_2eplus_24s1614286456x695605604_get(void);
V g_co_2eplus_24s169777576x280800149_get(void);
V g_co_2eplus_24s1854017309x1005292301_get(void);
V g_co_2eplus_24s1914620224x1667922359_get(void);
V g_co_2eplus_24s1926030886x1813643643_get(void);
V g_co_2eplus_24s2124540091x1079095538_get(void);
V g_co_2eplus_24s638448470x237911921_get(void);
V g_co_2eplus_24s781597930x1570803347_get(void);
V g_co_2eplus_24s860740675x1298266759(V);
V g_co_2eplus_24s860740675x1298266759_entry(V self, V *a);
extern Clo g_co_2eplus_24s860740675x1298266759_clo;
V g_co_2eplus_24s973240257x441859337_get(void);
V g_co_2eplus_24s984570155x1252140766_get(void);
V g_green_2egreen_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(V, V);
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_clo;
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2efilesystem_2efilesystem_get(void);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2enet_2enet_get(void);
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprogress_2eprogress_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_std_2eterminal_2econsole_get(void);
V g_co_2eplus_lam0(V self, V *args);
V g_co_2eplus_lam1(V self, V *args);
Clo g_co_2eplus_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_entry, 2, 0};

V g_co_2eplus(V v_h_240, V v_k_241) {
top: ;
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2eplus_lam0, 3, 2, (V[]){heff_dup(v_h_240), heff_dup(v_k_241)}), heff_clo_n(g_co_2eplus_lam1, 4, 2, (V[]){v_h_240, v_k_241})});
}
V g_co_2eplus_entry(V self, V *a) {
  (void)self;
  return g_co_2eplus(a[0], a[1]);
}
V g_co_2eplus_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_g_243 = args[1];
  V v_p_244 = args[2];
  V v_h_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_244)) {
  case TAG_InL: {
    V v_x_245 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InL = heff_take_reuse_n(v_p_244, 1ULL, 1);
    heff_drop_rec(v_k_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_h_240, 0, 2), 3, (V[]){v_m_242, v_g_243, v_x_245}));
    return heff_tag_at_n(v_ru_24p_244_24InL, TAG_InL, 1, (V[]){v_t_246});
  }
  case TAG_InR: {
    V v_y_247 = heff_field(v_p_244, 0);
    V v_ru_24p_244_24InR = heff_take_reuse_n(v_p_244, 1ULL, 1);
    heff_drop_rec(v_h_240, 2);
    V v_t_248 = heff_tr(heff_call(heff_get_n(v_k_241, 0, 2), 3, (V[]){v_m_242, v_g_243, v_y_247}));
    return heff_tag_at_n(v_ru_24p_244_24InR, TAG_InR, 1, (V[]){v_t_248});
  }
  default: return heff_nomatch(v_p_244);
  }
}
V g_co_2eplus_lam1(V self, V *args) {
  V v_m_249 = args[0];
  V v_n_2410 = args[1];
  V v_nt_2411 = args[2];
  V v_p_2412 = args[3];
  V v_h_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2412)) {
  case TAG_InL: {
    V v_x_2413 = heff_field(v_p_2412, 0);
    V v_ru_24p_2412_24InL = heff_take_reuse_n(v_p_2412, 1ULL, 1);
    heff_drop_rec(v_k_241, 2);
    V v_t_2414 = heff_tr(heff_call(heff_get_n(v_h_240, 1, 2), 4, (V[]){v_m_249, v_n_2410, v_nt_2411, v_x_2413}));
    return heff_tag_at_n(v_ru_24p_2412_24InL, TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_2412, 0);
    V v_ru_24p_2412_24InR = heff_take_reuse_n(v_p_2412, 1ULL, 1);
    heff_drop_rec(v_h_240, 2);
    V v_t_2416 = heff_tr(heff_call(heff_get_n(v_k_241, 1, 2), 4, (V[]){v_m_249, v_n_2410, v_nt_2411, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_2412_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_2412);
  }
}
V g_co_2eplus_24s1257879563x1568253915_lam1(V self, V *args);
V g_co_2eplus_24s1257879563x1568253915_lam0(V self, V *args);
V g_co_2eplus_24s1257879563x1568253915_lam3(V self, V *args);
V g_co_2eplus_24s1257879563x1568253915_lam2(V self, V *args);
Clo g_co_2eplus_24s1257879563x1568253915_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1257879563x1568253915_entry, 1, 0};

V g_co_2eplus_24s1257879563x1568253915(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2eplus_24s1257879563x1568253915_lam0, 3, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_co_2eplus_24s1257879563x1568253915_lam2, 4, 1, (V[]){v_k_240})});
}
V g_co_2eplus_24s1257879563x1568253915_entry(V self, V *a) {
  (void)self;
  return g_co_2eplus_24s1257879563x1568253915(a[0]);
}
V g_co_2eplus_24s1257879563x1568253915_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_g_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = heff_get_n(v_m_241, 0, 1);
  heff_room[0] = v_g_242;
  heff_room[1] = v_t_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s1257879563x1568253915_lam0(V self, V *args) {
  V v_m_241 = args[0];
  V v_g_242 = args[1];
  V v_p_243 = args[2];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    heff_drop_rec(v_k_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      heff_drop_rec(v_m_241, 1);
      heff_drop(v_g_242);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24Catch = heff_take_reuse_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_241, 0)), 2, (V[]){heff_dup(v_g_242), v_c_246}));
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Catch, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2eplus_24s1257879563x1568253915_lam1, 1, 3, (V[]){v_h_247, v_m_241, v_g_242})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    return heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_2411});
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 3, (V[]){v_m_241, v_g_242, v_y_2412}));
    return heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_co_2eplus_24s1257879563x1568253915_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_h_2421 = heff_env(self)[0];
  V v_nt_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_h_2421, 1, (V[]){v_s_2423}));
  V f_ = v_nt_2416;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1257879563x1568253915_lam2(V self, V *args) {
  V v_m_2414 = args[0];
  V v_n_2415 = args[1];
  V v_nt_2416 = args[2];
  V v_p_2417 = args[3];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    heff_drop(v_m_2414);
    heff_drop(v_n_2415);
    heff_drop_rec(v_k_240, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Throw: {
      V v_s_2419 = heff_field(v_x_2418, 0);
      V v_ru_24x_2418_24Throw = heff_take_reuse_n(v_x_2418, 1ULL, 1);
      heff_drop(v_nt_2416);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2418_24Throw, TAG_Throw, 1, (V[]){v_s_2419});
      break;
    }
    case TAG_Catch: {
      V v_c_2420 = heff_field(v_x_2418, 0);
      V v_h_2421 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24Catch = heff_take_reuse_n(v_x_2418, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(heff_dup(v_nt_2416), 1, (V[]){v_c_2420}));
      v_t_2425 = heff_tag_at_n(v_ru_24x_2418_24Catch, TAG_Catch, 2, (V[]){v_t_2422, heff_clo_n(g_co_2eplus_24s1257879563x1568253915_lam3, 1, 2, (V[]){v_h_2421, v_nt_2416})});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 4, (V[]){v_m_2414, v_n_2415, v_nt_2416, v_y_2426}));
    return heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2eplus_24s973240257x441859337_lam1(V self, V *args);
V g_co_2eplus_24s973240257x441859337_lam2(V self, V *args);
V g_co_2eplus_24s973240257x441859337_lam0(V self, V *args); static Clo g_co_2eplus_24s973240257x441859337_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s973240257x441859337_lam0, 3, 0};
V g_co_2eplus_24s973240257x441859337_lam4(V self, V *args);
V g_co_2eplus_24s973240257x441859337_lam3(V self, V *args); static Clo g_co_2eplus_24s973240257x441859337_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s973240257x441859337_lam3, 4, 0};

static V g_co_2eplus_24s973240257x441859337_val;
static HEFF_ONCE g_co_2eplus_24s973240257x441859337_st;
static V g_co_2eplus_24s973240257x441859337_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s973240257x441859337_lam0_clo), ((V)&g_co_2eplus_24s973240257x441859337_lam3_clo)});
}
V g_co_2eplus_24s973240257x441859337_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s973240257x441859337_st)) return g_co_2eplus_24s973240257x441859337_val;
  return heff_global(&g_co_2eplus_24s973240257x441859337_val, &g_co_2eplus_24s973240257x441859337_st, g_co_2eplus_24s973240257x441859337_init);
}
V g_co_2eplus_24s973240257x441859337_lam1(V self, V *args) {
  V v_st_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_st_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s973240257x441859337_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_h_2414 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tr(heff_call(v_h_2414, 1, (V[]){v_s_2416}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s973240257x441859337_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop_rec(v_m_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Get = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Get, TAG_Get, 1, (V[]){heff_clo_n(g_co_2eplus_24s973240257x441859337_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
      break;
    }
    case TAG_Put: {
      V v_st_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_247, v_t_249});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24Throw = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Throw, TAG_Throw, 1, (V[]){v_s_2412});
      break;
    }
    case TAG_Catch: {
      V v_c_2413 = heff_field(v_y_2411, 0);
      V v_h_2414 = heff_field(v_y_2411, 1);
      V v_ru_24y_2411_24Catch = heff_take_reuse_n(v_y_2411, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_2413}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Catch, TAG_Catch, 2, (V[]){v_t_2415, heff_clo_n(g_co_2eplus_24s973240257x441859337_lam2, 1, 3, (V[]){v_h_2414, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s973240257x441859337_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_h_2431 = heff_env(self)[0];
  V v_nt_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tr(heff_call(v_h_2431, 1, (V[]){v_s_2433}));
  V f_ = v_nt_2421;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s973240257x441859337_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  heff_drop(v_m_2419);
  heff_drop(v_n_2420);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    V v_t_2427;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Get: {
      V v_k_2424 = heff_field(v_x_2423, 0);
      V v_ru_24x_2423_24Get = heff_take_reuse_n(v_x_2423, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24Get, TAG_Get, 1, (V[]){v_k_2424});
      break;
    }
    case TAG_Put: {
      V v_st_2425 = heff_field(v_x_2423, 0);
      V v_x_2426 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24Put = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24Put, TAG_Put, 2, (V[]){v_st_2425, v_x_2426});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2427});
  }
  case TAG_InR: {
    V v_y_2428 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Throw: {
      V v_s_2429 = heff_field(v_y_2428, 0);
      V v_ru_24y_2428_24Throw = heff_take_reuse_n(v_y_2428, 1ULL, 1);
      heff_drop(v_nt_2421);
      v_t_2435 = heff_tag_at_n(v_ru_24y_2428_24Throw, TAG_Throw, 1, (V[]){v_s_2429});
      break;
    }
    case TAG_Catch: {
      V v_c_2430 = heff_field(v_y_2428, 0);
      V v_h_2431 = heff_field(v_y_2428, 1);
      V v_ru_24y_2428_24Catch = heff_take_reuse_n(v_y_2428, 3ULL, 2);
      V v_t_2432 = heff_tr(heff_call(heff_dup(v_nt_2421), 1, (V[]){v_c_2430}));
      v_t_2435 = heff_tag_at_n(v_ru_24y_2428_24Catch, TAG_Catch, 2, (V[]){v_t_2432, heff_clo_n(g_co_2eplus_24s973240257x441859337_lam4, 1, 2, (V[]){v_h_2431, v_nt_2421})});
      break;
    }
    default: heff_nomatch(v_y_2428);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2435});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2ebind_24s591410632x427349444_lam0(V self, V *args); static Clo g_co_2ebind_24s591410632x427349444_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s591410632x427349444_lam0, 1, 0};
V g_co_2ebind_24s591410632x427349444_lam1(V self, V *args);
Clo g_co_2ebind_24s591410632x427349444_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s591410632x427349444_entry, 3, 0};

V g_co_2ebind_24s591410632x427349444(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s591410632x427349444_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s591410632x427349444_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s591410632x427349444(a[0], a[1], a[2]);
}
V g_co_2ebind_24s591410632x427349444_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s591410632x427349444_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s2023162438x1917167210_lam1(V self, V *args); static Clo g_co_2ebind_24s2023162438x1917167210_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s2023162438x1917167210_lam1, 2, 0};
V g_co_2ebind_24s2023162438x1917167210_lam0(V self, V *args);
Clo g_co_2ebind_24s2023162438x1917167210_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s2023162438x1917167210_entry, 3, 0};

V g_co_2ebind_24s2023162438x1917167210(V v_c_240, V v_f_241, V v_z_242) {
top: ;
  return heff_tail(v_c_240, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_co_2ebind_24s2023162438x1917167210_lam0, 1, 1, (V[]){v_f_241}), v_z_242});
}
V g_co_2ebind_24s2023162438x1917167210_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s2023162438x1917167210(a[0], a[1], a[2]);
}
V g_co_2ebind_24s2023162438x1917167210_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_244}), v_a_245});
}
V g_co_2ebind_24s2023162438x1917167210_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_241;
  heff_room[0] = v_x_243;
  heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[2] = ((V)&g_co_2ebind_24s2023162438x1917167210_lam1_clo);
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eplus_24s1493898788x821937431_lam1(V self, V *args);
V g_co_2eplus_24s1493898788x821937431_lam0(V self, V *args); static Clo g_co_2eplus_24s1493898788x821937431_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1493898788x821937431_lam0, 3, 0};
V g_co_2eplus_24s1493898788x821937431_lam2(V self, V *args); static Clo g_co_2eplus_24s1493898788x821937431_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1493898788x821937431_lam2, 4, 0};

static V g_co_2eplus_24s1493898788x821937431_val;
static HEFF_ONCE g_co_2eplus_24s1493898788x821937431_st;
static V g_co_2eplus_24s1493898788x821937431_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1493898788x821937431_lam0_clo), ((V)&g_co_2eplus_24s1493898788x821937431_lam2_clo)});
}
V g_co_2eplus_24s1493898788x821937431_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1493898788x821937431_st)) return g_co_2eplus_24s1493898788x821937431_val;
  return heff_global(&g_co_2eplus_24s1493898788x821937431_val, &g_co_2eplus_24s1493898788x821937431_st, g_co_2eplus_24s1493898788x821937431_init);
}
V g_co_2eplus_24s1493898788x821937431_lam1(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_k_2411, 1, (V[]){v_s_2412}));
  V f_ = v_g_241;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1493898788x821937431_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2414;
      switch (heff_tag_of(v_x_244)) {
      case TAG_Write: {
        V v_str_245 = heff_field(v_x_244, 0);
        V v_x_246 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24Write = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_247 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_246}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24Write, TAG_Write, 2, (V[]){v_str_245, v_t_247});
        break;
      }
      case TAG_WriteErr: {
        V v_str_248 = heff_field(v_x_244, 0);
        V v_x_249 = heff_field(v_x_244, 1);
        V v_ru_24x_244_24WriteErr = heff_take_reuse_n(v_x_244, 3ULL, 2);
        heff_drop_cell(v_ru_24x_243_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_249}));
        v_t_2414 = heff_tag_at_n(v_ru_24x_244_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_248, v_t_2410});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2411 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_ReadStdin, 1, (V[]){heff_clo_n(g_co_2eplus_24s1493898788x821937431_lam1, 1, 2, (V[]){v_k_2411, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2417 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_InR: {
      V v_y_2415 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2417});
  }
  case TAG_InR: {
    V v_y_2418 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2418}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2419});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1493898788x821937431_lam2(V self, V *args) {
  V v_m_2420 = args[0];
  V v_n_2421 = args[1];
  V v_nt_2422 = args[2];
  V v_p_2423 = args[3];
  switch (heff_tag_of(v_p_2423)) {
  case TAG_InL: {
    V v_x_2424 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InL = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_x_2424)) {
    case TAG_InL: {
      V v_x_2425 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InL = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop(v_m_2420);
      heff_drop(v_n_2421);
      heff_drop(v_nt_2422);
      V v_t_2431;
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Write: {
        V v_str_2426 = heff_field(v_x_2425, 0);
        V v_x_2427 = heff_field(v_x_2425, 1);
        V v_ru_24x_2425_24Write = heff_take_reuse_n(v_x_2425, 3ULL, 2);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2425_24Write, TAG_Write, 2, (V[]){v_str_2426, v_x_2427});
        break;
      }
      case TAG_WriteErr: {
        V v_str_2428 = heff_field(v_x_2425, 0);
        V v_x_2429 = heff_field(v_x_2425, 1);
        V v_ru_24x_2425_24WriteErr = heff_take_reuse_n(v_x_2425, 3ULL, 2);
        heff_drop_cell(v_ru_24x_2424_24InL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2425_24WriteErr, TAG_WriteErr, 2, (V[]){v_str_2428, v_x_2429});
        break;
      }
      case TAG_ReadStdin: {
        V v_k_2430 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24InL, TAG_ReadStdin, 1, (V[]){v_k_2430});
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      v_t_2434 = heff_tag_at_n(v_ru_24p_2423_24InL, TAG_InL, 1, (V[]){v_t_2431});
      break;
    }
    case TAG_InR: {
      V v_y_2432 = heff_field(v_x_2424, 0);
      V v_ru_24x_2424_24InR = heff_take_reuse_n(v_x_2424, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2423_24InL, 1);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprocess_2eprocess_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2432}));
      v_t_2434 = heff_tag_at_n(v_ru_24x_2424_24InR, TAG_InR, 1, (V[]){v_t_2433});
      break;
    }
    default: heff_nomatch(v_x_2424);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2423, 0);
    V v_ru_24p_2423_24InR = heff_take_reuse_n(v_p_2423, 1ULL, 1);
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2efilesystem_2efilesystem_get(), 1)), 4, (V[]){v_m_2420, v_n_2421, v_nt_2422, v_y_2435}));
    return heff_tag_at_n(v_ru_24p_2423_24InR, TAG_InR, 1, (V[]){v_t_2436});
  }
  default: return heff_nomatch(v_p_2423);
  }
}
V g_co_2eplus_24s1614286456x695605604_lam0(V self, V *args); static Clo g_co_2eplus_24s1614286456x695605604_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1614286456x695605604_lam0, 3, 0};
V g_co_2eplus_24s1614286456x695605604_lam1(V self, V *args); static Clo g_co_2eplus_24s1614286456x695605604_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1614286456x695605604_lam1, 4, 0};

static V g_co_2eplus_24s1614286456x695605604_val;
static HEFF_ONCE g_co_2eplus_24s1614286456x695605604_st;
static V g_co_2eplus_24s1614286456x695605604_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1614286456x695605604_lam0_clo), ((V)&g_co_2eplus_24s1614286456x695605604_lam1_clo)});
}
V g_co_2eplus_24s1614286456x695605604_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1614286456x695605604_st)) return g_co_2eplus_24s1614286456x695605604_val;
  return heff_global(&g_co_2eplus_24s1614286456x695605604_val, &g_co_2eplus_24s1614286456x695605604_st, g_co_2eplus_24s1614286456x695605604_init);
}
V g_co_2eplus_24s1614286456x695605604_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1926030886x1813643643_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_248 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_246}));
      v_t_248 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_248});
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2413;
    switch (heff_tag_of(v_y_249)) {
    case TAG_Sleep: {
      V v_ms_2410 = heff_field(v_y_249, 0);
      V v_x_2411 = heff_field(v_y_249, 1);
      V v_ru_24y_249_24Sleep = heff_take_reuse_n(v_y_249, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2411}));
      v_t_2413 = heff_tag_at_n(v_ru_24y_249_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2410, v_t_2412});
      break;
    }
    default: heff_nomatch(v_y_249);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1614286456x695605604_lam1(V self, V *args) {
  V v_m_2414 = args[0];
  V v_n_2415 = args[1];
  V v_nt_2416 = args[2];
  V v_p_2417 = args[3];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2430;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_InL: {
      V v_x_2419 = heff_field(v_x_2418, 0);
      heff_take_n(v_x_2418, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1926030886x1813643643_get(), 1)), 4, (V[]){v_m_2414, v_n_2415, v_nt_2416, v_x_2419}));
      v_t_2430 = heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2420});
      break;
    }
    case TAG_InR: {
      V v_y_2421 = heff_field(v_x_2418, 0);
      V v_ru_24x_2418_24InR = heff_take_reuse_n(v_x_2418, 1ULL, 1);
      heff_drop(v_m_2414);
      heff_drop(v_n_2415);
      heff_drop(v_nt_2416);
      heff_drop_cell(v_ru_24p_2417_24InL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_y_2421)) {
      case TAG_Interactive: {
        V v_k_2422 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Interactive = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Interactive, TAG_Interactive, 1, (V[]){v_k_2422});
        break;
      }
      case TAG_Begin: {
        V v_k_2423 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Begin = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Begin, TAG_Begin, 1, (V[]){v_k_2423});
        break;
      }
      case TAG_Finish: {
        V v_x_2424 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Finish = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Finish, TAG_Finish, 1, (V[]){v_x_2424});
        break;
      }
      case TAG_Measure: {
        V v_k_2425 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Measure = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Measure, TAG_Measure, 1, (V[]){v_k_2425});
        break;
      }
      case TAG_ReadInput: {
        V v_k_2426 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24ReadInput = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24ReadInput, TAG_ReadInput, 1, (V[]){v_k_2426});
        break;
      }
      case TAG_Draw: {
        V v_s_2427 = heff_field(v_y_2421, 0);
        V v_x_2428 = heff_field(v_y_2421, 1);
        V v_ru_24y_2421_24Draw = heff_take_reuse_n(v_y_2421, 3ULL, 2);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Draw, TAG_Draw, 2, (V[]){v_s_2427, v_x_2428});
        break;
      }
      default: heff_nomatch(v_y_2421);
      }
      v_t_2430 = heff_tag_at_n(v_ru_24x_2418_24InR, TAG_InR, 1, (V[]){v_t_2429});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2430});
  }
  case TAG_InR: {
    V v_y_2431 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    heff_drop(v_m_2414);
    heff_drop(v_n_2415);
    heff_drop(v_nt_2416);
    V v_t_2434;
    switch (heff_tag_of(v_y_2431)) {
    case TAG_Sleep: {
      V v_ms_2432 = heff_field(v_y_2431, 0);
      V v_x_2433 = heff_field(v_y_2431, 1);
      V v_ru_24y_2431_24Sleep = heff_take_reuse_n(v_y_2431, 3ULL, 2);
      v_t_2434 = heff_tag_at_n(v_ru_24y_2431_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2432, v_x_2433});
      break;
    }
    default: heff_nomatch(v_y_2431);
    }
    return heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2434});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2eplus_24s1597160042x1604640811_lam0(V self, V *args); static Clo g_co_2eplus_24s1597160042x1604640811_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1597160042x1604640811_lam0, 3, 0};
V g_co_2eplus_24s1597160042x1604640811_lam1(V self, V *args); static Clo g_co_2eplus_24s1597160042x1604640811_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1597160042x1604640811_lam1, 4, 0};

static V g_co_2eplus_24s1597160042x1604640811_val;
static HEFF_ONCE g_co_2eplus_24s1597160042x1604640811_st;
static V g_co_2eplus_24s1597160042x1604640811_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1597160042x1604640811_lam0_clo), ((V)&g_co_2eplus_24s1597160042x1604640811_lam1_clo)});
}
V g_co_2eplus_24s1597160042x1604640811_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1597160042x1604640811_st)) return g_co_2eplus_24s1597160042x1604640811_val;
  return heff_global(&g_co_2eplus_24s1597160042x1604640811_val, &g_co_2eplus_24s1597160042x1604640811_st, g_co_2eplus_24s1597160042x1604640811_init);
}
V g_co_2eplus_24s1597160042x1604640811_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2415;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InL = heff_take_reuse_n(v_x_243, 1ULL, 1);
      V v_t_249;
      switch (heff_tag_of(v_x_244)) {
      case TAG_InL: {
        V v_x_245 = heff_field(v_x_244, 0);
        heff_take_n(v_x_244, 1ULL, 1);
        V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1926030886x1813643643_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_245}));
        v_t_249 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_246});
        break;
      }
      case TAG_InR: {
        V v_y_247 = heff_field(v_x_244, 0);
        V v_ru_24x_244_24InR = heff_take_reuse_n(v_x_244, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InL, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_247}));
        v_t_249 = heff_tag_at_n(v_ru_24x_244_24InR, TAG_InR, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x_244);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InL, TAG_InL, 1, (V[]){v_t_249});
      break;
    }
    case TAG_InR: {
      V v_y_2410 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2414;
      switch (heff_tag_of(v_y_2410)) {
      case TAG_Sleep: {
        V v_ms_2411 = heff_field(v_y_2410, 0);
        V v_x_2412 = heff_field(v_y_2410, 1);
        V v_ru_24y_2410_24Sleep = heff_take_reuse_n(v_y_2410, 3ULL, 2);
        V v_t_2413 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2412}));
        v_t_2414 = heff_tag_at_n(v_ru_24y_2410_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2411, v_t_2413});
        break;
      }
      default: heff_nomatch(v_y_2410);
      }
      v_t_2415 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2414});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2415});
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2416}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1597160042x1604640811_lam1(V self, V *args) {
  V v_m_2418 = args[0];
  V v_n_2419 = args[1];
  V v_nt_2420 = args[2];
  V v_p_2421 = args[3];
  switch (heff_tag_of(v_p_2421)) {
  case TAG_InL: {
    V v_x_2422 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InL = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1614286456x695605604_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_x_2422}));
    return heff_tag_at_n(v_ru_24p_2421_24InL, TAG_InL, 1, (V[]){v_t_2423});
  }
  case TAG_InR: {
    V v_y_2424 = heff_field(v_p_2421, 0);
    V v_ru_24p_2421_24InR = heff_take_reuse_n(v_p_2421, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2enet_2enet_get(), 1)), 4, (V[]){v_m_2418, v_n_2419, v_nt_2420, v_y_2424}));
    return heff_tag_at_n(v_ru_24p_2421_24InR, TAG_InR, 1, (V[]){v_t_2425});
  }
  default: return heff_nomatch(v_p_2421);
  }
}
V g_co_2eplus_24s984570155x1252140766_lam1(V self, V *args);
V g_co_2eplus_24s984570155x1252140766_lam2(V self, V *args);
V g_co_2eplus_24s984570155x1252140766_lam0(V self, V *args); static Clo g_co_2eplus_24s984570155x1252140766_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s984570155x1252140766_lam0, 3, 0};
V g_co_2eplus_24s984570155x1252140766_lam3(V self, V *args); static Clo g_co_2eplus_24s984570155x1252140766_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s984570155x1252140766_lam3, 4, 0};

static V g_co_2eplus_24s984570155x1252140766_val;
static HEFF_ONCE g_co_2eplus_24s984570155x1252140766_st;
static V g_co_2eplus_24s984570155x1252140766_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s984570155x1252140766_lam0_clo), ((V)&g_co_2eplus_24s984570155x1252140766_lam3_clo)});
}
V g_co_2eplus_24s984570155x1252140766_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s984570155x1252140766_st)) return g_co_2eplus_24s984570155x1252140766_val;
  return heff_global(&g_co_2eplus_24s984570155x1252140766_val, &g_co_2eplus_24s984570155x1252140766_st, g_co_2eplus_24s984570155x1252140766_init);
}
V g_co_2eplus_24s984570155x1252140766_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s984570155x1252140766_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s984570155x1252140766_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s169777576x280800149_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24UseColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s984570155x1252140766_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24ErrColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s984570155x1252140766_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s984570155x1252140766_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2428;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_InL: {
      V v_x_2422 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s169777576x280800149_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_x_2422}));
      v_t_2428 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2423});
      break;
    }
    case TAG_InR: {
      V v_y_2424 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24InR = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop(v_nt_2419);
      heff_drop_cell(v_ru_24p_2420_24InL, 1);
      V v_t_2427;
      switch (heff_tag_of(v_y_2424)) {
      case TAG_UseColor: {
        V v_k_2425 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24UseColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24UseColor, TAG_UseColor, 1, (V[]){v_k_2425});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2426 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24ErrColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24ErrColor, TAG_ErrColor, 1, (V[]){v_k_2426});
        break;
      }
      default: heff_nomatch(v_y_2424);
      }
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24InR, TAG_InR, 1, (V[]){v_t_2427});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_y_2429}));
    return heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eop_24s75967081x1174714853_lam1(V self, V *args);
V g_co_2eop_24s75967081x1174714853_lam0(V self, V *args); static Clo g_co_2eop_24s75967081x1174714853_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s75967081x1174714853_lam0, 4, 0};
V g_co_2eop_24s75967081x1174714853_lam3(V self, V *args);
V g_co_2eop_24s75967081x1174714853_lam2(V self, V *args);
V g_co_2eop_24s75967081x1174714853_lam4(V self, V *args);
Clo g_co_2eop_24s75967081x1174714853_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s75967081x1174714853_entry, 3, 0};

V g_co_2eop_24s75967081x1174714853(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s75967081x1174714853_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s75967081x1174714853_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s75967081x1174714853_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Send: {
      V v_rq_2417 = heff_field(v_y_2416, 0);
      V v_k_2418 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24Send = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      v_t_2419 = heff_tag_at_n(v_ru_24y_2416_24Send, TAG_Send, 2, (V[]){v_rq_2417, v_k_2418});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2421, v_k2_242});
}
V g_co_2eop_24s75967081x1174714853_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s75967081x1174714853(a[0], a[1], a[2]);
}
V g_co_2eop_24s75967081x1174714853_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s75967081x1174714853_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s75967081x1174714853_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s75967081x1174714853_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s75967081x1174714853_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s75967081x1174714853_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s75967081x1174714853_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s860740675x1298266759_lam1(V self, V *args);
V g_co_2eplus_24s860740675x1298266759_lam0(V self, V *args);
V g_co_2eplus_24s860740675x1298266759_lam3(V self, V *args);
V g_co_2eplus_24s860740675x1298266759_lam2(V self, V *args);
Clo g_co_2eplus_24s860740675x1298266759_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s860740675x1298266759_entry, 1, 0};

V g_co_2eplus_24s860740675x1298266759(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2eplus_24s860740675x1298266759_lam0, 3, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_co_2eplus_24s860740675x1298266759_lam2, 4, 1, (V[]){v_k_240})});
}
V g_co_2eplus_24s860740675x1298266759_entry(V self, V *a) {
  (void)self;
  return g_co_2eplus_24s860740675x1298266759(a[0]);
}
V g_co_2eplus_24s860740675x1298266759_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_g_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = heff_get_n(v_m_241, 0, 1);
  heff_room[0] = v_g_242;
  heff_room[1] = v_t_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s860740675x1298266759_lam0(V self, V *args) {
  V v_m_241 = args[0];
  V v_g_242 = args[1];
  V v_p_243 = args[2];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    heff_drop_rec(v_k_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      heff_drop_rec(v_m_241, 1);
      heff_drop(v_g_242);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24Catch = heff_take_reuse_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_241, 0)), 2, (V[]){heff_dup(v_g_242), v_c_246}));
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Catch, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2eplus_24s860740675x1298266759_lam1, 1, 3, (V[]){v_h_247, v_m_241, v_g_242})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    return heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_2411});
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 3, (V[]){v_m_241, v_g_242, v_y_2412}));
    return heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_co_2eplus_24s860740675x1298266759_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_h_2421 = heff_env(self)[0];
  V v_nt_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_h_2421, 1, (V[]){v_s_2423}));
  V f_ = v_nt_2416;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s860740675x1298266759_lam2(V self, V *args) {
  V v_m_2414 = args[0];
  V v_n_2415 = args[1];
  V v_nt_2416 = args[2];
  V v_p_2417 = args[3];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    heff_drop(v_m_2414);
    heff_drop(v_n_2415);
    heff_drop_rec(v_k_240, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Throw: {
      V v_s_2419 = heff_field(v_x_2418, 0);
      V v_ru_24x_2418_24Throw = heff_take_reuse_n(v_x_2418, 1ULL, 1);
      heff_drop(v_nt_2416);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2418_24Throw, TAG_Throw, 1, (V[]){v_s_2419});
      break;
    }
    case TAG_Catch: {
      V v_c_2420 = heff_field(v_x_2418, 0);
      V v_h_2421 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24Catch = heff_take_reuse_n(v_x_2418, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(heff_dup(v_nt_2416), 1, (V[]){v_c_2420}));
      v_t_2425 = heff_tag_at_n(v_ru_24x_2418_24Catch, TAG_Catch, 2, (V[]){v_t_2422, heff_clo_n(g_co_2eplus_24s860740675x1298266759_lam3, 1, 2, (V[]){v_h_2421, v_nt_2416})});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 4, (V[]){v_m_2414, v_n_2415, v_nt_2416, v_y_2426}));
    return heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2eplus_24s1854017309x1005292301_lam1(V self, V *args);
V g_co_2eplus_24s1854017309x1005292301_lam0(V self, V *args); static Clo g_co_2eplus_24s1854017309x1005292301_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1854017309x1005292301_lam0, 3, 0};
V g_co_2eplus_24s1854017309x1005292301_lam2(V self, V *args); static Clo g_co_2eplus_24s1854017309x1005292301_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1854017309x1005292301_lam2, 4, 0};

static V g_co_2eplus_24s1854017309x1005292301_val;
static HEFF_ONCE g_co_2eplus_24s1854017309x1005292301_st;
static V g_co_2eplus_24s1854017309x1005292301_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1854017309x1005292301_lam0_clo), ((V)&g_co_2eplus_24s1854017309x1005292301_lam2_clo)});
}
V g_co_2eplus_24s1854017309x1005292301_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1854017309x1005292301_st)) return g_co_2eplus_24s1854017309x1005292301_val;
  return heff_global(&g_co_2eplus_24s1854017309x1005292301_val, &g_co_2eplus_24s1854017309x1005292301_st, g_co_2eplus_24s1854017309x1005292301_init);
}
V g_co_2eplus_24s1854017309x1005292301_lam1(V self, V *args) {
  V v_r_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_r_2415}));
  V f_ = v_g_241;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1854017309x1005292301_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_InL: {
      V v_x_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24InL = heff_take_reuse_n(v_y_245, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_x_246)) {
      case TAG_InL: {
        V v_x_247 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InR, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1226459126x1628219458_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_247}));
        v_t_2411 = heff_tag_at_n(v_ru_24y_245_24InL, TAG_InL, 1, (V[]){v_t_248});
        break;
      }
      case TAG_InR: {
        V v_y_249 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 1);
        heff_drop_cell(v_ru_24y_245_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_249}));
        v_t_2411 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2411});
      break;
    }
    case TAG_InR: {
      V v_y_2412 = heff_field(v_y_245, 0);
      heff_take_n(v_y_245, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2417;
      switch (heff_tag_of(v_y_2412)) {
      case TAG_Send: {
        V v_rq_2413 = heff_field(v_y_2412, 0);
        V v_k_2414 = heff_field(v_y_2412, 1);
        V v_ru_24y_2412_24Send = heff_take_reuse_n(v_y_2412, 3ULL, 2);
        v_t_2417 = heff_tag_at_n(v_ru_24y_2412_24Send, TAG_Send, 2, (V[]){v_rq_2413, heff_clo_n(g_co_2eplus_24s1854017309x1005292301_lam1, 1, 2, (V[]){v_k_2414, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_2412);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1854017309x1005292301_lam2(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2436;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Start: {
      V v_parent_2424 = heff_field(v_x_2423, 0);
      V v_name_2425 = heff_field(v_x_2423, 1);
      V v_total_2426 = heff_field(v_x_2423, 2);
      V v_k_2427 = heff_field(v_x_2423, 3);
      V v_ru_24x_2423_24Start = heff_take_reuse_n(v_x_2423, 15ULL, 4);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24Start, TAG_Start, 4, (V[]){v_parent_2424, v_name_2425, v_total_2426, v_k_2427});
      break;
    }
    case TAG_Complete: {
      V v_t_2428 = heff_field(v_x_2423, 0);
      V v_x_2429 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24Complete = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24Complete, TAG_Complete, 2, (V[]){v_t_2428, v_x_2429});
      break;
    }
    case TAG_End: {
      V v_t_2430 = heff_field(v_x_2423, 0);
      V v_x_2431 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24End = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24End, TAG_End, 2, (V[]){v_t_2430, v_x_2431});
      break;
    }
    case TAG_RunUnder: {
      V v_t_2432 = heff_field(v_x_2423, 0);
      V v_cmd_2433 = heff_field(v_x_2423, 1);
      V v_argv_2434 = heff_field(v_x_2423, 2);
      V v_k_2435 = heff_field(v_x_2423, 3);
      V v_ru_24x_2423_24RunUnder = heff_take_reuse_n(v_x_2423, 15ULL, 4);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2432, v_cmd_2433, v_argv_2434, v_k_2435});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2436});
  }
  case TAG_InR: {
    V v_y_2437 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_y_2437)) {
    case TAG_InL: {
      V v_x_2438 = heff_field(v_y_2437, 0);
      V v_ru_24y_2437_24InL = heff_take_reuse_n(v_y_2437, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2422_24InR, 1);
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2438}));
      v_t_2444 = heff_tag_at_n(v_ru_24y_2437_24InL, TAG_InL, 1, (V[]){v_t_2439});
      break;
    }
    case TAG_InR: {
      V v_y_2440 = heff_field(v_y_2437, 0);
      heff_take_n(v_y_2437, 1ULL, 1);
      heff_drop(v_m_2419);
      heff_drop(v_n_2420);
      heff_drop(v_nt_2421);
      V v_t_2443;
      switch (heff_tag_of(v_y_2440)) {
      case TAG_Send: {
        V v_rq_2441 = heff_field(v_y_2440, 0);
        V v_k_2442 = heff_field(v_y_2440, 1);
        V v_ru_24y_2440_24Send = heff_take_reuse_n(v_y_2440, 3ULL, 2);
        v_t_2443 = heff_tag_at_n(v_ru_24y_2440_24Send, TAG_Send, 2, (V[]){v_rq_2441, v_k_2442});
        break;
      }
      default: heff_nomatch(v_y_2440);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_y_2437);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2eplus_24s781597930x1570803347_lam1(V self, V *args);
V g_co_2eplus_24s781597930x1570803347_lam2(V self, V *args);
V g_co_2eplus_24s781597930x1570803347_lam0(V self, V *args); static Clo g_co_2eplus_24s781597930x1570803347_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s781597930x1570803347_lam0, 3, 0};
V g_co_2eplus_24s781597930x1570803347_lam4(V self, V *args);
V g_co_2eplus_24s781597930x1570803347_lam5(V self, V *args);
V g_co_2eplus_24s781597930x1570803347_lam3(V self, V *args); static Clo g_co_2eplus_24s781597930x1570803347_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s781597930x1570803347_lam3, 4, 0};

static V g_co_2eplus_24s781597930x1570803347_val;
static HEFF_ONCE g_co_2eplus_24s781597930x1570803347_st;
static V g_co_2eplus_24s781597930x1570803347_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s781597930x1570803347_lam0_clo), ((V)&g_co_2eplus_24s781597930x1570803347_lam3_clo)});
}
V g_co_2eplus_24s781597930x1570803347_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s781597930x1570803347_st)) return g_co_2eplus_24s781597930x1570803347_val;
  return heff_global(&g_co_2eplus_24s781597930x1570803347_val, &g_co_2eplus_24s781597930x1570803347_st, g_co_2eplus_24s781597930x1570803347_init);
}
V g_co_2eplus_24s781597930x1570803347_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s781597930x1570803347_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_h_2415 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tr(heff_call(v_h_2415, 1, (V[]){v_s_2417}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s781597930x1570803347_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eplus_24s781597930x1570803347_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2422;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InL = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2412)) {
      case TAG_Throw: {
        V v_s_2413 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24Throw = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        heff_drop_rec(v_m_240, 1);
        heff_drop(v_g_241);
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24Throw, TAG_Throw, 1, (V[]){v_s_2413});
        break;
      }
      case TAG_Catch: {
        V v_c_2414 = heff_field(v_x_2412, 0);
        V v_h_2415 = heff_field(v_x_2412, 1);
        V v_ru_24x_2412_24Catch = heff_take_reuse_n(v_x_2412, 3ULL, 2);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_2414}));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24Catch, TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_co_2eplus_24s781597930x1570803347_lam2, 1, 3, (V[]){v_h_2415, v_m_240, v_g_241})});
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      v_t_2422 = heff_tag_at_n(v_ru_24y_2411_24InL, TAG_InL, 1, (V[]){v_t_2419});
      break;
    }
    case TAG_InR: {
      V v_y_2420 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2422});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s781597930x1570803347_lam4(V self, V *args) {
  V v_s_2432 = args[0];
  V v_h_2430 = heff_env(self)[0];
  V v_nt_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_tr(heff_call(v_h_2430, 1, (V[]){v_s_2432}));
  V f_ = v_nt_2425;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s781597930x1570803347_lam5(V self, V *args) {
  V v_s_2441 = args[0];
  V v_h_2439 = heff_env(self)[0];
  V v_nt_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2442 = heff_tr(heff_call(v_h_2439, 1, (V[]){v_s_2441}));
  V f_ = v_nt_2425;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s781597930x1570803347_lam3(V self, V *args) {
  V v_m_2423 = args[0];
  V v_n_2424 = args[1];
  V v_nt_2425 = args[2];
  V v_p_2426 = args[3];
  switch (heff_tag_of(v_p_2426)) {
  case TAG_InL: {
    V v_x_2427 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24InL = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    heff_drop(v_m_2423);
    heff_drop(v_n_2424);
    V v_t_2434;
    switch (heff_tag_of(v_x_2427)) {
    case TAG_Throw: {
      V v_s_2428 = heff_field(v_x_2427, 0);
      V v_ru_24x_2427_24Throw = heff_take_reuse_n(v_x_2427, 1ULL, 1);
      heff_drop(v_nt_2425);
      v_t_2434 = heff_tag_at_n(v_ru_24x_2427_24Throw, TAG_Throw, 1, (V[]){v_s_2428});
      break;
    }
    case TAG_Catch: {
      V v_c_2429 = heff_field(v_x_2427, 0);
      V v_h_2430 = heff_field(v_x_2427, 1);
      V v_ru_24x_2427_24Catch = heff_take_reuse_n(v_x_2427, 3ULL, 2);
      V v_t_2431 = heff_tr(heff_call(heff_dup(v_nt_2425), 1, (V[]){v_c_2429}));
      v_t_2434 = heff_tag_at_n(v_ru_24x_2427_24Catch, TAG_Catch, 2, (V[]){v_t_2431, heff_clo_n(g_co_2eplus_24s781597930x1570803347_lam4, 1, 2, (V[]){v_h_2430, v_nt_2425})});
      break;
    }
    default: heff_nomatch(v_x_2427);
    }
    return heff_tag_at_n(v_ru_24p_2426_24InL, TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2426, 0);
    V v_ru_24p_2426_24InR = heff_take_reuse_n(v_p_2426, 1ULL, 1);
    V v_t_2446;
    switch (heff_tag_of(v_y_2435)) {
    case TAG_InL: {
      V v_x_2436 = heff_field(v_y_2435, 0);
      V v_ru_24y_2435_24InL = heff_take_reuse_n(v_y_2435, 1ULL, 1);
      heff_drop(v_m_2423);
      heff_drop(v_n_2424);
      heff_drop_cell(v_ru_24p_2426_24InR, 1);
      V v_t_2443;
      switch (heff_tag_of(v_x_2436)) {
      case TAG_Throw: {
        V v_s_2437 = heff_field(v_x_2436, 0);
        V v_ru_24x_2436_24Throw = heff_take_reuse_n(v_x_2436, 1ULL, 1);
        heff_drop(v_nt_2425);
        v_t_2443 = heff_tag_at_n(v_ru_24x_2436_24Throw, TAG_Throw, 1, (V[]){v_s_2437});
        break;
      }
      case TAG_Catch: {
        V v_c_2438 = heff_field(v_x_2436, 0);
        V v_h_2439 = heff_field(v_x_2436, 1);
        V v_ru_24x_2436_24Catch = heff_take_reuse_n(v_x_2436, 3ULL, 2);
        V v_t_2440 = heff_tr(heff_call(heff_dup(v_nt_2425), 1, (V[]){v_c_2438}));
        v_t_2443 = heff_tag_at_n(v_ru_24x_2436_24Catch, TAG_Catch, 2, (V[]){v_t_2440, heff_clo_n(g_co_2eplus_24s781597930x1570803347_lam5, 1, 2, (V[]){v_h_2439, v_nt_2425})});
        break;
      }
      default: heff_nomatch(v_x_2436);
      }
      v_t_2446 = heff_tag_at_n(v_ru_24y_2435_24InL, TAG_InL, 1, (V[]){v_t_2443});
      break;
    }
    case TAG_InR: {
      V v_y_2444 = heff_field(v_y_2435, 0);
      heff_take_n(v_y_2435, 1ULL, 1);
      V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){v_m_2423, v_n_2424, v_nt_2425, v_y_2444}));
      v_t_2446 = heff_tag_at_n(v_ru_24p_2426_24InR, TAG_InR, 1, (V[]){v_t_2445});
      break;
    }
    default: heff_nomatch(v_y_2435);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2446});
  }
  default: return heff_nomatch(v_p_2426);
  }
}
V g_co_2eop_24s495635622x733177935_lam1(V self, V *args);
V g_co_2eop_24s495635622x733177935_lam0(V self, V *args); static Clo g_co_2eop_24s495635622x733177935_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s495635622x733177935_lam0, 4, 0};
V g_co_2eop_24s495635622x733177935_lam3(V self, V *args);
V g_co_2eop_24s495635622x733177935_lam2(V self, V *args);
V g_co_2eop_24s495635622x733177935_lam4(V self, V *args);
Clo g_co_2eop_24s495635622x733177935_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s495635622x733177935_entry, 3, 0};

V g_co_2eop_24s495635622x733177935(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s495635622x733177935_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s495635622x733177935_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s495635622x733177935_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s495635622x733177935_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s495635622x733177935(a[0], a[1], a[2]);
}
V g_co_2eop_24s495635622x733177935_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s495635622x733177935_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s495635622x733177935_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s495635622x733177935_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s495635622x733177935_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s495635622x733177935_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s495635622x733177935_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s655614836x79419354_str0, 2, ": ");
HEFF_LIT(g_co_2eop_24s655614836x79419354_str1, 1, "\012");
V g_co_2eop_24s655614836x79419354_lam1(V self, V *args);
V g_co_2eop_24s655614836x79419354_lam0(V self, V *args); static Clo g_co_2eop_24s655614836x79419354_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s655614836x79419354_lam0, 4, 0};
V g_co_2eop_24s655614836x79419354_lam3(V self, V *args);
V g_co_2eop_24s655614836x79419354_lam2(V self, V *args);
V g_co_2eop_24s655614836x79419354_lam4(V self, V *args);
V g_co_2eop_24s655614836x79419354_lam5(V self, V *args);
Clo g_co_2eop_24s655614836x79419354_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s655614836x79419354_entry, 8, 0};

V g_co_2eop_24s655614836x79419354(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s655614836x79419354_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s655614836x79419354_lam2, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s655614836x79419354_lam4, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2420, heff_clo_n(g_co_2eop_24s655614836x79419354_lam5, 1, 6, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s655614836x79419354_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s655614836x79419354(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_co_2eop_24s655614836x79419354_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_tr(heff_call(v_g_248, 1, (V[]){v_x_2412}));
  V f_ = v_k_2411;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s655614836x79419354_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_c_249 = args[1];
  V v_hd_2410 = args[2];
  V v_k_2411 = args[3];
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_co_2eop_24s655614836x79419354_lam1, 1, 2, (V[]){v_g_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s655614836x79419354_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2416}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s655614836x79419354_lam2(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2415;
  args[1] = heff_clo_n(g_co_2eop_24s655614836x79419354_lam3, 1, 2, (V[]){v_g_2414, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s655614836x79419354_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s655614836x79419354_lam5(V self, V *args) {
  V v_a_2421 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2421);
  V v_m_2422 = v_lit_240;
  V v_x2_2423 = v_lit_241;
  V v_n_2424 = heff_intAdd(v_lit_242, v_lit_243);
  V v_p_2425 = v_lit_244;
  V v_p_2426 = v_lit_245;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    heff_drop(v_m_2422);
    heff_drop(v_p_2425);
    V f_ = v_p_2426;
    args[0] = v_n_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2427 = heff_field(v_x2_2423, 0);
    V v_rest_2428 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24Cons = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2429 = heff_strAppend(heff_dup(v_m_2422), heff_strAppend(((V)&g_co_2eop_24s655614836x79419354_str0), v_l_2427));
    V v_t_2430 = heff_tag_at_n(v_ru_24x2_2423_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_co_2eop_24s655614836x79419354_str1)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s655614836x79419354(v_m_2422, v_rest_2428, v_n_2424, MK_INT(1LL), heff_dup(v_p_2425), v_p_2426, heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_p_2425));
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_co_2eop_24s1676588087x1342415945_lam1(V self, V *args);
V g_co_2eop_24s1676588087x1342415945_lam0(V self, V *args); static Clo g_co_2eop_24s1676588087x1342415945_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1676588087x1342415945_lam0, 4, 0};
V g_co_2eop_24s1676588087x1342415945_lam3(V self, V *args);
V g_co_2eop_24s1676588087x1342415945_lam2(V self, V *args);
V g_co_2eop_24s1676588087x1342415945_lam4(V self, V *args);
V g_co_2eop_24s1676588087x1342415945_lam5(V self, V *args);
Clo g_co_2eop_24s1676588087x1342415945_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1676588087x1342415945_entry, 8, 0};

V g_co_2eop_24s1676588087x1342415945(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1676588087x1342415945_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1676588087x1342415945_lam2, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s1676588087x1342415945_lam4, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2420, heff_clo_n(g_co_2eop_24s1676588087x1342415945_lam5, 1, 6, (V[]){heff_dup(v_lit_240), v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s1676588087x1342415945_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_co_2eop_24s1676588087x1342415945(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_co_2eop_24s1676588087x1342415945_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_tr(heff_call(v_g_248, 1, (V[]){v_x_2412}));
  V f_ = v_k_2411;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1676588087x1342415945_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_c_249 = args[1];
  V v_hd_2410 = args[2];
  V v_k_2411 = args[3];
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1676588087x1342415945_lam1, 1, 2, (V[]){v_g_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1676588087x1342415945_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2416}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1676588087x1342415945_lam2(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2415;
  args[1] = heff_clo_n(g_co_2eop_24s1676588087x1342415945_lam3, 1, 2, (V[]){v_g_2414, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1676588087x1342415945_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1676588087x1342415945_lam5(V self, V *args) {
  V v_a_2421 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2421);
  V v_t_2422 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V r_ = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_lit_244;
  heff_room[1] = v_lit_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1424406191x184069130_lam1(V self, V *args);
V g_co_2eop_24s1424406191x184069130_lam0(V self, V *args); static Clo g_co_2eop_24s1424406191x184069130_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1424406191x184069130_lam0, 4, 0};
V g_co_2eop_24s1424406191x184069130_lam3(V self, V *args);
V g_co_2eop_24s1424406191x184069130_lam2(V self, V *args);
V g_co_2eop_24s1424406191x184069130_lam4(V self, V *args);
V g_co_2eop_24s1424406191x184069130_lam5(V self, V *args);
Clo g_co_2eop_24s1424406191x184069130_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1424406191x184069130_entry, 7, 0};

V g_co_2eop_24s1424406191x184069130(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_p_245, V v_hd_246) {
top: ;
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1424406191x184069130_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1424406191x184069130_lam2, 2, 1, (V[]){heff_dup(v_hd_246)})}), heff_clo_n(g_co_2eop_24s1424406191x184069130_lam4, 1, 1, (V[]){heff_dup(v_hd_246)}), v_p_245}));
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2419, heff_clo_n(g_co_2eop_24s1424406191x184069130_lam5, 1, 5, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244})});
}
V g_co_2eop_24s1424406191x184069130_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s1424406191x184069130(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_co_2eop_24s1424406191x184069130_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2412 = heff_tr(heff_call(v_g_247, 1, (V[]){v_x_2411}));
  V f_ = v_k_2410;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1424406191x184069130_lam0(V self, V *args) {
  V v_g_247 = args[0];
  V v_c_248 = args[1];
  V v_hd_249 = args[2];
  V v_k_2410 = args[3];
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_co_2eop_24s1424406191x184069130_lam1, 1, 2, (V[]){v_g_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1424406191x184069130_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2415}));
  V f_ = heff_get_n(v_hd_246, 0, 3);
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1424406191x184069130_lam2(V self, V *args) {
  V v_g_2413 = args[0];
  V v_m_2414 = args[1];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_m_2414;
  args[1] = heff_clo_n(g_co_2eop_24s1424406191x184069130_lam3, 1, 2, (V[]){v_g_2413, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1424406191x184069130_lam4(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_get_n(v_hd_246, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1424406191x184069130_lam5(V self, V *args) {
  V v_a_2420 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_a_2420);
  V v_t_2421 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V r_ = (g_heff_2ebuild_2ecommands_2eprintFails_24s1073289170x1610174193(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_lit_243;
  heff_room[1] = v_lit_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s851371283x356629733_str0, 1, "\012");
V g_co_2eop_24s851371283x356629733_lam1(V self, V *args);
V g_co_2eop_24s851371283x356629733_lam0(V self, V *args); static Clo g_co_2eop_24s851371283x356629733_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s851371283x356629733_lam0, 4, 0};
V g_co_2eop_24s851371283x356629733_lam3(V self, V *args);
V g_co_2eop_24s851371283x356629733_lam2(V self, V *args);
V g_co_2eop_24s851371283x356629733_lam4(V self, V *args);
V g_co_2eop_24s851371283x356629733_lam5(V self, V *args);
Clo g_co_2eop_24s851371283x356629733_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s851371283x356629733_entry, 5, 0};

V g_co_2eop_24s851371283x356629733(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s851371283x356629733_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s851371283x356629733_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s851371283x356629733_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s851371283x356629733_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s851371283x356629733_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s851371283x356629733(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s851371283x356629733_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s851371283x356629733_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s851371283x356629733_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s851371283x356629733_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s851371283x356629733_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s851371283x356629733_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s851371283x356629733_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s851371283x356629733_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2424 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_2422, ((V)&g_co_2eop_24s851371283x356629733_str0)), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s851371283x356629733(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s695421809x762051105_lam1(V self, V *args);
V g_co_2eop_24s695421809x762051105_lam0(V self, V *args); static Clo g_co_2eop_24s695421809x762051105_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s695421809x762051105_lam0, 4, 0};
V g_co_2eop_24s695421809x762051105_lam3(V self, V *args);
V g_co_2eop_24s695421809x762051105_lam2(V self, V *args);
V g_co_2eop_24s695421809x762051105_lam4(V self, V *args);
V g_co_2eop_24s695421809x762051105_lam5(V self, V *args);
Clo g_co_2eop_24s695421809x762051105_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s695421809x762051105_entry, 10, 0};

V g_co_2eop_24s695421809x762051105(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s695421809x762051105_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s695421809x762051105_lam2, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s695421809x762051105_lam4, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s695421809x762051105_lam5, 1, 8, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s695421809x762051105_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s695421809x762051105(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a1); return r;
}
V g_co_2eop_24s695421809x762051105_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s695421809x762051105_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s695421809x762051105_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s695421809x762051105_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s695421809x762051105_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s695421809x762051105_lam3, 1, 2, (V[]){v_g_2416, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s695421809x762051105_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s695421809x762051105_lam5(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_a_2423);
  V v_t_2424 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1372695945x1822078628(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_lit_246;
  heff_room[1] = v_lit_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1938432363x1897732959_lam1(V self, V *args);
V g_co_2eop_24s1938432363x1897732959_lam0(V self, V *args); static Clo g_co_2eop_24s1938432363x1897732959_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1938432363x1897732959_lam0, 4, 0};
V g_co_2eop_24s1938432363x1897732959_lam3(V self, V *args);
V g_co_2eop_24s1938432363x1897732959_lam2(V self, V *args);
V g_co_2eop_24s1938432363x1897732959_lam4(V self, V *args);
V g_co_2eop_24s1938432363x1897732959_lam5(V self, V *args);
Clo g_co_2eop_24s1938432363x1897732959_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1938432363x1897732959_entry, 6, 0};

V g_co_2eop_24s1938432363x1897732959(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1938432363x1897732959_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1938432363x1897732959_lam2, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s1938432363x1897732959_lam4, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s1938432363x1897732959_lam5, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s1938432363x1897732959_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1938432363x1897732959(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s1938432363x1897732959_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1938432363x1897732959_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s1938432363x1897732959_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1938432363x1897732959_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1938432363x1897732959_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s1938432363x1897732959_lam3, 1, 2, (V[]){v_g_2412, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1938432363x1897732959_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1938432363x1897732959_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2419);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1199064485x1398611297(v_lit_240, v_lit_241, v_lit_242, v_lit_243));
}
V g_co_2eop_24s897039307x1692197561_lam1(V self, V *args);
V g_co_2eop_24s897039307x1692197561_lam0(V self, V *args); static Clo g_co_2eop_24s897039307x1692197561_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s897039307x1692197561_lam0, 4, 0};
V g_co_2eop_24s897039307x1692197561_lam3(V self, V *args);
V g_co_2eop_24s897039307x1692197561_lam2(V self, V *args);
V g_co_2eop_24s897039307x1692197561_lam4(V self, V *args);
V g_co_2eop_24s897039307x1692197561_lam5(V self, V *args);
Clo g_co_2eop_24s897039307x1692197561_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s897039307x1692197561_entry, 6, 0};

V g_co_2eop_24s897039307x1692197561(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s897039307x1692197561_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s897039307x1692197561_lam2, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s897039307x1692197561_lam4, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s897039307x1692197561_lam5, 1, 4, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243})});
}
V g_co_2eop_24s897039307x1692197561_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s897039307x1692197561(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_co_2eop_24s897039307x1692197561_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s897039307x1692197561_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s897039307x1692197561_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s897039307x1692197561_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s897039307x1692197561_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s897039307x1692197561_lam3, 1, 2, (V[]){v_g_2412, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s897039307x1692197561_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s897039307x1692197561_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2419);
  V v_t_2420 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V r_ = (g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(a_0, a_1)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2420;
  heff_room[0] = v_lit_242;
  heff_room[1] = v_lit_243;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1615307314x262795202_lam1(V self, V *args);
V g_co_2eop_24s1615307314x262795202_lam0(V self, V *args); static Clo g_co_2eop_24s1615307314x262795202_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1615307314x262795202_lam0, 4, 0};
V g_co_2eop_24s1615307314x262795202_lam3(V self, V *args);
V g_co_2eop_24s1615307314x262795202_lam2(V self, V *args);
V g_co_2eop_24s1615307314x262795202_lam4(V self, V *args);
V g_co_2eop_24s1615307314x262795202_lam5(V self, V *args);
Clo g_co_2eop_24s1615307314x262795202_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1615307314x262795202_entry, 3, 0};

V g_co_2eop_24s1615307314x262795202(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1615307314x262795202_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1615307314x262795202_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1615307314x262795202_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s1615307314x262795202_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s1615307314x262795202_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1615307314x262795202(a[0], a[1], a[2]);
}
V g_co_2eop_24s1615307314x262795202_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1615307314x262795202_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1615307314x262795202_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1615307314x262795202_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1615307314x262795202_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1615307314x262795202_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1615307314x262795202_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1615307314x262795202_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_RDone, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2040132903x129219385_lam1(V self, V *args);
V g_co_2eop_24s2040132903x129219385_lam0(V self, V *args); static Clo g_co_2eop_24s2040132903x129219385_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2040132903x129219385_lam0, 4, 0};
V g_co_2eop_24s2040132903x129219385_lam3(V self, V *args);
V g_co_2eop_24s2040132903x129219385_lam2(V self, V *args);
V g_co_2eop_24s2040132903x129219385_lam4(V self, V *args);
Clo g_co_2eop_24s2040132903x129219385_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s2040132903x129219385_entry, 3, 0};

V g_co_2eop_24s2040132903x129219385(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1914620224x1667922359_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s2040132903x129219385_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s2040132903x129219385_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s2040132903x129219385_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s2040132903x129219385_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s2040132903x129219385(a[0], a[1], a[2]);
}
V g_co_2eop_24s2040132903x129219385_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2040132903x129219385_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s2040132903x129219385_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2040132903x129219385_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s2040132903x129219385_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s2040132903x129219385_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s2040132903x129219385_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s638448470x237911921_lam0(V self, V *args); static Clo g_co_2eplus_24s638448470x237911921_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s638448470x237911921_lam0, 3, 0};
V g_co_2eplus_24s638448470x237911921_lam1(V self, V *args); static Clo g_co_2eplus_24s638448470x237911921_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s638448470x237911921_lam1, 4, 0};

static V g_co_2eplus_24s638448470x237911921_val;
static HEFF_ONCE g_co_2eplus_24s638448470x237911921_st;
static V g_co_2eplus_24s638448470x237911921_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s638448470x237911921_lam0_clo), ((V)&g_co_2eplus_24s638448470x237911921_lam1_clo)});
}
V g_co_2eplus_24s638448470x237911921_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s638448470x237911921_st)) return g_co_2eplus_24s638448470x237911921_val;
  return heff_global(&g_co_2eplus_24s638448470x237911921_val, &g_co_2eplus_24s638448470x237911921_st, g_co_2eplus_24s638448470x237911921_init);
}
V g_co_2eplus_24s638448470x237911921_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_green_2egreen_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s638448470x237911921_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Spawn: {
      V v_c_2412 = heff_field(v_x_2411, 0);
      V v_x_2413 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Spawn = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_nt_249, 1, (V[]){v_c_2412}));
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Spawn, TAG_Spawn, 2, (V[]){v_t_2414, v_x_2413});
      break;
    }
    case TAG_Yield: {
      V v_x_2415 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24Yield = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Yield, TAG_Yield, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_NewChan: {
      V v_k_2416 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24NewChan = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24NewChan, TAG_NewChan, 1, (V[]){v_k_2416});
      break;
    }
    case TAG_Send: {
      V v_ch_2417 = heff_field(v_x_2411, 0);
      V v_v_2418 = heff_field(v_x_2411, 1);
      V v_x_2419 = heff_field(v_x_2411, 2);
      V v_ru_24x_2411_24Send = heff_take_reuse_n(v_x_2411, 7ULL, 3);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Send, TAG_Send, 3, (V[]){v_ch_2417, v_v_2418, v_x_2419});
      break;
    }
    case TAG_Recv: {
      V v_ch_2420 = heff_field(v_x_2411, 0);
      V v_k_2421 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Recv = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Recv, TAG_Recv, 2, (V[]){v_ch_2420, v_k_2421});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s781597930x1570803347_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_y_2423}));
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2424});
  }
  default: return heff_nomatch(v_p_2410);
  }
}