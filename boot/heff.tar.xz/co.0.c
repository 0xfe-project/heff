// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Begin 41697
#define TAG_Catch 6517
#define TAG_Draw 50003
#define TAG_ErrColor 60683
#define TAG_Finish 61316
#define TAG_Get 18914
#define TAG_Interactive 42932
#define TAG_IsTerminal 53507
#define TAG_Left 13886
#define TAG_Measure 52418
#define TAG_NewChan 9424
#define TAG_RDone 16778
#define TAG_ReadInput 54226
#define TAG_Recv 61489
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Sleep 25229
#define TAG_Spawn 10053
#define TAG_Throw 56084
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(void);
V g_co_2e_3c_2b_3e_24s1117694589x1745783676_get(void);
V g_co_2e_3c_2b_3e_24s1126303732x722647959_get(void);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(void);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a);
extern Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo;
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(void);
V g_co_2e_3c_2b_3e_24s1939119747x628370105_get(void);
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void);
V g_co_2e_3c_2b_3e_24s421304345x1483988127_get(void);
V g_co_2e_3c_2b_3e_24s787064636x102052035_get(void);
V g_co_2ebind_24s1464300710x102529052(V, V, V);
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a);
extern Clo g_co_2ebind_24s1464300710x102529052_clo;
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_co_2eop_24s1138723349x835120997(V, V, V);
V g_co_2eop_24s1138723349x835120997_entry(V self, V *a);
extern Clo g_co_2eop_24s1138723349x835120997_clo;
V g_co_2eop_24s1191249873x1860951653(V, V, V, V, V);
V g_co_2eop_24s1191249873x1860951653_entry(V self, V *a);
extern Clo g_co_2eop_24s1191249873x1860951653_clo;
V g_co_2eop_24s1204515794x2100690815(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1204515794x2100690815_entry(V self, V *a);
extern Clo g_co_2eop_24s1204515794x2100690815_clo;
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s1979766345x1806196139(V, V, V);
V g_co_2eop_24s1979766345x1806196139_entry(V self, V *a);
extern Clo g_co_2eop_24s1979766345x1806196139_clo;
V g_co_2eop_24s293084245x615760588(V, V, V);
V g_co_2eop_24s293084245x615760588_entry(V self, V *a);
extern Clo g_co_2eop_24s293084245x615760588_clo;
V g_co_2eop_24s298669585x337250861(V, V, V);
V g_co_2eop_24s298669585x337250861_entry(V self, V *a);
extern Clo g_co_2eop_24s298669585x337250861_clo;
V g_co_2eop_24s321980040x1154251472(V, V, V, V, V);
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a);
extern Clo g_co_2eop_24s321980040x1154251472_clo;
V g_co_2eop_24s358005445x1922844939(V, V, V, V);
V g_co_2eop_24s358005445x1922844939_entry(V self, V *a);
extern Clo g_co_2eop_24s358005445x1922844939_clo;
V g_co_2eop_24s511476643x1802627326(V, V, V);
V g_co_2eop_24s511476643x1802627326_entry(V self, V *a);
extern Clo g_co_2eop_24s511476643x1802627326_clo;
V g_co_2eop_24s574817332x141721203(V);
V g_co_2eop_24s574817332x141721203_entry(V self, V *a);
extern Clo g_co_2eop_24s574817332x141721203_clo;
V g_co_2eop_24s710864882x261522381(V, V, V, V, V, V, V);
V g_co_2eop_24s710864882x261522381_entry(V self, V *a);
extern Clo g_co_2eop_24s710864882x261522381_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_green_2egreen_get(void);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2eterminal_2econsole_get(void);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam0(V self, V *args);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam2(V self, V *args);
Clo g_co_2e_3c_2b_3e_24s1585861108x1258949188_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry, 1, 0};

V g_co_2e_3c_2b_3e_24s1585861108x1258949188(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam0, 3, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam2, 4, 1, (V[]){v_k_240})});
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_entry(V self, V *a) {
  (void)self;
  return g_co_2e_3c_2b_3e_24s1585861108x1258949188(a[0]);
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam1(V self, V *args) {
  V v_s_249 = args[0];
  V v_h_247 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_g_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tr(heff_call(v_h_247, 1, (V[]){v_s_249}));
  V f_ = heff_get_n(v_m_241, 0, 1);
  heff_room[0] = v_g_242;
  heff_room[1] = v_t_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam0(V self, V *args) {
  V v_m_241 = args[0];
  V v_g_242 = args[1];
  V v_p_243 = args[2];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    heff_drop_rec(v_k_240, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_Throw: {
      V v_s_245 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24Throw = heff_take_reuse_n(v_x_244, 1ULL, 1);
      heff_drop_rec(v_m_241, 1);
      heff_drop(v_g_242);
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Throw, TAG_Throw, 1, (V[]){v_s_245});
      break;
    }
    case TAG_Catch: {
      V v_c_246 = heff_field(v_x_244, 0);
      V v_h_247 = heff_field(v_x_244, 1);
      V v_ru_24x_244_24Catch = heff_take_reuse_n(v_x_244, 3ULL, 2);
      V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_241, 0)), 2, (V[]){heff_dup(v_g_242), v_c_246}));
      v_t_2411 = heff_tag_at_n(v_ru_24x_244_24Catch, TAG_Catch, 2, (V[]){v_t_248, heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam1, 1, 3, (V[]){v_h_247, v_m_241, v_g_242})});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    return heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_2411});
  }
  case TAG_InR: {
    V v_y_2412 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 3, (V[]){v_m_241, v_g_242, v_y_2412}));
    return heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_243);
  }
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam3(V self, V *args) {
  V v_s_2423 = args[0];
  V v_h_2421 = heff_env(self)[0];
  V v_nt_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tr(heff_call(v_h_2421, 1, (V[]){v_s_2423}));
  V f_ = v_nt_2416;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam2(V self, V *args) {
  V v_m_2414 = args[0];
  V v_n_2415 = args[1];
  V v_nt_2416 = args[2];
  V v_p_2417 = args[3];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    heff_drop(v_m_2414);
    heff_drop(v_n_2415);
    heff_drop_rec(v_k_240, 2);
    V v_t_2425;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_Throw: {
      V v_s_2419 = heff_field(v_x_2418, 0);
      V v_ru_24x_2418_24Throw = heff_take_reuse_n(v_x_2418, 1ULL, 1);
      heff_drop(v_nt_2416);
      v_t_2425 = heff_tag_at_n(v_ru_24x_2418_24Throw, TAG_Throw, 1, (V[]){v_s_2419});
      break;
    }
    case TAG_Catch: {
      V v_c_2420 = heff_field(v_x_2418, 0);
      V v_h_2421 = heff_field(v_x_2418, 1);
      V v_ru_24x_2418_24Catch = heff_take_reuse_n(v_x_2418, 3ULL, 2);
      V v_t_2422 = heff_tr(heff_call(heff_dup(v_nt_2416), 1, (V[]){v_c_2420}));
      v_t_2425 = heff_tag_at_n(v_ru_24x_2418_24Catch, TAG_Catch, 2, (V[]){v_t_2422, heff_clo_n(g_co_2e_3c_2b_3e_24s1585861108x1258949188_lam3, 1, 2, (V[]){v_h_2421, v_nt_2416})});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2425});
  }
  case TAG_InR: {
    V v_y_2426 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 4, (V[]){v_m_2414, v_n_2415, v_nt_2416, v_y_2426}));
    return heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2427});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args); static Clo g_co_2ebind_24s1831149655x1541910000_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_lam0, 1, 0};
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args);
Clo g_co_2ebind_24s1831149655x1541910000_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_entry, 3, 0};

V g_co_2ebind_24s1831149655x1541910000(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s1831149655x1541910000_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s1831149655x1541910000_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1831149655x1541910000(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args); static Clo g_co_2ebind_24s1464300710x102529052_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_lam1, 2, 0};
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args);
Clo g_co_2ebind_24s1464300710x102529052_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_entry, 3, 0};

V g_co_2ebind_24s1464300710x102529052(V v_c_240, V v_f_241, V v_z_242) {
top: ;
  return heff_tail(v_c_240, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_co_2ebind_24s1464300710x102529052_lam0, 1, 1, (V[]){v_f_241}), v_z_242});
}
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1464300710x102529052(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_244}), v_a_245});
}
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_241;
  heff_room[0] = v_x_243;
  heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[2] = ((V)&g_co_2ebind_24s1464300710x102529052_lam1_clo);
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s1126303732x722647959_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1126303732x722647959_st;
static V g_co_2e_3c_2b_3e_24s1126303732x722647959_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1126303732x722647959_st)) return g_co_2e_3c_2b_3e_24s1126303732x722647959_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1126303732x722647959_val, &g_co_2e_3c_2b_3e_24s1126303732x722647959_st, g_co_2e_3c_2b_3e_24s1126303732x722647959_init);
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24UseColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1126303732x722647959_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24ErrColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1126303732x722647959_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2428;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_InL: {
      V v_x_2422 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_x_2422}));
      v_t_2428 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2423});
      break;
    }
    case TAG_InR: {
      V v_y_2424 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24InR = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop(v_nt_2419);
      heff_drop_cell(v_ru_24p_2420_24InL, 1);
      V v_t_2427;
      switch (heff_tag_of(v_y_2424)) {
      case TAG_UseColor: {
        V v_k_2425 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24UseColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24UseColor, TAG_UseColor, 1, (V[]){v_k_2425});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2426 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24ErrColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24ErrColor, TAG_ErrColor, 1, (V[]){v_k_2426});
        break;
      }
      default: heff_nomatch(v_y_2424);
      }
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24InR, TAG_InR, 1, (V[]){v_t_2427});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_y_2429}));
    return heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2430});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s1255920378x2056408676_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1255920378x2056408676_st;
static V g_co_2e_3c_2b_3e_24s1255920378x2056408676_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1255920378x2056408676_st)) return g_co_2e_3c_2b_3e_24s1255920378x2056408676_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1255920378x2056408676_val, &g_co_2e_3c_2b_3e_24s1255920378x2056408676_st, g_co_2e_3c_2b_3e_24s1255920378x2056408676_init);
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1126303732x722647959_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24IsTerminal = heff_take_reuse_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_argv_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_argv_2413, v_lines_2414, heff_clo_n(g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_InL: {
      V v_x_2424 = heff_field(v_x_2423, 0);
      V v_ru_24x_2423_24InL = heff_take_reuse_n(v_x_2423, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_x_2424)) {
      case TAG_InL: {
        V v_x_2425 = heff_field(v_x_2424, 0);
        heff_take_n(v_x_2424, 1ULL, 1);
        V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2425}));
        v_t_2431 = heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2426});
        break;
      }
      case TAG_InR: {
        V v_y_2427 = heff_field(v_x_2424, 0);
        V v_ru_24x_2424_24InR = heff_take_reuse_n(v_x_2424, 1ULL, 1);
        heff_drop(v_m_2419);
        heff_drop(v_n_2420);
        heff_drop(v_nt_2421);
        heff_drop_cell(v_ru_24p_2422_24InL, 1);
        V v_t_2430;
        switch (heff_tag_of(v_y_2427)) {
        case TAG_UseColor: {
          V v_k_2428 = heff_field(v_y_2427, 0);
          V v_ru_24y_2427_24UseColor = heff_take_reuse_n(v_y_2427, 1ULL, 1);
          v_t_2430 = heff_tag_at_n(v_ru_24y_2427_24UseColor, TAG_UseColor, 1, (V[]){v_k_2428});
          break;
        }
        case TAG_ErrColor: {
          V v_k_2429 = heff_field(v_y_2427, 0);
          V v_ru_24y_2427_24ErrColor = heff_take_reuse_n(v_y_2427, 1ULL, 1);
          v_t_2430 = heff_tag_at_n(v_ru_24y_2427_24ErrColor, TAG_ErrColor, 1, (V[]){v_k_2429});
          break;
        }
        default: heff_nomatch(v_y_2427);
        }
        v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24InR, TAG_InR, 1, (V[]){v_t_2430});
        break;
      }
      default: heff_nomatch(v_x_2424);
      }
      v_t_2434 = heff_tag_at_n(v_ru_24x_2423_24InL, TAG_InL, 1, (V[]){v_t_2431});
      break;
    }
    case TAG_InR: {
      V v_y_2432 = heff_field(v_x_2423, 0);
      V v_ru_24x_2423_24InR = heff_take_reuse_n(v_x_2423, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2422_24InL, 1);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_y_2432}));
      v_t_2434 = heff_tag_at_n(v_ru_24x_2423_24InR, TAG_InR, 1, (V[]){v_t_2433});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2434});
  }
  case TAG_InR: {
    V v_y_2435 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2443;
    switch (heff_tag_of(v_y_2435)) {
    case TAG_IsTerminal: {
      V v_k_2436 = heff_field(v_y_2435, 0);
      V v_ru_24y_2435_24IsTerminal = heff_take_reuse_n(v_y_2435, 1ULL, 1);
      v_t_2443 = heff_tag_at_n(v_ru_24y_2435_24IsTerminal, TAG_IsTerminal, 1, (V[]){v_k_2436});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2437 = heff_field(v_y_2435, 0);
      V v_x_2438 = heff_field(v_y_2435, 1);
      V v_ru_24y_2435_24ShowLines = heff_take_reuse_n(v_y_2435, 3ULL, 2);
      v_t_2443 = heff_tag_at_n(v_ru_24y_2435_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2437, v_x_2438});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2439 = heff_field(v_y_2435, 0);
      V v_argv_2440 = heff_field(v_y_2435, 1);
      V v_lines_2441 = heff_field(v_y_2435, 2);
      V v_k_2442 = heff_field(v_y_2435, 3);
      V v_ru_24y_2435_24ShowRun = heff_take_reuse_n(v_y_2435, 15ULL, 4);
      v_t_2443 = heff_tag_at_n(v_ru_24y_2435_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2439, v_argv_2440, v_lines_2441, v_k_2442});
      break;
    }
    default: heff_nomatch(v_y_2435);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2443});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2e_3c_2b_3e_24s421304345x1483988127_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s421304345x1483988127_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s421304345x1483988127_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s421304345x1483988127_lam1(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s421304345x1483988127_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s421304345x1483988127_lam1, 4, 0};

static V g_co_2e_3c_2b_3e_24s421304345x1483988127_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s421304345x1483988127_st;
static V g_co_2e_3c_2b_3e_24s421304345x1483988127_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s421304345x1483988127_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s421304345x1483988127_lam1_clo)});
}
V g_co_2e_3c_2b_3e_24s421304345x1483988127_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s421304345x1483988127_st)) return g_co_2e_3c_2b_3e_24s421304345x1483988127_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s421304345x1483988127_val, &g_co_2e_3c_2b_3e_24s421304345x1483988127_st, g_co_2e_3c_2b_3e_24s421304345x1483988127_init);
}
V g_co_2e_3c_2b_3e_24s421304345x1483988127_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_248 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eterminal_2econsole_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_246}));
      v_t_248 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_247});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_248});
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2413;
    switch (heff_tag_of(v_y_249)) {
    case TAG_Sleep: {
      V v_ms_2410 = heff_field(v_y_249, 0);
      V v_x_2411 = heff_field(v_y_249, 1);
      V v_ru_24y_249_24Sleep = heff_take_reuse_n(v_y_249, 3ULL, 2);
      V v_t_2412 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2411}));
      v_t_2413 = heff_tag_at_n(v_ru_24y_249_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2410, v_t_2412});
      break;
    }
    default: heff_nomatch(v_y_249);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s421304345x1483988127_lam1(V self, V *args) {
  V v_m_2414 = args[0];
  V v_n_2415 = args[1];
  V v_nt_2416 = args[2];
  V v_p_2417 = args[3];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InL = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2430;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_InL: {
      V v_x_2419 = heff_field(v_x_2418, 0);
      heff_take_n(v_x_2418, 1ULL, 1);
      V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(), 1)), 4, (V[]){v_m_2414, v_n_2415, v_nt_2416, v_x_2419}));
      v_t_2430 = heff_tag_at_n(v_ru_24p_2417_24InL, TAG_InL, 1, (V[]){v_t_2420});
      break;
    }
    case TAG_InR: {
      V v_y_2421 = heff_field(v_x_2418, 0);
      V v_ru_24x_2418_24InR = heff_take_reuse_n(v_x_2418, 1ULL, 1);
      heff_drop(v_m_2414);
      heff_drop(v_n_2415);
      heff_drop(v_nt_2416);
      heff_drop_cell(v_ru_24p_2417_24InL, 1);
      V v_t_2429;
      switch (heff_tag_of(v_y_2421)) {
      case TAG_Interactive: {
        V v_k_2422 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Interactive = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Interactive, TAG_Interactive, 1, (V[]){v_k_2422});
        break;
      }
      case TAG_Begin: {
        V v_k_2423 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Begin = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Begin, TAG_Begin, 1, (V[]){v_k_2423});
        break;
      }
      case TAG_Finish: {
        V v_x_2424 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Finish = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Finish, TAG_Finish, 1, (V[]){v_x_2424});
        break;
      }
      case TAG_Measure: {
        V v_k_2425 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24Measure = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Measure, TAG_Measure, 1, (V[]){v_k_2425});
        break;
      }
      case TAG_ReadInput: {
        V v_k_2426 = heff_field(v_y_2421, 0);
        V v_ru_24y_2421_24ReadInput = heff_take_reuse_n(v_y_2421, 1ULL, 1);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24ReadInput, TAG_ReadInput, 1, (V[]){v_k_2426});
        break;
      }
      case TAG_Draw: {
        V v_s_2427 = heff_field(v_y_2421, 0);
        V v_x_2428 = heff_field(v_y_2421, 1);
        V v_ru_24y_2421_24Draw = heff_take_reuse_n(v_y_2421, 3ULL, 2);
        v_t_2429 = heff_tag_at_n(v_ru_24y_2421_24Draw, TAG_Draw, 2, (V[]){v_s_2427, v_x_2428});
        break;
      }
      default: heff_nomatch(v_y_2421);
      }
      v_t_2430 = heff_tag_at_n(v_ru_24x_2418_24InR, TAG_InR, 1, (V[]){v_t_2429});
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2430});
  }
  case TAG_InR: {
    V v_y_2431 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    heff_drop(v_m_2414);
    heff_drop(v_n_2415);
    heff_drop(v_nt_2416);
    V v_t_2434;
    switch (heff_tag_of(v_y_2431)) {
    case TAG_Sleep: {
      V v_ms_2432 = heff_field(v_y_2431, 0);
      V v_x_2433 = heff_field(v_y_2431, 1);
      V v_ru_24y_2431_24Sleep = heff_take_reuse_n(v_y_2431, 3ULL, 2);
      v_t_2434 = heff_tag_at_n(v_ru_24y_2431_24Sleep, TAG_Sleep, 2, (V[]){v_ms_2432, v_x_2433});
      break;
    }
    default: heff_nomatch(v_y_2431);
    }
    return heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2434});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_co_2eop_24s358005445x1922844939_lam1(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam0(V self, V *args); static Clo g_co_2eop_24s358005445x1922844939_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s358005445x1922844939_lam0, 4, 0};
V g_co_2eop_24s358005445x1922844939_lam3(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam2(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam4(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam5(V self, V *args);
Clo g_co_2eop_24s358005445x1922844939_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s358005445x1922844939_entry, 4, 0};

V g_co_2eop_24s358005445x1922844939(V v_p_240, V v_k_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2421;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s358005445x1922844939_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s358005445x1922844939_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s358005445x1922844939_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_x_244}));
    v_t_2421 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2416});
    break;
  }
  case TAG_InR: {
    V v_y_2417 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2420;
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Send: {
      V v_rq_2418 = heff_field(v_y_2417, 0);
      V v_k_2419 = heff_field(v_y_2417, 1);
      V v_ru_24y_2417_24Send = heff_take_reuse_n(v_y_2417, 3ULL, 2);
      v_t_2420 = heff_tag_at_n(v_ru_24y_2417_24Send, TAG_Send, 2, (V[]){v_rq_2418, v_k_2419});
      break;
    }
    default: heff_nomatch(v_y_2417);
    }
    v_t_2421 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2420});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2421}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s358005445x1922844939_lam5, 1, 3, (V[]){v_k_241, v_hd_242, v_k2_243})});
}
V g_co_2eop_24s358005445x1922844939_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s358005445x1922844939(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s358005445x1922844939_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s358005445x1922844939_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s358005445x1922844939_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s358005445x1922844939_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s358005445x1922844939_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s358005445x1922844939_lam3, 1, 2, (V[]){v_g_2411, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s358005445x1922844939_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s358005445x1922844939_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  heff_room[0] = v_x_2423;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k2_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s298669585x337250861_lam1(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam0(V self, V *args); static Clo g_co_2eop_24s298669585x337250861_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s298669585x337250861_lam0, 4, 0};
V g_co_2eop_24s298669585x337250861_lam3(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam2(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam4(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam5(V self, V *args);
Clo g_co_2eop_24s298669585x337250861_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s298669585x337250861_entry, 3, 0};

V g_co_2eop_24s298669585x337250861(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s298669585x337250861_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s298669585x337250861_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s298669585x337250861_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s298669585x337250861_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s298669585x337250861_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s298669585x337250861(a[0], a[1], a[2]);
}
V g_co_2eop_24s298669585x337250861_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s298669585x337250861_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s298669585x337250861_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s298669585x337250861_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s298669585x337250861_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s298669585x337250861_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s298669585x337250861_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s298669585x337250861_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1138723349x835120997_lam0(V self, V *args);
V g_co_2eop_24s1138723349x835120997_lam2(V self, V *args);
V g_co_2eop_24s1138723349x835120997_lam1(V self, V *args); static Clo g_co_2eop_24s1138723349x835120997_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1138723349x835120997_lam1, 4, 0};
V g_co_2eop_24s1138723349x835120997_lam4(V self, V *args);
V g_co_2eop_24s1138723349x835120997_lam3(V self, V *args);
V g_co_2eop_24s1138723349x835120997_lam5(V self, V *args);
Clo g_co_2eop_24s1138723349x835120997_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1138723349x835120997_entry, 3, 0};

V g_co_2eop_24s1138723349x835120997(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s1138723349x835120997_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1138723349x835120997_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1138723349x835120997_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1138723349x835120997_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, v_k2_242});
}
V g_co_2eop_24s1138723349x835120997_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1138723349x835120997(a[0], a[1], a[2]);
}
V g_co_2eop_24s1138723349x835120997_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1138723349x835120997_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1138723349x835120997_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s1138723349x835120997_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1138723349x835120997_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1138723349x835120997_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s1138723349x835120997_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1138723349x835120997_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s321980040x1154251472_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_co_2eop_24s321980040x1154251472_str1, 1, "\012");
V g_co_2eop_24s321980040x1154251472_lam1(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam0(V self, V *args); static Clo g_co_2eop_24s321980040x1154251472_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s321980040x1154251472_lam0, 4, 0};
V g_co_2eop_24s321980040x1154251472_lam3(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam2(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam4(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam5(V self, V *args);
Clo g_co_2eop_24s321980040x1154251472_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s321980040x1154251472_entry, 5, 0};

V g_co_2eop_24s321980040x1154251472(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s321980040x1154251472_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s321980040x1154251472_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s321980040x1154251472_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s321980040x1154251472_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s321980040x1154251472(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s321980040x1154251472_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s321980040x1154251472_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s321980040x1154251472_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s321980040x1154251472_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s321980040x1154251472_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s321980040x1154251472_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s321980040x1154251472_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s321980040x1154251472_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_e_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_co_2eop_24s321980040x1154251472_str0), v_e_2422), ((V)&g_co_2eop_24s321980040x1154251472_str1));
    V v_t_2425 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_WriteErr, 2, (V[]){v_t_2424, NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    return (g_co_2eop_24s321980040x1154251472(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s574817332x141721203_lam0(V self, V *args);
V g_co_2eop_24s574817332x141721203_lam2(V self, V *args);
V g_co_2eop_24s574817332x141721203_lam1(V self, V *args); static Clo g_co_2eop_24s574817332x141721203_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s574817332x141721203_lam1, 4, 0};
V g_co_2eop_24s574817332x141721203_lam4(V self, V *args);
V g_co_2eop_24s574817332x141721203_lam3(V self, V *args); static Clo g_co_2eop_24s574817332x141721203_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s574817332x141721203_lam3, 4, 0};
V g_co_2eop_24s574817332x141721203_lam5(V self, V *args); static Clo g_co_2eop_24s574817332x141721203_lam5_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s574817332x141721203_lam5, 1, 0};
V g_co_2eop_24s574817332x141721203_lam7(V self, V *args);
V g_co_2eop_24s574817332x141721203_lam6(V self, V *args);
Clo g_co_2eop_24s574817332x141721203_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s574817332x141721203_entry, 1, 0};

V g_co_2eop_24s574817332x141721203(V v_p_240) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_241 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Throw: {
      V v_s_242 = heff_field(v_x_241, 0);
      V v_ru_24x_241_24Throw = heff_take_reuse_n(v_x_241, 1ULL, 1);
      v_t_248 = heff_tag_at_n(v_ru_24x_241_24Throw, TAG_Throw, 1, (V[]){v_s_242});
      break;
    }
    case TAG_Catch: {
      V v_c_243 = heff_field(v_x_241, 0);
      V v_h_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24Catch = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_245 = heff_tr(heff_call(v_c_243, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0))}));
      v_t_248 = heff_tag_at_n(v_ru_24x_241_24Catch, TAG_Catch, 2, (V[]){v_t_245, heff_clo_n(g_co_2eop_24s574817332x141721203_lam0, 1, 1, (V[]){v_h_244})});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    v_t_2426 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_248});
    break;
  }
  case TAG_InR: {
    V v_y_249 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s574817332x141721203_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s574817332x141721203_lam3_clo)}), ((V)&g_co_2eop_24s574817332x141721203_lam5_clo), v_y_249}));
    v_t_2426 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2425});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_m_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 2)), 1, (V[]){v_t_2426}));
  return heff_clo_n(g_co_2eop_24s574817332x141721203_lam6, 2, 1, (V[]){v_m_2427});
}
V g_co_2eop_24s574817332x141721203_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s574817332x141721203(a[0]);
}
V g_co_2eop_24s574817332x141721203_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_247 = heff_tr(heff_call(v_h_244, 1, (V[]){v_s_246}));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(g_exception_2eattempted_24s85350750x49672201_get());
  heff_room[1] = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s574817332x141721203_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s574817332x141721203_lam1(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s574817332x141721203_lam2, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s574817332x141721203_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_g_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    heff_drop(v_g_2416);
    V f_ = v_k_2419;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    V v_x_2423 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_y_2422}));
    V f_ = v_k_2419;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_co_2eop_24s574817332x141721203_lam3(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_2418 = args[2];
  V v_k_2419 = args[3];
  V f_ = v_m_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_co_2eop_24s574817332x141721203_lam4, 1, 2, (V[]){v_k_2419, v_g_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s574817332x141721203_lam5(V self, V *args) {
  V v_c_2424 = args[0];
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(g_exception_2eattempted_24s85350750x49672201_get());
  heff_room[1] = heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0));
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s574817332x141721203_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_x_2431 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    V f_ = v_k_2429;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_x_2431});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    V v_a_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_y_2432; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V f_ = v_k_2429;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_a_2433});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_co_2eop_24s574817332x141721203_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_m_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_co_2eop_24s574817332x141721203_lam7, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s710864882x261522381_lam1(V self, V *args);
V g_co_2eop_24s710864882x261522381_lam0(V self, V *args); static Clo g_co_2eop_24s710864882x261522381_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s710864882x261522381_lam0, 4, 0};
V g_co_2eop_24s710864882x261522381_lam3(V self, V *args);
V g_co_2eop_24s710864882x261522381_lam2(V self, V *args);
V g_co_2eop_24s710864882x261522381_lam4(V self, V *args);
V g_co_2eop_24s710864882x261522381_lam5(V self, V *args);
Clo g_co_2eop_24s710864882x261522381_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s710864882x261522381_entry, 7, 0};

V g_co_2eop_24s710864882x261522381(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_p_245, V v_hd_246) {
top: ;
  V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s710864882x261522381_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s710864882x261522381_lam2, 2, 1, (V[]){heff_dup(v_hd_246)})}), heff_clo_n(g_co_2eop_24s710864882x261522381_lam4, 1, 1, (V[]){heff_dup(v_hd_246)}), v_p_245}));
  V v_t_2419 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2418}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2419, heff_clo_n(g_co_2eop_24s710864882x261522381_lam5, 1, 5, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244})});
}
V g_co_2eop_24s710864882x261522381_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s710864882x261522381(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_co_2eop_24s710864882x261522381_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2412 = heff_tr(heff_call(v_g_247, 1, (V[]){v_x_2411}));
  V f_ = v_k_2410;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s710864882x261522381_lam0(V self, V *args) {
  V v_g_247 = args[0];
  V v_c_248 = args[1];
  V v_hd_249 = args[2];
  V v_k_2410 = args[3];
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_co_2eop_24s710864882x261522381_lam1, 1, 2, (V[]){v_g_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s710864882x261522381_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_2413 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_g_2413, 1, (V[]){v_x_2415}));
  V f_ = heff_get_n(v_hd_246, 0, 3);
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s710864882x261522381_lam2(V self, V *args) {
  V v_g_2413 = args[0];
  V v_m_2414 = args[1];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_m_2414;
  args[1] = heff_clo_n(g_co_2eop_24s710864882x261522381_lam3, 1, 2, (V[]){v_g_2413, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s710864882x261522381_lam4(V self, V *args) {
  V v_c_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_get_n(v_hd_246, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s710864882x261522381_lam5(V self, V *args) {
  V v_a_2420 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_a_2420);
  V v_t_2421 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V r_ = (g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(a_0, a_1, a_2)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2421;
  heff_room[0] = v_lit_243;
  heff_room[1] = v_lit_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s1191249873x1860951653_str0, 1, "\012");
V g_co_2eop_24s1191249873x1860951653_lam1(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam0(V self, V *args); static Clo g_co_2eop_24s1191249873x1860951653_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1191249873x1860951653_lam0, 4, 0};
V g_co_2eop_24s1191249873x1860951653_lam3(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam2(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam4(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam5(V self, V *args);
Clo g_co_2eop_24s1191249873x1860951653_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1191249873x1860951653_entry, 5, 0};

V g_co_2eop_24s1191249873x1860951653(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1191249873x1860951653_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam2, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam4, 1, 1, (V[]){heff_dup(v_hd_244)}), v_p_243}));
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2417, heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam5, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1191249873x1860951653_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1191249873x1860951653(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1191249873x1860951653_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1191249873x1860951653_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1191249873x1860951653_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1191249873x1860951653_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam3, 1, 2, (V[]){v_g_2411, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1191249873x1860951653_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1191249873x1860951653_lam5(V self, V *args) {
  V v_a_2418 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2418);
  V v_x1_2419 = v_lit_240;
  V v_p_2420 = v_lit_241;
  V v_p_2421 = v_lit_242;
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_Nil: {
    heff_drop(v_p_2420);
    V f_ = v_p_2421;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2422 = heff_field(v_x1_2419, 0);
    V v_rest_2423 = heff_field(v_x1_2419, 1);
    V v_ru_24x1_2419_24Cons = heff_take_reuse_n(v_x1_2419, 3ULL, 2);
    V v_t_2424 = heff_tag_at_n(v_ru_24x1_2419_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_2422, ((V)&g_co_2eop_24s1191249873x1860951653_str0)), NTAG(TAG_MkUnit)});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
    return (g_co_2eop_24s1191249873x1860951653(v_rest_2423, heff_dup(v_p_2420), v_p_2421, heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_p_2420));
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
V g_co_2eop_24s1204515794x2100690815_lam1(V self, V *args);
V g_co_2eop_24s1204515794x2100690815_lam0(V self, V *args); static Clo g_co_2eop_24s1204515794x2100690815_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1204515794x2100690815_lam0, 4, 0};
V g_co_2eop_24s1204515794x2100690815_lam3(V self, V *args);
V g_co_2eop_24s1204515794x2100690815_lam2(V self, V *args);
V g_co_2eop_24s1204515794x2100690815_lam4(V self, V *args);
V g_co_2eop_24s1204515794x2100690815_lam5(V self, V *args);
Clo g_co_2eop_24s1204515794x2100690815_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1204515794x2100690815_entry, 8, 0};

V g_co_2eop_24s1204515794x2100690815(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1204515794x2100690815_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1204515794x2100690815_lam2, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s1204515794x2100690815_lam4, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2420, heff_clo_n(g_co_2eop_24s1204515794x2100690815_lam5, 1, 6, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s1204515794x2100690815_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1204515794x2100690815(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_co_2eop_24s1204515794x2100690815_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_tr(heff_call(v_g_248, 1, (V[]){v_x_2412}));
  V f_ = v_k_2411;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1204515794x2100690815_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_c_249 = args[1];
  V v_hd_2410 = args[2];
  V v_k_2411 = args[3];
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1204515794x2100690815_lam1, 1, 2, (V[]){v_g_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1204515794x2100690815_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2416}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1204515794x2100690815_lam2(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2415;
  args[1] = heff_clo_n(g_co_2eop_24s1204515794x2100690815_lam3, 1, 2, (V[]){v_g_2414, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1204515794x2100690815_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1204515794x2100690815_lam5(V self, V *args) {
  V v_a_2421 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2421);
  return (g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245));
}
V g_co_2eop_24s293084245x615760588_lam1(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam0(V self, V *args); static Clo g_co_2eop_24s293084245x615760588_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s293084245x615760588_lam0, 4, 0};
V g_co_2eop_24s293084245x615760588_lam3(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam2(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam4(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam5(V self, V *args);
Clo g_co_2eop_24s293084245x615760588_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s293084245x615760588_entry, 3, 0};

V g_co_2eop_24s293084245x615760588(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s293084245x615760588_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s293084245x615760588_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s293084245x615760588_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s293084245x615760588_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s293084245x615760588_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s293084245x615760588(a[0], a[1], a[2]);
}
V g_co_2eop_24s293084245x615760588_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s293084245x615760588_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s293084245x615760588_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s293084245x615760588_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s293084245x615760588_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s293084245x615760588_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s293084245x615760588_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s293084245x615760588_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_RDone, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1939119747x628370105_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1939119747x628370105_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam3(V self, V *args);
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam2(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1939119747x628370105_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1939119747x628370105_lam2, 4, 0};

static V g_co_2e_3c_2b_3e_24s1939119747x628370105_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1939119747x628370105_st;
static V g_co_2e_3c_2b_3e_24s1939119747x628370105_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1939119747x628370105_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1939119747x628370105_lam2_clo)});
}
V g_co_2e_3c_2b_3e_24s1939119747x628370105_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1939119747x628370105_st)) return g_co_2e_3c_2b_3e_24s1939119747x628370105_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1939119747x628370105_val, &g_co_2e_3c_2b_3e_24s1939119747x628370105_st, g_co_2e_3c_2b_3e_24s1939119747x628370105_init);
}
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_245}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2e_3c_2b_3e_24s1939119747x628370105_lam1, 1, 3, (V[]){v_h_246, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InL = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_242_24InR, 1);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(g_green_2egreen_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_2412}));
      v_t_2416 = heff_tag_at_n(v_ru_24y_2411_24InL, TAG_InL, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_InR: {
      V v_y_2414 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2414}));
      v_t_2416 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2415});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  V v_h_2424 = heff_env(self)[0];
  V v_nt_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tr(heff_call(v_h_2424, 1, (V[]){v_s_2426}));
  V f_ = v_nt_2419;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1939119747x628370105_lam2(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_m_2417);
    heff_drop(v_n_2418);
    V v_t_2428;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_Throw: {
      V v_s_2422 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24Throw = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_nt_2419);
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24Throw, TAG_Throw, 1, (V[]){v_s_2422});
      break;
    }
    case TAG_Catch: {
      V v_c_2423 = heff_field(v_x_2421, 0);
      V v_h_2424 = heff_field(v_x_2421, 1);
      V v_ru_24x_2421_24Catch = heff_take_reuse_n(v_x_2421, 3ULL, 2);
      V v_t_2425 = heff_tr(heff_call(heff_dup(v_nt_2419), 1, (V[]){v_c_2423}));
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24Catch, TAG_Catch, 2, (V[]){v_t_2425, heff_clo_n(g_co_2e_3c_2b_3e_24s1939119747x628370105_lam3, 1, 2, (V[]){v_h_2424, v_nt_2419})});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_y_2429)) {
    case TAG_InL: {
      V v_x_2430 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24InL = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop_cell(v_ru_24p_2420_24InR, 1);
      V v_t_2441;
      switch (heff_tag_of(v_x_2430)) {
      case TAG_Spawn: {
        V v_c_2431 = heff_field(v_x_2430, 0);
        V v_x_2432 = heff_field(v_x_2430, 1);
        V v_ru_24x_2430_24Spawn = heff_take_reuse_n(v_x_2430, 3ULL, 2);
        V v_t_2433 = heff_tr(heff_call(v_nt_2419, 1, (V[]){v_c_2431}));
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Spawn, TAG_Spawn, 2, (V[]){v_t_2433, v_x_2432});
        break;
      }
      case TAG_Yield: {
        V v_x_2434 = heff_field(v_x_2430, 0);
        V v_ru_24x_2430_24Yield = heff_take_reuse_n(v_x_2430, 1ULL, 1);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Yield, TAG_Yield, 1, (V[]){v_x_2434});
        break;
      }
      case TAG_NewChan: {
        V v_k_2435 = heff_field(v_x_2430, 0);
        V v_ru_24x_2430_24NewChan = heff_take_reuse_n(v_x_2430, 1ULL, 1);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24NewChan, TAG_NewChan, 1, (V[]){v_k_2435});
        break;
      }
      case TAG_Send: {
        V v_ch_2436 = heff_field(v_x_2430, 0);
        V v_v_2437 = heff_field(v_x_2430, 1);
        V v_x_2438 = heff_field(v_x_2430, 2);
        V v_ru_24x_2430_24Send = heff_take_reuse_n(v_x_2430, 7ULL, 3);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Send, TAG_Send, 3, (V[]){v_ch_2436, v_v_2437, v_x_2438});
        break;
      }
      case TAG_Recv: {
        V v_ch_2439 = heff_field(v_x_2430, 0);
        V v_k_2440 = heff_field(v_x_2430, 1);
        V v_ru_24x_2430_24Recv = heff_take_reuse_n(v_x_2430, 3ULL, 2);
        heff_drop(v_nt_2419);
        v_t_2441 = heff_tag_at_n(v_ru_24x_2430_24Recv, TAG_Recv, 2, (V[]){v_ch_2439, v_k_2440});
        break;
      }
      default: heff_nomatch(v_x_2430);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24y_2429_24InL, TAG_InL, 1, (V[]){v_t_2441});
      break;
    }
    case TAG_InR: {
      V v_y_2442 = heff_field(v_y_2429, 0);
      heff_take_n(v_y_2429, 1ULL, 1);
      V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_y_2442}));
      v_t_2444 = heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_y_2429);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eop_24s1979766345x1806196139_lam1(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam0(V self, V *args); static Clo g_co_2eop_24s1979766345x1806196139_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1979766345x1806196139_lam0, 4, 0};
V g_co_2eop_24s1979766345x1806196139_lam3(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam2(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam4(V self, V *args);
Clo g_co_2eop_24s1979766345x1806196139_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1979766345x1806196139_entry, 3, 0};

V g_co_2eop_24s1979766345x1806196139(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1939119747x628370105_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1979766345x1806196139_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s1979766345x1806196139_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1979766345x1806196139(a[0], a[1], a[2]);
}
V g_co_2eop_24s1979766345x1806196139_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1979766345x1806196139_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1979766345x1806196139_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1979766345x1806196139_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1979766345x1806196139_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1, 4, 0};

static V g_co_2e_3c_2b_3e_24s1957723276x2068325901_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1957723276x2068325901_st;
static V g_co_2e_3c_2b_3e_24s1957723276x2068325901_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1_clo)});
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1957723276x2068325901_st)) return g_co_2e_3c_2b_3e_24s1957723276x2068325901_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1957723276x2068325901_val, &g_co_2e_3c_2b_3e_24s1957723276x2068325901_st, g_co_2e_3c_2b_3e_24s1957723276x2068325901_init);
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_green_2egreen_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Spawn: {
      V v_c_2412 = heff_field(v_x_2411, 0);
      V v_x_2413 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Spawn = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_nt_249, 1, (V[]){v_c_2412}));
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Spawn, TAG_Spawn, 2, (V[]){v_t_2414, v_x_2413});
      break;
    }
    case TAG_Yield: {
      V v_x_2415 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24Yield = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Yield, TAG_Yield, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_NewChan: {
      V v_k_2416 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24NewChan = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24NewChan, TAG_NewChan, 1, (V[]){v_k_2416});
      break;
    }
    case TAG_Send: {
      V v_ch_2417 = heff_field(v_x_2411, 0);
      V v_v_2418 = heff_field(v_x_2411, 1);
      V v_x_2419 = heff_field(v_x_2411, 2);
      V v_ru_24x_2411_24Send = heff_take_reuse_n(v_x_2411, 7ULL, 3);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Send, TAG_Send, 3, (V[]){v_ch_2417, v_v_2418, v_x_2419});
      break;
    }
    case TAG_Recv: {
      V v_ch_2420 = heff_field(v_x_2411, 0);
      V v_k_2421 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Recv = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Recv, TAG_Recv, 2, (V[]){v_ch_2420, v_k_2421});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_y_2423}));
    return heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2424});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eop_24s1876960293x1282655859_lam1(V self, V *args);
V g_co_2eop_24s1876960293x1282655859_lam0(V self, V *args); static Clo g_co_2eop_24s1876960293x1282655859_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1876960293x1282655859_lam0, 4, 0};
V g_co_2eop_24s1876960293x1282655859_lam3(V self, V *args);
V g_co_2eop_24s1876960293x1282655859_lam2(V self, V *args);
V g_co_2eop_24s1876960293x1282655859_lam4(V self, V *args);
Clo g_co_2eop_24s1876960293x1282655859_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1876960293x1282655859_entry, 3, 0};

V g_co_2eop_24s1876960293x1282655859(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Spawn: {
      V v_c_244 = heff_field(v_x_243, 0);
      V v_x_245 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Spawn = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Spawn, TAG_Spawn, 2, (V[]){v_t_246, v_x_245});
      break;
    }
    case TAG_Yield: {
      V v_x_247 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Yield = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Yield, TAG_Yield, 1, (V[]){v_x_247});
      break;
    }
    case TAG_NewChan: {
      V v_k_248 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24NewChan = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24NewChan, TAG_NewChan, 1, (V[]){v_k_248});
      break;
    }
    case TAG_Send: {
      V v_ch_249 = heff_field(v_x_243, 0);
      V v_v_2410 = heff_field(v_x_243, 1);
      V v_x_2411 = heff_field(v_x_243, 2);
      V v_ru_24x_243_24Send = heff_take_reuse_n(v_x_243, 7ULL, 3);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Send, TAG_Send, 3, (V[]){v_ch_249, v_v_2410, v_x_2411});
      break;
    }
    case TAG_Recv: {
      V v_ch_2412 = heff_field(v_x_243, 0);
      V v_k_2413 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Recv = heff_take_reuse_n(v_x_243, 3ULL, 2);
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24Recv, TAG_Recv, 2, (V[]){v_ch_2412, v_k_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2414});
    break;
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1876960293x1282655859_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2415}));
    v_t_2428 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2427});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2428}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2429, v_k2_242});
}
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1876960293x1282655859(a[0], a[1], a[2]);
}
V g_co_2eop_24s1876960293x1282655859_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2420}));
  V f_ = v_k_2419;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1876960293x1282655859_lam0(V self, V *args) {
  V v_g_2416 = args[0];
  V v_c_2417 = args[1];
  V v_hd_2418 = args[2];
  V v_k_2419 = args[3];
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam1, 1, 2, (V[]){v_g_2416, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1876960293x1282655859_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_x_2424}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1876960293x1282655859_lam2(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2423;
  args[1] = heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam3, 1, 2, (V[]){v_g_2422, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1876960293x1282655859_lam4(V self, V *args) {
  V v_c_2426 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s511476643x1802627326_lam0(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam2(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam1(V self, V *args); static Clo g_co_2eop_24s511476643x1802627326_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s511476643x1802627326_lam1, 4, 0};
V g_co_2eop_24s511476643x1802627326_lam4(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam3(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam5(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam6(V self, V *args);
Clo g_co_2eop_24s511476643x1802627326_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s511476643x1802627326_entry, 3, 0};

V g_co_2eop_24s511476643x1802627326(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s511476643x1802627326_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1117694589x1745783676_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s511476643x1802627326_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s511476643x1802627326_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s511476643x1802627326_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, heff_clo_n(g_co_2eop_24s511476643x1802627326_lam6, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s511476643x1802627326_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s511476643x1802627326(a[0], a[1], a[2]);
}
V g_co_2eop_24s511476643x1802627326_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s511476643x1802627326_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s511476643x1802627326_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s511476643x1802627326_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s511476643x1802627326_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s511476643x1802627326_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s511476643x1802627326_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s511476643x1802627326_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s511476643x1802627326_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}