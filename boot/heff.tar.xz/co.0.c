// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Attempt 14217
#define TAG_Await 41810
#define TAG_Catch 6517
#define TAG_ErrColor 60683
#define TAG_Exit 20279
#define TAG_Get 18914
#define TAG_IsTerminal 53507
#define TAG_Log 24016
#define TAG_NewChan 9424
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Quit 47258
#define TAG_RDone 16778
#define TAG_Recv 61489
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Spawn 10053
#define TAG_Throw 56084
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_ret 322331
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(void);
V g_co_2e_3c_2b_3e_24s1126303732x722647959_get(void);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(void);
V g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(void);
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void);
V g_co_2e_3c_2b_3e_24s373441151x488264545_get(void);
V g_co_2e_3c_2b_3e_24s787064636x102052035_get(void);
V g_co_2ebind_24s1464300710x102529052(V, V, V);
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a);
extern Clo g_co_2ebind_24s1464300710x102529052_clo;
V g_co_2ebind_24s1831149655x1541910000(V, V, V);
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a);
extern Clo g_co_2ebind_24s1831149655x1541910000_clo;
V g_co_2eop_24s1191249873x1860951653(V, V, V, V, V);
V g_co_2eop_24s1191249873x1860951653_entry(V self, V *a);
extern Clo g_co_2eop_24s1191249873x1860951653_clo;
V g_co_2eop_24s1554102946x910234624(V, V, V);
V g_co_2eop_24s1554102946x910234624_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_clo;
V g_co_2eop_24s1554102946x910234624_24tok1(V, V, V, V);
V g_co_2eop_24s1554102946x910234624_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_24tok1_clo;
V g_co_2eop_24s1623411525x1925292021_24tok1(V, V, V, V);
V g_co_2eop_24s1623411525x1925292021_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s1623411525x1925292021_24tok1_clo;
V g_co_2eop_24s1876960293x1282655859(V, V, V);
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a);
extern Clo g_co_2eop_24s1876960293x1282655859_clo;
V g_co_2eop_24s1964021109x2127220916(V, V, V);
V g_co_2eop_24s1964021109x2127220916_entry(V self, V *a);
extern Clo g_co_2eop_24s1964021109x2127220916_clo;
V g_co_2eop_24s1979766345x1806196139(V, V, V);
V g_co_2eop_24s1979766345x1806196139_entry(V self, V *a);
extern Clo g_co_2eop_24s1979766345x1806196139_clo;
V g_co_2eop_24s293084245x615760588(V, V, V);
V g_co_2eop_24s293084245x615760588_entry(V self, V *a);
extern Clo g_co_2eop_24s293084245x615760588_clo;
V g_co_2eop_24s298669585x337250861(V, V, V);
V g_co_2eop_24s298669585x337250861_entry(V self, V *a);
extern Clo g_co_2eop_24s298669585x337250861_clo;
V g_co_2eop_24s321980040x1154251472(V, V, V, V, V);
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a);
extern Clo g_co_2eop_24s321980040x1154251472_clo;
V g_co_2eop_24s358005445x1922844939(V, V, V, V);
V g_co_2eop_24s358005445x1922844939_entry(V self, V *a);
extern Clo g_co_2eop_24s358005445x1922844939_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s511476643x1802627326(V, V, V);
V g_co_2eop_24s511476643x1802627326_entry(V self, V *a);
extern Clo g_co_2eop_24s511476643x1802627326_clo;
V g_co_2eop_24s747777320x140686263(V, V, V);
V g_co_2eop_24s747777320x140686263_entry(V self, V *a);
extern Clo g_co_2eop_24s747777320x140686263_clo;
V g_co_2eop_24s948886493x1367785519(V, V, V);
V g_co_2eop_24s948886493x1367785519_entry(V self, V *a);
extern Clo g_co_2eop_24s948886493x1367785519_clo;
V g_green_2egreen_get(void);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args); static Clo g_co_2ebind_24s1831149655x1541910000_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_lam0, 1, 0};
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args);
Clo g_co_2ebind_24s1831149655x1541910000_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1831149655x1541910000_entry, 3, 0};

V g_co_2ebind_24s1831149655x1541910000(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s1831149655x1541910000_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s1831149655x1541910000_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s1831149655x1541910000_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1831149655x1541910000(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1831149655x1541910000_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 9); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s1831149655x1541910000_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args); static Clo g_co_2ebind_24s1464300710x102529052_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_lam1, 2, 0};
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args);
Clo g_co_2ebind_24s1464300710x102529052_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s1464300710x102529052_entry, 3, 0};

V g_co_2ebind_24s1464300710x102529052(V v_c_240, V v_f_241, V v_z_242) {
top: ;
  return heff_tail(v_c_240, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_co_2ebind_24s1464300710x102529052_lam0, 1, 1, (V[]){v_f_241}), v_z_242});
}
V g_co_2ebind_24s1464300710x102529052_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s1464300710x102529052(a[0], a[1], a[2]);
}
V g_co_2ebind_24s1464300710x102529052_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_244}), v_a_245});
}
V g_co_2ebind_24s1464300710x102529052_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_241;
  heff_room[0] = v_x_243;
  heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[2] = ((V)&g_co_2ebind_24s1464300710x102529052_lam1_clo);
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s1126303732x722647959_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1126303732x722647959_st;
static V g_co_2e_3c_2b_3e_24s1126303732x722647959_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1126303732x722647959_st)) return g_co_2e_3c_2b_3e_24s1126303732x722647959_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1126303732x722647959_val, &g_co_2e_3c_2b_3e_24s1126303732x722647959_st, g_co_2e_3c_2b_3e_24s1126303732x722647959_init);
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1004019096x1485078532_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24UseColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1126303732x722647959_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24ErrColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1126303732x722647959_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1126303732x722647959_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_m_2417);
    heff_drop(v_n_2418);
    heff_drop(v_nt_2419);
    return heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_x_2421});
  }
  case TAG_InR: {
    V v_y_2422 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_y_2422}));
    return heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam1(V self, V *args);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3, 4, 0};

static V g_co_2e_3c_2b_3e_24s1255920378x2056408676_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1255920378x2056408676_st;
static V g_co_2e_3c_2b_3e_24s1255920378x2056408676_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3_clo)});
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1255920378x2056408676_st)) return g_co_2e_3c_2b_3e_24s1255920378x2056408676_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1255920378x2056408676_val, &g_co_2e_3c_2b_3e_24s1255920378x2056408676_st, g_co_2e_3c_2b_3e_24s1255920378x2056408676_init);
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam1(V self, V *args) {
  V v_b_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_b_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam2(V self, V *args) {
  V v_r_2416 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_r_2416}));
  V f_ = v_g_241;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1126303732x722647959_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop(v_m_240);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_IsTerminal: {
      V v_k_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24IsTerminal = heff_take_reuse_n(v_y_245, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24IsTerminal, TAG_IsTerminal, 1, (V[]){heff_clo_n(g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_249 = heff_field(v_y_245, 0);
      V v_x_2410 = heff_field(v_y_245, 1);
      V v_ru_24y_245_24ShowLines = heff_take_reuse_n(v_y_245, 3ULL, 2);
      V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_249, v_t_2411});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2412 = heff_field(v_y_245, 0);
      V v_argv_2413 = heff_field(v_y_245, 1);
      V v_lines_2414 = heff_field(v_y_245, 2);
      V v_k_2415 = heff_field(v_y_245, 3);
      V v_ru_24y_245_24ShowRun = heff_take_reuse_n(v_y_245, 15ULL, 4);
      v_t_2418 = heff_tag_at_n(v_ru_24y_245_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2412, v_argv_2413, v_lines_2414, heff_clo_n(g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam2, 1, 2, (V[]){v_k_2415, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1255920378x2056408676_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_InL: {
      V v_x_2424 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      heff_drop(v_m_2419);
      heff_drop(v_n_2420);
      heff_drop(v_nt_2421);
      v_t_2427 = heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_x_2424});
      break;
    }
    case TAG_InR: {
      V v_y_2425 = heff_field(v_x_2423, 0);
      V v_ru_24x_2423_24InR = heff_take_reuse_n(v_x_2423, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2422_24InL, 1);
      V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_y_2425}));
      v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24InR, TAG_InR, 1, (V[]){v_t_2426});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2427});
  }
  case TAG_InR: {
    V v_y_2428 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_y_2428});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2eop_24s358005445x1922844939_lam1(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam0(V self, V *args); static Clo g_co_2eop_24s358005445x1922844939_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s358005445x1922844939_lam0, 4, 0};
V g_co_2eop_24s358005445x1922844939_lam3(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam2(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam4(V self, V *args);
V g_co_2eop_24s358005445x1922844939_lam5(V self, V *args);
Clo g_co_2eop_24s358005445x1922844939_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s358005445x1922844939_entry, 4, 0};

V g_co_2eop_24s358005445x1922844939(V v_p_240, V v_k_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_244 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s358005445x1922844939_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s358005445x1922844939_lam2, 2, 1, (V[]){heff_dup(v_hd_242)})}), heff_clo_n(g_co_2eop_24s358005445x1922844939_lam4, 1, 1, (V[]){heff_dup(v_hd_242)}), v_x_244}));
    v_t_2418 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2416});
    break;
  }
  case TAG_InR: {
    V v_y_2417 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    v_t_2418 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_y_2417});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2418}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_2419, heff_clo_n(g_co_2eop_24s358005445x1922844939_lam5, 1, 3, (V[]){v_k_241, v_hd_242, v_k2_243})});
}
V g_co_2eop_24s358005445x1922844939_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s358005445x1922844939(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s358005445x1922844939_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2410 = heff_tr(heff_call(v_g_245, 1, (V[]){v_x_249}));
  V f_ = v_k_248;
  args[0] = v_x_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s358005445x1922844939_lam0(V self, V *args) {
  V v_g_245 = args[0];
  V v_c_246 = args[1];
  V v_hd_247 = args[2];
  V v_k_248 = args[3];
  V f_ = v_c_246;
  args[0] = v_hd_247;
  args[1] = heff_clo_n(g_co_2eop_24s358005445x1922844939_lam1, 1, 2, (V[]){v_g_245, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s358005445x1922844939_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tr(heff_call(v_g_2411, 1, (V[]){v_x_2413}));
  V f_ = heff_get_n(v_hd_242, 0, 3);
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s358005445x1922844939_lam2(V self, V *args) {
  V v_g_2411 = args[0];
  V v_m_2412 = args[1];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  args[0] = v_m_2412;
  args[1] = heff_clo_n(g_co_2eop_24s358005445x1922844939_lam3, 1, 2, (V[]){v_g_2411, v_hd_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s358005445x1922844939_lam4(V self, V *args) {
  V v_c_2415 = args[0];
  V v_hd_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_get_n(v_hd_242, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s358005445x1922844939_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k2_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  heff_room[0] = v_x_2420;
  heff_room[1] = v_hd_242;
  heff_room[2] = v_k2_243;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eop_24s298669585x337250861_lam0(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam2(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam1(V self, V *args); static Clo g_co_2eop_24s298669585x337250861_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s298669585x337250861_lam1, 4, 0};
V g_co_2eop_24s298669585x337250861_lam4(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam3(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam5(V self, V *args);
V g_co_2eop_24s298669585x337250861_lam6(V self, V *args);
Clo g_co_2eop_24s298669585x337250861_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s298669585x337250861_entry, 3, 0};

V g_co_2eop_24s298669585x337250861(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s298669585x337250861_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s298669585x337250861_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s298669585x337250861_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s298669585x337250861_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, heff_clo_n(g_co_2eop_24s298669585x337250861_lam6, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s298669585x337250861_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s298669585x337250861(a[0], a[1], a[2]);
}
V g_co_2eop_24s298669585x337250861_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s298669585x337250861_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s298669585x337250861_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s298669585x337250861_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s298669585x337250861_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s298669585x337250861_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s298669585x337250861_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s298669585x337250861_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s298669585x337250861_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_co_2eop_24s321980040x1154251472_str0, 20, "heff: not compiled: ");
HEFF_LIT(g_co_2eop_24s321980040x1154251472_str1, 1, "\012");
V g_co_2eop_24s321980040x1154251472_lam0(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam2(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam1(V self, V *args); static Clo g_co_2eop_24s321980040x1154251472_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s321980040x1154251472_lam1, 4, 0};
V g_co_2eop_24s321980040x1154251472_lam4(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam3(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam5(V self, V *args);
V g_co_2eop_24s321980040x1154251472_lam6(V self, V *args);
Clo g_co_2eop_24s321980040x1154251472_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s321980040x1154251472_entry, 5, 0};

V g_co_2eop_24s321980040x1154251472(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_245 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_Throw: {
      V v_s_246 = heff_field(v_x_245, 0);
      V v_ru_24x_245_24Throw = heff_take_reuse_n(v_x_245, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x_245_24Throw, TAG_Throw, 1, (V[]){v_s_246});
      break;
    }
    case TAG_Catch: {
      V v_c_247 = heff_field(v_x_245, 0);
      V v_h_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24Catch = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(v_hd_244), heff_dup(heff_rfield(v_hd_244, 0))}));
      v_t_2412 = heff_tag_at_n(v_ru_24x_245_24Catch, TAG_Catch, 2, (V[]){v_t_249, heff_clo_n(g_co_2eop_24s321980040x1154251472_lam0, 1, 2, (V[]){v_h_248, heff_dup(v_hd_244)})});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    v_t_2426 = heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_2412});
    break;
  }
  case TAG_InR: {
    V v_y_2413 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s321980040x1154251472_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s321980040x1154251472_lam3, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s321980040x1154251472_lam5, 1, 1, (V[]){heff_dup(v_hd_244)}), v_y_2413}));
    v_t_2426 = heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_2425});
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2427, heff_clo_n(g_co_2eop_24s321980040x1154251472_lam6, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s321980040x1154251472_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s321980040x1154251472(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s321980040x1154251472_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_h_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2411 = heff_tr(heff_call(v_h_248, 1, (V[]){v_s_2410}));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s321980040x1154251472_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2419 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2418}));
  V f_ = v_k_2417;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s321980040x1154251472_lam1(V self, V *args) {
  V v_g_2414 = args[0];
  V v_c_2415 = args[1];
  V v_hd_2416 = args[2];
  V v_k_2417 = args[3];
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_co_2eop_24s321980040x1154251472_lam2, 1, 2, (V[]){v_g_2414, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s321980040x1154251472_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_2420 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_g_2420, 1, (V[]){v_x_2422}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s321980040x1154251472_lam3(V self, V *args) {
  V v_g_2420 = args[0];
  V v_m_2421 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2421;
  args[1] = heff_clo_n(g_co_2eop_24s321980040x1154251472_lam4, 1, 2, (V[]){v_g_2420, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s321980040x1154251472_lam5(V self, V *args) {
  V v_c_2424 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s321980040x1154251472_lam6(V self, V *args) {
  V v_a_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2428);
  V v_x1_2429 = v_lit_240;
  V v_p_2430 = v_lit_241;
  V v_p_2431 = v_lit_242;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_Nil: {
    heff_drop(v_p_2430);
    V f_ = v_p_2431;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_e_2432 = heff_field(v_x1_2429, 0);
    V v_rest_2433 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24Cons = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_co_2eop_24s321980040x1154251472_str0), v_e_2432), ((V)&g_co_2eop_24s321980040x1154251472_str1));
    V v_t_2435 = heff_tag_at_n(v_ru_24x1_2429_24Cons, TAG_WriteErr, 2, (V[]){v_t_2434, NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
    return (g_co_2eop_24s321980040x1154251472(v_rest_2433, heff_dup(v_p_2430), v_p_2431, heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_p_2430));
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
V g_co_2eop_24s747777320x140686263_lam0(V self, V *args);
V g_co_2eop_24s747777320x140686263_lam1(V self, V *args);
V g_co_2eop_24s747777320x140686263_lam3(V self, V *args);
V g_co_2eop_24s747777320x140686263_lam2(V self, V *args); static Clo g_co_2eop_24s747777320x140686263_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s747777320x140686263_lam2, 4, 0};
V g_co_2eop_24s747777320x140686263_lam5(V self, V *args);
V g_co_2eop_24s747777320x140686263_lam4(V self, V *args);
V g_co_2eop_24s747777320x140686263_lam6(V self, V *args);
Clo g_co_2eop_24s747777320x140686263_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s747777320x140686263_entry, 3, 0};

V g_co_2eop_24s747777320x140686263(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2434;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s747777320x140686263_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2434 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2433;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_InL: {
      V v_x_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24InL = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24InR, 1);
      V v_t_2419;
      switch (heff_tag_of(v_x_2412)) {
      case TAG_Throw: {
        V v_s_2413 = heff_field(v_x_2412, 0);
        V v_ru_24x_2412_24Throw = heff_take_reuse_n(v_x_2412, 1ULL, 1);
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24Throw, TAG_Throw, 1, (V[]){v_s_2413});
        break;
      }
      case TAG_Catch: {
        V v_c_2414 = heff_field(v_x_2412, 0);
        V v_h_2415 = heff_field(v_x_2412, 1);
        V v_ru_24x_2412_24Catch = heff_take_reuse_n(v_x_2412, 3ULL, 2);
        V v_t_2416 = heff_tr(heff_call(v_c_2414, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
        v_t_2419 = heff_tag_at_n(v_ru_24x_2412_24Catch, TAG_Catch, 2, (V[]){v_t_2416, heff_clo_n(g_co_2eop_24s747777320x140686263_lam1, 1, 2, (V[]){v_h_2415, heff_dup(v_hd_241)})});
        break;
      }
      default: heff_nomatch(v_x_2412);
      }
      v_t_2433 = heff_tag_at_n(v_ru_24y_2411_24InL, TAG_InL, 1, (V[]){v_t_2419});
      break;
    }
    case TAG_InR: {
      V v_y_2420 = heff_field(v_y_2411, 0);
      heff_take_n(v_y_2411, 1ULL, 1);
      V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s747777320x140686263_lam2_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s747777320x140686263_lam4, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s747777320x140686263_lam6, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2420}));
      v_t_2433 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2432});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2433});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2434}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2435, v_k2_242});
}
V g_co_2eop_24s747777320x140686263_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s747777320x140686263(a[0], a[1], a[2]);
}
V g_co_2eop_24s747777320x140686263_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s747777320x140686263_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_h_2415 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2418 = heff_tr(heff_call(v_h_2415, 1, (V[]){v_s_2417}));
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s747777320x140686263_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_2421 = heff_env(self)[0];
  V v_k_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2426 = heff_tr(heff_call(v_g_2421, 1, (V[]){v_x_2425}));
  V f_ = v_k_2424;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s747777320x140686263_lam2(V self, V *args) {
  V v_g_2421 = args[0];
  V v_c_2422 = args[1];
  V v_hd_2423 = args[2];
  V v_k_2424 = args[3];
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_co_2eop_24s747777320x140686263_lam3, 1, 2, (V[]){v_g_2421, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s747777320x140686263_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_g_2427 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_call(v_g_2427, 1, (V[]){v_x_2429}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s747777320x140686263_lam4(V self, V *args) {
  V v_g_2427 = args[0];
  V v_m_2428 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2428;
  args[1] = heff_clo_n(g_co_2eop_24s747777320x140686263_lam5, 1, 2, (V[]){v_g_2427, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s747777320x140686263_lam6(V self, V *args) {
  V v_c_2431 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_co_2eop_24s1191249873x1860951653_str0, 1, "\012");
V g_co_2eop_24s1191249873x1860951653_lam0(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam2(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam1(V self, V *args); static Clo g_co_2eop_24s1191249873x1860951653_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1191249873x1860951653_lam1, 4, 0};
V g_co_2eop_24s1191249873x1860951653_lam4(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam3(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam5(V self, V *args);
V g_co_2eop_24s1191249873x1860951653_lam6(V self, V *args);
Clo g_co_2eop_24s1191249873x1860951653_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1191249873x1860951653_entry, 5, 0};

V g_co_2eop_24s1191249873x1860951653(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_hd_244) {
top: ;
  V v_t_2426;
  switch (heff_tag_of(v_p_243)) {
  case TAG_InL: {
    V v_x_245 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InL = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_245)) {
    case TAG_Throw: {
      V v_s_246 = heff_field(v_x_245, 0);
      V v_ru_24x_245_24Throw = heff_take_reuse_n(v_x_245, 1ULL, 1);
      v_t_2412 = heff_tag_at_n(v_ru_24x_245_24Throw, TAG_Throw, 1, (V[]){v_s_246});
      break;
    }
    case TAG_Catch: {
      V v_c_247 = heff_field(v_x_245, 0);
      V v_h_248 = heff_field(v_x_245, 1);
      V v_ru_24x_245_24Catch = heff_take_reuse_n(v_x_245, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(v_hd_244), heff_dup(heff_rfield(v_hd_244, 0))}));
      v_t_2412 = heff_tag_at_n(v_ru_24x_245_24Catch, TAG_Catch, 2, (V[]){v_t_249, heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam0, 1, 2, (V[]){v_h_248, heff_dup(v_hd_244)})});
      break;
    }
    default: heff_nomatch(v_x_245);
    }
    v_t_2426 = heff_tag_at_n(v_ru_24p_243_24InL, TAG_InL, 1, (V[]){v_t_2412});
    break;
  }
  case TAG_InR: {
    V v_y_2413 = heff_field(v_p_243, 0);
    V v_ru_24p_243_24InR = heff_take_reuse_n(v_p_243, 1ULL, 1);
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1191249873x1860951653_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam3, 2, 1, (V[]){heff_dup(v_hd_244)})}), heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam5, 1, 1, (V[]){heff_dup(v_hd_244)}), v_y_2413}));
    v_t_2426 = heff_tag_at_n(v_ru_24p_243_24InR, TAG_InR, 1, (V[]){v_t_2425});
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2426}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2427, heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam6, 1, 3, (V[]){v_lit_240, v_lit_241, v_lit_242})});
}
V g_co_2eop_24s1191249873x1860951653_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1191249873x1860951653(a[0], a[1], a[2], a[3], a[4]);
}
V g_co_2eop_24s1191249873x1860951653_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  V v_h_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_2411 = heff_tr(heff_call(v_h_248, 1, (V[]){v_s_2410}));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1191249873x1860951653_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2419 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2418}));
  V f_ = v_k_2417;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1191249873x1860951653_lam1(V self, V *args) {
  V v_g_2414 = args[0];
  V v_c_2415 = args[1];
  V v_hd_2416 = args[2];
  V v_k_2417 = args[3];
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam2, 1, 2, (V[]){v_g_2414, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1191249873x1860951653_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_g_2420 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_g_2420, 1, (V[]){v_x_2422}));
  V f_ = heff_get_n(v_hd_244, 0, 3);
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1191249873x1860951653_lam3(V self, V *args) {
  V v_g_2420 = args[0];
  V v_m_2421 = args[1];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_m_2421;
  args[1] = heff_clo_n(g_co_2eop_24s1191249873x1860951653_lam4, 1, 2, (V[]){v_g_2420, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1191249873x1860951653_lam5(V self, V *args) {
  V v_c_2424 = args[0];
  V v_hd_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_get_n(v_hd_244, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1191249873x1860951653_lam6(V self, V *args) {
  V v_a_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_a_2428);
  V v_x1_2429 = v_lit_240;
  V v_p_2430 = v_lit_241;
  V v_p_2431 = v_lit_242;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_Nil: {
    heff_drop(v_p_2430);
    V f_ = v_p_2431;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2432 = heff_field(v_x1_2429, 0);
    V v_rest_2433 = heff_field(v_x1_2429, 1);
    V v_ru_24x1_2429_24Cons = heff_take_reuse_n(v_x1_2429, 3ULL, 2);
    V v_t_2434 = heff_tag_at_n(v_ru_24x1_2429_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_2432, ((V)&g_co_2eop_24s1191249873x1860951653_str0)), NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s1191249873x1860951653(v_rest_2433, heff_dup(v_p_2430), v_p_2431, heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_p_2430));
  }
  default: return heff_nomatch(v_x1_2429);
  }
}
Clo g_co_2eop_24s948886493x1367785519_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s948886493x1367785519_entry, 3, 0};

V g_co_2eop_24s948886493x1367785519(V v_lit_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_bind_243 = heff_take_field(v_hd_241, 1);
  V v_malg_244 = heff_get_n(v_hd_241, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_lit_240})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(v_malg_244, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
  return heff_tail(v_bind_243, 2, (V[]){v_t_2411, v_k2_242});
}
V g_co_2eop_24s948886493x1367785519_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s948886493x1367785519(a[0], a[1], a[2]);
}
Clo g_co_2eop_24s1964021109x2127220916_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1964021109x2127220916_entry, 3, 0};

V g_co_2eop_24s1964021109x2127220916(V v_lit_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_bind_243 = heff_take_field(v_hd_241, 1);
  V v_malg_244 = heff_get_n(v_hd_241, 2, 3);
  V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){v_lit_240, NTAG(TAG_MkUnit)});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(v_malg_244, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})}));
  return heff_tail(v_bind_243, 2, (V[]){v_t_2412, v_k2_242});
}
V g_co_2eop_24s1964021109x2127220916_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1964021109x2127220916(a[0], a[1], a[2]);
}
V g_co_2eop_24s1554102946x910234624_lam1(V self, V *args);
V g_co_2eop_24s1554102946x910234624_lam0(V self, V *args);
Clo g_co_2eop_24s1554102946x910234624_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1554102946x910234624_entry, 3, 0};

V g_co_2eop_24s1554102946x910234624(V v_lit_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_lit_240)) {
  case TAG_Await: {
    V v_t_243 = heff_field(v_lit_240, 0);
    V v_k_244 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24Await = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24Await, TAG_Await, 2, (V[]){v_t_243, v_k_244});
    break;
  }
  case TAG_Send: {
    V v_s_245 = heff_field(v_lit_240, 0);
    V v_x_246 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24Send = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24Send, TAG_Send, 2, (V[]){v_s_245, v_x_246});
    break;
  }
  case TAG_Log: {
    V v_s_247 = heff_field(v_lit_240, 0);
    V v_x_248 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24Log = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24Log, TAG_Log, 2, (V[]){v_s_247, v_x_248});
    break;
  }
  case TAG_Now: {
    V v_k_249 = heff_field(v_lit_240, 0);
    V v_ru_24lit_240_24Now = heff_take_reuse_n(v_lit_240, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24Now, TAG_Now, 1, (V[]){v_k_249});
    break;
  }
  case TAG_ProjectFiles: {
    V v_r_2410 = heff_field(v_lit_240, 0);
    V v_k_2411 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24ProjectFiles = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2410, v_k_2411});
    break;
  }
  case TAG_UriPath: {
    V v_u_2412 = heff_field(v_lit_240, 0);
    V v_k_2413 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24UriPath = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24UriPath, TAG_UriPath, 2, (V[]){v_u_2412, v_k_2413});
    break;
  }
  case TAG_PathUri: {
    V v_p_2414 = heff_field(v_lit_240, 0);
    V v_k_2415 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24PathUri = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24PathUri, TAG_PathUri, 2, (V[]){v_p_2414, v_k_2415});
    break;
  }
  case TAG_AbsPath: {
    V v_p_2416 = heff_field(v_lit_240, 0);
    V v_k_2417 = heff_field(v_lit_240, 1);
    V v_ru_24lit_240_24AbsPath = heff_take_reuse_n(v_lit_240, 3ULL, 2);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2416, v_k_2417});
    break;
  }
  case TAG_Attempt: {
    V v_b_2418 = heff_field(v_lit_240, 0);
    V v_ru_24lit_240_24Attempt = heff_take_reuse_n(v_lit_240, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24Attempt, TAG_Attempt, 1, (V[]){heff_clo_n(g_co_2eop_24s1554102946x910234624_lam0, 1, 2, (V[]){v_b_2418, heff_dup(v_hd_241)})});
    break;
  }
  case TAG_Quit: {
    V v_c_2423 = heff_field(v_lit_240, 0);
    V v_ru_24lit_240_24Quit = heff_take_reuse_n(v_lit_240, 1ULL, 1);
    v_t_2424 = heff_tag_at_n(v_ru_24lit_240_24Quit, TAG_Quit, 1, (V[]){v_c_2423});
    break;
  }
  default: heff_nomatch(v_lit_240);
  }
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2429}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2430, v_k2_242});
}
V g_co_2eop_24s1554102946x910234624_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1554102946x910234624(a[0], a[1], a[2]);
}
V g_co_2eop_24s1554102946x910234624_lam1(V self, V *args) {
  V v_c_2420 = args[0];
  V v_k_2421 = args[1];
  V v_hd_241 = heff_env(self)[0];
  V v_use_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_c_2420, 2, (V[]){heff_dup(v_hd_241), heff_get_n(v_hd_241, 0, 3)}));
  V f_ = v_use_2419;
  args[0] = v_t_2422;
  args[1] = v_k_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1554102946x910234624_lam0(V self, V *args) {
  V v_use_2419 = args[0];
  V v_b_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2418;
  args[0] = heff_clo_n(g_co_2eop_24s1554102946x910234624_lam1, 2, 2, (V[]){v_hd_241, v_use_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s293084245x615760588_lam0(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam2(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam1(V self, V *args); static Clo g_co_2eop_24s293084245x615760588_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s293084245x615760588_lam1, 4, 0};
V g_co_2eop_24s293084245x615760588_lam4(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam3(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam5(V self, V *args);
V g_co_2eop_24s293084245x615760588_lam6(V self, V *args);
Clo g_co_2eop_24s293084245x615760588_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s293084245x615760588_entry, 3, 0};

V g_co_2eop_24s293084245x615760588(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s293084245x615760588_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s293084245x615760588_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s293084245x615760588_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s293084245x615760588_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, heff_clo_n(g_co_2eop_24s293084245x615760588_lam6, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s293084245x615760588_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s293084245x615760588(a[0], a[1], a[2]);
}
V g_co_2eop_24s293084245x615760588_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s293084245x615760588_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s293084245x615760588_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s293084245x615760588_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s293084245x615760588_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s293084245x615760588_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s293084245x615760588_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s293084245x615760588_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s293084245x615760588_lam6(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_RDone, 1, (V[]){v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0, 3, 0};
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam2(V self, V *args);
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1(V self, V *args); static Clo g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1, 4, 0};

static V g_co_2e_3c_2b_3e_24s1957723276x2068325901_val;
static HEFF_ONCE g_co_2e_3c_2b_3e_24s1957723276x2068325901_st;
static V g_co_2e_3c_2b_3e_24s1957723276x2068325901_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0_clo), ((V)&g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1_clo)});
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(void) {
  if (HEFF_DONE(g_co_2e_3c_2b_3e_24s1957723276x2068325901_st)) return g_co_2e_3c_2b_3e_24s1957723276x2068325901_val;
  return heff_global(&g_co_2e_3c_2b_3e_24s1957723276x2068325901_val, &g_co_2e_3c_2b_3e_24s1957723276x2068325901_st, g_co_2e_3c_2b_3e_24s1957723276x2068325901_init);
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_green_2egreen_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1733666804x1061788546_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_245}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_246});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam2(V self, V *args) {
  V v_s_2429 = args[0];
  V v_h_2427 = heff_env(self)[0];
  V v_nt_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_call(v_h_2427, 1, (V[]){v_s_2429}));
  V f_ = v_nt_249;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam1(V self, V *args) {
  V v_m_247 = args[0];
  V v_n_248 = args[1];
  V v_nt_249 = args[2];
  V v_p_2410 = args[3];
  switch (heff_tag_of(v_p_2410)) {
  case TAG_InL: {
    V v_x_2411 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InL = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    heff_drop(v_m_247);
    heff_drop(v_n_248);
    V v_t_2422;
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Spawn: {
      V v_c_2412 = heff_field(v_x_2411, 0);
      V v_x_2413 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Spawn = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(v_nt_249, 1, (V[]){v_c_2412}));
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Spawn, TAG_Spawn, 2, (V[]){v_t_2414, v_x_2413});
      break;
    }
    case TAG_Yield: {
      V v_x_2415 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24Yield = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Yield, TAG_Yield, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_NewChan: {
      V v_k_2416 = heff_field(v_x_2411, 0);
      V v_ru_24x_2411_24NewChan = heff_take_reuse_n(v_x_2411, 1ULL, 1);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24NewChan, TAG_NewChan, 1, (V[]){v_k_2416});
      break;
    }
    case TAG_Send: {
      V v_ch_2417 = heff_field(v_x_2411, 0);
      V v_v_2418 = heff_field(v_x_2411, 1);
      V v_x_2419 = heff_field(v_x_2411, 2);
      V v_ru_24x_2411_24Send = heff_take_reuse_n(v_x_2411, 7ULL, 3);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Send, TAG_Send, 3, (V[]){v_ch_2417, v_v_2418, v_x_2419});
      break;
    }
    case TAG_Recv: {
      V v_ch_2420 = heff_field(v_x_2411, 0);
      V v_k_2421 = heff_field(v_x_2411, 1);
      V v_ru_24x_2411_24Recv = heff_take_reuse_n(v_x_2411, 3ULL, 2);
      heff_drop(v_nt_249);
      v_t_2422 = heff_tag_at_n(v_ru_24x_2411_24Recv, TAG_Recv, 2, (V[]){v_ch_2420, v_k_2421});
      break;
    }
    default: heff_nomatch(v_x_2411);
    }
    return heff_tag_at_n(v_ru_24p_2410_24InL, TAG_InL, 1, (V[]){v_t_2422});
  }
  case TAG_InR: {
    V v_y_2423 = heff_field(v_p_2410, 0);
    V v_ru_24p_2410_24InR = heff_take_reuse_n(v_p_2410, 1ULL, 1);
    V v_t_2434;
    switch (heff_tag_of(v_y_2423)) {
    case TAG_InL: {
      V v_x_2424 = heff_field(v_y_2423, 0);
      V v_ru_24y_2423_24InL = heff_take_reuse_n(v_y_2423, 1ULL, 1);
      heff_drop(v_m_247);
      heff_drop(v_n_248);
      heff_drop_cell(v_ru_24p_2410_24InR, 1);
      V v_t_2431;
      switch (heff_tag_of(v_x_2424)) {
      case TAG_Throw: {
        V v_s_2425 = heff_field(v_x_2424, 0);
        V v_ru_24x_2424_24Throw = heff_take_reuse_n(v_x_2424, 1ULL, 1);
        heff_drop(v_nt_249);
        v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24Throw, TAG_Throw, 1, (V[]){v_s_2425});
        break;
      }
      case TAG_Catch: {
        V v_c_2426 = heff_field(v_x_2424, 0);
        V v_h_2427 = heff_field(v_x_2424, 1);
        V v_ru_24x_2424_24Catch = heff_take_reuse_n(v_x_2424, 3ULL, 2);
        V v_t_2428 = heff_tr(heff_call(heff_dup(v_nt_249), 1, (V[]){v_c_2426}));
        v_t_2431 = heff_tag_at_n(v_ru_24x_2424_24Catch, TAG_Catch, 2, (V[]){v_t_2428, heff_clo_n(g_co_2e_3c_2b_3e_24s1957723276x2068325901_lam2, 1, 2, (V[]){v_h_2427, v_nt_249})});
        break;
      }
      default: heff_nomatch(v_x_2424);
      }
      v_t_2434 = heff_tag_at_n(v_ru_24y_2423_24InL, TAG_InL, 1, (V[]){v_t_2431});
      break;
    }
    case TAG_InR: {
      V v_y_2432 = heff_field(v_y_2423, 0);
      heff_take_n(v_y_2423, 1ULL, 1);
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){v_m_247, v_n_248, v_nt_249, v_y_2432}));
      v_t_2434 = heff_tag_at_n(v_ru_24p_2410_24InR, TAG_InR, 1, (V[]){v_t_2433});
      break;
    }
    default: heff_nomatch(v_y_2423);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2434});
  }
  default: return heff_nomatch(v_p_2410);
  }
}
V g_co_2eop_24s1876960293x1282655859_lam1(V self, V *args);
V g_co_2eop_24s1876960293x1282655859_lam0(V self, V *args); static Clo g_co_2eop_24s1876960293x1282655859_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1876960293x1282655859_lam0, 4, 0};
V g_co_2eop_24s1876960293x1282655859_lam3(V self, V *args);
V g_co_2eop_24s1876960293x1282655859_lam2(V self, V *args);
V g_co_2eop_24s1876960293x1282655859_lam4(V self, V *args);
Clo g_co_2eop_24s1876960293x1282655859_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1876960293x1282655859_entry, 3, 0};

V g_co_2eop_24s1876960293x1282655859(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1876960293x1282655859_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, v_k2_242});
}
V g_co_2eop_24s1876960293x1282655859_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1876960293x1282655859(a[0], a[1], a[2]);
}
V g_co_2eop_24s1876960293x1282655859_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1876960293x1282655859_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1876960293x1282655859_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1876960293x1282655859_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s1876960293x1282655859_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1876960293x1282655859_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1979766345x1806196139_lam0(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam2(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam1(V self, V *args); static Clo g_co_2eop_24s1979766345x1806196139_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1979766345x1806196139_lam1, 4, 0};
V g_co_2eop_24s1979766345x1806196139_lam4(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam3(V self, V *args);
V g_co_2eop_24s1979766345x1806196139_lam5(V self, V *args);
Clo g_co_2eop_24s1979766345x1806196139_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1979766345x1806196139_entry, 3, 0};

V g_co_2eop_24s1979766345x1806196139(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Throw: {
      V v_s_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Throw = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Throw, TAG_Throw, 1, (V[]){v_s_244});
      break;
    }
    case TAG_Catch: {
      V v_c_245 = heff_field(v_x_243, 0);
      V v_h_246 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Catch = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(v_hd_241), heff_dup(heff_rfield(v_hd_241, 0))}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Catch, TAG_Catch, 2, (V[]){v_t_247, heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam0, 1, 2, (V[]){v_h_246, heff_dup(v_hd_241)})});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s1957723276x2068325901_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1979766345x1806196139_lam1_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam3, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam5, 1, 1, (V[]){heff_dup(v_hd_241)}), v_y_2411}));
    v_t_2424 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2423});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2425, v_k2_242});
}
V g_co_2eop_24s1979766345x1806196139_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1979766345x1806196139(a[0], a[1], a[2]);
}
V g_co_2eop_24s1979766345x1806196139_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_h_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_249 = heff_tr(heff_call(v_h_246, 1, (V[]){v_s_248}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1979766345x1806196139_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2416}));
  V f_ = v_k_2415;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1979766345x1806196139_lam1(V self, V *args) {
  V v_g_2412 = args[0];
  V v_c_2413 = args[1];
  V v_hd_2414 = args[2];
  V v_k_2415 = args[3];
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam2, 1, 2, (V[]){v_g_2412, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1979766345x1806196139_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_2418 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_g_2418, 1, (V[]){v_x_2420}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1979766345x1806196139_lam3(V self, V *args) {
  V v_g_2418 = args[0];
  V v_m_2419 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2419;
  args[1] = heff_clo_n(g_co_2eop_24s1979766345x1806196139_lam4, 1, 2, (V[]){v_g_2418, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1979766345x1806196139_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s511476643x1802627326_lam1(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam0(V self, V *args); static Clo g_co_2eop_24s511476643x1802627326_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s511476643x1802627326_lam0, 4, 0};
V g_co_2eop_24s511476643x1802627326_lam3(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam2(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam4(V self, V *args);
V g_co_2eop_24s511476643x1802627326_lam5(V self, V *args);
Clo g_co_2eop_24s511476643x1802627326_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s511476643x1802627326_entry, 3, 0};

V g_co_2eop_24s511476643x1802627326(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s373441151x488264545_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s511476643x1802627326_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s511476643x1802627326_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s511476643x1802627326_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_p_240}));
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2415, heff_clo_n(g_co_2eop_24s511476643x1802627326_lam5, 1, 1, (V[]){v_k2_242})});
}
V g_co_2eop_24s511476643x1802627326_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s511476643x1802627326(a[0], a[1], a[2]);
}
V g_co_2eop_24s511476643x1802627326_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248 = heff_tr(heff_call(v_g_243, 1, (V[]){v_x_247}));
  V f_ = v_k_246;
  args[0] = v_x_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s511476643x1802627326_lam0(V self, V *args) {
  V v_g_243 = args[0];
  V v_c_244 = args[1];
  V v_hd_245 = args[2];
  V v_k_246 = args[3];
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_co_2eop_24s511476643x1802627326_lam1, 1, 2, (V[]){v_g_243, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s511476643x1802627326_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2411}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s511476643x1802627326_lam2(V self, V *args) {
  V v_g_249 = args[0];
  V v_m_2410 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2410;
  args[1] = heff_clo_n(g_co_2eop_24s511476643x1802627326_lam3, 1, 2, (V[]){v_g_249, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s511476643x1802627326_lam4(V self, V *args) {
  V v_c_2413 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s511476643x1802627326_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k2_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k2_242;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1554102946x910234624_24tok1_lam1(V self, V *args);
V g_co_2eop_24s1554102946x910234624_24tok1_lam0(V self, V *args);
Clo g_co_2eop_24s1554102946x910234624_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1554102946x910234624_24tok1_entry, 4, 0};

V g_co_2eop_24s1554102946x910234624_24tok1(V v_tok_240, V v_lit_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_lit_241)) {
  case TAG_Await: {
    V v_t_244 = heff_field(v_lit_241, 0);
    V v_k_245 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24Await = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24Await, TAG_Await, 2, (V[]){v_t_244, v_k_245});
    break;
  }
  case TAG_Send: {
    V v_s_246 = heff_field(v_lit_241, 0);
    V v_x_247 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24Send = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24Send, TAG_Send, 2, (V[]){v_s_246, v_x_247});
    break;
  }
  case TAG_Log: {
    V v_s_248 = heff_field(v_lit_241, 0);
    V v_x_249 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24Log = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24Log, TAG_Log, 2, (V[]){v_s_248, v_x_249});
    break;
  }
  case TAG_Now: {
    V v_k_2410 = heff_field(v_lit_241, 0);
    heff_take_n(v_lit_241, 1ULL, 1);
    v_t_2425 = heff_tag_at_n(v_tok_240, TAG_Now, 1, (V[]){v_k_2410});
    break;
  }
  case TAG_ProjectFiles: {
    V v_r_2411 = heff_field(v_lit_241, 0);
    V v_k_2412 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24ProjectFiles = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2411, v_k_2412});
    break;
  }
  case TAG_UriPath: {
    V v_u_2413 = heff_field(v_lit_241, 0);
    V v_k_2414 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24UriPath = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24UriPath, TAG_UriPath, 2, (V[]){v_u_2413, v_k_2414});
    break;
  }
  case TAG_PathUri: {
    V v_p_2415 = heff_field(v_lit_241, 0);
    V v_k_2416 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24PathUri = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24PathUri, TAG_PathUri, 2, (V[]){v_p_2415, v_k_2416});
    break;
  }
  case TAG_AbsPath: {
    V v_p_2417 = heff_field(v_lit_241, 0);
    V v_k_2418 = heff_field(v_lit_241, 1);
    V v_ru_24lit_241_24AbsPath = heff_take_reuse_n(v_lit_241, 3ULL, 2);
    heff_drop_cell(v_tok_240, 1);
    v_t_2425 = heff_tag_at_n(v_ru_24lit_241_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2417, v_k_2418});
    break;
  }
  case TAG_Attempt: {
    V v_b_2419 = heff_field(v_lit_241, 0);
    heff_take_n(v_lit_241, 1ULL, 1);
    v_t_2425 = heff_tag_at_n(v_tok_240, TAG_Attempt, 1, (V[]){heff_clo_n(g_co_2eop_24s1554102946x910234624_24tok1_lam0, 1, 2, (V[]){v_b_2419, heff_dup(v_hd_242)})});
    break;
  }
  case TAG_Quit: {
    V v_c_2424 = heff_field(v_lit_241, 0);
    heff_take_n(v_lit_241, 1ULL, 1);
    v_t_2425 = heff_tag_at_n(v_tok_240, TAG_Quit, 1, (V[]){v_c_2424});
    break;
  }
  default: heff_nomatch(v_lit_241);
  }
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2430}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_2431, v_k2_243});
}
V g_co_2eop_24s1554102946x910234624_24tok1_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1554102946x910234624_24tok1(a[0], a[1], a[2], a[3]);
}
V g_co_2eop_24s1554102946x910234624_24tok1_lam1(V self, V *args) {
  V v_c_2421 = args[0];
  V v_k_2422 = args[1];
  V v_hd_242 = heff_env(self)[0];
  V v_use_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(v_c_2421, 2, (V[]){heff_dup(v_hd_242), heff_get_n(v_hd_242, 0, 3)}));
  V f_ = v_use_2420;
  args[0] = v_t_2423;
  args[1] = v_k_2422;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1554102946x910234624_24tok1_lam0(V self, V *args) {
  V v_use_2420 = args[0];
  V v_b_2419 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_b_2419;
  args[0] = heff_clo_n(g_co_2eop_24s1554102946x910234624_24tok1_lam1, 2, 2, (V[]){v_hd_242, v_use_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_co_2eop_24s1623411525x1925292021_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1623411525x1925292021_24tok1_entry, 4, 0};

V g_co_2eop_24s1623411525x1925292021_24tok1(V v_tok_240, V v_lit_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_246 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_lit_241})});
  V v_t_247 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(v_bind_244, 2, (V[]){v_t_247, v_k2_243});
}
V g_co_2eop_24s1623411525x1925292021_24tok1_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1623411525x1925292021_24tok1(a[0], a[1], a[2], a[3]);
}
Clo g_co_2eop_24s40508559x1835373952_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s40508559x1835373952_24tok1_entry, 4, 0};

V g_co_2eop_24s40508559x1835373952_24tok1(V v_tok_240, V v_lit_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_246 = heff_tag_n(TAG_Exit, 2, (V[]){v_lit_241, NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})}));
  return heff_tail(v_bind_244, 2, (V[]){v_t_2413, v_k2_243});
}
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s40508559x1835373952_24tok1(a[0], a[1], a[2], a[3]);
}