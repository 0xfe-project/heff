// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsPath 63561
#define TAG_Await 41810
#define TAG_Catch 6517
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_ErrColor 60683
#define TAG_Get 18914
#define TAG_Log 24016
#define TAG_NewChan 9424
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_Put 28059
#define TAG_Quit 47258
#define TAG_Recv 61489
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_Spawn 10053
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_UriPath 39251
#define TAG_UseColor 15915
#define TAG_WriteErr 37283
#define TAG_Yield 38529
#define LBL_bind 9519364
#define LBL_builds 569118448
#define LBL_fmap 9641981
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_pages 307784670
#define LBL_port 9942344
#define LBL_proxy 308299400
#define LBL_ret 322331
#define LBL_wanted 1152016858
static uint32_t shape_builds__wanted__port__proxy__pages[] = {LBL_builds, LBL_wanted, LBL_port, LBL_proxy, LBL_pages};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2ebind_24s2023162438x1917167210(V, V, V);
V g_co_2ebind_24s2023162438x1917167210_entry(V self, V *a);
extern Clo g_co_2ebind_24s2023162438x1917167210_clo;
V g_co_2ebind_24s591410632x427349444(V, V, V);
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a);
extern Clo g_co_2ebind_24s591410632x427349444_clo;
V g_co_2eop_24s1179717641x1895974648(V, V, V, V, V, V);
V g_co_2eop_24s1179717641x1895974648_entry(V self, V *a);
extern Clo g_co_2eop_24s1179717641x1895974648_clo;
V g_co_2eop_24s1390932844x694948683(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1390932844x694948683_entry(V self, V *a);
extern Clo g_co_2eop_24s1390932844x694948683_clo;
V g_co_2eop_24s161437114x968393689(V, V, V, V, V, V, V, V);
V g_co_2eop_24s161437114x968393689_entry(V self, V *a);
extern Clo g_co_2eop_24s161437114x968393689_clo;
V g_co_2eop_24s1622770744x67950580(V, V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s1622770744x67950580_entry(V self, V *a);
extern Clo g_co_2eop_24s1622770744x67950580_clo;
V g_co_2eop_24s279158732x359344659(V, V, V, V, V, V, V);
V g_co_2eop_24s279158732x359344659_entry(V self, V *a);
extern Clo g_co_2eop_24s279158732x359344659_clo;
V g_co_2eop_24s728204878x155198609(V, V, V, V, V, V, V);
V g_co_2eop_24s728204878x155198609_entry(V self, V *a);
extern Clo g_co_2eop_24s728204878x155198609_clo;
V g_co_2eop_24s75967081x1174714853(V, V, V);
V g_co_2eop_24s75967081x1174714853_entry(V self, V *a);
extern Clo g_co_2eop_24s75967081x1174714853_clo;
V g_co_2eop_24s868939913x277534373(V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s868939913x277534373_entry(V self, V *a);
extern Clo g_co_2eop_24s868939913x277534373_clo;
V g_co_2eop_24s901899803x1656620254(V, V, V, V, V, V, V, V);
V g_co_2eop_24s901899803x1656620254_entry(V self, V *a);
extern Clo g_co_2eop_24s901899803x1656620254_clo;
V g_co_2eplus_24s1226459126x1628219458_get(void);
V g_co_2eplus_24s169777576x280800149_get(void);
V g_co_2eplus_24s1854017309x1005292301_get(void);
V g_co_2eplus_24s2124540091x1079095538_get(void);
V g_co_2eplus_24s973240257x441859337_get(void);
V g_co_2eplus_24s984570155x1252140766_get(void);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245_clo;
V g_heff_2ebuild_2edev_2ecycle_24s531591947x1868948246(V, V, V, V, V, V);
V g_heff_2ebuild_2edev_2ecycle_24s531591947x1868948246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2ecycle_24s531591947x1868948246_clo;
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(V, V, V, V);
V g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2elsp_2erpc_2erpc_get(void);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s410120642x105714730(V, V);
V g_list_2efoldl_24s410120642x105714730_entry(V self, V *a);
extern Clo g_list_2efoldl_24s410120642x105714730_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361(V, V, V, V, V);
V g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361_clo;
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551(V, V, V, V, V);
V g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_entry(V self, V *a);
extern Clo g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2eprogress_2eprogress_get(void);
V g_std_2ereactor_2ereactor_get(void);
V g_co_2eplus_24s973240257x441859337_lam1(V self, V *args);
V g_co_2eplus_24s973240257x441859337_lam2(V self, V *args);
V g_co_2eplus_24s973240257x441859337_lam0(V self, V *args); static Clo g_co_2eplus_24s973240257x441859337_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s973240257x441859337_lam0, 3, 0};
V g_co_2eplus_24s973240257x441859337_lam4(V self, V *args);
V g_co_2eplus_24s973240257x441859337_lam3(V self, V *args); static Clo g_co_2eplus_24s973240257x441859337_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s973240257x441859337_lam3, 4, 0};

static V g_co_2eplus_24s973240257x441859337_val;
static HEFF_ONCE g_co_2eplus_24s973240257x441859337_st;
static V g_co_2eplus_24s973240257x441859337_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s973240257x441859337_lam0_clo), ((V)&g_co_2eplus_24s973240257x441859337_lam3_clo)});
}
V g_co_2eplus_24s973240257x441859337_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s973240257x441859337_st)) return g_co_2eplus_24s973240257x441859337_val;
  return heff_global(&g_co_2eplus_24s973240257x441859337_val, &g_co_2eplus_24s973240257x441859337_st, g_co_2eplus_24s973240257x441859337_init);
}
V g_co_2eplus_24s973240257x441859337_lam1(V self, V *args) {
  V v_st_245 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tr(heff_call(v_k_244, 1, (V[]){v_st_245}));
  V f_ = v_g_241;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s973240257x441859337_lam2(V self, V *args) {
  V v_s_2416 = args[0];
  V v_h_2414 = heff_env(self)[0];
  V v_m_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tr(heff_call(v_h_2414, 1, (V[]){v_s_2416}));
  V f_ = heff_get_n(v_m_240, 0, 1);
  heff_room[0] = v_g_241;
  heff_room[1] = v_t_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s973240257x441859337_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    heff_drop_rec(v_m_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_Get: {
      V v_k_244 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24Get = heff_take_reuse_n(v_x_243, 1ULL, 1);
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Get, TAG_Get, 1, (V[]){heff_clo_n(g_co_2eplus_24s973240257x441859337_lam1, 1, 2, (V[]){v_k_244, v_g_241})});
      break;
    }
    case TAG_Put: {
      V v_st_247 = heff_field(v_x_243, 0);
      V v_x_248 = heff_field(v_x_243, 1);
      V v_ru_24x_243_24Put = heff_take_reuse_n(v_x_243, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_248}));
      v_t_2410 = heff_tag_at_n(v_ru_24x_243_24Put, TAG_Put, 2, (V[]){v_st_247, v_t_249});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_2410});
  }
  case TAG_InR: {
    V v_y_2411 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_2411)) {
    case TAG_Throw: {
      V v_s_2412 = heff_field(v_y_2411, 0);
      V v_ru_24y_2411_24Throw = heff_take_reuse_n(v_y_2411, 1ULL, 1);
      heff_drop_rec(v_m_240, 1);
      heff_drop(v_g_241);
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Throw, TAG_Throw, 1, (V[]){v_s_2412});
      break;
    }
    case TAG_Catch: {
      V v_c_2413 = heff_field(v_y_2411, 0);
      V v_h_2414 = heff_field(v_y_2411, 1);
      V v_ru_24y_2411_24Catch = heff_take_reuse_n(v_y_2411, 3ULL, 2);
      V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_m_240, 0)), 2, (V[]){heff_dup(v_g_241), v_c_2413}));
      v_t_2418 = heff_tag_at_n(v_ru_24y_2411_24Catch, TAG_Catch, 2, (V[]){v_t_2415, heff_clo_n(g_co_2eplus_24s973240257x441859337_lam2, 1, 3, (V[]){v_h_2414, v_m_240, v_g_241})});
      break;
    }
    default: heff_nomatch(v_y_2411);
    }
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s973240257x441859337_lam4(V self, V *args) {
  V v_s_2433 = args[0];
  V v_h_2431 = heff_env(self)[0];
  V v_nt_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_tr(heff_call(v_h_2431, 1, (V[]){v_s_2433}));
  V f_ = v_nt_2421;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s973240257x441859337_lam3(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  heff_drop(v_m_2419);
  heff_drop(v_n_2420);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_nt_2421);
    V v_t_2427;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Get: {
      V v_k_2424 = heff_field(v_x_2423, 0);
      V v_ru_24x_2423_24Get = heff_take_reuse_n(v_x_2423, 1ULL, 1);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24Get, TAG_Get, 1, (V[]){v_k_2424});
      break;
    }
    case TAG_Put: {
      V v_st_2425 = heff_field(v_x_2423, 0);
      V v_x_2426 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24Put = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      v_t_2427 = heff_tag_at_n(v_ru_24x_2423_24Put, TAG_Put, 2, (V[]){v_st_2425, v_x_2426});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2427});
  }
  case TAG_InR: {
    V v_y_2428 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2435;
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Throw: {
      V v_s_2429 = heff_field(v_y_2428, 0);
      V v_ru_24y_2428_24Throw = heff_take_reuse_n(v_y_2428, 1ULL, 1);
      heff_drop(v_nt_2421);
      v_t_2435 = heff_tag_at_n(v_ru_24y_2428_24Throw, TAG_Throw, 1, (V[]){v_s_2429});
      break;
    }
    case TAG_Catch: {
      V v_c_2430 = heff_field(v_y_2428, 0);
      V v_h_2431 = heff_field(v_y_2428, 1);
      V v_ru_24y_2428_24Catch = heff_take_reuse_n(v_y_2428, 3ULL, 2);
      V v_t_2432 = heff_tr(heff_call(heff_dup(v_nt_2421), 1, (V[]){v_c_2430}));
      v_t_2435 = heff_tag_at_n(v_ru_24y_2428_24Catch, TAG_Catch, 2, (V[]){v_t_2432, heff_clo_n(g_co_2eplus_24s973240257x441859337_lam4, 1, 2, (V[]){v_h_2431, v_nt_2421})});
      break;
    }
    default: heff_nomatch(v_y_2428);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2435});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
V g_co_2ebind_24s591410632x427349444_lam0(V self, V *args); static Clo g_co_2ebind_24s591410632x427349444_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s591410632x427349444_lam0, 1, 0};
V g_co_2ebind_24s591410632x427349444_lam1(V self, V *args);
Clo g_co_2ebind_24s591410632x427349444_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s591410632x427349444_entry, 3, 0};

V g_co_2ebind_24s591410632x427349444(V v_f_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_co_2ebind_24s591410632x427349444_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_249, heff_clo_n(g_co_2ebind_24s591410632x427349444_lam1, 1, 3, (V[]){v_f_240, v_hd_241, v_k_242})});
}
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s591410632x427349444(a[0], a[1], a[2]);
}
V g_co_2ebind_24s591410632x427349444_lam0(V self, V *args) {
  V v_c_243 = args[0];
  V v_t_244 = ({ V b_0 = heff_get_n(v_c_243, 3, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s366344330x1145113647(v_t_244));
  V v_xs_246 = (g_list_2efoldl_24s410120642x105714730(NTAG(TAG_Nil), v_t_245));
  return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
}
V g_co_2ebind_24s591410632x427349444_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_f_240;
  heff_room[0] = v_x_2410;
  heff_room[1] = v_hd_241;
  heff_room[2] = v_k_242;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2ebind_24s2023162438x1917167210_lam1(V self, V *args); static Clo g_co_2ebind_24s2023162438x1917167210_lam1_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s2023162438x1917167210_lam1, 2, 0};
V g_co_2ebind_24s2023162438x1917167210_lam0(V self, V *args);
Clo g_co_2ebind_24s2023162438x1917167210_clo = {{0x80000000u, K_CLO, 0}, g_co_2ebind_24s2023162438x1917167210_entry, 3, 0};

V g_co_2ebind_24s2023162438x1917167210(V v_c_240, V v_f_241, V v_z_242) {
top: ;
  return heff_tail(v_c_240, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_co_2ebind_24s2023162438x1917167210_lam0, 1, 1, (V[]){v_f_241}), v_z_242});
}
V g_co_2ebind_24s2023162438x1917167210_entry(V self, V *a) {
  (void)self;
  return g_co_2ebind_24s2023162438x1917167210(a[0], a[1], a[2]);
}
V g_co_2ebind_24s2023162438x1917167210_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_a_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_244}), v_a_245});
}
V g_co_2ebind_24s2023162438x1917167210_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_f_241;
  heff_room[0] = v_x_243;
  heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[2] = ((V)&g_co_2ebind_24s2023162438x1917167210_lam1_clo);
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_co_2eplus_24s984570155x1252140766_lam1(V self, V *args);
V g_co_2eplus_24s984570155x1252140766_lam2(V self, V *args);
V g_co_2eplus_24s984570155x1252140766_lam0(V self, V *args); static Clo g_co_2eplus_24s984570155x1252140766_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s984570155x1252140766_lam0, 3, 0};
V g_co_2eplus_24s984570155x1252140766_lam3(V self, V *args); static Clo g_co_2eplus_24s984570155x1252140766_lam3_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s984570155x1252140766_lam3, 4, 0};

static V g_co_2eplus_24s984570155x1252140766_val;
static HEFF_ONCE g_co_2eplus_24s984570155x1252140766_st;
static V g_co_2eplus_24s984570155x1252140766_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s984570155x1252140766_lam0_clo), ((V)&g_co_2eplus_24s984570155x1252140766_lam3_clo)});
}
V g_co_2eplus_24s984570155x1252140766_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s984570155x1252140766_st)) return g_co_2eplus_24s984570155x1252140766_val;
  return heff_global(&g_co_2eplus_24s984570155x1252140766_val, &g_co_2eplus_24s984570155x1252140766_st, g_co_2eplus_24s984570155x1252140766_init);
}
V g_co_2eplus_24s984570155x1252140766_lam1(V self, V *args) {
  V v_b_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_b_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s984570155x1252140766_lam2(V self, V *args) {
  V v_b_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_b_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s984570155x1252140766_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_243)) {
    case TAG_InL: {
      V v_x_244 = heff_field(v_x_243, 0);
      heff_take_n(v_x_243, 1ULL, 1);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s169777576x280800149_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_244}));
      v_t_2414 = heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_245});
      break;
    }
    case TAG_InR: {
      V v_y_246 = heff_field(v_x_243, 0);
      V v_ru_24x_243_24InR = heff_take_reuse_n(v_x_243, 1ULL, 1);
      heff_drop(v_m_240);
      heff_drop_cell(v_ru_24p_242_24InL, 1);
      V v_t_2413;
      switch (heff_tag_of(v_y_246)) {
      case TAG_UseColor: {
        V v_k_247 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24UseColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24UseColor, TAG_UseColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s984570155x1252140766_lam1, 1, 2, (V[]){v_k_247, v_g_241})});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2410 = heff_field(v_y_246, 0);
        V v_ru_24y_246_24ErrColor = heff_take_reuse_n(v_y_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24y_246_24ErrColor, TAG_ErrColor, 1, (V[]){heff_clo_n(g_co_2eplus_24s984570155x1252140766_lam2, 1, 2, (V[]){v_k_2410, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_246);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_243_24InR, TAG_InR, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2414});
  }
  case TAG_InR: {
    V v_y_2415 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(g_heff_2elsp_2erpc_2erpc_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_2415}));
    return heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2416});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s984570155x1252140766_lam3(V self, V *args) {
  V v_m_2417 = args[0];
  V v_n_2418 = args[1];
  V v_nt_2419 = args[2];
  V v_p_2420 = args[3];
  switch (heff_tag_of(v_p_2420)) {
  case TAG_InL: {
    V v_x_2421 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InL = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    V v_t_2428;
    switch (heff_tag_of(v_x_2421)) {
    case TAG_InL: {
      V v_x_2422 = heff_field(v_x_2421, 0);
      heff_take_n(v_x_2421, 1ULL, 1);
      V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s169777576x280800149_get(), 1)), 4, (V[]){v_m_2417, v_n_2418, v_nt_2419, v_x_2422}));
      v_t_2428 = heff_tag_at_n(v_ru_24p_2420_24InL, TAG_InL, 1, (V[]){v_t_2423});
      break;
    }
    case TAG_InR: {
      V v_y_2424 = heff_field(v_x_2421, 0);
      V v_ru_24x_2421_24InR = heff_take_reuse_n(v_x_2421, 1ULL, 1);
      heff_drop(v_m_2417);
      heff_drop(v_n_2418);
      heff_drop(v_nt_2419);
      heff_drop_cell(v_ru_24p_2420_24InL, 1);
      V v_t_2427;
      switch (heff_tag_of(v_y_2424)) {
      case TAG_UseColor: {
        V v_k_2425 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24UseColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24UseColor, TAG_UseColor, 1, (V[]){v_k_2425});
        break;
      }
      case TAG_ErrColor: {
        V v_k_2426 = heff_field(v_y_2424, 0);
        V v_ru_24y_2424_24ErrColor = heff_take_reuse_n(v_y_2424, 1ULL, 1);
        v_t_2427 = heff_tag_at_n(v_ru_24y_2424_24ErrColor, TAG_ErrColor, 1, (V[]){v_k_2426});
        break;
      }
      default: heff_nomatch(v_y_2424);
      }
      v_t_2428 = heff_tag_at_n(v_ru_24x_2421_24InR, TAG_InR, 1, (V[]){v_t_2427});
      break;
    }
    default: heff_nomatch(v_x_2421);
    }
    return heff_tag_n(TAG_InL, 1, (V[]){v_t_2428});
  }
  case TAG_InR: {
    V v_y_2429 = heff_field(v_p_2420, 0);
    V v_ru_24p_2420_24InR = heff_take_reuse_n(v_p_2420, 1ULL, 1);
    heff_drop(v_m_2417);
    heff_drop(v_n_2418);
    heff_drop(v_nt_2419);
    V v_t_2446;
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Await: {
      V v_t_2430 = heff_field(v_y_2429, 0);
      V v_k_2431 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24Await = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Await, TAG_Await, 2, (V[]){v_t_2430, v_k_2431});
      break;
    }
    case TAG_Send: {
      V v_s_2432 = heff_field(v_y_2429, 0);
      V v_x_2433 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24Send = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Send, TAG_Send, 2, (V[]){v_s_2432, v_x_2433});
      break;
    }
    case TAG_Log: {
      V v_s_2434 = heff_field(v_y_2429, 0);
      V v_x_2435 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24Log = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Log, TAG_Log, 2, (V[]){v_s_2434, v_x_2435});
      break;
    }
    case TAG_Now: {
      V v_k_2436 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24Now = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Now, TAG_Now, 1, (V[]){v_k_2436});
      break;
    }
    case TAG_ProjectFiles: {
      V v_r_2437 = heff_field(v_y_2429, 0);
      V v_k_2438 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24ProjectFiles = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24ProjectFiles, TAG_ProjectFiles, 2, (V[]){v_r_2437, v_k_2438});
      break;
    }
    case TAG_UriPath: {
      V v_u_2439 = heff_field(v_y_2429, 0);
      V v_k_2440 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24UriPath = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24UriPath, TAG_UriPath, 2, (V[]){v_u_2439, v_k_2440});
      break;
    }
    case TAG_PathUri: {
      V v_p_2441 = heff_field(v_y_2429, 0);
      V v_k_2442 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24PathUri = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24PathUri, TAG_PathUri, 2, (V[]){v_p_2441, v_k_2442});
      break;
    }
    case TAG_AbsPath: {
      V v_p_2443 = heff_field(v_y_2429, 0);
      V v_k_2444 = heff_field(v_y_2429, 1);
      V v_ru_24y_2429_24AbsPath = heff_take_reuse_n(v_y_2429, 3ULL, 2);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24AbsPath, TAG_AbsPath, 2, (V[]){v_p_2443, v_k_2444});
      break;
    }
    case TAG_Quit: {
      V v_c_2445 = heff_field(v_y_2429, 0);
      V v_ru_24y_2429_24Quit = heff_take_reuse_n(v_y_2429, 1ULL, 1);
      v_t_2446 = heff_tag_at_n(v_ru_24y_2429_24Quit, TAG_Quit, 1, (V[]){v_c_2445});
      break;
    }
    default: heff_nomatch(v_y_2429);
    }
    return heff_tag_at_n(v_ru_24p_2420_24InR, TAG_InR, 1, (V[]){v_t_2446});
  }
  default: return heff_nomatch(v_p_2420);
  }
}
V g_co_2eop_24s75967081x1174714853_lam1(V self, V *args);
V g_co_2eop_24s75967081x1174714853_lam0(V self, V *args); static Clo g_co_2eop_24s75967081x1174714853_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s75967081x1174714853_lam0, 4, 0};
V g_co_2eop_24s75967081x1174714853_lam3(V self, V *args);
V g_co_2eop_24s75967081x1174714853_lam2(V self, V *args);
V g_co_2eop_24s75967081x1174714853_lam4(V self, V *args);
Clo g_co_2eop_24s75967081x1174714853_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s75967081x1174714853_entry, 3, 0};

V g_co_2eop_24s75967081x1174714853(V v_p_240, V v_hd_241, V v_k2_242) {
top: ;
  V v_t_2420;
  switch (heff_tag_of(v_p_240)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InL = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s75967081x1174714853_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s75967081x1174714853_lam2, 2, 1, (V[]){heff_dup(v_hd_241)})}), heff_clo_n(g_co_2eop_24s75967081x1174714853_lam4, 1, 1, (V[]){heff_dup(v_hd_241)}), v_x_243}));
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InL, TAG_InL, 1, (V[]){v_t_2415});
    break;
  }
  case TAG_InR: {
    V v_y_2416 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24InR = heff_take_reuse_n(v_p_240, 1ULL, 1);
    V v_t_2419;
    switch (heff_tag_of(v_y_2416)) {
    case TAG_Send: {
      V v_rq_2417 = heff_field(v_y_2416, 0);
      V v_k_2418 = heff_field(v_y_2416, 1);
      V v_ru_24y_2416_24Send = heff_take_reuse_n(v_y_2416, 3ULL, 2);
      v_t_2419 = heff_tag_at_n(v_ru_24y_2416_24Send, TAG_Send, 2, (V[]){v_rq_2417, v_k_2418});
      break;
    }
    default: heff_nomatch(v_y_2416);
    }
    v_t_2420 = heff_tag_at_n(v_ru_24p_240_24InR, TAG_InR, 1, (V[]){v_t_2419});
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_241, 1, 3), 2, (V[]){v_t_2421, v_k2_242});
}
V g_co_2eop_24s75967081x1174714853_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s75967081x1174714853(a[0], a[1], a[2]);
}
V g_co_2eop_24s75967081x1174714853_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_244 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_249 = heff_tr(heff_call(v_g_244, 1, (V[]){v_x_248}));
  V f_ = v_k_247;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s75967081x1174714853_lam0(V self, V *args) {
  V v_g_244 = args[0];
  V v_c_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_co_2eop_24s75967081x1174714853_lam1, 1, 2, (V[]){v_g_244, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s75967081x1174714853_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2412}));
  V f_ = heff_get_n(v_hd_241, 0, 3);
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s75967081x1174714853_lam2(V self, V *args) {
  V v_g_2410 = args[0];
  V v_m_2411 = args[1];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  args[0] = v_m_2411;
  args[1] = heff_clo_n(g_co_2eop_24s75967081x1174714853_lam3, 1, 2, (V[]){v_g_2410, v_hd_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s75967081x1174714853_lam4(V self, V *args) {
  V v_c_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_get_n(v_hd_241, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eplus_24s1854017309x1005292301_lam1(V self, V *args);
V g_co_2eplus_24s1854017309x1005292301_lam0(V self, V *args); static Clo g_co_2eplus_24s1854017309x1005292301_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1854017309x1005292301_lam0, 3, 0};
V g_co_2eplus_24s1854017309x1005292301_lam2(V self, V *args); static Clo g_co_2eplus_24s1854017309x1005292301_lam2_clo = {{0x80000000u, K_CLO, 0}, g_co_2eplus_24s1854017309x1005292301_lam2, 4, 0};

static V g_co_2eplus_24s1854017309x1005292301_val;
static HEFF_ONCE g_co_2eplus_24s1854017309x1005292301_st;
static V g_co_2eplus_24s1854017309x1005292301_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_co_2eplus_24s1854017309x1005292301_lam0_clo), ((V)&g_co_2eplus_24s1854017309x1005292301_lam2_clo)});
}
V g_co_2eplus_24s1854017309x1005292301_get(void) {
  if (HEFF_DONE(g_co_2eplus_24s1854017309x1005292301_st)) return g_co_2eplus_24s1854017309x1005292301_val;
  return heff_global(&g_co_2eplus_24s1854017309x1005292301_val, &g_co_2eplus_24s1854017309x1005292301_st, g_co_2eplus_24s1854017309x1005292301_init);
}
V g_co_2eplus_24s1854017309x1005292301_lam1(V self, V *args) {
  V v_r_2415 = args[0];
  V v_k_2414 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_tr(heff_call(v_k_2414, 1, (V[]){v_r_2415}));
  V f_ = v_g_241;
  args[0] = v_t_2416;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eplus_24s1854017309x1005292301_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  switch (heff_tag_of(v_p_242)) {
  case TAG_InL: {
    V v_x_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InL = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2eprogress_2eprogress_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_243}));
    return heff_tag_at_n(v_ru_24p_242_24InL, TAG_InL, 1, (V[]){v_t_244});
  }
  case TAG_InR: {
    V v_y_245 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24InR = heff_take_reuse_n(v_p_242, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_y_245)) {
    case TAG_InL: {
      V v_x_246 = heff_field(v_y_245, 0);
      V v_ru_24y_245_24InL = heff_take_reuse_n(v_y_245, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_x_246)) {
      case TAG_InL: {
        V v_x_247 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 1);
        heff_drop_cell(v_ru_24p_242_24InR, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1226459126x1628219458_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_x_247}));
        v_t_2411 = heff_tag_at_n(v_ru_24y_245_24InL, TAG_InL, 1, (V[]){v_t_248});
        break;
      }
      case TAG_InR: {
        V v_y_249 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 1);
        heff_drop_cell(v_ru_24y_245_24InL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(g_std_2ereactor_2ereactor_get(), 0)), 3, (V[]){v_m_240, v_g_241, v_y_249}));
        v_t_2411 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){v_t_2411});
      break;
    }
    case TAG_InR: {
      V v_y_2412 = heff_field(v_y_245, 0);
      heff_take_n(v_y_245, 1ULL, 1);
      heff_drop(v_m_240);
      V v_t_2417;
      switch (heff_tag_of(v_y_2412)) {
      case TAG_Send: {
        V v_rq_2413 = heff_field(v_y_2412, 0);
        V v_k_2414 = heff_field(v_y_2412, 1);
        V v_ru_24y_2412_24Send = heff_take_reuse_n(v_y_2412, 3ULL, 2);
        v_t_2417 = heff_tag_at_n(v_ru_24y_2412_24Send, TAG_Send, 2, (V[]){v_rq_2413, heff_clo_n(g_co_2eplus_24s1854017309x1005292301_lam1, 1, 2, (V[]){v_k_2414, v_g_241})});
        break;
      }
      default: heff_nomatch(v_y_2412);
      }
      v_t_2418 = heff_tag_at_n(v_ru_24p_242_24InR, TAG_InR, 1, (V[]){v_t_2417});
      break;
    }
    default: heff_nomatch(v_y_245);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2418});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_co_2eplus_24s1854017309x1005292301_lam2(V self, V *args) {
  V v_m_2419 = args[0];
  V v_n_2420 = args[1];
  V v_nt_2421 = args[2];
  V v_p_2422 = args[3];
  switch (heff_tag_of(v_p_2422)) {
  case TAG_InL: {
    V v_x_2423 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InL = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    heff_drop(v_m_2419);
    heff_drop(v_n_2420);
    heff_drop(v_nt_2421);
    V v_t_2436;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Start: {
      V v_parent_2424 = heff_field(v_x_2423, 0);
      V v_name_2425 = heff_field(v_x_2423, 1);
      V v_total_2426 = heff_field(v_x_2423, 2);
      V v_k_2427 = heff_field(v_x_2423, 3);
      V v_ru_24x_2423_24Start = heff_take_reuse_n(v_x_2423, 15ULL, 4);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24Start, TAG_Start, 4, (V[]){v_parent_2424, v_name_2425, v_total_2426, v_k_2427});
      break;
    }
    case TAG_Complete: {
      V v_t_2428 = heff_field(v_x_2423, 0);
      V v_x_2429 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24Complete = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24Complete, TAG_Complete, 2, (V[]){v_t_2428, v_x_2429});
      break;
    }
    case TAG_End: {
      V v_t_2430 = heff_field(v_x_2423, 0);
      V v_x_2431 = heff_field(v_x_2423, 1);
      V v_ru_24x_2423_24End = heff_take_reuse_n(v_x_2423, 3ULL, 2);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24End, TAG_End, 2, (V[]){v_t_2430, v_x_2431});
      break;
    }
    case TAG_RunUnder: {
      V v_t_2432 = heff_field(v_x_2423, 0);
      V v_cmd_2433 = heff_field(v_x_2423, 1);
      V v_as_2434 = heff_field(v_x_2423, 2);
      V v_k_2435 = heff_field(v_x_2423, 3);
      V v_ru_24x_2423_24RunUnder = heff_take_reuse_n(v_x_2423, 15ULL, 4);
      v_t_2436 = heff_tag_at_n(v_ru_24x_2423_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2432, v_cmd_2433, v_as_2434, v_k_2435});
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    return heff_tag_at_n(v_ru_24p_2422_24InL, TAG_InL, 1, (V[]){v_t_2436});
  }
  case TAG_InR: {
    V v_y_2437 = heff_field(v_p_2422, 0);
    V v_ru_24p_2422_24InR = heff_take_reuse_n(v_p_2422, 1ULL, 1);
    V v_t_2444;
    switch (heff_tag_of(v_y_2437)) {
    case TAG_InL: {
      V v_x_2438 = heff_field(v_y_2437, 0);
      V v_ru_24y_2437_24InL = heff_take_reuse_n(v_y_2437, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2422_24InR, 1);
      V v_t_2439 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s2124540091x1079095538_get(), 1)), 4, (V[]){v_m_2419, v_n_2420, v_nt_2421, v_x_2438}));
      v_t_2444 = heff_tag_at_n(v_ru_24y_2437_24InL, TAG_InL, 1, (V[]){v_t_2439});
      break;
    }
    case TAG_InR: {
      V v_y_2440 = heff_field(v_y_2437, 0);
      heff_take_n(v_y_2437, 1ULL, 1);
      heff_drop(v_m_2419);
      heff_drop(v_n_2420);
      heff_drop(v_nt_2421);
      V v_t_2443;
      switch (heff_tag_of(v_y_2440)) {
      case TAG_Send: {
        V v_rq_2441 = heff_field(v_y_2440, 0);
        V v_k_2442 = heff_field(v_y_2440, 1);
        V v_ru_24y_2440_24Send = heff_take_reuse_n(v_y_2440, 3ULL, 2);
        v_t_2443 = heff_tag_at_n(v_ru_24y_2440_24Send, TAG_Send, 2, (V[]){v_rq_2441, v_k_2442});
        break;
      }
      default: heff_nomatch(v_y_2440);
      }
      v_t_2444 = heff_tag_at_n(v_ru_24p_2422_24InR, TAG_InR, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_y_2437);
    }
    return heff_tag_n(TAG_InR, 1, (V[]){v_t_2444});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
HEFF_LIT(g_co_2eop_24s901899803x1656620254_str0, 2, ": ");
HEFF_LIT(g_co_2eop_24s901899803x1656620254_str1, 1, "\012");
V g_co_2eop_24s901899803x1656620254_lam1(V self, V *args);
V g_co_2eop_24s901899803x1656620254_lam0(V self, V *args); static Clo g_co_2eop_24s901899803x1656620254_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s901899803x1656620254_lam0, 4, 0};
V g_co_2eop_24s901899803x1656620254_lam3(V self, V *args);
V g_co_2eop_24s901899803x1656620254_lam2(V self, V *args);
V g_co_2eop_24s901899803x1656620254_lam4(V self, V *args);
V g_co_2eop_24s901899803x1656620254_lam5(V self, V *args);
Clo g_co_2eop_24s901899803x1656620254_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s901899803x1656620254_entry, 8, 0};

V g_co_2eop_24s901899803x1656620254(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s901899803x1656620254_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s901899803x1656620254_lam2, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s901899803x1656620254_lam4, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2420, heff_clo_n(g_co_2eop_24s901899803x1656620254_lam5, 1, 6, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s901899803x1656620254_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s901899803x1656620254(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_co_2eop_24s901899803x1656620254_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_tr(heff_call(v_g_248, 1, (V[]){v_x_2412}));
  V f_ = v_k_2411;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s901899803x1656620254_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_c_249 = args[1];
  V v_hd_2410 = args[2];
  V v_k_2411 = args[3];
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_co_2eop_24s901899803x1656620254_lam1, 1, 2, (V[]){v_g_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s901899803x1656620254_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2416}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s901899803x1656620254_lam2(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2415;
  args[1] = heff_clo_n(g_co_2eop_24s901899803x1656620254_lam3, 1, 2, (V[]){v_g_2414, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s901899803x1656620254_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s901899803x1656620254_lam5(V self, V *args) {
  V v_a_2421 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2421);
  V v_m_2422 = v_lit_240;
  V v_x2_2423 = v_lit_241;
  V v_n_2424 = heff_intAdd(v_lit_242, v_lit_243);
  V v_p_2425 = v_lit_244;
  V v_p_2426 = v_lit_245;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    heff_drop(v_m_2422);
    heff_drop(v_p_2425);
    V f_ = v_p_2426;
    args[0] = v_n_2424;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_l_2427 = heff_field(v_x2_2423, 0);
    V v_rest_2428 = heff_field(v_x2_2423, 1);
    V v_ru_24x2_2423_24Cons = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
    V v_t_2429 = heff_strAppend(heff_dup(v_m_2422), heff_strAppend(((V)&g_co_2eop_24s901899803x1656620254_str0), v_l_2427));
    V v_t_2430 = heff_tag_at_n(v_ru_24x2_2423_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_co_2eop_24s901899803x1656620254_str1)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    return (g_co_2eop_24s901899803x1656620254(v_m_2422, v_rest_2428, v_n_2424, MK_INT(1LL), heff_dup(v_p_2425), v_p_2426, heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_p_2425));
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_co_2eop_24s161437114x968393689_lam1(V self, V *args);
V g_co_2eop_24s161437114x968393689_lam0(V self, V *args); static Clo g_co_2eop_24s161437114x968393689_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s161437114x968393689_lam0, 4, 0};
V g_co_2eop_24s161437114x968393689_lam3(V self, V *args);
V g_co_2eop_24s161437114x968393689_lam2(V self, V *args);
V g_co_2eop_24s161437114x968393689_lam4(V self, V *args);
V g_co_2eop_24s161437114x968393689_lam5(V self, V *args);
Clo g_co_2eop_24s161437114x968393689_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s161437114x968393689_entry, 8, 0};

V g_co_2eop_24s161437114x968393689(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_p_246, V v_hd_247) {
top: ;
  V v_t_2419 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s161437114x968393689_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s161437114x968393689_lam2, 2, 1, (V[]){heff_dup(v_hd_247)})}), heff_clo_n(g_co_2eop_24s161437114x968393689_lam4, 1, 1, (V[]){heff_dup(v_hd_247)}), v_p_246}));
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2419}));
  return heff_tail(heff_get_n(v_hd_247, 1, 3), 2, (V[]){v_t_2420, heff_clo_n(g_co_2eop_24s161437114x968393689_lam5, 1, 6, (V[]){heff_dup(v_lit_240), v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245})});
}
V g_co_2eop_24s161437114x968393689_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_co_2eop_24s161437114x968393689(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_co_2eop_24s161437114x968393689_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_248 = heff_env(self)[0];
  V v_k_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = heff_tr(heff_call(v_g_248, 1, (V[]){v_x_2412}));
  V f_ = v_k_2411;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s161437114x968393689_lam0(V self, V *args) {
  V v_g_248 = args[0];
  V v_c_249 = args[1];
  V v_hd_2410 = args[2];
  V v_k_2411 = args[3];
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_co_2eop_24s161437114x968393689_lam1, 1, 2, (V[]){v_g_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s161437114x968393689_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_2414 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tr(heff_call(v_g_2414, 1, (V[]){v_x_2416}));
  V f_ = heff_get_n(v_hd_247, 0, 3);
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s161437114x968393689_lam2(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  args[0] = v_m_2415;
  args[1] = heff_clo_n(g_co_2eop_24s161437114x968393689_lam3, 1, 2, (V[]){v_g_2414, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s161437114x968393689_lam4(V self, V *args) {
  V v_c_2418 = args[0];
  V v_hd_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_get_n(v_hd_247, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s161437114x968393689_lam5(V self, V *args) {
  V v_a_2421 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_a_2421);
  V v_t_2422 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V r_ = (g_heff_2ebuild_2ecommands_2egoldensGo_24s172048507x649478386(a_0, a_1, a_2, a_3)); heff_drop(v_lit_240); r_; });
  V f_ = v_t_2422;
  heff_room[0] = v_lit_244;
  heff_room[1] = v_lit_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1622770744x67950580_lam1(V self, V *args);
V g_co_2eop_24s1622770744x67950580_lam0(V self, V *args); static Clo g_co_2eop_24s1622770744x67950580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1622770744x67950580_lam0, 4, 0};
V g_co_2eop_24s1622770744x67950580_lam3(V self, V *args);
V g_co_2eop_24s1622770744x67950580_lam2(V self, V *args);
V g_co_2eop_24s1622770744x67950580_lam4(V self, V *args);
V g_co_2eop_24s1622770744x67950580_lam5(V self, V *args);
Clo g_co_2eop_24s1622770744x67950580_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1622770744x67950580_entry, 10, 0};

V g_co_2eop_24s1622770744x67950580(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1622770744x67950580_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1622770744x67950580_lam2, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s1622770744x67950580_lam4, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s1622770744x67950580_lam5, 1, 8, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s1622770744x67950580_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s1622770744x67950580(a[0], a1, a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]); heff_drop(a1); return r;
}
V g_co_2eop_24s1622770744x67950580_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1622770744x67950580_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1622770744x67950580_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1622770744x67950580_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1622770744x67950580_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s1622770744x67950580_lam3, 1, 2, (V[]){v_g_2416, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1622770744x67950580_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1622770744x67950580_lam5(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_a_2423);
  V v_t_2424 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1374727810x31238532(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_241); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_lit_246;
  heff_room[1] = v_lit_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s868939913x277534373_lam1(V self, V *args);
V g_co_2eop_24s868939913x277534373_lam0(V self, V *args); static Clo g_co_2eop_24s868939913x277534373_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s868939913x277534373_lam0, 4, 0};
V g_co_2eop_24s868939913x277534373_lam3(V self, V *args);
V g_co_2eop_24s868939913x277534373_lam2(V self, V *args);
V g_co_2eop_24s868939913x277534373_lam4(V self, V *args);
V g_co_2eop_24s868939913x277534373_lam5(V self, V *args);
Clo g_co_2eop_24s868939913x277534373_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s868939913x277534373_entry, 9, 0};

V g_co_2eop_24s868939913x277534373(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_p_247, V v_hd_248) {
top: ;
  V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s868939913x277534373_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s868939913x277534373_lam2, 2, 1, (V[]){heff_dup(v_hd_248)})}), heff_clo_n(g_co_2eop_24s868939913x277534373_lam4, 1, 1, (V[]){heff_dup(v_hd_248)}), v_p_247}));
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2420}));
  return heff_tail(heff_get_n(v_hd_248, 1, 3), 2, (V[]){v_t_2421, heff_clo_n(g_co_2eop_24s868939913x277534373_lam5, 1, 7, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, heff_dup(v_lit_244), v_lit_245, v_lit_246})});
}
V g_co_2eop_24s868939913x277534373_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a4 = a[4]; V r = g_co_2eop_24s868939913x277534373(a[0], a1, a[2], a[3], a4, a[5], a[6], a[7], a[8]); heff_drop(a1); heff_drop(a4); return r;
}
V g_co_2eop_24s868939913x277534373_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2414 = heff_tr(heff_call(v_g_249, 1, (V[]){v_x_2413}));
  V f_ = v_k_2412;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s868939913x277534373_lam0(V self, V *args) {
  V v_g_249 = args[0];
  V v_c_2410 = args[1];
  V v_hd_2411 = args[2];
  V v_k_2412 = args[3];
  V f_ = v_c_2410;
  args[0] = v_hd_2411;
  args[1] = heff_clo_n(g_co_2eop_24s868939913x277534373_lam1, 1, 2, (V[]){v_g_249, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s868939913x277534373_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_call(v_g_2415, 1, (V[]){v_x_2417}));
  V f_ = heff_get_n(v_hd_248, 0, 3);
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s868939913x277534373_lam2(V self, V *args) {
  V v_g_2415 = args[0];
  V v_m_2416 = args[1];
  V v_hd_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_248, 1));
  args[0] = v_m_2416;
  args[1] = heff_clo_n(g_co_2eop_24s868939913x277534373_lam3, 1, 2, (V[]){v_g_2415, v_hd_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s868939913x277534373_lam4(V self, V *args) {
  V v_c_2419 = args[0];
  V v_hd_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_get_n(v_hd_248, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s868939913x277534373_lam5(V self, V *args) {
  V v_a_2422 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_a_2422);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V a_5 = v_lit_245; V a_6 = v_lit_246; V r_ = (g_heff_2ebuild_2ecommands_2eplaceIn_24s1373351161x236989245(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_241); heff_drop(v_lit_244); r_; });
}
V g_co_2eop_24s1179717641x1895974648_lam1(V self, V *args);
V g_co_2eop_24s1179717641x1895974648_lam0(V self, V *args); static Clo g_co_2eop_24s1179717641x1895974648_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1179717641x1895974648_lam0, 4, 0};
V g_co_2eop_24s1179717641x1895974648_lam3(V self, V *args);
V g_co_2eop_24s1179717641x1895974648_lam2(V self, V *args);
V g_co_2eop_24s1179717641x1895974648_lam4(V self, V *args);
V g_co_2eop_24s1179717641x1895974648_lam5(V self, V *args);
Clo g_co_2eop_24s1179717641x1895974648_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1179717641x1895974648_entry, 6, 0};

V g_co_2eop_24s1179717641x1895974648(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_hd_245) {
top: ;
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1179717641x1895974648_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1179717641x1895974648_lam2, 2, 1, (V[]){heff_dup(v_hd_245)})}), heff_clo_n(g_co_2eop_24s1179717641x1895974648_lam4, 1, 1, (V[]){heff_dup(v_hd_245)}), v_p_244}));
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2417}));
  return heff_tail(heff_get_n(v_hd_245, 1, 3), 2, (V[]){v_t_2418, heff_clo_n(g_co_2eop_24s1179717641x1895974648_lam5, 1, 4, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243})});
}
V g_co_2eop_24s1179717641x1895974648_entry(V self, V *a) {
  (void)self;
  return g_co_2eop_24s1179717641x1895974648(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_co_2eop_24s1179717641x1895974648_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2411 = heff_tr(heff_call(v_g_246, 1, (V[]){v_x_2410}));
  V f_ = v_k_249;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1179717641x1895974648_lam0(V self, V *args) {
  V v_g_246 = args[0];
  V v_c_247 = args[1];
  V v_hd_248 = args[2];
  V v_k_249 = args[3];
  V f_ = v_c_247;
  args[0] = v_hd_248;
  args[1] = heff_clo_n(g_co_2eop_24s1179717641x1895974648_lam1, 1, 2, (V[]){v_g_246, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1179717641x1895974648_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2412 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_g_2412, 1, (V[]){v_x_2414}));
  V f_ = heff_get_n(v_hd_245, 0, 3);
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1179717641x1895974648_lam2(V self, V *args) {
  V v_g_2412 = args[0];
  V v_m_2413 = args[1];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  args[0] = v_m_2413;
  args[1] = heff_clo_n(g_co_2eop_24s1179717641x1895974648_lam3, 1, 2, (V[]){v_g_2412, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1179717641x1895974648_lam4(V self, V *args) {
  V v_c_2416 = args[0];
  V v_hd_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_get_n(v_hd_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1179717641x1895974648_lam5(V self, V *args) {
  V v_a_2419 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_a_2419);
  return (g_heff_2ebuild_2edev_2estillRunning_24s1303602926x1963486001(v_lit_240, v_lit_241, v_lit_242, v_lit_243));
}
V g_co_2eop_24s1390932844x694948683_lam1(V self, V *args);
V g_co_2eop_24s1390932844x694948683_lam0(V self, V *args); static Clo g_co_2eop_24s1390932844x694948683_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1390932844x694948683_lam0, 4, 0};
V g_co_2eop_24s1390932844x694948683_lam3(V self, V *args);
V g_co_2eop_24s1390932844x694948683_lam2(V self, V *args);
V g_co_2eop_24s1390932844x694948683_lam4(V self, V *args);
V g_co_2eop_24s1390932844x694948683_lam5(V self, V *args);
Clo g_co_2eop_24s1390932844x694948683_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s1390932844x694948683_entry, 10, 0};

V g_co_2eop_24s1390932844x694948683(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_p_248, V v_hd_249) {
top: ;
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s1390932844x694948683_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s1390932844x694948683_lam2, 2, 1, (V[]){heff_dup(v_hd_249)})}), heff_clo_n(g_co_2eop_24s1390932844x694948683_lam4, 1, 1, (V[]){heff_dup(v_hd_249)}), v_p_248}));
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2421}));
  return heff_tail(heff_get_n(v_hd_249, 1, 3), 2, (V[]){v_t_2422, heff_clo_n(g_co_2eop_24s1390932844x694948683_lam5, 1, 8, (V[]){v_lit_243, v_lit_240, v_lit_241, heff_dup(v_lit_242), heff_dup(v_lit_244), v_lit_245, v_lit_246, v_lit_247})});
}
V g_co_2eop_24s1390932844x694948683_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_co_2eop_24s1390932844x694948683(a[0], a[1], a2, a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a2); heff_drop(a4); return r;
}
V g_co_2eop_24s1390932844x694948683_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_2410 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2415 = heff_tr(heff_call(v_g_2410, 1, (V[]){v_x_2414}));
  V f_ = v_k_2413;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1390932844x694948683_lam0(V self, V *args) {
  V v_g_2410 = args[0];
  V v_c_2411 = args[1];
  V v_hd_2412 = args[2];
  V v_k_2413 = args[3];
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_co_2eop_24s1390932844x694948683_lam1, 1, 2, (V[]){v_g_2410, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1390932844x694948683_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2416 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_g_2416, 1, (V[]){v_x_2418}));
  V f_ = heff_get_n(v_hd_249, 0, 3);
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s1390932844x694948683_lam2(V self, V *args) {
  V v_g_2416 = args[0];
  V v_m_2417 = args[1];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_249, 1));
  args[0] = v_m_2417;
  args[1] = heff_clo_n(g_co_2eop_24s1390932844x694948683_lam3, 1, 2, (V[]){v_g_2416, v_hd_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s1390932844x694948683_lam4(V self, V *args) {
  V v_c_2420 = args[0];
  V v_hd_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_get_n(v_hd_249, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s1390932844x694948683_lam5(V self, V *args) {
  V v_a_2423 = args[0];
  V v_lit_243 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  V v_lit_245 = heff_env(self)[5];
  V v_lit_246 = heff_env(self)[6];
  V v_lit_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_a_2423);
  V v_t_2424 = ({ V rv_4 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_lit_243, 15ULL, 5, shape_builds__wanted__port__proxy__pages, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_2425 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_t_2424; V a_4 = v_lit_244; V a_5 = v_lit_245; V r_ = (g_heff_2ebuild_2edev_2ecycle_24s531591947x1868948246(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_lit_242); heff_drop(v_lit_244); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_lit_246;
  heff_room[1] = v_lit_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s279158732x359344659_lam1(V self, V *args);
V g_co_2eop_24s279158732x359344659_lam0(V self, V *args); static Clo g_co_2eop_24s279158732x359344659_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s279158732x359344659_lam0, 4, 0};
V g_co_2eop_24s279158732x359344659_lam3(V self, V *args);
V g_co_2eop_24s279158732x359344659_lam2(V self, V *args);
V g_co_2eop_24s279158732x359344659_lam4(V self, V *args);
V g_co_2eop_24s279158732x359344659_lam5(V self, V *args);
Clo g_co_2eop_24s279158732x359344659_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s279158732x359344659_entry, 7, 0};

V g_co_2eop_24s279158732x359344659(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_p_245, V v_hd_246) {
top: ;
  V v_t_2432;
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_247 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_x_247)) {
    case TAG_Spawn: {
      V v_c_248 = heff_field(v_x_247, 0);
      V v_x_249 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24Spawn = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(v_hd_246), heff_dup(heff_rfield(v_hd_246, 0))}));
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Spawn, TAG_Spawn, 2, (V[]){v_t_2410, v_x_249});
      break;
    }
    case TAG_Yield: {
      V v_x_2411 = heff_field(v_x_247, 0);
      V v_ru_24x_247_24Yield = heff_take_reuse_n(v_x_247, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Yield, TAG_Yield, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_NewChan: {
      V v_k_2412 = heff_field(v_x_247, 0);
      V v_ru_24x_247_24NewChan = heff_take_reuse_n(v_x_247, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24NewChan, TAG_NewChan, 1, (V[]){v_k_2412});
      break;
    }
    case TAG_Send: {
      V v_ch_2413 = heff_field(v_x_247, 0);
      V v_v_2414 = heff_field(v_x_247, 1);
      V v_x_2415 = heff_field(v_x_247, 2);
      V v_ru_24x_247_24Send = heff_take_reuse_n(v_x_247, 7ULL, 3);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Send, TAG_Send, 3, (V[]){v_ch_2413, v_v_2414, v_x_2415});
      break;
    }
    case TAG_Recv: {
      V v_ch_2416 = heff_field(v_x_247, 0);
      V v_k_2417 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24Recv = heff_take_reuse_n(v_x_247, 3ULL, 2);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Recv, TAG_Recv, 2, (V[]){v_ch_2416, v_k_2417});
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    v_t_2432 = heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_2418});
    break;
  }
  case TAG_InR: {
    V v_y_2419 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s279158732x359344659_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s279158732x359344659_lam2, 2, 1, (V[]){heff_dup(v_hd_246)})}), heff_clo_n(g_co_2eop_24s279158732x359344659_lam4, 1, 1, (V[]){heff_dup(v_hd_246)}), v_y_2419}));
    v_t_2432 = heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2431});
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2432}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2433, heff_clo_n(g_co_2eop_24s279158732x359344659_lam5, 1, 5, (V[]){v_lit_240, heff_dup(v_lit_241), v_lit_242, v_lit_243, v_lit_244})});
}
V g_co_2eop_24s279158732x359344659_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_co_2eop_24s279158732x359344659(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_co_2eop_24s279158732x359344659_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2420 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2425 = heff_tr(heff_call(v_g_2420, 1, (V[]){v_x_2424}));
  V f_ = v_k_2423;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s279158732x359344659_lam0(V self, V *args) {
  V v_g_2420 = args[0];
  V v_c_2421 = args[1];
  V v_hd_2422 = args[2];
  V v_k_2423 = args[3];
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_co_2eop_24s279158732x359344659_lam1, 1, 2, (V[]){v_g_2420, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s279158732x359344659_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_2426 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_tr(heff_call(v_g_2426, 1, (V[]){v_x_2428}));
  V f_ = heff_get_n(v_hd_246, 0, 3);
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s279158732x359344659_lam2(V self, V *args) {
  V v_g_2426 = args[0];
  V v_m_2427 = args[1];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_m_2427;
  args[1] = heff_clo_n(g_co_2eop_24s279158732x359344659_lam3, 1, 2, (V[]){v_g_2426, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s279158732x359344659_lam4(V self, V *args) {
  V v_c_2430 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_get_n(v_hd_246, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s279158732x359344659_lam5(V self, V *args) {
  V v_a_2434 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_a_2434);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V r_ = (g_std_2ehttp_2eserver_2edrain_24s700459468x1684446361(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_241); r_; });
}
V g_co_2eop_24s728204878x155198609_lam1(V self, V *args);
V g_co_2eop_24s728204878x155198609_lam0(V self, V *args); static Clo g_co_2eop_24s728204878x155198609_lam0_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s728204878x155198609_lam0, 4, 0};
V g_co_2eop_24s728204878x155198609_lam3(V self, V *args);
V g_co_2eop_24s728204878x155198609_lam2(V self, V *args);
V g_co_2eop_24s728204878x155198609_lam4(V self, V *args);
V g_co_2eop_24s728204878x155198609_lam5(V self, V *args);
Clo g_co_2eop_24s728204878x155198609_clo = {{0x80000000u, K_CLO, 0}, g_co_2eop_24s728204878x155198609_entry, 7, 0};

V g_co_2eop_24s728204878x155198609(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_p_245, V v_hd_246) {
top: ;
  V v_t_2432;
  switch (heff_tag_of(v_p_245)) {
  case TAG_InL: {
    V v_x_247 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InL = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_x_247)) {
    case TAG_Spawn: {
      V v_c_248 = heff_field(v_x_247, 0);
      V v_x_249 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24Spawn = heff_take_reuse_n(v_x_247, 3ULL, 2);
      V v_t_2410 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(v_hd_246), heff_dup(heff_rfield(v_hd_246, 0))}));
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Spawn, TAG_Spawn, 2, (V[]){v_t_2410, v_x_249});
      break;
    }
    case TAG_Yield: {
      V v_x_2411 = heff_field(v_x_247, 0);
      V v_ru_24x_247_24Yield = heff_take_reuse_n(v_x_247, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Yield, TAG_Yield, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_NewChan: {
      V v_k_2412 = heff_field(v_x_247, 0);
      V v_ru_24x_247_24NewChan = heff_take_reuse_n(v_x_247, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24NewChan, TAG_NewChan, 1, (V[]){v_k_2412});
      break;
    }
    case TAG_Send: {
      V v_ch_2413 = heff_field(v_x_247, 0);
      V v_v_2414 = heff_field(v_x_247, 1);
      V v_x_2415 = heff_field(v_x_247, 2);
      V v_ru_24x_247_24Send = heff_take_reuse_n(v_x_247, 7ULL, 3);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Send, TAG_Send, 3, (V[]){v_ch_2413, v_v_2414, v_x_2415});
      break;
    }
    case TAG_Recv: {
      V v_ch_2416 = heff_field(v_x_247, 0);
      V v_k_2417 = heff_field(v_x_247, 1);
      V v_ru_24x_247_24Recv = heff_take_reuse_n(v_x_247, 3ULL, 2);
      v_t_2418 = heff_tag_at_n(v_ru_24x_247_24Recv, TAG_Recv, 2, (V[]){v_ch_2416, v_k_2417});
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    v_t_2432 = heff_tag_at_n(v_ru_24p_245_24InL, TAG_InL, 1, (V[]){v_t_2418});
    break;
  }
  case TAG_InR: {
    V v_y_2419 = heff_field(v_p_245, 0);
    V v_ru_24p_245_24InR = heff_take_reuse_n(v_p_245, 1ULL, 1);
    V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1854017309x1005292301_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_co_2eop_24s728204878x155198609_lam0_clo)}), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_co_2eop_24s728204878x155198609_lam2, 2, 1, (V[]){heff_dup(v_hd_246)})}), heff_clo_n(g_co_2eop_24s728204878x155198609_lam4, 1, 1, (V[]){heff_dup(v_hd_246)}), v_y_2419}));
    v_t_2432 = heff_tag_at_n(v_ru_24p_245_24InR, TAG_InR, 1, (V[]){v_t_2431});
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2432}));
  return heff_tail(heff_get_n(v_hd_246, 1, 3), 2, (V[]){v_t_2433, heff_clo_n(g_co_2eop_24s728204878x155198609_lam5, 1, 5, (V[]){v_lit_240, v_lit_241, heff_dup(v_lit_242), v_lit_243, v_lit_244})});
}
V g_co_2eop_24s728204878x155198609_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_co_2eop_24s728204878x155198609(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_co_2eop_24s728204878x155198609_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_g_2420 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2425 = heff_tr(heff_call(v_g_2420, 1, (V[]){v_x_2424}));
  V f_ = v_k_2423;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s728204878x155198609_lam0(V self, V *args) {
  V v_g_2420 = args[0];
  V v_c_2421 = args[1];
  V v_hd_2422 = args[2];
  V v_k_2423 = args[3];
  V f_ = v_c_2421;
  args[0] = v_hd_2422;
  args[1] = heff_clo_n(g_co_2eop_24s728204878x155198609_lam1, 1, 2, (V[]){v_g_2420, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s728204878x155198609_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_2426 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_tr(heff_call(v_g_2426, 1, (V[]){v_x_2428}));
  V f_ = heff_get_n(v_hd_246, 0, 3);
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_co_2eop_24s728204878x155198609_lam2(V self, V *args) {
  V v_g_2426 = args[0];
  V v_m_2427 = args[1];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_m_2427;
  args[1] = heff_clo_n(g_co_2eop_24s728204878x155198609_lam3, 1, 2, (V[]){v_g_2426, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_co_2eop_24s728204878x155198609_lam4(V self, V *args) {
  V v_c_2430 = args[0];
  V v_hd_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_get_n(v_hd_246, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_co_2eop_24s728204878x155198609_lam5(V self, V *args) {
  V v_a_2434 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_a_2434);
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_lit_244; V r_ = (g_std_2ehttp_2eserver_2eserveConnection_24s76270986x1441914551(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_lit_242); r_; });
}