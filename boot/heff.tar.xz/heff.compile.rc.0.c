// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CAbandon 30933
#define TAG_CDecl 45531
#define TAG_CLet 49341
#define TAG_CReturn 19985
#define TAG_CSet 56068
#define TAG_F32 16337
#define TAG_Given 9359
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_KnownCell 38933
#define TAG_KnownClo 18392
#define TAG_KnownRec 32578
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkCode 2932
#define TAG_MkDrop 35958
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RAbandon 7524
#define TAG_RApply 9191
#define TAG_RBool 22760
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RCall 39004
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RDupE 22574
#define TAG_RF32 30142
#define TAG_RF32U 16824
#define TAG_RF64U 19769
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RFixU 5362
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLam 37393
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPeek 36757
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RPrimU 23344
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RTagIn 62720
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RWord 58722
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_after 294093302
#define LBL_args 9498020
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_fixed 298804110
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_op 10312
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_takes 311482598
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_ret};
V g_heff_2ecompile_2erc_2eapplyLast(V, V, V);
V g_heff_2ecompile_2erc_2eapplyLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eapplyLast_clo;
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_clo;
V g_heff_2ecompile_2erc_2eboolDone(V, V);
V g_heff_2ecompile_2erc_2eboolDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eboolDone_clo;
V g_heff_2ecompile_2erc_2eboolName_get(void);
V g_heff_2ecompile_2erc_2ebuiltOf(V);
V g_heff_2ecompile_2erc_2ebuiltOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ebuiltOf_clo;
V g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305(V, V, V);
V g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305_clo;
V g_heff_2ecompile_2erc_2ecoerce(V, V, V);
V g_heff_2ecompile_2erc_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecoerce_clo;
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(V, V, V, V);
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_clo;
V g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(V, V, V);
V g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_clo;
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(V, V);
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_clo;
V g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(V, V, V, V);
V g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_clo;
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_clo;
V g_heff_2ecompile_2erc_2edropOf(V, V);
V g_heff_2ecompile_2erc_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2edropOf_clo;
V g_heff_2ecompile_2erc_2edropsOf(V, V);
V g_heff_2ecompile_2erc_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2edropsOf_clo;
V g_heff_2ecompile_2erc_2eelemI(V, V);
V g_heff_2ecompile_2erc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemI_clo;
V g_heff_2ecompile_2erc_2eelemS(V, V);
V g_heff_2ecompile_2erc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemS_clo;
V g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_clo;
V g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_clo;
V g_heff_2ecompile_2erc_2efieldLentOf(V, V, V, V);
V g_heff_2ecompile_2erc_2efieldLentOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldLentOf_clo;
V g_heff_2ecompile_2erc_2efreeOf(V, V);
V g_heff_2ecompile_2erc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efreeOf_clo;
V g_heff_2ecompile_2erc_2efunRc(V, V, V, V);
V g_heff_2ecompile_2erc_2efunRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efunRc_clo;
V g_heff_2ecompile_2erc_2efunWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efunWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efunWith_clo;
V g_heff_2ecompile_2erc_2efvOp(V);
V g_heff_2ecompile_2erc_2efvOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvOp_clo;
V g_heff_2ecompile_2erc_2efvRest(V, V);
V g_heff_2ecompile_2erc_2efvRest_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvRest_clo;
V g_heff_2ecompile_2erc_2efvSts(V);
V g_heff_2ecompile_2erc_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvSts_clo;
V g_heff_2ecompile_2erc_2efvTl(V);
V g_heff_2ecompile_2erc_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvTl_clo;
V g_heff_2ecompile_2erc_2eindexIn(V, V, V);
V g_heff_2ecompile_2erc_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eindexIn_clo;
V g_heff_2ecompile_2erc_2ejustsOf(V);
V g_heff_2ecompile_2erc_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ejustsOf_clo;
V g_heff_2ecompile_2erc_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erc_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938(V, V, V, V);
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_clo;
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780(V, V, V, V, V);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_clo;
V g_heff_2ecompile_2erc_2elentField(V, V, V);
V g_heff_2ecompile_2erc_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentField_clo;
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_clo;
V g_heff_2ecompile_2erc_2elentTo(V);
V g_heff_2ecompile_2erc_2elentTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentTo_clo;
V g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_clo;
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_clo;
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004(V, V, V, V);
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_clo;
V g_heff_2ecompile_2erc_2enaturalOf(V, V);
V g_heff_2ecompile_2erc_2enaturalOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2enaturalOf_clo;
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_clo;
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(V, V, V);
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_clo;
V g_heff_2ecompile_2erc_2eoperandsOf(V);
V g_heff_2ecompile_2erc_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsOf_clo;
V g_heff_2ecompile_2erc_2epow2(V);
V g_heff_2ecompile_2erc_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2epow2_clo;
V g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_clo;
V g_heff_2ecompile_2erc_2ereusePrim_get(void);
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(V, V, V);
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_clo;
V g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416(V, V, V);
V g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_clo;
V g_heff_2ecompile_2erc_2ereusedOf(V);
V g_heff_2ecompile_2erc_2ereusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereusedOf_clo;
V g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(V, V);
V g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139_clo;
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_clo;
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(V, V, V);
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_clo;
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(V, V);
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_clo;
V g_heff_2ecompile_2erc_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erc_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakesAt_clo;
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074(V, V, V);
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_clo;
V g_heff_2ecompile_2erc_2eunboxOf(V, V);
V g_heff_2ecompile_2erc_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eunboxOf_clo;
V g_heff_2ecompile_2erc_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erc_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eunboxParam_clo;
V g_heff_2ecompile_2erc_2eunboxParams(V, V, V, V);
V g_heff_2ecompile_2erc_2eunboxParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eunboxParams_clo;
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(V, V, V, V);
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_clo;
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(V, V, V);
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_clo;
V g_heff_2ecompile_2erc_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erc_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewithFrame_clo;
V g_heff_2ecompile_2erc_2ewrapUnbox(V, V, V);
V g_heff_2ecompile_2erc_2ewrapUnbox_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewrapUnbox_clo;
V g_heff_2ecompile_2erepr_2efloatShape(V);
V g_heff_2ecompile_2erepr_2efloatShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efloatShape_clo;
V g_heff_2ecompile_2erepr_2eopShape(V, V);
V g_heff_2ecompile_2erepr_2eopShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eopShape_clo;
V g_heff_2ecompile_2erepr_2ereadRepr(V, V);
V g_heff_2ecompile_2erepr_2ereadRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereadRepr_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1419248316x13095286(V, V, V);
V g_list_2efoldl_24f1419248316x13095286_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1419248316x13095286_clo;
V g_list_2efoldl_24f1686830387x1555365313(V, V, V, V);
V g_list_2efoldl_24f1686830387x1555365313_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1686830387x1555365313_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1651310864x859456474(V, V);
V g_list_2efoldl_24s1651310864x859456474_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1651310864x859456474_clo;
V g_list_2efoldl_24s1790904629x1122008408(V, V);
V g_list_2efoldl_24s1790904629x1122008408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1790904629x1122008408_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1341404685x1564972929(V);
V g_list_2emap_24s1341404685x1564972929_entry(V self, V *a);
extern Clo g_list_2emap_24s1341404685x1564972929_clo;
V g_list_2emap_24s1598879313x231311047(V);
V g_list_2emap_24s1598879313x231311047_entry(V self, V *a);
extern Clo g_list_2emap_24s1598879313x231311047_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s471405029x78128406(V);
V g_list_2emap_24s471405029x78128406_entry(V self, V *a);
extern Clo g_list_2emap_24s471405029x78128406_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
Clo g_heff_2ecompile_2erc_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2erc_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2eelemS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2eelemS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erc_2ewithFrame_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ewithFrame_entry, 3, 0};

V g_heff_2ecompile_2erc_2ewithFrame(V v_s_240, V v_n_241, V v_ce_242) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_s_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_s_243 = heff_dup(heff_field(v_s_240, 0));
    V v_x1_244 = (g_map_2elookup_24s1546226666x2146984184(heff_get_n(v_s_243, 0, 2), heff_rfield(v_ce_242, 11)));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_s_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 1);
      v_t_246 = heff_get_n(v_s_245, 1, 2);
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    break;
  }
  default: heff_nomatch(v_s_240);
  }
  return ({ V rv_2 = v_s_240; V rv_3 = v_n_241; V rv_9 = NTAG(TAG_Nil); V rv_12 = v_t_246; V rr_ = heff_rec_reuse_nf(v_ce_242, 3571ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 15990543u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 12) = rv_12; rr_; });
}
V g_heff_2ecompile_2erc_2ewithFrame_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ewithFrame(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2edropOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2edropOf_entry, 2, 0};

V g_heff_2ecompile_2erc_2edropOf(V v_x_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_k_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_242 = heff_dup(heff_field(v_k_241, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_KnownTag: {
      V v_n_243 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_243)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    case TAG_KnownCell: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownRec: {
      heff_take_n(v_x11_242, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
    }
    case TAG_KnownClo: {
      V v_n_247 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      if (heff_intLt_c(MK_INT(0LL), v_n_247)) {
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkDrop, 2, (V[]){v_x_240, v_k_241}), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_x_240);
        heff_drop_tag(v_k_241, 1);
        return NTAG(TAG_Nil);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_k_241);
  }
}
V g_heff_2ecompile_2erc_2edropOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2edropOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2eindexIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eindexIn_entry, 3, 0};

V g_heff_2ecompile_2erc_2eindexIn(V v_l_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_ks_244 = heff_field(v_x3_242, 1);
    if (heff_strEq_c(heff_dup(v_l_240), heff_dup(v_k_243))) {
      heff_drop(v_l_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_l_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_ks_244;
      v_l_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2eindexIn_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2eindexIn(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2efieldLentOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efieldLentOf_entry, 4, 0};

V g_heff_2ecompile_2erc_2efieldLentOf(V v_ce_240, V v_after_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_i_243);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_i_243)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_i_243, 0);
      V v_ru_24i_243_24Just = heff_take_reuse_n(v_i_243, 1ULL, 1);
      V v_t_246 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_244), v_after_241));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_t_246);
        V v_t_247 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_RLocal, 1, (V[]){v_x_244}), v_i_245});
        return heff_tag_at_n(v_ru_24i_243_24Just, TAG_Just, 1, (V[]){v_t_247});
      } else {
        heff_drop(v_t_246);
        V v_t_248 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get_n(v_ce_240, 6, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          V v_t_249 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_RLocal, 1, (V[]){v_x_244}), v_i_245});
          return heff_tag_at_n(v_ru_24i_243_24Just, TAG_Just, 1, (V[]){v_t_249});
        } else {
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x3_242_24Just, 1);
          heff_drop(v_i_245);
          heff_drop_cell(v_ru_24i_243_24Just, 1);
          heff_drop(v_t_248);
          return NTAG(TAG_Nothing);
        }
      }
    }
    default: return heff_nomatch(v_i_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2efieldLentOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2efieldLentOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erc_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2erc_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2erc_2ejustsOf_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ejustsOf(a[0]);
}
Clo g_heff_2ecompile_2erc_2eunboxOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eunboxOf_entry, 2, 0};

V g_heff_2ecompile_2erc_2eunboxOf(V v_rp_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_RLocal: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDup: {
    V v_x_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RDup = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RDup, TAG_RLocal, 1, (V[]){v_x_243})});
  }
  case TAG_RClo: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGet: {
    V v_g_245 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24RGet = heff_take_reuse_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, heff_tag_at_n(v_ru_24v_241_24RGet, TAG_RGetRaw, 1, (V[]){v_g_245})});
  }
  case TAG_RGetRaw: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RInt: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFloat: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RStr: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBytes: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixed: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RNTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTag: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTagIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRec: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RRecIn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RDupE: {
    V v_e_2432 = heff_field(v_v_241, 0);
    heff_take_n(v_v_241, 1ULL, 1);
    return heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_240, v_e_2432});
  }
  case TAG_RFieldV: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetN: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFieldU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetNU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RWord: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RTakeField: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RGetLabel: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimFn: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrim: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RLam: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RCall: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RApply: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBool: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RAbandon: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RBox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RUnbox: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPeek: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RPrimU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RFixU: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF32U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  case TAG_RF64U: {
    return heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_240, v_v_241});
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erc_2eunboxOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eunboxOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2elentTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2elentTo_entry, 1, 0};

V g_heff_2ecompile_2erc_2elentTo(V v_ce_240) {
top: ;
  V v_bs_241 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_ce_240, 4)), heff_take_field(v_ce_240, 6)));
  V v_ce_242 = ({ V rv_6 = v_bs_241; V rr_ = heff_rec_reuse_nf(v_ce_240, 8127ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67096575u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  return ({ V rv_9 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_ce_242, 7679ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 66322431u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
}
V g_heff_2ecompile_2erc_2elentTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2elentTo(a[0]);
}
Clo g_heff_2ecompile_2erc_2epow2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2epow2_entry, 1, 0};

V g_heff_2ecompile_2erc_2epow2(V v_n_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ecompile_2erc_2epow2(heff_intSub(v_n_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(2LL), v_t_242);
  }
}
V g_heff_2ecompile_2erc_2epow2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2epow2(a[0]);
}
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_entry, 3, 0};

V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074(V v_ru_240, V v_n_241, V v_arms_242) {
top: ;
  V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_242));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_242));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2419});
}
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_t_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 4ULL, 3);
    V v_x1_247 = (g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(v_ru_240, v_n_241, v_t_246));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      return v_x_248;
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_arm_243);
  }
}
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_b_2414 = heff_field(v_arm_2411, 2);
    V v_ru_24arm_2411_24MkArm = heff_take_reuse_n(v_arm_2411, 7ULL, 3);
    V v_x1_2415 = (g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(v_ru_240, v_n_241, v_b_2414));
    V v_t_2418;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_y_2417 = heff_field(v_x1_2415, 1);
      heff_take_n(v_x1_2415, 2ULL, 2);
      v_t_2418 = v_y_2417;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return heff_tag_at_n(v_ru_24arm_2411_24MkArm, TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_t_2418});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
Clo g_heff_2ecompile_2erc_2ebuiltOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ebuiltOf_entry, 1, 0};

V g_heff_2ecompile_2erc_2ebuiltOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_OSimple: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24OSimple = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_SVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      V v_xs_2412 = heff_field(v_x11_241, 0);
      V v_x112_2413 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      switch (heff_tag_of(v_x112_2413)) {
      case TAG_MkBlock: {
        V v_t_2414 = heff_field(v_x112_2413, 0);
        heff_take_n(v_x112_2413, 1ULL, 1);
        V v_xs_2415 = (g_heff_2ecompile_2erc_2efreeOf(v_xs_2412, v_t_2414));
        V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2415; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
        return heff_tag_at_n(v_ru_24x1_240_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownClo, 1, (V[]){v_t_2416})});
      }
      default: return heff_nomatch(v_x112_2413);
      }
    }
    case TAG_STag: {
      V v_as_2418 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      V v_t_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2418; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2418); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2419})});
    }
    case TAG_SRec: {
      V v_fs_2420 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      V v_t_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2420; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_fs_2420); r_; });
      return heff_tag_at_n(v_ru_24x1_240_24OSimple, TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownRec, 1, (V[]){v_t_2422})});
    }
    case TAG_SProj: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      V v_p_2427 = heff_field(v_x11_241, 0);
      V v_as_2428 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24OSimple, 1);
      if (heff_strEq_c(v_p_2427, heff_dup(g_heff_2ecompile_2erc_2ereusePrim_get()))) {
        return ({ V a_0 = v_as_2428; V r_ = (g_heff_2ecompile_2erc_2ereusedOf(a_0)); heff_drop(v_as_2428); r_; });
      } else {
        heff_drop(v_as_2428);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_OCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OApply: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OPrim: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_OBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2ebuiltOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ebuiltOf(a[0]);
}
V g_heff_2ecompile_2erc_2eunboxParams_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2eunboxParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eunboxParams_entry, 4, 0};

V g_heff_2ecompile_2erc_2eunboxParams(V v_ce_240, V v_bi_241, V v_rps_242, V v_xs_243) {
top: ;
  V v_t_244 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_243), v_rps_242));
  V v_t_245 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_245, MK_INT(1LL))));
  V v_t_2417 = (g_list_2efoldl_24f1686830387x1555365313(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erc_2eunboxParams_lam0, 2, 2, (V[]){heff_dup(v_bi_241), v_ce_240}), v_t_244, v_t_246));
  return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1651310864x859456474(a_0, a_1)); heff_drop(v_t_2417); r_; });
}
V g_heff_2ecompile_2erc_2eunboxParams_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2eunboxParams(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2eunboxParams_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_i_248 = args[1];
  V v_bi_241 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_lent_249 = ({ V a_0 = v_i_248; V a_1 = v_bi_241; V r_ = (g_heff_2ecompile_2erc_2eelemI(a_0, a_1)); heff_drop(v_bi_241); r_; });
  V v_rp_2412;
  switch (heff_tag_of(v_p_247)) {
  case TAG_MkPair: {
    V v_y_2411 = heff_dup(heff_field(v_p_247, 1));
    v_rp_2412 = v_y_2411;
    break;
  }
  default: heff_nomatch(v_p_247);
  }
  V v_x_2415;
  switch (heff_tag_of(v_p_247)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_247, 0);
    heff_take_n(v_p_247, 1ULL, 2);
    v_x_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_247);
  }
  switch (heff_tag_of(v_rp_2412)) {
  case TAG_RepV: {
    return ({ V a_0 = v_ce_240; V a_1 = v_lent_249; V a_2 = v_x_2415; V r_ = (g_heff_2ecompile_2erc_2eunboxParam(a_0, a_1, a_2)); heff_drop(v_lent_249); r_; });
  }
  case TAG_RepFix: {
    heff_take_n(v_rp_2412, 0ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    heff_drop(v_x_2415);
    return NTAG(TAG_Nil);
  }
  case TAG_RepF64: {
    heff_drop(v_ce_240);
    heff_drop(v_lent_249);
    heff_drop(v_x_2415);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_rp_2412);
  }
}
HEFF_LIT(g_heff_2ecompile_2erc_2ewrapUnbox_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erc_2ewrapUnbox_str1, 4, "box$");
Clo g_heff_2ecompile_2erc_2ewrapUnbox_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ewrapUnbox_entry, 3, 0};

V g_heff_2ecompile_2erc_2ewrapUnbox(V v_lent_240, V v_rp_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_rp_241)) {
  case TAG_RepV: {
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_RepFix: {
    V v_v_244 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erc_2ewrapUnbox_str0), heff_dup(v_x_242))});
    V v_t_245;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_245 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_244});
    } else {
      v_t_245 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_244});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_245}), NTAG(TAG_Nil)});
  }
  case TAG_RepF64: {
    V v_v_246 = heff_tag_n(TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erc_2ewrapUnbox_str1), heff_dup(v_x_242))});
    V v_t_247;
    if ((heff_dup(v_lent_240) == NTAG(TAG_True))) {
      v_t_247 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_241, v_v_246});
    } else {
      v_t_247 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_241, v_v_246});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_247}), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_rp_241);
  }
}
V g_heff_2ecompile_2erc_2ewrapUnbox_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erc_2ewrapUnbox(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_str0, 4, "box$");
HEFF_LIT(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_str1, 4, "box$");
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam3(V self, V *args);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam4(V self, V *args);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam5(V self, V *args);
Clo g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_entry, 5, 0};

V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780(V v_ce_240, V v_live_241, V v_xs_242, V v_t_243, V v_fv_244) {
top: ;
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_xs_242)));
  V v_t_2412 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_fv_244)));
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam2, 1, 2, (V[]){heff_dup(v_ce_240), v_live_241}), heff_dup(v_fv_244)));
  V v_t_2415 = (g_list_2efoldl_24f1419248316x13095286(NTAG(TAG_Nil), heff_dup(v_xs_242), heff_dup(v_fv_244)));
  V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam3, 2, 1, (V[]){heff_dup(v_ce_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  V v_wanted_2420 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_243)));
  V v_xs_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam4, 1, 1, (V[]){v_wanted_2420}), heff_dup(v_xs_242)));
  V v_t_2428 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam5, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2423));
  V v_t_2429 = (g_list_2emap_24s1901363476x1479927424(v_t_2428));
  V v_t_2430 = (g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938(v_ce_240, v_xs_242, v_t_243, v_fv_244));
  V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2429, v_t_2430));
  V v_t_2432 = (g_prelude_2e_2b_2b(v_t_2419, v_t_2431));
  return heff_tag_n(TAG_RLam, 4, (V[]){v_t_248, v_t_2412, v_t_2414, heff_tag_n(TAG_MkCode, 1, (V[]){v_t_2432})});
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_246 = ({ V a_0 = heff_dup(v_x_245); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    return v_x_245;
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    return heff_strAppend(((V)&g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_str0), v_x_245);
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2410 = ({ V a_0 = heff_dup(v_x_249); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_2410)) {
  case TAG_Nothing: {
    return v_x_249;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2410, 0ULL, 1);
    return heff_strAppend(((V)&g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_str1), v_x_249);
  }
  default: return heff_nomatch(v_x3_2410);
  }
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), heff_tag_n(TAG_SVar, 1, (V[]){v_x_2413})));
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam3(V self, V *args) {
  V v_acc_2416 = args[0];
  V v_x_2417 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2418 = ({ V a_0 = v_ce_240; V b_1 = NTAG(TAG_False); V a_2 = v_x_2417; V r_ = (g_heff_2ecompile_2erc_2eunboxParam(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_2416));
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam4(V self, V *args) {
  V v_v_2421 = args[0];
  V v_wanted_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2422 = ({ V a_0 = v_v_2421; V a_1 = v_wanted_2420; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2420); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2422) == NTAG(TAG_True)));
  heff_drop(v_x1_2422);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2425 = ({ V a_0 = v_x_2424; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2427;
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Nothing: {
    v_x1_2427 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2425, 0ULL, 1);
    v_x1_2427 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2425);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2427) == NTAG(TAG_True)));
  heff_drop(v_x1_2427);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_entry, 6, 0};

V g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244, V v_may_245) {
top: ;
  V v_t_2428;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    V v_x_246 = heff_dup(heff_field(v_e_242, 0));
    v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
    break;
  }
  case TAG_SGlobal: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SInt: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  V v_t_2451;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SGlobal: {
    V v_g_2430 = heff_dup(heff_field(v_e_242, 0));
    v_t_2451 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2430});
    break;
  }
  case TAG_SInt: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SStr: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SBytes: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFixed: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SFloat32: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrimFn: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SLam: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_STag: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SRec: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SProj: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_SPrim: {
    v_t_2451 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_e_242);
  }
  return (g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533(v_ce_240, v_live_241, v_e_242, v_i_243, v_n_244, v_may_245, v_t_2428, v_t_2451));
}
V g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_entry, 3, 0};

V g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
  }
  case TAG_Cons: {
    V v_ru_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_ru_243);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
    }
    case TAG_Cons: {
      V v_x421_245 = heff_field(v_x42_244, 0);
      V v_x422_246 = heff_field(v_x42_244, 1);
      heff_take_n(v_x42_244, 3ULL, 2);
      switch (heff_tag_of(v_x421_245)) {
      case TAG_SVar: {
        V v_ru_24x421_245_24SVar = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SVar, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SGlobal: {
        V v_ru_24x421_245_24SGlobal = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SGlobal, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SInt: {
        V v_ru_24x421_245_24SInt = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SInt, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFloat: {
        V v_ru_24x421_245_24SFloat = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SFloat, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SStr: {
        V v_ru_24x421_245_24SStr = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SStr, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SBytes: {
        V v_ru_24x421_245_24SBytes = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SBytes, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFixed: {
        heff_take_n(v_x421_245, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SFloat32: {
        V v_ru_24x421_245_24SFloat32 = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SFloat32, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SPrimFn: {
        V v_ru_24x421_245_24SPrimFn = heff_take_reuse_n(v_x421_245, 0ULL, 1);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_at_n(v_ru_24x421_245_24SPrimFn, TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SLam: {
        heff_take_n(v_x421_245, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_STag: {
        V v_t_2419 = heff_field(v_x421_245, 0);
        V v_as_2420 = heff_field(v_x421_245, 1);
        heff_take_n(v_x421_245, 3ULL, 2);
        switch (heff_tag_of(v_x422_246)) {
        case TAG_Nil: {
          V v_x2_2421 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_ru_243, v_as_2420})));
          switch (heff_tag_of(v_x2_2421)) {
          case TAG_Nil: {
            heff_drop(v_t_2419);
            return NTAG(TAG_RAbandon);
          }
          case TAG_Cons: {
            V v_rv_2422 = heff_field(v_x2_2421, 0);
            V v_vs_2423 = heff_field(v_x2_2421, 1);
            heff_take_n(v_x2_2421, 3ULL, 2);
            return heff_tag_n(TAG_RTagIn, 3, (V[]){v_rv_2422, v_t_2419, v_vs_2423});
          }
          default: return heff_nomatch(v_x2_2421);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_x422_246, 0ULL, 2);
          heff_drop(v_ce_240);
          heff_drop(v_live_241);
          heff_drop(v_ru_243);
          heff_drop_cell(v_ru_24x4_242_24Cons, 2);
          heff_drop(v_t_2419);
          heff_drop(v_as_2420);
          return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
        }
        default: return heff_nomatch(v_x422_246);
        }
      }
      case TAG_SRec: {
        heff_take_n(v_x421_245, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SProj: {
        heff_take_n(v_x421_245, 0ULL, 4);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      case TAG_SPrim: {
        heff_take_n(v_x421_245, 0ULL, 2);
        heff_drop(v_ce_240);
        heff_drop(v_live_241);
        heff_drop(v_ru_243);
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_x422_246);
        return heff_tag_n(TAG_RInt, 1, (V[]){MK_INT(0LL)});
      }
      default: return heff_nomatch(v_x421_245);
      }
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str0, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str1, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str2, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str3, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str4, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str5, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str6, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str7, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str8, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str9, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str10, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str11, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str12, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str13, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str14, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str15, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str16, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str17, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str18, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str19, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str20, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str21, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str22, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str23, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str24, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str25, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str26, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str27, 7, "Float32");
Clo g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_entry, 4, 0};

V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(V v_ce_240, V v_live_241, V v_want_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_v_243)) {
  case TAG_SVar: {
    V v_t_245 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_246 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_245, v_want_242, v_t_246));
  }
  case TAG_SGlobal: {
    V v_t_248 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_249 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_248, v_want_242, v_t_249));
  }
  case TAG_SInt: {
    V v_t_2411 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2412 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2411, v_want_242, v_t_2412));
  }
  case TAG_SFloat: {
    V v_x_2413 = heff_field(v_v_243, 0);
    V v_ru_24v_243_24SFloat = heff_take_reuse_n(v_v_243, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFloat, TAG_RFloat, 1, (V[]){v_x_2413})));
    }
    case TAG_RepFix: {
      return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFloat, TAG_RFloat, 1, (V[]){v_x_2413})));
    }
    case TAG_RepF64: {
      return heff_tag_at_n(v_ru_24v_243_24SFloat, TAG_RF64U, 1, (V[]){v_x_2413});
    }
    default: return heff_nomatch(v_want_242);
    }
  }
  case TAG_SStr: {
    V v_t_2416 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2417 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2416, v_want_242, v_t_2417));
  }
  case TAG_SBytes: {
    V v_t_2419 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2420 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2419, v_want_242, v_t_2420));
  }
  case TAG_SFixed: {
    V v_w_2421 = heff_field(v_v_243, 0);
    V v_n_2422 = heff_field(v_v_243, 1);
    V v_ru_24v_243_24SFixed = heff_take_reuse_n(v_v_243, 3ULL, 2);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    V v_t_2426;
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    case TAG_RepFix: {
      V v_b1_2423 = heff_dup(heff_field(v_want_242, 0));
      V v_t_2424;
      switch (heff_tag_of(v_w_2421)) {
      case TAG_I8: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str0);
        break;
      }
      case TAG_I16: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str1);
        break;
      }
      case TAG_I32: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str2);
        break;
      }
      case TAG_I64: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str3);
        break;
      }
      case TAG_U8: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str4);
        break;
      }
      case TAG_U16: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str5);
        break;
      }
      case TAG_U32: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str6);
        break;
      }
      case TAG_U64: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str7);
        break;
      }
      case TAG_F32: {
        v_t_2424 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str8);
        break;
      }
      default: heff_nomatch(v_w_2421);
      }
      V v_t_2425;
      switch (heff_tag_of(v_b1_2423)) {
      case TAG_I8: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str9);
        break;
      }
      case TAG_I16: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str10);
        break;
      }
      case TAG_I32: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str11);
        break;
      }
      case TAG_I64: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str12);
        break;
      }
      case TAG_U8: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str13);
        break;
      }
      case TAG_U16: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str14);
        break;
      }
      case TAG_U32: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str15);
        break;
      }
      case TAG_U64: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str16);
        break;
      }
      case TAG_F32: {
        v_t_2425 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str17);
        break;
      }
      default: heff_nomatch(v_b1_2423);
      }
      v_t_2426 = heff_strEq(v_t_2424, v_t_2425);
      break;
    }
    case TAG_RepF64: {
      v_t_2426 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_want_242);
    }
    if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
      heff_drop(v_want_242);
      heff_drop(v_t_2426);
      return heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixU, 2, (V[]){v_w_2421, v_n_2422});
    } else {
      heff_drop(v_t_2426);
      V v_t_2428;
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2428 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2428 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
        heff_drop(v_want_242);
        heff_drop(v_t_2428);
        return heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2421, v_n_2422});
      } else {
        heff_drop(v_t_2428);
        switch (heff_tag_of(v_want_242)) {
        case TAG_RepV: {
          return heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RBox, 2, (V[]){NTAG(TAG_RepV), heff_tag_n(TAG_RFixed, 2, (V[]){v_w_2421, v_n_2422})});
        }
        case TAG_RepFix: {
          return (g_heff_2ecompile_2erc_2eunboxOf(v_want_242, heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2421, v_n_2422})));
        }
        case TAG_RepF64: {
          return (g_heff_2ecompile_2erc_2eunboxOf(v_want_242, heff_tag_at_n(v_ru_24v_243_24SFixed, TAG_RFixed, 2, (V[]){v_w_2421, v_n_2422})));
        }
        default: return heff_nomatch(v_want_242);
        }
      }
    }
  }
  case TAG_SFloat32: {
    V v_x_2430 = heff_field(v_v_243, 0);
    V v_ru_24v_243_24SFloat32 = heff_take_reuse_n(v_v_243, 1ULL, 1);
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    switch (heff_tag_of(v_want_242)) {
    case TAG_RepV: {
      return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFloat32, TAG_RF32, 1, (V[]){v_x_2430})));
    }
    case TAG_RepFix: {
      V v_b1_2431 = heff_dup(heff_field(v_want_242, 0));
      V v_t_2432;
      switch (heff_tag_of(v_b1_2431)) {
      case TAG_I8: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str18);
        break;
      }
      case TAG_I16: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str19);
        break;
      }
      case TAG_I32: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str20);
        break;
      }
      case TAG_I64: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str21);
        break;
      }
      case TAG_U8: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str22);
        break;
      }
      case TAG_U16: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str23);
        break;
      }
      case TAG_U32: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str24);
        break;
      }
      case TAG_U64: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str25);
        break;
      }
      case TAG_F32: {
        v_t_2432 = ((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str26);
        break;
      }
      default: heff_nomatch(v_b1_2431);
      }
      if (heff_strEq_c(((V)&g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_str27), v_t_2432)) {
        heff_drop_tag(v_want_242, 1);
        return heff_tag_at_n(v_ru_24v_243_24SFloat32, TAG_RF32U, 1, (V[]){v_x_2430});
      } else {
        return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFloat32, TAG_RF32, 1, (V[]){v_x_2430})));
      }
    }
    case TAG_RepF64: {
      return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, heff_tag_at_n(v_ru_24v_243_24SFloat32, TAG_RF32, 1, (V[]){v_x_2430})));
    }
    default: return heff_nomatch(v_want_242);
    }
  }
  case TAG_SPrimFn: {
    V v_t_2435 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2436 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2435, v_want_242, v_t_2436));
  }
  case TAG_SLam: {
    V v_t_2439 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2440 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2439, v_want_242, v_t_2440));
  }
  case TAG_STag: {
    V v_t_2443 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2444 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2443, v_want_242, v_t_2444));
  }
  case TAG_SRec: {
    V v_t_2447 = (g_heff_2ecompile_2erc_2enaturalOf(heff_dup(v_ce_240), v_v_243));
    V v_t_2448 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(v_t_2447, v_want_242, v_t_2448));
  }
  case TAG_SProj: {
    V v_e_2449 = heff_field(v_v_243, 0);
    V v_l_2450 = heff_field(v_v_243, 1);
    V v_sh_2451 = heff_field(v_v_243, 2);
    V v_t_2452 = heff_field(v_v_243, 3);
    V v_ru_24v_243_24SProj = heff_take_reuse_n(v_v_243, 15ULL, 4);
    V v_t_2453 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_sh_2451));
    V v_t_2454 = (g_heff_2ecompile_2erc_2eindexIn(heff_dup(v_l_2450), MK_INT(0LL), v_sh_2451));
    V v_t_2455 = (g_heff_2ecompile_2erc_2eindexIn(heff_dup(v_l_2450), MK_INT(0LL), v_sh_2451));
    V v_t_2456 = (g_heff_2ecompile_2erepr_2ereadRepr(v_t_2455, heff_dup(v_t_2452)));
    return (g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130(v_ce_240, v_live_241, v_want_242, heff_tag_at_n(v_ru_24v_243_24SProj, TAG_SProj, 4, (V[]){heff_dup(v_e_2449), v_l_2450, v_sh_2451, v_t_2452}), v_e_2449, v_t_2453, v_t_2454, v_t_2456));
  }
  case TAG_SPrim: {
    V v_p_2457 = heff_field(v_v_243, 0);
    V v_as_2458 = heff_field(v_v_243, 1);
    V v_ru_24v_243_24SPrim = heff_take_reuse_n(v_v_243, 3ULL, 2);
    V v_x2_2459 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2457)));
    V v_x7_2462;
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_Nothing: {
      v_x7_2462 = (g_heff_2ecompile_2erepr_2efloatShape(heff_dup(v_p_2457)));
      break;
    }
    case TAG_Just: {
      V v_fp_2460 = heff_field(v_x2_2459, 0);
      V v_ru_24x2_2459_24Just = heff_take_reuse_n(v_x2_2459, 1ULL, 1);
      V v_t_2461 = heff_tag_at_n(v_ru_24x2_2459_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_2460, 0))});
      v_x7_2462 = ({ V a_0 = v_t_2461; V b_1 = heff_get_n(v_fp_2460, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2459);
    }
    switch (heff_tag_of(v_x7_2462)) {
    case TAG_Nothing: {
      V v_t_2463 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24v_243_24SPrim, TAG_SPrim, 2, (V[]){v_p_2457, v_as_2458})));
      return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2463));
    }
    case TAG_Just: {
      V v_sh_2464 = heff_field(v_x7_2462, 0);
      heff_take_n(v_x7_2462, 1ULL, 1);
      V v_t_2465 = (g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(v_ce_240, v_live_241, heff_take_field(v_sh_2464, 0), v_as_2458));
      return (g_heff_2ecompile_2erc_2ecoerce(heff_get_n(v_sh_2464, 1, 2), v_want_242, heff_tag_at_n(v_ru_24v_243_24SPrim, TAG_RPrimU, 2, (V[]){v_p_2457, v_t_2465})));
    }
    default: return heff_nomatch(v_x7_2462);
    }
  }
  default: return heff_nomatch(v_v_243);
  }
}
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_entry, 6, 0};

V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_t_2430;
    switch (heff_tag_of(v_e_244)) {
    case TAG_SVar: {
      V v_x_246 = heff_dup(heff_field(v_e_244, 0));
      V v_x3_247 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_246), heff_rfield(v_ce_240, 10)));
      switch (heff_tag_of(v_x3_247)) {
      case TAG_Nothing: {
        v_t_2430 = heff_tag_n(TAG_Just, 1, (V[]){v_x_246});
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_247, 0ULL, 1);
        heff_drop(v_x_246);
        v_t_2430 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x3_247);
      }
      break;
    }
    case TAG_SGlobal: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      v_t_2430 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_244);
    }
    HEFF_LAST return g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903(v_ce_240, v_live_241, v_bi_242, v_i_243, v_e_244, v_t_2430);
  }
  case TAG_Just: {
    V v_a_2431 = heff_field(v_x7_245, 0);
    V v_ru_24x7_245_24Just = heff_take_reuse_n(v_x7_245, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    heff_drop(v_e_244);
    return heff_tag_at_n(v_ru_24x7_245_24Just, TAG_Given, 1, (V[]){v_a_2431});
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_entry, 3, 0};

V g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_x4_242, 0);
    heff_take_n(v_x4_242, 1ULL, 1);
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_v_243));
  }
  case TAG_OCall: {
    V v_g_244 = heff_field(v_x4_242, 0);
    V v_as_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_244), heff_rfield(v_ce_240, 1)));
    V v_t_248;
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    V v_x3_249 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_ce_240, 11)));
    V v_t_2411;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_t_2411 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x3_249, 0);
      V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 1ULL, 1);
      v_t_2411 = heff_tag_at_n(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V v_x2_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_ce_240, 7)));
    V v_t_2414;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nothing: {
      v_t_2414 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      heff_take_n(v_x2_2412, 1ULL, 1);
      v_t_2414 = v_x_2413;
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_x2_2415 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_244), heff_rfield(v_ce_240, 11)));
    V v_t_2417;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nothing: {
      v_t_2417 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_as_245)));
      break;
    }
    case TAG_Just: {
      V v_s_2416 = heff_field(v_x2_2415, 0);
      heff_take_n(v_x2_2415, 1ULL, 1);
      v_t_2417 = heff_get_n(v_s_2416, 0, 2);
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2418 = ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_t_2414; V a_3 = MK_INT(0LL); V a_4 = v_t_2417; V a_5 = v_as_245; V r_ = (g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2414); r_; });
    return heff_tag_n(TAG_RCall, 4, (V[]){v_g_244, v_t_248, v_t_2411, v_t_2418});
  }
  case TAG_OApply: {
    V v_f_2419 = heff_field(v_x4_242, 0);
    V v_as_2420 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OApply = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2421 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(v_ce_240, v_live_241, heff_tag_at_n(v_ru_24x4_242_24OApply, TAG_Cons, 2, (V[]){v_f_2419, v_as_2420})));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nil: {
      return NTAG(TAG_RAbandon);
    }
    case TAG_Cons: {
      V v_fv_2422 = heff_field(v_t_2421, 0);
      V v_vs_2423 = heff_field(v_t_2421, 1);
      V v_ru_24t_2421_24Cons = heff_take_reuse_n(v_t_2421, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2421_24Cons, TAG_RApply, 2, (V[]){v_fv_2422, v_vs_2423});
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_OPrim: {
    V v_p_2424 = heff_field(v_x4_242, 0);
    V v_as_2425 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24OPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2426 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(v_ce_240, v_live_241, v_as_2425));
    return heff_tag_at_n(v_ru_24x4_242_24OPrim, TAG_RPrim, 2, (V[]){v_p_2424, v_t_2426});
  }
  case TAG_OAbandon: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return NTAG(TAG_RAbandon);
  }
  case TAG_OBool: {
    V v_c_2427 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24OBool = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_t_2428 = (g_heff_2ecompile_2erc_2elentTo(v_ce_240));
    V v_t_2429 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(v_t_2428, v_c_2427));
    return heff_tag_at_n(v_ru_24x4_242_24OBool, TAG_RBool, 1, (V[]){v_t_2429});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ecompV_24s792489109x351586786(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139_entry, 2, 0};

V g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(V v_ce_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_st_241)) {
  case TAG_SLet: {
    V v_ru_24st_241_24SLet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 13);
    return heff_tag_at_n(v_ru_24st_241_24SLet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SDecl: {
    heff_take_n(v_st_241, 0ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SSet: {
    V v_ru_24st_241_24SSet = heff_take_reuse_n(v_st_241, 0ULL, 2);
    heff_drop_rec(v_ce_240, 13);
    return heff_tag_at_n(v_ru_24st_241_24SSet, TAG_Cons, 2, (V[]){NTAG(TAG_CAbandon), NTAG(TAG_Nil)});
  }
  case TAG_SIf: {
    V v_st1_247 = heff_field(v_st_241, 0);
    V v_ts_248 = heff_field(v_st_241, 1);
    V v_fs_249 = heff_field(v_st_241, 2);
    heff_take_n(v_st_241, 7ULL, 3);
    switch (heff_tag_of(v_st1_247)) {
    case TAG_PTrue: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PFalse: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PRel: {
      V v_p_2410 = heff_field(v_st1_247, 0);
      V v_a_2411 = heff_field(v_st1_247, 1);
      V v_b_2412 = heff_field(v_st1_247, 2);
      heff_take_n(v_st1_247, 7ULL, 3);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2412), NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2412, NTAG(TAG_Nil)});
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2411), v_t_2414})));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = (g_heff_2ecompile_2erc_2efvSts(heff_dup(v_ts_248)));
      V v_t_2418 = (g_heff_2ecompile_2erc_2efvSts(heff_dup(v_fs_249)));
      V v_t_2419 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2417, v_t_2418));
      return ({ V a_0 = v_ce_240; V a_1 = v_p_2410; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, v_t_2413}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_4 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V a_5 = v_t_2416; V a_6 = v_t_2419; V r_ = (g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390(a_0, a_1, a_2, b_3, b_4, a_5, a_6)); heff_drop(b_3); heff_drop(b_4); r_; });
    }
    case TAG_PBool: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PNot: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PIf: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PLet: {
      return ({ V a_0 = v_ce_240; V a_1 = v_st1_247; V b_2 = heff_tag_n(TAG_ASts, 1, (V[]){v_ts_248}); V b_3 = heff_tag_n(TAG_ASts, 1, (V[]){v_fs_249}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_st1_247);
    }
  }
  case TAG_SCase: {
    V v_v_2428 = heff_field(v_st_241, 0);
    V v_arms_2429 = heff_field(v_st_241, 1);
    V v_ru_24st_241_24SCase = heff_take_reuse_n(v_st_241, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24s471405029x78128406(v_arms_2429));
    V v_t_2431 = (g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004(v_ce_240, NTAG(TAG_False), v_v_2428, v_t_2430));
    return heff_tag_at_n(v_ru_24st_241_24SCase, TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_st_241);
  }
}
V g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(a[0], a[1]);
}
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_entry, 3, 0};

V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(V v_ce_240, V v_x3_241, V v_after_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_after_242)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ce_240, 13);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_t_243 = heff_field(v_after_242, 0);
      heff_take_n(v_after_242, 1ULL, 1);
      return (g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(v_ce_240, v_t_243));
    }
    default: return heff_nomatch(v_after_242);
    }
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_rest_245 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_SLet: {
      V v_x_246 = heff_field(v_x31_244, 0);
      V v_o_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24SLet = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_fa_248 = (g_heff_2ecompile_2erc_2efvOp(heff_dup(v_o_247)));
      V v_known_249 = (g_heff_2ecompile_2erc_2ebuiltOf(heff_dup(v_o_247)));
      V v_after_2412;
      switch (heff_tag_of(v_after_242)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x31_244_24SLet, 2);
        v_after_2412 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_245)}), NTAG(TAG_Nil)});
        break;
      }
      case TAG_Just: {
        V v_t_2410 = heff_dup(heff_field(v_after_242, 0));
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2410}), NTAG(TAG_Nil)});
        v_after_2412 = heff_tag_at_n(v_ru_24x31_244_24SLet, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){heff_dup(v_rest_245)}), v_t_2411});
        break;
      }
      default: heff_nomatch(v_after_242);
      }
      V v_t_2413 = (g_heff_2ecompile_2erc_2eoperandsOf(heff_dup(v_o_247)));
      V v_takes_2414 = (g_heff_2ecompile_2erc_2etakesAt(heff_dup(v_ce_240), NTAG(TAG_Nil), v_after_2412, v_t_2413));
      V v_t_2415 = (g_heff_2ecompile_2erc_2efvRest(heff_dup(v_rest_245), heff_dup(v_after_242)));
      V v_t_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(heff_rfield(v_ce_240, 5))));
      return ({ V a_0 = heff_dup(v_ce_240); V a_1 = heff_dup(v_x_246); V a_2 = v_fa_248; V a_3 = heff_clo_n(g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_lam0, 1, 3, (V[]){v_x_246, v_ce_240, v_o_247}); V a_4 = v_known_249; V a_5 = v_takes_2414; V a_6 = v_rest_245; V a_7 = v_after_242; V a_8 = v_t_2416; V r_ = (g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_known_249); r_; });
    }
    case TAG_SDecl: {
      V v_x_2423 = heff_dup(heff_field(v_x31_244, 0));
      switch (heff_tag_of(v_rest_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_241_24Cons, 2);
        heff_drop(v_x_2423);
        V v_t_2424 = (g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(heff_dup(v_ce_240), v_x31_244));
        V v_t_2425 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_240, v_rest_245, v_after_242));
        return (g_prelude_2e_2b_2b(v_t_2424, v_t_2425));
      }
      case TAG_Cons: {
        V v_st_2426 = heff_field(v_rest_245, 0);
        V v_rest2_2427 = heff_field(v_rest_245, 1);
        heff_take_n(v_rest_245, 3ULL, 2);
        heff_drop_tag(v_x31_244, 1);
        V v_t_2428 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_st_2426), NTAG(TAG_Nil)});
        V v_fa_2429 = (g_heff_2ecompile_2erc_2efvSts(v_t_2428));
        V v_t_2430 = (g_heff_2ecompile_2erc_2efvRest(heff_dup(v_rest2_2427), heff_dup(v_after_242)));
        V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2430, heff_dup(heff_rfield(v_ce_240, 5))));
        return ({ V a_0 = v_ce_240; V a_1 = heff_dup(v_x_2423); V a_2 = v_fa_2429; V a_3 = heff_clo_n(g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_lam1, 1, 2, (V[]){v_st_2426, v_x_2423}); V b_4 = NTAG(TAG_Nothing); V a_5 = NTAG(TAG_Nil); V a_6 = v_rest2_2427; V a_7 = v_after_242; V a_8 = v_t_2431; V r_ = (g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272(a_0, a_1, a_2, a_3, b_4, a_5, a_6, a_7, a_8)); heff_drop(b_4); r_; });
      }
      default: return heff_nomatch(v_rest_245);
      }
    }
    case TAG_SSet: {
      V v_x_2434 = heff_field(v_x31_244, 0);
      V v_o_2435 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      V v_x2_2436 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2434), heff_rfield(v_ce_240, 10)));
      V v_want_2438;
      switch (heff_tag_of(v_x2_2436)) {
      case TAG_Nothing: {
        v_want_2438 = NTAG(TAG_RepV);
        break;
      }
      case TAG_Just: {
        V v_x_2437 = heff_field(v_x2_2436, 0);
        heff_take_n(v_x2_2436, 1ULL, 1);
        v_want_2438 = v_x_2437;
        break;
      }
      default: heff_nomatch(v_x2_2436);
      }
      V v_t_2439 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), heff_dup(heff_rfield(v_ce_240, 5)), v_want_2438, heff_dup(v_o_2435)));
      V v_t_2440 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_o_2435; V r_ = (g_heff_2ecompile_2erc_2eboolDone(a_0, a_1)); heff_drop(v_o_2435); r_; });
      V v_t_2441 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_240, v_rest_245, v_after_242));
      V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2440, v_t_2441));
      return heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CSet, 2, (V[]){v_x_2434, v_t_2439}), v_t_2442});
    }
    case TAG_SIf: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2446 = (g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(heff_dup(v_ce_240), v_x31_244));
      V v_t_2447 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_240, v_rest_245, v_after_242));
      return (g_prelude_2e_2b_2b(v_t_2446, v_t_2447));
    }
    case TAG_SCase: {
      heff_drop_cell(v_ru_24x3_241_24Cons, 2);
      V v_t_2450 = (g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(heff_dup(v_ce_240), v_x31_244));
      V v_t_2451 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_240, v_rest_245, v_after_242));
      return (g_prelude_2e_2b_2b(v_t_2450, v_t_2451));
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_lam0(V self, V *args) {
  V v_ce2_2417 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  V v_o_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2418 = ({ V a_0 = heff_dup(v_x_246); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_want_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    v_want_2420 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    heff_take_n(v_x2_2418, 1ULL, 1);
    v_want_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2421 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce2_2417), heff_dup(heff_rfield(v_ce2_2417, 5)), v_want_2420, heff_dup(v_o_247)));
  V v_t_2422 = ({ V a_0 = v_ce2_2417; V a_1 = v_o_247; V r_ = (g_heff_2ecompile_2erc_2eboolDone(a_0, a_1)); heff_drop(v_o_247); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_246, v_t_2421}), v_t_2422});
}
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_lam1(V self, V *args) {
  V v_ce2_2432 = args[0];
  V v_st_2426 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = (g_heff_2ecompile_2erc_2esetting_24s254772071x2107692139(v_ce2_2432, v_st_2426));
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDecl, 1, (V[]){v_x_2423}), v_t_2433});
}
Clo g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_entry, 7, 0};

V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244, V v_x7_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    heff_drop(v_x7_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_p_247 = heff_field(v_x6_244, 0);
    V v_ps_248 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x7_245)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      heff_drop(v_i_243);
      heff_drop(v_p_247);
      heff_drop(v_ps_248);
      heff_drop_cell(v_ru_24x6_244_24Cons, 2);
      return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x7_245, 0);
      V v_es_2410 = heff_field(v_x7_245, 1);
      heff_take_n(v_x7_245, 3ULL, 2);
      V v_x3_2411 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_p_247), heff_rfield(v_ce_240, 10)));
      V v_t_2413;
      switch (heff_tag_of(v_x3_2411)) {
      case TAG_Nothing: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2411, 0ULL, 1);
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x3_2411);
      }
      V v_t_2426;
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2410)));
        V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2414); r_; });
        V v_live_2416 = (g_prelude_2e_2b_2b(v_t_2415, heff_dup(v_live_241)));
        V v_x2_2417 = (g_map_2elookup_24s1546226666x2146984184(v_p_247, heff_rfield(v_ce_240, 10)));
        V v_want_2419;
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_Nothing: {
          v_want_2419 = NTAG(TAG_RepV);
          break;
        }
        case TAG_Just: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          heff_take_n(v_x2_2417, 1ULL, 1);
          v_want_2419 = v_x_2418;
          break;
        }
        default: heff_nomatch(v_x2_2417);
        }
        V v_t_2420 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(heff_dup(v_ce_240), v_live_2416, v_want_2419, v_e_249));
        v_t_2426 = heff_tag_n(TAG_Given, 1, (V[]){v_t_2420});
      } else {
        heff_drop(v_p_247);
        heff_drop(v_t_2413);
        V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2410)));
        V v_t_2422 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2421); r_; });
        V v_live_2423 = (g_prelude_2e_2b_2b(v_t_2422, heff_dup(v_live_241)));
        V v_t_2424 = (g_heff_2ecompile_2erc_2eelemI(heff_dup(v_i_243), v_bi_242));
        V v_t_2425;
        if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
          heff_drop(v_t_2424);
          v_t_2425 = (g_heff_2ecompile_2erc_2elentField(heff_dup(v_ce_240), v_live_241, v_e_249));
        } else {
          heff_drop(v_t_2424);
          v_t_2425 = NTAG(TAG_Nothing);
        }
        v_t_2426 = (g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(heff_dup(v_ce_240), v_live_2423, v_bi_242, heff_dup(v_i_243), v_e_249, v_t_2425));
      }
      V v_cell_2427 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2426, heff_hole()});
      V v_u_2428 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2427));
      heff_drop(v_u_2428);
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_bi_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_ps_248;
      V t_5 = v_es_2410;
      V t_6 = v_cell_2427;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_bi_242 = t_2;
      v_i_243 = t_3;
      v_x6_244 = t_4;
      v_x7_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    default: return heff_nomatch(v_x7_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2eloopOperands_24s1313556591x1813837499_24dps(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_entry, 2, 0};

V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(V v_ce_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_TSeq: {
    V v_ss_242 = heff_field(v_x3_241, 0);
    V v_t_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    return (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_240, v_ss_242, heff_tag_n(TAG_Just, 1, (V[]){v_t_243})));
  }
  case TAG_TReturn: {
    V v_x31_244 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24TReturn = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_OSimple: {
      V v_t_246 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 12, 13), v_x31_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_246}), NTAG(TAG_Nil)});
    }
    case TAG_OCall: {
      V v_g_247 = heff_field(v_x31_244, 0);
      V v_as_248 = heff_field(v_x31_244, 1);
      heff_take_n(v_x31_244, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_241_24TReturn, 1);
      return (g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305(v_ce_240, v_g_247, v_as_248));
    }
    case TAG_OApply: {
      V v_f_249 = heff_field(v_x31_244, 0);
      V v_as_2410 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24OApply = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_2411 = heff_dup(heff_rfield(v_ce_240, 12));
      V v_t_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_RepV: {
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        heff_take_n(v_t_2411, 0ULL, 1);
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x3_241_24TReturn, 1);
        heff_drop(v_t_2413);
        V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2410));
        V v_t_2415 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x31_244_24OApply, TAG_Cons, 2, (V[]){v_f_249, v_as_2410})));
        return (g_heff_2ecompile_2erc_2eapplyLast(v_ce_240, v_t_2414, v_t_2415));
      } else {
        heff_drop(v_t_2413);
        V v_t_2416 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 12, 13), heff_tag_at_n(v_ru_24x31_244_24OApply, TAG_OApply, 2, (V[]){v_f_249, v_as_2410})));
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_2416}), NTAG(TAG_Nil)});
      }
    }
    case TAG_OPrim: {
      V v_t_2419 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 12, 13), v_x31_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_2419}), NTAG(TAG_Nil)});
    }
    case TAG_OAbandon: {
      V v_t_2420 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), heff_get_n(v_ce_240, 12, 13), v_x31_244));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_CReturn, 1, (V[]){v_t_2420}), NTAG(TAG_Nil)});
    }
    case TAG_OBool: {
      V v_c_2421 = heff_field(v_x31_244, 0);
      V v_ru_24x31_244_24OBool = heff_take_reuse_n(v_x31_244, 1ULL, 1);
      V v_t_2422 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), NTAG(TAG_RepV), heff_tag_at_n(v_ru_24x3_241_24TReturn, TAG_OBool, 1, (V[]){v_c_2421})));
      V v_t_2423 = (g_heff_2ecompile_2erc_2edropsOf(heff_dup(v_ce_240), heff_dup(heff_rfield(v_ce_240, 4))));
      V v_t_2424 = (g_list_2emap_24s1796125103x644876049(v_t_2423));
      V v_t_2425 = (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), heff_get_n(v_ce_240, 12, 13), heff_tag_at_n(v_ru_24x31_244_24OBool, TAG_RLocal, 1, (V[]){heff_dup(g_heff_2ecompile_2erc_2eboolName_get())})));
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CReturn, 1, (V[]){v_t_2425}), NTAG(TAG_Nil)});
      V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2426));
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){heff_dup(g_heff_2ecompile_2erc_2eboolName_get()), v_t_2422}), v_t_2427});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  case TAG_TLoop: {
    V v_as_2428 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24TLoop = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_2429 = heff_dup(heff_rfield(v_ce_240, 2));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_as_2428);
      V v_t_2430 = heff_tag_at_n(v_ru_24x3_241_24TLoop, TAG_CReturn, 1, (V[]){NTAG(TAG_RAbandon)});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    }
    case TAG_Just: {
      V v_s_2431 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24TLoop, 1);
      return (g_heff_2ecompile_2erc_2ecallLast_24s1815774051x1886726305(v_ce_240, heff_get_n(v_s_2431, 0, 2), v_as_2428));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_TIf: {
    V v_x31_2432 = heff_field(v_x3_241, 0);
    V v_t_2433 = heff_field(v_x3_241, 1);
    V v_e_2434 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    switch (heff_tag_of(v_x31_2432)) {
    case TAG_PTrue: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2432; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PFalse: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2432; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PRel: {
      V v_p_2435 = heff_field(v_x31_2432, 0);
      V v_a_2436 = heff_field(v_x31_2432, 1);
      V v_b_2437 = heff_field(v_x31_2432, 2);
      heff_take_n(v_x31_2432, 7ULL, 3);
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2437), NTAG(TAG_Nil)});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2437, NTAG(TAG_Nil)});
      V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_2436), v_t_2439})));
      V v_t_2441 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2440; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2440); r_; });
      V v_t_2442 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_2433)));
      V v_t_2443 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_e_2434)));
      V v_t_2444 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2442, v_t_2443));
      return ({ V a_0 = v_ce_240; V a_1 = v_p_2435; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2436, v_t_2438}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_4 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V a_5 = v_t_2441; V a_6 = v_t_2444; V r_ = (g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390(a_0, a_1, a_2, b_3, b_4, a_5, a_6)); heff_drop(b_3); heff_drop(b_4); r_; });
    }
    case TAG_PBool: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2432; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PNot: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2432; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PIf: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2432; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    case TAG_PLet: {
      return ({ V a_0 = v_ce_240; V a_1 = v_x31_2432; V b_2 = heff_tag_n(TAG_ATail, 1, (V[]){v_t_2433}); V b_3 = heff_tag_n(TAG_ATail, 1, (V[]){v_e_2434}); V r_ = (g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a_0, a_1, b_2, b_3)); heff_drop(b_2); heff_drop(b_3); r_; });
    }
    default: return heff_nomatch(v_x31_2432);
    }
  }
  case TAG_TCase: {
    V v_v_2453 = heff_field(v_x3_241, 0);
    V v_arms_2454 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24TCase = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2455 = (g_list_2emap_24s1341404685x1564972929(v_arms_2454));
    V v_t_2456 = (g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004(v_ce_240, NTAG(TAG_True), v_v_2453, v_t_2455));
    return heff_tag_at_n(v_ru_24x3_241_24TCase, TAG_Cons, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2efunRc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efunRc_entry, 4, 0};

V g_heff_2ecompile_2erc_2efunRc(V v_ce_240, V v_key_241, V v_xs_242, V v_b_243) {
top: ;
  V v_x2_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_241), heff_rfield(v_ce_240, 7)));
  V v_t_246;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x2_244, 0);
    heff_take_n(v_x2_244, 1ULL, 1);
    v_t_246 = v_x_245;
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_x2_247 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_241), heff_rfield(v_ce_240, 11)));
  V v_t_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_t_249 = (g_list_2emap_24s1598879313x231311047(heff_dup(v_xs_242)));
    break;
  }
  case TAG_Just: {
    V v_s_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_t_249 = heff_get_n(v_s_248, 0, 2);
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2410 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_241), heff_rfield(v_ce_240, 11)));
  return (g_heff_2ecompile_2erc_2efunWith(v_ce_240, v_key_241, v_xs_242, v_b_243, v_t_246, v_t_249, v_t_2410));
}
V g_heff_2ecompile_2erc_2efunRc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efunRc(a[0], a[1], a[2], a[3]);
}