// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_IsTerminal 53507
#define TAG_MkKid 64674
#define TAG_MkTask 37714
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define LBL_bind 9519364
#define LBL_done 9584713
#define LBL_going 299892244
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_parent 951717845
#define LBL_ret 322331
#define LBL_task 10048076
#define LBL_total 311908190
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_next__going[] = {LBL_next, LBL_going};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369(V);
V g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s1364294205x625005369_clo;
V g_app_2eheff_2emain_2eprogram_24s1917382536x791486084(V);
V g_app_2eheff_2emain_2eprogram_24s1917382536x791486084_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s1917382536x791486084_clo;
V g_co_2eplus_24s1499074119x1407181331_get(void);
V g_co_2ethrough_24s1918455300x553827868_get(void);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s352363709x250826586(V, V);
V g_list_2efilter_24s352363709x250826586_entry(V self, V *a);
extern Clo g_list_2efilter_24s352363709x250826586_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2eprogress_2ecountOf(V, V);
V g_std_2eprogress_2ecountOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2ecountOf_clo;
V g_std_2eprogress_2edrawTop(V, V);
V g_std_2eprogress_2edrawTop_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawTop_clo;
V g_std_2eprogress_2edrawUnder(V, V, V);
V g_std_2eprogress_2edrawUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawUnder_clo;
V g_std_2eprogress_2edrawing_24s1430340132x541078361_get(void);
V g_std_2eprogress_2edrawn_24s1137940462x35880749_get(void);
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582(V, V);
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_clo;
V g_std_2eprogress_2eended(V, V);
V g_std_2eprogress_2eended_entry(V self, V *a);
extern Clo g_std_2eprogress_2eended_clo;
V g_std_2eprogress_2ekidsUnder(V, V, V);
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_clo;
V g_std_2eprogress_2eparentOf(V, V);
V g_std_2eprogress_2eparentOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2eparentOf_clo;
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2equietly_24s755065368x1740453353(V);
V g_std_2eprogress_2equietly_24s755065368x1740453353_entry(V self, V *a);
extern Clo g_std_2eprogress_2equietly_24s755065368x1740453353_clo;
V g_std_2eprogress_2eredrawn_24s742480751x1815451405(V, V);
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_entry(V self, V *a);
extern Clo g_std_2eprogress_2eredrawn_24s742480751x1815451405_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2erooted(V, V, V);
V g_std_2eprogress_2erooted_entry(V self, V *a);
extern Clo g_std_2eprogress_2erooted_clo;
V g_std_2eprogress_2eshown_24s1055853045x1560533240_get(void);

static V g_std_2eprogress_2eroot_val;
static int g_std_2eprogress_2eroot_st;
static V g_std_2eprogress_2eroot_init(void) {
  return heff_tag(TAG_MkTask, 1, (V[]){MK_INT(0LL)});
}
V g_std_2eprogress_2eroot_get(void) {
  if (g_std_2eprogress_2eroot_st == 2) return g_std_2eprogress_2eroot_val;
  if (g_std_2eprogress_2eroot_st == 1) heff_fail("defined by itself");
  g_std_2eprogress_2eroot_st = 1;
  g_std_2eprogress_2eroot_val = heff_tr(g_std_2eprogress_2eroot_init());
  g_std_2eprogress_2eroot_st = 2;
  return g_std_2eprogress_2eroot_val;
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args);
V g_std_2eprogress_2eprogress_lam2(V self, V *args);
V g_std_2eprogress_2eprogress_lam0(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam0, 3, 0};
V g_std_2eprogress_2eprogress_lam3(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam3, 2, 0};

static V g_std_2eprogress_2eprogress_val;
static int g_std_2eprogress_2eprogress_st;
static V g_std_2eprogress_2eprogress_init(void) {
  return heff_rec(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprogress_2eprogress_lam0_clo), ((V)&g_std_2eprogress_2eprogress_lam3_clo)});
}
V g_std_2eprogress_2eprogress_get(void) {
  if (g_std_2eprogress_2eprogress_st == 2) return g_std_2eprogress_2eprogress_val;
  if (g_std_2eprogress_2eprogress_st == 1) heff_fail("defined by itself");
  g_std_2eprogress_2eprogress_st = 1;
  g_std_2eprogress_2eprogress_val = heff_tr(g_std_2eprogress_2eprogress_init());
  g_std_2eprogress_2eprogress_st = 2;
  return g_std_2eprogress_2eprogress_val;
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args) {
  V v_t_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_apply(v_k_246, 1, (V[]){v_t_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_apply(v_k_2418, 1, (V[]){v_r_2419}));
  V f_ = v_g_241;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam0(V self, V *args) {
  V v_fm_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_fm_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Start: {
    V v_parent_243 = heff_field(v_p_242, 0);
    V v_name_244 = heff_field(v_p_242, 1);
    V v_total_245 = heff_field(v_p_242, 2);
    V v_k_246 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at(v_ru_24p_242_24Start, TAG_Start, 4, (V[]){v_parent_243, v_name_244, v_total_245, heff_clo(g_std_2eprogress_2eprogress_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Complete: {
    V v_t_249 = heff_field(v_p_242, 0);
    V v_x_2410 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Complete = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_2410}));
    return heff_tag_at(v_ru_24p_242_24Complete, TAG_Complete, 2, (V[]){v_t_249, v_t_2411});
  }
  case TAG_End: {
    V v_t_2412 = heff_field(v_p_242, 0);
    V v_x_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2414 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_at(v_ru_24p_242_24End, TAG_End, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_RunUnder: {
    V v_t_2415 = heff_field(v_p_242, 0);
    V v_cmd_2416 = heff_field(v_p_242, 1);
    V v_as_2417 = heff_field(v_p_242, 2);
    V v_k_2418 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24RunUnder = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at(v_ru_24p_242_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2415, v_cmd_2416, v_as_2417, heff_clo(g_std_2eprogress_2eprogress_lam2, 1, 2, (V[]){v_k_2418, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprogress_2eprogress_lam3(V self, V *args) {
  V v_nt_2421 = args[0];
  V v_p_2422 = args[1];
  heff_drop(v_nt_2421);
  switch (heff_tag_of(v_p_2422)) {
  case TAG_Start: {
    V v_parent_2423 = heff_field(v_p_2422, 0);
    V v_name_2424 = heff_field(v_p_2422, 1);
    V v_total_2425 = heff_field(v_p_2422, 2);
    V v_k_2426 = heff_field(v_p_2422, 3);
    V v_ru_24p_2422_24Start = heff_take_reuse_n(v_p_2422, 15ULL, 4);
    return heff_tag_at(v_ru_24p_2422_24Start, TAG_Start, 4, (V[]){v_parent_2423, v_name_2424, v_total_2425, v_k_2426});
  }
  case TAG_Complete: {
    V v_t_2427 = heff_field(v_p_2422, 0);
    V v_x_2428 = heff_field(v_p_2422, 1);
    V v_ru_24p_2422_24Complete = heff_take_reuse_n(v_p_2422, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2422_24Complete, TAG_Complete, 2, (V[]){v_t_2427, v_x_2428});
  }
  case TAG_End: {
    V v_t_2429 = heff_field(v_p_2422, 0);
    V v_x_2430 = heff_field(v_p_2422, 1);
    V v_ru_24p_2422_24End = heff_take_reuse_n(v_p_2422, 3ULL, 2);
    return heff_tag_at(v_ru_24p_2422_24End, TAG_End, 2, (V[]){v_t_2429, v_x_2430});
  }
  case TAG_RunUnder: {
    V v_t_2431 = heff_field(v_p_2422, 0);
    V v_cmd_2432 = heff_field(v_p_2422, 1);
    V v_as_2433 = heff_field(v_p_2422, 2);
    V v_k_2434 = heff_field(v_p_2422, 3);
    V v_ru_24p_2422_24RunUnder = heff_take_reuse_n(v_p_2422, 15ULL, 4);
    return heff_tag_at(v_ru_24p_2422_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2431, v_cmd_2432, v_as_2433, v_k_2434});
  }
  default: return heff_nomatch(v_p_2422);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2ecountOf_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2ecountOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2ecountOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2eprogress_2ecountOf_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2ecountOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2eprogress_2ecountOf_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2ecountOf_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2ecountOf_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_std_2eprogress_2ecountOf_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 32}};
Clo g_std_2eprogress_2ecountOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ecountOf_entry, 2, 0};

V g_std_2eprogress_2ecountOf(V v_done_240, V v_total_241) {
top: ;
  if (heff_intEq_c(heff_dup(v_done_240), MK_INT(0LL))) {
    if (heff_intEq_c(heff_dup(v_total_241), MK_INT(0LL))) {
      heff_drop(v_done_240);
      heff_drop(v_total_241);
      return ((V)&g_std_2eprogress_2ecountOf_str0);
    } else {
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str1), heff_strAppend(heff_intShow(v_done_240), heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str2), heff_strAppend(heff_intShow(v_total_241), ((V)&g_std_2eprogress_2ecountOf_str3)))));
    }
  } else {
    if (heff_intEq_c(heff_dup(v_total_241), MK_INT(0LL))) {
      heff_drop(v_total_241);
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str4), heff_strAppend(heff_intShow(v_done_240), ((V)&g_std_2eprogress_2ecountOf_str5)));
    } else {
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str6), heff_strAppend(heff_intShow(v_done_240), heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str7), heff_strAppend(heff_intShow(v_total_241), ((V)&g_std_2eprogress_2ecountOf_str8)))));
    }
  }
}
V g_std_2eprogress_2ecountOf_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ecountOf(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2eprogress_2edrawUnder_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {9492, 9472, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2eprogress_2edrawUnder_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {9500, 9472, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2eprogress_2edrawUnder_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_std_2eprogress_2edrawUnder_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {9474, 32, 32}};
V g_std_2eprogress_2edrawUnder_lam0(V self, V *args);
Clo g_std_2eprogress_2edrawUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawUnder_entry, 3, 0};

V g_std_2eprogress_2edrawUnder(V v_every_240, V v_prefix_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    heff_drop(v_prefix_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x1_247;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_x1_247 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_248;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = ((V)&g_std_2eprogress_2edrawUnder_str0);
      break;
    }
    case TAG_False: {
      v_t_248 = ((V)&g_std_2eprogress_2edrawUnder_str1);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    V v_t_249 = (g_std_2eprogress_2ecountOf(heff_get(heff_dup(v_t_243), LBL_done), heff_get(heff_dup(v_t_243), LBL_total)));
    V v_t_2410 = heff_strAppend(heff_dup(v_prefix_241), heff_strAppend(v_t_248, heff_strAppend(v_t_249, heff_get(heff_dup(v_t_243), LBL_name))));
    V v_x1_2413;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_x1_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2414;
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_True: {
      v_t_2414 = ((V)&g_std_2eprogress_2edrawUnder_str2);
      break;
    }
    case TAG_False: {
      v_t_2414 = ((V)&g_std_2eprogress_2edrawUnder_str3);
      break;
    }
    default: heff_nomatch(v_x1_2413);
    }
    V v_t_2416 = (g_list_2efilter(heff_clo(g_std_2eprogress_2edrawUnder_lam0, 1, 1, (V[]){v_t_243}), heff_dup(v_every_240)));
    V v_t_2417 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), heff_strAppend(heff_dup(v_prefix_241), v_t_2414), v_t_2416));
    V v_t_2418 = (g_std_2eprogress_2edrawUnder(v_every_240, v_prefix_241, v_rest_244));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_prelude_2e_2b_2b(v_t_2417, v_t_2418))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2edrawUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawUnder(a[0], a[1], a[2]);
}
V g_std_2eprogress_2edrawUnder_lam0(V self, V *args) {
  V v_t_2415 = args[0];
  V v_t_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(heff_get(v_t_2415, LBL_parent), heff_get(v_t_243, LBL_task));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2edrawTop_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_std_2eprogress_2edrawTop_lam0(V self, V *args);
Clo g_std_2eprogress_2edrawTop_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawTop_entry, 2, 0};

V g_std_2eprogress_2edrawTop(V v_every_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_std_2eprogress_2ecountOf(heff_get(heff_dup(v_t_242), LBL_done), heff_get(heff_dup(v_t_242), LBL_total)));
    V v_t_245 = heff_strAppend(v_t_244, heff_get(heff_dup(v_t_242), LBL_name));
    V v_t_247 = (g_list_2efilter(heff_clo(g_std_2eprogress_2edrawTop_lam0, 1, 1, (V[]){v_t_242}), heff_dup(v_every_240)));
    V v_t_248 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), ((V)&g_std_2eprogress_2edrawTop_str0), v_t_247));
    V v_t_249 = (g_std_2eprogress_2edrawTop(v_every_240, v_rest_243));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, (g_prelude_2e_2b_2b(v_t_248, v_t_249))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawTop_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawTop(a[0], a[1]);
}
V g_std_2eprogress_2edrawTop_lam0(V self, V *args) {
  V v_t_246 = args[0];
  V v_t_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_intEq(heff_get(v_t_246, LBL_parent), heff_get(v_t_242, LBL_task));
}
Clo g_std_2eprogress_2ekidsUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_entry, 3, 0};

V g_std_2eprogress_2ekidsUnder(V v_t_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkKid: {
      V v_name_245 = heff_field(v_x31_243, 0);
      V v_done_246 = heff_field(v_x31_243, 1);
      V v_total_247 = heff_field(v_x31_243, 2);
      V v_parent_248 = heff_field(v_x31_243, 3);
      heff_take_n(v_x31_243, 15ULL, 4);
      V v_t_2411;
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        v_t_2411 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c(heff_dup(v_i_241), MK_INT(255LL))) {
          v_t_2411 = heff_dup(v_t_240);
        } else {
          v_t_2411 = heff_intSub(MK_INT(-1LL), heff_dup(v_i_241));
        }
      }
      V v_t_2414;
      if (heff_intEq_c(heff_dup(v_parent_248), MK_INT(0LL))) {
        heff_drop(v_parent_248);
        v_t_2414 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c(heff_dup(v_parent_248), MK_INT(255LL))) {
          heff_drop(v_parent_248);
          v_t_2414 = heff_dup(v_t_240);
        } else {
          v_t_2414 = heff_intSub(MK_INT(-1LL), v_parent_248);
        }
      }
      return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec(5, shape_task__parent__name__done__total, (V[]){v_t_2411, v_t_2414, v_name_245, v_done_246, v_total_247}), (g_std_2eprogress_2ekidsUnder(v_t_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244))});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2eprogress_2erooted_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2eprogress_2erooted_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2erooted_entry, 3, 0};

V g_std_2eprogress_2erooted(V v_t_240, V v_x2_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkKid: {
    V v_name_243 = heff_field(v_x2_241, 0);
    V v_done_244 = heff_field(v_x2_241, 1);
    V v_total_245 = heff_field(v_x2_241, 2);
    if (heff_intEq_c(heff_get(heff_dup(v_s_242), LBL_task), v_t_240)) {
      V v_t_249;
      if (heff_strEq_c(heff_dup(v_name_243), ((V)&g_std_2eprogress_2erooted_str0))) {
        v_t_249 = heff_get(heff_dup(v_s_242), LBL_name);
      } else {
        v_t_249 = heff_dup(v_name_243);
      }
      V v_t_2414;
      if (heff_intEq_c(heff_dup(v_total_245), MK_INT(0LL))) {
        if (heff_intLt_c(MK_INT(0LL), heff_get(heff_dup(v_s_242), LBL_total))) {
          V v_b_2412 = heff_get(heff_dup(v_s_242), LBL_total);
          if (heff_intLe_c(heff_dup(v_done_244), heff_dup(v_b_2412))) {
            heff_drop(v_b_2412);
            v_t_2414 = heff_dup(v_done_244);
          } else {
            v_t_2414 = v_b_2412;
          }
        } else {
          v_t_2414 = heff_dup(v_done_244);
        }
      } else {
        v_t_2414 = heff_dup(v_done_244);
      }
      V v_t_2416;
      if (heff_intEq_c(heff_dup(v_total_245), MK_INT(0LL))) {
        v_t_2416 = heff_get(heff_dup(v_s_242), LBL_total);
      } else {
        v_t_2416 = heff_dup(v_total_245);
      }
      return heff_rec(5, shape_task__parent__name__done__total, (V[]){heff_get(heff_dup(v_s_242), LBL_task), heff_get(v_s_242, LBL_parent), v_t_249, v_t_2414, v_t_2416});
    } else {
      return v_s_242;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2erooted_entry(V self, V *a) {
  (void)self;
  V r = g_std_2eprogress_2erooted(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
Clo g_std_2eprogress_2eparentOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eparentOf_entry, 2, 0};

V g_std_2eprogress_2eparentOf(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_get(heff_dup(v_t_242), LBL_task), heff_dup(v_i_240))) {
      heff_drop(v_i_240);
      return heff_get(heff_dup(v_t_242), LBL_parent);
    } else {
      V t_0 = v_i_240;
      V t_1 = v_rest_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2eparentOf_entry(V self, V *a) {
  (void)self;
  V r = g_std_2eprogress_2eparentOf(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_std_2eprogress_2eended_lam0(V self, V *args);
V g_std_2eprogress_2eended_lam1(V self, V *args);
Clo g_std_2eprogress_2eended_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eended_entry, 2, 0};

V g_std_2eprogress_2eended(V v_i_240, V v_ts_241) {
top: ;
  V v_i_242 = ({ V a_0 = heff_dup(v_i_240); V b_1 = heff_get(heff_dup(v_ts_241), LBL_going); V r_ = (g_std_2eprogress_2eparentOf(a_0, b_1)); heff_drop(b_1); r_; });
  V v_ts_245 = (g_list_2efilter(heff_clo(g_std_2eprogress_2eended_lam0, 1, 1, (V[]){v_i_240}), heff_get(heff_dup(v_ts_241), LBL_going)));
  V v_t_249 = (g_list_2emap(heff_clo(g_std_2eprogress_2eended_lam1, 1, 1, (V[]){v_i_242}), v_ts_245));
  return heff_rec(2, shape_next__going, (V[]){heff_get(v_ts_241, LBL_next), v_t_249});
}
V g_std_2eprogress_2eended_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2eended(a[0], a[1]);
}
V g_std_2eprogress_2eended_lam0(V self, V *args) {
  V v_t_243 = args[0];
  V v_i_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_intEq_c(heff_get(v_t_243, LBL_task), v_i_240)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
V g_std_2eprogress_2eended_lam1(V self, V *args) {
  V v_t_246 = args[0];
  V v_i_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_intEq_c(heff_get(heff_dup(v_t_246), LBL_task), v_i_242)) {
    V v_t_248 = heff_intAdd(heff_get(heff_dup(v_t_246), LBL_done), MK_INT(1LL));
    return heff_rec(5, shape_task__parent__name__done__total, (V[]){heff_get(heff_dup(v_t_246), LBL_task), heff_get(heff_dup(v_t_246), LBL_parent), heff_get(heff_dup(v_t_246), LBL_name), v_t_248, heff_get(v_t_246, LBL_total)});
  } else {
    return v_t_246;
  }
}
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam0(V self, V *args);
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam2(V self, V *args);
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam1(V self, V *args);
Clo g_std_2eprogress_2eredrawn_24s742480751x1815451405_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eredrawn_24s742480751x1815451405_entry, 2, 0};

V g_std_2eprogress_2eredrawn_24s742480751x1815451405(V v_ts_240, V v_x_241) {
top: ;
  V v_ts_242 = heff_get(heff_dup(v_ts_240), LBL_going);
  V v_t_243 = (g_list_2efilter_24s352363709x250826586(MK_INT(0LL), heff_dup(v_ts_242)));
  V v_ls_244 = (g_std_2eprogress_2edrawTop(v_ts_242, v_t_243));
  V v_c_249 = heff_clo(g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam0, 2, 1, (V[]){v_ls_244});
  return heff_clo(g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam1, 2, 3, (V[]){v_c_249, v_ts_240, v_x_241});
}
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2eredrawn_24s742480751x1815451405(a[0], a[1]);
}
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k2_246 = args[1];
  V v_ls_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_ShowLines, 2, (V[]){v_ls_244, NTAG(TAG_MkUnit)});
  V v_t_248 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_245), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_247})}));
  V f_ = heff_get(v_hd_245, LBL_bind);
  args[0] = v_t_248;
  args[1] = v_k2_246;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2412);
  V f_ = v_k_2411;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_ts_240, v_x_241});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo(g_std_2eprogress_2eredrawn_24s742480751x1815451405_lam2, 1, 3, (V[]){v_k_2411, v_ts_240, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam0(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam3(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam2(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam4(V self, V *args); static Clo g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam4, 1, 0};
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam5(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam1(V self, V *args);
Clo g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_entry, 2, 0};

V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582(V v_ts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Start: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_name_243 = heff_field(v_x2_241, 1);
    V v_total_244 = heff_field(v_x2_241, 2);
    V v_k_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkTask: {
      V v_p_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24MkTask = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intAdd(heff_get(heff_dup(v_ts_240), LBL_next), MK_INT(1LL));
      V v_t_248 = heff_rec(5, shape_task__parent__name__done__total, (V[]){heff_get(heff_dup(v_ts_240), LBL_next), v_p_246, v_name_243, MK_INT(0LL), v_total_244});
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_t_2410 = (g_prelude_2e_2b_2b(heff_get(heff_dup(v_ts_240), LBL_going), v_t_249));
      V v_t_2411 = heff_tag_at(v_ru_24x21_242_24MkTask, TAG_MkTask, 1, (V[]){heff_get(v_ts_240, LBL_next)});
      V v_t_2412 = heff_tr(heff_apply(v_k_245, 1, (V[]){v_t_2411}));
      HEFF_LAST return g_std_2eprogress_2eredrawn_24s742480751x1815451405(heff_rec(2, shape_next__going, (V[]){v_t_247, v_t_2410}), v_t_2412);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_Complete: {
    V v_x21_2413 = heff_field(v_x2_241, 0);
    V v_x_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2413)) {
    case TAG_MkTask: {
      V v_i_2415 = heff_field(v_x21_2413, 0);
      heff_take_n(v_x21_2413, 1ULL, 1);
      V v_t_2419 = (g_list_2emap(heff_clo(g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam0, 1, 1, (V[]){v_i_2415}), heff_get(heff_dup(v_ts_240), LBL_going)));
      V v_t_2420 = heff_rec(2, shape_next__going, (V[]){heff_get(v_ts_240, LBL_next), v_t_2419});
      HEFF_LAST return g_std_2eprogress_2eredrawn_24s742480751x1815451405(v_t_2420, v_x_2414);
    }
    default: return heff_nomatch(v_x21_2413);
    }
  }
  case TAG_End: {
    V v_x21_2421 = heff_field(v_x2_241, 0);
    V v_x_2422 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkTask: {
      V v_i_2423 = heff_field(v_x21_2421, 0);
      heff_take_n(v_x21_2421, 1ULL, 1);
      V v_t_2424 = (g_std_2eprogress_2eended(v_i_2423, v_ts_240));
      HEFF_LAST return g_std_2eprogress_2eredrawn_24s742480751x1815451405(v_t_2424, v_x_2422);
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  case TAG_RunUnder: {
    V v_x21_2425 = heff_field(v_x2_241, 0);
    V v_cmd_2426 = heff_field(v_x2_241, 1);
    V v_as_2427 = heff_field(v_x2_241, 2);
    V v_k_2428 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_2425)) {
    case TAG_MkTask: {
      V v_i_2429 = heff_field(v_x21_2425, 0);
      heff_take_n(v_x21_2425, 1ULL, 1);
      return heff_clo(g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam1, 2, 5, (V[]){v_cmd_2426, v_as_2427, v_ts_240, v_i_2429, v_k_2428});
    }
    default: return heff_nomatch(v_x21_2425);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawnOp_24s1579838052x1689901582(a[0], a[1]);
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam0(V self, V *args) {
  V v_t_2416 = args[0];
  V v_i_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_intEq_c(heff_get(heff_dup(v_t_2416), LBL_task), v_i_2415)) {
    V v_t_2418 = heff_intAdd(heff_get(heff_dup(v_t_2416), LBL_done), MK_INT(1LL));
    return heff_rec(5, shape_task__parent__name__done__total, (V[]){heff_get(heff_dup(v_t_2416), LBL_task), heff_get(heff_dup(v_t_2416), LBL_parent), heff_get(heff_dup(v_t_2416), LBL_name), v_t_2418, heff_get(v_t_2416, LBL_total)});
  } else {
    return v_t_2416;
  }
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam3(V self, V *args) {
  V v_s_2436 = args[0];
  V v_i_2429 = heff_env(self)[0];
  V v_r_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_i_2429; V a_1 = v_r_2434; V a_2 = v_s_2436; V r_ = (g_std_2eprogress_2erooted(a_0, a_1, a_2)); heff_drop(v_r_2434); r_; });
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam2(V self, V *args) {
  V v_kids_2432 = args[0];
  V v_ts_240 = heff_env(self)[0];
  V v_i_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ts_2433 = heff_get(v_ts_240, LBL_going);
  V v_ts_2439;
  switch (heff_tag_of(v_kids_2432)) {
  case TAG_Nil: {
    heff_drop(v_i_2429);
    v_ts_2439 = v_ts_2433;
    break;
  }
  case TAG_Cons: {
    V v_r_2434 = heff_field(v_kids_2432, 0);
    V v_kids_2435 = heff_field(v_kids_2432, 1);
    heff_take_n(v_kids_2432, 3ULL, 2);
    V v_t_2437 = (g_list_2emap(heff_clo(g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam3, 1, 2, (V[]){heff_dup(v_i_2429), v_r_2434}), v_ts_2433));
    V v_t_2438 = (g_std_2eprogress_2ekidsUnder(v_i_2429, MK_INT(1LL), v_kids_2435));
    v_ts_2439 = (g_prelude_2e_2b_2b(v_t_2437, v_t_2438));
    break;
  }
  default: heff_nomatch(v_kids_2432);
  }
  V v_t_2440 = (g_list_2efilter_24s352363709x250826586(MK_INT(0LL), heff_dup(v_ts_2439)));
  return (g_std_2eprogress_2edrawTop(v_ts_2439, v_t_2440));
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam4(V self, V *args) {
  V v_r_2441 = args[0];
  return v_r_2441;
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_2428 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_hd_2430 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2445 = heff_tr(heff_apply(v_k_2428, 1, (V[]){v_x_2444}));
  V v_t_2446 = (g_std_2eprogress_2eredrawn_24s742480751x1815451405(v_ts_240, v_t_2445));
  return heff_tail(v_t_2446, 2, (V[]){v_hd_2430, v_k_2431});
}
V g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam1(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_cmd_2426 = heff_env(self)[0];
  V v_as_2427 = heff_env(self)[1];
  V v_ts_240 = heff_env(self)[2];
  V v_i_2429 = heff_env(self)[3];
  V v_k_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2442 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ShowRun, 4, (V[]){v_cmd_2426, v_as_2427, heff_clo(g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam2, 1, 2, (V[]){heff_dup(v_ts_240), v_i_2429}), ((V)&g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam4_clo)})});
  V v_t_2443 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2430), LBL_malg), 1, (V[]){v_t_2442}));
  V f_ = heff_get(heff_dup(v_hd_2430), LBL_bind);
  args[0] = v_t_2443;
  args[1] = heff_clo(g_std_2eprogress_2edrawnOp_24s1579838052x1689901582_lam5, 1, 4, (V[]){v_k_2428, v_ts_240, v_hd_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam0(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1430340132x541078361_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1430340132x541078361_lam0, 4, 0};
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam3(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam2(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam1(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1430340132x541078361_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1430340132x541078361_lam1, 3, 0};
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam7(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam6(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam5(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam9(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam10(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam8(V self, V *args);
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam4(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1430340132x541078361_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1430340132x541078361_lam4, 2, 0};

static V g_std_2eprogress_2edrawing_24s1430340132x541078361_val;
static int g_std_2eprogress_2edrawing_24s1430340132x541078361_st;
static V g_std_2eprogress_2edrawing_24s1430340132x541078361_init(void) {
  return heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2edrawing_24s1430340132x541078361_lam0_clo), ((V)&g_std_2eprogress_2edrawing_24s1430340132x541078361_lam1_clo), ((V)&g_std_2eprogress_2edrawing_24s1430340132x541078361_lam4_clo)});
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_get(void) {
  if (g_std_2eprogress_2edrawing_24s1430340132x541078361_st == 2) return g_std_2eprogress_2edrawing_24s1430340132x541078361_val;
  if (g_std_2eprogress_2edrawing_24s1430340132x541078361_st == 1) heff_fail("defined by itself");
  g_std_2eprogress_2edrawing_24s1430340132x541078361_st = 1;
  g_std_2eprogress_2edrawing_24s1430340132x541078361_val = heff_tr(g_std_2eprogress_2edrawing_24s1430340132x541078361_init());
  g_std_2eprogress_2edrawing_24s1430340132x541078361_st = 2;
  return g_std_2eprogress_2edrawing_24s1430340132x541078361_val;
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_ts_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_ts_241, v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_dup(heff_field(v_x_2410, 1));
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  return heff_tail(v_k_245, 4, (V[]){v_t_2413, v_t_2416, v_hd_248, v_k_249});
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam3, 1, 3, (V[]){v_k_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam1(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_ts_246 = args[2];
  V v_c_247 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_ts_246}));
  return heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam2, 2, 2, (V[]){v_c_247, v_k_245});
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2429;
  switch (heff_tag_of(v_x_2426)) {
  case TAG_MkPair: {
    V v_y_2428 = heff_field(v_x_2426, 1);
    heff_take_n(v_x_2426, 2ULL, 2);
    v_x_2429 = v_y_2428;
    break;
  }
  default: heff_nomatch(v_x_2426);
  }
  V f_ = v_k_2425;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2423;
  args[0] = v_hd_2424;
  args[1] = heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam7, 1, 1, (V[]){v_k_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam5(V self, V *args) {
  V v_c_2422 = args[0];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2423 = heff_tr(heff_apply(v_c_2422, 1, (V[]){v_ts_2418}));
  return heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam6, 2, 1, (V[]){v_c_2423});
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam9(V self, V *args) {
  V v_c_2444 = args[0];
  V v_hd_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tail(v_c_2444, 2, (V[]){heff_dup(v_hd_2441), heff_get(v_hd_2441, LBL_ret)});
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam10(V self, V *args) {
  V v_x_2457 = args[0];
  V v_k2_2442 = heff_env(self)[0];
  V v_ts_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k2_2442;
  args[0] = heff_tag(TAG_MkPair, 2, (V[]){v_ts_2418, v_x_2457});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam8(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k2_2442 = args[1];
  V v_p_2440 = heff_env(self)[0];
  V v_ts_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455;
  switch (heff_tag_of(v_p_2440)) {
  case TAG_InL: {
    V v_x_2443 = heff_field(v_p_2440, 0);
    V v_ru_24p_2440_24InL = heff_take_reuse_n(v_p_2440, 1ULL, 1);
    V v_t_2445 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1499074119x1407181331_get()), LBL_hmap), 2, (V[]){heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam9, 1, 1, (V[]){heff_dup(v_hd_2441)}), v_x_2443}));
    v_t_2455 = heff_tag_at(v_ru_24p_2440_24InL, TAG_InL, 1, (V[]){v_t_2445});
    break;
  }
  case TAG_InR: {
    V v_y_2446 = heff_field(v_p_2440, 0);
    V v_ru_24p_2440_24InR = heff_take_reuse_n(v_p_2440, 1ULL, 1);
    V v_t_2454;
    switch (heff_tag_of(v_y_2446)) {
    case TAG_IsTerminal: {
      V v_k_2447 = heff_field(v_y_2446, 0);
      heff_take_n(v_y_2446, 1ULL, 1);
      v_t_2454 = heff_tag_at(v_ru_24p_2440_24InR, TAG_IsTerminal, 1, (V[]){v_k_2447});
      break;
    }
    case TAG_ShowLines: {
      V v_ls_2448 = heff_field(v_y_2446, 0);
      V v_x_2449 = heff_field(v_y_2446, 1);
      V v_ru_24y_2446_24ShowLines = heff_take_reuse_n(v_y_2446, 3ULL, 2);
      heff_drop_cell(v_ru_24p_2440_24InR, 1);
      v_t_2454 = heff_tag_at(v_ru_24y_2446_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2448, v_x_2449});
      break;
    }
    case TAG_ShowRun: {
      V v_cmd_2450 = heff_field(v_y_2446, 0);
      V v_as_2451 = heff_field(v_y_2446, 1);
      V v_lines_2452 = heff_field(v_y_2446, 2);
      V v_k_2453 = heff_field(v_y_2446, 3);
      V v_ru_24y_2446_24ShowRun = heff_take_reuse_n(v_y_2446, 15ULL, 4);
      heff_drop_cell(v_ru_24p_2440_24InR, 1);
      v_t_2454 = heff_tag_at(v_ru_24y_2446_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2450, v_as_2451, v_lines_2452, v_k_2453});
      break;
    }
    default: heff_nomatch(v_y_2446);
    }
    v_t_2455 = heff_tag(TAG_InR, 1, (V[]){v_t_2454});
    break;
  }
  default: heff_nomatch(v_p_2440);
  }
  V v_t_2456 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2441), LBL_malg), 1, (V[]){v_t_2455}));
  V f_ = heff_get(v_hd_2441, LBL_bind);
  args[0] = v_t_2456;
  args[1] = heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam10, 1, 2, (V[]){v_k2_2442, v_ts_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1430340132x541078361_lam4(V self, V *args) {
  V v_p_2417 = args[0];
  V v_ts_2418 = args[1];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_o_2419 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 1);
    return (g_std_2eprogress_2edrawnOp_24s1579838052x1689901582(v_ts_2418, v_o_2419));
  }
  case TAG_InR: {
    V v_q_2420 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_p_2440;
    switch (heff_tag_of(v_q_2420)) {
    case TAG_InL: {
      V v_x_2421 = heff_field(v_q_2420, 0);
      heff_take_n(v_q_2420, 1ULL, 1);
      V v_t_2430 = heff_tr(heff_apply(heff_get(heff_dup(g_co_2eplus_24s1499074119x1407181331_get()), LBL_hmap), 2, (V[]){heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam5, 1, 1, (V[]){heff_dup(v_ts_2418)}), v_x_2421}));
      v_p_2440 = heff_tag_at(v_ru_24p_2417_24InR, TAG_InL, 1, (V[]){v_t_2430});
      break;
    }
    case TAG_InR: {
      V v_y_2431 = heff_field(v_q_2420, 0);
      V v_ru_24q_2420_24InR = heff_take_reuse_n(v_q_2420, 1ULL, 1);
      V v_t_2439;
      switch (heff_tag_of(v_y_2431)) {
      case TAG_IsTerminal: {
        V v_k_2432 = heff_field(v_y_2431, 0);
        heff_take_n(v_y_2431, 1ULL, 1);
        v_t_2439 = heff_tag_at(v_ru_24p_2417_24InR, TAG_IsTerminal, 1, (V[]){v_k_2432});
        break;
      }
      case TAG_ShowLines: {
        V v_ls_2433 = heff_field(v_y_2431, 0);
        V v_x_2434 = heff_field(v_y_2431, 1);
        V v_ru_24y_2431_24ShowLines = heff_take_reuse_n(v_y_2431, 3ULL, 2);
        heff_drop_cell(v_ru_24p_2417_24InR, 1);
        v_t_2439 = heff_tag_at(v_ru_24y_2431_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2433, v_x_2434});
        break;
      }
      case TAG_ShowRun: {
        V v_cmd_2435 = heff_field(v_y_2431, 0);
        V v_as_2436 = heff_field(v_y_2431, 1);
        V v_lines_2437 = heff_field(v_y_2431, 2);
        V v_k_2438 = heff_field(v_y_2431, 3);
        V v_ru_24y_2431_24ShowRun = heff_take_reuse_n(v_y_2431, 15ULL, 4);
        heff_drop_cell(v_ru_24p_2417_24InR, 1);
        v_t_2439 = heff_tag_at(v_ru_24y_2431_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2435, v_as_2436, v_lines_2437, v_k_2438});
        break;
      }
      default: heff_nomatch(v_y_2431);
      }
      v_p_2440 = heff_tag_at(v_ru_24q_2420_24InR, TAG_InR, 1, (V[]){v_t_2439});
      break;
    }
    default: heff_nomatch(v_q_2420);
    }
    return heff_clo(g_std_2eprogress_2edrawing_24s1430340132x541078361_lam8, 2, 2, (V[]){v_p_2440, v_ts_2418});
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_std_2eprogress_2edrawn_24s1137940462x35880749_lam2(V self, V *args);
V g_std_2eprogress_2edrawn_24s1137940462x35880749_lam1(V self, V *args);
V g_std_2eprogress_2edrawn_24s1137940462x35880749_lam0(V self, V *args);

static V g_std_2eprogress_2edrawn_24s1137940462x35880749_val;
static int g_std_2eprogress_2edrawn_24s1137940462x35880749_st;
static V g_std_2eprogress_2edrawn_24s1137940462x35880749_init(void) {
  V v_t_240 = (g_app_2eheff_2emain_2eprogram_24s1917382536x791486084(heff_get(heff_dup(g_std_2eprogress_2edrawing_24s1430340132x541078361_get()), LBL_ret)));
  V v_t_241 = heff_rec(2, shape_next__going, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
  V v_c_242 = heff_tr(heff_apply(v_t_240, 1, (V[]){v_t_241}));
  return heff_clo(g_std_2eprogress_2edrawn_24s1137940462x35880749_lam0, 2, 1, (V[]){v_c_242});
}
V g_std_2eprogress_2edrawn_24s1137940462x35880749_get(void) {
  if (g_std_2eprogress_2edrawn_24s1137940462x35880749_st == 2) return g_std_2eprogress_2edrawn_24s1137940462x35880749_val;
  if (g_std_2eprogress_2edrawn_24s1137940462x35880749_st == 1) heff_fail("defined by itself");
  g_std_2eprogress_2edrawn_24s1137940462x35880749_st = 1;
  g_std_2eprogress_2edrawn_24s1137940462x35880749_val = heff_tr(g_std_2eprogress_2edrawn_24s1137940462x35880749_init());
  g_std_2eprogress_2edrawn_24s1137940462x35880749_st = 2;
  return g_std_2eprogress_2edrawn_24s1137940462x35880749_val;
}
V g_std_2eprogress_2edrawn_24s1137940462x35880749_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_248);
  V v_x_2411;
  switch (heff_tag_of(v_x_245)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_field(v_x_245, 1);
    heff_take_n(v_x_245, 2ULL, 2);
    v_x_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  V f_ = v_k_244;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawn_24s1137940462x35880749_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  V v_t_247 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_243), LBL_malg), 1, (V[]){heff_tag(TAG_InR, 1, (V[]){v_t_246})}));
  return heff_tail(heff_get(v_hd_243, LBL_bind), 2, (V[]){v_t_247, heff_clo(g_std_2eprogress_2edrawn_24s1137940462x35880749_lam2, 1, 2, (V[]){v_x_245, v_k_244})});
}
V g_std_2eprogress_2edrawn_24s1137940462x35880749_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_std_2eprogress_2edrawn_24s1137940462x35880749_lam1, 1, 2, (V[]){v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam0(V self, V *args);
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam1(V self, V *args);
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam2(V self, V *args);
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam4(V self, V *args); static Clo g_std_2eprogress_2equietly_24s755065368x1740453353_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2equietly_24s755065368x1740453353_lam4, 1, 0};
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam5(V self, V *args);
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam3(V self, V *args);
Clo g_std_2eprogress_2equietly_24s755065368x1740453353_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2equietly_24s755065368x1740453353_entry, 1, 0};

V g_std_2eprogress_2equietly_24s755065368x1740453353(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Start: {
    V v_k_244 = heff_field(v_x1_240, 3);
    V v_x_245 = heff_tr(heff_apply(heff_dup(v_k_244), 1, (V[]){heff_dup(g_std_2eprogress_2eroot_get())}));
    return heff_clo(g_std_2eprogress_2equietly_24s755065368x1740453353_lam0, 2, 1, (V[]){v_x_245});
  }
  case TAG_Complete: {
    V v_x_249 = heff_field(v_x1_240, 1);
    return heff_clo(g_std_2eprogress_2equietly_24s755065368x1740453353_lam1, 2, 1, (V[]){heff_dup(v_x_249)});
  }
  case TAG_End: {
    V v_x_2413 = heff_field(v_x1_240, 1);
    return heff_clo(g_std_2eprogress_2equietly_24s755065368x1740453353_lam2, 2, 1, (V[]){heff_dup(v_x_2413)});
  }
  case TAG_RunUnder: {
    V v_cmd_2417 = heff_field(v_x1_240, 1);
    V v_as_2418 = heff_field(v_x1_240, 2);
    V v_k_2419 = heff_field(v_x1_240, 3);
    return heff_clo(g_std_2eprogress_2equietly_24s755065368x1740453353_lam3, 2, 3, (V[]){heff_dup(v_cmd_2417), heff_dup(v_as_2418), heff_dup(v_k_2419)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_entry(V self, V *a) {
  (void)self;
  V r = g_std_2eprogress_2equietly_24s755065368x1740453353(a[0]); heff_drop(a[0]); return r;
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam4(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428 = heff_tr(heff_apply(v_k_2419, 1, (V[]){v_x_2427}));
  V f_ = v_k_2421;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s755065368x1740453353_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_cmd_2417 = heff_env(self)[0];
  V v_as_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_Run, 3, (V[]){v_cmd_2417, v_as_2418, ((V)&g_std_2eprogress_2equietly_24s755065368x1740453353_lam4_clo)})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2425}));
  V f_ = heff_get(v_hd_2420, LBL_bind);
  args[0] = v_t_2426;
  args[1] = heff_clo(g_std_2eprogress_2equietly_24s755065368x1740453353_lam5, 1, 2, (V[]){v_k_2419, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam0(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam0, 1, 0};
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam2(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam2, 2, 0};
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam4(V self, V *args);
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam3(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam3, 3, 0};
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam5(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam5, 2, 0};
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam6(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam6, 2, 0};
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam7(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam7, 1, 0};
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam1(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1055853045x1560533240_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1055853045x1560533240_lam1, 1, 0};

static V g_std_2eprogress_2eshown_24s1055853045x1560533240_val;
static int g_std_2eprogress_2eshown_24s1055853045x1560533240_st;
static V g_std_2eprogress_2eshown_24s1055853045x1560533240_init(void) {
  V v_t_241 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_IsTerminal, 1, (V[]){((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam0_clo)})});
  return heff_perform(v_t_241, ((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam1_clo));
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_get(void) {
  if (g_std_2eprogress_2eshown_24s1055853045x1560533240_st == 2) return g_std_2eprogress_2eshown_24s1055853045x1560533240_val;
  if (g_std_2eprogress_2eshown_24s1055853045x1560533240_st == 1) heff_fail("defined by itself");
  g_std_2eprogress_2eshown_24s1055853045x1560533240_st = 1;
  g_std_2eprogress_2eshown_24s1055853045x1560533240_val = heff_tr(g_std_2eprogress_2eshown_24s1055853045x1560533240_init());
  g_std_2eprogress_2eshown_24s1055853045x1560533240_st = 2;
  return g_std_2eprogress_2eshown_24s1055853045x1560533240_val;
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam0(V self, V *args) {
  V v_b_240 = args[0];
  return v_b_240;
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam2(V self, V *args) {
  V v_a_243 = args[0];
  V v_a_244 = args[1];
  V f_ = v_a_244;
  args[0] = v_a_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam4(V self, V *args) {
  V v_a_248 = args[0];
  V v_a_246 = heff_env(self)[0];
  V v_a_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tail(v_a_246, 2, (V[]){v_a_248, v_a_247});
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam3(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  V v_a_247 = args[2];
  V f_ = v_a_245;
  args[0] = heff_clo(g_std_2eprogress_2eshown_24s1055853045x1560533240_lam4, 1, 2, (V[]){v_a_246, v_a_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam5(V self, V *args) {
  V v_a_249 = args[0];
  V v_a_2410 = args[1];
  return heff_perform(v_a_249, v_a_2410);
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam6(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2412 = args[1];
  V f_ = v_a_2412;
  args[0] = v_a_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam7(V self, V *args) {
  V v_a_2413 = args[0];
  heff_drop(v_a_2413);
  return NTAG(TAG_MkUnit);
}
V g_std_2eprogress_2eshown_24s1055853045x1560533240_lam1(V self, V *args) {
  V v_a_242 = args[0];
  switch (heff_tag_of(v_a_242)) {
  case TAG_True: {
    return heff_tail(heff_dup(g_std_2eprogress_2edrawn_24s1137940462x35880749_get()), 3, (V[]){heff_rec(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam2_clo), ((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam3_clo), ((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam5_clo)}), ((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam6_clo), ((V)&g_std_2eprogress_2eshown_24s1055853045x1560533240_lam7_clo)});
  }
  case TAG_False: {
    return (g_app_2eheff_2emain_2eprogram_24s1364294205x625005369(heff_get(heff_dup(g_co_2ethrough_24s1918455300x553827868_get()), LBL_ret)));
  }
  default: return heff_nomatch(v_a_242);
  }
}