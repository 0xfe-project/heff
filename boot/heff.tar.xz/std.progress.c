// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_IsTerminal 53507
#define TAG_MkKid 64674
#define TAG_MkTask 37714
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define LBL_bind 9519364
#define LBL_done 9584713
#define LBL_fmap 9641981
#define LBL_going 299892244
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_parent 951717845
#define LBL_ret 322331
#define LBL_task 10048076
#define LBL_total 311908190
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_next__going[] = {LBL_next, LBL_going};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_app_2eheff_2emain_2eprogram_24s1014075943x1216828586(V, V);
V g_app_2eheff_2emain_2eprogram_24s1014075943x1216828586_entry(V self, V *a);
extern Clo g_app_2eheff_2emain_2eprogram_24s1014075943x1216828586_clo;
V g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_get(void);
V g_co_2eop_24s1279463522x45159155(V, V, V, V);
V g_co_2eop_24s1279463522x45159155_entry(V self, V *a);
extern Clo g_co_2eop_24s1279463522x45159155_clo;
V g_co_2eop_24s364335313x798093277(V, V);
V g_co_2eop_24s364335313x798093277_entry(V self, V *a);
extern Clo g_co_2eop_24s364335313x798093277_clo;
V g_co_2eop_24s504905999x685316098(V, V, V);
V g_co_2eop_24s504905999x685316098_entry(V self, V *a);
extern Clo g_co_2eop_24s504905999x685316098_clo;
V g_co_2eplus_24s1100180636x1646925226_get(void);
V g_list_2efilter_24s1371839958x1221974112(V, V);
V g_list_2efilter_24s1371839958x1221974112_entry(V self, V *a);
extern Clo g_list_2efilter_24s1371839958x1221974112_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f378206553x1816388893(V, V, V, V);
V g_list_2emap_24f378206553x1816388893_entry(V self, V *a);
extern Clo g_list_2emap_24f378206553x1816388893_clo;
V g_list_2emap_24s1661513421x830177447(V, V, V);
V g_list_2emap_24s1661513421x830177447_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2eprogress_2ecountOf(V, V);
V g_std_2eprogress_2ecountOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2ecountOf_clo;
V g_std_2eprogress_2edrawTop(V, V);
V g_std_2eprogress_2edrawTop_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawTop_clo;
V g_std_2eprogress_2edrawUnder(V, V, V);
V g_std_2eprogress_2edrawUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawUnder_clo;
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(void);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752(V, V);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_clo;
V g_std_2eprogress_2ekidsUnder(V, V, V);
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_clo;
V g_std_2eprogress_2ekidsUnder_24dps(V, V, V, V);
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_24dps_clo;
V g_std_2eprogress_2eparentOf(V, V);
V g_std_2eprogress_2eparentOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2eparentOf_clo;
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2equietly_24s1392860441x1460275359(V);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_entry(V self, V *a);
extern Clo g_std_2eprogress_2equietly_24s1392860441x1460275359_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2erooted(V, V, V);
V g_std_2eprogress_2erooted_entry(V self, V *a);
extern Clo g_std_2eprogress_2erooted_clo;
V g_std_2eprogress_2eshown_24s1929445196x1856941725_get(void);

static V g_std_2eprogress_2eroot_val;
static HEFF_ONCE g_std_2eprogress_2eroot_st;
static V g_std_2eprogress_2eroot_init(void) {
  return heff_tag_n(TAG_MkTask, 1, (V[]){MK_INT(0LL)});
}
V g_std_2eprogress_2eroot_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eroot_st)) return g_std_2eprogress_2eroot_val;
  return heff_global(&g_std_2eprogress_2eroot_val, &g_std_2eprogress_2eroot_st, g_std_2eprogress_2eroot_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args);
V g_std_2eprogress_2eprogress_lam2(V self, V *args);
V g_std_2eprogress_2eprogress_lam0(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam0, 3, 0};
V g_std_2eprogress_2eprogress_lam3(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam3, 4, 0};

static V g_std_2eprogress_2eprogress_val;
static HEFF_ONCE g_std_2eprogress_2eprogress_st;
static V g_std_2eprogress_2eprogress_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprogress_2eprogress_lam0_clo), ((V)&g_std_2eprogress_2eprogress_lam3_clo)});
}
V g_std_2eprogress_2eprogress_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eprogress_st)) return g_std_2eprogress_2eprogress_val;
  return heff_global(&g_std_2eprogress_2eprogress_val, &g_std_2eprogress_2eprogress_st, g_std_2eprogress_2eprogress_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args) {
  V v_t_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_t_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_call(v_k_2418, 1, (V[]){v_r_2419}));
  V f_ = v_g_241;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Start: {
    V v_parent_243 = heff_field(v_p_242, 0);
    V v_name_244 = heff_field(v_p_242, 1);
    V v_total_245 = heff_field(v_p_242, 2);
    V v_k_246 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Start, TAG_Start, 4, (V[]){v_parent_243, v_name_244, v_total_245, heff_clo_n(g_std_2eprogress_2eprogress_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Complete: {
    V v_t_249 = heff_field(v_p_242, 0);
    V v_x_2410 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Complete = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
    return heff_tag_at_n(v_ru_24p_242_24Complete, TAG_Complete, 2, (V[]){v_t_249, v_t_2411});
  }
  case TAG_End: {
    V v_t_2412 = heff_field(v_p_242, 0);
    V v_x_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_at_n(v_ru_24p_242_24End, TAG_End, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_RunUnder: {
    V v_t_2415 = heff_field(v_p_242, 0);
    V v_cmd_2416 = heff_field(v_p_242, 1);
    V v_as_2417 = heff_field(v_p_242, 2);
    V v_k_2418 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24RunUnder = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2415, v_cmd_2416, v_as_2417, heff_clo_n(g_std_2eprogress_2eprogress_lam2, 1, 2, (V[]){v_k_2418, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprogress_2eprogress_lam3(V self, V *args) {
  V v_m_2421 = args[0];
  V v_n_2422 = args[1];
  V v_nt_2423 = args[2];
  V v_p_2424 = args[3];
  heff_drop(v_m_2421);
  heff_drop(v_n_2422);
  heff_drop(v_nt_2423);
  switch (heff_tag_of(v_p_2424)) {
  case TAG_Start: {
    V v_parent_2425 = heff_field(v_p_2424, 0);
    V v_name_2426 = heff_field(v_p_2424, 1);
    V v_total_2427 = heff_field(v_p_2424, 2);
    V v_k_2428 = heff_field(v_p_2424, 3);
    V v_ru_24p_2424_24Start = heff_take_reuse_n(v_p_2424, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2424_24Start, TAG_Start, 4, (V[]){v_parent_2425, v_name_2426, v_total_2427, v_k_2428});
  }
  case TAG_Complete: {
    V v_t_2429 = heff_field(v_p_2424, 0);
    V v_x_2430 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24Complete = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2424_24Complete, TAG_Complete, 2, (V[]){v_t_2429, v_x_2430});
  }
  case TAG_End: {
    V v_t_2431 = heff_field(v_p_2424, 0);
    V v_x_2432 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24End = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2424_24End, TAG_End, 2, (V[]){v_t_2431, v_x_2432});
  }
  case TAG_RunUnder: {
    V v_t_2433 = heff_field(v_p_2424, 0);
    V v_cmd_2434 = heff_field(v_p_2424, 1);
    V v_as_2435 = heff_field(v_p_2424, 2);
    V v_k_2436 = heff_field(v_p_2424, 3);
    V v_ru_24p_2424_24RunUnder = heff_take_reuse_n(v_p_2424, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2424_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2433, v_cmd_2434, v_as_2435, v_k_2436});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
HEFF_LIT(g_std_2eprogress_2ecountOf_str0, 0, "");
HEFF_LIT(g_std_2eprogress_2ecountOf_str1, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str2, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str3, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str4, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str5, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str6, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str7, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str8, 1, "[");
Clo g_std_2eprogress_2ecountOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ecountOf_entry, 2, 0};

V g_std_2eprogress_2ecountOf(V v_done_240, V v_total_241) {
top: ;
  if (heff_intEq_c(heff_dup(v_done_240), MK_INT(0LL))) {
    if (heff_intEq_c(heff_dup(v_total_241), MK_INT(0LL))) {
      heff_drop(v_done_240);
      heff_drop(v_total_241);
      return ((V)&g_std_2eprogress_2ecountOf_str0);
    } else {
      V v_t_244 = heff_strAppend(heff_intShow(v_total_241), ((V)&g_std_2eprogress_2ecountOf_str1));
      V v_t_245 = heff_strAppend(heff_intShow(v_done_240), heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str2), v_t_244));
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str3), v_t_245);
    }
  } else {
    if (heff_intEq_c(heff_dup(v_total_241), MK_INT(0LL))) {
      heff_drop(v_total_241);
      V v_t_247 = heff_strAppend(heff_intShow(v_done_240), ((V)&g_std_2eprogress_2ecountOf_str4));
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str5), v_t_247);
    } else {
      V v_t_248 = heff_strAppend(heff_intShow(v_total_241), ((V)&g_std_2eprogress_2ecountOf_str6));
      V v_t_249 = heff_strAppend(heff_intShow(v_done_240), heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str7), v_t_248));
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str8), v_t_249);
    }
  }
}
V g_std_2eprogress_2ecountOf_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ecountOf(a[0], a[1]);
}
HEFF_LIT(g_std_2eprogress_2edrawUnder_str0, 7, "\342\224\224\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str1, 7, "\342\224\234\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str2, 3, "   ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str3, 5, "\342\224\202  ");
Clo g_std_2eprogress_2edrawUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawUnder_entry, 3, 0};

V g_std_2eprogress_2edrawUnder(V v_every_240, V v_prefix_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    heff_drop(v_prefix_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_std_2eprogress_2edrawUnder_str0);
      break;
    }
    case TAG_Cons: {
      v_t_247 = ((V)&g_std_2eprogress_2edrawUnder_str1);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_248 = (g_std_2eprogress_2ecountOf(heff_take_field(v_t_243, 3), heff_take_field(v_t_243, 4)));
    V v_t_249 = heff_strAppend(v_t_248, heff_take_field(v_t_243, 2));
    V v_t_2410 = heff_strAppend(heff_dup(v_prefix_241), heff_strAppend(v_t_247, v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_std_2eprogress_2edrawUnder_str2);
      break;
    }
    case TAG_Cons: {
      v_t_2413 = ((V)&g_std_2eprogress_2edrawUnder_str3);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2414 = (g_list_2efilter_24s1371839958x1221974112(heff_get_n(v_t_243, 0, 5), heff_dup(v_every_240)));
    V v_t_2415 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), heff_strAppend(heff_dup(v_prefix_241), v_t_2413), v_t_2414));
    V v_t_2416 = (g_std_2eprogress_2edrawUnder(v_every_240, v_prefix_241, v_rest_244));
    V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2416));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_2417});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2edrawUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawUnder(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eprogress_2edrawTop_str0, 0, "");
Clo g_std_2eprogress_2edrawTop_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawTop_entry, 2, 0};

V g_std_2eprogress_2edrawTop(V v_every_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_std_2eprogress_2ecountOf(heff_take_field(v_t_242, 3), heff_take_field(v_t_242, 4)));
    V v_t_245 = heff_strAppend(v_t_244, heff_take_field(v_t_242, 2));
    V v_t_246 = (g_list_2efilter_24s1371839958x1221974112(heff_get_n(v_t_242, 0, 5), heff_dup(v_every_240)));
    V v_t_247 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), ((V)&g_std_2eprogress_2edrawTop_str0), v_t_246));
    V v_t_248 = (g_std_2eprogress_2edrawTop(v_every_240, v_rest_243));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawTop_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawTop(a[0], a[1]);
}
Clo g_std_2eprogress_2ekidsUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_entry, 3, 0};

V g_std_2eprogress_2ekidsUnder(V v_t_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkKid: {
      V v_name_245 = heff_field(v_x31_243, 0);
      V v_done_246 = heff_field(v_x31_243, 1);
      V v_total_247 = heff_field(v_x31_243, 2);
      V v_parent_248 = heff_field(v_x31_243, 3);
      heff_take_n(v_x31_243, 15ULL, 4);
      V v_t_2411;
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        v_t_2411 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c(heff_dup(v_i_241), MK_INT(255LL))) {
          v_t_2411 = heff_dup(v_t_240);
        } else {
          v_t_2411 = heff_intSub(MK_INT(-1LL), heff_dup(v_i_241));
        }
      }
      V v_t_2414;
      if (heff_intEq_c(heff_dup(v_parent_248), MK_INT(0LL))) {
        heff_drop(v_parent_248);
        v_t_2414 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c(heff_dup(v_parent_248), MK_INT(255LL))) {
          heff_drop(v_parent_248);
          v_t_2414 = heff_dup(v_t_240);
        } else {
          v_t_2414 = heff_intSub(MK_INT(-1LL), v_parent_248);
        }
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_2411, v_t_2414, v_name_245, v_done_246, v_total_247}), heff_hole()});
      V v_u_2416 = (g_std_2eprogress_2ekidsUnder_24dps(v_t_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_244, heff_dup(v_cell_2415)));
      heff_drop(v_u_2416);
      return v_cell_2415;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder(a[0], a[1], a[2]);
}
Clo g_std_2eprogress_2ekidsUnder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_24dps_entry, 4, 0};

V g_std_2eprogress_2ekidsUnder_24dps(V v_t_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkKid: {
      V v_name_246 = heff_field(v_x31_244, 0);
      V v_done_247 = heff_field(v_x31_244, 1);
      V v_total_248 = heff_field(v_x31_244, 2);
      V v_parent_249 = heff_field(v_x31_244, 3);
      heff_take_n(v_x31_244, 15ULL, 4);
      V v_t_2412;
      if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
        v_t_2412 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c(heff_dup(v_i_241), MK_INT(255LL))) {
          v_t_2412 = heff_dup(v_t_240);
        } else {
          v_t_2412 = heff_intSub(MK_INT(-1LL), heff_dup(v_i_241));
        }
      }
      V v_t_2415;
      if (heff_intEq_c(heff_dup(v_parent_249), MK_INT(0LL))) {
        heff_drop(v_parent_249);
        v_t_2415 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c(heff_dup(v_parent_249), MK_INT(255LL))) {
          heff_drop(v_parent_249);
          v_t_2415 = heff_dup(v_t_240);
        } else {
          v_t_2415 = heff_intSub(MK_INT(-1LL), v_parent_249);
        }
      }
      V v_cell_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_2412, v_t_2415, v_name_246, v_done_247, v_total_248}), heff_hole()});
      V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
      heff_drop(v_u_2417);
      V t_0 = v_t_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_rest_245;
      V t_3 = v_cell_2416;
      v_t_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2eprogress_2erooted_str0, 0, "");
Clo g_std_2eprogress_2erooted_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2erooted_entry, 3, 0};

V g_std_2eprogress_2erooted(V v_t_240, V v_x2_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkKid: {
    V v_name_243 = heff_field(v_x2_241, 0);
    V v_done_244 = heff_field(v_x2_241, 1);
    V v_total_245 = heff_field(v_x2_241, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_s_242, 0)), v_t_240)) {
      V v_t_249;
      if (heff_strEq_c(heff_dup(v_name_243), ((V)&g_std_2eprogress_2erooted_str0))) {
        v_t_249 = heff_dup(heff_rfield(v_s_242, 2));
      } else {
        v_t_249 = heff_dup(v_name_243);
      }
      V v_t_2414;
      if (heff_intEq_c(heff_dup(v_total_245), MK_INT(0LL))) {
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 4)))) {
          V v_y_2412 = heff_dup(heff_rfield(v_s_242, 4));
          if (heff_intLe_c(heff_dup(v_done_244), heff_dup(v_y_2412))) {
            heff_drop(v_y_2412);
            v_t_2414 = heff_dup(v_done_244);
          } else {
            v_t_2414 = v_y_2412;
          }
        } else {
          v_t_2414 = heff_dup(v_done_244);
        }
      } else {
        v_t_2414 = heff_dup(v_done_244);
      }
      V v_t_2416;
      if (heff_intEq_c(heff_dup(v_total_245), MK_INT(0LL))) {
        v_t_2416 = heff_dup(heff_rfield(v_s_242, 4));
      } else {
        v_t_2416 = heff_dup(v_total_245);
      }
      return ({ V rv_2 = v_t_249; V rv_3 = v_t_2414; V rv_4 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_s_242, 3ULL, 5, shape_task__parent__name__done__total, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      return v_s_242;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2erooted_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eprogress_2erooted(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2eprogress_2eparentOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eparentOf_entry, 2, 0};

V g_std_2eprogress_2eparentOf(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 0)), heff_dup(v_i_240))) {
      heff_drop(v_i_240);
      return heff_dup(heff_rfield(v_t_242, 1));
    } else {
      V t_0 = v_i_240;
      V t_1 = v_rest_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2eparentOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eprogress_2eparentOf(a[0], a1); heff_drop(a1); return r;
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam1(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam0(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam3(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam2(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam5(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam4(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam8(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam7(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam9(V self, V *args); static Clo g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam9, 1, 0};
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam11(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam10(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam6(V self, V *args);
Clo g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_entry, 2, 0};

V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752(V v_ts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Start: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_name_243 = heff_field(v_x2_241, 1);
    V v_total_244 = heff_field(v_x2_241, 2);
    V v_k_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkTask: {
      V v_p_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24MkTask = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_ts_240, 0)), MK_INT(1LL));
      V v_t_248 = heff_rec_n(5, shape_task__parent__name__done__total, (V[]){heff_dup(heff_rfield(v_ts_240, 0)), v_p_246, v_name_243, MK_INT(0LL), v_total_244});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_ts_240, 1), v_t_249));
      V v_ts_2411 = heff_rec_n(2, shape_next__going, (V[]){v_t_247, v_t_2410});
      V v_t_2412 = heff_tag_at_n(v_ru_24x21_242_24MkTask, TAG_MkTask, 1, (V[]){heff_get_n(v_ts_240, 0, 2)});
      V v_x_2413 = heff_tr(heff_call(v_k_245, 1, (V[]){v_t_2412}));
      V v_ts_2414 = heff_dup(heff_rfield(v_ts_2411, 1));
      V v_t_2415 = (g_list_2efilter_24s1371839958x1221974112(MK_INT(0LL), heff_dup(v_ts_2414)));
      V v_ls_2416 = (g_std_2eprogress_2edrawTop(v_ts_2414, v_t_2415));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam0, 2, 3, (V[]){v_ls_2416, v_ts_2411, v_x_2413});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_Complete: {
    V v_x21_2421 = heff_field(v_x2_241, 0);
    V v_x_2422 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkTask: {
      V v_i_2423 = heff_field(v_x21_2421, 0);
      heff_take_n(v_x21_2421, 1ULL, 1);
      V v_t_2424 = (g_list_2emap_24s1661513421x830177447(v_i_2423, MK_INT(1LL), heff_take_field(v_ts_240, 1)));
      V v_ts_2425 = ({ V rv_1 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2426 = heff_dup(heff_rfield(v_ts_2425, 1));
      V v_t_2427 = (g_list_2efilter_24s1371839958x1221974112(MK_INT(0LL), heff_dup(v_ts_2426)));
      V v_ls_2428 = (g_std_2eprogress_2edrawTop(v_ts_2426, v_t_2427));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam2, 2, 3, (V[]){v_ls_2428, v_ts_2425, v_x_2422});
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  case TAG_End: {
    V v_x21_2433 = heff_field(v_x2_241, 0);
    V v_x_2434 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2433)) {
    case TAG_MkTask: {
      V v_i_2435 = heff_field(v_x21_2433, 0);
      heff_take_n(v_x21_2433, 1ULL, 1);
      V v_i_2436 = (g_std_2eprogress_2eparentOf(heff_dup(v_i_2435), heff_rfield(v_ts_240, 1)));
      V v_t_2437 = (g_list_2emap_24f378206553x1816388893(v_i_2436, MK_INT(1LL), v_i_2435, heff_take_field(v_ts_240, 1)));
      V v_ts_2438 = ({ V rv_1 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2439 = heff_dup(heff_rfield(v_ts_2438, 1));
      V v_t_2440 = (g_list_2efilter_24s1371839958x1221974112(MK_INT(0LL), heff_dup(v_ts_2439)));
      V v_ls_2441 = (g_std_2eprogress_2edrawTop(v_ts_2439, v_t_2440));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam4, 2, 3, (V[]){v_ls_2441, v_ts_2438, v_x_2434});
    }
    default: return heff_nomatch(v_x21_2433);
    }
  }
  case TAG_RunUnder: {
    V v_x21_2446 = heff_field(v_x2_241, 0);
    V v_cmd_2447 = heff_field(v_x2_241, 1);
    V v_as_2448 = heff_field(v_x2_241, 2);
    V v_k_2449 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_2446)) {
    case TAG_MkTask: {
      V v_i_2450 = heff_field(v_x21_2446, 0);
      heff_take_n(v_x21_2446, 1ULL, 1);
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam6, 2, 5, (V[]){v_cmd_2447, v_as_2448, v_ts_240, v_i_2450, v_k_2449});
    }
    default: return heff_nomatch(v_x21_2446);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawnOp_24s1598125166x1100140752(a[0], a[1]);
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2420);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_ls_2416 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2416, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s504905999x685316098(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_hd_2417, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam1, 1, 3, (V[]){v_k_2418, v_ts_2411, v_x_2413})));
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_ts_2425 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2425, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam2(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_ls_2428 = heff_env(self)[0];
  V v_ts_2425 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2428, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s504905999x685316098(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2429, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam3, 1, 3, (V[]){v_k_2430, v_ts_2425, v_x_2422})));
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam5(V self, V *args) {
  V v_x_2445 = args[0];
  V v_k_2443 = heff_env(self)[0];
  V v_ts_2438 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2445);
  V f_ = v_k_2443;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2438, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam4(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_ls_2441 = heff_env(self)[0];
  V v_ts_2438 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2444 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2441, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s504905999x685316098(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2442, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam5, 1, 3, (V[]){v_k_2443, v_ts_2438, v_x_2434})));
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam8(V self, V *args) {
  V v_s_2457 = args[0];
  V v_i_2450 = heff_env(self)[0];
  V v_r_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_i_2450; V a_1 = v_r_2455; V a_2 = v_s_2457; V r_ = (g_std_2eprogress_2erooted(a_0, a_1, a_2)); heff_drop(v_r_2455); r_; });
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam7(V self, V *args) {
  V v_kids_2453 = args[0];
  V v_ts_240 = heff_env(self)[0];
  V v_i_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ts_2454 = heff_get_n(v_ts_240, 1, 2);
  V v_ts_2460;
  switch (heff_tag_of(v_kids_2453)) {
  case TAG_Nil: {
    heff_drop(v_i_2450);
    v_ts_2460 = v_ts_2454;
    break;
  }
  case TAG_Cons: {
    V v_r_2455 = heff_field(v_kids_2453, 0);
    V v_kids_2456 = heff_field(v_kids_2453, 1);
    heff_take_n(v_kids_2453, 3ULL, 2);
    V v_t_2458 = (g_list_2emap(heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam8, 1, 2, (V[]){heff_dup(v_i_2450), v_r_2455}), v_ts_2454));
    V v_t_2459 = (g_std_2eprogress_2ekidsUnder(v_i_2450, MK_INT(1LL), v_kids_2456));
    v_ts_2460 = (g_prelude_2e_2b_2b(v_t_2458, v_t_2459));
    break;
  }
  default: heff_nomatch(v_kids_2453);
  }
  V v_t_2461 = (g_list_2efilter_24s1371839958x1221974112(MK_INT(0LL), heff_dup(v_ts_2460)));
  return (g_std_2eprogress_2edrawTop(v_ts_2460, v_t_2461));
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam9(V self, V *args) {
  V v_r_2462 = args[0];
  return v_r_2462;
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_k_2452 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_x_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2470);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_240, v_x_2465});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam10(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_hd_2451 = heff_env(self)[2];
  V v_k_2452 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2465 = heff_tr(heff_call(v_k_2449, 1, (V[]){v_x_2464}));
  V v_ts_2466 = heff_dup(heff_rfield(v_ts_240, 1));
  V v_t_2467 = (g_list_2efilter_24s1371839958x1221974112(MK_INT(0LL), heff_dup(v_ts_2466)));
  V v_ls_2468 = (g_std_2eprogress_2edrawTop(v_ts_2466, v_t_2467));
  V v_t_2469 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2468, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s504905999x685316098(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), v_hd_2451, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam11, 1, 3, (V[]){v_k_2452, v_ts_240, v_x_2465})));
}
V g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam6(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_cmd_2447 = heff_env(self)[0];
  V v_as_2448 = heff_env(self)[1];
  V v_ts_240 = heff_env(self)[2];
  V v_i_2450 = heff_env(self)[3];
  V v_k_2449 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ShowRun, 4, (V[]){v_cmd_2447, v_as_2448, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam7, 1, 2, (V[]){heff_dup(v_ts_240), v_i_2450}), ((V)&g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam9_clo)})});
  return (g_co_2eop_24s504905999x685316098(v_t_2463, heff_dup(v_hd_2451), heff_clo_n(g_std_2eprogress_2edrawnOp_24s1598125166x1100140752_lam10, 1, 4, (V[]){v_k_2449, v_ts_240, v_hd_2451, v_k_2452})));
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam0(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam0, 4, 0};
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam3(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam2(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam1(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam1, 3, 0};
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam7(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam6(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam5(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam5, 3, 0};
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam9(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam8(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam8, 4, 0};
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam12(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam11(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam10(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam13(V self, V *args);
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam4(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam4, 2, 0};

static V g_std_2eprogress_2edrawing_24s1506381720x1028922836_val;
static HEFF_ONCE g_std_2eprogress_2edrawing_24s1506381720x1028922836_st;
static V g_std_2eprogress_2edrawing_24s1506381720x1028922836_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam0_clo), ((V)&g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam1_clo), ((V)&g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam4_clo)});
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2edrawing_24s1506381720x1028922836_st)) return g_std_2eprogress_2edrawing_24s1506381720x1028922836_val;
  return heff_global(&g_std_2eprogress_2edrawing_24s1506381720x1028922836_val, &g_std_2eprogress_2edrawing_24s1506381720x1028922836_st, g_std_2eprogress_2edrawing_24s1506381720x1028922836_init);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_ts_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_241, v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_dup(heff_field(v_x_2410, 1));
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_245;
  heff_room[0] = v_t_2413;
  heff_room[1] = v_t_2416;
  heff_room[2] = v_hd_248;
  heff_room[3] = v_k_249;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam3, 1, 3, (V[]){v_k_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam1(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_ts_246 = args[2];
  V v_c_247 = heff_tr(heff_call(v_m_244, 1, (V[]){v_ts_246}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam2, 2, 2, (V[]){v_c_247, v_k_245});
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_dup(heff_field(v_x_2428, 0));
    v_t_2431 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2434;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_y_2433 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 2ULL, 2);
    v_t_2434 = v_y_2433;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2435 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_t_2434}));
  V v_x_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, v_t_2435});
  V f_ = v_k_2427;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_g_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam7, 1, 2, (V[]){v_g_2422, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam5(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_ts_2424 = args[2];
  V v_c_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_ts_2424}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam6, 2, 2, (V[]){v_c_2425, v_g_2422});
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_2437 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2442 = heff_tr(heff_call(v_g_2437, 1, (V[]){v_x_2441}));
  V f_ = v_k_2440;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam8(V self, V *args) {
  V v_g_2437 = args[0];
  V v_c_2438 = args[1];
  V v_hd_2439 = args[2];
  V v_k_2440 = args[3];
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam9, 1, 2, (V[]){v_g_2437, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam12(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_y_2449 = heff_field(v_x_2447, 1);
    heff_take_n(v_x_2447, 2ULL, 2);
    v_t_2450 = v_y_2449;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V f_ = v_k_2446;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam11(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam12, 1, 1, (V[]){v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam10(V self, V *args) {
  V v_c_2443 = args[0];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2444 = heff_tr(heff_call(v_c_2443, 1, (V[]){v_ts_2418}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam11, 2, 1, (V[]){v_c_2444});
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam13(V self, V *args) {
  V v_x_2462 = args[0];
  V v_hd_2463 = args[1];
  V v_k_2464 = args[2];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2463);
  V f_ = v_k_2464;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2418, v_x_2462});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam4(V self, V *args) {
  V v_p_2417 = args[0];
  V v_ts_2418 = args[1];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_o_2419 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 1);
    return (g_std_2eprogress_2edrawnOp_24s1598125166x1100140752(v_ts_2418, v_o_2419));
  }
  case TAG_InR: {
    V v_q_2420 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2461;
    switch (heff_tag_of(v_q_2420)) {
    case TAG_InL: {
      V v_x_2421 = heff_field(v_q_2420, 0);
      V v_ru_24q_2420_24InL = heff_take_reuse_n(v_q_2420, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2eplus_24s1100180636x1646925226_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam5_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam8_clo)}), heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam10, 1, 1, (V[]){heff_dup(v_ts_2418)}), v_x_2421}));
      v_t_2461 = heff_tag_at_n(v_ru_24q_2420_24InL, TAG_InL, 1, (V[]){v_t_2451});
      break;
    }
    case TAG_InR: {
      V v_y_2452 = heff_field(v_q_2420, 0);
      V v_ru_24q_2420_24InR = heff_take_reuse_n(v_q_2420, 1ULL, 1);
      V v_t_2460;
      switch (heff_tag_of(v_y_2452)) {
      case TAG_IsTerminal: {
        V v_k_2453 = heff_field(v_y_2452, 0);
        heff_take_n(v_y_2452, 1ULL, 1);
        v_t_2460 = heff_tag_at_n(v_ru_24q_2420_24InR, TAG_IsTerminal, 1, (V[]){v_k_2453});
        break;
      }
      case TAG_ShowLines: {
        V v_ls_2454 = heff_field(v_y_2452, 0);
        V v_x_2455 = heff_field(v_y_2452, 1);
        V v_ru_24y_2452_24ShowLines = heff_take_reuse_n(v_y_2452, 3ULL, 2);
        heff_drop_cell(v_ru_24q_2420_24InR, 1);
        v_t_2460 = heff_tag_at_n(v_ru_24y_2452_24ShowLines, TAG_ShowLines, 2, (V[]){v_ls_2454, v_x_2455});
        break;
      }
      case TAG_ShowRun: {
        V v_cmd_2456 = heff_field(v_y_2452, 0);
        V v_as_2457 = heff_field(v_y_2452, 1);
        V v_lines_2458 = heff_field(v_y_2452, 2);
        V v_k_2459 = heff_field(v_y_2452, 3);
        V v_ru_24y_2452_24ShowRun = heff_take_reuse_n(v_y_2452, 15ULL, 4);
        heff_drop_cell(v_ru_24q_2420_24InR, 1);
        v_t_2460 = heff_tag_at_n(v_ru_24y_2452_24ShowRun, TAG_ShowRun, 4, (V[]){v_cmd_2456, v_as_2457, v_lines_2458, v_k_2459});
        break;
      }
      default: heff_nomatch(v_y_2452);
      }
      v_t_2461 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2460});
      break;
    }
    default: heff_nomatch(v_q_2420);
    }
    V f_ = ((V)&g_co_2eop_24s1279463522x45159155_clo);
    args[0] = v_t_2461;
    args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s1506381720x1028922836_lam13, 3, 1, (V[]){v_ts_2418});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam0(V self, V *args);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam1(V self, V *args);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam2(V self, V *args);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam4(V self, V *args); static Clo g_std_2eprogress_2equietly_24s1392860441x1460275359_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2equietly_24s1392860441x1460275359_lam4, 1, 0};
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam5(V self, V *args);
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam3(V self, V *args);
Clo g_std_2eprogress_2equietly_24s1392860441x1460275359_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2equietly_24s1392860441x1460275359_entry, 1, 0};

V g_std_2eprogress_2equietly_24s1392860441x1460275359(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Start: {
    V v_k_244 = heff_field(v_x1_240, 3);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_k_244), 1, (V[]){heff_dup(g_std_2eprogress_2eroot_get())}));
    return heff_clo_n(g_std_2eprogress_2equietly_24s1392860441x1460275359_lam0, 2, 1, (V[]){v_x_245});
  }
  case TAG_Complete: {
    V v_x_249 = heff_field(v_x1_240, 1);
    return heff_clo_n(g_std_2eprogress_2equietly_24s1392860441x1460275359_lam1, 2, 1, (V[]){heff_dup(v_x_249)});
  }
  case TAG_End: {
    V v_x_2413 = heff_field(v_x1_240, 1);
    return heff_clo_n(g_std_2eprogress_2equietly_24s1392860441x1460275359_lam2, 2, 1, (V[]){heff_dup(v_x_2413)});
  }
  case TAG_RunUnder: {
    V v_cmd_2417 = heff_field(v_x1_240, 1);
    V v_as_2418 = heff_field(v_x1_240, 2);
    V v_k_2419 = heff_field(v_x1_240, 3);
    return heff_clo_n(g_std_2eprogress_2equietly_24s1392860441x1460275359_lam3, 2, 3, (V[]){heff_dup(v_cmd_2417), heff_dup(v_as_2418), heff_dup(v_k_2419)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eprogress_2equietly_24s1392860441x1460275359(a0); heff_drop(a0); return r;
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam4(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_k_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2427 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_x_2426}));
  V f_ = v_k_2421;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1392860441x1460275359_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_cmd_2417 = heff_env(self)[0];
  V v_as_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){v_cmd_2417, v_as_2418, ((V)&g_std_2eprogress_2equietly_24s1392860441x1460275359_lam4_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s504905999x685316098(v_t_2425, v_hd_2420, heff_clo_n(g_std_2eprogress_2equietly_24s1392860441x1460275359_lam5, 1, 2, (V[]){v_k_2419, v_k_2421})));
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam0(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam0, 1, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam2(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam2, 2, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam4(V self, V *args);
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam3(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam3, 3, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam5(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam5, 2, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam7(V self, V *args);
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam6(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam6, 1, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam8(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam8, 1, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam9(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam9, 1, 0};
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam1(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1929445196x1856941725_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1929445196x1856941725_lam1, 1, 0};

static V g_std_2eprogress_2eshown_24s1929445196x1856941725_val;
static HEFF_ONCE g_std_2eprogress_2eshown_24s1929445196x1856941725_st;
static V g_std_2eprogress_2eshown_24s1929445196x1856941725_init(void) {
  V v_t_241 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_IsTerminal, 1, (V[]){((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam0_clo)})});
  return heff_perform(v_t_241, ((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam1_clo));
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eshown_24s1929445196x1856941725_st)) return g_std_2eprogress_2eshown_24s1929445196x1856941725_val;
  return heff_global(&g_std_2eprogress_2eshown_24s1929445196x1856941725_val, &g_std_2eprogress_2eshown_24s1929445196x1856941725_st, g_std_2eprogress_2eshown_24s1929445196x1856941725_init);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam0(V self, V *args) {
  V v_b_240 = args[0];
  return v_b_240;
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam2(V self, V *args) {
  V v_a_245 = args[0];
  V v_a_246 = args[1];
  V f_ = v_a_246;
  args[0] = v_a_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam4(V self, V *args) {
  V v_a_2410 = args[0];
  V v_a_248 = heff_env(self)[0];
  V v_a_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_248;
  heff_room[0] = v_a_2410;
  heff_room[1] = v_a_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam3(V self, V *args) {
  V v_a_247 = args[0];
  V v_a_248 = args[1];
  V v_a_249 = args[2];
  V f_ = v_a_247;
  args[0] = heff_clo_n(g_std_2eprogress_2eshown_24s1929445196x1856941725_lam4, 1, 2, (V[]){v_a_248, v_a_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam5(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2412 = args[1];
  return heff_perform(v_a_2411, v_a_2412);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam7(V self, V *args) {
  V v_x_2415 = args[0];
  V v_a_2416 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2415);
  V v_t_2419;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_x_2413, 1);
    heff_take_n(v_x_2413, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_a_2416;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_2414 = heff_tag_n(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s364335313x798093277(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_clo_n(g_std_2eprogress_2eshown_24s1929445196x1856941725_lam7, 2, 1, (V[]){v_x_2413})));
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam8(V self, V *args) {
  V v_a_2420 = args[0];
  heff_drop(v_a_2420);
  return NTAG(TAG_MkUnit);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam9(V self, V *args) {
  V v_a_2421 = args[0];
  heff_drop(v_a_2421);
  return NTAG(TAG_MkUnit);
}
V g_std_2eprogress_2eshown_24s1929445196x1856941725_lam1(V self, V *args) {
  V v_a_242 = args[0];
  if ((heff_dup(v_a_242) == NTAG(TAG_True))) {
    heff_drop(v_a_242);
    V v_t_243 = heff_rec_n(2, shape_next__going, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    V v_c_244 = (g_app_2eheff_2emain_2eprogram_24s1014075943x1216828586(heff_dup(heff_rfield(g_std_2eprogress_2edrawing_24s1506381720x1028922836_get(), 0)), v_t_243));
    V f_ = v_c_244;
    heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam2_clo), ((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam3_clo), ((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam5_clo)});
    heff_room[1] = ((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam6_clo);
    heff_room[2] = ((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam8_clo);
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_a_242);
    V f_ = heff_dup(g_app_2eheff_2emain_2eprogram_24s1019515090x1973225267_get());
    args[0] = ((V)&g_std_2eprogress_2eshown_24s1929445196x1856941725_lam9_clo);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}