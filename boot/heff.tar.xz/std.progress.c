// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_IsTerminal 53507
#define TAG_MkKid 64674
#define TAG_MkTask 37714
#define TAG_NoInput 41055
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_fmap 9641981
#define LBL_going 299892244
#define LBL_group 299987609
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_output 941629484
#define LBL_parent 951717845
#define LBL_ret 322331
#define LBL_task 10048076
#define LBL_timeout 1065429926
#define LBL_total 311908190
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_next__going[] = {LBL_next, LBL_going};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_co_2e_3c_2b_3e_24s787064636x102052035_get(void);
V g_co_2eop_24s1932151623x486962575(V, V, V);
V g_co_2eop_24s1932151623x486962575_entry(V self, V *a);
extern Clo g_co_2eop_24s1932151623x486962575_clo;
V g_co_2eop_24s358005445x1922844939(V, V, V, V);
V g_co_2eop_24s358005445x1922844939_entry(V self, V *a);
extern Clo g_co_2eop_24s358005445x1922844939_clo;
V g_list_2ekeepIf_24s2085003797x1793382462(V, V);
V g_list_2ekeepIf_24s2085003797x1793382462_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s2085003797x1793382462_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1832335087x1608171547(V, V, V, V);
V g_list_2emap_24f1832335087x1608171547_entry(V self, V *a);
extern Clo g_list_2emap_24f1832335087x1608171547_clo;
V g_list_2emap_24s2021078391x832341393(V, V, V);
V g_list_2emap_24s2021078391x832341393_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eprogress_2ecountOf(V, V);
V g_std_2eprogress_2ecountOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2ecountOf_clo;
V g_std_2eprogress_2edrawTop(V, V);
V g_std_2eprogress_2edrawTop_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawTop_clo;
V g_std_2eprogress_2edrawUnder(V, V, V);
V g_std_2eprogress_2edrawUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawUnder_clo;
V g_std_2eprogress_2edrawing_24s99689049x1192072418_get(void);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874(V, V);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawnOp_24s1298996847x528338874_clo;
V g_std_2eprogress_2ekidsUnder(V, V, V);
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_clo;
V g_std_2eprogress_2ekidsUnder_24dps(V, V, V, V);
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_24dps_clo;
V g_std_2eprogress_2eparentOf(V, V);
V g_std_2eprogress_2eparentOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2eparentOf_clo;
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2eshown_24s241685406x889772080(V);
V g_std_2eprogress_2eshown_24s241685406x889772080_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s241685406x889772080_clo;

static V g_std_2eprogress_2eroot_val;
static HEFF_ONCE g_std_2eprogress_2eroot_st;
static V g_std_2eprogress_2eroot_init(void) {
  return heff_tag_n(TAG_MkTask, 1, (V[]){MK_INT(0LL)});
}
V g_std_2eprogress_2eroot_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eroot_st)) return g_std_2eprogress_2eroot_val;
  return heff_global(&g_std_2eprogress_2eroot_val, &g_std_2eprogress_2eroot_st, g_std_2eprogress_2eroot_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args);
V g_std_2eprogress_2eprogress_lam2(V self, V *args);
V g_std_2eprogress_2eprogress_lam0(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam0, 3, 0};
V g_std_2eprogress_2eprogress_lam3(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam3, 4, 0};

static V g_std_2eprogress_2eprogress_val;
static HEFF_ONCE g_std_2eprogress_2eprogress_st;
static V g_std_2eprogress_2eprogress_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprogress_2eprogress_lam0_clo), ((V)&g_std_2eprogress_2eprogress_lam3_clo)});
}
V g_std_2eprogress_2eprogress_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eprogress_st)) return g_std_2eprogress_2eprogress_val;
  return heff_global(&g_std_2eprogress_2eprogress_val, &g_std_2eprogress_2eprogress_st, g_std_2eprogress_2eprogress_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args) {
  V v_t_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_t_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_call(v_k_2418, 1, (V[]){v_r_2419}));
  V f_ = v_g_241;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Start: {
    V v_parent_243 = heff_field(v_p_242, 0);
    V v_name_244 = heff_field(v_p_242, 1);
    V v_total_245 = heff_field(v_p_242, 2);
    V v_k_246 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Start, TAG_Start, 4, (V[]){v_parent_243, v_name_244, v_total_245, heff_clo_n(g_std_2eprogress_2eprogress_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Complete: {
    V v_t_249 = heff_field(v_p_242, 0);
    V v_x_2410 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Complete = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
    return heff_tag_at_n(v_ru_24p_242_24Complete, TAG_Complete, 2, (V[]){v_t_249, v_t_2411});
  }
  case TAG_End: {
    V v_t_2412 = heff_field(v_p_242, 0);
    V v_x_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_at_n(v_ru_24p_242_24End, TAG_End, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_RunUnder: {
    V v_t_2415 = heff_field(v_p_242, 0);
    V v_cmd_2416 = heff_field(v_p_242, 1);
    V v_argv_2417 = heff_field(v_p_242, 2);
    V v_k_2418 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24RunUnder = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2415, v_cmd_2416, v_argv_2417, heff_clo_n(g_std_2eprogress_2eprogress_lam2, 1, 2, (V[]){v_k_2418, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprogress_2eprogress_lam3(V self, V *args) {
  V v_m_2421 = args[0];
  V v_n_2422 = args[1];
  V v_nt_2423 = args[2];
  V v_p_2424 = args[3];
  heff_drop(v_m_2421);
  heff_drop(v_n_2422);
  heff_drop(v_nt_2423);
  return v_p_2424;
}
HEFF_LIT(g_std_2eprogress_2ecountOf_str0, 0, "");
HEFF_LIT(g_std_2eprogress_2ecountOf_str1, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str2, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str3, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str4, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str5, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str6, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str7, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str8, 2, "] ");
Clo g_std_2eprogress_2ecountOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ecountOf_entry, 2, 0};

V g_std_2eprogress_2ecountOf(V v_done_240, V v_total_241) {
top: ;
  if (heff_intEq_c_lent(v_done_240, MK_INT(0LL), 2)) {
    if (heff_intEq_c_lent(v_total_241, MK_INT(0LL), 2)) {
      heff_drop(v_done_240);
      heff_drop(v_total_241);
      return ((V)&g_std_2eprogress_2ecountOf_str0);
    } else {
      V v_t_242 = heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str1), heff_intShow(v_done_240));
      V v_t_243 = heff_strAppend(heff_strAppend(v_t_242, ((V)&g_std_2eprogress_2ecountOf_str2)), heff_intShow(v_total_241));
      return heff_strAppend(v_t_243, ((V)&g_std_2eprogress_2ecountOf_str3));
    }
  } else {
    if (heff_intEq_c_lent(v_total_241, MK_INT(0LL), 2)) {
      heff_drop(v_total_241);
      V v_t_244 = heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str4), heff_intShow(v_done_240));
      return heff_strAppend(v_t_244, ((V)&g_std_2eprogress_2ecountOf_str5));
    } else {
      V v_t_245 = heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str6), heff_intShow(v_done_240));
      V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_std_2eprogress_2ecountOf_str7)), heff_intShow(v_total_241));
      return heff_strAppend(v_t_246, ((V)&g_std_2eprogress_2ecountOf_str8));
    }
  }
}
V g_std_2eprogress_2ecountOf_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ecountOf(a[0], a[1]);
}
HEFF_LIT(g_std_2eprogress_2edrawUnder_str0, 7, "\342\224\224\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str1, 7, "\342\224\234\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str2, 3, "   ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str3, 5, "\342\224\202  ");
Clo g_std_2eprogress_2edrawUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawUnder_entry, 3, 0};

V g_std_2eprogress_2edrawUnder(V v_every_240, V v_prefix_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    heff_drop(v_prefix_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_done_245 = heff_take_field(v_t_243, 3);
    V v_total_246 = heff_take_field(v_t_243, 4);
    V v_name_247 = heff_take_field(v_t_243, 2);
    V v_task_248 = heff_get_n(v_t_243, 0, 5);
    V v_t_2411;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_std_2eprogress_2edrawUnder_str0);
      break;
    }
    case TAG_Cons: {
      v_t_2411 = ((V)&g_std_2eprogress_2edrawUnder_str1);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2412 = (g_std_2eprogress_2ecountOf(v_done_245, v_total_246));
    V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_prefix_241), v_t_2411), heff_strAppend(v_t_2412, v_name_247));
    V v_t_2416;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_std_2eprogress_2edrawUnder_str2);
      break;
    }
    case TAG_Cons: {
      v_t_2416 = ((V)&g_std_2eprogress_2edrawUnder_str3);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2417 = (g_list_2ekeepIf_24s2085003797x1793382462(v_task_248, heff_dup(v_every_240)));
    V v_t_2418 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), heff_strAppend(heff_dup(v_prefix_241), v_t_2416), v_t_2417));
    V v_t_2419 = (g_std_2eprogress_2edrawUnder(v_every_240, v_prefix_241, v_rest_244));
    V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2413, v_t_2420});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2edrawUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawUnder(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eprogress_2edrawTop_str0, 0, "");
Clo g_std_2eprogress_2edrawTop_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawTop_entry, 2, 0};

V g_std_2eprogress_2edrawTop(V v_every_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_done_244 = heff_take_field(v_t_242, 3);
    V v_total_245 = heff_take_field(v_t_242, 4);
    V v_name_246 = heff_take_field(v_t_242, 2);
    V v_task_247 = heff_get_n(v_t_242, 0, 5);
    V v_t_248 = (g_std_2eprogress_2ecountOf(v_done_244, v_total_245));
    V v_t_249 = (g_list_2ekeepIf_24s2085003797x1793382462(v_task_247, heff_dup(v_every_240)));
    V v_t_2410 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), ((V)&g_std_2eprogress_2edrawTop_str0), v_t_249));
    V v_t_2411 = (g_std_2eprogress_2edrawTop(v_every_240, v_rest_243));
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_248, v_name_246), v_t_2412});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawTop_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawTop(a[0], a[1]);
}
Clo g_std_2eprogress_2ekidsUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_entry, 3, 0};

V g_std_2eprogress_2ekidsUnder(V v_t_240, V v_box_24i_241, V v_x3_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkKid: {
      V v_name_245 = heff_field(v_x31_243, 0);
      V v_done_246 = heff_field(v_x31_243, 1);
      V v_total_247 = heff_field(v_x31_243, 2);
      V v_parent_248 = heff_field(v_x31_243, 3);
      heff_take_n(v_x31_243, 15ULL, 4);
      V v_t_249;
      if ((v_i_241 == ((int64_t)0ULL))) {
        v_t_249 = heff_dup(v_t_240);
      } else {
        if ((v_i_241 == ((int64_t)255ULL))) {
          v_t_249 = heff_dup(v_t_240);
        } else {
          v_t_249 = heff_box_word((((int64_t)-1ULL) - v_i_241));
        }
      }
      V v_t_2410;
      if (heff_intEq_c_lent(v_parent_248, MK_INT(0LL), 2)) {
        heff_drop(v_parent_248);
        v_t_2410 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_parent_248, MK_INT(255LL), 2)) {
          heff_drop(v_parent_248);
          v_t_2410 = heff_dup(v_t_240);
        } else {
          v_t_2410 = heff_intSub(MK_INT(-1LL), v_parent_248);
        }
      }
      V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_249, v_t_2410, v_name_245, v_done_246, v_total_247}), heff_hole()});
      V v_u_2412 = (g_std_2eprogress_2ekidsUnder_24dps(v_t_240, heff_box_word((v_i_241 + ((int64_t)1ULL))), v_rest_244, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder(a[0], a[1], a[2]);
}
Clo g_std_2eprogress_2ekidsUnder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_24dps_entry, 4, 0};

V g_std_2eprogress_2ekidsUnder_24dps(V v_t_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkKid: {
      V v_name_246 = heff_field(v_x31_244, 0);
      V v_done_247 = heff_field(v_x31_244, 1);
      V v_total_248 = heff_field(v_x31_244, 2);
      V v_parent_249 = heff_field(v_x31_244, 3);
      heff_take_n(v_x31_244, 15ULL, 4);
      V v_t_2410;
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        v_t_2410 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_i_241, MK_INT(255LL), 2)) {
          v_t_2410 = heff_dup(v_t_240);
        } else {
          v_t_2410 = heff_intSub(MK_INT(-1LL), heff_dup(v_i_241));
        }
      }
      V v_t_2411;
      if (heff_intEq_c_lent(v_parent_249, MK_INT(0LL), 2)) {
        heff_drop(v_parent_249);
        v_t_2411 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_parent_249, MK_INT(255LL), 2)) {
          heff_drop(v_parent_249);
          v_t_2411 = heff_dup(v_t_240);
        } else {
          v_t_2411 = heff_intSub(MK_INT(-1LL), v_parent_249);
        }
      }
      V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_2410, v_t_2411, v_name_246, v_done_247, v_total_248}), heff_hole()});
      V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_t_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_rest_245;
      V t_3 = v_cell_2412;
      v_t_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_std_2eprogress_2eparentOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eparentOf_entry, 2, 0};

V g_std_2eprogress_2eparentOf(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_task_244 = heff_dup(heff_rfield(v_t_242, 0));
    V v_parent_245 = heff_dup(heff_rfield(v_t_242, 1));
    if (heff_intEq_c_lent(v_task_244, v_i_240, 1)) {
      heff_drop(v_i_240);
      return v_parent_245;
    } else {
      heff_drop(v_parent_245);
      V t_0 = v_i_240;
      V t_1 = v_rest_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2eparentOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eprogress_2eparentOf(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_str0, 0, "");
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam1(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam0(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam3(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam2(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam5(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam4(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam8(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam7(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9(V self, V *args); static Clo g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9, 1, 0};
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam11(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam10(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam6(V self, V *args);
Clo g_std_2eprogress_2edrawnOp_24s1298996847x528338874_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1298996847x528338874_entry, 2, 0};

V g_std_2eprogress_2edrawnOp_24s1298996847x528338874(V v_ts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Start: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_name_243 = heff_field(v_x2_241, 1);
    V v_total_244 = heff_field(v_x2_241, 2);
    V v_k_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkTask: {
      V v_p_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24MkTask = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_ts_240, 0)), MK_INT(1LL));
      V v_t_248 = heff_rec_n(5, shape_task__parent__name__done__total, (V[]){heff_dup(heff_rfield(v_ts_240, 0)), v_p_246, v_name_243, MK_INT(0LL), v_total_244});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_ts_240, 1), v_t_249));
      V v_ts_2411 = heff_rec_n(2, shape_next__going, (V[]){v_t_247, v_t_2410});
      V v_t_2412 = heff_tag_at_n(v_ru_24x21_242_24MkTask, TAG_MkTask, 1, (V[]){heff_get_n(v_ts_240, 0, 2)});
      V v_x_2413 = heff_tr(heff_call(v_k_245, 1, (V[]){v_t_2412}));
      V v_ts_2414 = heff_dup(heff_rfield(v_ts_2411, 1));
      V v_t_2415 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2414)));
      V v_ls_2416 = (g_std_2eprogress_2edrawTop(v_ts_2414, v_t_2415));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam0, 2, 3, (V[]){v_ls_2416, v_ts_2411, v_x_2413});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_Complete: {
    V v_x21_2427 = heff_field(v_x2_241, 0);
    V v_x_2428 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_MkTask: {
      V v_i_2429 = heff_field(v_x21_2427, 0);
      heff_take_n(v_x21_2427, 1ULL, 1);
      V v_t_2430 = (g_list_2emap_24s2021078391x832341393(v_i_2429, MK_INT(1LL), heff_take_field(v_ts_240, 1)));
      V v_ts_2431 = ({ V rv_1 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2432 = heff_dup(heff_rfield(v_ts_2431, 1));
      V v_t_2433 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2432)));
      V v_ls_2434 = (g_std_2eprogress_2edrawTop(v_ts_2432, v_t_2433));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam2, 2, 3, (V[]){v_ls_2434, v_ts_2431, v_x_2428});
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  case TAG_End: {
    V v_x21_2445 = heff_field(v_x2_241, 0);
    V v_x_2446 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2445)) {
    case TAG_MkTask: {
      V v_i_2447 = heff_field(v_x21_2445, 0);
      heff_take_n(v_x21_2445, 1ULL, 1);
      V v_i_2448 = (g_std_2eprogress_2eparentOf(heff_dup(v_i_2447), heff_rfield(v_ts_240, 1)));
      V v_t_2449 = (g_list_2emap_24f1832335087x1608171547(v_i_2448, MK_INT(1LL), v_i_2447, heff_take_field(v_ts_240, 1)));
      V v_ts_2450 = ({ V rv_1 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2451 = heff_dup(heff_rfield(v_ts_2450, 1));
      V v_t_2452 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2451)));
      V v_ls_2453 = (g_std_2eprogress_2edrawTop(v_ts_2451, v_t_2452));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam4, 2, 3, (V[]){v_ls_2453, v_ts_2450, v_x_2446});
    }
    default: return heff_nomatch(v_x21_2445);
    }
  }
  case TAG_RunUnder: {
    V v_x21_2464 = heff_field(v_x2_241, 0);
    V v_cmd_2465 = heff_field(v_x2_241, 1);
    V v_argv_2466 = heff_field(v_x2_241, 2);
    V v_k_2467 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_2464)) {
    case TAG_MkTask: {
      V v_i_2468 = heff_field(v_x21_2464, 0);
      heff_take_n(v_x21_2464, 1ULL, 1);
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam6, 2, 5, (V[]){v_cmd_2465, v_argv_2466, v_ts_240, v_i_2468, v_k_2467});
    }
    default: return heff_nomatch(v_x21_2464);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawnOp_24s1298996847x528338874(a[0], a[1]);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_ls_2416 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2419 = heff_take_field(v_hd_2417, 1);
  V v_malg_2420 = heff_get_n(v_hd_2417, 2, 3);
  V v_t_2421 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2416, NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(v_malg_2420, 1, (V[]){v_t_2424}));
  V f_ = v_bind_2419;
  args[0] = v_t_2425;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam1, 1, 3, (V[]){v_k_2418, v_ts_2411, v_x_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam3(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_ts_2431 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2444);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2431, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_ls_2434 = heff_env(self)[0];
  V v_ts_2431 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2437 = heff_take_field(v_hd_2435, 1);
  V v_malg_2438 = heff_get_n(v_hd_2435, 2, 3);
  V v_t_2439 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2434, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tr(heff_call(v_malg_2438, 1, (V[]){v_t_2442}));
  V f_ = v_bind_2437;
  args[0] = v_t_2443;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam3, 1, 3, (V[]){v_k_2436, v_ts_2431, v_x_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam5(V self, V *args) {
  V v_x_2463 = args[0];
  V v_k_2455 = heff_env(self)[0];
  V v_ts_2450 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2463);
  V f_ = v_k_2455;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2450, v_x_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam4(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_ls_2453 = heff_env(self)[0];
  V v_ts_2450 = heff_env(self)[1];
  V v_x_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2456 = heff_take_field(v_hd_2454, 1);
  V v_malg_2457 = heff_get_n(v_hd_2454, 2, 3);
  V v_t_2458 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2453, NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(v_malg_2457, 1, (V[]){v_t_2461}));
  V f_ = v_bind_2456;
  args[0] = v_t_2462;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam5, 1, 3, (V[]){v_k_2455, v_ts_2450, v_x_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam8(V self, V *args) {
  V v_s_2477 = args[0];
  V v_i_2468 = heff_env(self)[0];
  V v_r_2475 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2478 = v_i_2468;
  V v_x2_2479 = v_r_2475;
  V v_s_2480 = v_s_2477;
  switch (heff_tag_of(v_x2_2479)) {
  case TAG_MkKid: {
    V v_name_2481 = heff_field(v_x2_2479, 0);
    V v_done_2482 = heff_field(v_x2_2479, 1);
    V v_total_2483 = heff_field(v_x2_2479, 2);
    heff_take_n(v_x2_2479, 7ULL, 4);
    if (heff_intEq_c(heff_dup(heff_rfield(v_s_2480, 0)), v_t_2478)) {
      V v_t_2485;
      if (heff_strEq_c_lent(v_name_2481, ((V)&g_std_2eprogress_2edrawnOp_24s1298996847x528338874_str0), 2)) {
        heff_drop(v_name_2481);
        v_t_2485 = heff_dup(heff_rfield(v_s_2480, 2));
      } else {
        v_t_2485 = v_name_2481;
      }
      V v_t_2487;
      if ((heff_intEq_c_lent(v_total_2483, MK_INT(0LL), 2) && heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_2480, 4))))) {
        V v_y_2486 = heff_dup(heff_rfield(v_s_2480, 4));
        if (heff_intLe_c_lent(v_done_2482, v_y_2486, 0)) {
          heff_drop(v_y_2486);
          v_t_2487 = v_done_2482;
        } else {
          heff_drop(v_done_2482);
          v_t_2487 = v_y_2486;
        }
      } else {
        v_t_2487 = v_done_2482;
      }
      V v_t_2488;
      if (heff_intEq_c_lent(v_total_2483, MK_INT(0LL), 2)) {
        heff_drop(v_total_2483);
        v_t_2488 = heff_dup(heff_rfield(v_s_2480, 4));
      } else {
        v_t_2488 = v_total_2483;
      }
      return ({ V rv_2 = v_t_2485; V rv_3 = v_t_2487; V rv_4 = v_t_2488; V rr_ = heff_rec_reuse_nf(v_s_2480, 3ULL, 5, shape_task__parent__name__done__total, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      heff_drop(v_name_2481);
      heff_drop(v_done_2482);
      heff_drop(v_total_2483);
      return v_s_2480;
    }
  }
  default: return heff_nomatch(v_x2_2479);
  }
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam7(V self, V *args) {
  V v_kids_2473 = args[0];
  V v_ts_240 = heff_env(self)[0];
  V v_i_2468 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ts_2474 = heff_get_n(v_ts_240, 1, 2);
  V v_ts_2491;
  switch (heff_tag_of(v_kids_2473)) {
  case TAG_Nil: {
    heff_drop(v_i_2468);
    v_ts_2491 = v_ts_2474;
    break;
  }
  case TAG_Cons: {
    V v_r_2475 = heff_field(v_kids_2473, 0);
    V v_kids_2476 = heff_field(v_kids_2473, 1);
    V v_ru_24kids_2473_24Cons = heff_take_reuse_n(v_kids_2473, 3ULL, 2);
    V v_t_2489 = (g_list_2emap_24tok2(v_ru_24kids_2473_24Cons, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam8, 1, 2, (V[]){heff_dup(v_i_2468), v_r_2475}), v_ts_2474));
    V v_t_2490 = (g_std_2eprogress_2ekidsUnder(v_i_2468, MK_INT(1LL), v_kids_2476));
    v_ts_2491 = (g_prelude_2e_2b_2b(v_t_2489, v_t_2490));
    break;
  }
  default: heff_nomatch(v_kids_2473);
  }
  V v_t_2492 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_2491)));
  return (g_std_2eprogress_2edrawTop(v_ts_2491, v_t_2492));
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9(V self, V *args) {
  V v_r_2493 = args[0];
  return v_r_2493;
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam11(V self, V *args) {
  V v_x_24108 = args[0];
  V v_k_2470 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_x_2499 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24108);
  V f_ = v_k_2470;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_240, v_x_2499});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam10(V self, V *args) {
  V v_x_2498 = args[0];
  V v_k_2467 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_malg_2472 = heff_env(self)[2];
  V v_bind_2471 = heff_env(self)[3];
  V v_k_2470 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2499 = heff_tr(heff_call(v_k_2467, 1, (V[]){v_x_2498}));
  V v_ts_24100 = heff_dup(heff_rfield(v_ts_240, 1));
  V v_t_24101 = (g_list_2ekeepIf_24s2085003797x1793382462(MK_INT(0LL), heff_dup(v_ts_24100)));
  V v_ls_24102 = (g_std_2eprogress_2edrawTop(v_ts_24100, v_t_24101));
  V v_t_24103 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_24102, NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tr(heff_call(v_malg_2472, 1, (V[]){v_t_24106}));
  V f_ = v_bind_2471;
  heff_room[0] = v_t_24107;
  heff_room[1] = heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam11, 1, 3, (V[]){v_k_2470, v_ts_240, v_x_2499});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam6(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_cmd_2465 = heff_env(self)[0];
  V v_argv_2466 = heff_env(self)[1];
  V v_ts_240 = heff_env(self)[2];
  V v_i_2468 = heff_env(self)[3];
  V v_k_2467 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_bind_2471 = heff_take_field(v_hd_2469, 1);
  V v_malg_2472 = heff_get_n(v_hd_2469, 2, 3);
  V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ShowRun, 4, (V[]){v_cmd_2465, v_argv_2466, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam7, 1, 2, (V[]){heff_dup(v_ts_240), v_i_2468}), ((V)&g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9_clo)})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tr(heff_call(heff_dup(v_malg_2472), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})}));
  V f_ = heff_dup(v_bind_2471);
  args[0] = v_t_2497;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam10, 1, 5, (V[]){v_k_2467, v_ts_240, v_malg_2472, v_bind_2471, v_k_2470});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0, 4, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam3(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam2(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1, 3, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam7(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam6(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5, 3, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam9(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8, 4, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam12(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam11(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam10(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam13(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4, 2, 0};

static V g_std_2eprogress_2edrawing_24s99689049x1192072418_val;
static HEFF_ONCE g_std_2eprogress_2edrawing_24s99689049x1192072418_st;
static V g_std_2eprogress_2edrawing_24s99689049x1192072418_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0_clo), ((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1_clo), ((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4_clo)});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2edrawing_24s99689049x1192072418_st)) return g_std_2eprogress_2edrawing_24s99689049x1192072418_val;
  return heff_global(&g_std_2eprogress_2edrawing_24s99689049x1192072418_val, &g_std_2eprogress_2edrawing_24s99689049x1192072418_st, g_std_2eprogress_2edrawing_24s99689049x1192072418_init);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_ts_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_241, v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_dup(heff_field(v_x_2410, 1));
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_245;
  heff_room[0] = v_t_2413;
  heff_room[1] = v_t_2416;
  heff_room[2] = v_hd_248;
  heff_room[3] = v_k_249;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam3, 1, 3, (V[]){v_k_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_ts_246 = args[2];
  V v_c_247 = heff_tr(heff_call(v_m_244, 1, (V[]){v_ts_246}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam2, 2, 2, (V[]){v_c_247, v_k_245});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_dup(heff_field(v_x_2428, 0));
    v_t_2431 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2434;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_y_2433 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 2ULL, 2);
    v_t_2434 = v_y_2433;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2435 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_t_2434}));
  V v_x_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, v_t_2435});
  V f_ = v_k_2427;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_g_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam7, 1, 2, (V[]){v_g_2422, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_ts_2424 = args[2];
  V v_c_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_ts_2424}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam6, 2, 2, (V[]){v_c_2425, v_g_2422});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_2437 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2442 = heff_tr(heff_call(v_g_2437, 1, (V[]){v_x_2441}));
  V f_ = v_k_2440;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8(V self, V *args) {
  V v_g_2437 = args[0];
  V v_c_2438 = args[1];
  V v_hd_2439 = args[2];
  V v_k_2440 = args[3];
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam9, 1, 2, (V[]){v_g_2437, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam12(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_y_2449 = heff_field(v_x_2447, 1);
    heff_take_n(v_x_2447, 2ULL, 2);
    v_t_2450 = v_y_2449;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V f_ = v_k_2446;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam11(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam12, 1, 1, (V[]){v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam10(V self, V *args) {
  V v_c_2443 = args[0];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2444 = heff_tr(heff_call(v_c_2443, 1, (V[]){v_ts_2418}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam11, 2, 1, (V[]){v_c_2444});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam13(V self, V *args) {
  V v_x_2454 = args[0];
  V v_hd_2455 = args[1];
  V v_k_2456 = args[2];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2418, v_x_2454});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4(V self, V *args) {
  V v_p_2417 = args[0];
  V v_ts_2418 = args[1];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_o_2419 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 1);
    return (g_std_2eprogress_2edrawnOp_24s1298996847x528338874(v_ts_2418, v_o_2419));
  }
  case TAG_InR: {
    V v_q_2420 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2453;
    switch (heff_tag_of(v_q_2420)) {
    case TAG_InL: {
      V v_x_2421 = heff_field(v_q_2420, 0);
      V v_ru_24q_2420_24InL = heff_take_reuse_n(v_q_2420, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8_clo)}), heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam10, 1, 1, (V[]){heff_dup(v_ts_2418)}), v_x_2421}));
      v_t_2453 = heff_tag_at_n(v_ru_24q_2420_24InL, TAG_InL, 1, (V[]){v_t_2451});
      break;
    }
    case TAG_InR: {
      V v_y_2452 = heff_field(v_q_2420, 0);
      heff_take_n(v_q_2420, 1ULL, 1);
      v_t_2453 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_y_2452});
      break;
    }
    default: heff_nomatch(v_q_2420);
    }
    V f_ = ((V)&g_co_2eop_24s358005445x1922844939_clo);
    args[0] = v_t_2453;
    args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam13, 3, 1, (V[]){v_ts_2418});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_p_2417);
  }
}
HEFF_LIT(g_std_2eprogress_2eshown_24s241685406x889772080_str0, 0, "");
V g_std_2eprogress_2eshown_24s241685406x889772080_lam0(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam0, 1, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam2(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam2_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam2, 4, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam3(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam3, 2, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam5(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam4(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam4, 3, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam6(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam6_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam6, 2, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam8(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam7(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam7, 2, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam9(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam9, 1, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam10(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam10_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam10, 3, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam12(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam11(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam11_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam11, 4, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam14(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam15(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam16(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam18(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam18_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam18, 1, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam19(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam17(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam13(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam13_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam13, 1, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam20(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam20_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam20, 3, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam21(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam21_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam21, 2, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam23(V self, V *args);
V g_std_2eprogress_2eshown_24s241685406x889772080_lam22(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam22_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam22, 3, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam24(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam24_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam24, 2, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam25(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam25_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam25, 2, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam26(V self, V *args); static Clo g_std_2eprogress_2eshown_24s241685406x889772080_lam26_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_lam26, 1, 0};
V g_std_2eprogress_2eshown_24s241685406x889772080_lam1(V self, V *args);
Clo g_std_2eprogress_2eshown_24s241685406x889772080_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s241685406x889772080_entry, 1, 0};

V g_std_2eprogress_2eshown_24s241685406x889772080(V v_c_240) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_IsTerminal, 1, (V[]){((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam0_clo)})});
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_242})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  return heff_perform(heff_tag_n(TAG_InL, 1, (V[]){v_t_244}), heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam1, 1, 1, (V[]){v_c_240}));
}
V g_std_2eprogress_2eshown_24s241685406x889772080_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2eshown_24s241685406x889772080(a[0]);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam0(V self, V *args) {
  V v_b_241 = args[0];
  return v_b_241;
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_ts_248 = args[1];
  V v_hd_249 = args[2];
  V v_k_2410 = args[3];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_248, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2412 = args[1];
  V f_ = v_a_2412;
  args[0] = v_a_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam5(V self, V *args) {
  V v_a_2416 = args[0];
  V v_a_2414 = heff_env(self)[0];
  V v_a_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2414;
  heff_room[0] = v_a_2416;
  heff_room[1] = v_a_2415;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam4(V self, V *args) {
  V v_a_2413 = args[0];
  V v_a_2414 = args[1];
  V v_a_2415 = args[2];
  V f_ = v_a_2413;
  args[0] = heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam5, 1, 2, (V[]){v_a_2414, v_a_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam6(V self, V *args) {
  V v_a_2417 = args[0];
  V v_a_2418 = args[1];
  return heff_perform(v_a_2417, v_a_2418);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam8(V self, V *args) {
  V v_a_2425 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_a_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_a_2425);
  V v_t_2428;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_MkPair: {
    V v_y_2427 = heff_field(v_x_2419, 1);
    heff_take_n(v_x_2419, 2ULL, 2);
    v_t_2428 = v_y_2427;
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V f_ = v_a_2420;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_a_2420 = args[1];
  V v_t_2421 = heff_tag_n(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return heff_perform(v_t_2424, heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam8, 1, 2, (V[]){v_x_2419, v_a_2420}));
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam9(V self, V *args) {
  V v_a_2429 = args[0];
  heff_drop(v_a_2429);
  return NTAG(TAG_MkUnit);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam10(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam12(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_hd_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2434;
  heff_room[0] = v_x_2437;
  heff_room[1] = v_hd_2435;
  heff_room[2] = v_k_2436;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam11(V self, V *args) {
  V v_m_2433 = args[0];
  V v_k_2434 = args[1];
  V v_hd_2435 = args[2];
  V v_k_2436 = args[3];
  V f_ = v_m_2433;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam12, 1, 3, (V[]){v_k_2434, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam14(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  V v_x_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = v_x_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam15(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam16(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_x_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2454);
  V f_ = v_k_2455;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam18(V self, V *args) {
  V v_r_2465 = args[0];
  return v_r_2465;
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam19(V self, V *args) {
  V v_x_2472 = args[0];
  V v_k_2459 = heff_env(self)[0];
  V v_k_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2473 = heff_tr(heff_call(v_k_2459, 1, (V[]){v_x_2472}));
  V f_ = v_k_2461;
  args[0] = v_x_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam17(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_cmd_2457 = heff_env(self)[0];
  V v_argv_2458 = heff_env(self)[1];
  V v_k_2459 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_bind_2462 = heff_take_field(v_hd_2460, 1);
  V v_malg_2463 = heff_get_n(v_hd_2460, 2, 3);
  V v_t_2464 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_cmd_2457, v_argv_2458, ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_str0), NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 2, (V[]){v_t_2464, ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam18_clo)})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(v_malg_2463, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})}));
  V f_ = v_bind_2462;
  args[0] = v_t_2471;
  args[1] = heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam19, 1, 2, (V[]){v_k_2459, v_k_2461});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam13(V self, V *args) {
  V v_p_2438 = args[0];
  switch (heff_tag_of(v_p_2438)) {
  case TAG_InL: {
    V v_t_2439 = heff_field(v_p_2438, 0);
    heff_take_n(v_p_2438, 1ULL, 1);
    V v_x1_2440 = v_t_2439;
    switch (heff_tag_of(v_x1_2440)) {
    case TAG_Start: {
      V v_k_2444 = heff_field(v_x1_2440, 3);
      heff_take_n(v_x1_2440, 8ULL, 4);
      V v_x_2445 = heff_tr(heff_call(v_k_2444, 1, (V[]){heff_dup(g_std_2eprogress_2eroot_get())}));
      return heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam14, 2, 1, (V[]){v_x_2445});
    }
    case TAG_Complete: {
      V v_x_2449 = heff_field(v_x1_2440, 1);
      heff_take_n(v_x1_2440, 2ULL, 2);
      return heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam15, 2, 1, (V[]){v_x_2449});
    }
    case TAG_End: {
      V v_x_2453 = heff_field(v_x1_2440, 1);
      heff_take_n(v_x1_2440, 2ULL, 2);
      return heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam16, 2, 1, (V[]){v_x_2453});
    }
    case TAG_RunUnder: {
      V v_cmd_2457 = heff_field(v_x1_2440, 1);
      V v_argv_2458 = heff_field(v_x1_2440, 2);
      V v_k_2459 = heff_field(v_x1_2440, 3);
      heff_take_n(v_x1_2440, 14ULL, 4);
      return heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam17, 2, 3, (V[]){v_cmd_2457, v_argv_2458, v_k_2459});
    }
    default: return heff_nomatch(v_x1_2440);
    }
  }
  case TAG_InR: {
    V v_q_2474 = heff_field(v_p_2438, 0);
    heff_take_n(v_p_2438, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s1932151623x486962575_clo);
    args[0] = v_q_2474;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_2438);
  }
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam20(V self, V *args) {
  V v_x_2475 = args[0];
  V v_hd_2476 = args[1];
  V v_k_2477 = args[2];
  heff_drop(v_hd_2476);
  V f_ = v_k_2477;
  args[0] = v_x_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam21(V self, V *args) {
  V v_a_2478 = args[0];
  V v_a_2479 = args[1];
  V f_ = v_a_2479;
  args[0] = v_a_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam23(V self, V *args) {
  V v_a_2483 = args[0];
  V v_a_2481 = heff_env(self)[0];
  V v_a_2482 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_a_2481;
  heff_room[0] = v_a_2483;
  heff_room[1] = v_a_2482;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam22(V self, V *args) {
  V v_a_2480 = args[0];
  V v_a_2481 = args[1];
  V v_a_2482 = args[2];
  V f_ = v_a_2480;
  args[0] = heff_clo_n(g_std_2eprogress_2eshown_24s241685406x889772080_lam23, 1, 2, (V[]){v_a_2481, v_a_2482});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam24(V self, V *args) {
  V v_a_2484 = args[0];
  V v_a_2485 = args[1];
  return heff_perform(v_a_2484, v_a_2485);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam25(V self, V *args) {
  V v_a_2486 = args[0];
  V v_a_2487 = args[1];
  V f_ = v_a_2487;
  args[0] = v_a_2486;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam26(V self, V *args) {
  V v_a_2488 = args[0];
  heff_drop(v_a_2488);
  return NTAG(TAG_MkUnit);
}
V g_std_2eprogress_2eshown_24s241685406x889772080_lam1(V self, V *args) {
  V v_a_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if ((heff_dup(v_a_245) == NTAG(TAG_True))) {
    heff_drop(v_a_245);
    V v_t_246 = heff_rec_n(2, shape_next__going, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    return heff_tail(v_c_240, 6, (V[]){heff_dup(g_std_2eprogress_2edrawing_24s99689049x1192072418_get()), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam2_clo), v_t_246, heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam3_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam4_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam6_clo)}), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam7_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam9_clo)});
  } else {
    heff_drop(v_a_245);
    return heff_tail(v_c_240, 5, (V[]){heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam10_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam11_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam13_clo)}), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam20_clo), heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam21_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam22_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam24_clo)}), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam25_clo), ((V)&g_std_2eprogress_2eshown_24s241685406x889772080_lam26_clo)});
  }
}