// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_IsTerminal 53507
#define TAG_MkKid 64674
#define TAG_MkTask 37714
#define TAG_NoInput 41055
#define TAG_Run 29975
#define TAG_RunUnder 28888
#define TAG_Send 26077
#define TAG_ShowLines 37640
#define TAG_ShowRun 62232
#define TAG_Start 63542
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_fmap 9641981
#define LBL_going 299892244
#define LBL_group 299987609
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_output 941629484
#define LBL_parent 951717845
#define LBL_ret 322331
#define LBL_task 10048076
#define LBL_timeout 1065429926
#define LBL_total 311908190
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_fmap[] = {LBL_fmap};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
static uint32_t shape_next__going[] = {LBL_next, LBL_going};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
V g_co_2e_3c_2b_3e_24s787064636x102052035_get(void);
V g_co_2eop_24s1932151623x486962575(V, V, V);
V g_co_2eop_24s1932151623x486962575_entry(V self, V *a);
extern Clo g_co_2eop_24s1932151623x486962575_clo;
V g_co_2eop_24s358005445x1922844939(V, V, V, V);
V g_co_2eop_24s358005445x1922844939_entry(V self, V *a);
extern Clo g_co_2eop_24s358005445x1922844939_clo;
V g_co_2eop_24s448066416x262457974(V, V, V);
V g_co_2eop_24s448066416x262457974_entry(V self, V *a);
extern Clo g_co_2eop_24s448066416x262457974_clo;
V g_list_2ekeepIf_24s404882566x1805760949(V, V);
V g_list_2ekeepIf_24s404882566x1805760949_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s404882566x1805760949_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f273747616x929587227(V, V, V, V);
V g_list_2emap_24f273747616x929587227_entry(V self, V *a);
extern Clo g_list_2emap_24f273747616x929587227_clo;
V g_list_2emap_24s1661513421x830177447(V, V, V);
V g_list_2emap_24s1661513421x830177447_entry(V self, V *a);
extern Clo g_list_2emap_24s1661513421x830177447_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprogress_2ecountOf(V, V);
V g_std_2eprogress_2ecountOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2ecountOf_clo;
V g_std_2eprogress_2edrawTop(V, V);
V g_std_2eprogress_2edrawTop_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawTop_clo;
V g_std_2eprogress_2edrawUnder(V, V, V);
V g_std_2eprogress_2edrawUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawUnder_clo;
V g_std_2eprogress_2edrawing_24s99689049x1192072418_get(void);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874(V, V);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_entry(V self, V *a);
extern Clo g_std_2eprogress_2edrawnOp_24s1298996847x528338874_clo;
V g_std_2eprogress_2ekidsUnder(V, V, V);
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_clo;
V g_std_2eprogress_2ekidsUnder_24dps(V, V, V, V);
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a);
extern Clo g_std_2eprogress_2ekidsUnder_24dps_clo;
V g_std_2eprogress_2eparentOf(V, V);
V g_std_2eprogress_2eparentOf_entry(V self, V *a);
extern Clo g_std_2eprogress_2eparentOf_clo;
V g_std_2eprogress_2eprogress_get(void);
V g_std_2eprogress_2equietly_24s1658224449x1316783431(V);
V g_std_2eprogress_2equietly_24s1658224449x1316783431_entry(V self, V *a);
extern Clo g_std_2eprogress_2equietly_24s1658224449x1316783431_clo;
V g_std_2eprogress_2eroot_get(void);
V g_std_2eprogress_2erooted(V, V, V);
V g_std_2eprogress_2erooted_entry(V self, V *a);
extern Clo g_std_2eprogress_2erooted_clo;
V g_std_2eprogress_2eshown_24s1775398343x1420570306(V, V, V, V);
V g_std_2eprogress_2eshown_24s1775398343x1420570306_entry(V self, V *a);
extern Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_clo;

static V g_std_2eprogress_2eroot_val;
static HEFF_ONCE g_std_2eprogress_2eroot_st;
static V g_std_2eprogress_2eroot_init(void) {
  return heff_tag_n(TAG_MkTask, 1, (V[]){MK_INT(0LL)});
}
V g_std_2eprogress_2eroot_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eroot_st)) return g_std_2eprogress_2eroot_val;
  return heff_global(&g_std_2eprogress_2eroot_val, &g_std_2eprogress_2eroot_st, g_std_2eprogress_2eroot_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args);
V g_std_2eprogress_2eprogress_lam2(V self, V *args);
V g_std_2eprogress_2eprogress_lam0(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam0, 3, 0};
V g_std_2eprogress_2eprogress_lam3(V self, V *args); static Clo g_std_2eprogress_2eprogress_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eprogress_lam3, 4, 0};

static V g_std_2eprogress_2eprogress_val;
static HEFF_ONCE g_std_2eprogress_2eprogress_st;
static V g_std_2eprogress_2eprogress_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprogress_2eprogress_lam0_clo), ((V)&g_std_2eprogress_2eprogress_lam3_clo)});
}
V g_std_2eprogress_2eprogress_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2eprogress_st)) return g_std_2eprogress_2eprogress_val;
  return heff_global(&g_std_2eprogress_2eprogress_val, &g_std_2eprogress_2eprogress_st, g_std_2eprogress_2eprogress_init);
}
V g_std_2eprogress_2eprogress_lam1(V self, V *args) {
  V v_t_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_248 = heff_tr(heff_call(v_k_246, 1, (V[]){v_t_247}));
  V f_ = v_g_241;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam2(V self, V *args) {
  V v_r_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tr(heff_call(v_k_2418, 1, (V[]){v_r_2419}));
  V f_ = v_g_241;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eprogress_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Start: {
    V v_parent_243 = heff_field(v_p_242, 0);
    V v_name_244 = heff_field(v_p_242, 1);
    V v_total_245 = heff_field(v_p_242, 2);
    V v_k_246 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24Start, TAG_Start, 4, (V[]){v_parent_243, v_name_244, v_total_245, heff_clo_n(g_std_2eprogress_2eprogress_lam1, 1, 2, (V[]){v_k_246, v_g_241})});
  }
  case TAG_Complete: {
    V v_t_249 = heff_field(v_p_242, 0);
    V v_x_2410 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Complete = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2410}));
    return heff_tag_at_n(v_ru_24p_242_24Complete, TAG_Complete, 2, (V[]){v_t_249, v_t_2411});
  }
  case TAG_End: {
    V v_t_2412 = heff_field(v_p_242, 0);
    V v_x_2413 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24End = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2414 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2413}));
    return heff_tag_at_n(v_ru_24p_242_24End, TAG_End, 2, (V[]){v_t_2412, v_t_2414});
  }
  case TAG_RunUnder: {
    V v_t_2415 = heff_field(v_p_242, 0);
    V v_cmd_2416 = heff_field(v_p_242, 1);
    V v_argv_2417 = heff_field(v_p_242, 2);
    V v_k_2418 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24RunUnder = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2415, v_cmd_2416, v_argv_2417, heff_clo_n(g_std_2eprogress_2eprogress_lam2, 1, 2, (V[]){v_k_2418, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprogress_2eprogress_lam3(V self, V *args) {
  V v_m_2421 = args[0];
  V v_n_2422 = args[1];
  V v_nt_2423 = args[2];
  V v_p_2424 = args[3];
  heff_drop(v_m_2421);
  heff_drop(v_n_2422);
  heff_drop(v_nt_2423);
  switch (heff_tag_of(v_p_2424)) {
  case TAG_Start: {
    V v_parent_2425 = heff_field(v_p_2424, 0);
    V v_name_2426 = heff_field(v_p_2424, 1);
    V v_total_2427 = heff_field(v_p_2424, 2);
    V v_k_2428 = heff_field(v_p_2424, 3);
    V v_ru_24p_2424_24Start = heff_take_reuse_n(v_p_2424, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2424_24Start, TAG_Start, 4, (V[]){v_parent_2425, v_name_2426, v_total_2427, v_k_2428});
  }
  case TAG_Complete: {
    V v_t_2429 = heff_field(v_p_2424, 0);
    V v_x_2430 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24Complete = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2424_24Complete, TAG_Complete, 2, (V[]){v_t_2429, v_x_2430});
  }
  case TAG_End: {
    V v_t_2431 = heff_field(v_p_2424, 0);
    V v_x_2432 = heff_field(v_p_2424, 1);
    V v_ru_24p_2424_24End = heff_take_reuse_n(v_p_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2424_24End, TAG_End, 2, (V[]){v_t_2431, v_x_2432});
  }
  case TAG_RunUnder: {
    V v_t_2433 = heff_field(v_p_2424, 0);
    V v_cmd_2434 = heff_field(v_p_2424, 1);
    V v_argv_2435 = heff_field(v_p_2424, 2);
    V v_k_2436 = heff_field(v_p_2424, 3);
    V v_ru_24p_2424_24RunUnder = heff_take_reuse_n(v_p_2424, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2424_24RunUnder, TAG_RunUnder, 4, (V[]){v_t_2433, v_cmd_2434, v_argv_2435, v_k_2436});
  }
  default: return heff_nomatch(v_p_2424);
  }
}
HEFF_LIT(g_std_2eprogress_2ecountOf_str0, 0, "");
HEFF_LIT(g_std_2eprogress_2ecountOf_str1, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str2, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str3, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str4, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str5, 1, "[");
HEFF_LIT(g_std_2eprogress_2ecountOf_str6, 2, "] ");
HEFF_LIT(g_std_2eprogress_2ecountOf_str7, 1, "/");
HEFF_LIT(g_std_2eprogress_2ecountOf_str8, 1, "[");
Clo g_std_2eprogress_2ecountOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ecountOf_entry, 2, 0};

V g_std_2eprogress_2ecountOf(V v_done_240, V v_total_241) {
top: ;
  if (heff_intEq_c_lent(v_done_240, MK_INT(0LL), 2)) {
    if (heff_intEq_c_lent(v_total_241, MK_INT(0LL), 2)) {
      heff_drop(v_done_240);
      heff_drop(v_total_241);
      return ((V)&g_std_2eprogress_2ecountOf_str0);
    } else {
      V v_t_244 = heff_strAppend(heff_intShow(v_total_241), ((V)&g_std_2eprogress_2ecountOf_str1));
      V v_t_245 = heff_strAppend(heff_intShow(v_done_240), heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str2), v_t_244));
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str3), v_t_245);
    }
  } else {
    if (heff_intEq_c_lent(v_total_241, MK_INT(0LL), 2)) {
      heff_drop(v_total_241);
      V v_t_247 = heff_strAppend(heff_intShow(v_done_240), ((V)&g_std_2eprogress_2ecountOf_str4));
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str5), v_t_247);
    } else {
      V v_t_248 = heff_strAppend(heff_intShow(v_total_241), ((V)&g_std_2eprogress_2ecountOf_str6));
      V v_t_249 = heff_strAppend(heff_intShow(v_done_240), heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str7), v_t_248));
      return heff_strAppend(((V)&g_std_2eprogress_2ecountOf_str8), v_t_249);
    }
  }
}
V g_std_2eprogress_2ecountOf_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ecountOf(a[0], a[1]);
}
HEFF_LIT(g_std_2eprogress_2edrawUnder_str0, 7, "\342\224\224\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str1, 7, "\342\224\234\342\224\200 ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str2, 3, "   ");
HEFF_LIT(g_std_2eprogress_2edrawUnder_str3, 5, "\342\224\202  ");
Clo g_std_2eprogress_2edrawUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawUnder_entry, 3, 0};

V g_std_2eprogress_2edrawUnder(V v_every_240, V v_prefix_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    heff_drop(v_prefix_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_std_2eprogress_2edrawUnder_str0);
      break;
    }
    case TAG_Cons: {
      v_t_247 = ((V)&g_std_2eprogress_2edrawUnder_str1);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_248 = (g_std_2eprogress_2ecountOf(heff_take_field(v_t_243, 3), heff_take_field(v_t_243, 4)));
    V v_t_249 = heff_strAppend(v_t_248, heff_take_field(v_t_243, 2));
    V v_t_2410 = heff_strAppend(heff_dup(v_prefix_241), heff_strAppend(v_t_247, v_t_249));
    V v_t_2413;
    switch (heff_tag_of(v_rest_244)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_std_2eprogress_2edrawUnder_str2);
      break;
    }
    case TAG_Cons: {
      v_t_2413 = ((V)&g_std_2eprogress_2edrawUnder_str3);
      break;
    }
    default: heff_nomatch(v_rest_244);
    }
    V v_t_2414 = (g_list_2ekeepIf_24s404882566x1805760949(heff_get_n(v_t_243, 0, 5), heff_dup(v_every_240)));
    V v_t_2415 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), heff_strAppend(heff_dup(v_prefix_241), v_t_2413), v_t_2414));
    V v_t_2416 = (g_std_2eprogress_2edrawUnder(v_every_240, v_prefix_241, v_rest_244));
    V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2416));
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_t_2417});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2edrawUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawUnder(a[0], a[1], a[2]);
}
HEFF_LIT(g_std_2eprogress_2edrawTop_str0, 0, "");
Clo g_std_2eprogress_2edrawTop_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawTop_entry, 2, 0};

V g_std_2eprogress_2edrawTop(V v_every_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_every_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_std_2eprogress_2ecountOf(heff_take_field(v_t_242, 3), heff_take_field(v_t_242, 4)));
    V v_t_245 = heff_strAppend(v_t_244, heff_take_field(v_t_242, 2));
    V v_t_246 = (g_list_2ekeepIf_24s404882566x1805760949(heff_get_n(v_t_242, 0, 5), heff_dup(v_every_240)));
    V v_t_247 = (g_std_2eprogress_2edrawUnder(heff_dup(v_every_240), ((V)&g_std_2eprogress_2edrawTop_str0), v_t_246));
    V v_t_248 = (g_std_2eprogress_2edrawTop(v_every_240, v_rest_243));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_247, v_t_248));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawTop_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawTop(a[0], a[1]);
}
Clo g_std_2eprogress_2ekidsUnder_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_entry, 3, 0};

V g_std_2eprogress_2ekidsUnder(V v_t_240, V v_box_24i_241, V v_x3_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkKid: {
      V v_name_245 = heff_field(v_x31_243, 0);
      V v_done_246 = heff_field(v_x31_243, 1);
      V v_total_247 = heff_field(v_x31_243, 2);
      V v_parent_248 = heff_field(v_x31_243, 3);
      heff_take_n(v_x31_243, 15ULL, 4);
      V v_t_2411;
      if ((v_i_241 == ((int64_t)0ULL))) {
        v_t_2411 = heff_dup(v_t_240);
      } else {
        if ((v_i_241 == ((int64_t)255ULL))) {
          v_t_2411 = heff_dup(v_t_240);
        } else {
          v_t_2411 = heff_box_word((((int64_t)-1ULL) - v_i_241));
        }
      }
      V v_t_2414;
      if (heff_intEq_c_lent(v_parent_248, MK_INT(0LL), 2)) {
        heff_drop(v_parent_248);
        v_t_2414 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_parent_248, MK_INT(255LL), 2)) {
          heff_drop(v_parent_248);
          v_t_2414 = heff_dup(v_t_240);
        } else {
          v_t_2414 = heff_intSub(MK_INT(-1LL), v_parent_248);
        }
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_2411, v_t_2414, v_name_245, v_done_246, v_total_247}), heff_hole()});
      V v_u_2416 = (g_std_2eprogress_2ekidsUnder_24dps(v_t_240, heff_box_word((v_i_241 + ((int64_t)1ULL))), v_rest_244, heff_dup(v_cell_2415)));
      heff_drop(v_u_2416);
      return v_cell_2415;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder(a[0], a[1], a[2]);
}
Clo g_std_2eprogress_2ekidsUnder_24dps_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2ekidsUnder_24dps_entry, 4, 0};

V g_std_2eprogress_2ekidsUnder_24dps(V v_t_240, V v_i_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_i_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkKid: {
      V v_name_246 = heff_field(v_x31_244, 0);
      V v_done_247 = heff_field(v_x31_244, 1);
      V v_total_248 = heff_field(v_x31_244, 2);
      V v_parent_249 = heff_field(v_x31_244, 3);
      heff_take_n(v_x31_244, 15ULL, 4);
      V v_t_2412;
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        v_t_2412 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_i_241, MK_INT(255LL), 2)) {
          v_t_2412 = heff_dup(v_t_240);
        } else {
          v_t_2412 = heff_intSub(MK_INT(-1LL), heff_dup(v_i_241));
        }
      }
      V v_t_2415;
      if (heff_intEq_c_lent(v_parent_249, MK_INT(0LL), 2)) {
        heff_drop(v_parent_249);
        v_t_2415 = heff_dup(v_t_240);
      } else {
        if (heff_intEq_c_lent(v_parent_249, MK_INT(255LL), 2)) {
          heff_drop(v_parent_249);
          v_t_2415 = heff_dup(v_t_240);
        } else {
          v_t_2415 = heff_intSub(MK_INT(-1LL), v_parent_249);
        }
      }
      V v_cell_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(5, shape_task__parent__name__done__total, (V[]){v_t_2412, v_t_2415, v_name_246, v_done_247, v_total_248}), heff_hole()});
      V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
      heff_drop(v_u_2417);
      V t_0 = v_t_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_rest_245;
      V t_3 = v_cell_2416;
      v_t_240 = t_0;
      v_i_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_std_2eprogress_2ekidsUnder_24dps_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2ekidsUnder_24dps(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_std_2eprogress_2erooted_str0, 0, "");
Clo g_std_2eprogress_2erooted_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2erooted_entry, 3, 0};

V g_std_2eprogress_2erooted(V v_t_240, V v_x2_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkKid: {
    V v_name_243 = heff_field(v_x2_241, 0);
    V v_done_244 = heff_field(v_x2_241, 1);
    V v_total_245 = heff_field(v_x2_241, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_s_242, 0)), v_t_240)) {
      V v_t_249;
      if (heff_strEq_c_lent(v_name_243, ((V)&g_std_2eprogress_2erooted_str0), 2)) {
        v_t_249 = heff_dup(heff_rfield(v_s_242, 2));
      } else {
        v_t_249 = heff_dup(v_name_243);
      }
      V v_t_2414;
      if (heff_intEq_c_lent(v_total_245, MK_INT(0LL), 2)) {
        if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 4)))) {
          V v_y_2412 = heff_dup(heff_rfield(v_s_242, 4));
          if (heff_intLe_c_lent(v_done_244, v_y_2412, 0)) {
            heff_drop(v_y_2412);
            v_t_2414 = heff_dup(v_done_244);
          } else {
            v_t_2414 = v_y_2412;
          }
        } else {
          v_t_2414 = heff_dup(v_done_244);
        }
      } else {
        v_t_2414 = heff_dup(v_done_244);
      }
      V v_t_2416;
      if (heff_intEq_c_lent(v_total_245, MK_INT(0LL), 2)) {
        v_t_2416 = heff_dup(heff_rfield(v_s_242, 4));
      } else {
        v_t_2416 = heff_dup(v_total_245);
      }
      return ({ V rv_2 = v_t_249; V rv_3 = v_t_2414; V rv_4 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_s_242, 3ULL, 5, shape_task__parent__name__done__total, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    } else {
      return v_s_242;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2erooted_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eprogress_2erooted(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_std_2eprogress_2eparentOf_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eparentOf_entry, 2, 0};

V g_std_2eprogress_2eparentOf(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 0)), heff_dup(v_i_240))) {
      heff_drop(v_i_240);
      return heff_dup(heff_rfield(v_t_242, 1));
    } else {
      V t_0 = v_i_240;
      V t_1 = v_rest_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2eparentOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2eprogress_2eparentOf(a[0], a1); heff_drop(a1); return r;
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam1(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam0(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam3(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam2(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam5(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam4(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam8(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam7(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9(V self, V *args); static Clo g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9, 1, 0};
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam11(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam10(V self, V *args);
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam6(V self, V *args);
Clo g_std_2eprogress_2edrawnOp_24s1298996847x528338874_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawnOp_24s1298996847x528338874_entry, 2, 0};

V g_std_2eprogress_2edrawnOp_24s1298996847x528338874(V v_ts_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Start: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_name_243 = heff_field(v_x2_241, 1);
    V v_total_244 = heff_field(v_x2_241, 2);
    V v_k_245 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkTask: {
      V v_p_246 = heff_field(v_x21_242, 0);
      V v_ru_24x21_242_24MkTask = heff_take_reuse_n(v_x21_242, 1ULL, 1);
      V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_ts_240, 0)), MK_INT(1LL));
      V v_t_248 = heff_rec_n(5, shape_task__parent__name__done__total, (V[]){heff_dup(heff_rfield(v_ts_240, 0)), v_p_246, v_name_243, MK_INT(0LL), v_total_244});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
      V v_t_2410 = (g_prelude_2e_2b_2b(heff_take_field(v_ts_240, 1), v_t_249));
      V v_ts_2411 = heff_rec_n(2, shape_next__going, (V[]){v_t_247, v_t_2410});
      V v_t_2412 = heff_tag_at_n(v_ru_24x21_242_24MkTask, TAG_MkTask, 1, (V[]){heff_get_n(v_ts_240, 0, 2)});
      V v_x_2413 = heff_tr(heff_call(v_k_245, 1, (V[]){v_t_2412}));
      V v_ts_2414 = heff_dup(heff_rfield(v_ts_2411, 1));
      V v_t_2415 = (g_list_2ekeepIf_24s404882566x1805760949(MK_INT(0LL), heff_dup(v_ts_2414)));
      V v_ls_2416 = (g_std_2eprogress_2edrawTop(v_ts_2414, v_t_2415));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam0, 2, 3, (V[]){v_ls_2416, v_ts_2411, v_x_2413});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  case TAG_Complete: {
    V v_x21_2424 = heff_field(v_x2_241, 0);
    V v_x_2425 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2424)) {
    case TAG_MkTask: {
      V v_i_2426 = heff_field(v_x21_2424, 0);
      heff_take_n(v_x21_2424, 1ULL, 1);
      V v_t_2427 = (g_list_2emap_24s1661513421x830177447(v_i_2426, MK_INT(1LL), heff_take_field(v_ts_240, 1)));
      V v_ts_2428 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2429 = heff_dup(heff_rfield(v_ts_2428, 1));
      V v_t_2430 = (g_list_2ekeepIf_24s404882566x1805760949(MK_INT(0LL), heff_dup(v_ts_2429)));
      V v_ls_2431 = (g_std_2eprogress_2edrawTop(v_ts_2429, v_t_2430));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam2, 2, 3, (V[]){v_ls_2431, v_ts_2428, v_x_2425});
    }
    default: return heff_nomatch(v_x21_2424);
    }
  }
  case TAG_End: {
    V v_x21_2439 = heff_field(v_x2_241, 0);
    V v_x_2440 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_2439)) {
    case TAG_MkTask: {
      V v_i_2441 = heff_field(v_x21_2439, 0);
      heff_take_n(v_x21_2439, 1ULL, 1);
      V v_i_2442 = (g_std_2eprogress_2eparentOf(heff_dup(v_i_2441), heff_rfield(v_ts_240, 1)));
      V v_t_2443 = (g_list_2emap_24f273747616x929587227(v_i_2442, MK_INT(1LL), v_i_2441, heff_take_field(v_ts_240, 1)));
      V v_ts_2444 = ({ V rv_1 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_ts_240, 1ULL, 2, shape_next__going, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_ts_2445 = heff_dup(heff_rfield(v_ts_2444, 1));
      V v_t_2446 = (g_list_2ekeepIf_24s404882566x1805760949(MK_INT(0LL), heff_dup(v_ts_2445)));
      V v_ls_2447 = (g_std_2eprogress_2edrawTop(v_ts_2445, v_t_2446));
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam4, 2, 3, (V[]){v_ls_2447, v_ts_2444, v_x_2440});
    }
    default: return heff_nomatch(v_x21_2439);
    }
  }
  case TAG_RunUnder: {
    V v_x21_2455 = heff_field(v_x2_241, 0);
    V v_cmd_2456 = heff_field(v_x2_241, 1);
    V v_argv_2457 = heff_field(v_x2_241, 2);
    V v_k_2458 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    switch (heff_tag_of(v_x21_2455)) {
    case TAG_MkTask: {
      V v_i_2459 = heff_field(v_x21_2455, 0);
      heff_take_n(v_x21_2455, 1ULL, 1);
      return heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam6, 2, 5, (V[]){v_cmd_2456, v_argv_2457, v_ts_240, v_i_2459, v_k_2458});
    }
    default: return heff_nomatch(v_x21_2455);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2edrawnOp_24s1298996847x528338874(a[0], a[1]);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam0(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_ls_2416 = heff_env(self)[0];
  V v_ts_2411 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2416, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s448066416x262457974(v_t_2422, v_hd_2417, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam1, 1, 3, (V[]){v_k_2418, v_ts_2411, v_x_2413})));
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2433 = heff_env(self)[0];
  V v_ts_2428 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2438);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2428, v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_ls_2431 = heff_env(self)[0];
  V v_ts_2428 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2431, NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s448066416x262457974(v_t_2437, v_hd_2432, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam3, 1, 3, (V[]){v_k_2433, v_ts_2428, v_x_2425})));
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam5(V self, V *args) {
  V v_x_2454 = args[0];
  V v_k_2449 = heff_env(self)[0];
  V v_ts_2444 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2454);
  V f_ = v_k_2449;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2444, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam4(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_ls_2447 = heff_env(self)[0];
  V v_ts_2444 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2450 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2447, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  return (g_co_2eop_24s448066416x262457974(v_t_2453, v_hd_2448, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam5, 1, 3, (V[]){v_k_2449, v_ts_2444, v_x_2440})));
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam8(V self, V *args) {
  V v_s_2466 = args[0];
  V v_i_2459 = heff_env(self)[0];
  V v_r_2464 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_i_2459; V a_1 = v_r_2464; V a_2 = v_s_2466; V r_ = (g_std_2eprogress_2erooted(a_0, a_1, a_2)); heff_drop(v_r_2464); r_; });
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam7(V self, V *args) {
  V v_kids_2462 = args[0];
  V v_ts_240 = heff_env(self)[0];
  V v_i_2459 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_ts_2463 = heff_get_n(v_ts_240, 1, 2);
  V v_ts_2469;
  switch (heff_tag_of(v_kids_2462)) {
  case TAG_Nil: {
    heff_drop(v_i_2459);
    v_ts_2469 = v_ts_2463;
    break;
  }
  case TAG_Cons: {
    V v_r_2464 = heff_field(v_kids_2462, 0);
    V v_kids_2465 = heff_field(v_kids_2462, 1);
    heff_take_n(v_kids_2462, 3ULL, 2);
    V v_t_2467 = (g_list_2emap(heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam8, 1, 2, (V[]){heff_dup(v_i_2459), v_r_2464}), v_ts_2463));
    V v_t_2468 = (g_std_2eprogress_2ekidsUnder(v_i_2459, MK_INT(1LL), v_kids_2465));
    v_ts_2469 = (g_prelude_2e_2b_2b(v_t_2467, v_t_2468));
    break;
  }
  default: heff_nomatch(v_kids_2462);
  }
  V v_t_2470 = (g_list_2ekeepIf_24s404882566x1805760949(MK_INT(0LL), heff_dup(v_ts_2469)));
  return (g_std_2eprogress_2edrawTop(v_ts_2469, v_t_2470));
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9(V self, V *args) {
  V v_r_2471 = args[0];
  return v_r_2471;
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam11(V self, V *args) {
  V v_x_2484 = args[0];
  V v_k_2461 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_x_2476 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2484);
  V f_ = v_k_2461;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_240, v_x_2476});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam10(V self, V *args) {
  V v_x_2475 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_ts_240 = heff_env(self)[1];
  V v_hd_2460 = heff_env(self)[2];
  V v_k_2461 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2476 = heff_tr(heff_call(v_k_2458, 1, (V[]){v_x_2475}));
  V v_ts_2477 = heff_dup(heff_rfield(v_ts_240, 1));
  V v_t_2478 = (g_list_2ekeepIf_24s404882566x1805760949(MK_INT(0LL), heff_dup(v_ts_2477)));
  V v_ls_2479 = (g_std_2eprogress_2edrawTop(v_ts_2477, v_t_2478));
  V v_t_2480 = heff_tag_n(TAG_ShowLines, 2, (V[]){v_ls_2479, NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  return (g_co_2eop_24s448066416x262457974(v_t_2483, v_hd_2460, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam11, 1, 3, (V[]){v_k_2461, v_ts_240, v_x_2476})));
}
V g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam6(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  V v_cmd_2456 = heff_env(self)[0];
  V v_argv_2457 = heff_env(self)[1];
  V v_ts_240 = heff_env(self)[2];
  V v_i_2459 = heff_env(self)[3];
  V v_k_2458 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ShowRun, 4, (V[]){v_cmd_2456, v_argv_2457, heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam7, 1, 2, (V[]){heff_dup(v_ts_240), v_i_2459}), ((V)&g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam9_clo)})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s448066416x262457974(heff_tag_n(TAG_InL, 1, (V[]){v_t_2474}), heff_dup(v_hd_2460), heff_clo_n(g_std_2eprogress_2edrawnOp_24s1298996847x528338874_lam10, 1, 4, (V[]){v_k_2458, v_ts_240, v_hd_2460, v_k_2461})));
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0, 4, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam3(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam2(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1, 3, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam7(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam6(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5, 3, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam9(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8, 4, 0};
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam12(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam11(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam10(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam13(V self, V *args);
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4(V self, V *args); static Clo g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4, 2, 0};

static V g_std_2eprogress_2edrawing_24s99689049x1192072418_val;
static HEFF_ONCE g_std_2eprogress_2edrawing_24s99689049x1192072418_st;
static V g_std_2eprogress_2edrawing_24s99689049x1192072418_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0_clo), ((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1_clo), ((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4_clo)});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_get(void) {
  if (HEFF_DONE(g_std_2eprogress_2edrawing_24s99689049x1192072418_st)) return g_std_2eprogress_2edrawing_24s99689049x1192072418_val;
  return heff_global(&g_std_2eprogress_2edrawing_24s99689049x1192072418_val, &g_std_2eprogress_2edrawing_24s99689049x1192072418_st, g_std_2eprogress_2edrawing_24s99689049x1192072418_init);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_ts_241 = args[1];
  V v_hd_242 = args[2];
  V v_k_243 = args[3];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_241, v_x_240});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_y_2412 = heff_dup(heff_field(v_x_2410, 1));
    v_t_2413 = v_y_2412;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_245;
  heff_room[0] = v_t_2413;
  heff_room[1] = v_t_2416;
  heff_room[2] = v_hd_248;
  heff_room[3] = v_k_249;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam2(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam3, 1, 3, (V[]){v_k_245, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam1(V self, V *args) {
  V v_m_244 = args[0];
  V v_k_245 = args[1];
  V v_ts_246 = args[2];
  V v_c_247 = heff_tr(heff_call(v_m_244, 1, (V[]){v_ts_246}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam2, 2, 2, (V[]){v_c_247, v_k_245});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam7(V self, V *args) {
  V v_x_2428 = args[0];
  V v_g_2422 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_x_2429 = heff_dup(heff_field(v_x_2428, 0));
    v_t_2431 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2434;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkPair: {
    V v_y_2433 = heff_field(v_x_2428, 1);
    heff_take_n(v_x_2428, 2ULL, 2);
    v_t_2434 = v_y_2433;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2435 = heff_tr(heff_call(v_g_2422, 1, (V[]){v_t_2434}));
  V v_x_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, v_t_2435});
  V f_ = v_k_2427;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_g_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2425;
  args[0] = v_hd_2426;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam7, 1, 2, (V[]){v_g_2422, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5(V self, V *args) {
  V v_g_2422 = args[0];
  V v_m_2423 = args[1];
  V v_ts_2424 = args[2];
  V v_c_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_ts_2424}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam6, 2, 2, (V[]){v_c_2425, v_g_2422});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_2437 = heff_env(self)[0];
  V v_k_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2442 = heff_tr(heff_call(v_g_2437, 1, (V[]){v_x_2441}));
  V f_ = v_k_2440;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8(V self, V *args) {
  V v_g_2437 = args[0];
  V v_c_2438 = args[1];
  V v_hd_2439 = args[2];
  V v_k_2440 = args[3];
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam9, 1, 2, (V[]){v_g_2437, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam12(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_MkPair: {
    V v_y_2449 = heff_field(v_x_2447, 1);
    heff_take_n(v_x_2447, 2ULL, 2);
    v_t_2450 = v_y_2449;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V f_ = v_k_2446;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam11(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2444;
  args[0] = v_hd_2445;
  args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam12, 1, 1, (V[]){v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam10(V self, V *args) {
  V v_c_2443 = args[0];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_2444 = heff_tr(heff_call(v_c_2443, 1, (V[]){v_ts_2418}));
  return heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam11, 2, 1, (V[]){v_c_2444});
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam13(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_2458 = args[1];
  V v_k_2459 = args[2];
  V v_ts_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_ts_2418, v_x_2457});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2edrawing_24s99689049x1192072418_lam4(V self, V *args) {
  V v_p_2417 = args[0];
  V v_ts_2418 = args[1];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_InL: {
    V v_o_2419 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 1);
    return (g_std_2eprogress_2edrawnOp_24s1298996847x528338874(v_ts_2418, v_o_2419));
  }
  case TAG_InR: {
    V v_q_2420 = heff_field(v_p_2417, 0);
    V v_ru_24p_2417_24InR = heff_take_reuse_n(v_p_2417, 1ULL, 1);
    V v_t_2456;
    switch (heff_tag_of(v_q_2420)) {
    case TAG_InL: {
      V v_x_2421 = heff_field(v_q_2420, 0);
      V v_ru_24q_2420_24InL = heff_take_reuse_n(v_q_2420, 1ULL, 1);
      heff_drop_cell(v_ru_24p_2417_24InR, 1);
      V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s787064636x102052035_get(), 1)), 4, (V[]){heff_rec_n(1, shape_fmap, (V[]){((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam5_clo)}), heff_rec_n(1, shape_fmap, (V[]){((V)&g_std_2eprogress_2edrawing_24s99689049x1192072418_lam8_clo)}), heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam10, 1, 1, (V[]){heff_dup(v_ts_2418)}), v_x_2421}));
      v_t_2456 = heff_tag_at_n(v_ru_24q_2420_24InL, TAG_InL, 1, (V[]){v_t_2451});
      break;
    }
    case TAG_InR: {
      V v_y_2452 = heff_field(v_q_2420, 0);
      heff_take_n(v_q_2420, 1ULL, 1);
      V v_t_2455;
      switch (heff_tag_of(v_y_2452)) {
      case TAG_Send: {
        V v_rq_2453 = heff_field(v_y_2452, 0);
        V v_k_2454 = heff_field(v_y_2452, 1);
        V v_ru_24y_2452_24Send = heff_take_reuse_n(v_y_2452, 3ULL, 2);
        v_t_2455 = heff_tag_at_n(v_ru_24y_2452_24Send, TAG_Send, 2, (V[]){v_rq_2453, v_k_2454});
        break;
      }
      default: heff_nomatch(v_y_2452);
      }
      v_t_2456 = heff_tag_at_n(v_ru_24p_2417_24InR, TAG_InR, 1, (V[]){v_t_2455});
      break;
    }
    default: heff_nomatch(v_q_2420);
    }
    V f_ = ((V)&g_co_2eop_24s358005445x1922844939_clo);
    args[0] = v_t_2456;
    args[1] = heff_clo_n(g_std_2eprogress_2edrawing_24s99689049x1192072418_lam13, 3, 1, (V[]){v_ts_2418});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_p_2417);
  }
}
HEFF_LIT(g_std_2eprogress_2equietly_24s1658224449x1316783431_str0, 0, "");
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam0(V self, V *args);
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam1(V self, V *args);
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam2(V self, V *args);
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam3(V self, V *args); static Clo g_std_2eprogress_2equietly_24s1658224449x1316783431_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2equietly_24s1658224449x1316783431_lam3, 1, 0};
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam5(V self, V *args);
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam4(V self, V *args);
Clo g_std_2eprogress_2equietly_24s1658224449x1316783431_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2equietly_24s1658224449x1316783431_entry, 1, 0};

V g_std_2eprogress_2equietly_24s1658224449x1316783431(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Start: {
    V v_k_244 = heff_field(v_x1_240, 3);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_k_244), 1, (V[]){heff_dup(g_std_2eprogress_2eroot_get())}));
    return heff_clo_n(g_std_2eprogress_2equietly_24s1658224449x1316783431_lam0, 2, 1, (V[]){v_x_245});
  }
  case TAG_Complete: {
    V v_x_249 = heff_field(v_x1_240, 1);
    return heff_clo_n(g_std_2eprogress_2equietly_24s1658224449x1316783431_lam1, 2, 1, (V[]){heff_dup(v_x_249)});
  }
  case TAG_End: {
    V v_x_2413 = heff_field(v_x1_240, 1);
    return heff_clo_n(g_std_2eprogress_2equietly_24s1658224449x1316783431_lam2, 2, 1, (V[]){heff_dup(v_x_2413)});
  }
  case TAG_RunUnder: {
    V v_cmd_2417 = heff_field(v_x1_240, 1);
    V v_argv_2418 = heff_field(v_x1_240, 2);
    V v_k_2419 = heff_field(v_x1_240, 3);
    V v_t_2420 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    V v_t_2421;
    if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
      heff_drop(v_t_2420);
      v_t_2421 = ((V)&g_std_2eprogress_2equietly_24s1658224449x1316783431_str0);
    } else {
      heff_drop(v_t_2420);
      v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    }
    V v_t_2422 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_cmd_2417), heff_dup(v_argv_2418), v_t_2421, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2424 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2422, ((V)&g_std_2eprogress_2equietly_24s1658224449x1316783431_lam3_clo)});
    return heff_clo_n(g_std_2eprogress_2equietly_24s1658224449x1316783431_lam4, 2, 2, (V[]){v_a_2424, heff_dup(v_k_2419)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eprogress_2equietly_24s1658224449x1316783431(a0); heff_drop(a0); return r;
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_x_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam3(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2433 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_x_2432}));
  V f_ = v_k_2426;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2equietly_24s1658224449x1316783431_lam4(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_a_2424 = heff_env(self)[0];
  V v_k_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s448066416x262457974(v_t_2431, v_hd_2425, heff_clo_n(g_std_2eprogress_2equietly_24s1658224449x1316783431_lam5, 1, 2, (V[]){v_k_2419, v_k_2426})));
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam0(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1775398343x1420570306_lam0, 1, 0};
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam3(V self, V *args);
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam2(V self, V *args);
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam4(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_lam4_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1775398343x1420570306_lam4, 3, 0};
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam6(V self, V *args);
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam5(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1775398343x1420570306_lam5, 4, 0};
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam7(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1775398343x1420570306_lam7, 1, 0};
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam8(V self, V *args); static Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_lam8_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1775398343x1420570306_lam8, 3, 0};
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam1(V self, V *args);
Clo g_std_2eprogress_2eshown_24s1775398343x1420570306_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprogress_2eshown_24s1775398343x1420570306_entry, 4, 0};

V g_std_2eprogress_2eshown_24s1775398343x1420570306(V v_c_240, V v_hd_241, V v_k_242, V v_z_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_IsTerminal, 1, (V[]){((V)&g_std_2eprogress_2eshown_24s1775398343x1420570306_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_2434 = heff_tr(g_co_2eop_24s448066416x262457974(heff_tag_n(TAG_InL, 1, (V[]){v_t_247}), heff_dup(v_hd_241), heff_clo_n(g_std_2eprogress_2eshown_24s1775398343x1420570306_lam1, 1, 3, (V[]){v_c_240, v_hd_241, v_k_242})));
  return heff_tail(v_t_2434, 1, (V[]){v_z_243});
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_entry(V self, V *a) {
  (void)self;
  return g_std_2eprogress_2eshown_24s1775398343x1420570306(a[0], a[1], a[2], a[3]);
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam0(V self, V *args) {
  V v_b_244 = args[0];
  return v_b_244;
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2419;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_MkPair: {
    V v_y_2418 = heff_field(v_x_2411, 1);
    heff_take_n(v_x_2411, 2ULL, 2);
    v_t_2419 = v_y_2418;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V f_ = v_k_242;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_ShowLines, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s448066416x262457974(v_t_2415, v_hd_241, heff_clo_n(g_std_2eprogress_2eshown_24s1775398343x1420570306_lam3, 1, 2, (V[]){v_x_2411, v_k_242})));
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_2421 = args[1];
  V v_k_2422 = args[2];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2424 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_k_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2424;
  heff_room[0] = v_x_2427;
  heff_room[1] = v_hd_2425;
  heff_room[2] = v_k_2426;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam5(V self, V *args) {
  V v_m_2423 = args[0];
  V v_k_2424 = args[1];
  V v_hd_2425 = args[2];
  V v_k_2426 = args[3];
  V f_ = v_m_2423;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_std_2eprogress_2eshown_24s1775398343x1420570306_lam6, 1, 3, (V[]){v_k_2424, v_hd_2425, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam7(V self, V *args) {
  V v_p_2428 = args[0];
  switch (heff_tag_of(v_p_2428)) {
  case TAG_InL: {
    V v_t_2429 = heff_field(v_p_2428, 0);
    heff_take_n(v_p_2428, 1ULL, 1);
    return ({ V a_0 = v_t_2429; V r_ = (g_std_2eprogress_2equietly_24s1658224449x1316783431(a_0)); heff_drop(v_t_2429); r_; });
  }
  case TAG_InR: {
    V v_q_2430 = heff_field(v_p_2428, 0);
    heff_take_n(v_p_2428, 1ULL, 1);
    V f_ = ((V)&g_co_2eop_24s1932151623x486962575_clo);
    args[0] = v_q_2430;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_p_2428);
  }
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprogress_2eshown_24s1775398343x1420570306_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_248) == NTAG(TAG_True))) {
    heff_drop(v_x_248);
    V v_t_249 = heff_rec_n(2, shape_next__going, (V[]){MK_INT(1LL), NTAG(TAG_Nil)});
    V v_c_2410 = heff_tr(heff_call(v_c_240, 3, (V[]){heff_dup(g_std_2eprogress_2edrawing_24s99689049x1192072418_get()), heff_dup(heff_rfield(g_std_2eprogress_2edrawing_24s99689049x1192072418_get(), 0)), v_t_249}));
    V f_ = v_c_2410;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_std_2eprogress_2eshown_24s1775398343x1420570306_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_248);
    V f_ = v_c_240;
    heff_room[0] = heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_std_2eprogress_2eshown_24s1775398343x1420570306_lam4_clo), ((V)&g_std_2eprogress_2eshown_24s1775398343x1420570306_lam5_clo), ((V)&g_std_2eprogress_2eshown_24s1775398343x1420570306_lam7_clo)});
    heff_room[1] = ((V)&g_std_2eprogress_2eshown_24s1775398343x1420570306_lam8_clo);
    heff_room[2] = v_hd_241;
    heff_room[3] = v_k_242;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
}