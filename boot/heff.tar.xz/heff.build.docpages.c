// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_exposes 1070285678
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_source 1050636102
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_top 324559
V g_heff_2ebuild_2edocpages_2eanchorOf(V);
V g_heff_2ebuild_2edocpages_2eanchorOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eanchorOf_clo;
V g_heff_2ebuild_2edocpages_2eentriesOf(V);
V g_heff_2ebuild_2edocpages_2eentriesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentriesOf_clo;
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps(V, V);
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentriesOf_24dps_clo;
V g_heff_2ebuild_2edocpages_2eentryWith(V, V, V);
V g_heff_2ebuild_2edocpages_2eentryWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentryWith_clo;
V g_heff_2ebuild_2edocpages_2efirstParagraph(V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo;
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(V, V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_clo;
V g_heff_2ebuild_2edocpages_2efirstSentence(V);
V g_heff_2ebuild_2edocpages_2efirstSentence_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstSentence_clo;
V g_heff_2ebuild_2edocpages_2eheaderComment(V);
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo;
V g_heff_2ebuild_2edocpages_2eheaderGo(V);
V g_heff_2ebuild_2edocpages_2eheaderGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderGo_clo;
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps(V, V);
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderGo_24dps_clo;
V g_heff_2ebuild_2edocpages_2eindexLine(V);
V g_heff_2ebuild_2edocpages_2eindexLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eindexLine_clo;
V g_heff_2ebuild_2edocpages_2enameStart(V);
V g_heff_2ebuild_2edocpages_2enameStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2enameStart_clo;
V g_heff_2ebuild_2edocpages_2eopWord(V);
V g_heff_2ebuild_2edocpages_2eopWord_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eopWord_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edocpages_2epart(V);
V g_heff_2ebuild_2edocpages_2epart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epart_clo;
HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edocpages_2espanNamed_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(V, V);
V g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348_clo;
V g_heff_2ebuild_2edriver_2esignatureOf(V, V);
V g_heff_2ebuild_2edriver_2esignatureOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esignatureOf_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s965939768x96753258(V);
V g_list_2efilter_24s965939768x96753258_entry(V self, V *a);
extern Clo g_list_2efilter_24s965939768x96753258_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f904804876x285797696(V, V, V);
V g_list_2emap_24f904804876x285797696_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str3, 0, "");
Clo g_heff_2ebuild_2edocpages_2eheaderGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderGo_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eheaderGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str0))) {
      V v_t_245;
      if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str1))) {
        v_t_245 = heff_strSlice(heff_dup(v_l_241), MK_INT(3LL), heff_strLength(v_l_241));
      } else {
        v_t_245 = heff_strSlice(heff_dup(v_l_241), MK_INT(2LL), heff_strLength(v_l_241));
      }
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = (g_heff_2ebuild_2edocpages_2eheaderGo_24dps(v_rest_242, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      V v_t_248 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_2410 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_249), MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(v_l_241, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str2))) {
        V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str3), heff_hole()});
        V v_u_2414 = (g_heff_2ebuild_2edocpages_2eheaderGo_24dps(v_rest_242, heff_dup(v_cell_2413)));
        heff_drop(v_u_2414);
        return v_cell_2413;
      } else {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eheaderGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eheaderGo(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str3, 0, "");
Clo g_heff_2ebuild_2edocpages_2eheaderGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2eheaderGo_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str0))) {
      V v_t_246;
      if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str1))) {
        v_t_246 = heff_strSlice(heff_dup(v_l_242), MK_INT(3LL), heff_strLength(v_l_242));
      } else {
        v_t_246 = heff_strSlice(heff_dup(v_l_242), MK_INT(2LL), heff_strLength(v_l_242));
      }
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_rest_243;
      V t_1 = v_cell_247;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      V v_t_249 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_2411 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_2410), MK_INT(-1LL)));
      V v_t_2412 = heff_strSlice(v_l_242, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2412, ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str2))) {
        V v_cell_2414 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str3), heff_hole()});
        V v_u_2415 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V t_0 = v_rest_243;
        V t_1 = v_cell_2414;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eheaderGo_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str3, 1, "\012");
Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderComment_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eheaderComment(V v_src_240) {
top: ;
  V v_t_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str0); V a_1 = v_src_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str1), v_src_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_x2_242 = (g_heff_2ebuild_2edocpages_2eheaderGo(v_t_241));
  V v_s_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_s_245 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_s_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = (g_prelude_2eskipSpaces(v_s_245, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
  V v_t_248 = (g_prelude_2eskipSpaces(v_s_245, heff_box_word(v_t_247), MK_INT(-1LL)));
  return heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
}
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2eheaderComment(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstParagraph_str0, 0, "");
Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstParagraph_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2efirstParagraph(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
    V v_t_245 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_244), MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2edocpages_2efirstParagraph_str0))) {
      heff_drop(v_l_241);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_248 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_2410 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_249), MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(v_l_241, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(v_rest_242, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2efirstParagraph(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_str0, 0, "");
Clo g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_245), MK_INT(-1LL)));
    V v_t_247 = heff_strSlice(heff_dup(v_l_242), v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_str0))) {
      heff_drop(v_l_242);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_249 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_2411 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_2410), MK_INT(-1LL)));
      V v_t_2412 = heff_strSlice(v_l_242, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
      V v_cell_2413 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
      V v_u_2414 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2413));
      heff_drop(v_u_2414);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(a[0], a[1]);
}

HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V v_s_240, V v_i_241, V v_code_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
    heff_drop(v_i_241);
    heff_drop(v_code_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)96ULL))) {
      V v_t_245 = heff_bool(!(heff_dup(v_code_242) == NTAG(TAG_True)));
      heff_drop(v_code_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_t_245;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_code_242 = t_2;
      goto top;
    } else {
      if ((heff_dup(v_code_242) == NTAG(TAG_True))) {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_code_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_code_242 = t_2;
        goto top;
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)46ULL))) {
          V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
          if ((heff_unbox_word(v_t_247) == ((int64_t)32ULL))) {
            heff_drop(v_code_242);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
          } else {
            V t_0 = v_s_240;
            V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
            V t_2 = v_code_242;
            v_s_240 = t_0;
            v_i_241 = t_1;
            v_code_242 = t_2;
            goto top;
          }
        } else {
          V t_0 = v_s_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_code_242;
          v_s_240 = t_0;
          v_i_241 = t_1;
          v_code_242 = t_2;
          goto top;
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstSentence_str7, 1, " ");
Clo g_heff_2ebuild_2edocpages_2efirstSentence_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstSentence_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2efirstSentence(V v_header_240) {
top: ;
  V v_t_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str0); V a_1 = v_header_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str1), v_header_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_x2_242 = (g_heff_2ebuild_2edocpages_2efirstParagraph(v_t_241));
  V v_s_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_s_245 = ((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_s_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str4); V a_1 = v_header_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str5), v_header_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_x2_247 = (g_heff_2ebuild_2edocpages_2efirstParagraph(v_t_246));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2efirstSentence_str7); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  HeffT2 v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_False); HeffT2 r_ = (g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_i_2415 = v_field_2413;
      return heff_strSlice(v_s_245, MK_INT(0LL), heff_intAdd(v_i_2415, MK_INT(1LL)));
    } else {
      heff_drop(v_field_2413);
      return v_s_245;
    }
  }
}
V g_heff_2ebuild_2edocpages_2efirstSentence_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2efirstSentence(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2edocpages_2espanNamed_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_sp_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_x_240, v_y_244, 2)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_sp_245}});
      } else {
        heff_drop(v_sp_245);
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str2, 2, "\012\012");
Clo g_heff_2ebuild_2edocpages_2epart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2epart_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2epart(V v_text_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(v_text_240, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_text_240, 0)) - ((int64_t)1ULL));
  V v_t_243 = (g_prelude_2eskipSpaces(v_text_240, heff_box_word(v_t_242), MK_INT(-1LL)));
  V v_t_244 = heff_strSlice(heff_dup(v_text_240), v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2edocpages_2epart_str0))) {
    return ((V)&g_heff_2ebuild_2edocpages_2epart_str1);
  } else {
    V v_t_246 = (g_prelude_2eskipSpaces(v_text_240, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_text_240, 0)) - ((int64_t)1ULL));
    V v_t_248 = (g_prelude_2eskipSpaces(v_text_240, heff_box_word(v_t_247), MK_INT(-1LL)));
    V v_t_249 = heff_strSlice(heff_dup(v_text_240), v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
    return heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2edocpages_2epart_str2));
  }
}
V g_heff_2ebuild_2edocpages_2epart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2epart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str0, 2, "lt");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str1, 2, "gt");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str2, 4, "plus");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str3, 5, "minus");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str4, 4, "star");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str5, 5, "slash");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str6, 2, "eq");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str7, 5, "colon");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str8, 3, "dot");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str9, 3, "bar");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str10, 3, "amp");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str11, 5, "caret");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str12, 6, "dollar");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str13, 4, "bang");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str14, 8, "question");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str15, 5, "tilde");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str16, 7, "percent");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str17, 2, "at");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str18, 4, "hash");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str19, 9, "backslash");
Clo g_heff_2ebuild_2edocpages_2eopWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eopWord_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eopWord(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  if ((v_b_240 == ((int64_t)60ULL))) {
    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str0);
  } else {
    if ((v_b_240 == ((int64_t)62ULL))) {
      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str1);
    } else {
      if ((v_b_240 == ((int64_t)43ULL))) {
        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str2);
      } else {
        if ((v_b_240 == ((int64_t)45ULL))) {
          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str3);
        } else {
          if ((v_b_240 == ((int64_t)42ULL))) {
            return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str4);
          } else {
            if ((v_b_240 == ((int64_t)47ULL))) {
              return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str5);
            } else {
              if ((v_b_240 == ((int64_t)61ULL))) {
                return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str6);
              } else {
                if ((v_b_240 == ((int64_t)58ULL))) {
                  return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str7);
                } else {
                  if ((v_b_240 == ((int64_t)46ULL))) {
                    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str8);
                  } else {
                    if ((v_b_240 == ((int64_t)124ULL))) {
                      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str9);
                    } else {
                      if ((v_b_240 == ((int64_t)38ULL))) {
                        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str10);
                      } else {
                        if ((v_b_240 == ((int64_t)94ULL))) {
                          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str11);
                        } else {
                          if ((v_b_240 == ((int64_t)36ULL))) {
                            return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str12);
                          } else {
                            if ((v_b_240 == ((int64_t)33ULL))) {
                              return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str13);
                            } else {
                              if ((v_b_240 == ((int64_t)63ULL))) {
                                return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str14);
                              } else {
                                if ((v_b_240 == ((int64_t)126ULL))) {
                                  return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str15);
                                } else {
                                  if ((v_b_240 == ((int64_t)37ULL))) {
                                    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str16);
                                  } else {
                                    if ((v_b_240 == ((int64_t)64ULL))) {
                                      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str17);
                                    } else {
                                      if ((v_b_240 == ((int64_t)35ULL))) {
                                        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str18);
                                      } else {
                                        if ((v_b_240 == ((int64_t)92ULL))) {
                                          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str19);
                                        } else {
                                          return heff_intShow(heff_box_word(v_b_240));
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edocpages_2eopWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eopWord(a[0]);
}
Clo g_heff_2ebuild_2edocpages_2enameStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2enameStart_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2enameStart(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)65ULL) <= v_b_240) ? ((v_b_240 <= ((int64_t)90ULL)) || ((((int64_t)97ULL) <= v_b_240) ? ((v_b_240 <= ((int64_t)122ULL)) || (v_b_240 == ((int64_t)95ULL))) : (v_b_240 == ((int64_t)95ULL)))) : ((((int64_t)97ULL) <= v_b_240) ? (heff_intLe_c(heff_box_word(v_b_240), MK_INT(122LL)) || heff_intEq_c(heff_box_word(v_b_240), MK_INT(95LL))) : (v_b_240 == ((int64_t)95ULL)))));
  return v_ret_24bool;
}
V g_heff_2ebuild_2edocpages_2enameStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2enameStart(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eanchorOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eanchorOf_str1, 1, "-");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eanchorOf_str2, 3, "op-");
V g_heff_2ebuild_2edocpages_2eanchorOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2eanchorOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eanchorOf_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eanchorOf(V v_x_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2edocpages_2enameStart(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)));
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return v_x_240;
  } else {
    heff_drop(v_t_241);
    int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)1ULL));
    V v_x2_244 = (g_list_2emap_24f904804876x285797696(heff_clo_n(g_heff_2ebuild_2edocpages_2eanchorOf_lam0, 1, 1, (V[]){v_x_240}), MK_INT(0LL), heff_box_word(v_t_242)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2ebuild_2edocpages_2eanchorOf_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eanchorOf_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    return heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eanchorOf_str2), v_t_247);
  }
}
V g_heff_2ebuild_2edocpages_2eanchorOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eanchorOf(a[0]);
}
V g_heff_2ebuild_2edocpages_2eanchorOf_lam0(V self, V *args) {
  V v_i_243 = args[0];
  V v_x_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edocpages_2eopWord(heff_strByteAt(v_x_240, v_i_243)));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str0, 7, "haskell");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str2, 6, "\012```\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str3, 14, "}\012\012```haskell\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str4, 4, "` {#");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str5, 4, "## `");
Clo g_heff_2ebuild_2edocpages_2eentryWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentryWith_entry, 3, 0};

V g_heff_2ebuild_2edocpages_2eentryWith(V v_c_240, V v_o_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 14);
    heff_drop_rec(v_o_241, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_sig_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_heff_2ebuild_2edocpages_2eanchorOf(heff_dup(heff_rfield(v_o_241, 0))));
    V v_t_245 = (g_prelude_2eskipSpaces(v_sig_243, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_sig_243, 0)) - ((int64_t)1ULL));
    V v_t_247 = (g_prelude_2eskipSpaces(v_sig_243, heff_box_word(v_t_246), MK_INT(-1LL)));
    V v_t_248 = heff_strSlice(v_sig_243, v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
    HeffT2 v_t_2410 = (g_heff_2ebuild_2edocpages_2espanNamed_24cpr(heff_rfield(v_o_241, 0), v_t_249));
    V v_t_2419;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_sp_2414 = v_field_2412;
        V v_start_2415 = (g_heff_2ebuild_2equery_2elineStartOf(heff_rfield(v_c_240, 3), heff_get_n(v_sp_2414, 0, 2)));
        V v_t_2416 = ({ V b_0 = heff_get_n(v_c_240, 3, 14); V a_1 = v_start_2415; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2417 = (g_list_2emap_24s1819241345x1511673126(v_t_2416));
        V v_t_2418 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2417));
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str0); V a_1 = v_t_2418; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_t_2418); r_; });
      } else {
        heff_drop_rec(v_c_240, 14);
        heff_drop(v_field_2412);
        v_t_2419 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str1);
      }
    }
    V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2ebuild_2edocpages_2epart(a_0)); heff_drop(v_t_2419); r_; });
    V v_t_2421 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str2), v_t_2420));
    V v_t_2422 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str3), v_t_2421));
    V v_t_2423 = heff_strAppend(heff_get_n(v_o_241, 0, 2), heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str4), v_t_2422));
    return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str5), v_t_2423)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edocpages_2eentryWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentryWith(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2edocpages_2eentriesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentriesOf_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eentriesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edocpages_2eentriesOf_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eentriesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentriesOf(a[0]);
}
Clo g_heff_2ebuild_2edocpages_2eentriesOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2eentriesOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentriesOf_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str0, 6, "\012---\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str3, 11, "---\012title: ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str4, 1, "\012");
V g_heff_2ebuild_2edocpages_2epage_lam0(V self, V *args);
V g_heff_2ebuild_2edocpages_2epage_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2epage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2epage_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2epage(V v_c_240) {
top: ;
  V v_t_241 = heff_strAppend(heff_dup(heff_rfield(v_c_240, 0)), ((V)&g_heff_2ebuild_2edocpages_2epage_str0));
  V v_t_242 = (g_heff_2ebuild_2edocpages_2eheaderComment(heff_rfield(v_c_240, 3)));
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2ebuild_2edocpages_2epart(a_0)); heff_drop(v_t_242); r_; });
  V v_own_244 = heff_dup(heff_rfield(v_c_240, 7));
  V v_t_245 = heff_dup(heff_rfield(v_c_240, 13));
  V v_t_248;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_248 = (g_list_2efilter_24s965939768x96753258(v_own_244));
    break;
  }
  case TAG_Just: {
    V v_es_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_248 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2edocpages_2epage_lam0, 1, 1, (V[]){v_es_246}), v_own_244));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2411 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edocpages_2epage_lam1, 1, 1, (V[]){v_c_240}), v_t_248));
  V v_x2_2412 = (g_heff_2ebuild_2edocpages_2eentriesOf(v_t_2411));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2ebuild_2edocpages_2epage_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2epage_str2); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_s_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2epage_str3), v_t_241), heff_strAppend(v_t_243, v_t_2415));
  V v_t_2417 = (g_prelude_2eskipSpaces(v_s_2416, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_s_2416, 0)) - ((int64_t)1ULL));
  V v_t_2419 = (g_prelude_2eskipSpaces(v_s_2416, heff_box_word(v_t_2418), MK_INT(-1LL)));
  V v_t_2420 = heff_strSlice(v_s_2416, v_t_2417, heff_intAdd(v_t_2419, MK_INT(1LL)));
  return heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2edocpages_2epage_str4));
}
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2epage(a[0]);
}
V g_heff_2ebuild_2edocpages_2epage_lam0(V self, V *args) {
  V v_o_247 = args[0];
  V v_es_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_o_247, 0, 2); V a_1 = v_es_246; V r_ = (g_heff_2ebuild_2edriver_2eanyD_24s874235132x1112200348(b_0, a_1)); heff_drop(b_0); heff_drop(v_es_246); r_; });
}
V g_heff_2ebuild_2edocpages_2epage_lam1(V self, V *args) {
  V v_o_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2edriver_2esignatureOf(heff_dup(v_c_240), heff_dup(v_o_249)));
  return (g_heff_2ebuild_2edocpages_2eentryWith(v_c_240, v_o_249, v_t_2410));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str6, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str7, 1, ")");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str9, 3, ".md");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str10, 3, "`](");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eindexLine_str11, 4, "- [`");
Clo g_heff_2ebuild_2edocpages_2eindexLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eindexLine_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eindexLine(V v_c_240) {
top: ;
  V v_m_241 = heff_dup(heff_rfield(v_c_240, 0));
  V v_x2_242 = ({ V b_0 = ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str0); V a_1 = v_m_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2eindexLine_str1), v_m_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_241); r_; });
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = (g_heff_2ebuild_2edocpages_2eheaderComment(heff_rfield(v_c_240, 3)));
  V v_t_2410;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str4))) {
    v_t_2410 = ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str5);
  } else {
    V v_t_248 = (g_heff_2ebuild_2edocpages_2eheaderComment(heff_rfield(v_c_240, 3)));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ebuild_2edocpages_2efirstSentence(a_0)); heff_drop(v_t_248); r_; });
    v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eindexLine_str6), v_t_249);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eindexLine_str7), heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str8)));
  V v_t_2412 = heff_strAppend(heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2edocpages_2eindexLine_str9)), v_t_2411);
  V v_t_2413 = heff_strAppend(heff_get_n(v_c_240, 0, 14), heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eindexLine_str10), v_t_2412));
  return heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eindexLine_str11), v_t_2413);
}
V g_heff_2ebuild_2edocpages_2eindexLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eindexLine(a[0]);
}