// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_exposes 1070285678
#define LBL_fixities 357800079
#define LBL_fmap 9641981
#define LBL_globals 352931696
#define LBL_hmap 9701563
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_packages 1496006433
#define LBL_ret 322331
#define LBL_source 1050636102
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_top 324559
static uint32_t shape_fmap[] = {LBL_fmap};
V g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(void);
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s2022167152x294629972_24rec0_get(void);
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo;
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065(V, V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_clo;
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762(V, V);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_clo;
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449(V);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_clo;
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805(V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_clo;
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0_clo;
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424(V, V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_clo;
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026(V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_clo;
V g_heff_2ebuild_2edocpages_2eentriesOf(V);
V g_heff_2ebuild_2edocpages_2eentriesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentriesOf_clo;
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps(V, V);
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentriesOf_24dps_clo;
V g_heff_2ebuild_2edocpages_2eentryWith(V, V, V);
V g_heff_2ebuild_2edocpages_2eentryWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentryWith_clo;
V g_heff_2ebuild_2edocpages_2efirstParagraph(V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo;
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(V, V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_clo;
V g_heff_2ebuild_2edocpages_2eheaderComment(V);
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo;
V g_heff_2ebuild_2edocpages_2eheaderGo(V);
V g_heff_2ebuild_2edocpages_2eheaderGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderGo_clo;
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps(V, V);
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderGo_24dps_clo;
V g_heff_2ebuild_2edocpages_2eopWord(V);
V g_heff_2ebuild_2edocpages_2eopWord_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eopWord_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edocpages_2epart(V);
V g_heff_2ebuild_2edocpages_2epart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epart_clo;
HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edocpages_2espanNamed_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eexposedIn(V, V);
V g_heff_2ebuild_2edriver_2eexposedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedIn_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eascending_24s918142136x542754241(V, V, V, V, V);
V g_list_2eascending_24s918142136x542754241_entry(V self, V *a);
extern Clo g_list_2eascending_24s918142136x542754241_clo;
V g_list_2edescending_24s379747839x1236130333(V, V, V, V, V);
V g_list_2edescending_24s379747839x1236130333_entry(V self, V *a);
extern Clo g_list_2edescending_24s379747839x1236130333_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1468236620x1316701813(V, V);
V g_list_2efoldl_24s1468236620x1316701813_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1468236620x1316701813_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f904804876x285797696(V, V, V);
V g_list_2emap_24f904804876x285797696_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s631322900x900609068(V);
V g_list_2emap_24s631322900x900609068_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_clo;
V g_list_2emap_24s763976875x1978337183(V);
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s935175472x420697861(V, V, V, V);
V g_list_2emergeRuns_24s935175472x420697861_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s935175472x420697861_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str3, 0, "");
Clo g_heff_2ebuild_2edocpages_2eheaderGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderGo_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eheaderGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str0))) {
      V v_t_243;
      if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str1))) {
        v_t_243 = heff_strSlice(heff_dup(v_l_241), MK_INT(3LL), heff_strLength(v_l_241));
      } else {
        v_t_243 = heff_strSlice(heff_dup(v_l_241), MK_INT(2LL), heff_strLength(v_l_241));
      }
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edocpages_2eheaderGo_24dps(v_rest_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(v_l_241, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str2))) {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str3), heff_hole()});
        V v_u_2411 = (g_heff_2ebuild_2edocpages_2eheaderGo_24dps(v_rest_242, v_cell_2410));
        heff_drop(v_u_2411);
        return v_cell_2410;
      } else {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eheaderGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eheaderGo(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str3, 0, "");
Clo g_heff_2ebuild_2edocpages_2eheaderGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2eheaderGo_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str0))) {
      V v_t_244;
      if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str1))) {
        v_t_244 = heff_strSlice(heff_dup(v_l_242), MK_INT(3LL), heff_strLength(v_l_242));
      } else {
        v_t_244 = heff_strSlice(heff_dup(v_l_242), MK_INT(2LL), heff_strLength(v_l_242));
      }
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(v_l_242, v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str2))) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str3), heff_hole()});
        V v_u_2412 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2411);
        V t_0 = v_rest_243;
        V t_1 = v_u_2412;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edocpages_2eheaderGo_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str3, 1, "\012");
Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderComment_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eheaderComment(V v_src_240) {
top: ;
  V v_t_241 = ({ V a_0 = v_src_240; V b_1 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str1), v_src_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_x2_242 = (g_heff_2ebuild_2edocpages_2eheaderGo(v_t_241));
  V v_s_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_s_245 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_s_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = (g_prelude_2eskipSpaces(v_s_245, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
  V v_t_248 = (g_prelude_2eskipSpaces(v_s_245, heff_box_word(v_t_247), MK_INT(-1LL)));
  return heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
}
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2eheaderComment(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstParagraph_str0, 0, "");
Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstParagraph_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2efirstParagraph(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
    V v_t_245 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_244), MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2edocpages_2efirstParagraph_str0))) {
      heff_drop(v_l_241);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(v_l_241, v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(v_rest_242, v_cell_2411));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2efirstParagraph(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_str0, 0, "");
Clo g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_245), MK_INT(-1LL)));
    V v_t_247 = heff_strSlice(heff_dup(v_l_242), v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_str0))) {
      heff_drop(v_l_242);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_248 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_2410 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_249), MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(v_l_242, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_2412);
      V t_0 = v_rest_243;
      V t_1 = v_u_2413;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(a[0], a1); heff_drop(a1); return r;
}

HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V v_s_240, V v_i_241, V v_code_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd_lent(v_i_241, MK_INT(1LL), 2))) {
    heff_drop(v_i_241);
    heff_drop(v_code_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)96ULL))) {
      V v_t_243 = heff_bool(!(heff_dup(v_code_242) == NTAG(TAG_True)));
      heff_drop(v_code_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_t_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_code_242 = t_2;
      goto top;
    } else {
      if (((heff_dup(v_code_242) == NTAG(TAG_True)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)46ULL)) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_intAdd_lent(v_i_241, MK_INT(1LL), 2), 2)) == ((int64_t)32ULL))))) {
        heff_drop(v_code_242);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_code_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_code_242 = t_2;
        goto top;
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edocpages_2espanNamed_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_sp_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_sp_245)}});
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str2, 2, "\012\012");
Clo g_heff_2ebuild_2edocpages_2epart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2epart_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2epart(V v_text_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(v_text_240, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_text_240, 0)) - ((int64_t)1ULL));
  V v_t_243 = (g_prelude_2eskipSpaces(v_text_240, heff_box_word(v_t_242), MK_INT(-1LL)));
  V v_t_244 = heff_strSlice(heff_dup(v_text_240), v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2edocpages_2epart_str0))) {
    return ((V)&g_heff_2ebuild_2edocpages_2epart_str1);
  } else {
    V v_t_245 = (g_prelude_2eskipSpaces(v_text_240, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_text_240, 0)) - ((int64_t)1ULL));
    V v_t_247 = (g_prelude_2eskipSpaces(v_text_240, heff_box_word(v_t_246), MK_INT(-1LL)));
    V v_t_248 = heff_strSlice(heff_dup(v_text_240), v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
    return heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2edocpages_2epart_str2));
  }
}
V g_heff_2ebuild_2edocpages_2epart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2epart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str0, 2, "lt");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str1, 2, "gt");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str2, 4, "plus");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str3, 5, "minus");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str4, 4, "star");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str5, 5, "slash");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str6, 2, "eq");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str7, 5, "colon");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str8, 3, "dot");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str9, 3, "bar");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str10, 3, "amp");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str11, 5, "caret");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str12, 6, "dollar");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str13, 4, "bang");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str14, 8, "question");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str15, 5, "tilde");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str16, 7, "percent");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str17, 2, "at");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str18, 4, "hash");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str19, 9, "backslash");
Clo g_heff_2ebuild_2edocpages_2eopWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eopWord_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eopWord(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  if ((v_b_240 == ((int64_t)60ULL))) {
    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str0);
  } else {
    if ((v_b_240 == ((int64_t)62ULL))) {
      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str1);
    } else {
      if ((v_b_240 == ((int64_t)43ULL))) {
        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str2);
      } else {
        if ((v_b_240 == ((int64_t)45ULL))) {
          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str3);
        } else {
          if ((v_b_240 == ((int64_t)42ULL))) {
            return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str4);
          } else {
            if ((v_b_240 == ((int64_t)47ULL))) {
              return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str5);
            } else {
              if ((v_b_240 == ((int64_t)61ULL))) {
                return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str6);
              } else {
                if ((v_b_240 == ((int64_t)58ULL))) {
                  return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str7);
                } else {
                  if ((v_b_240 == ((int64_t)46ULL))) {
                    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str8);
                  } else {
                    if ((v_b_240 == ((int64_t)124ULL))) {
                      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str9);
                    } else {
                      if ((v_b_240 == ((int64_t)38ULL))) {
                        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str10);
                      } else {
                        if ((v_b_240 == ((int64_t)94ULL))) {
                          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str11);
                        } else {
                          if ((v_b_240 == ((int64_t)36ULL))) {
                            return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str12);
                          } else {
                            if ((v_b_240 == ((int64_t)33ULL))) {
                              return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str13);
                            } else {
                              if ((v_b_240 == ((int64_t)63ULL))) {
                                return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str14);
                              } else {
                                if ((v_b_240 == ((int64_t)126ULL))) {
                                  return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str15);
                                } else {
                                  if ((v_b_240 == ((int64_t)37ULL))) {
                                    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str16);
                                  } else {
                                    if ((v_b_240 == ((int64_t)64ULL))) {
                                      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str17);
                                    } else {
                                      if ((v_b_240 == ((int64_t)35ULL))) {
                                        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str18);
                                      } else {
                                        if ((v_b_240 == ((int64_t)92ULL))) {
                                          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str19);
                                        } else {
                                          return heff_intShow(heff_box_word(v_b_240));
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edocpages_2eopWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eopWord(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str0, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str5, 3, "op-");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str7, 7, "haskell");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str9, 3, "## ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str10, 3, " {#");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str11, 14, "}\012\012```haskell\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str12, 6, "\012```\012\012");
V g_heff_2ebuild_2edocpages_2eentryWith_lam0(V self, V *args);
V g_heff_2ebuild_2edocpages_2eentryWith_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2eentryWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentryWith_entry, 3, 0};

V g_heff_2ebuild_2edocpages_2eentryWith(V v_c_240, V v_o_241, V v_x3_242) {
top: ;
  V v_fixities_243 = heff_take_field(v_c_240, 11);
  V v_top_244 = heff_take_field(v_c_240, 5);
  V v_source_245 = heff_get_n(v_c_240, 3, 14);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_241, 2);
    heff_drop(v_fixities_243);
    heff_drop_rec(v_top_244, 10);
    heff_drop(v_source_245);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_sig_246 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_x_247 = heff_dup(heff_rfield(v_o_241, 0));
    V v_b_248 = heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2);
    V v_t_2418;
    if ((((((int64_t)65ULL) <= heff_peek_word(v_b_248)) && (heff_peek_word(v_b_248) <= ((int64_t)90ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_b_248)) && (heff_peek_word(v_b_248) <= ((int64_t)122ULL))) || (heff_peek_word(v_b_248) == ((int64_t)95ULL))))) {
      heff_drop(v_b_248);
      v_t_2418 = v_x_247;
    } else {
      heff_drop(v_b_248);
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_x_247, 0)) - ((int64_t)1ULL));
      V v_x2_2415 = (g_list_2emap_24f904804876x285797696(heff_clo_n(g_heff_2ebuild_2edocpages_2eentryWith_lam0, 1, 1, (V[]){v_x_247}), MK_INT(0LL), heff_box_word(v_t_249)));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nil: {
        v_t_2418 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_xs_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
    }
    V v_x_2419 = heff_dup(heff_rfield(v_o_241, 0));
    V v_b_2420 = heff_strByteAt_lent(v_x_2419, MK_INT(0LL), 2);
    V v_t_2427;
    if ((((((int64_t)65ULL) <= heff_peek_word(v_b_2420)) && (heff_peek_word(v_b_2420) <= ((int64_t)90ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_b_2420)) && (heff_peek_word(v_b_2420) <= ((int64_t)122ULL))) || (heff_peek_word(v_b_2420) == ((int64_t)95ULL))))) {
      heff_drop(v_b_2420);
      v_t_2427 = v_x_2419;
    } else {
      heff_drop(v_b_2420);
      int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_x_2419, 0)) - ((int64_t)1ULL));
      V v_x2_2423 = (g_list_2emap_24f904804876x285797696(heff_clo_n(g_heff_2ebuild_2edocpages_2eentryWith_lam1, 1, 1, (V[]){v_x_2419}), MK_INT(0LL), heff_box_word(v_t_2421)));
      V v_t_2426;
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_Nil: {
        v_t_2426 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_2424 = heff_field(v_x2_2423, 0);
        V v_xs_2425 = heff_field(v_x2_2423, 1);
        heff_take_n(v_x2_2423, 3ULL, 2);
        v_t_2426 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str4); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2423);
      }
      v_t_2427 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str5), v_t_2426);
    }
    V v_sig_2428 = heff_dup(v_sig_246);
    V v_t_2429 = (g_prelude_2eskipSpaces(v_sig_246, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2430 = (heff_unbox_word(heff_strLength_lent(v_sig_246, 0)) - ((int64_t)1ULL));
    V v_t_2431 = (g_prelude_2eskipSpaces(v_sig_246, heff_box_word(v_t_2430), MK_INT(-1LL)));
    V v_t_2432 = heff_strSlice(v_sig_246, v_t_2429, heff_intAdd(v_t_2431, MK_INT(1LL)));
    HeffT2 v_t_2433 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fixities_243, heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str6))));
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      V v_t_2444;
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        V v_why_2436 = v_field_2435;
        heff_drop(v_why_2436);
        V v_t_2437 = (g_prelude_2eskipSpaces(v_sig_2428, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_sig_2428, 0)) - ((int64_t)1ULL));
        V v_t_2439 = (g_prelude_2eskipSpaces(v_sig_2428, heff_box_word(v_t_2438), MK_INT(-1LL)));
        v_t_2444 = heff_strSlice(v_sig_2428, v_t_2437, heff_intAdd(v_t_2439, MK_INT(1LL)));
      } else {
        heff_drop(v_sig_2428);
        V v_out_2440 = v_field_2435;
        V v_t_2441 = (g_prelude_2eskipSpaces(v_out_2440, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_out_2440, 0)) - ((int64_t)1ULL));
        V v_t_2443 = (g_prelude_2eskipSpaces(v_out_2440, heff_box_word(v_t_2442), MK_INT(-1LL)));
        v_t_2444 = heff_strSlice(v_out_2440, v_t_2441, heff_intAdd(v_t_2443, MK_INT(1LL)));
      }
      HeffT2 v_t_2445 = ({ V b_0 = heff_get_n(v_o_241, 0, 2); V b_1 = heff_get_n(v_top_244, 6, 10); HeffT2 r_ = (g_heff_2ebuild_2edocpages_2espanNamed_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      {
        V v_field_2447 = v_t_2445.f[1];
        int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
        V v_t_2454;
        if ((v_tag_2446 == ((int64_t)0ULL))) {
          V v_sp_2448 = v_field_2447;
          V v_src_2449 = heff_dup(v_source_245);
          V v_start_2450 = ({ V a_0 = v_source_245; V a_1 = heff_get_n(v_sp_2448, 0, 2); V r_ = (g_heff_2ebuild_2equery_2elineStartOf(a_0, a_1)); heff_drop(v_source_245); r_; });
          V v_t_2451 = ({ V a_0 = v_src_2449; V a_1 = v_start_2450; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(a_0, a_1, a_2)); heff_drop(v_src_2449); r_; });
          V v_t_2452 = (g_list_2emap_24s1819241345x1511673126(v_t_2451));
          V v_t_2453 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2452));
          v_t_2454 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str7); V a_1 = v_t_2453; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_t_2453); r_; });
        } else {
          heff_drop(v_source_245);
          heff_drop(v_field_2447);
          v_t_2454 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str8);
        }
        V v_t_2455 = ({ V a_0 = v_t_2454; V r_ = (g_heff_2ebuild_2edocpages_2epart(a_0)); heff_drop(v_t_2454); r_; });
        V v_t_2456 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str9), v_t_2418), ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str10));
        V v_t_2457 = heff_strAppend(heff_strAppend(v_t_2456, v_t_2427), ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str11));
        V v_t_2458 = heff_strAppend(heff_strAppend(v_t_2457, v_t_2444), ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str12));
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_t_2458, v_t_2455)});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edocpages_2eentryWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentryWith(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edocpages_2eentryWith_lam0(V self, V *args) {
  V v_i_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2411 = v_x_247;
  V v_i_2412 = v_i_2410;
  V v_b_2413 = heff_strByteAt_lent(v_x_2411, v_i_2412, 0);
  if ((((((int64_t)33ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)47ULL))) || (((((int64_t)58ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)64ULL))) || (((((int64_t)91ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)96ULL))) || ((((int64_t)123ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)126ULL))))))) {
    heff_drop(v_b_2413);
    V v_t_2414 = heff_strSlice(v_x_2411, heff_dup(v_i_2412), heff_intAdd(v_i_2412, MK_INT(1LL)));
    return heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str0), v_t_2414);
  } else {
    heff_drop(v_b_2413);
    return heff_strSlice(v_x_2411, heff_dup(v_i_2412), heff_intAdd(v_i_2412, MK_INT(1LL)));
  }
}
V g_heff_2ebuild_2edocpages_2eentryWith_lam1(V self, V *args) {
  V v_i_2422 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edocpages_2eopWord(heff_strByteAt(v_x_2419, v_i_2422)));
}
Clo g_heff_2ebuild_2edocpages_2eentriesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentriesOf_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eentriesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edocpages_2eentriesOf_24dps(v_rest_242, v_cell_244));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eentriesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentriesOf(a[0]);
}
Clo g_heff_2ebuild_2edocpages_2eentriesOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2eentriesOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_rest_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2edocpages_2eentriesOf_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str2, 11, "---\012title: ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str3, 6, "\012---\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str4, 1, "\012");
V g_heff_2ebuild_2edocpages_2epage_lam1(V self, V *args);
V g_heff_2ebuild_2edocpages_2epage_lam0(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2epage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2epage_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2epage(V v_c_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2edocpages_2eheaderComment(heff_rfield(v_c_240, 3)));
  V v_t_242 = ({ V a_0 = v_t_241; V r_ = (g_heff_2ebuild_2edocpages_2epart(a_0)); heff_drop(v_t_241); r_; });
  V v_t_243 = (g_heff_2ebuild_2edriver_2eexposedIn(heff_rfield(v_c_240, 13), heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edocpages_2epage_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), v_t_243));
  V v_x2_2418 = (g_heff_2ebuild_2edocpages_2eentriesOf(v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2ebuild_2edocpages_2epage_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2epage_str1); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2epage_str2), heff_get_n(v_c_240, 0, 14));
  V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2edocpages_2epage_str3)), v_t_242);
  V v_s_2424 = heff_strAppend(v_t_2423, v_t_2421);
  V v_t_2425 = (g_prelude_2eskipSpaces(v_s_2424, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2426 = (heff_unbox_word(heff_strLength_lent(v_s_2424, 0)) - ((int64_t)1ULL));
  V v_t_2427 = (g_prelude_2eskipSpaces(v_s_2424, heff_box_word(v_t_2426), MK_INT(-1LL)));
  V v_t_2428 = heff_strSlice(v_s_2424, v_t_2425, heff_intAdd(v_t_2427, MK_INT(1LL)));
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2edocpages_2epage_str4));
}
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2epage(a[0]);
}
V g_heff_2ebuild_2edocpages_2epage_lam1(V self, V *args) {
  V v_k_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_d_2411 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_2410)));
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = ({ V a_0 = v_m_249; V a_1 = v_k_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_249); heff_drop(v_k_2410); r_; });
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      heff_drop(v_d_2411);
      V v_x_2415 = v_field_2414;
      return v_x_2415;
    } else {
      heff_drop(v_field_2414);
      return v_d_2411;
    }
  }
}
V g_heff_2ebuild_2edocpages_2epage_lam0(V self, V *args) {
  V v_o_244 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_c_245 = heff_dup(v_c_240);
  V v_o_246 = heff_dup(v_o_244);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_c_245, 5)), 0, 10);
  V v_t_248 = ({ V b_0 = heff_get_n(v_t_247, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_249 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1468236620x1316701813(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_t_2416 = (g_heff_2ebuild_2edriver_2esigEntry(v_c_245, heff_clo_n(g_heff_2ebuild_2edocpages_2epage_lam1, 1, 1, (V[]){v_m_249}), v_o_246));
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edocpages_2eentryWith(v_c_240, v_o_244, v_t_2416));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str1, 68, "heff doc: no src/ here: run it at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str2, 68, "heff doc: no src/ here: run it at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str3, 3, "src");
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam7(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam2(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449(V v_given_240) {
top: ;
  switch (heff_tag_of(v_given_240)) {
  case TAG_Nil: {
    V v_path_241 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str0)));
    V v_t_242 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_241; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_244 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_242, ((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam0_clo)});
    return heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam1, 2, 2, (V[]){v_a_244, v_path_241});
  }
  case TAG_Cons: {
    V v_t_2454 = (g_list_2emap_24s1420651609x666245096(v_given_240));
    return (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2454, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_240);
  }
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449(a[0]);
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam0(V self, V *args) {
  V v_r_243 = args[0];
  return v_r_243;
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_drop(v_x_2427);
  heff_clo_take(self, 1);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_245, heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam4, 1, 1, (V[]){v_k_246})));
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_drop(v_x_2443);
  heff_clo_take(self, 1);
  V f_ = v_k_246;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_drop(v_x_2436);
  V v_t_2437 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_245, heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam6, 1, 1, (V[]){v_k_246})));
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam7(V self, V *args) {
  V v_n_2445 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2445));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_241, v_t_2446));
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 0ULL, 1);
    heff_clo_take(self, 3);
    heff_drop(v_path_241);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str1), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam3, 1, 2, (V[]){v_hd_245, v_k_246})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2412, 0);
    V v_ru_24x_2412_24Right = heff_take_reuse_n(v_x_2412, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 0ULL, 1);
      heff_clo_take(self, 3);
      heff_drop(v_path_241);
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str2), NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_at_n(v_ru_24x_2412_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2428_24Left, TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam5, 1, 2, (V[]){v_hd_245, v_k_246})));
    }
    case TAG_Right: {
      V v_x_2444 = heff_field(v_y_2428, 0);
      heff_take_n(v_y_2428, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2412_24Right, 1);
      heff_clo_take(self, 3);
      V v_x_2447 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam7, 1, 1, (V[]){v_path_241}), v_x_2444));
      V v_x_2448 = (g_list_2emap_24s219049803x1458391381(v_x_2447));
      heff_drop(v_x_2448);
      V v_t_2449 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_str3)});
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
      V v_t_2451 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s725938111x2086911199(v_t_2450, NTAG(TAG_Nil)));
      V f_ = v_t_2451;
      heff_room[0] = v_hd_245;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_a_244 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_244})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2411, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449_lam2, 1, 3, (V[]){v_hd_245, v_k_246, v_path_241})));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_str0, 4, "heff");
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam7(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam7, 2, 0};
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam9(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam8(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam2(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_entry, 5, 0};

V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065(V v_chk_240, V v_x2_241, V v_acc_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_chk_240);
    heff_drop(v_z_243);
    V v_x_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_tail(v_z_244, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_rest_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_chk_240), heff_dup(v_f_246), MK_INT(0LL), ((V)&g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
    return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam1, 1, 6, (V[]){v_z_243, v_f_246, v_acc_242, v_chk_240, v_rest_247, v_z_244})));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam7(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_cs_2421 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_z_243 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  heff_drop(v_x_2429);
  V v_t_2436;
  heff_clo_take(self, 7);
  if (heff_intLt_c(MK_INT(0LL), v_x_2418)) {
    V v_found_2430 = ({ V a_0 = v_cs_2421; V r_ = (g_heff_2ebuild_2edriver_2elastChecked(a_0)); heff_drop(v_cs_2421); r_; });
    heff_drop(v_found_2430);
    v_t_2436 = v_acc_242;
  } else {
    V v_bad_2431 = (g_list_2eany_24s1740858080x874135214(v_cs_2421));
    HeffT2 v_t_2432 = ({ V a_0 = v_cs_2421; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_2421); r_; });
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((heff_dup(v_bad_2431) == NTAG(TAG_True))) {
        heff_drop(v_bad_2431);
        heff_drop(v_field_2434);
        v_t_2436 = v_acc_242;
      } else {
        heff_drop(v_bad_2431);
        if ((v_tag_2433 == ((int64_t)0ULL))) {
          V v_c_2435 = v_field_2434;
          v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2435, v_acc_242});
        } else {
          heff_drop(v_field_2434);
          v_t_2436 = v_acc_242;
        }
      }
    }
  }
  return (g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065(v_chk_240, v_rest_247, v_t_2436, v_z_243, v_z_244));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_cs_2421 = heff_env(self)[3];
  V v_acc_242 = heff_env(self)[4];
  V v_chk_240 = heff_env(self)[5];
  V v_rest_247 = heff_env(self)[6];
  V v_z_244 = heff_env(self)[7];
  heff_drop(v_x_2426);
  heff_clo_take(self, 8);
  V v_t_2427 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam9, 1, 7, (V[]){v_x_2418, v_cs_2421, v_acc_242, v_chk_240, v_rest_247, v_z_243, v_z_244})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_chk_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  V v_cs_2421 = heff_get_n(v_x_2420, 0, 2);
  V v_t_2422 = (g_list_2eany_24s1740858080x874135214(v_cs_2421));
  V v_c_2425;
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_t_2422);
    v_c_2425 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s48543521x1749305721_clo), 1, (V[]){heff_dup(v_cs_2421)}));
  } else {
    heff_drop(v_t_2422);
    v_c_2425 = ((V)&g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam7_clo);
  }
  heff_clo_take(self, 7);
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam8, 1, 8, (V[]){v_x_2411, v_z_243, v_x_2418, v_cs_2421, v_acc_242, v_chk_240, v_rest_247, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_chk_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(v_x_2417));
  V f_ = v_t_2419;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam6, 1, 7, (V[]){v_z_243, v_x_2411, v_x_2418, v_acc_242, v_chk_240, v_rest_247, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_chk_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2415, heff_dup(heff_rfield(v_x_2414, 4))));
  heff_clo_take(self, 7);
  V v_x_2417 = (g_list_2efoldl_24s571074576x1179600767(v_x_2414, v_t_2416));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_str0), heff_dup(heff_rfield(v_x_2417, 1)), MK_INT(0LL), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam5, 1, 7, (V[]){v_x_2417, v_z_243, v_x_2411, v_acc_242, v_chk_240, v_rest_247, v_z_244})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam4, 1, 7, (V[]){v_x_2414, v_z_243, v_x_2411, v_acc_242, v_chk_240, v_rest_247, v_z_244})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_chk_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2413, v_f_246, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam3, 1, 6, (V[]){v_z_243, v_x_2411, v_acc_242, v_chk_240, v_rest_247, v_z_244})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_chk_240 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_c_2412 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065_lam2, 1, 7, (V[]){v_f_246, v_z_243, v_x_2411, v_acc_242, v_chk_240, v_rest_247, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_str0, 5, "win32");
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam2(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam2, 1, 0};
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_entry, 4, 0};

V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805(V v_path_240, V v_text_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam1, 1, 4, (V[]){v_path_240, v_hd_242, v_text_241, v_k_243})));
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam2(V self, V *args) {
  V v_r_2427 = args[0];
  return v_r_2427;
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam3(V self, V *args) {
  V v_x_2434 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Left: {
    V v_x_2435 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Left = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_path_240; V a_1 = v_text_241; V a_2 = v_hd_242; V a_3 = v_k_243; V b_4 = heff_tag_re_n(v_ru_24x_2434_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2435}); V r_ = (g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  }
  case TAG_Right: {
    V v_y_2436 = heff_field(v_x_2434, 0);
    V v_ru_24x_2434_24Right = heff_take_reuse_n(v_x_2434, 1ULL, 1);
    switch (heff_tag_of(v_y_2436)) {
    case TAG_Left: {
      V v_err_2437 = heff_field(v_y_2436, 0);
      V v_ru_24y_2436_24Left = heff_take_reuse_n(v_y_2436, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2434_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_path_240; V a_1 = v_text_241; V a_2 = v_hd_242; V a_3 = v_k_243; V b_4 = heff_tag_re_n(v_ru_24y_2436_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2437}); V r_ = (g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    case TAG_Right: {
      V v_x_2438 = heff_field(v_y_2436, 0);
      heff_take_n(v_y_2436, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_path_240; V a_1 = v_text_241; V a_2 = v_hd_242; V a_3 = v_k_243; V b_4 = heff_tag_at_n(v_ru_24x_2434_24Right, TAG_Right, 1, (V[]){v_x_2438}); V r_ = (g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    default: return heff_nomatch(v_y_2436);
    }
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_text_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_st_2412;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_str0))) {
    v_st_2412 = NTAG(TAG_Windows);
  } else {
    v_st_2412 = NTAG(TAG_Posix);
  }
  HeffT3 v_t_2413 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2412), heff_dup(v_path_240)));
  {
    V v_field_2414 = v_t_2413.f[0];
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    V v_d_2417 = v_field_2414;
    V v_a_2418 = v_field_2415;
    V v_xs_2419 = v_field_2416;
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    V v_xs_2421 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2420; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2420); r_; });
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    V v_t_2423 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2417, v_a_2418, v_t_2422});
    V v_s_2424 = ({ V a_0 = v_st_2412; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2412); heff_drop_tag(v_t_2423, 3); r_; });
    V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2424));
    V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
    V v_a_2428 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2426, ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam2_clo)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    heff_clo_take(self, 4);
    return (g_co_2eop_24s1896221640x2141527803(v_t_2433, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805_lam3, 1, 4, (V[]){v_path_240, v_text_241, v_hd_242, v_k_243})));
  }
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str5, 3, ".md");
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam2(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_entry, 5, 0};

V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424(V v_w_240, V v_dir_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_dir_241);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s535099379x685970669(v_t_2413, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam1, 1, 6, (V[]){v_c_245, v_dir_241, v_p_243, v_w_240, v_rest_246, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_g_2437 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_tr(heff_call(v_g_2437, 1, (V[]){v_x_2439}));
  V f_ = heff_get_n(v_hd_2436, 0, 3);
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam3(V self, V *args) {
  V v_g_2437 = args[0];
  V v_m_2438 = args[1];
  V v_hd_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  args[0] = v_m_2438;
  args[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam4, 1, 2, (V[]){v_g_2437, v_hd_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam5(V self, V *args) {
  V v_c_2441 = args[0];
  V v_hd_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_get_n(v_hd_2436, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam6(V self, V *args) {
  V v_a_2444 = args[0];
  V v_lit_2428 = heff_env(self)[0];
  V v_lit_2429 = heff_env(self)[1];
  V v_lit_2430 = heff_env(self)[2];
  V v_lit_2431 = heff_env(self)[3];
  V v_lit_2432 = heff_env(self)[4];
  heff_drop(v_a_2444);
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424(v_lit_2428, v_lit_2429, v_lit_2430, v_lit_2431, v_lit_2432));
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_drop(v_x_2427);
  V v_lit_2428 = heff_dup(v_w_240);
  heff_clo_take(self, 5);
  V v_lit_2429 = v_dir_241;
  V v_lit_2430 = v_rest_246;
  V v_lit_2431 = heff_dup(v_p_243);
  V v_lit_2432 = v_p_244;
  V v_t_2433 = heff_tag_n(TAG_Complete, 2, (V[]){v_w_240, NTAG(TAG_MkUnit)});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_p_2435 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2434});
  V v_hd_2436 = v_p_243;
  V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(g_co_2e_3c_2b_3e_24s2086886503x1354141756_get(), 1)), 4, (V[]){heff_dup(g_co_2eop_24s2022167152x294629972_24rec0_get()), heff_rec_n(1, shape_fmap, (V[]){heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam3, 2, 1, (V[]){heff_dup(v_hd_2436)})}), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam5, 1, 1, (V[]){heff_dup(v_hd_2436)}), v_p_2435}));
  V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2442}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  heff_room[0] = v_t_2443;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam6, 1, 5, (V[]){v_lit_2428, v_lit_2429, v_lit_2430, v_lit_2431, v_lit_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_dir_241 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_w_240 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  V v_m_2416 = heff_dup(heff_rfield(v_c_245, 0));
  V v_x2_2417 = ({ V a_0 = v_m_2416; V b_1 = ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str2), v_m_2416, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_m_2416); heff_drop(b_1); r_; });
  V v_t_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str4); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_b_2421 = heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_str5));
  V v_t_2422 = (g_std_2epath_2eparse(heff_dup(v_st_2415), heff_dup(v_dir_241)));
  V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2415), v_b_2421));
  V v_t_2424 = (g_std_2epath_2ejoin(v_t_2422, v_t_2423));
  V v_t_2425 = ({ V a_0 = v_st_2415; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2415); heff_drop(v_t_2424); r_; });
  heff_clo_take(self, 6);
  V v_t_2426 = (g_heff_2ebuild_2edocpages_2epage(v_c_245));
  return (g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805(v_t_2425, v_t_2426, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424_lam2, 1, 5, (V[]){v_w_240, v_dir_241, v_rest_246, v_p_243, v_p_244})));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str3, 13, "writing pages");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str4, 8, "index.md");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str7, 127, "---\012title: API\012sidebar:\012  label: Modules\012---\012\012The modules, each a page: what it exposes, with its type and its documentation.\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str8, 10, "heff doc: ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str9, 27, " pages and their index, in ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str10, 1, "\012");
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam2(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam2, 1, 0};
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_entry, 4, 0};

V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026(V v_x1_240, V v_cs_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_x2_244 = (g_list_2emap_24s763976875x1978337183(v_cs_241));
    V v_str_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_str_247 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_str_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_tag_n(TAG_Write, 2, (V[]){v_str_247, NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_z_242, v_z_243));
  }
  case TAG_Just: {
    V v_dir_2414 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam0_clo)})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s535099379x685970669(v_t_2421, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam1, 1, 4, (V[]){v_cs_241, v_z_242, v_dir_2414, v_z_243})));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam0(V self, V *args) {
  V v_s_2415 = args[0];
  return v_s_2415;
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam2(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam6(V self, V *args) {
  V v_x_2456 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_drop(v_x_2456);
  heff_clo_take(self, 4);
  V v_t_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_cs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_cs_241); r_; });
  V v_t_2458 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str8), heff_intShow(v_t_2457));
  V v_str_2459 = heff_strAppend(heff_strAppend(v_t_2458, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str9)), v_dir_2414);
  V v_t_2460 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2459, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str10)), NTAG(TAG_MkUnit)});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2465}), v_z_242, v_z_243));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam5(V self, V *args) {
  V v_x_2453 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_dir_2414 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_drop(v_x_2453);
  heff_clo_take(self, 5);
  V v_t_2454 = heff_tag_n(TAG_End, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam6, 1, 4, (V[]){v_cs_241, v_dir_2414, v_z_242, v_z_243})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2423 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_x_2429 = heff_env(self)[4];
  V v_z_243 = heff_env(self)[5];
  heff_drop(v_x_2430);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2423), heff_dup(v_dir_2414)));
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2423), ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str4)));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  heff_clo_take(self, 6);
  V v_t_2434 = ({ V a_0 = v_st_2423; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2423); heff_drop(v_t_2433); r_; });
  V v_t_2448;
  switch (heff_tag_of(v_cs_241)) {
  case TAG_Nil: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2435 = heff_dup(heff_field(v_cs_241, 0));
    V v_xs_2436 = heff_dup(heff_field(v_cs_241, 1));
    V v_lit_2437 = MK_INT(0LL);
    V v_lit_2438 = MK_INT(0LL);
    V v_x_2439 = v_x_2435;
    V v_x3_2440 = v_xs_2436;
    V v_t_2447;
    switch (heff_tag_of(v_x3_2440)) {
    case TAG_Nil: {
      heff_drop(v_lit_2437);
      heff_drop(v_lit_2438);
      V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
      v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_y_2442 = heff_field(v_x3_2440, 0);
      V v_ys_2443 = heff_field(v_x3_2440, 1);
      V v_ru_24x3_2440_24Cons = heff_take_reuse_n(v_x3_2440, 3ULL, 2);
      V v_a_2444 = heff_strCompare(heff_dup(heff_rfield(v_x_2439, 0)), heff_dup(heff_rfield(v_y_2442, 0)));
      if ((heff_intLt_c_lent(v_a_2444, v_lit_2437, 0) || heff_intEq_c_lent(v_a_2444, v_lit_2438, 0))) {
        heff_drop(v_a_2444);
        V v_t_2445 = heff_tag_at_n(v_ru_24x3_2440_24Cons, TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
        v_t_2447 = (g_list_2eascending_24s918142136x542754241(v_lit_2437, v_lit_2438, heff_dup(v_y_2442), heff_tag_n(TAG_Cons, 2, (V[]){v_y_2442, v_t_2445}), v_ys_2443));
      } else {
        heff_drop(v_a_2444);
        V v_t_2446 = heff_tag_at_n(v_ru_24x3_2440_24Cons, TAG_Cons, 2, (V[]){v_x_2439, NTAG(TAG_Nil)});
        v_t_2447 = (g_list_2edescending_24s379747839x1236130333(v_lit_2437, v_lit_2438, heff_dup(v_y_2442), heff_tag_n(TAG_Cons, 2, (V[]){v_y_2442, v_t_2446}), v_ys_2443));
      }
      break;
    }
    default: heff_nomatch(v_x3_2440);
    }
    v_t_2448 = (g_list_2emergeRuns_24s935175472x420697861(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2447));
    break;
  }
  default: heff_nomatch(v_cs_241);
  }
  V v_x2_2449 = (g_list_2emap_24s631322900x900609068(v_t_2448));
  V v_t_2452;
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_Nil: {
    v_t_2452 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_xs_2451 = heff_field(v_x2_2449, 1);
    heff_take_n(v_x2_2449, 3ULL, 2);
    v_t_2452 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str6); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2449);
  }
  return (g_heff_2ebuild_2edocpages_2edocPageWritten_24s1361515200x758160805(v_t_2434, heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str7), v_t_2452), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam5, 1, 5, (V[]){v_x_2429, v_z_242, v_cs_241, v_dir_2414, v_z_243})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_dir_2414 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_st_2423 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2edocpages_2edocPagesWritten_24s709675120x2072208424(heff_dup(v_x_2429), heff_dup(v_dir_2414), heff_dup(v_cs_241), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam4, 1, 6, (V[]){v_st_2423, v_dir_2414, v_cs_241, v_z_242, v_x_2429, v_z_243})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_dir_2414 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_st_2423;
  if (heff_strEq_c(v_x_2422, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str2))) {
    v_st_2423 = NTAG(TAG_Windows);
  } else {
    v_st_2423 = NTAG(TAG_Posix);
  }
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_241));
  V v_total_2425 = heff_intAdd(v_t_2424, MK_INT(1LL));
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_str3), v_total_2425, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam2_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2428, heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026_lam3, 1, 5, (V[]){v_dir_2414, v_cs_241, v_z_242, v_st_2423, v_z_243})));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_str0, 16, "checking modules");
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam2(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam2, 1, 0};
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam1(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam0(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762(V v_out_240, V v_given_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2edocpages_2edocFiles_24s1549124608x191702449(v_given_241));
  return heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam0, 2, 2, (V[]){v_c_242, v_out_240});
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762(a[0], a[1]);
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam2(V self, V *args) {
  V v_t_247 = args[0];
  return v_t_247;
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam6(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_drop(v_x_2415);
  heff_clo_take(self, 4);
  V v_t_2416 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_2411); r_; });
  V v_t_2417 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_245; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_245); r_; });
  if (heff_intLt_c(v_t_2416, v_t_2417)) {
    V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_243, v_k_244));
  } else {
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_out_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_drop(v_x_2414);
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2edocpages_2edocWritten_24s2033543525x2129209026(v_out_240, heff_dup(v_x_2411), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam6, 1, 4, (V[]){v_x_2411, v_x_245, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_out_240 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_End, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam5, 1, 5, (V[]){v_out_240, v_x_2411, v_hd_243, v_x_245, v_k_244})));
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_out_240 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2edocpages_2edocChecked_24s884912543x460668065(heff_dup(v_x_2410), heff_dup(v_x_245), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam4, 1, 5, (V[]){v_x_2410, v_hd_243, v_out_240, v_x_245, v_k_244})));
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_out_240 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_total_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_245));
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_str0), v_total_246, ((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam2_clo)})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(v_t_249, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam3, 1, 4, (V[]){v_x_245, v_hd_243, v_out_240, v_k_244})));
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_out_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1774325264x1884328762_lam1, 1, 3, (V[]){v_hd_243, v_out_240, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}