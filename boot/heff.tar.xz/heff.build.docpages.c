// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_aliases 1464806715
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_exposes 1070285678
#define LBL_fixities 357800079
#define LBL_globals 352931696
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_source 1050636102
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_top 324559
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883(V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_clo;
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954(V, V, V);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_clo;
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039(V, V);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_clo;
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243(V, V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_clo;
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269(V, V, V, V, V, V);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_clo;
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995(V, V, V);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_clo;
V g_heff_2ebuild_2edocpages_2eentriesOf(V);
V g_heff_2ebuild_2edocpages_2eentriesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentriesOf_clo;
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps(V, V);
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentriesOf_24dps_clo;
V g_heff_2ebuild_2edocpages_2eentryWith(V, V, V);
V g_heff_2ebuild_2edocpages_2eentryWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eentryWith_clo;
V g_heff_2ebuild_2edocpages_2efirstParagraph(V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo;
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(V, V);
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_clo;
V g_heff_2ebuild_2edocpages_2eheaderComment(V);
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo;
V g_heff_2ebuild_2edocpages_2eheaderGo(V);
V g_heff_2ebuild_2edocpages_2eheaderGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderGo_clo;
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps(V, V);
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eheaderGo_24dps_clo;
V g_heff_2ebuild_2edocpages_2eopWord(V);
V g_heff_2ebuild_2edocpages_2eopWord_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2eopWord_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2edocpages_2epart(V);
V g_heff_2ebuild_2edocpages_2epart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epart_clo;
HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edocpages_2espanNamed_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eexposedIn(V, V);
V g_heff_2ebuild_2edriver_2eexposedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexposedIn_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2esigEntry(V, V, V);
V g_heff_2ebuild_2edriver_2esigEntry_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2esigEntry_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(V, V, V);
V g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eascending_24s918142136x542754241(V, V, V, V, V);
V g_list_2eascending_24s918142136x542754241_entry(V self, V *a);
extern Clo g_list_2eascending_24s918142136x542754241_clo;
V g_list_2edescending_24s379747839x1236130333(V, V, V, V, V);
V g_list_2edescending_24s379747839x1236130333_entry(V self, V *a);
extern Clo g_list_2edescending_24s379747839x1236130333_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1468236620x1316701813(V, V);
V g_list_2efoldl_24s1468236620x1316701813_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1468236620x1316701813_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f904804876x285797696(V, V, V);
V g_list_2emap_24f904804876x285797696_entry(V self, V *a);
extern Clo g_list_2emap_24f904804876x285797696_clo;
V g_list_2emap_24s1420651609x666245096(V);
V g_list_2emap_24s1420651609x666245096_entry(V self, V *a);
extern Clo g_list_2emap_24s1420651609x666245096_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s631322900x900609068(V);
V g_list_2emap_24s631322900x900609068_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_clo;
V g_list_2emap_24s763976875x1978337183(V);
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s935175472x420697861(V, V, V, V);
V g_list_2emergeRuns_24s935175472x420697861_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s935175472x420697861_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_str3, 0, "");
Clo g_heff_2ebuild_2edocpages_2eheaderGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderGo_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eheaderGo(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str0))) {
      V v_t_243;
      if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str1))) {
        v_t_243 = heff_strSlice(heff_dup(v_l_241), MK_INT(3LL), heff_strLength(v_l_241));
      } else {
        v_t_243 = heff_strSlice(heff_dup(v_l_241), MK_INT(2LL), heff_strLength(v_l_241));
      }
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edocpages_2eheaderGo_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    } else {
      V v_t_246 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_247), MK_INT(-1LL)));
      V v_t_249 = heff_strSlice(v_l_241, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
      if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str2))) {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2eheaderGo_str3), heff_hole()});
        V v_u_2411 = (g_heff_2ebuild_2edocpages_2eheaderGo_24dps(v_rest_242, heff_dup(v_cell_2410)));
        heff_drop(v_u_2411);
        return v_cell_2410;
      } else {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eheaderGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eheaderGo(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str0, 2, "--");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str1, 3, "-- ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str3, 0, "");
Clo g_heff_2ebuild_2edocpages_2eheaderGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2eheaderGo_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str0))) {
      V v_t_244;
      if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str1))) {
        v_t_244 = heff_strSlice(heff_dup(v_l_242), MK_INT(3LL), heff_strLength(v_l_242));
      } else {
        v_t_244 = heff_strSlice(heff_dup(v_l_242), MK_INT(2LL), heff_strLength(v_l_242));
      }
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(v_l_242, v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str2))) {
        V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2eheaderGo_24dps_str3), heff_hole()});
        V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
        heff_drop(v_u_2412);
        V t_0 = v_rest_243;
        V t_1 = v_cell_2411;
        v_x1_240 = t_0;
        v_d_241 = t_1;
        goto top;
      } else {
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eheaderGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eheaderGo_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eheaderComment_str3, 1, "\012");
Clo g_heff_2ebuild_2edocpages_2eheaderComment_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eheaderComment_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eheaderComment(V v_src_240) {
top: ;
  V v_t_241 = ({ V a_0 = v_src_240; V b_1 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str1), v_src_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_x2_242 = (g_heff_2ebuild_2edocpages_2eheaderGo(v_t_241));
  V v_s_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_s_245 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_s_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eheaderComment_str3); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_t_246 = (g_prelude_2eskipSpaces(v_s_245, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
  V v_t_248 = (g_prelude_2eskipSpaces(v_s_245, heff_box_word(v_t_247), MK_INT(-1LL)));
  return heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
}
V g_heff_2ebuild_2edocpages_2eheaderComment_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2eheaderComment(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstParagraph_str0, 0, "");
Clo g_heff_2ebuild_2edocpages_2efirstParagraph_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstParagraph_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2efirstParagraph(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
    V v_t_245 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_244), MK_INT(-1LL)));
    V v_t_246 = heff_strSlice(heff_dup(v_l_241), v_t_243, heff_intAdd(v_t_245, MK_INT(1LL)));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2edocpages_2efirstParagraph_str0))) {
      heff_drop(v_l_241);
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      V v_t_247 = (g_prelude_2eskipSpaces(v_l_241, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_l_241, 0)) - ((int64_t)1ULL));
      V v_t_249 = (g_prelude_2eskipSpaces(v_l_241, heff_box_word(v_t_248), MK_INT(-1LL)));
      V v_t_2410 = heff_strSlice(v_l_241, v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
      V v_u_2412 = (g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(v_rest_242, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2efirstParagraph_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2efirstParagraph(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_str0, 0, "");
Clo g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
    V v_t_246 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_245), MK_INT(-1LL)));
    V v_t_247 = heff_strSlice(heff_dup(v_l_242), v_t_244, heff_intAdd(v_t_246, MK_INT(1LL)));
    if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_str0))) {
      heff_drop(v_l_242);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_t_248 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
      V v_t_2410 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_249), MK_INT(-1LL)));
      V v_t_2411 = heff_strSlice(v_l_242, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_rest_243;
      V t_1 = v_cell_2412;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2efirstParagraph_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2efirstParagraph_24dps(a[0], a[1]);
}

HeffT2 g_heff_2ebuild_2edocpages_2esentenceEnd_24cpr(V v_s_240, V v_i_241, V v_code_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) {
    heff_drop(v_i_241);
    heff_drop(v_code_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)96ULL))) {
      V v_t_243 = heff_bool(!(heff_dup(v_code_242) == NTAG(TAG_True)));
      heff_drop(v_code_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_t_243;
      v_s_240 = t_0;
      v_i_241 = t_1;
      v_code_242 = t_2;
      goto top;
    } else {
      if (((heff_dup(v_code_242) == NTAG(TAG_True)) ? 0 : ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)46ULL)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)32ULL))))) {
        heff_drop(v_code_242);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_i_241}});
      } else {
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_code_242;
        v_s_240 = t_0;
        v_i_241 = t_1;
        v_code_242 = t_2;
        goto top;
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2edocpages_2espanNamed_24cpr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_sp_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c_lent(v_x_240, v_y_244, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_sp_245)}});
      } else {
        V t_0 = v_x_240;
        V t_1 = v_rest_243;
        v_x_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epart_str2, 2, "\012\012");
Clo g_heff_2ebuild_2edocpages_2epart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2epart_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2epart(V v_text_240) {
top: ;
  V v_t_241 = (g_prelude_2eskipSpaces(v_text_240, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_242 = (heff_unbox_word(heff_strLength_lent(v_text_240, 0)) - ((int64_t)1ULL));
  V v_t_243 = (g_prelude_2eskipSpaces(v_text_240, heff_box_word(v_t_242), MK_INT(-1LL)));
  V v_t_244 = heff_strSlice(heff_dup(v_text_240), v_t_241, heff_intAdd(v_t_243, MK_INT(1LL)));
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2edocpages_2epart_str0))) {
    return ((V)&g_heff_2ebuild_2edocpages_2epart_str1);
  } else {
    V v_t_245 = (g_prelude_2eskipSpaces(v_text_240, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_text_240, 0)) - ((int64_t)1ULL));
    V v_t_247 = (g_prelude_2eskipSpaces(v_text_240, heff_box_word(v_t_246), MK_INT(-1LL)));
    V v_t_248 = heff_strSlice(heff_dup(v_text_240), v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
    return heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2edocpages_2epart_str2));
  }
}
V g_heff_2ebuild_2edocpages_2epart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2edocpages_2epart(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str0, 2, "lt");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str1, 2, "gt");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str2, 4, "plus");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str3, 5, "minus");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str4, 4, "star");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str5, 5, "slash");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str6, 2, "eq");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str7, 5, "colon");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str8, 3, "dot");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str9, 3, "bar");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str10, 3, "amp");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str11, 5, "caret");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str12, 6, "dollar");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str13, 4, "bang");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str14, 8, "question");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str15, 5, "tilde");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str16, 7, "percent");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str17, 2, "at");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str18, 4, "hash");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eopWord_str19, 9, "backslash");
Clo g_heff_2ebuild_2edocpages_2eopWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eopWord_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eopWord(V v_box_24b_240) {
  int64_t v_b_240 = heff_unbox_word(v_box_24b_240);
top: ;
  if ((v_b_240 == ((int64_t)60ULL))) {
    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str0);
  } else {
    if ((v_b_240 == ((int64_t)62ULL))) {
      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str1);
    } else {
      if ((v_b_240 == ((int64_t)43ULL))) {
        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str2);
      } else {
        if ((v_b_240 == ((int64_t)45ULL))) {
          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str3);
        } else {
          if ((v_b_240 == ((int64_t)42ULL))) {
            return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str4);
          } else {
            if ((v_b_240 == ((int64_t)47ULL))) {
              return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str5);
            } else {
              if ((v_b_240 == ((int64_t)61ULL))) {
                return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str6);
              } else {
                if ((v_b_240 == ((int64_t)58ULL))) {
                  return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str7);
                } else {
                  if ((v_b_240 == ((int64_t)46ULL))) {
                    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str8);
                  } else {
                    if ((v_b_240 == ((int64_t)124ULL))) {
                      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str9);
                    } else {
                      if ((v_b_240 == ((int64_t)38ULL))) {
                        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str10);
                      } else {
                        if ((v_b_240 == ((int64_t)94ULL))) {
                          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str11);
                        } else {
                          if ((v_b_240 == ((int64_t)36ULL))) {
                            return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str12);
                          } else {
                            if ((v_b_240 == ((int64_t)33ULL))) {
                              return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str13);
                            } else {
                              if ((v_b_240 == ((int64_t)63ULL))) {
                                return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str14);
                              } else {
                                if ((v_b_240 == ((int64_t)126ULL))) {
                                  return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str15);
                                } else {
                                  if ((v_b_240 == ((int64_t)37ULL))) {
                                    return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str16);
                                  } else {
                                    if ((v_b_240 == ((int64_t)64ULL))) {
                                      return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str17);
                                    } else {
                                      if ((v_b_240 == ((int64_t)35ULL))) {
                                        return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str18);
                                      } else {
                                        if ((v_b_240 == ((int64_t)92ULL))) {
                                          return ((V)&g_heff_2ebuild_2edocpages_2eopWord_str19);
                                        } else {
                                          return heff_intShow(heff_box_word(v_b_240));
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2edocpages_2eopWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eopWord(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str0, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str3, 3, "## ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str4, 3, " {#");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str6, 1, "-");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str7, 3, "op-");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str8, 14, "}\012\012```haskell\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str9, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str10, 6, "\012```\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str11, 7, "haskell");
HEFF_LIT(g_heff_2ebuild_2edocpages_2eentryWith_str12, 0, "");
V g_heff_2ebuild_2edocpages_2eentryWith_lam0(V self, V *args);
V g_heff_2ebuild_2edocpages_2eentryWith_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2eentryWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentryWith_entry, 3, 0};

V g_heff_2ebuild_2edocpages_2eentryWith(V v_c_240, V v_o_241, V v_x3_242) {
top: ;
  V v_fixities_243 = heff_take_field(v_c_240, 11);
  V v_top_244 = heff_take_field(v_c_240, 5);
  V v_source_245 = heff_get_n(v_c_240, 3, 14);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_241, 2);
    heff_drop(v_fixities_243);
    heff_drop_rec(v_top_244, 10);
    heff_drop(v_source_245);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_sig_246 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_x_247 = heff_dup(heff_rfield(v_o_241, 0));
    V v_b_248 = heff_strByteAt_lent(v_x_247, MK_INT(0LL), 2);
    V v_t_2418;
    if ((((((int64_t)65ULL) <= heff_peek_word(v_b_248)) && (heff_peek_word(v_b_248) <= ((int64_t)90ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_b_248)) && (heff_peek_word(v_b_248) <= ((int64_t)122ULL))) || (heff_peek_word(v_b_248) == ((int64_t)95ULL))))) {
      heff_drop(v_b_248);
      v_t_2418 = v_x_247;
    } else {
      heff_drop(v_b_248);
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_x_247, 0)) - ((int64_t)1ULL));
      V v_x2_2415 = (g_list_2emap_24f904804876x285797696(heff_clo_n(g_heff_2ebuild_2edocpages_2eentryWith_lam0, 1, 1, (V[]){v_x_247}), MK_INT(0LL), heff_box_word(v_t_249)));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_Nil: {
        v_t_2418 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_xs_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str2); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2415);
      }
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str3), v_t_2418), ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str4));
    V v_x_2420 = heff_dup(heff_rfield(v_o_241, 0));
    V v_b_2421 = heff_strByteAt_lent(v_x_2420, MK_INT(0LL), 2);
    V v_t_2428;
    if ((((((int64_t)65ULL) <= heff_peek_word(v_b_2421)) && (heff_peek_word(v_b_2421) <= ((int64_t)90ULL))) || (((((int64_t)97ULL) <= heff_peek_word(v_b_2421)) && (heff_peek_word(v_b_2421) <= ((int64_t)122ULL))) || (heff_peek_word(v_b_2421) == ((int64_t)95ULL))))) {
      heff_drop(v_b_2421);
      v_t_2428 = v_x_2420;
    } else {
      heff_drop(v_b_2421);
      int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_x_2420, 0)) - ((int64_t)1ULL));
      V v_x2_2424 = (g_list_2emap_24f904804876x285797696(heff_clo_n(g_heff_2ebuild_2edocpages_2eentryWith_lam1, 1, 1, (V[]){v_x_2420}), MK_INT(0LL), heff_box_word(v_t_2422)));
      V v_t_2427;
      switch (heff_tag_of(v_x2_2424)) {
      case TAG_Nil: {
        v_t_2427 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2425 = heff_field(v_x2_2424, 0);
        V v_xs_2426 = heff_field(v_x2_2424, 1);
        heff_take_n(v_x2_2424, 3ULL, 2);
        v_t_2427 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str6); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2424);
      }
      v_t_2428 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str7), v_t_2427);
    }
    V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2428), ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str8));
    V v_sig_2430 = heff_dup(v_sig_246);
    V v_t_2431 = (g_prelude_2eskipSpaces(v_sig_246, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_sig_246, 0)) - ((int64_t)1ULL));
    V v_t_2433 = (g_prelude_2eskipSpaces(v_sig_246, heff_box_word(v_t_2432), MK_INT(-1LL)));
    V v_t_2434 = heff_strSlice(v_sig_246, v_t_2431, heff_intAdd(v_t_2433, MK_INT(1LL)));
    HeffT2 v_t_2435 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fixities_243, heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str9))));
    V v_t_2446;
    {
      V v_field_2437 = v_t_2435.f[1];
      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
      if ((v_tag_2436 == ((int64_t)0ULL))) {
        V v_why_2438 = v_field_2437;
        heff_drop(v_why_2438);
        V v_t_2439 = (g_prelude_2eskipSpaces(v_sig_2430, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2440 = (heff_unbox_word(heff_strLength_lent(v_sig_2430, 0)) - ((int64_t)1ULL));
        V v_t_2441 = (g_prelude_2eskipSpaces(v_sig_2430, heff_box_word(v_t_2440), MK_INT(-1LL)));
        v_t_2446 = heff_strSlice(v_sig_2430, v_t_2439, heff_intAdd(v_t_2441, MK_INT(1LL)));
      } else {
        heff_drop(v_sig_2430);
        V v_out_2442 = v_field_2437;
        V v_t_2443 = (g_prelude_2eskipSpaces(v_out_2442, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2444 = (heff_unbox_word(heff_strLength_lent(v_out_2442, 0)) - ((int64_t)1ULL));
        V v_t_2445 = (g_prelude_2eskipSpaces(v_out_2442, heff_box_word(v_t_2444), MK_INT(-1LL)));
        v_t_2446 = heff_strSlice(v_out_2442, v_t_2443, heff_intAdd(v_t_2445, MK_INT(1LL)));
      }
    }
    V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2429, v_t_2446), ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str10));
    HeffT2 v_t_2448 = ({ V b_0 = heff_get_n(v_o_241, 0, 2); V b_1 = heff_get_n(v_top_244, 6, 10); HeffT2 r_ = (g_heff_2ebuild_2edocpages_2espanNamed_24cpr(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    V v_t_2457;
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        V v_sp_2451 = v_field_2450;
        V v_src_2452 = heff_dup(v_source_245);
        V v_start_2453 = ({ V a_0 = v_source_245; V a_1 = heff_get_n(v_sp_2451, 0, 2); V r_ = (g_heff_2ebuild_2equery_2elineStartOf(a_0, a_1)); heff_drop(v_source_245); r_; });
        V v_t_2454 = ({ V a_0 = v_src_2452; V a_1 = v_start_2453; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(a_0, a_1, a_2)); heff_drop(v_src_2452); r_; });
        V v_t_2455 = (g_list_2emap_24s1819241345x1511673126(v_t_2454));
        V v_t_2456 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2455));
        v_t_2457 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str11); V a_1 = v_t_2456; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_t_2456); r_; });
      } else {
        heff_drop(v_source_245);
        heff_drop(v_field_2450);
        v_t_2457 = ((V)&g_heff_2ebuild_2edocpages_2eentryWith_str12);
      }
    }
    V v_t_2458 = ({ V a_0 = v_t_2457; V r_ = (g_heff_2ebuild_2edocpages_2epart(a_0)); heff_drop(v_t_2457); r_; });
    return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_t_2447, v_t_2458)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2edocpages_2eentryWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentryWith(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edocpages_2eentryWith_lam0(V self, V *args) {
  V v_i_2410 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2411 = v_x_247;
  V v_i_2412 = v_i_2410;
  V v_b_2413 = heff_strByteAt_lent(v_x_2411, v_i_2412, 0);
  if ((((((int64_t)33ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)47ULL))) || (((((int64_t)58ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)64ULL))) || (((((int64_t)91ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)96ULL))) || ((((int64_t)123ULL) <= heff_peek_word(v_b_2413)) && (heff_peek_word(v_b_2413) <= ((int64_t)126ULL))))))) {
    heff_drop(v_b_2413);
    V v_t_2414 = heff_strSlice(v_x_2411, heff_dup(v_i_2412), heff_intAdd(v_i_2412, MK_INT(1LL)));
    return heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2eentryWith_str0), v_t_2414);
  } else {
    heff_drop(v_b_2413);
    return heff_strSlice(v_x_2411, heff_dup(v_i_2412), heff_intAdd(v_i_2412, MK_INT(1LL)));
  }
}
V g_heff_2ebuild_2edocpages_2eentryWith_lam1(V self, V *args) {
  V v_i_2423 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edocpages_2eopWord(heff_strByteAt(v_x_2420, v_i_2423)));
}
Clo g_heff_2ebuild_2edocpages_2eentriesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentriesOf_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2eentriesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2edocpages_2eentriesOf_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eentriesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentriesOf(a[0]);
}
Clo g_heff_2ebuild_2edocpages_2eentriesOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2eentriesOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2edocpages_2eentriesOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2eentriesOf_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str0, 11, "---\012title: ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str1, 6, "\012---\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2epage_str4, 1, "\012");
V g_heff_2ebuild_2edocpages_2epage_lam1(V self, V *args);
V g_heff_2ebuild_2edocpages_2epage_lam0(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2epage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2epage_entry, 1, 0};

V g_heff_2ebuild_2edocpages_2epage(V v_c_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2epage_str0), heff_dup(heff_rfield(v_c_240, 0)));
  V v_t_242 = (g_heff_2ebuild_2edocpages_2eheaderComment(heff_rfield(v_c_240, 3)));
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2ebuild_2edocpages_2epart(a_0)); heff_drop(v_t_242); r_; });
  V v_t_244 = heff_strAppend(heff_strAppend(v_t_241, ((V)&g_heff_2ebuild_2edocpages_2epage_str1)), v_t_243);
  V v_t_245 = (g_heff_2ebuild_2edriver_2eexposedIn(heff_rfield(v_c_240, 13), heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2edocpages_2epage_lam0, 1, 1, (V[]){v_c_240}), v_t_245));
  V v_x2_2420 = (g_heff_2ebuild_2edocpages_2eentriesOf(v_t_2419));
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_heff_2ebuild_2edocpages_2epage_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2epage_str3); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_s_2424 = heff_strAppend(v_t_244, v_t_2423);
  V v_t_2425 = (g_prelude_2eskipSpaces(v_s_2424, MK_INT(0LL), MK_INT(1LL)));
  int64_t v_t_2426 = (heff_unbox_word(heff_strLength_lent(v_s_2424, 0)) - ((int64_t)1ULL));
  V v_t_2427 = (g_prelude_2eskipSpaces(v_s_2424, heff_box_word(v_t_2426), MK_INT(-1LL)));
  V v_t_2428 = heff_strSlice(v_s_2424, v_t_2425, heff_intAdd(v_t_2427, MK_INT(1LL)));
  return heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2edocpages_2epage_str4));
}
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2epage(a[0]);
}
V g_heff_2ebuild_2edocpages_2epage_lam1(V self, V *args) {
  V v_k_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_2413 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_k_2412)));
  HeffT2 v_t_2414 = ({ V a_0 = v_m_2411; V a_1 = v_k_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_2411); heff_drop(v_k_2412); r_; });
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_d_2413);
      V v_x_2417 = v_field_2416;
      return v_x_2417;
    } else {
      heff_drop(v_field_2416);
      return v_d_2413;
    }
  }
}
V g_heff_2ebuild_2edocpages_2epage_lam0(V self, V *args) {
  V v_o_246 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_247 = heff_dup(v_c_240);
  V v_o_248 = heff_dup(v_o_246);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_c_247, 5)), 0, 10);
  V v_t_2410 = ({ V b_0 = heff_get_n(v_t_249, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_m_2411 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1468236620x1316701813(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2418 = (g_heff_2ebuild_2edriver_2esigEntry(v_c_247, heff_clo_n(g_heff_2ebuild_2edocpages_2epage_lam1, 1, 1, (V[]){v_m_2411}), v_o_248));
  return (g_heff_2ebuild_2edocpages_2eentryWith(v_c_240, v_o_246, v_t_2418));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_str1, 68, "heff doc: no src/ here: run it at the project's root, or give FILEs\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_str2, 3, "src");
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam1(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam2(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_entry, 2, 0};

V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039(V v_e_240, V v_given_241) {
top: ;
  switch (heff_tag_of(v_given_241)) {
  case TAG_Nil: {
    V v_path_242 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_str0)));
    V v_c_243 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_242));
    V v_t_244 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_249 = heff_tr(heff_call(v_c_243, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam0_clo)}));
    return heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam2, 2, 2, (V[]){v_c_249, v_e_240});
  }
  case TAG_Cons: {
    V v_t_2436 = (g_list_2emap_24s1420651609x666245096(v_given_241));
    return (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2436, NTAG(TAG_Nil)));
  }
  default: return heff_nomatch(v_given_241);
  }
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039(a[0], a[1]);
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_246 = (g_list_2emap_24s219049803x1458391381(v_x_245));
  return heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam1, 2, 1, (V[]){v_x_246});
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_hd_2410, heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam5, 1, 1, (V[]){v_k_2411})));
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Left: {
    V v_ru_24x_2412_24Left = heff_take_reuse_n(v_x_2412, 0ULL, 1);
    V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_str1), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_at_n(v_ru_24x_2412_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_2410), heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam4, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2412, 0ULL, 1);
    V v_t_2431 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), ((V)&g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_str2)});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    V v_t_2433 = (g_heff_2ebuild_2etesting_2etestFilesGo_24s548303603x2016023902(v_e_240, v_t_2432, NTAG(TAG_Nil)));
    V f_ = v_t_2433;
    heff_room[0] = v_hd_2410;
    heff_room[1] = v_k_2411;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039_lam3, 1, 3, (V[]){v_e_240, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_str0, 4, "heff");
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam0(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam2(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam2, 1, 0};
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam7(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam7, 2, 0};
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam9(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam8(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_entry, 4, 0};

V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883(V v_e_240, V v_chk_241, V v_x2_242, V v_acc_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_chk_241);
    V v_x_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
    return heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam0, 2, 1, (V[]){v_x_244});
  }
  case TAG_Cons: {
    V v_f_247 = heff_field(v_x2_242, 0);
    V v_rest_248 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam1, 2, 5, (V[]){v_chk_241, v_f_247, v_e_240, v_acc_243, v_rest_248});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_x_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam2(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam7(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_cs_2419 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_chk_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_hd_249 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2427);
  V v_t_2434;
  if (heff_intLt_c(MK_INT(0LL), v_x_2416)) {
    V v_found_2428 = ({ V a_0 = v_cs_2419; V r_ = (g_heff_2ebuild_2edriver_2elastChecked(a_0)); heff_drop(v_cs_2419); r_; });
    heff_drop(v_found_2428);
    v_t_2434 = v_acc_243;
  } else {
    V v_bad_2429 = (g_list_2eany_24s1740858080x874135214(v_cs_2419));
    HeffT2 v_t_2430 = ({ V a_0 = v_cs_2419; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_2419); r_; });
    {
      V v_field_2432 = v_t_2430.f[1];
      int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
      if ((heff_dup(v_bad_2429) == NTAG(TAG_True))) {
        heff_drop(v_bad_2429);
        heff_drop(v_field_2432);
        v_t_2434 = v_acc_243;
      } else {
        heff_drop(v_bad_2429);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_c_2433 = v_field_2432;
          v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2433, v_acc_243});
        } else {
          heff_drop(v_field_2432);
          v_t_2434 = v_acc_243;
        }
      }
    }
  }
  V v_t_2435 = (g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883(v_e_240, v_chk_241, v_rest_248, v_t_2434));
  V f_ = v_t_2435;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_cs_2419 = heff_env(self)[4];
  V v_acc_243 = heff_env(self)[5];
  V v_chk_241 = heff_env(self)[6];
  V v_rest_248 = heff_env(self)[7];
  V v_k_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam9, 1, 8, (V[]){v_x_2416, v_cs_2419, v_acc_243, v_e_240, v_chk_241, v_rest_248, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_chk_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_cs_2419 = heff_get_n(v_x_2418, 0, 2);
  V v_t_2420 = (g_list_2eany_24s1740858080x874135214(v_cs_2419));
  V v_c_2423;
  if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
    heff_drop(v_t_2420);
    v_c_2423 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo), 2, (V[]){heff_dup(v_e_240), heff_dup(v_cs_2419)}));
  } else {
    heff_drop(v_t_2420);
    v_c_2423 = ((V)&g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam7_clo);
  }
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam8, 1, 9, (V[]){v_x_2414, v_e_240, v_hd_249, v_x_2416, v_cs_2419, v_acc_243, v_chk_241, v_rest_248, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_chk_241 = heff_env(self)[5];
  V v_rest_248 = heff_env(self)[6];
  V v_k_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2417 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), v_x_2415));
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam6, 1, 8, (V[]){v_e_240, v_hd_249, v_x_2414, v_x_2416, v_acc_243, v_chk_241, v_rest_248, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_chk_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_str0), heff_dup(heff_rfield(v_x_2415, 1)), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam5, 1, 8, (V[]){v_e_240, v_x_2415, v_hd_249, v_x_2414, v_acc_243, v_chk_241, v_rest_248, v_k_2410})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_chk_241 = heff_env(self)[4];
  V v_rest_248 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), v_f_247, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam4, 1, 7, (V[]){v_e_240, v_hd_249, v_x_2414, v_acc_243, v_chk_241, v_rest_248, v_k_2410})));
}
V g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_chk_241 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_chk_241), heff_dup(v_f_247), MK_INT(0LL), ((V)&g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2413, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883_lam3, 1, 7, (V[]){v_e_240, v_f_247, v_hd_249, v_acc_243, v_chk_241, v_rest_248, v_k_2410})));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_str1, 23, "heff doc: cannot write ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_str2, 1, "\012");
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam2(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam2, 3, 0};
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam4(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam4, 3, 0};
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_entry, 5, 0};

V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243(V v_e_240, V v_path_241, V v_text_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam1, 1, 5, (V[]){v_path_241, v_e_240, v_hd_243, v_text_242, v_k_244})));
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2431 = args[1];
  V v_k_2432 = args[2];
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2439 = args[1];
  V v_k_2440 = args[2];
  heff_drop(v_hd_2439);
  V f_ = v_k_2440;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2442)) {
  case TAG_Left: {
    V v_ru_24x_2442_24Left = heff_take_reuse_n(v_x_2442, 0ULL, 1);
    V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_str1), v_path_241), ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_str2));
    V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2444, NTAG(TAG_MkUnit)});
    V v_t_2446 = heff_tag_at_n(v_ru_24x_2442_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam6, 1, 3, (V[]){v_e_240, v_hd_243, v_k_244})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2442, 0ULL, 1);
    heff_drop(v_path_241);
    heff_drop(v_e_240);
    heff_drop(v_hd_243);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2442);
  }
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam3(V self, V *args) {
  V v_x_2434 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_text_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2434);
  V v_path_2435 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_241)));
  V v_c_2436 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2435; V a_2 = v_text_242; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2435); r_; });
  V v_t_2437 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2441 = heff_tr(heff_call(v_c_2436, 2, (V[]){v_t_2437, ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam4_clo)}));
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam5, 1, 4, (V[]){v_path_241, v_e_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_text_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2414;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  HeffT3 v_t_2415 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2414), heff_dup(v_path_241)));
  V v_t_2425;
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    V v_d_2419 = v_field_2416;
    V v_a_2420 = v_field_2417;
    V v_xs_2421 = v_field_2418;
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    V v_xs_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2422; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2422); r_; });
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
    v_t_2425 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2419, v_a_2420, v_t_2424});
  }
  V v_s_2426 = ({ V a_0 = v_st_2414; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2425); r_; });
  V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2426));
  V v_c_2428 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2427; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2427); r_; });
  V v_t_2429 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2433 = heff_tr(heff_call(v_c_2428, 2, (V[]){v_t_2429, ((V)&g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam2_clo)}));
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243_lam3, 1, 5, (V[]){v_path_241, v_e_240, v_text_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str5, 3, ".md");
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam0(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam0, 1, 0};
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam2(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam1(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_entry, 6, 0};

V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269(V v_e_240, V v_w_241, V v_dir_242, V v_x3_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_w_241);
    heff_drop(v_dir_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2415, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam1, 1, 7, (V[]){v_c_246, v_dir_242, v_e_240, v_p_244, v_w_241, v_rest_247, v_p_245})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_w_241 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2432);
  return (g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269(v_e_240, v_w_241, v_dir_242, v_rest_247, v_p_244, v_p_245));
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_w_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_w_241), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam3, 1, 6, (V[]){v_e_240, v_w_241, v_dir_242, v_rest_247, v_p_244, v_p_245})));
}
V g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_c_246 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_w_241 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2417;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_m_2418 = heff_dup(heff_rfield(v_c_246, 0));
  V v_x2_2419 = ({ V a_0 = v_m_2418; V b_1 = ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str1); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str2), v_m_2418, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_m_2418); heff_drop(b_1); r_; });
  V v_t_2422;
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nil: {
    v_t_2422 = ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_xs_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    v_t_2422 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str4); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2419);
  }
  V v_b_2423 = heff_strAppend(v_t_2422, ((V)&g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_str5));
  V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_dir_242)));
  V v_t_2425 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_b_2423));
  V v_t_2426 = (g_std_2epath_2ejoin(v_t_2424, v_t_2425));
  V v_t_2427 = ({ V a_0 = v_st_2417; V a_1 = v_t_2426; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2426); r_; });
  V v_t_2428 = (g_heff_2ebuild_2edocpages_2epage(v_c_246));
  return (g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243(heff_dup(v_e_240), v_t_2427, v_t_2428, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269_lam2, 1, 6, (V[]){v_w_241, v_e_240, v_p_244, v_dir_242, v_rest_247, v_p_245})));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str3, 13, "writing pages");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str4, 8, "index.md");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str7, 127, "---\012title: API\012sidebar:\012  label: Modules\012---\012\012The modules, each a page: what it exposes, with its type and its documentation.\012\012");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str8, 10, "heff doc: ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str9, 27, " pages and their index, in ");
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str10, 1, "\012");
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam1(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam1, 1, 0};
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam3(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam3, 1, 0};
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam7(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam2(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam0(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_entry, 3, 0};

V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995(V v_e_240, V v_x1_241, V v_cs_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nothing: {
    V v_x2_243 = (g_list_2emap_24s763976875x1978337183(v_cs_242));
    V v_str_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_str_246 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_str_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_247 = heff_tag_n(TAG_Write, 2, (V[]){v_str_246, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return heff_tail(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  }
  case TAG_Just: {
    V v_dir_2414 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam0, 2, 3, (V[]){v_e_240, v_cs_242, v_dir_2414});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  return v_s_2417;
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam3(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2460);
  V v_t_2461 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_cs_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_cs_242); r_; });
  V v_t_2462 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str8), heff_intShow(v_t_2461));
  V v_str_2463 = heff_strAppend(heff_strAppend(v_t_2462, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str9)), v_dir_2414);
  V v_t_2464 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2463, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str10)), NTAG(TAG_MkUnit)});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam6(V self, V *args) {
  V v_x_2457 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  V v_dir_2414 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2457);
  V v_t_2458 = heff_tag_n(TAG_End, 2, (V[]){v_x_2432, NTAG(TAG_MkUnit)});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam7, 1, 5, (V[]){v_cs_242, v_dir_2414, v_e_240, v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2426 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_x_2432 = heff_env(self)[5];
  V v_k_2416 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_std_2epath_2eparse(heff_dup(v_st_2426), heff_dup(v_dir_2414)));
  V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_2426), ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str4)));
  V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
  V v_t_2437 = ({ V a_0 = v_st_2426; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2426); heff_drop(v_t_2436); r_; });
  V v_t_2451;
  switch (heff_tag_of(v_cs_242)) {
  case TAG_Nil: {
    v_t_2451 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_2438 = heff_dup(heff_field(v_cs_242, 0));
    V v_xs_2439 = heff_dup(heff_field(v_cs_242, 1));
    V v_lit_2440 = MK_INT(0LL);
    V v_lit_2441 = MK_INT(0LL);
    V v_x_2442 = v_x_2438;
    V v_x3_2443 = v_xs_2439;
    V v_t_2450;
    switch (heff_tag_of(v_x3_2443)) {
    case TAG_Nil: {
      heff_drop(v_lit_2440);
      heff_drop(v_lit_2441);
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2442, NTAG(TAG_Nil)});
      v_t_2450 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      V v_y_2445 = heff_field(v_x3_2443, 0);
      V v_ys_2446 = heff_field(v_x3_2443, 1);
      V v_ru_24x3_2443_24Cons = heff_take_reuse_n(v_x3_2443, 3ULL, 2);
      V v_a_2447 = heff_strCompare(heff_dup(heff_rfield(v_x_2442, 0)), heff_dup(heff_rfield(v_y_2445, 0)));
      if ((heff_intLt_c_lent(v_a_2447, v_lit_2440, 0) || heff_intEq_c_lent(v_a_2447, v_lit_2441, 0))) {
        heff_drop(v_a_2447);
        V v_t_2448 = heff_tag_at_n(v_ru_24x3_2443_24Cons, TAG_Cons, 2, (V[]){v_x_2442, NTAG(TAG_Nil)});
        v_t_2450 = (g_list_2eascending_24s918142136x542754241(v_lit_2440, v_lit_2441, heff_dup(v_y_2445), heff_tag_n(TAG_Cons, 2, (V[]){v_y_2445, v_t_2448}), v_ys_2446));
      } else {
        heff_drop(v_a_2447);
        V v_t_2449 = heff_tag_at_n(v_ru_24x3_2443_24Cons, TAG_Cons, 2, (V[]){v_x_2442, NTAG(TAG_Nil)});
        v_t_2450 = (g_list_2edescending_24s379747839x1236130333(v_lit_2440, v_lit_2441, heff_dup(v_y_2445), heff_tag_n(TAG_Cons, 2, (V[]){v_y_2445, v_t_2449}), v_ys_2446));
      }
      break;
    }
    default: heff_nomatch(v_x3_2443);
    }
    v_t_2451 = (g_list_2emergeRuns_24s935175472x420697861(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2450));
    break;
  }
  default: heff_nomatch(v_cs_242);
  }
  V v_x2_2452 = (g_list_2emap_24s631322900x900609068(v_t_2451));
  V v_t_2455;
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_Nil: {
    v_t_2455 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_xs_2454 = heff_field(v_x2_2452, 1);
    heff_take_n(v_x2_2452, 3ULL, 2);
    v_t_2455 = ({ V a_0 = ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str6); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2452);
  }
  V v_t_2456 = heff_strAppend(((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str7), v_t_2455);
  return (g_heff_2ebuild_2edocpages_2edocPageWritten_24s160549941x1196100243(heff_dup(v_e_240), v_t_2437, v_t_2456, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam6, 1, 6, (V[]){v_x_2432, v_e_240, v_hd_2415, v_cs_242, v_dir_2414, v_k_2416})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_dir_2414 = heff_env(self)[1];
  V v_cs_242 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_st_2426 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2edocpages_2edocPagesWritten_24s2034549651x555023269(heff_dup(v_e_240), heff_dup(v_x_2432), heff_dup(v_dir_2414), heff_dup(v_cs_242), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam5, 1, 7, (V[]){v_st_2426, v_dir_2414, v_cs_242, v_e_240, v_hd_2415, v_x_2432, v_k_2416})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2415 = heff_env(self)[2];
  V v_dir_2414 = heff_env(self)[3];
  V v_k_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2426;
  if (heff_strEq_c(v_x_2425, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str2))) {
    v_st_2426 = NTAG(TAG_Windows);
  } else {
    v_st_2426 = NTAG(TAG_Posix);
  }
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_242));
  V v_total_2428 = heff_intAdd(v_t_2427, MK_INT(1LL));
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_str3), v_total_2428, ((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam3_clo)})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2431, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam4, 1, 6, (V[]){v_e_240, v_dir_2414, v_cs_242, v_hd_2415, v_st_2426, v_k_2416})));
}
V g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_cs_242 = heff_env(self)[1];
  V v_dir_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam1_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2424, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995_lam2, 1, 5, (V[]){v_cs_242, v_e_240, v_hd_2415, v_dir_2414, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_str0, 16, "checking modules");
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam2(V self, V *args); static Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam2, 1, 0};
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam6(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam5(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam4(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam3(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam1(V self, V *args);
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam0(V self, V *args);
Clo g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_entry, 3, 0};

V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954(V v_e_240, V v_out_241, V v_given_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2edocpages_2edocFiles_24s1970002009x802358039(heff_dup(v_e_240), v_given_242));
  return heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam0, 2, 3, (V[]){v_c_243, v_e_240, v_out_241});
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2418);
  V v_t_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_2413; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_2413); r_; });
  V v_t_2420 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  if (heff_intLt_c(v_t_2419, v_t_2420)) {
    V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_244, v_k_245));
  } else {
    heff_drop(v_e_240);
    heff_drop(v_hd_244);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_out_241 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2416);
  V v_c_2417 = heff_tr(g_heff_2ebuild_2edocpages_2edocWritten_24s2000640409x1336754995(heff_dup(v_e_240), v_out_241, heff_dup(v_x_2413)));
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam6, 1, 5, (V[]){v_x_2413, v_x_246, v_e_240, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_out_241 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2414 = heff_tag_n(TAG_End, 2, (V[]){v_x_2411, NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam5, 1, 6, (V[]){v_e_240, v_out_241, v_x_2413, v_hd_244, v_x_246, v_k_245})));
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_out_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2412 = (g_heff_2ebuild_2edocpages_2edocChecked_24s722390514x1212626883(heff_dup(v_e_240), heff_dup(v_x_2411), heff_dup(v_x_246), NTAG(TAG_Nil)));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam4, 1, 6, (V[]){v_x_2411, v_e_240, v_hd_244, v_out_241, v_x_246, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_out_241 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_total_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_246));
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_str0), v_total_247, ((V)&g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam2_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam3, 1, 5, (V[]){v_e_240, v_x_246, v_hd_244, v_out_241, v_k_245})));
}
V g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_out_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2edocpages_2edocCmd_24s1887588307x638851954_lam1, 1, 4, (V[]){v_e_240, v_hd_244, v_out_241, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}