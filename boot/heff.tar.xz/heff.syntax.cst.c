// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Catch 6517
#define TAG_DData 48360
#define TAG_DEqn 7245
#define TAG_DFixity 43809
#define TAG_DImport 15253
#define TAG_DPrimitive 59284
#define TAG_DSig 20444
#define TAG_DTest 4640
#define TAG_DTheory 52633
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_ELet 43397
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_F32 16337
#define TAG_Get 18914
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_MkLetHead 58143
#define TAG_MkSep 6724
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sum 30935
#define TAG_Throw 56084
#define TAG_Tup 31899
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_app 306331
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blank 295177582
#define LBL_caseE 295790383
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_doE 309140
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_first 298798794
#define LBL_i 323
#define LBL_ifE 313666
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lambda 837049074
#define LBL_letE 9813585
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_opExpr 935619233
#define LBL_patAtom 1586746071
#define LBL_patHead 1586939750
#define LBL_pattern 1588251091
#define LBL_raw 322210
#define LBL_ret 322331
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_userOps 84709677
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE[] = {LBL_expr, LBL_opExpr, LBL_userOps, LBL_app, LBL_atom, LBL_pattern, LBL_patHead, LBL_patAtom, LBL_lambda, LBL_caseE, LBL_ifE, LBL_doE, LBL_letE};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_ret__bind__malg[] = {LBL_ret, LBL_bind, LBL_malg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eanonymousSumF(V, V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_clo;
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(V, V);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo;
V g_heff_2esyntax_2ecst_2earrowRhsF(V, V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_clo;
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V, V);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatTok(V, V, V);
V g_heff_2esyntax_2ecst_2eatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatTok_clo;
V g_heff_2esyntax_2ecst_2eatomBase(V, V);
V g_heff_2esyntax_2ecst_2eatomBase_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_clo;
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo;
V g_heff_2esyntax_2ecst_2eatomF(V, V, V);
V g_heff_2esyntax_2ecst_2eatomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_clo;
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V, V);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo;
V g_heff_2esyntax_2ecst_2eblockGo(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo;
V g_heff_2esyntax_2ecst_2ebracesF(V, V, V);
V g_heff_2esyntax_2ecst_2ebracesF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_clo;
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(V, V);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo;
V g_heff_2esyntax_2ecst_2ecaseExprF(V, V, V);
V g_heff_2esyntax_2ecst_2ecaseExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecaseExprF_clo;
V g_heff_2esyntax_2ecst_2echeckAltNames(V, V);
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edataAlternative(V, V);
V g_heff_2esyntax_2ecst_2edataAlternative_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataAlternative_clo;
V g_heff_2esyntax_2ecst_2edataDecl(V, V, V);
V g_heff_2esyntax_2ecst_2edataDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataDecl_clo;
V g_heff_2esyntax_2ecst_2edataLast(V, V, V, V);
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataLast_clo;
V g_heff_2esyntax_2ecst_2edataParam(V, V);
V g_heff_2esyntax_2ecst_2edataParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edataParam_clo;
V g_heff_2esyntax_2ecst_2edeclAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclAt_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2edeclaredAt(V);
V g_heff_2esyntax_2ecst_2edeclaredAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredAt_clo;
V g_heff_2esyntax_2ecst_2edeclaredTwo(V, V);
V g_heff_2esyntax_2ecst_2edeclaredTwo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredTwo_clo;
V g_heff_2esyntax_2ecst_2edefaultedF(V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_clo;
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_clo;
V g_heff_2esyntax_2ecst_2eendBefore(V, V);
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eendBefore_clo;
V g_heff_2esyntax_2ecst_2eexpectAnn(V, V);
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectPunct(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF(V, V, V);
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2eexprHead(V, V);
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_clo;
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo;
V g_heff_2esyntax_2ecst_2efieldDefault(V, V);
V g_heff_2esyntax_2ecst_2efieldDefault_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldDefault_clo;
V g_heff_2esyntax_2ecst_2efieldsGo(V, V, V);
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efieldsGo_clo;
V g_heff_2esyntax_2ecst_2efirstD(V);
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstD_clo;
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2efirstP(V);
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstP_clo;
V g_heff_2esyntax_2ecst_2efixityRest(V, V, V);
V g_heff_2esyntax_2ecst_2efixityRest_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efixityRest_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eifExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eifExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifExprF_clo;
V g_heff_2esyntax_2ecst_2einBrackets(V, V, V);
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2einBrackets_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elamBinders(V, V, V, V);
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinders_clo;
V g_heff_2esyntax_2ecst_2elambdaF(V, V, V);
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elambdaF_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2elastP(V);
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastP_clo;
V g_heff_2esyntax_2ecst_2eletExprF(V, V, V);
V g_heff_2esyntax_2ecst_2eletExprF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletExprF_clo;
V g_heff_2esyntax_2ecst_2eletHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletHeadF_clo;
V g_heff_2esyntax_2ecst_2eletStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eletStmtF_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo;
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V, V, V);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emanyParams(V, V, V);
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyParams_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eopLoopF(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_clo;
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V, V, V, V);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo;
V g_heff_2esyntax_2ecst_2eoperandsF(V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_clo;
V g_heff_2esyntax_2ecst_2eparensF(V, V, V);
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_clo;
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(V, V);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo;
V g_heff_2esyntax_2ecst_2epatAtomF(V, V, V);
V g_heff_2esyntax_2ecst_2epatAtomF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatAtomF_clo;
V g_heff_2esyntax_2ecst_2epatHeadF(V, V, V);
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatHeadF_clo;
V g_heff_2esyntax_2ecst_2epatternF(V, V, V);
V g_heff_2esyntax_2ecst_2epatternF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2epatternF_clo;
V g_heff_2esyntax_2ecst_2eprimitiveDecl(V, V, V);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo;
V g_heff_2esyntax_2ecst_2eprogramGo(V, V);
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eprogramGo_clo;
V g_heff_2esyntax_2ecst_2ereadH_get(void);
V g_heff_2esyntax_2ecst_2ereadSumAlg(V, V);
V g_heff_2esyntax_2ecst_2ereadSumAlg_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ereadSumAlg_clo;
V g_heff_2esyntax_2ecst_2erecordPatF(V, V, V);
V g_heff_2esyntax_2ecst_2erecordPatF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2erecordPatF_clo;
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(V);
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_clo;
V g_heff_2esyntax_2ecst_2esepGo(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo;
V g_heff_2esyntax_2ecst_2eskipDecl(V);
V g_heff_2esyntax_2ecst_2eskipDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipDecl_clo;
V g_heff_2esyntax_2ecst_2eskipFrom(V);
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipFrom_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2estatementF(V, V, V);
V g_heff_2esyntax_2ecst_2estatementF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estatementF_clo;
V g_heff_2esyntax_2ecst_2etheoryDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo;
V g_heff_2esyntax_2ecst_2etheoryField(V, V);
V g_heff_2esyntax_2ecst_2etheoryField_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etheoryField_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etypeDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etypeDecl_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
Clo g_heff_2esyntax_2ecst_2ereadSumAlg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadSumAlg_entry, 2, 0};

V g_heff_2esyntax_2ecst_2ereadSumAlg(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_InL: {
    V v_t_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InL = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_t_242)) {
    case TAG_Get: {
      V v_k_243 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_t_244 = heff_tr(heff_call(v_k_243, 1, (V[]){heff_dup(v_p_241)}));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_t_244}), v_p_241});
    }
    case TAG_Put: {
      V v_s2_245 = heff_field(v_t_242, 0);
      V v_x_246 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24Put = heff_take_reuse_n(v_t_242, 3ULL, 2);
      heff_drop(v_p_241);
      return heff_tag_at_n(v_ru_24t_242_24Put, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InL, TAG_Right, 1, (V[]){v_x_246}), v_s2_245});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  case TAG_InR: {
    V v_q_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24InR = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_q_247)) {
    case TAG_Throw: {
      V v_d_248 = heff_field(v_q_247, 0);
      heff_take_n(v_q_247, 1ULL, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24InR, TAG_Left, 1, (V[]){v_d_248}), v_p_241});
    }
    case TAG_Catch: {
      V v_c_249 = heff_field(v_q_247, 0);
      V v_h_2410 = heff_field(v_q_247, 1);
      heff_take_n(v_q_247, 3ULL, 2);
      heff_drop_cell(v_ru_24x1_240_24InR, 1);
      V v_r_2411 = heff_tr(heff_call(v_c_249, 1, (V[]){v_p_241}));
      switch (heff_tag_of(v_r_2411)) {
      case TAG_MkPair: {
        V v_r1_2412 = heff_dup(heff_field(v_r_2411, 0));
        V v_st_2413 = heff_dup(heff_field(v_r_2411, 1));
        switch (heff_tag_of(v_r1_2412)) {
        case TAG_Left: {
          V v_d_2414 = heff_field(v_r1_2412, 0);
          heff_take_n(v_r1_2412, 1ULL, 1);
          heff_drop_tag(v_r_2411, 2);
          return heff_tail(v_h_2410, 2, (V[]){v_d_2414, v_st_2413});
        }
        case TAG_Right: {
          heff_take_n(v_r1_2412, 0ULL, 1);
          heff_drop(v_h_2410);
          heff_drop(v_st_2413);
          return v_r_2411;
        }
        default: return heff_nomatch(v_r1_2412);
        }
      }
      default: return heff_nomatch(v_r_2411);
      }
    }
    default: return heff_nomatch(v_q_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2ereadSumAlg_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ereadSumAlg(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2ereadH_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ereadH_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadH_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2ereadH_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ereadH_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ereadH_lam1, 3, 0};

static V g_heff_2esyntax_2ecst_2ereadH_val;
static HEFF_ONCE g_heff_2esyntax_2ecst_2ereadH_st;
static V g_heff_2esyntax_2ecst_2ereadH_init(void) {
  return heff_rec_n(3, shape_ret__bind__malg, (V[]){((V)&g_heff_2esyntax_2ecst_2ereadH_lam0_clo), ((V)&g_heff_2esyntax_2ecst_2ereadH_lam1_clo), ((V)&g_heff_2esyntax_2ecst_2ereadSumAlg_clo)});
}
V g_heff_2esyntax_2ecst_2ereadH_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2ecst_2ereadH_st)) return g_heff_2esyntax_2ecst_2ereadH_val;
  return heff_global(&g_heff_2esyntax_2ecst_2ereadH_val, &g_heff_2esyntax_2ecst_2ereadH_st, g_heff_2esyntax_2ecst_2ereadH_init);
}
V g_heff_2esyntax_2ecst_2ereadH_lam0(V self, V *args) {
  V v_x_240 = args[0];
  V v_st_241 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_240}), v_st_241});
}
V g_heff_2esyntax_2ecst_2ereadH_lam1(V self, V *args) {
  V v_m_242 = args[0];
  V v_k_243 = args[1];
  V v_st_244 = args[2];
  V v_x1_245 = heff_tr(heff_call(v_m_242, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_k_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_245_24MkPair, 2);
      V f_ = v_k_243;
      args[0] = v_x_249;
      args[1] = v_st_247;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
Clo g_heff_2esyntax_2ecst_2eendBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eendBefore_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eendBefore(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_j_241), MK_INT(0LL))) {
    heff_drop_rec(v_s_240, 5);
    heff_drop(v_j_241);
    return MK_INT(0LL);
  } else {
    V v_t_243 = heff_arrayLength(heff_dup(heff_rfield(v_s_240, 0)));
    if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
      heff_drop_rec(v_s_240, 5);
      heff_drop(v_j_241);
      return MK_INT(0LL);
    } else {
      V v_t_245 = heff_arrayLength(heff_dup(heff_rfield(v_s_240, 0)));
      if (heff_intLt_c(v_t_245, heff_dup(v_j_241))) {
        heff_drop(v_j_241);
        V v_t_247 = heff_arrayLength(heff_dup(heff_rfield(v_s_240, 0)));
        V v_t_248 = heff_arrayIndex(heff_get_n(v_s_240, 0, 5), heff_intSub(v_t_247, MK_INT(1LL)));
        return heff_get_n(v_t_248, 4, 9);
      } else {
        V v_t_249 = heff_arrayIndex(heff_get_n(v_s_240, 0, 5), heff_intSub(v_j_241, MK_INT(1LL)));
        return heff_get_n(v_t_249, 4, 9);
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2eendBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eendBefore(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str5, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatTok_str7, 0, "");
Clo g_heff_2esyntax_2ecst_2eatTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatTok_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eatTok(V v_s_240, V v_j_241, V v_t_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2ecst_2eatTok_str0))) {
    heff_drop_rec(v_t_242, 9);
    V v_e_244 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
    return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2eatTok_str1), ((V)&g_heff_2esyntax_2ecst_2eatTok_str2), ((V)&g_heff_2esyntax_2ecst_2eatTok_str3), heff_dup(v_e_244), v_e_244, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  } else {
    if (heff_intLt_c(heff_dup(heff_rfield(v_s_240, 2)), heff_dup(v_j_241))) {
      V v_t_246 = heff_dup(heff_rfield(v_t_242, 6));
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 5)), MK_INT(0LL))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2esyntax_2ecst_2eatTok_str4))) {
            heff_drop_rec(v_s_240, 5);
            heff_drop(v_j_241);
            return v_t_242;
          } else {
            heff_drop_rec(v_t_242, 9);
            V v_e_249 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
            return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2eatTok_str5), ((V)&g_heff_2esyntax_2ecst_2eatTok_str6), ((V)&g_heff_2esyntax_2ecst_2eatTok_str7), heff_dup(v_e_249), v_e_249, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          }
        } else {
          heff_drop_rec(v_s_240, 5);
          heff_drop(v_j_241);
          return v_t_242;
        }
      }
      case TAG_False: {
        heff_drop_rec(v_s_240, 5);
        heff_drop(v_j_241);
        return v_t_242;
      }
      default: return heff_nomatch(v_t_246);
      }
    } else {
      heff_drop_rec(v_s_240, 5);
      heff_drop(v_j_241);
      return v_t_242;
    }
  }
}
V g_heff_2esyntax_2ecst_2eatTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatTok(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2etokAt_str5, 0, "");
Clo g_heff_2esyntax_2ecst_2etokAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etokAt_entry, 2, 0};

V g_heff_2esyntax_2ecst_2etokAt(V v_s_240, V v_j_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_j_241), MK_INT(0LL))) {
    V v_e_243 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
    return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2etokAt_str0), ((V)&g_heff_2esyntax_2ecst_2etokAt_str1), ((V)&g_heff_2esyntax_2ecst_2etokAt_str2), heff_dup(v_e_243), v_e_243, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  } else {
    V v_t_244 = heff_arrayLength(heff_dup(heff_rfield(v_s_240, 0)));
    if (heff_intLe_c(v_t_244, heff_dup(v_j_241))) {
      V v_e_246 = (g_heff_2esyntax_2ecst_2eendBefore(v_s_240, v_j_241));
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2etokAt_str3), ((V)&g_heff_2esyntax_2ecst_2etokAt_str4), ((V)&g_heff_2esyntax_2ecst_2etokAt_str5), heff_dup(v_e_246), v_e_246, MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    } else {
      V v_t_247 = heff_arrayIndex(heff_dup(heff_rfield(v_s_240, 0)), heff_dup(v_j_241));
      return (g_heff_2esyntax_2ecst_2eatTok(v_s_240, v_j_241, v_t_247));
    }
  }
}
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etokAt(a[0], a[1]);
}
Clo g_heff_2esyntax_2ecst_2ecur_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ecur_entry, 1, 0};

V g_heff_2esyntax_2ecst_2ecur(V v_s_240) {
top: ;
  return (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_get_n(v_s_240, 1, 5)));
}
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ecur(a[0]);
}
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2enext_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enext_entry, 2, 0};

V g_heff_2esyntax_2ecst_2enext(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enext(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2enext_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_t_246 = heff_intAdd(heff_take_field(v_s_245, 1), MK_INT(1LL));
  return ({ V rv_1 = v_t_246; V rr_ = heff_rec_reuse_n(v_s_245, 29ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2esyntax_2ecst_2enext_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V f_ = v_k_241;
  args[0] = v_x_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2enext_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam3, 1, 2, (V[]){v_k_241, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2enext_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2enext_lam1_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enext_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2enextN_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2enextN_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2enextN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2enextN_entry, 3, 0};

V g_heff_2esyntax_2ecst_2enextN(V v_n_240, V v_p_241, V v_p_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_Nil)});
  } else {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_p_241), heff_clo_n(g_heff_2esyntax_2ecst_2enextN_lam0, 1, 3, (V[]){v_n_240, v_p_241, v_p_242})));
  }
}
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2enextN(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2enextN_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_242;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2enextN_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2enextN_clo), 1, (V[]){heff_intSub(v_n_240, MK_INT(1LL))}));
  V f_ = v_c_245;
  heff_room[0] = v_p_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2enextN_lam1, 1, 2, (V[]){v_p_242, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatBoundary_str0, 3, "eof");
V g_heff_2esyntax_2ecst_2eatBoundary_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatBoundary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatBoundary_lam0, 1, 0};
Clo g_heff_2esyntax_2ecst_2eatBoundary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatBoundary_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatBoundary(V v_hd_240, V v_k2_241) {
top: ;
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eatBoundary_lam0_clo)})});
  V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2416}));
  return heff_tail(heff_get_n(v_hd_240, 1, 3), 2, (V[]){v_t_2417, v_k2_241});
}
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatBoundary(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatBoundary_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_t_243 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_242), heff_dup(heff_rfield(v_s_242, 1))));
  if (heff_strEq_c(heff_get_n(v_t_243, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eatBoundary_str0))) {
    heff_drop_rec(v_s_242, 5);
    return NTAG(TAG_True);
  } else {
    V v_t_245 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_242), heff_dup(heff_rfield(v_s_242, 1))));
    V v_t_246 = heff_get_n(v_t_245, 6, 9);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_t_247 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_242), heff_dup(heff_rfield(v_s_242, 1))));
      V v_t_248 = heff_take_field(v_s_242, 3);
      V v_x2_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_x2_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        heff_take_n(v_t_248, 1ULL, 2);
        v_x2_2411 = heff_tag_n(TAG_Just, 1, (V[]){v_x_249});
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2413;
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_Nothing: {
        v_t_2413 = MK_INT(0LL);
        break;
      }
      case TAG_Just: {
        V v_x_2412 = heff_field(v_x2_2411, 0);
        heff_take_n(v_x2_2411, 1ULL, 1);
        v_t_2413 = v_x_2412;
        break;
      }
      default: heff_nomatch(v_x2_2411);
      }
      if (heff_intLe_c(heff_get_n(v_t_247, 5, 9), v_t_2413)) {
        if (heff_intEq_c(heff_dup(heff_rfield(v_s_242, 1)), heff_get_n(v_s_242, 4, 5))) {
          return NTAG(TAG_False);
        } else {
          return NTAG(TAG_True);
        }
      } else {
        heff_drop_rec(v_s_242, 5);
        return NTAG(TAG_False);
      }
    }
    case TAG_False: {
      heff_drop_rec(v_s_242, 5);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str2, 12, "expected `:`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectAnn_str3, 12, "expected `:`");
V g_heff_2esyntax_2ecst_2eexpectAnn_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectAnn_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexpectAnn(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectAnn_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexpectAnn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectAnn(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexpectAnn_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str1))) {
      heff_drop_rec(v_x_244, 9);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_240, v_k_241));
    } else {
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str2), v_t_247, NTAG(TAG_Nothing)});
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
      V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_249}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2410;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  } else {
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eexpectAnn_str3), v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str5, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str6, 7, "`, not ");
V g_heff_2esyntax_2ecst_2eexpectSym_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectSym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectSym_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectSym(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectSym_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectSym(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectSym_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str0))) {
    v_t_247 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), heff_dup(v_x_240));
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_x_240);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
  }
  case TAG_False: {
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str1))) {
      v_t_249 = ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str2);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str3), heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str4)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str5), heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str6), v_t_249)));
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str5, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectPunct_str6, 7, "`, not ");
V g_heff_2esyntax_2ecst_2eexpectPunct_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectPunct_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectPunct_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectPunct(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectPunct_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectPunct_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectPunct(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectPunct_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str0))) {
    v_t_247 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), heff_dup(v_x_240));
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_x_240);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
  }
  case TAG_False: {
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str1))) {
      v_t_249 = ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str2);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str3), heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str4)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str5), heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectPunct_str6), v_t_249)));
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str5, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKw_str6, 7, "`, not ");
V g_heff_2esyntax_2ecst_2eexpectKw_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectKw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectKw_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectKw(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectKw_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectKw(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectKw_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str0))) {
    v_t_247 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), heff_dup(v_x_240));
  } else {
    v_t_247 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_x_240);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
  }
  case TAG_False: {
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str1))) {
      v_t_249 = ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str2);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str3), heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectKw_str4)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str5), heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKw_str6), v_t_249)));
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str4, 9, "expected ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectKind_str5, 6, ", not ");
V g_heff_2esyntax_2ecst_2eexpectKind_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectKind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectKind_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eexpectKind(V v_k_240, V v_what_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectKind_lam0, 1, 4, (V[]){v_k_240, v_hd_242, v_k_243, v_what_241})});
}
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectKind(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eexpectKind_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_what_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), v_k_240)) {
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_what_241);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_242, v_k_243));
  } else {
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str0))) {
      v_t_249 = ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str1);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str2), heff_strAppend(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectKind_str3)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str4), heff_strAppend(v_what_241, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectKind_str5), v_t_249)));
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 3), heff_get_n(v_x_246, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2econtinuesBlock_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2econtinuesBlock_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2econtinuesBlock_str2, 5, "where");
Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2econtinuesBlock_entry, 2, 0};

V g_heff_2esyntax_2ecst_2econtinuesBlock(V v_t_240, V v_col_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2econtinuesBlock_str0))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_col_241);
    return NTAG(TAG_False);
  } else {
    V v_t_243 = heff_take_field(v_t_240, 6);
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      if (heff_intEq_c(heff_dup(heff_rfield(v_t_240, 5)), v_col_241)) {
        V v_x1_246;
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2econtinuesBlock_str1))) {
          v_x1_246 = heff_strEq(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2econtinuesBlock_str2));
        } else {
          heff_drop_rec(v_t_240, 9);
          v_x1_246 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_x1_246)) {
        case TAG_True: {
          return NTAG(TAG_False);
        }
        case TAG_False: {
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x1_246);
        }
      } else {
        heff_drop_rec(v_t_240, 9);
        return NTAG(TAG_False);
      }
    }
    case TAG_False: {
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_col_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_243);
    }
  }
}
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2econtinuesBlock(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eblockGo(V v_item_240, V v_col_241, V v_acc_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam1, 1, 5, (V[]){v_hd_243, v_item_240, v_col_241, v_acc_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eblockGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eblockGo_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_245, 1)); V rr_ = heff_rec_reuse_n(v_s_245, 15ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_col_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2415, heff_dup(v_col_241)));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, v_col_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242}), v_hd_243, v_k_244));
  }
  case TAG_False: {
    heff_drop(v_col_241);
    heff_drop(v_item_240);
    heff_drop_rec(v_hd_243, 3);
    V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_242})));
    V f_ = v_k_244;
    args[0] = v_x_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_col_241 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam4, 1, 6, (V[]){v_col_241, v_item_240, v_x_2412, v_acc_242, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2411);
  V f_ = heff_dup(v_item_240);
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam3, 1, 5, (V[]){v_hd_243, v_col_241, v_item_240, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_col_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249 = heff_tag_n(TAG_Put, 2, (V[]){v_x_248, NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2410;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_lam2, 1, 5, (V[]){v_item_240, v_hd_243, v_col_241, v_acc_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eblock(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_item_240})});
}
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eblock_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_t_2412 = heff_get_n(v_s_2411, 3, 5);
  V v_x2_2415;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    v_x2_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 2);
    v_x2_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    heff_take_n(v_x2_2415, 1ULL, 1);
    return v_x_2416;
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2esyntax_2ecst_2eblock_lam3(V self, V *args) {
  V v_s_2426 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_245, 5, 9), heff_take_field(v_s_2426, 3)});
  return ({ V rv_3 = v_t_2427; V rr_ = heff_rec_reuse_n(v_s_2426, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_lam7(V self, V *args) {
  V v_s_2435 = args[0];
  V v_k_2436 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2435, 3)));
  return ({ V rv_3 = v_k_2436; V rr_ = heff_rec_reuse_n(v_s_2435, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2442);
  V f_ = v_k_242;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2440 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2441;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam9, 1, 2, (V[]){v_k_242, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_lam7_clo)})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2437}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam8, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2434});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2433);
  return (g_heff_2esyntax_2ecst_2eblockGo(v_item_240, heff_get_n(v_x_245, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eblock_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2430, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam5, 1, 4, (V[]){v_item_240, v_x_245, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2420 = heff_dup(heff_rfield(v_x_245, 6));
  V v_t_2421;
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    v_t_2421 = heff_intLe(heff_dup(heff_rfield(v_x_245, 5)), v_x_2419);
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2419);
    v_t_2421 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2420);
  }
  switch (heff_tag_of(v_t_2421)) {
  case TAG_True: {
    heff_drop(v_item_240);
    V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_str2), v_t_2422, NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2424}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2425;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam3, 1, 1, (V[]){heff_dup(v_x_245)})})});
    V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2428}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2429;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam4, 1, 4, (V[]){v_hd_241, v_item_240, v_x_245, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2esyntax_2ecst_2eblock_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_item_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_str0))) {
    heff_drop(v_item_240);
    V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_str1), v_t_247, NTAG(TAG_Nothing)});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_249}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2410;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_lam1_clo)})});
    V v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2417}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2418;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_lam2, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_item_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2einBrackets_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einBrackets_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einBrackets_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2einBrackets_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2einBrackets_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einBrackets_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2einBrackets_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2einBrackets_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2einBrackets_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2einBrackets_entry, 3, 0};

V g_heff_2esyntax_2ecst_2einBrackets(V v_p_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einBrackets_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam1, 1, 3, (V[]){v_hd_241, v_p_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2einBrackets_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2einBrackets(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2einBrackets_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(-1LL), heff_take_field(v_s_243, 3)});
  return ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_n(v_s_243, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2einBrackets_lam4(V self, V *args) {
  V v_s_2412 = args[0];
  V v_k_2413 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2412, 3)));
  return ({ V rv_3 = v_k_2413; V rr_ = heff_rec_reuse_n(v_s_2412, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2einBrackets_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V f_ = v_k_242;
  args[0] = v_x_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2einBrackets_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})}));
  V f_ = heff_get_n(v_hd_241, 1, 3);
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam6, 1, 2, (V[]){v_k_242, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einBrackets_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2einBrackets_lam4_clo)})});
  V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2414}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2415;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam5, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einBrackets_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2410);
  V f_ = v_p_240;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam3, 1, 2, (V[]){v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2einBrackets_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_p_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2einBrackets_lam2, 1, 3, (V[]){v_p_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str8, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str9, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str10, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str11, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str12, 5, "Float");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str13, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str14, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str15, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str16, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str17, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str18, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str19, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str20, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str21, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str22, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str23, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str24, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str25, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str26, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str27, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str28, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str29, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str30, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str31, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str32, 1, "[");
V g_heff_2esyntax_2ecst_2estartsAtom_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2estartsAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estartsAtom_entry, 1, 0};

V g_heff_2esyntax_2ecst_2estartsAtom(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 0))}));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str2), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str4), v_t_243})});
  V v_t_245 = ({ V a_0 = v_t_241; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str5), v_t_244}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop_rec(v_t_240, 9);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str6))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str7), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str9), v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str11), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str13), v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str14), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str15), v_t_2411})});
      V v_t_2413 = ({ V a_0 = v_t_247; V a_1 = v_t_2412; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2412, 2); r_; });
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop_rec(v_t_240, 9);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_x3_2416 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2ecst_2estartsAtom_lam0, 1, 1, (V[]){heff_dup(v_t_240)}); V b_1 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x3_2416)) {
        case TAG_Nothing: {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str25))) {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str26))) {
              heff_drop_rec(v_t_240, 9);
              return NTAG(TAG_True);
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str27))) {
                heff_drop_rec(v_t_240, 9);
                return NTAG(TAG_True);
              } else {
                return heff_strEq(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str28));
              }
            }
          } else {
            heff_drop_rec(v_t_240, 9);
            return NTAG(TAG_False);
          }
        }
        case TAG_Just: {
          heff_take_n(v_x3_2416, 0ULL, 1);
          heff_drop_rec(v_t_240, 9);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_x3_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str29))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str30))) {
          heff_drop_rec(v_t_240, 9);
          return NTAG(TAG_True);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str31))) {
            heff_drop_rec(v_t_240, 9);
            return NTAG(TAG_True);
          } else {
            return heff_strEq(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str32));
          }
        }
      } else {
        heff_drop_rec(v_t_240, 9);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estartsAtom(a[0]);
}
V g_heff_2esyntax_2ecst_2estartsAtom_lam0(V self, V *args) {
  V v_w_2414 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_w_2414)) {
  case TAG_I8: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str16);
    break;
  }
  case TAG_I16: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str17);
    break;
  }
  case TAG_I32: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str18);
    break;
  }
  case TAG_I64: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str19);
    break;
  }
  case TAG_U8: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str20);
    break;
  }
  case TAG_U16: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str21);
    break;
  }
  case TAG_U32: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str22);
    break;
  }
  case TAG_U64: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str23);
    break;
  }
  case TAG_F32: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str24);
    break;
  }
  default: heff_nomatch(v_w_2414);
  }
  return heff_strEq(v_t_2415, heff_get_n(v_t_240, 1, 9));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str1, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyGo_str2, 1, "(");
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emanyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emanyGo_entry, 4, 0};

V g_heff_2esyntax_2ecst_2emanyGo(V v_p_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam0, 1, 4, (V[]){v_hd_242, v_acc_241, v_k_243, v_p_240})));
}
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emanyGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2emanyGo_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(v_p_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2emanyGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_244)) {
  case TAG_True: {
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_p_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_249 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_247)));
    V v_x1_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop_rec(v_x_247, 9);
      v_x1_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str0))) {
        heff_drop_rec(v_x_247, 9);
        v_x1_2412 = NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str1))) {
          v_x1_2412 = heff_strEq(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2emanyGo_str2));
        } else {
          heff_drop_rec(v_x_247, 9);
          v_x1_2412 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_True: {
      V f_ = heff_dup(v_p_240);
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam2, 1, 4, (V[]){v_p_240, v_acc_241, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_False: {
      heff_drop(v_p_240);
      heff_drop_rec(v_hd_242, 3);
      V v_x_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
      V f_ = v_k_243;
      args[0] = v_x_2414;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x_244);
  }
}
V g_heff_2esyntax_2ecst_2emanyGo_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_p_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyGo_lam1, 1, 5, (V[]){v_x_244, v_acc_241, v_k_243, v_p_240, v_hd_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo(V v_sep_240, V v_p_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam0, 1, 6, (V[]){v_sep_240, v_hd_244, v_p_241, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2esepGo_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2esepGo(v_sep_240, v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_items_242}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}), v_hd_244, v_k_245));
}
V g_heff_2esyntax_2ecst_2esepGo_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_dup(v_p_241);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam2, 1, 7, (V[]){v_sep_240, v_p_241, v_items_242, v_x_2410, v_seps_243, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_lam1, 1, 6, (V[]){v_p_241, v_hd_244, v_sep_240, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_p_241);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243))});
    V f_ = v_k_245;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_str11, 3, "let");
Clo g_heff_2esyntax_2ecst_2eexprHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprHead(V v_g_240, V v_t_241) {
top: ;
  V v_t_243;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str0))) {
    v_t_243 = heff_strEq(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str1));
  } else {
    v_t_243 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop_rec(v_t_241, 9);
    return heff_get_n(v_g_240, 8, 13);
  }
  case TAG_False: {
    V v_t_245;
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str2))) {
      v_t_245 = heff_strEq(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str3));
    } else {
      v_t_245 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop_rec(v_t_241, 9);
      return heff_get_n(v_g_240, 9, 13);
    }
    case TAG_False: {
      V v_t_247;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str4))) {
        v_t_247 = heff_strEq(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str5));
      } else {
        v_t_247 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop_rec(v_t_241, 9);
        return heff_get_n(v_g_240, 10, 13);
      }
      case TAG_False: {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str6))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str7))) {
            heff_drop_rec(v_t_241, 9);
            return heff_get_n(v_g_240, 11, 13);
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str8))) {
              if (heff_strEq_c(heff_get_n(v_t_241, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str9))) {
                return heff_get_n(v_g_240, 12, 13);
              } else {
                return heff_tail(heff_get_n(v_g_240, 1, 13), 1, (V[]){MK_INT(0LL)});
              }
            } else {
              heff_drop_rec(v_t_241, 9);
              return heff_tail(heff_get_n(v_g_240, 1, 13), 1, (V[]){MK_INT(0LL)});
            }
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str10))) {
            if (heff_strEq_c(heff_get_n(v_t_241, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_str11))) {
              return heff_get_n(v_g_240, 12, 13);
            } else {
              return heff_tail(heff_get_n(v_g_240, 1, 13), 1, (V[]){MK_INT(0LL)});
            }
          } else {
            heff_drop_rec(v_t_241, 9);
            return heff_tail(heff_get_n(v_g_240, 1, 13), 1, (V[]){MK_INT(0LL)});
          }
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexprF_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_247, v_x_2414, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam5, 1, 3, (V[]){v_k_242, v_x_247, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_2410, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_str1))) {
      switch (heff_tag_of(v_x_2411)) {
      case TAG_True: {
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 13);
        V f_ = v_k_242;
        args[0] = v_x_247;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_247})));
      }
      default: return heff_nomatch(v_x_2411);
      }
    } else {
      heff_drop(v_x_2411);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 13);
      V f_ = v_k_242;
      args[0] = v_x_247;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2411);
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam3, 1, 5, (V[]){v_x_2410, v_k_242, v_x_247, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam2, 1, 4, (V[]){v_hd_241, v_k_242, v_x_247, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = heff_tr(g_heff_2esyntax_2ecst_2eexprHead(heff_dup(v_g_240), v_x_245));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_str5, 4, "case");
V g_heff_2esyntax_2ecst_2earrowRhsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earrowRhsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earrowRhsF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2earrowRhsF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2earrowRhsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earrowRhsF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2earrowRhsF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str0))) {
    heff_drop_rec(v_x_245, 9);
    V f_ = heff_get_n(v_g_240, 0, 13);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str1))) {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_245, 1, 9)}));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str2), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str4), v_t_249})});
      V v_t_2411 = ({ V a_0 = v_t_248; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_str5), v_t_2410}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_False: {
        V f_ = heff_get_n(v_g_240, 1, 13);
        heff_room[0] = MK_INT(1LL);
        heff_room[1] = v_hd_241;
        heff_room[2] = v_k_242;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      heff_drop_rec(v_x_245, 9);
      V f_ = heff_get_n(v_g_240, 1, 13);
      heff_room[0] = MK_INT(1LL);
      heff_room[1] = v_hd_241;
      heff_room[2] = v_k_242;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str2, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str4, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str6, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_str8, 1, "~");
V g_heff_2esyntax_2ecst_2eopLoopF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_entry, 5, 0};

V g_heff_2esyntax_2ecst_2eopLoopF(V v_g_240, V v_minPrec_241, V v_lhs_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam0, 1, 5, (V[]){v_hd_243, v_minPrec_241, v_g_240, v_lhs_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam3(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_lhs_242 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eopLoopF(v_g_240, v_minPrec_241, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_242, v_x_2421, v_x_2432}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_minPrec_241 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2422 = heff_dup(heff_rfield(v_x_247, 1));
  V v_t_2425;
  if (heff_strEq_c(heff_dup(v_s_2422), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str5))) {
    heff_drop(v_s_2422);
    v_t_2425 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2422, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str6))) {
      v_t_2425 = MK_INT(2LL);
    } else {
      v_t_2425 = MK_INT(-1LL);
    }
  }
  V v_c_2431;
  if (heff_intEq_c(v_t_2425, MK_INT(1LL))) {
    heff_drop_rec(v_x_247, 9);
    v_c_2431 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2earrowRhsF_clo), 1, (V[]){heff_dup(v_g_240)}));
  } else {
    V v_s_2427 = heff_get_n(v_x_247, 1, 9);
    V v_t_2430;
    if (heff_strEq_c(heff_dup(v_s_2427), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str7))) {
      heff_drop(v_s_2427);
      v_t_2430 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2427, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str8))) {
        v_t_2430 = MK_INT(2LL);
      } else {
        v_t_2430 = MK_INT(-1LL);
      }
    }
    v_c_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_g_240, 1)), 1, (V[]){v_t_2430}));
  }
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam3, 1, 6, (V[]){v_g_240, v_minPrec_241, v_lhs_242, v_x_2421, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_lhs_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str0))) {
    V v_s_2410 = heff_dup(heff_rfield(v_x_247, 1));
    V v_a_2413;
    if (heff_strEq_c(heff_dup(v_s_2410), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str1))) {
      heff_drop(v_s_2410);
      v_a_2413 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2410, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str2))) {
        v_a_2413 = MK_INT(2LL);
      } else {
        v_a_2413 = MK_INT(-1LL);
      }
    }
    if (heff_intLe_c(MK_INT(1LL), v_a_2413)) {
      V v_s_2415 = heff_dup(heff_rfield(v_x_247, 1));
      V v_a_2418;
      if (heff_strEq_c(heff_dup(v_s_2415), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str3))) {
        heff_drop(v_s_2415);
        v_a_2418 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2415, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_str4))) {
          v_a_2418 = MK_INT(2LL);
        } else {
          v_a_2418 = MK_INT(-1LL);
        }
      }
      if (heff_intLe_c(heff_dup(v_minPrec_241), v_a_2418)) {
        switch (heff_tag_of(v_x_248)) {
        case TAG_True: {
          v_t_2420 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2420 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_248);
        }
      } else {
        heff_drop(v_x_248);
        v_t_2420 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_248);
      v_t_2420 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_248);
    v_t_2420 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam2, 1, 6, (V[]){v_x_247, v_g_240, v_hd_243, v_minPrec_241, v_lhs_242, v_k_244})));
  }
  case TAG_False: {
    heff_drop_rec(v_x_247, 9);
    heff_drop(v_minPrec_241);
    heff_drop_rec(v_hd_243, 3);
    heff_drop_rec(v_g_240, 13);
    V f_ = v_k_244;
    args[0] = v_lhs_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_lhs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_lam1, 1, 6, (V[]){v_x_247, v_minPrec_241, v_hd_243, v_g_240, v_lhs_242, v_k_244})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str1, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str3, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str4, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str5, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eoperandsF_str6, 4, "case");
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eoperandsF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eoperandsF_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eoperandsF(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam0, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eoperandsF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eoperandsF(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2417}), v_acc_241});
  V v_x_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2418));
  V f_ = v_k_243;
  args[0] = v_x_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2425}), v_acc_241});
  V v_x_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2426));
  V f_ = v_k_243;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2428}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2429, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_x_2412, v_x_2430}), v_acc_241});
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_240, v_t_2431, v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2415, 1)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str1))) {
    heff_drop_rec(v_x_2415, 9);
    V f_ = heff_get_n(v_g_240, 0, 13);
    heff_room[0] = v_hd_242;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam4, 1, 3, (V[]){v_x_2412, v_acc_241, v_k_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2415, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str2))) {
      V v_t_2421 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_2415, 1, 9)}));
      V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str3), NTAG(TAG_Nil)});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str5), v_t_2422})});
      V v_t_2424 = ({ V a_0 = v_t_2421; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eoperandsF_str6), v_t_2423}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_242;
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam5, 1, 3, (V[]){v_x_2412, v_acc_241, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_False: {
        V f_ = heff_dup(heff_rfield(v_g_240, 3));
        heff_room[0] = heff_dup(v_hd_242);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam6, 1, 5, (V[]){v_x_2412, v_acc_241, v_g_240, v_hd_242, v_k_243});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_t_2424);
      }
    } else {
      heff_drop_rec(v_x_2415, 9);
      V f_ = heff_dup(heff_rfield(v_g_240, 3));
      heff_room[0] = heff_dup(v_hd_242);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam7, 1, 5, (V[]){v_x_2412, v_acc_241, v_g_240, v_hd_242, v_k_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam3, 1, 5, (V[]){v_g_240, v_hd_242, v_x_2412, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eoperandsF_str0))) {
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_246, 1, 9)}));
    V v_x1_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      heff_drop(v_x_247);
      v_t_2411 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      switch (heff_tag_of(v_x_247)) {
      case TAG_True: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2411 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    v_t_2411 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam2, 1, 4, (V[]){v_hd_242, v_g_240, v_acc_241, v_k_243})));
  }
  case TAG_False: {
    heff_drop_rec(v_hd_242, 3);
    heff_drop_rec(v_g_240, 13);
    V v_x_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    V f_ = v_k_243;
    args[0] = v_x_2432;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2esyntax_2ecst_2eoperandsF_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eoperandsF_lam1, 1, 5, (V[]){v_x_246, v_hd_242, v_g_240, v_acc_241, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldsGo_str0, 5, "field");
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldsGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efieldsGo(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam0, 1, 3, (V[]){v_hd_241, v_e_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2efieldsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldsGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efieldsGo(heff_tag_n(TAG_EField, 2, (V[]){v_e_240, v_x_247}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efieldsGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2efieldsGo_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efieldsGo_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
  } else {
    heff_drop_rec(v_hd_241, 3);
    V f_ = v_k_242;
    args[0] = v_e_240;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edefaultedF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 0)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_243, v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam4, 1, 3, (V[]){v_k_242, v_x_243, v_x_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_str0))) {
    V v_t_2411;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_str1))) {
      heff_drop_rec(v_x_246, 9);
      switch (heff_tag_of(v_x_247)) {
      case TAG_True: {
        v_t_2411 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2411 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x_247);
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_str2))) {
        switch (heff_tag_of(v_x_247)) {
        case TAG_True: {
          v_t_2411 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2411 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_x_247);
        v_t_2411 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
    }
    case TAG_False: {
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 13);
      V f_ = v_k_242;
      args[0] = v_x_243;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2411);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam2, 1, 5, (V[]){v_x_246, v_hd_241, v_g_240, v_k_242, v_x_243})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str1, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str2, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str3, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str6, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str7, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str8, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str9, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_str10, 1, "}");
V g_heff_2esyntax_2ecst_2ebracesF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ebracesF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2ebracesF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebracesF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ebracesF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ebracesF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebracesF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam8(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_x_2418 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_InstB, 5, (V[]){v_x_243, v_x_2416, v_x_2417, v_x_2418, v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str3), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam8, 1, 5, (V[]){v_k_245, v_x_243, v_x_2416, v_x_2417, v_x_2418})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str2), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam7, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_get_n(v_g_240, 0, 13), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam6, 1, 4, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2421});
  V f_ = v_k_245;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam13(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_EFSet, 3, (V[]){v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam12(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2424 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_2424;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam13, 1, 3, (V[]){v_k_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_lam11(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2424 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ebracesF_str6), heff_dup(v_hd_2424), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam12, 1, 4, (V[]){v_g_240, v_hd_2424, v_k_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam10(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2424), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam11, 1, 3, (V[]){v_hd_2424, v_g_240, v_k_2425})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam16(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2436;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_MkSep: {
    V v_items_2434 = heff_field(v_x_2432, 0);
    V v_seps_2435 = heff_field(v_x_2432, 1);
    heff_take_n(v_x_2432, 3ULL, 2);
    v_x_2436 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, v_items_2434, v_seps_2435, v_x_2433});
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V f_ = v_k_245;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam15(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str8), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam16, 1, 3, (V[]){v_x_2432, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam14(V self, V *args) {
  V v_x_2430 = args[0];
  V v_p_2429 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2ebracesF_str7), v_p_2429, v_t_2431, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam15, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam19(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2444;
  switch (heff_tag_of(v_x_2440)) {
  case TAG_MkSep: {
    V v_items_2442 = heff_field(v_x_2440, 0);
    V v_seps_2443 = heff_field(v_x_2440, 1);
    heff_take_n(v_x_2440, 3ULL, 2);
    v_x_2444 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_243, v_items_2442, v_seps_2443, v_x_2441});
    break;
  }
  default: heff_nomatch(v_x_2440);
  }
  V f_ = v_k_245;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam18(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_str10), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam19, 1, 3, (V[]){v_x_2440, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam17(V self, V *args) {
  V v_x_2438 = args[0];
  V v_p_2437 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2438, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2ebracesF_str9), v_p_2437, v_t_2439, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam18, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2ebracesF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str0))) {
    v_t_2415 = heff_strEq(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str1));
  } else {
    v_t_2415 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop_rec(v_x_2413, 9);
    heff_drop_rec(v_x_248, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam5, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243})));
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str4))) {
      heff_drop_rec(v_x_2413, 9);
      heff_drop_rec(v_g_240, 13);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam9, 1, 2, (V[]){v_x_243, v_k_245})));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2413, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_str5))) {
        V v_p_2429 = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam10, 2, 1, (V[]){v_g_240});
        V f_ = heff_dup(v_p_2429);
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam14, 1, 4, (V[]){v_p_2429, v_hd_244, v_x_243, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        V v_p_2437 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2edefaultedF_clo), 1, (V[]){v_g_240}));
        V f_ = heff_dup(v_p_2437);
        heff_room[0] = heff_dup(v_hd_244);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam17, 1, 4, (V[]){v_p_2437, v_hd_244, v_x_243, v_k_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ebracesF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_g_240, v_k_245, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam2, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_lam1, 2, 2, (V[]){v_g_240, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_str1, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_str2, 1, "}");
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eanonymousSumF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eanonymousSumF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eanonymousSumF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eanonymousSumF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_ECon, 2, (V[]){v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_240, 4, 13), NTAG(TAG_Nil), v_hd_245, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam4, 1, 2, (V[]){v_k_246, v_x_247})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam2(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_245), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam3, 1, 3, (V[]){v_g_240, v_hd_245, v_k_246})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam8(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2418;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkSep: {
    V v_items_2416 = heff_field(v_x_2414, 0);
    V v_seps_2417 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2418 = heff_tag_n(TAG_Sum, 5, (V[]){v_x_243, v_x_244, v_items_2416, v_seps_2417, v_x_2415});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2411;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_str2), v_hd_2410, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam8, 1, 4, (V[]){v_x_2414, v_x_243, v_x_244, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam6(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_str1), v_p_249, v_t_2413, NTAG(TAG_Nil), heff_dup(v_hd_2410), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam7, 1, 4, (V[]){v_hd_2410, v_x_243, v_x_244, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam5(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(v_p_249);
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam6, 1, 5, (V[]){v_p_249, v_hd_2410, v_x_243, v_x_244, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_p_249 = heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam2, 2, 1, (V[]){v_g_240});
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam5, 2, 3, (V[]){v_p_249, v_x_243, v_x_244}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_lam1, 1, 4, (V[]){v_g_240, v_x_243, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str4, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str5, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str7, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str9, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_str12, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eparensF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eparensF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eparensF_lam3(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2eparensF_lam6(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_2418 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_243, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2418}), v_x_2419});
  V f_ = v_k_245;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam6, 1, 3, (V[]){v_x_243, v_x_2418, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam10(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_2427 = heff_env(self)[3];
  V v_x_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_243, v_x_2426, v_x_2427, v_x_2428, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam9(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str8), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam10, 1, 5, (V[]){v_k_245, v_x_243, v_x_2426, v_x_2427, v_x_2428})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam9, 1, 5, (V[]){v_hd_244, v_k_245, v_x_243, v_x_2426, v_x_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam8, 1, 5, (V[]){v_g_240, v_hd_244, v_k_245, v_x_243, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam14(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2440;
  switch (heff_tag_of(v_x_2436)) {
  case TAG_MkSep: {
    V v_items_2438 = heff_field(v_x_2436, 0);
    V v_seps_2439 = heff_field(v_x_2436, 1);
    heff_take_n(v_x_2436, 3ULL, 2);
    v_x_2440 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, v_items_2438, v_seps_2439, v_x_2437});
    break;
  }
  default: heff_nomatch(v_x_2436);
  }
  V f_ = v_k_245;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam13(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str11), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam14, 1, 3, (V[]){v_x_2436, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eparensF_lam15(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_243, v_x_2430, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam12(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2433, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_str9))) {
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eparensF_str10), heff_get_n(v_g_240, 0, 13), v_t_2435, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam13, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  } else {
    heff_drop_rec(v_g_240, 13);
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_str12), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam15, 1, 3, (V[]){v_k_245, v_x_243, v_x_2430})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_lam11(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2431}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam12, 1, 5, (V[]){v_x_2430, v_g_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str0))) {
    V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_248, 1))}));
    V v_x1_2416 = ({ V a_0 = v_t_2415; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_True: {
      v_t_2417 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2417 = heff_strEq(heff_dup(heff_rfield(v_x_2413, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str1));
      break;
    }
    default: heff_nomatch(v_x1_2416);
    }
  } else {
    v_t_2417 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop_rec(v_x_2413, 9);
    heff_drop_rec(v_x_248, 9);
    heff_drop_rec(v_g_240, 13);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam5, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245})));
  }
  case TAG_False: {
    V v_t_2425;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str2))) {
      heff_drop_rec(v_x_248, 9);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str3))) {
        v_t_2425 = heff_strEq(heff_get_n(v_x_2413, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_str4));
      } else {
        heff_drop_rec(v_x_2413, 9);
        v_t_2425 = NTAG(TAG_False);
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_248, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_str5))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_2413, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_str6))) {
          v_t_2425 = heff_strEq(heff_get_n(v_x_2413, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_str7));
        } else {
          heff_drop_rec(v_x_2413, 9);
          v_t_2425 = NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_x_2413, 9);
        v_t_2425 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2425)) {
    case TAG_True: {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam7, 1, 4, (V[]){v_hd_244, v_g_240, v_k_245, v_x_243})));
    }
    case TAG_False: {
      V f_ = heff_dup(heff_rfield(v_g_240, 0));
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam11, 1, 4, (V[]){v_hd_244, v_g_240, v_x_243, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2esyntax_2ecst_2eparensF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_lam3_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam4, 1, 5, (V[]){v_x_248, v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam2, 1, 4, (V[]){v_hd_244, v_x_243, v_k_245, v_g_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_lam1, 2, 2, (V[]){v_x_243, v_g_240}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str1, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str2, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2411;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str1), v_item_240, v_t_2416, NTAG(TAG_Nil), v_hd_2413, v_k_2414));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_item_240);
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam5, 1, 3, (V[]){v_item_240, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_x_2422 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2417;
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_str0))) {
    heff_drop(v_item_240);
    v_c_2417 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam3_clo);
  } else {
    v_c_2417 = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam4, 2, 1, (V[]){v_item_240});
  }
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_item_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam2, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_lam1, 2, 2, (V[]){v_item_240, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str8, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str10, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str12, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str13, 5, "Float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str14, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str15, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str16, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str17, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str18, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str19, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str20, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str21, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str22, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str23, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str24, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str25, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str26, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str28, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str29, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str30, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str31, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str32, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str33, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str35, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_str36, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_lam1, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_lam3(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomBase(V v_g_240, V v_t_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_241, 0))}));
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str0), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str2), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str4), v_t_244})});
  V v_t_246 = ({ V a_0 = v_t_242; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str5), v_t_245}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2418;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str6))) {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_241, 1))}));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str7), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str9), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str11), v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str13), v_t_2411})});
      V v_t_2413 = ({ V a_0 = v_t_248; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_str14), v_t_2412}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        v_t_2418 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        V v_x3_2416 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam0, 1, 1, (V[]){heff_dup(v_t_241)}); V b_1 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x3_2416)) {
        case TAG_Nothing: {
          v_t_2418 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2416, 0ULL, 1);
          v_t_2418 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2416);
        }
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
    } else {
      v_t_2418 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    heff_drop_rec(v_g_240, 13);
    heff_drop_rec(v_t_241, 9);
    return ((V)&g_heff_2esyntax_2ecst_2eatomBase_lam1_clo);
  }
  case TAG_False: {
    V v_t_2423;
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str24))) {
      v_t_2423 = heff_strEq(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str25));
    } else {
      v_t_2423 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop_rec(v_t_241, 9);
      return heff_tail(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_clo), 1, (V[]){v_g_240});
    }
    case TAG_False: {
      V v_t_2425;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str26))) {
        v_t_2425 = heff_strEq(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str27));
      } else {
        v_t_2425 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2425)) {
      case TAG_True: {
        heff_drop_rec(v_t_241, 9);
        return heff_tail(((V)&g_heff_2esyntax_2ecst_2eparensF_clo), 1, (V[]){v_g_240});
      }
      case TAG_False: {
        V v_t_2427;
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str28))) {
          v_t_2427 = heff_strEq(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str29));
        } else {
          v_t_2427 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2427)) {
        case TAG_True: {
          heff_drop_rec(v_t_241, 9);
          return heff_tail(((V)&g_heff_2esyntax_2ecst_2ebracesF_clo), 1, (V[]){v_g_240});
        }
        case TAG_False: {
          V v_t_2429;
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str30))) {
            v_t_2429 = heff_strEq(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str31));
          } else {
            v_t_2429 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2429)) {
          case TAG_True: {
            heff_drop_rec(v_t_241, 9);
            return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){heff_get_n(v_g_240, 0, 13)});
          }
          case TAG_False: {
            heff_drop_rec(v_g_240, 13);
            V v_t_2431;
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str32))) {
              v_t_2431 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str33);
            } else {
              v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_str34), heff_strAppend(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_str35)));
            }
            V v_msg_2432 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_str36), v_t_2431);
            return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam3, 2, 2, (V[]){v_t_241, v_msg_2432});
          }
          default: return heff_nomatch(v_t_2429);
          }
        }
        default: return heff_nomatch(v_t_2427);
        }
      }
      default: return heff_nomatch(v_t_2425);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomBase_lam0(V self, V *args) {
  V v_w_2414 = args[0];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_w_2414)) {
  case TAG_I8: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str15);
    break;
  }
  case TAG_I16: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str16);
    break;
  }
  case TAG_I32: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str17);
    break;
  }
  case TAG_I64: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str18);
    break;
  }
  case TAG_U8: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str19);
    break;
  }
  case TAG_U16: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str20);
    break;
  }
  case TAG_U32: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str21);
    break;
  }
  case TAG_U64: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str22);
    break;
  }
  case TAG_F32: {
    v_t_2415 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_str23);
    break;
  }
  default: heff_nomatch(v_w_2414);
  }
  return heff_strEq(v_t_2415, heff_get_n(v_t_241, 1, 9));
}
V g_heff_2esyntax_2ecst_2eatomBase_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_lam1(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2419, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_lam2, 1, 1, (V[]){v_k_2420})));
}
V g_heff_2esyntax_2ecst_2eatomBase_lam3(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_msg_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2435 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
  V v_t_2436 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2432, v_t_2435, NTAG(TAG_Nothing)});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2438;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_str4, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eatomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2eatomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eatomF_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2417, v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2eatomF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248;
  switch (heff_tag_of(v_x_246)) {
  case TAG_True: {
    v_t_248 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_x1_247 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_245)));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_True: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    heff_drop(v_g_240);
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_str0))) {
      v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eatomF_str1);
    } else {
      v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str2), heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_str3)));
    }
    V v_msg_2411 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_str4), v_t_2410);
    V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2411, v_t_2412, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2415;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_c_2416 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase(v_g_240, v_x_245));
    V f_ = v_c_2416;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam2, 1, 2, (V[]){v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2esyntax_2ecst_2eatomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_lam1, 1, 4, (V[]){v_x_245, v_hd_241, v_k_242, v_g_240})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str5, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str6, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str7, 36, "expected an implicit argument's name");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str8, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str9, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str10, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str11, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str12, 41, "expected a binder's name: `\\(x : T) -> e`");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str13, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinderF_str14, 50, "a lambda binds names: `\\x y -> e`, `\\(x : T) -> e`");
V g_heff_2esyntax_2ecst_2elamBinderF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinderF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elamBinderF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elamBinderF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elamBinderF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elamBinderF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_BVar, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_BImp, 3, (V[]){v_x_2411, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elamBinderF_str6), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam5, 1, 3, (V[]){v_k_242, v_x_2411, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2416;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2414, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str4))) {
    v_x1_2416 = NTAG(TAG_True);
  } else {
    v_x1_2416 = heff_strEq(heff_dup(heff_rfield(v_x_2414, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str5));
  }
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_True: {
    heff_drop_rec(v_x_2414, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam4, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411})));
  }
  case TAG_False: {
    heff_drop(v_x_2411);
    V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2414, 3), heff_get_n(v_x_2414, 4, 9)});
    V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str7), v_t_2419, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2421}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2422;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x1_2416);
  }
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam3, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam12(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_2427 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2438 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_x_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_BAnn, 5, (V[]){v_x_2425, v_x_2438, v_x_2439, v_x_2440, v_x_2441});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam11(V self, V *args) {
  V v_x_2440 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_2438 = heff_env(self)[3];
  V v_x_2439 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elamBinderF_str13), v_hd_2426, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam12, 1, 5, (V[]){v_k_2427, v_x_2425, v_x_2438, v_x_2439, v_x_2440})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam10(V self, V *args) {
  V v_x_2439 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = heff_dup(v_hd_2426);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam11, 1, 5, (V[]){v_hd_2426, v_k_2427, v_x_2425, v_x_2438, v_x_2439});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_2426), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam10, 1, 5, (V[]){v_g_240, v_hd_2426, v_k_2427, v_x_2425, v_x_2438})));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_2426 = heff_env(self)[0];
  V v_k_2427 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2432;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2430, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str10))) {
    v_x1_2432 = NTAG(TAG_True);
  } else {
    v_x1_2432 = heff_strEq(heff_dup(heff_rfield(v_x_2430, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str11));
  }
  V v_t_2433;
  switch (heff_tag_of(v_x1_2432)) {
  case TAG_True: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_False: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x1_2432);
  }
  switch (heff_tag_of(v_t_2433)) {
  case TAG_True: {
    heff_drop_rec(v_g_240, 13);
    heff_drop(v_x_2425);
    V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2430, 3), heff_get_n(v_x_2430, 4, 9)});
    V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str12), v_t_2434, NTAG(TAG_Nothing)});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2426, 2), 1, (V[]){v_t_2436}));
    V f_ = heff_get_n(v_hd_2426, 1, 3);
    heff_room[0] = v_t_2437;
    heff_room[1] = v_k_2427;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    heff_drop_rec(v_x_2430, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2426), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam9, 1, 4, (V[]){v_hd_2426, v_g_240, v_k_2427, v_x_2425})));
  }
  default: return heff_nomatch(v_t_2433);
  }
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam7(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2426, 2)), 1, (V[]){v_t_2428}));
  V f_ = heff_dup(heff_rfield(v_hd_2426, 1));
  args[0] = v_t_2429;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam8, 1, 4, (V[]){v_hd_2426, v_k_2427, v_g_240, v_x_2425});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam7, 2, 2, (V[]){v_g_240, v_x_2425}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2elamBinderF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str0))) {
    v_t_247 = NTAG(TAG_True);
  } else {
    v_t_247 = heff_strEq(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str1));
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_g_240, 13);
    return (g_heff_2esyntax_2ecst_2enext(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam1, 1, 1, (V[]){v_k_242})));
  }
  case TAG_False: {
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str2))) {
      v_t_2410 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str3));
    } else {
      v_t_2410 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop_rec(v_x_245, 9);
      heff_drop_rec(v_g_240, 13);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_False: {
      V v_t_2424;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str8))) {
        v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str9));
      } else {
        v_t_2424 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop_rec(v_x_245, 9);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinderF_lam6, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
      }
      case TAG_False: {
        heff_drop_rec(v_g_240, 13);
        V v_t_2442 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
        V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2elamBinderF_str14), v_t_2442, NTAG(TAG_Nothing)});
        V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
        V v_t_2445 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2444}));
        V f_ = heff_get_n(v_hd_241, 1, 3);
        heff_room[0] = v_t_2445;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str2, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2elamBinders_str4, 1, "(");
V g_heff_2esyntax_2ecst_2elamBinders_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elamBinders_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elamBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elamBinders_entry, 4, 0};

V g_heff_2esyntax_2ecst_2elamBinders(V v_g_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam0, 1, 4, (V[]){v_g_240, v_hd_242, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elamBinders(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2elamBinders_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(v_g_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, v_acc_241}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2elamBinders_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str0))) {
    heff_drop_rec(v_x_246, 9);
    return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam1, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str1))) {
      heff_drop_rec(v_x_246, 9);
      return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam2, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str2))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 1)), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str3))) {
          heff_drop_rec(v_x_246, 9);
          return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam3, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
        } else {
          if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elamBinders_str4))) {
            return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2elamBinders_lam4, 1, 4, (V[]){v_g_240, v_acc_241, v_hd_242, v_k_243})));
          } else {
            heff_drop(v_g_240);
            heff_drop_rec(v_hd_242, 3);
            V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
            V f_ = v_k_243;
            args[0] = v_x_2416;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
        }
      } else {
        heff_drop_rec(v_x_246, 9);
        heff_drop(v_g_240);
        heff_drop_rec(v_hd_242, 3);
        V v_x_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        V f_ = v_k_243;
        args[0] = v_x_2417;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elambdaF_str0, 2, "->");
V g_heff_2esyntax_2ecst_2elambdaF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elambdaF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elambdaF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elambdaF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elambdaF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elambdaF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Lam, 4, (V[]){v_x_243, heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_x_245}), v_x_246, v_x_247});
  V f_ = v_k_242;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elambdaF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam4, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elambdaF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2elambdaF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam3, 1, 6, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(heff_dup(v_g_240), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ecaseExprF_str0, 2, "of");
HEFF_LIT(g_heff_2esyntax_2ecst_2ecaseExprF_str1, 2, "->");
V g_heff_2esyntax_2ecst_2ecaseExprF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ecaseExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ecaseExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ecaseExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ecaseExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_EAlt, 3, (V[]){v_x_248, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam6, 1, 3, (V[]){v_k_247, v_x_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ecaseExprF_str1), heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam5, 1, 4, (V[]){v_g_240, v_hd_246, v_k_247, v_x_248})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam3(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_g_240, 5));
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam4, 1, 3, (V[]){v_hd_246, v_g_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam7(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Case, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam3, 2, 1, (V[]){v_g_240}), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam7, 1, 4, (V[]){v_k_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2ecaseExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2ecaseExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eifExprF_str0, 4, "then");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifExprF_str1, 4, "else");
V g_heff_2esyntax_2ecst_2eifExprF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eifExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eifExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eifExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eifExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eifExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eifExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eifExprF_lam5(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_If, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eifExprF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam5, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifExprF_str1), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam4, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2eifExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam3, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eifExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str1, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletHeadF_str2, 1, "=");
V g_heff_2esyntax_2ecst_2eletHeadF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam5(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eletHeadF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_lam5, 2, 0};
V g_heff_2esyntax_2ecst_2eletHeadF_lam6(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eletHeadF_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_lam6, 2, 0};
V g_heff_2esyntax_2ecst_2eletHeadF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletHeadF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletHeadF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 5)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eletHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletHeadF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_x_2412})});
  V f_ = v_k_2410;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam4, 1, 2, (V[]){v_x_2411, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam2(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_249), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam3, 1, 3, (V[]){v_g_240, v_hd_249, v_k_2410})));
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam5(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam6(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam9(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2419 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_MkLetHead, 4, (V[]){v_x_243, v_x_2419, v_x_2420, v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam8(V self, V *args) {
  V v_x_2420 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam9, 1, 4, (V[]){v_k_242, v_x_243, v_x_2419, v_x_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2eletHeadF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam8, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_2419})));
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2418;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eletHeadF_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eletHeadF_str1))) {
      v_c_2418 = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam2, 2, 1, (V[]){heff_dup(v_g_240)});
    } else {
      v_c_2418 = ((V)&g_heff_2esyntax_2ecst_2eletHeadF_lam5_clo);
    }
  } else {
    heff_drop_rec(v_x_246, 9);
    v_c_2418 = ((V)&g_heff_2esyntax_2ecst_2eletHeadF_lam6_clo);
  }
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam7, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletHeadF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletHeadF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletExprF_str0, 2, "in");
V g_heff_2esyntax_2ecst_2eletExprF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletExprF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletExprF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletExprF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletExprF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletExprF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletExprF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletExprF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2412;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_247 = heff_field(v_x_244, 0);
    V v_ann_248 = heff_field(v_x_244, 1);
    V v_eq_249 = heff_field(v_x_244, 2);
    V v_e_2410 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_x_246})});
    v_x_2412 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_247, v_ann_248, v_eq_249, v_e_2410, v_t_2411});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletExprF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam3, 1, 4, (V[]){v_x_244, v_x_245, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletExprF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eletExprF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletExprF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletExprF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str1, 2, "in");
HEFF_LIT(g_heff_2esyntax_2ecst_2eletStmtF_str2, 2, "in");
V g_heff_2esyntax_2ecst_2eletStmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eletStmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eletStmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eletStmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eletStmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eletStmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eletStmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam4(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2417;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkLetHead: {
    V v_p_2412 = heff_field(v_x_244, 0);
    V v_ann_2413 = heff_field(v_x_244, 1);
    V v_eq_2414 = heff_field(v_x_244, 2);
    V v_e_2415 = heff_field(v_x_244, 3);
    heff_take_n(v_x_244, 15ULL, 4);
    V v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_x_2411})});
    v_x_2417 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_2412, v_ann_2413, v_eq_2414, v_e_2415, v_t_2416});
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V f_ = v_k_242;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam4, 1, 4, (V[]){v_x_244, v_x_2410, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_249;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str0))) {
    v_t_249 = heff_strEq(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eletStmtF_str1));
  } else {
    heff_drop_rec(v_x_247, 9);
    v_t_249 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eletStmtF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam3, 1, 5, (V[]){v_g_240, v_hd_241, v_x_244, v_x_243, v_k_242})));
  }
  case TAG_False: {
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    V v_x_2422;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkLetHead: {
      V v_p_2418 = heff_field(v_x_244, 0);
      V v_ann_2419 = heff_field(v_x_244, 1);
      V v_eq_2420 = heff_field(v_x_244, 2);
      V v_e_2421 = heff_field(v_x_244, 3);
      heff_take_n(v_x_244, 15ULL, 4);
      v_x_2422 = heff_tag_n(TAG_ELet, 6, (V[]){v_x_243, v_p_2418, v_ann_2419, v_eq_2420, v_e_2421, NTAG(TAG_Nothing)});
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V f_ = v_k_242;
    args[0] = v_x_2422;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_244, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eletStmtF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eletHeadF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eletStmtF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str1, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str3, 2, "<-");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estatementF_str5, 2, "<-");
V g_heff_2esyntax_2ecst_2estatementF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2estatementF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estatementF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2estatementF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2estatementF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2estatementF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estatementF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2estatementF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2estatementF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estatementF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2estatementF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2estatementF_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2415, v_x_2416, v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estatementF_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam5, 1, 3, (V[]){v_k_242, v_x_2415, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estatementF_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2estatementF_lam8(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_ESBind, 3, (V[]){v_x_2420, v_x_2421, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2estatementF_lam7(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam8, 1, 3, (V[]){v_k_242, v_x_2420, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2estatementF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam7, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2420})));
}
V g_heff_2esyntax_2ecst_2estatementF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2estatementF_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2estatementF_str1))) {
      heff_drop_rec(v_x_2410, 9);
      heff_drop_rec(v_x_245, 9);
      return (g_heff_2esyntax_2ecst_2eletStmtF(v_g_240, v_hd_241, v_k_242));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str2))) {
        if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str3))) {
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam3, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
        } else {
          V f_ = heff_get_n(v_g_240, 0, 13);
          heff_room[0] = v_hd_241;
          heff_room[1] = v_k_242;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop_rec(v_x_2410, 9);
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  } else {
    if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str4))) {
      if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2estatementF_str5))) {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam6, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
      } else {
        V f_ = heff_get_n(v_g_240, 0, 13);
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_2410, 9);
      V f_ = heff_get_n(v_g_240, 0, 13);
      heff_room[0] = v_hd_241;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2esyntax_2ecst_2estatementF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2estatementF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2estatementF_lam2, 1, 4, (V[]){v_x_245, v_g_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str1, 12, "a field name");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str2, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str3, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2erecordPatF_str4, 1, "}");
V g_heff_2esyntax_2ecst_2erecordPatF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2erecordPatF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2erecordPatF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2erecordPatF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2erecordPatF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2erecordPatF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_PField, 3, (V[]){v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 5, 13);
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam4, 1, 3, (V[]){v_k_245, v_x_246, v_x_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str2), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam3, 1, 4, (V[]){v_g_240, v_hd_244, v_k_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str0), ((V)&g_heff_2esyntax_2ecst_2erecordPatF_str1), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam2, 1, 3, (V[]){v_hd_244, v_g_240, v_k_245})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam8(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2418;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_MkSep: {
    V v_items_2416 = heff_field(v_x_2414, 0);
    V v_seps_2417 = heff_field(v_x_2414, 1);
    heff_take_n(v_x_2414, 3ULL, 2);
    v_x_2418 = heff_tag_n(TAG_PRec, 4, (V[]){v_x_243, v_items_2416, v_seps_2417, v_x_2415});
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V f_ = v_k_2411;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2410 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str4), v_hd_2410, heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam8, 1, 3, (V[]){v_x_2414, v_x_243, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam6(V self, V *args) {
  V v_x_2412 = args[0];
  V v_p_249 = heff_env(self)[0];
  V v_hd_2410 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2erecordPatF_str3), v_p_249, v_t_2413, NTAG(TAG_Nil), heff_dup(v_hd_2410), heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam7, 1, 3, (V[]){v_hd_2410, v_x_243, v_k_2411})));
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam5(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_p_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(v_p_249);
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam6, 1, 4, (V[]){v_p_249, v_hd_2410, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2erecordPatF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_p_249 = heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam1, 2, 1, (V[]){v_g_240});
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2erecordPatF_lam5, 2, 2, (V[]){v_p_249, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatHeadF_str0, 3, "con");
V g_heff_2esyntax_2ecst_2epatHeadF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatHeadF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2epatHeadF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatHeadF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatHeadF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatHeadF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2epatHeadF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatHeadF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PCon, 2, (V[]){v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_240, 7, 13), NTAG(TAG_Nil), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam2, 1, 2, (V[]){v_k_242, v_x_247})));
}
V g_heff_2esyntax_2ecst_2epatHeadF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_get_n(v_x_245, 0, 9), ((V)&g_heff_2esyntax_2ecst_2epatHeadF_str0))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatHeadF_lam1, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
  } else {
    V f_ = heff_get_n(v_g_240, 7, 13);
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatternF_str0, 3, "sym");
V g_heff_2esyntax_2ecst_2epatternF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2epatternF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatternF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatternF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatternF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return heff_tail(heff_dup(heff_rfield(v_g_240, 6)), 2, (V[]){heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2epatternF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatternF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatternF_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_POp, 3, (V[]){v_x_243, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatternF_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 5, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam4, 1, 3, (V[]){v_k_242, v_x_243, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2epatternF_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2epatternF_str0))) {
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_246, 1, 9)}));
    V v_x1_2410 = ({ V a_0 = v_t_249; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_True: {
      heff_drop(v_x_247);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 13);
      V f_ = v_k_242;
      args[0] = v_x_243;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      switch (heff_tag_of(v_x_247)) {
      case TAG_True: {
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 13);
        V f_ = v_k_242;
        args[0] = v_x_243;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam3, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243})));
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  } else {
    heff_drop(v_x_247);
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 13);
    V f_ = v_k_242;
    args[0] = v_x_243;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2epatternF_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam2, 1, 5, (V[]){v_x_246, v_k_242, v_x_243, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2epatternF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatternF_lam1, 1, 4, (V[]){v_hd_241, v_k_242, v_x_243, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str0, 1, "]");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str1, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str2, 1, "]");
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3, 2, 0};
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(V v_item_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0, 1, 3, (V[]){v_item_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  V f_ = v_k_2411;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2415, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str1), v_item_240, v_t_2416, NTAG(TAG_Nil), v_hd_2413, v_k_2414));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(v_item_240);
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam5, 1, 3, (V[]){v_item_240, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkSep: {
    V v_items_2420 = heff_field(v_x_2418, 0);
    V v_seps_2421 = heff_field(v_x_2418, 1);
    heff_take_n(v_x_2418, 3ULL, 2);
    v_x_2422 = heff_tag_n(TAG_PList, 4, (V[]){v_x_243, v_items_2420, v_seps_2421, v_x_2419});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_245;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam7, 1, 3, (V[]){v_x_2418, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2417;
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_str0))) {
    heff_drop(v_item_240);
    v_c_2417 = ((V)&g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam3_clo);
  } else {
    v_c_2417 = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam4, 2, 1, (V[]){v_item_240});
  }
  V f_ = v_c_2417;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam6, 1, 3, (V[]){v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_item_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_247;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam2, 1, 4, (V[]){v_item_240, v_hd_244, v_x_243, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119_lam1, 2, 2, (V[]){v_item_240, v_x_243}), v_hd_241, v_k_242));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str0, 18, "expected a pattern");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str2, 1, "@");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str3, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str4, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str5, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str6, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str7, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str8, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str9, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str10, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str11, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str12, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str13, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str14, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str16, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str17, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str19, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2epatAtomF_str20, 24, "expected a pattern, not ");
V g_heff_2esyntax_2ecst_2epatAtomF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2epatAtomF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatAtomF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2epatAtomF_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2epatAtomF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatAtomF_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2epatAtomF_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2epatAtomF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2epatAtomF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2epatAtomF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2epatAtomF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_g_240})});
}
V g_heff_2esyntax_2ecst_2epatAtomF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2epatAtomF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_t_2412 = heff_intAdd(heff_dup(heff_rfield(v_s_2411, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2411, v_t_2412));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2425 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PAs, 3, (V[]){v_x_2425, v_x_2426, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 7, 13);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam8, 1, 3, (V[]){v_k_242, v_x_2425, v_x_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam6(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam7, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_PAtom, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam13(V self, V *args) {
  V v_x_2444 = args[0];
  V v_k_2442 = heff_env(self)[0];
  V v_x_2440 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_PParen, 3, (V[]){v_x_2440, v_x_2443, v_x_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam12(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_2441 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  V v_x_2440 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2epatAtomF_str15), v_hd_2441, heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam13, 1, 3, (V[]){v_k_2442, v_x_2440, v_x_2443})));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam11(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_x_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_get_n(v_g_240, 5, 13);
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam12, 1, 3, (V[]){v_hd_2441, v_k_2442, v_x_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam10(V self, V *args) {
  V v_x_2440 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam11, 2, 2, (V[]){v_g_240, v_x_2440}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2416)) {
  case TAG_True: {
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_x_2415, 9);
    heff_drop_rec(v_g_240, 13);
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str0), v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_t_2424;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str1))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str2))) {
        if (heff_intEq_c(heff_dup(heff_rfield(v_x_245, 4)), heff_dup(heff_rfield(v_x_2410, 3)))) {
          v_t_2424 = heff_intEq(heff_get_n(v_x_2410, 4, 9), heff_get_n(v_x_2415, 3, 9));
        } else {
          heff_drop_rec(v_x_2410, 9);
          heff_drop_rec(v_x_2415, 9);
          v_t_2424 = NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_x_2415, 9);
        v_t_2424 = NTAG(TAG_False);
      }
    } else {
      heff_drop_rec(v_x_2410, 9);
      heff_drop_rec(v_x_2415, 9);
      v_t_2424 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      heff_drop_rec(v_x_245, 9);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam6, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
    }
    case TAG_False: {
      V v_t_2428 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_245, 0))}));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str3), NTAG(TAG_Nil)});
      V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str5), v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str7), v_t_2430})});
      V v_t_2432 = ({ V a_0 = v_t_2428; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_str8), v_t_2431}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2432)) {
      case TAG_True: {
        heff_drop_rec(v_x_245, 9);
        heff_drop_rec(v_g_240, 13);
        return (g_heff_2esyntax_2ecst_2enext(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam9, 1, 1, (V[]){v_k_242})));
      }
      case TAG_False: {
        V v_t_2435;
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str9))) {
          v_t_2435 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str10));
        } else {
          v_t_2435 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2435)) {
        case TAG_True: {
          heff_drop_rec(v_x_245, 9);
          return (g_heff_2esyntax_2ecst_2elistOfF_24s306148072x1877150119(heff_get_n(v_g_240, 5, 13), v_hd_241, v_k_242));
        }
        case TAG_False: {
          V v_t_2437;
          if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str11))) {
            v_t_2437 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str12));
          } else {
            v_t_2437 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2437)) {
          case TAG_True: {
            heff_drop_rec(v_x_245, 9);
            return (g_heff_2esyntax_2ecst_2erecordPatF(v_g_240, v_hd_241, v_k_242));
          }
          case TAG_False: {
            V v_t_2439;
            if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str13))) {
              v_t_2439 = heff_strEq(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str14));
            } else {
              v_t_2439 = NTAG(TAG_False);
            }
            switch (heff_tag_of(v_t_2439)) {
            case TAG_True: {
              heff_drop_rec(v_x_245, 9);
              return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam10, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
            }
            case TAG_False: {
              heff_drop_rec(v_g_240, 13);
              V v_t_2446;
              if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str16))) {
                v_t_2446 = ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str17);
              } else {
                v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2epatAtomF_str18), heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2epatAtomF_str19)));
              }
              V v_msg_2447 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2epatAtomF_str20), v_t_2446);
              V v_t_2448 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
              V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2447, v_t_2448, NTAG(TAG_Nothing)});
              V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2449})});
              V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2450}));
              V f_ = heff_get_n(v_hd_241, 1, 3);
              heff_room[0] = v_t_2451;
              heff_room[1] = v_k_242;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
            default: return heff_nomatch(v_t_2439);
            }
          }
          default: return heff_nomatch(v_t_2437);
          }
        }
        default: return heff_nomatch(v_t_2435);
        }
      }
      default: return heff_nomatch(v_t_2432);
      }
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam5, 1, 6, (V[]){v_x_245, v_hd_241, v_k_242, v_x_2410, v_x_2415, v_g_240})));
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_lam3_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam4, 1, 5, (V[]){v_hd_241, v_x_245, v_k_242, v_x_2410, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2epatAtomF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2epatAtomF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2epatAtomF_lam2, 1, 4, (V[]){v_hd_241, v_x_245, v_k_242, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam1, 2, 0};
V g_heff_2esyntax_2ecst_2egram_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam4, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam8, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam12(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam12, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam13(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam13, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam14(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam14, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam15(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam15, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam16(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam16, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam17(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam17, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam18, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam22(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam21(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam20(V self, V *args);
V g_heff_2esyntax_2ecst_2egram_lam19(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam19, 1, 0};
V g_heff_2esyntax_2ecst_2egram_lam23(V self, V *args); static Clo g_heff_2esyntax_2ecst_2egram_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2egram_lam23, 1, 0};

static V g_heff_2esyntax_2ecst_2egram_val;
static HEFF_ONCE g_heff_2esyntax_2ecst_2egram_st;
static V g_heff_2esyntax_2ecst_2egram_init(void) {
  return heff_rec_n(13, shape_expr__opExpr__userOps__app__atom__pattern__patHead__patAtom__lambda__caseE__ifE__doE__letE, (V[]){((V)&g_heff_2esyntax_2ecst_2egram_lam0_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam1_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam4_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam8_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam12_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam13_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam14_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam15_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam16_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam17_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam18_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam19_clo), ((V)&g_heff_2esyntax_2ecst_2egram_lam23_clo)});
}
V g_heff_2esyntax_2ecst_2egram_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2ecst_2egram_st)) return g_heff_2esyntax_2ecst_2egram_val;
  return heff_global(&g_heff_2esyntax_2ecst_2egram_val, &g_heff_2esyntax_2ecst_2egram_st, g_heff_2esyntax_2ecst_2egram_init);
}
V g_heff_2esyntax_2ecst_2egram_lam0(V self, V *args) {
  V v_st_240 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eexprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_240;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam3(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_minPrec_241 = heff_env(self)[1];
  V v_st_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eopLoopF(v_g_243, v_minPrec_241, v_x_245, v_st_242, v_k_244));
}
V g_heff_2esyntax_2ecst_2egram_lam2(V self, V *args) {
  V v_k_244 = args[0];
  V v_g_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_minPrec_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_243, 2));
  heff_room[0] = heff_dup(v_st_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam3, 1, 4, (V[]){v_g_243, v_minPrec_241, v_st_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam1(V self, V *args) {
  V v_minPrec_241 = args[0];
  V v_st_242 = args[1];
  V v_g_243 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam2, 1, 3, (V[]){v_g_243, v_st_242, v_minPrec_241});
}
V g_heff_2esyntax_2ecst_2egram_lam7(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nil: {
    v_x_2413 = v_x_249;
    break;
  }
  case TAG_Cons: {
    v_x_2413 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_249, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V f_ = v_k_248;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam6(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eoperandsF(v_g_247, NTAG(TAG_Nil), v_st_246, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam7, 1, 2, (V[]){v_x_249, v_k_248})));
}
V g_heff_2esyntax_2ecst_2egram_lam5(V self, V *args) {
  V v_k_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_g_247, 3));
  heff_room[0] = heff_dup(v_st_246);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam6, 1, 3, (V[]){v_g_247, v_st_246, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam4(V self, V *args) {
  V v_st_246 = args[0];
  V v_g_247 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam5, 1, 2, (V[]){v_g_247, v_st_246});
}
V g_heff_2esyntax_2ecst_2egram_lam11(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Nil: {
    v_x_2421 = v_x_2417;
    break;
  }
  case TAG_Cons: {
    v_x_2421 = heff_tag_n(TAG_App, 2, (V[]){v_x_2417, v_x_2418});
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V f_ = v_k_2416;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam10(V self, V *args) {
  V v_x_2417 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_st_2414 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_get_n(v_g_2415, 4, 13), NTAG(TAG_Nil), v_st_2414, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam11, 1, 2, (V[]){v_x_2417, v_k_2416})));
}
V g_heff_2esyntax_2ecst_2egram_lam9(V self, V *args) {
  V v_k_2416 = args[0];
  V v_g_2415 = heff_env(self)[0];
  V v_st_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = heff_dup(heff_rfield(v_g_2415, 4));
  heff_room[0] = heff_dup(v_st_2414);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam10, 1, 3, (V[]){v_g_2415, v_st_2414, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam8(V self, V *args) {
  V v_st_2414 = args[0];
  V v_g_2415 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam9, 1, 2, (V[]){v_g_2415, v_st_2414});
}
V g_heff_2esyntax_2ecst_2egram_lam12(V self, V *args) {
  V v_st_2422 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eatomF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam13(V self, V *args) {
  V v_st_2423 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatternF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2423;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam14(V self, V *args) {
  V v_st_2424 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatHeadF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2424;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam15(V self, V *args) {
  V v_st_2425 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2epatAtomF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2425;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam16(V self, V *args) {
  V v_st_2426 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2elambdaF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2426;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam17(V self, V *args) {
  V v_st_2427 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2ecaseExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam18(V self, V *args) {
  V v_st_2428 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eifExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2428;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2egram_lam22(V self, V *args) {
  V v_x_2434 = args[0];
  V v_k_2431 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Do, 2, (V[]){v_x_2432, v_x_2434});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2egram_lam21(V self, V *args) {
  V v_x_2432 = args[0];
  V v_g_2430 = heff_env(self)[0];
  V v_st_2429 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tr(heff_call(((V)&g_heff_2esyntax_2ecst_2estatementF_clo), 1, (V[]){v_g_2430}));
  return (g_heff_2esyntax_2ecst_2eblock(v_t_2433, v_st_2429, heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam22, 1, 2, (V[]){v_k_2431, v_x_2432})));
}
V g_heff_2esyntax_2ecst_2egram_lam20(V self, V *args) {
  V v_k_2431 = args[0];
  V v_st_2429 = heff_env(self)[0];
  V v_g_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_st_2429), heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam21, 1, 3, (V[]){v_g_2430, v_st_2429, v_k_2431})));
}
V g_heff_2esyntax_2ecst_2egram_lam19(V self, V *args) {
  V v_st_2429 = args[0];
  V v_g_2430 = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  return heff_clo_n(g_heff_2esyntax_2ecst_2egram_lam20, 1, 2, (V[]){v_st_2429, v_g_2430});
}
V g_heff_2esyntax_2ecst_2egram_lam23(V self, V *args) {
  V v_st_2435 = args[0];
  V f_ = ((V)&g_heff_2esyntax_2ecst_2eletExprF_clo);
  heff_room[0] = heff_dup(g_heff_2esyntax_2ecst_2egram_get());
  heff_room[1] = v_st_2435;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam3(V self, V *args) {
  V v_a_2411 = args[0];
  V v_a_2410 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_a_2410, v_a_2411}), v_items_241});
  return (g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363(v_sep_240, v_t_2412, heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam2(V self, V *args) {
  V v_a_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_seps_242 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam3, 1, 7, (V[]){v_a_2410, v_items_241, v_sep_240, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_sep_240 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam2, 1, 6, (V[]){v_hd_243, v_items_241, v_sep_240, v_x_249, v_seps_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363_lam1, 1, 5, (V[]){v_hd_243, v_items_241, v_sep_240, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2413, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242))});
    V f_ = v_k_244;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str1, 1, "|");
HEFF_LIT(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str2, 1, "}");
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkSep: {
    V v_items_2411 = heff_field(v_x_249, 0);
    V v_seps_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    v_x_2413 = heff_tag_n(TAG_Sum, 5, (V[]){v_x_242, v_x_243, v_items_2411, v_seps_2412, v_x_2410});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_245;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str2), v_hd_244, heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam6, 1, 4, (V[]){v_x_249, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ECon, 2, (V[]){v_x_246, v_x_247}), NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo_24s1451169230x584062363(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str1), v_t_248, NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam5, 1, 4, (V[]){v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam4, 1, 5, (V[]){v_x_246, v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam2(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam3, 1, 4, (V[]){v_hd_244, v_x_242, v_x_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam2, 2, 2, (V[]){v_x_242, v_x_243}), v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_str0), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_lam1, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str5, 4, "case");
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry, 2, 0};

V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(1LL), v_x_2411, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(1LL), v_x_2412, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str0))) {
    heff_drop_rec(v_x_244, 9);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, v_k_241));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str1))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_244, 1, 9)}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str2), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str4), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_247; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_str5), v_t_249}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, v_k_241));
      }
      case TAG_False: {
        V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
        heff_room[0] = heff_dup(v_hd_240);
        heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam1, 1, 2, (V[]){v_hd_240, v_k_241});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_t_2410);
      }
    } else {
      heff_drop_rec(v_x_244, 9);
      V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
      heff_room[0] = heff_dup(v_hd_240);
      heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_lam2, 1, 2, (V[]){v_hd_240, v_k_241});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6, 1, "~");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7, 2, "->");
HEFF_LIT(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8, 1, "~");
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(V v_minPrec_240, V v_lhs_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0, 1, 4, (V[]){v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_minPrec_2429 = heff_env(self)[0];
  V v_st_2430 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_minPrec_2429, v_x_2432, v_st_2430, v_k_2431));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3(V self, V *args) {
  V v_st_2430 = args[0];
  V v_k_2431 = args[1];
  V v_minPrec_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
  args[0] = heff_dup(v_st_2430);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam4, 1, 3, (V[]){v_minPrec_2429, v_st_2430, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_minPrec_240 = heff_env(self)[0];
  V v_lhs_241 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(v_minPrec_240, heff_tag_n(TAG_Op, 3, (V[]){v_lhs_241, v_x_2420, v_x_2434}), v_hd_242, v_k_243));
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_minPrec_240 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_s_2421 = heff_dup(heff_rfield(v_x_246, 1));
  V v_t_2424;
  if (heff_strEq_c(heff_dup(v_s_2421), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str5))) {
    heff_drop(v_s_2421);
    v_t_2424 = MK_INT(1LL);
  } else {
    if (heff_strEq_c(v_s_2421, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str6))) {
      v_t_2424 = MK_INT(2LL);
    } else {
      v_t_2424 = MK_INT(-1LL);
    }
  }
  V v_c_2433;
  if (heff_intEq_c(v_t_2424, MK_INT(1LL))) {
    heff_drop_rec(v_x_246, 9);
    v_c_2433 = ((V)&g_heff_2esyntax_2ecst_2earrowRhsF_24s1782326137x326931407_clo);
  } else {
    V v_s_2426 = heff_get_n(v_x_246, 1, 9);
    V v_minPrec_2429;
    if (heff_strEq_c(heff_dup(v_s_2426), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str7))) {
      heff_drop(v_s_2426);
      v_minPrec_2429 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_2426, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str8))) {
        v_minPrec_2429 = MK_INT(2LL);
      } else {
        v_minPrec_2429 = MK_INT(-1LL);
      }
    }
    v_c_2433 = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam3, 2, 1, (V[]){v_minPrec_2429});
  }
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam5, 1, 5, (V[]){v_minPrec_240, v_lhs_241, v_x_2420, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_lhs_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2419;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str0))) {
    V v_s_249 = heff_dup(heff_rfield(v_x_246, 1));
    V v_a_2412;
    if (heff_strEq_c(heff_dup(v_s_249), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str1))) {
      heff_drop(v_s_249);
      v_a_2412 = MK_INT(1LL);
    } else {
      if (heff_strEq_c(v_s_249, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str2))) {
        v_a_2412 = MK_INT(2LL);
      } else {
        v_a_2412 = MK_INT(-1LL);
      }
    }
    if (heff_intLe_c(MK_INT(1LL), v_a_2412)) {
      V v_s_2414 = heff_dup(heff_rfield(v_x_246, 1));
      V v_a_2417;
      if (heff_strEq_c(heff_dup(v_s_2414), ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str3))) {
        heff_drop(v_s_2414);
        v_a_2417 = MK_INT(1LL);
      } else {
        if (heff_strEq_c(v_s_2414, ((V)&g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_str4))) {
          v_a_2417 = MK_INT(2LL);
        } else {
          v_a_2417 = MK_INT(-1LL);
        }
      }
      if (heff_intLe_c(heff_dup(v_minPrec_240), v_a_2417)) {
        switch (heff_tag_of(v_x_247)) {
        case TAG_True: {
          v_t_2419 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2419 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_247);
        }
      } else {
        heff_drop(v_x_247);
        v_t_2419 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_x_247);
      v_t_2419 = NTAG(TAG_False);
    }
  } else {
    heff_drop(v_x_247);
    v_t_2419 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam2, 1, 5, (V[]){v_x_246, v_hd_242, v_minPrec_240, v_lhs_241, v_k_243})));
  }
  case TAG_False: {
    heff_drop_rec(v_x_246, 9);
    heff_drop(v_minPrec_240);
    heff_drop_rec(v_hd_242, 3);
    V f_ = v_k_243;
    args[0] = v_lhs_241;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2419);
  }
}
V g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_minPrec_240 = heff_env(self)[1];
  V v_lhs_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966_lam1, 1, 5, (V[]){v_x_246, v_minPrec_240, v_hd_242, v_lhs_241, v_k_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11, 3, "let");
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4, 2, 0};
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6, 2, 0};
Clo g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(V v_t_240) {
top: ;
  V v_t_242;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str0))) {
    v_t_242 = heff_strEq(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str1));
  } else {
    v_t_242 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop_rec(v_t_240, 9);
    return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 8));
  }
  case TAG_False: {
    V v_t_244;
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str2))) {
      v_t_244 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str3));
    } else {
      v_t_244 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop_rec(v_t_240, 9);
      return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 9));
    }
    case TAG_False: {
      V v_t_246;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str4))) {
        v_t_246 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str5));
      } else {
        v_t_246 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_246)) {
      case TAG_True: {
        heff_drop_rec(v_t_240, 9);
        return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 10));
      }
      case TAG_False: {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str6))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str7))) {
            heff_drop_rec(v_t_240, 9);
            return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 11));
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str8))) {
              if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str9))) {
                return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 12));
              } else {
                return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0_clo);
              }
            } else {
              heff_drop_rec(v_t_240, 9);
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2_clo);
            }
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str10))) {
            if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_str11))) {
              return heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 12));
            } else {
              return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4_clo);
            }
          } else {
            heff_drop_rec(v_t_240, 9);
            return ((V)&g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6_clo);
          }
        }
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(a[0]);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_st_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_x_2413, v_st_2411, v_k_2412));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam0(V self, V *args) {
  V v_st_2411 = args[0];
  V v_k_2412 = args[1];
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
  args[0] = heff_dup(v_st_2411);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam1, 1, 2, (V[]){v_st_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_k_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_x_2416, v_st_2414, v_k_2415));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam2(V self, V *args) {
  V v_st_2414 = args[0];
  V v_k_2415 = args[1];
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
  args[0] = heff_dup(v_st_2414);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam3, 1, 2, (V[]){v_st_2414, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5(V self, V *args) {
  V v_x_2421 = args[0];
  V v_st_2419 = heff_env(self)[0];
  V v_k_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_x_2421, v_st_2419, v_k_2420));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam4(V self, V *args) {
  V v_st_2419 = args[0];
  V v_k_2420 = args[1];
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
  args[0] = heff_dup(v_st_2419);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam5, 1, 2, (V[]){v_st_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam7(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_2422 = heff_env(self)[0];
  V v_k_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eopLoopF_24s1630971941x1425987966(MK_INT(0LL), v_x_2424, v_st_2422, v_k_2423));
}
V g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam6(V self, V *args) {
  V v_st_2422 = args[0];
  V v_k_2423 = args[1];
  V f_ = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 2));
  args[0] = heff_dup(v_st_2422);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755_lam7, 1, 2, (V[]){v_st_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_249, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_str1))) {
      switch (heff_tag_of(v_x_2410)) {
      case TAG_True: {
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
      default: return heff_nomatch(v_x_2410);
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(v_x_244));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_lam1, 1, 2, (V[]){v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str2, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str4, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str5, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str7, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str9, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str12, 1, ")");
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam6(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, heff_tag_n(TAG_Atom, 1, (V[]){v_x_2417}), v_x_2418});
  V f_ = v_k_244;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam5(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam6, 1, 3, (V[]){v_x_242, v_x_2417, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam10(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_x_2426 = heff_env(self)[3];
  V v_x_2427 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_Named, 5, (V[]){v_x_242, v_x_2425, v_x_2426, v_x_2427, v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam9(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  V v_x_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str8), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam10, 1, 5, (V[]){v_k_244, v_x_242, v_x_2425, v_x_2426, v_x_2427})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam8(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam9, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam8, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2425})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam14(V self, V *args) {
  V v_x_2436 = args[0];
  V v_x_2435 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2439;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkSep: {
    V v_items_2437 = heff_field(v_x_2435, 0);
    V v_seps_2438 = heff_field(v_x_2435, 1);
    heff_take_n(v_x_2435, 3ULL, 2);
    v_x_2439 = heff_tag_n(TAG_Tup, 4, (V[]){v_x_242, v_items_2437, v_seps_2438, v_x_2436});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_k_244;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam13(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str11), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam14, 1, 3, (V[]){v_x_2435, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam15(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_EParen, 3, (V[]){v_x_242, v_x_2429, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam12(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_get_n(v_x_2432, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str9))) {
    V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, NTAG(TAG_Nil)});
    return (g_heff_2esyntax_2ecst_2esepGo(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str10), heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0)), v_t_2434, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  } else {
    return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str12), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam15, 1, 3, (V[]){v_k_244, v_x_242, v_x_2429})));
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam11(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2430}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam12, 1, 4, (V[]){v_x_2429, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str0))) {
    V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_247, 1))}));
    V v_x1_2415 = ({ V a_0 = v_t_2414; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_True: {
      v_t_2416 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2416 = heff_strEq(heff_dup(heff_rfield(v_x_2412, 1)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str1));
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
  } else {
    v_t_2416 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2416)) {
  case TAG_True: {
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_x_247, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam5, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
  }
  case TAG_False: {
    V v_t_2424;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str2))) {
      heff_drop_rec(v_x_247, 9);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str3))) {
        v_t_2424 = heff_strEq(heff_get_n(v_x_2412, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str4));
      } else {
        heff_drop_rec(v_x_2412, 9);
        v_t_2424 = NTAG(TAG_False);
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_247, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str5))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str6))) {
          v_t_2424 = heff_strEq(heff_get_n(v_x_2412, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_str7));
        } else {
          heff_drop_rec(v_x_2412, 9);
          v_t_2424 = NTAG(TAG_False);
        }
      } else {
        heff_drop_rec(v_x_2412, 9);
        v_t_2424 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2424)) {
    case TAG_True: {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam7, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
    }
    case TAG_False: {
      return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam11, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam2, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552(V v_lit_240, V v_sep_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam0, 1, 6, (V[]){v_sep_241, v_hd_244, v_lit_240, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam4(V self, V *args) {
  V v_a_2413 = args[0];
  V v_a_2411 = heff_env(self)[0];
  V v_a_2412 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_sep_241 = heff_env(self)[4];
  V v_x_2410 = heff_env(self)[5];
  V v_seps_243 = heff_env(self)[6];
  V v_hd_244 = heff_env(self)[7];
  V v_k_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFSet, 3, (V[]){v_a_2411, v_a_2412, v_a_2413}), v_items_242});
  return (g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552(v_lit_240, v_sep_241, v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}), v_hd_244, v_k_245));
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam3(V self, V *args) {
  V v_a_2412 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_sep_241 = heff_env(self)[4];
  V v_x_2410 = heff_env(self)[5];
  V v_seps_243 = heff_env(self)[6];
  V v_k_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam4, 1, 9, (V[]){v_a_2411, v_a_2412, v_items_242, v_lit_240, v_sep_241, v_x_2410, v_seps_243, v_hd_244, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam2(V self, V *args) {
  V v_a_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_sep_241 = heff_env(self)[3];
  V v_x_2410 = heff_env(self)[4];
  V v_seps_243 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eexpectSym(heff_dup(v_lit_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam3, 1, 8, (V[]){v_hd_244, v_a_2411, v_items_242, v_lit_240, v_sep_241, v_x_2410, v_seps_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_sep_241 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam2, 1, 7, (V[]){v_lit_240, v_hd_244, v_items_242, v_sep_241, v_x_2410, v_seps_243, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_241))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552_lam1, 1, 6, (V[]){v_hd_244, v_lit_240, v_items_242, v_sep_241, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_lit_240);
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_x_2416 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2415, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243))});
    V f_ = v_k_245;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str1, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str2, 2, ":=");
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_EFDefault, 3, (V[]){v_x_242, v_x_2411, v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam4, 1, 3, (V[]){v_k_241, v_x_242, v_x_2411})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str0))) {
    V v_t_2410;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str1))) {
      heff_drop_rec(v_x_245, 9);
      switch (heff_tag_of(v_x_246)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x_246);
      }
    } else {
      if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_str2))) {
        switch (heff_tag_of(v_x_246)) {
        case TAG_True: {
          v_t_2410 = NTAG(TAG_False);
          break;
        }
        case TAG_False: {
          v_t_2410 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x_246);
        }
      } else {
        heff_drop(v_x_246);
        v_t_2410 = NTAG(TAG_False);
      }
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam3, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
    }
    case TAG_False: {
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_242;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_t_2410);
    }
  } else {
    heff_drop(v_x_246);
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_242;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam2, 1, 4, (V[]){v_x_245, v_hd_240, v_k_241, v_x_242})));
}
V g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_243}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_244;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(v_sep_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242))});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str0, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str1, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str2, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str3, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str5, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str6, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str7, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str8, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str9, 1, "}");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str10, 1, ",");
HEFF_LIT(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str11, 1, "}");
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3(V self, V *args); static Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3, 1, 0};
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry, 2, 0};

V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3(V self, V *args) {
  V v_s_248 = args[0];
  V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_s_248, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_248, v_t_249));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_244;
  args[0] = heff_tag_n(TAG_InstB, 5, (V[]){v_x_242, v_x_2415, v_x_2416, v_x_2417, v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_x_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str3), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam8, 1, 5, (V[]){v_k_244, v_x_242, v_x_2415, v_x_2416, v_x_2417})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str2), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam7, 1, 5, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415, v_x_2416})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0)), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam6, 1, 4, (V[]){v_hd_243, v_k_244, v_x_242, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, NTAG(TAG_Nil), NTAG(TAG_Nil), v_x_2420});
  V f_ = v_k_244;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2431;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkSep: {
    V v_items_2429 = heff_field(v_x_2427, 0);
    V v_seps_2430 = heff_field(v_x_2427, 1);
    heff_take_n(v_x_2427, 3ULL, 2);
    v_x_2431 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2429, v_seps_2430, v_x_2428});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_244;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str9), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam14, 1, 3, (V[]){v_x_2427, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_x_2424 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFSet, 3, (V[]){v_x_2423, v_x_2424, v_x_2425}), NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo_24s887028397x1731080552(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str7), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str8), v_t_2426, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam13, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam12, 1, 5, (V[]){v_x_2423, v_x_2424, v_hd_243, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str6), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam11, 1, 4, (V[]){v_hd_243, v_x_2423, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2438;
  switch (heff_tag_of(v_x_2434)) {
  case TAG_MkSep: {
    V v_items_2436 = heff_field(v_x_2434, 0);
    V v_seps_2437 = heff_field(v_x_2434, 1);
    heff_take_n(v_x_2434, 3ULL, 2);
    v_x_2438 = heff_tag_n(TAG_Braces, 4, (V[]){v_x_242, v_items_2436, v_seps_2437, v_x_2435});
    break;
  }
  default: heff_nomatch(v_x_2434);
  }
  V f_ = v_k_244;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectPunct(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str11), v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam17, 1, 3, (V[]){v_x_2434, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2432, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo_24s645774059x2076817610(((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str10), v_t_2433, NTAG(TAG_Nil), heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam16, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str0))) {
    v_t_2414 = heff_strEq(heff_dup(heff_rfield(v_x_247, 1)), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str1));
  } else {
    v_t_2414 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_2414)) {
  case TAG_True: {
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_x_247, 9);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam5, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242})));
  }
  case TAG_False: {
    if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str4))) {
      heff_drop_rec(v_x_2412, 9);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_243, heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam9, 1, 2, (V[]){v_x_242, v_k_244})));
    } else {
      if (heff_strEq_c(heff_get_n(v_x_2412, 1, 9), ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_str5))) {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam10, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      } else {
        return (g_heff_2esyntax_2ecst_2edefaultedF_24s320943895x225118697(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam15, 1, 3, (V[]){v_hd_243, v_x_242, v_k_244})));
      }
    }
  }
  default: return heff_nomatch(v_t_2414);
  }
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam3_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam4, 1, 4, (V[]){v_x_247, v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  args[0] = v_t_246;
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam2, 1, 3, (V[]){v_hd_243, v_k_244, v_x_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2einBrackets(heff_clo_n(g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_lam1, 2, 1, (V[]){v_x_242}), v_hd_240, v_k_241));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str0, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str1, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str2, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str3, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str4, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str6, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str7, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str8, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str10, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str12, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str13, 5, "Float");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str14, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str15, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str16, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str17, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str18, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str19, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str20, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str21, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str22, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str23, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str24, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str25, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str26, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str27, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str28, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str29, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str30, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str31, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str32, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str33, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str35, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str36, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1, 2, 0};
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 0))}));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str2), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str4), v_t_243})});
  V v_t_245 = ({ V a_0 = v_t_241; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str5), v_t_244}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2417;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_2417 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str6))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str7), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str9), v_t_248})});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str11), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str13), v_t_2410})});
      V v_t_2412 = ({ V a_0 = v_t_247; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str14), v_t_2411}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        V v_x3_2415 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0, 1, 1, (V[]){heff_dup(v_t_240)}); V b_1 = heff_dup(g_heff_2eelab_2efixed_2eallFixed_get()); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_x3_2415)) {
        case TAG_Nothing: {
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2415, 0ULL, 1);
          v_t_2417 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_x3_2415);
        }
        break;
      }
      default: heff_nomatch(v_t_2412);
      }
    } else {
      v_t_2417 = NTAG(TAG_False);
    }
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_2417)) {
  case TAG_True: {
    heff_drop_rec(v_t_240, 9);
    return ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1_clo);
  }
  case TAG_False: {
    V v_t_2422;
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str24))) {
      v_t_2422 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str25));
    } else {
      v_t_2422 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2422)) {
    case TAG_True: {
      heff_drop_rec(v_t_240, 9);
      return ((V)&g_heff_2esyntax_2ecst_2eanonymousSumF_24s1166573822x1278876809_clo);
    }
    case TAG_False: {
      V v_t_2424;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str26))) {
        v_t_2424 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str27));
      } else {
        v_t_2424 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        heff_drop_rec(v_t_240, 9);
        return ((V)&g_heff_2esyntax_2ecst_2eparensF_24s1117645302x1410938128_clo);
      }
      case TAG_False: {
        V v_t_2426;
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str28))) {
          v_t_2426 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str29));
        } else {
          v_t_2426 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2426)) {
        case TAG_True: {
          heff_drop_rec(v_t_240, 9);
          return ((V)&g_heff_2esyntax_2ecst_2ebracesF_24s55448273x375101051_clo);
        }
        case TAG_False: {
          V v_t_2428;
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str30))) {
            v_t_2428 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str31));
          } else {
            v_t_2428 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2428)) {
          case TAG_True: {
            heff_drop_rec(v_t_240, 9);
            return heff_tail(((V)&g_heff_2esyntax_2ecst_2elistOfF_24s1185797643x20886097_clo), 1, (V[]){heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 0))});
          }
          case TAG_False: {
            V v_t_2430;
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str32))) {
              v_t_2430 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str33);
            } else {
              v_t_2430 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str34), heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str35)));
            }
            V v_msg_2431 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str36), v_t_2430);
            return heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3, 2, 2, (V[]){v_t_240, v_msg_2431});
          }
          default: return heff_nomatch(v_t_2428);
          }
        }
        default: return heff_nomatch(v_t_2426);
        }
      }
      default: return heff_nomatch(v_t_2424);
      }
    }
    default: return heff_nomatch(v_t_2422);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(a[0]);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam0(V self, V *args) {
  V v_w_2413 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414;
  switch (heff_tag_of(v_w_2413)) {
  case TAG_I8: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str15);
    break;
  }
  case TAG_I16: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str16);
    break;
  }
  case TAG_I32: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str17);
    break;
  }
  case TAG_I64: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str18);
    break;
  }
  case TAG_U8: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str19);
    break;
  }
  case TAG_U16: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str20);
    break;
  }
  case TAG_U32: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str21);
    break;
  }
  case TAG_U64: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str22);
    break;
  }
  case TAG_F32: {
    v_t_2414 = ((V)&g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_str23);
    break;
  }
  default: heff_nomatch(v_w_2413);
  }
  return heff_strEq(v_t_2414, heff_get_n(v_t_240, 1, 9));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(v_hd_2418, heff_clo_n(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam2, 1, 1, (V[]){v_k_2419})));
}
V g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043_lam3(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_t_240 = heff_env(self)[0];
  V v_msg_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
  V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2431, v_t_2434, NTAG(TAG_Nothing)});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2432, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2432, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4, 28, "expected an expression, not ");
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efieldsGo(v_x_2416, v_hd_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247;
  switch (heff_tag_of(v_x_245)) {
  case TAG_True: {
    v_t_247 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_x1_246 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_244)));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_True: {
      v_t_247 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_247 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_246);
    }
    break;
  }
  default: heff_nomatch(v_x_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_249;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str0))) {
      v_t_249 = ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str1);
    } else {
      v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str2), heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str3)));
    }
    V v_msg_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_str4), v_t_249);
    V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2412 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2410, v_t_2411, NTAG(TAG_Nothing)});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2413}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2414;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_c_2415 = heff_tr(g_heff_2esyntax_2ecst_2eatomBase_24s1943752057x867978043(v_x_244));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_240);
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam2, 1, 2, (V[]){v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str0, 17, "no parameter here");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str2, 55, "a type's parameter is lower case, or given its type: `(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str3, 10, " :: Type)`");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str4, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataParam_str7, 17, "no parameter here");
V g_heff_2esyntax_2ecst_2edataParam_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edataParam_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataParam_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataParam_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edataParam(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2edataParam_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2edataParam_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataParam(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edataParam_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Atom, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataParam_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_True: {
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2edataParam_str0), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str1))) {
      V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2edataParam_str2), heff_strAppend(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str3)));
      V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2411, v_t_2412, NTAG(TAG_Nothing)});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2414}));
      V f_ = heff_get_n(v_hd_240, 1, 3);
      heff_room[0] = v_t_2415;
      heff_room[1] = v_k_241;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str4))) {
        heff_drop_rec(v_x_244, 9);
        return (g_heff_2esyntax_2ecst_2enext(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edataParam_lam2, 1, 1, (V[]){v_k_241})));
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str5))) {
          heff_drop_rec(v_x_244, 9);
          return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(v_hd_240, v_k_241));
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2edataParam_str6))) {
            heff_drop_rec(v_x_244, 9);
            return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(v_hd_240, v_k_241));
          } else {
            V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
            V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2edataParam_str7), v_t_2420, NTAG(TAG_Nothing)});
            V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
            V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2422}));
            V f_ = heff_get_n(v_hd_240, 1, 3);
            heff_room[0] = v_t_2423;
            heff_room[1] = v_k_241;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2esyntax_2ecst_2edataParam_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataParam_lam1, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyParams_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyParams_str1, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2emanyParams_str2, 1, "(");
V g_heff_2esyntax_2ecst_2emanyParams_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyParams_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emanyParams_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emanyParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emanyParams_entry, 3, 0};

V g_heff_2esyntax_2ecst_2emanyParams(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})));
}
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emanyParams(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2emanyParams_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2emanyParams_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_243)) {
  case TAG_True: {
    heff_drop_rec(v_x_246, 9);
    heff_drop_rec(v_hd_241, 3);
    V v_x_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_False: {
    V v_t_248 = (g_heff_2esyntax_2ecst_2estartsAtom(heff_dup(v_x_246)));
    V v_x1_2411;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop_rec(v_x_246, 9);
      v_x1_2411 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyParams_str0))) {
        heff_drop_rec(v_x_246, 9);
        v_x1_2411 = NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_246, 0)), ((V)&g_heff_2esyntax_2ecst_2emanyParams_str1))) {
          v_x1_2411 = heff_strEq(heff_get_n(v_x_246, 1, 9), ((V)&g_heff_2esyntax_2ecst_2emanyParams_str2));
        } else {
          heff_drop_rec(v_x_246, 9);
          v_x1_2411 = NTAG(TAG_False);
        }
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_True: {
      return (g_heff_2esyntax_2ecst_2edataParam(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam2, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
    }
    case TAG_False: {
      heff_drop_rec(v_hd_241, 3);
      V v_x_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
      V f_ = v_k_242;
      args[0] = v_x_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x_243);
  }
}
V g_heff_2esyntax_2ecst_2emanyParams_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_244}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_245;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2emanyParams_lam1, 1, 4, (V[]){v_x_243, v_acc_240, v_k_242, v_hd_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edataAlternative_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataAlternative_str1, 35, "a constructor starts with a capital");
V g_heff_2esyntax_2ecst_2edataAlternative_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataAlternative_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataAlternative_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataAlternative_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edataAlternative(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataAlternative_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2edataAlternative_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataAlternative(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2edataAlternative_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_ECon, 2, (V[]){v_x_242, v_x_244});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataAlternative_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2ecst_2edataAlternative_str0))) {
    return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2edataAlternative_lam1, 1, 2, (V[]){v_k_241, v_x_242})));
  } else {
    V v_t_245 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2edataAlternative_str1), v_t_245, NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_247}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_248;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str1, 62, "` names the type; its constructor needs another name, e.g. `Mk");
HEFF_LIT(g_heff_2esyntax_2ecst_2echeckAltNames_str2, 1, "`");
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_lam0, 2, 0};
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2echeckAltNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2echeckAltNames_entry, 2, 0};

V g_heff_2esyntax_2ecst_2echeckAltNames(V v_name_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_name_240);
    return ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EParen: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Named: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Tup: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Braces: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_InstB: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFSet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EFDefault: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Sum: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ECon: {
      V v_c_2439 = heff_field(v_x21_244, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_c_2439, 1)), heff_dup(v_name_240))) {
        heff_drop(v_name_240);
        return heff_clo_n(g_heff_2esyntax_2ecst_2echeckAltNames_lam1, 2, 1, (V[]){heff_dup(v_c_2439)});
      } else {
        V t_0 = v_name_240;
        V t_1 = v_rest_245;
        v_name_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    case TAG_EField: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_App: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Op: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ops: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_OpRhs: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Ann: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BVar: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BImp: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_BAnn: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Lam: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Case: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_EAlt: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_If: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Do: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ESBind: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      V t_0 = v_name_240;
      V t_1 = v_rest_245;
      v_name_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2ecst_2echeckAltNames_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2echeckAltNames(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2echeckAltNames_lam1(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str0), heff_strAppend(heff_dup(heff_rfield(v_c_2439, 1)), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str1), heff_strAppend(heff_dup(heff_rfield(v_c_2439, 1)), ((V)&g_heff_2esyntax_2ecst_2echeckAltNames_str2)))));
  V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_c_2439, 3), heff_get_n(v_c_2439, 4, 9)});
  V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2444, v_t_2445, NTAG(TAG_Nothing)});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2447}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2448;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam0, 1, 5, (V[]){v_sep_240, v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(v_sep_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}), heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}), v_hd_243, v_k_244));
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2edataAlternative(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_x_2412 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242))});
    V f_ = v_k_244;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str1, 18, "the name of a type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str4, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2edataDecl_str5, 1, "|");
V g_heff_2esyntax_2ecst_2edataDecl_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam4(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam4, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam8(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam8, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam9(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam9, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam12(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam12, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam16(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edataDecl_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_lam16, 2, 0};
V g_heff_2esyntax_2ecst_2edataDecl_lam18(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam17(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edataDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edataDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edataDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_2451 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_2451, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2edataDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edataDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam7(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2418;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nil: {
    v_x_2418 = v_x_2414;
    break;
  }
  case TAG_Cons: {
    v_x_2418 = heff_tag_n(TAG_App, 2, (V[]){v_x_2414, v_x_2415});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_x_2418})});
  V f_ = v_k_2412;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam6(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), v_hd_2411, heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam7, 1, 3, (V[]){v_x_2414, v_x_2413, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatomF_24s1127707874x1234301124(heff_dup(v_hd_2411), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam6, 1, 3, (V[]){v_hd_2411, v_x_2413, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam4(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2411), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam5, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam8(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam9(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam15(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_MkSep: {
    V v_items_2436 = heff_field(v_x_2435, 0);
    V v_seps_2437 = heff_field(v_x_2435, 1);
    heff_take_n(v_x_2435, 3ULL, 2);
    v_t_2438 = heff_tag_n(TAG_MkDAlts, 3, (V[]){v_x_2432, v_items_2436, v_seps_2437});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V v_x_2439 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2438});
  V f_ = v_k_2431;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam14(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2433, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2ecst_2esepGo_24s351168210x1581180939(((V)&g_heff_2esyntax_2ecst_2edataDecl_str5), v_t_2434, NTAG(TAG_Nil), v_hd_2430, heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam15, 1, 2, (V[]){v_x_2432, v_k_2431})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam13(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2edataAlternative(heff_dup(v_hd_2430), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam14, 1, 3, (V[]){v_hd_2430, v_x_2432, v_k_2431})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam12(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2430), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam13, 1, 2, (V[]){v_hd_2430, v_k_2431})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam16(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam18(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_2425 = heff_env(self)[4];
  V v_x_2443 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2450);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DData, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_2425, v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edataDecl_lam17(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_x_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2448;
  switch (heff_tag_of(v_x_2443)) {
  case TAG_Nothing: {
    v_t_2448 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x11_2444 = heff_dup(heff_field(v_x_2443, 0));
    switch (heff_tag_of(v_x11_2444)) {
    case TAG_MkDAlts: {
      V v_alts_2446 = heff_field(v_x11_2444, 1);
      heff_take_n(v_x11_2444, 2ULL, 3);
      v_t_2448 = v_alts_2446;
      break;
    }
    default: heff_nomatch(v_x11_2444);
    }
    break;
  }
  default: heff_nomatch(v_x_2443);
  }
  V v_c_2449 = ({ V a_0 = heff_dup(heff_rfield(v_x_244, 1)); V a_1 = v_t_2448; V r_ = (g_heff_2esyntax_2ecst_2echeckAltNames(a_0, a_1)); heff_drop(v_t_2448); r_; });
  V f_ = v_c_2449;
  heff_room[0] = v_hd_240;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam18, 1, 6, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_2425, v_x_2443});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam11(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_x_2425 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2442;
  if (heff_strEq_c(heff_get_n(v_x_2428, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str4))) {
    v_c_2442 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam12_clo);
  } else {
    v_c_2442 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam16_clo);
  }
  V f_ = v_c_2442;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam17, 1, 6, (V[]){v_x_244, v_hd_240, v_k_241, v_x_243, v_x_245, v_x_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam10(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2426}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam11, 1, 6, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243, v_x_245, v_x_2425});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2424;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_248, 1)), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str2))) {
    if (heff_strEq_c(heff_get_n(v_x_248, 0, 9), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str3))) {
      v_c_2424 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam4_clo);
    } else {
      v_c_2424 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam8_clo);
    }
  } else {
    heff_drop_rec(v_x_248, 9);
    v_c_2424 = ((V)&g_heff_2esyntax_2ecst_2edataDecl_lam9_clo);
  }
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam10, 1, 5, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_246}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_247;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam3, 1, 5, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2edataDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam2, 1, 4, (V[]){v_hd_240, v_x_244, v_k_241, v_x_243})));
}
V g_heff_2esyntax_2ecst_2edataDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2edataDecl_str0), ((V)&g_heff_2esyntax_2ecst_2edataDecl_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2edataDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str0, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str1, 3, "sym");
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_Ann, 3, (V[]){v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam5, 1, 3, (V[]){v_k_241, v_x_246, v_x_2413})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  V v_hd_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 1)), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_249, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_str1))) {
      switch (heff_tag_of(v_x_2410)) {
      case TAG_True: {
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = v_x_246;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam4, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246})));
      }
      default: return heff_nomatch(v_x_2410);
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = v_x_246;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = v_x_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam3, 1, 4, (V[]){v_x_249, v_k_241, v_x_246, v_hd_240})));
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam2, 1, 3, (V[]){v_hd_240, v_k_241, v_x_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245 = (g_heff_2esyntax_2ecst_2eexprHead_24s1201908996x573065755(v_x_244));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_240);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_lam1, 1, 2, (V[]){v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str1, 18, "the name of a type");
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str2, 1, "=");
V g_heff_2esyntax_2ecst_2etypeDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etypeDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etypeDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etypeDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_248 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_248, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etypeDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DType, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam4, 1, 5, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2etypeDecl_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2etypeDecl_str0), ((V)&g_heff_2esyntax_2ecst_2etypeDecl_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldDefault_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2efieldDefault_str1, 1, "=");
V g_heff_2esyntax_2ecst_2efieldDefault_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldDefault_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldDefault_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efieldDefault_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efieldDefault_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efieldDefault_entry, 2, 0};

V g_heff_2esyntax_2ecst_2efieldDefault(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2efieldDefault_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efieldDefault(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, v_x_249})});
  V f_ = v_k_241;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam3, 1, 2, (V[]){v_x_248, v_k_241})));
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2efieldDefault_str0))) {
    if (heff_strEq_c(heff_get_n(v_x_244, 1, 9), ((V)&g_heff_2esyntax_2ecst_2efieldDefault_str1))) {
      switch (heff_tag_of(v_x_245)) {
      case TAG_True: {
        heff_drop_rec(v_hd_240, 3);
        V f_ = v_k_241;
        args[0] = NTAG(TAG_Nothing);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_False: {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam2, 1, 2, (V[]){v_hd_240, v_k_241})));
      }
      default: return heff_nomatch(v_x_245);
      }
    } else {
      heff_drop(v_x_245);
      heff_drop_rec(v_hd_240, 3);
      V f_ = v_k_241;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_245);
    heff_drop_rec(v_x_244, 9);
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2efieldDefault_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2efieldDefault_lam1, 1, 3, (V[]){v_x_244, v_k_241, v_hd_240})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryField_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryField_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryField_str2, 24, "a field is `name : Type`");
V g_heff_2esyntax_2ecst_2etheoryField_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryField_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryField_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryField_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etheoryField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etheoryField_entry, 2, 0};

V g_heff_2esyntax_2ecst_2etheoryField(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2esyntax_2ecst_2etheoryField_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etheoryField(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2etheoryField_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_MkTF, 4, (V[]){v_x_242, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etheoryField_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2efieldDefault(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam3, 1, 4, (V[]){v_k_241, v_x_242, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etheoryField_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_242, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etheoryField_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_244;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2ecst_2etheoryField_str0))) {
    v_x1_244 = NTAG(TAG_True);
  } else {
    v_x1_244 = heff_strEq(heff_dup(heff_rfield(v_x_242, 0)), ((V)&g_heff_2esyntax_2ecst_2etheoryField_str1));
  }
  switch (heff_tag_of(v_x1_244)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryField_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_242})));
  }
  case TAG_False: {
    V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242, 3), heff_get_n(v_x_242, 4, 9)});
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2etheoryField_str2), v_t_248, NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2410}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2411;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_244, 1)); V rr_ = heff_rec_reuse_n(v_s_244, 15ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  }
  case TAG_False: {
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2esyntax_2ecst_2etheoryField(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get_n(v_s_2410, 3, 5);
  V v_x2_2414;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    v_x2_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    v_x2_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_244, 5, 9), heff_take_field(v_s_2425, 3)});
  return ({ V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_n(v_s_2425, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_k_2435 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2434, 3)));
  return ({ V rv_3 = v_k_2435; V rr_ = heff_rec_reuse_n(v_s_2434, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V f_ = v_k_241;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam9, 1, 2, (V[]){v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam7_clo)})});
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2436}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s147623303x632760435(heff_get_n(v_x_244, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_dup(heff_rfield(v_x_244, 6));
  V v_t_2420;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    v_t_2420 = heff_intLe(heff_dup(heff_rfield(v_x_244, 5)), v_x_2418);
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2418);
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str2), v_t_2421, NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2423}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2424;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2427}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2428;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str0))) {
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam1_clo)})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2416}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str1, 20, "the name of a theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2etheoryDecl_str2, 5, "where");
V g_heff_2esyntax_2ecst_2etheoryDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etheoryDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etheoryDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etheoryDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etheoryDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_248 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_248, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2etheoryDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etheoryDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DTheory, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock_24s1203619681x354008797(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam4, 1, 5, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2etheoryDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str0), ((V)&g_heff_2esyntax_2ecst_2etheoryDecl_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etheoryDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprimitiveDecl_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprimitiveDecl_str1, 20, "the primitive's name");
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eprimitiveDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eprimitiveDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eprimitiveDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_247 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_247, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eprimitiveDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DPrimitive, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam3, 1, 4, (V[]){v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectAnn(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eprimitiveDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2eprimitiveDecl_str0), ((V)&g_heff_2esyntax_2ecst_2eprimitiveDecl_str1), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eprimitiveDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efixityRest_str0, 3, "eof");
V g_heff_2esyntax_2ecst_2efixityRest_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2efixityRest_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2efixityRest_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2efixityRest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efixityRest_entry, 3, 0};

V g_heff_2esyntax_2ecst_2efixityRest(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2efixityRest_lam0, 1, 3, (V[]){v_acc_240, v_k_242, v_hd_241})});
}
V g_heff_2esyntax_2ecst_2efixityRest_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2efixityRest(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2efixityRest_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efixityRest(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efixityRest_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2efixityRest(heff_tag_n(TAG_Cons, 2, (V[]){v_x_2412, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2efixityRest_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2efixityRest_str0))) {
    heff_drop_rec(v_x_245, 9);
    heff_drop_rec(v_hd_241, 3);
    V v_x_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_248 = heff_take_field(v_x_245, 6);
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      if (heff_intEq_c(heff_get_n(v_x_245, 5, 9), MK_INT(0LL))) {
        heff_drop_rec(v_hd_241, 3);
        V v_x_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
        V f_ = v_k_242;
        args[0] = v_x_2410;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efixityRest_lam1, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
      }
    }
    case TAG_False: {
      heff_drop_rec(v_x_245, 9);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2efixityRest_lam2, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str1, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str3, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclNameLen_str4, 1, ")");
Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclNameLen_entry, 3, 0};

V g_heff_2esyntax_2ecst_2edeclNameLen(V v_t_240, V v_t2_241, V v_t3_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str0))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop_rec(v_t2_241, 9);
    heff_drop_rec(v_t3_242, 9);
    return MK_INT(1LL);
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str1))) {
      heff_drop_rec(v_t_240, 9);
      heff_drop_rec(v_t2_241, 9);
      heff_drop_rec(v_t3_242, 9);
      return MK_INT(1LL);
    } else {
      if (heff_strEq_c(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str2))) {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t2_241, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str3))) {
          V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t2_241, 1, 9)}));
          V v_x1_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
          switch (heff_tag_of(v_x1_248)) {
          case TAG_True: {
            heff_drop_rec(v_t3_242, 9);
            return MK_INT(0LL);
          }
          case TAG_False: {
            if (heff_strEq_c(heff_get_n(v_t3_242, 1, 9), ((V)&g_heff_2esyntax_2ecst_2edeclNameLen_str4))) {
              return MK_INT(3LL);
            } else {
              return MK_INT(0LL);
            }
          }
          default: return heff_nomatch(v_x1_248);
          }
        } else {
          heff_drop_rec(v_t2_241, 9);
          heff_drop_rec(v_t3_242, 9);
          return MK_INT(0LL);
        }
      } else {
        heff_drop_rec(v_t2_241, 9);
        heff_drop_rec(v_t3_242, 9);
        return MK_INT(0LL);
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclNameLen(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str0, 33, "a declaration cannot start with `");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str3, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str5, 5, "where");
V g_heff_2esyntax_2ecst_2esigOrEqn_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam17(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam17, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam18, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_entry, 4, 0};

V g_heff_2esyntax_2ecst_2esigOrEqn(V v_item_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam1, 1, 4, (V[]){v_hd_242, v_t_241, v_k_243, v_item_240})});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigOrEqn(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_244, v_t_245));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_s_2422, 1)), v_k_2421);
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2422, v_t_2423));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_DSig, 3, (V[]){v_x_2429, v_x_2430, v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam8, 1, 3, (V[]){v_k_243, v_x_2429, v_x_2430})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam7, 1, 3, (V[]){v_hd_242, v_k_243, v_x_2429})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_x_2445})});
  V f_ = v_k_2443;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam15(V self, V *args) {
  V v_x_2444 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2442 = heff_env(self)[1];
  V v_k_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eblock(v_item_240, v_hd_2442, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam16, 1, 2, (V[]){v_x_2444, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam14(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2442), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam15, 1, 3, (V[]){v_item_240, v_hd_2442, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam17(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam18(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam19(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2433, v_x_2434, v_x_2435, v_x_2436, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam13(V self, V *args) {
  V v_x_2439 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  V v_x_2436 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2451;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2439, 0)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str4))) {
    if (heff_strEq_c(heff_get_n(v_x_2439, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str5))) {
      v_c_2451 = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam14, 2, 1, (V[]){v_item_240});
    } else {
      heff_drop(v_item_240);
      v_c_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam17_clo);
    }
  } else {
    heff_drop_rec(v_x_2439, 9);
    heff_drop(v_item_240);
    v_c_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam18_clo);
  }
  V f_ = v_c_2451;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam19, 1, 5, (V[]){v_k_243, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam12(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2437}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam13, 1, 7, (V[]){v_item_240, v_hd_242, v_k_243, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam11(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam12, 1, 6, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2433, v_x_2434, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str3), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam11, 1, 5, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2433, v_x_2434})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 7)), NTAG(TAG_Nil), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam10, 1, 4, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2433})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_item_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_2426, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str2))) {
    heff_drop(v_item_240);
    V v_t_2428 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2428, heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam6, 1, 2, (V[]){v_hd_242, v_k_243})));
  } else {
    V v_t_2432 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2432, heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam9, 1, 3, (V[]){v_hd_242, v_item_240, v_k_243})));
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_item_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    heff_drop(v_item_240);
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str0), heff_strAppend(heff_dup(heff_rfield(v_t_241, 1)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str1)));
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2416, v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_k_2421 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam4, 1, 1, (V[]){v_k_2421})})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2424}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2425;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam5, 1, 6, (V[]){v_t_241, v_x_248, v_x_2413, v_hd_242, v_k_243, v_item_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam3, 1, 5, (V[]){v_t_241, v_x_248, v_hd_242, v_k_243, v_item_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elocalDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elocalDecl_entry, 2, 0};

V g_heff_2esyntax_2ecst_2elocalDecl(V v_st_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_st_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2elocalDecl_lam0, 1, 2, (V[]){v_st_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elocalDecl(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2elocalDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2esigOrEqn(((V)&g_heff_2esyntax_2ecst_2elocalDecl_clo), v_x_244, v_st_240, v_k_241));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_244, 1)); V rr_ = heff_rec_reuse_n(v_s_244, 15ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    return (g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  }
  case TAG_False: {
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2esyntax_2ecst_2elocalDecl(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str1, 16, "a block is empty");
HEFF_LIT(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str2, 43, "a block must be indented past what it is in");
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7, 1, 0};
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_t_2411 = heff_get_n(v_s_2410, 3, 5);
  V v_x2_2414;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nil: {
    v_x2_2414 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 2);
    v_x2_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2412});
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_Nothing: {
    return MK_INT(0LL);
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    heff_take_n(v_x2_2414, 1ULL, 1);
    return v_x_2415;
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_x_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_x_244, 5, 9), heff_take_field(v_s_2425, 3)});
  return ({ V rv_3 = v_t_2426; V rr_ = heff_rec_reuse_n(v_s_2425, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7(V self, V *args) {
  V v_s_2434 = args[0];
  V v_k_2435 = (g_list_2edrop(MK_INT(1LL), heff_take_field(v_s_2434, 3)));
  return ({ V rv_3 = v_k_2435; V rr_ = heff_rec_reuse_n(v_s_2434, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V f_ = v_k_241;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2439 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})}));
  V f_ = heff_get_n(v_hd_240, 1, 3);
  heff_room[0] = v_t_2440;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam9, 1, 2, (V[]){v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam7_clo)})});
  V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2436}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam8, 1, 3, (V[]){v_hd_240, v_k_241, v_x_2433});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2432);
  return (g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(heff_get_n(v_x_244, 5, 9), NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam6, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2429, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})}));
  V f_ = heff_dup(heff_rfield(v_hd_240, 1));
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam5, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_dup(heff_rfield(v_x_244, 6));
  V v_t_2420;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_True: {
    v_t_2420 = heff_intLe(heff_dup(heff_rfield(v_x_244, 5)), v_x_2418);
    break;
  }
  case TAG_False: {
    heff_drop(v_x_2418);
    v_t_2420 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  switch (heff_tag_of(v_t_2420)) {
  case TAG_True: {
    V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str2), v_t_2421, NTAG(TAG_Nothing)});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2423}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2424;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam3, 1, 1, (V[]){heff_dup(v_x_244)})})});
    V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2427}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2428;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam4, 1, 3, (V[]){v_hd_240, v_x_244, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2420);
  }
}
V g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str0))) {
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_str1), v_t_246, NTAG(TAG_Nothing)});
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_248}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_249;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam1_clo)})});
    V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_2416}));
    V f_ = heff_dup(heff_rfield(v_hd_240, 1));
    heff_room[0] = v_t_2417;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175_lam2, 1, 3, (V[]){v_x_244, v_hd_240, v_k_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str0, 33, "a declaration cannot start with `");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str3, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str5, 5, "where");
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry, 4, 0};

V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V v_t_240, V v_hd_241, V v_k_242, V v_z_243) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 3, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1, 1, 3, (V[]){v_hd_241, v_t_240, v_k_242}), v_z_243});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_244, v_t_245));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_s_2422, 1)), v_k_2421);
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2422, v_t_2423));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_DSig, 3, (V[]){v_x_2429, v_x_2430, v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam8, 1, 3, (V[]){v_k_242, v_x_2429, v_x_2430})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam7, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2429})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_x_2445})});
  V f_ = v_k_2443;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2442 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eblock_24s492004241x1878561175(v_hd_2442, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam16, 1, 2, (V[]){v_x_2444, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2442), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam15, 1, 2, (V[]){v_hd_2442, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2433, v_x_2434, v_x_2435, v_x_2436, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_x_2436 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2451;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2439, 0)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str4))) {
    if (heff_strEq_c(heff_get_n(v_x_2439, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str5))) {
      v_c_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam14_clo);
    } else {
      v_c_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam17_clo);
    }
  } else {
    heff_drop_rec(v_x_2439, 9);
    v_c_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam18_clo);
  }
  V f_ = v_c_2451;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam19, 1, 5, (V[]){v_k_242, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2437}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam13, 1, 6, (V[]){v_hd_241, v_k_242, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_2434 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam12, 1, 5, (V[]){v_hd_241, v_k_242, v_x_2433, v_x_2434, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str3), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam11, 1, 4, (V[]){v_hd_241, v_k_242, v_x_2433, v_x_2434})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 7)), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam10, 1, 3, (V[]){v_hd_241, v_k_242, v_x_2433})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_2426, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str2))) {
    V v_t_2428 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_240, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2428, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
  } else {
    V v_t_2432 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_240, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2432, heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam9, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2414 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_248), heff_dup(v_x_2413)));
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str0), heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_str1)));
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2416, v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_k_2421 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_240), heff_dup(v_x_248), heff_dup(v_x_2413)));
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam4, 1, 1, (V[]){v_k_2421})})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2424}));
    V f_ = heff_dup(heff_rfield(v_hd_241, 1));
    heff_room[0] = v_t_2425;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam5, 1, 5, (V[]){v_t_240, v_x_248, v_x_2413, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_lam3, 1, 4, (V[]){v_t_240, v_x_248, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str0, 6, "import");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str2, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str3, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str4, 4, "type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str5, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str6, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str7, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str8, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str10, 6, "infixl");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str11, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str12, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str13, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str14, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str15, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str16, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str17, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str18, 6, "infixr");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str20, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str21, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str22, 5, "infix");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str23, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str24, 4, "test");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str25, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str26, 13, "a test's name");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str27, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclAt_str28, 7, "doctest");
V g_heff_2esyntax_2ecst_2edeclAt_lam0(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2edeclAt_lam7(V self, V *args);
Clo g_heff_2esyntax_2ecst_2edeclAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclAt_entry, 4, 0};

V g_heff_2esyntax_2ecst_2edeclAt(V v_t_240, V v_z_241, V v_z_242, V v_z_243) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str0))) {
    heff_drop_rec(v_t_240, 9);
    V v_t_246 = heff_tr(g_heff_2esyntax_2ecst_2enext(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam0, 1, 1, (V[]){v_z_242})));
    return heff_tail(v_t_246, 1, (V[]){v_z_243});
  } else {
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str1))) {
      v_t_248 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str2));
    } else {
      v_t_248 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop_rec(v_t_240, 9);
      return (g_heff_2esyntax_2ecst_2edataDecl(v_z_241, v_z_242, v_z_243));
    }
    case TAG_False: {
      V v_t_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str3))) {
        v_t_2410 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str4));
      } else {
        v_t_2410 = NTAG(TAG_False);
      }
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop_rec(v_t_240, 9);
        return (g_heff_2esyntax_2ecst_2etypeDecl(v_z_241, v_z_242, v_z_243));
      }
      case TAG_False: {
        V v_t_2412;
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str5))) {
          v_t_2412 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str6));
        } else {
          v_t_2412 = NTAG(TAG_False);
        }
        switch (heff_tag_of(v_t_2412)) {
        case TAG_True: {
          heff_drop_rec(v_t_240, 9);
          return (g_heff_2esyntax_2ecst_2etheoryDecl(v_z_241, v_z_242, v_z_243));
        }
        case TAG_False: {
          V v_t_2414;
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str7))) {
            v_t_2414 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str8));
          } else {
            v_t_2414 = NTAG(TAG_False);
          }
          switch (heff_tag_of(v_t_2414)) {
          case TAG_True: {
            heff_drop_rec(v_t_240, 9);
            return (g_heff_2esyntax_2ecst_2eprimitiveDecl(v_z_241, v_z_242, v_z_243));
          }
          case TAG_False: {
            V v_t_2425;
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str9))) {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str10))) {
                v_t_2425 = NTAG(TAG_True);
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str11))) {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str12))) {
                    v_t_2425 = NTAG(TAG_True);
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str13))) {
                      v_t_2425 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str14));
                    } else {
                      v_t_2425 = NTAG(TAG_False);
                    }
                  }
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str15))) {
                    v_t_2425 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str16));
                  } else {
                    v_t_2425 = NTAG(TAG_False);
                  }
                }
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str17))) {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str18))) {
                  v_t_2425 = NTAG(TAG_True);
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str19))) {
                    v_t_2425 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str20));
                  } else {
                    v_t_2425 = NTAG(TAG_False);
                  }
                }
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str21))) {
                  v_t_2425 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str22));
                } else {
                  v_t_2425 = NTAG(TAG_False);
                }
              }
            }
            switch (heff_tag_of(v_t_2425)) {
            case TAG_True: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2428 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam1, 1, 2, (V[]){v_z_241, v_z_242})));
              return heff_tail(v_t_2428, 1, (V[]){v_z_243});
            }
            case TAG_False: {
              V v_t_2430;
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str23))) {
                v_t_2430 = heff_strEq(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str24));
              } else {
                v_t_2430 = NTAG(TAG_False);
              }
              switch (heff_tag_of(v_t_2430)) {
              case TAG_True: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2433 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam3, 1, 2, (V[]){v_z_241, v_z_242})));
                return heff_tail(v_t_2433, 1, (V[]){v_z_243});
              }
              case TAG_False: {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str27))) {
                  heff_drop_rec(v_t_240, 9);
                  V v_t_2437 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam5, 1, 2, (V[]){v_z_241, v_z_242})));
                  return heff_tail(v_t_2437, 1, (V[]){v_z_243});
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str28))) {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2441 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_z_241), heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam7, 1, 2, (V[]){v_z_241, v_z_242})));
                    return heff_tail(v_t_2441, 1, (V[]){v_z_243});
                  } else {
                    HEFF_LAST return g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(v_t_240, v_z_241, v_z_242, v_z_243);
                  }
                }
              }
              default: return heff_nomatch(v_t_2430);
              }
            }
            default: return heff_nomatch(v_t_2425);
            }
          }
          default: return heff_nomatch(v_t_2414);
          }
        }
        default: return heff_nomatch(v_t_2412);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclAt(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_z_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DImport, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DFixity, 2, (V[]){v_x_2426, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2efixityRest(NTAG(TAG_Nil), v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam2, 1, 2, (V[]){v_z_242, v_x_2426})));
}
V g_heff_2esyntax_2ecst_2edeclAt_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DTest, 2, (V[]){v_x_2431, v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexpectKind(((V)&g_heff_2esyntax_2ecst_2edeclAt_str25), ((V)&g_heff_2esyntax_2ecst_2edeclAt_str26), v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam4, 1, 2, (V[]){v_z_242, v_x_2431})));
}
V g_heff_2esyntax_2ecst_2edeclAt_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2435, v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam6, 1, 2, (V[]){v_z_242, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2edeclAt_lam8(V self, V *args) {
  V v_x_2440 = args[0];
  V v_z_242 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_z_242;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2439, v_x_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2edeclAt_lam7(V self, V *args) {
  V v_x_2439 = args[0];
  V v_z_241 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_z_241, heff_clo_n(g_heff_2esyntax_2ecst_2edeclAt_lam8, 1, 2, (V[]){v_z_242, v_x_2439})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eskipFrom_str0, 3, "eof");
Clo g_heff_2esyntax_2ecst_2eskipFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eskipFrom_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eskipFrom(V v_s_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s_240), heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_241, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eskipFrom_str0))) {
    return v_s_240;
  } else {
    V v_t_243 = heff_intAdd(heff_take_field(v_s_240, 1), MK_INT(1LL));
    V v_t_244 = ({ V rv_1 = v_t_243; V rr_ = heff_rec_reuse_n(v_s_240, 29ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 1) = rv_1; rr_; });
    V t_0 = v_t_244;
    v_s_240 = t_0;
    goto top;
  }
}
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eskipFrom(a[0]);
}
Clo g_heff_2esyntax_2ecst_2eskipDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eskipDecl_entry, 1, 0};

V g_heff_2esyntax_2ecst_2eskipDecl(V v_s_240) {
top: ;
  V v_t_241 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
  V v_i_243;
  if (heff_intLt_c(heff_dup(heff_rfield(v_s_240, 1)), v_t_241)) {
    v_i_243 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
  } else {
    v_i_243 = heff_dup(heff_rfield(v_s_240, 1));
  }
  V v_s_244 = ({ V rv_1 = v_i_243; V rr_ = heff_rec_reuse_n(v_s_240, 29ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_246 = ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_n(v_s_244, 23ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 3) = rv_3; rr_; });
  HEFF_LAST return g_heff_2esyntax_2ecst_2eskipFrom(v_t_246);
}
V g_heff_2esyntax_2ecst_2eskipDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eskipDecl(a[0]);
}
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0, 2, 0};
Clo g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_entry, 1, 0};

V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(V v_st_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Right, 1, (V[]){(g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_st_240), heff_dup(heff_rfield(v_st_240, 1))))});
  V v_x1_242 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_241, v_st_240});
  switch (heff_tag_of(v_x1_242)) {
  case TAG_MkPair: {
    V v_x11_243 = heff_field(v_x1_242, 0);
    V v_st_244 = heff_field(v_x1_242, 1);
    V v_ru_24x1_242_24MkPair = heff_take_reuse_n(v_x1_242, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_245}), v_st_244});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_242_24MkPair, 2);
      return (g_heff_2esyntax_2ecst_2edeclAt(v_x_246, heff_dup(g_heff_2esyntax_2ecst_2ereadH_get()), ((V)&g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0_clo), v_st_244));
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(a[0]);
}
V g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_248 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_247}), v_st_248});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str1, 9, "primitive");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str2, 4, "type");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str3, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str4, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str6, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str8, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str9, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredTwo_str10, 3, "con");
Clo g_heff_2esyntax_2ecst_2edeclaredTwo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclaredTwo_entry, 2, 0};

V g_heff_2esyntax_2ecst_2edeclaredTwo(V v_t_240, V v_u_241) {
top: ;
  V v_t_246;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str0))) {
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str1), NTAG(TAG_Nil)});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str3), v_t_244})});
    v_t_246 = ({ V a_0 = v_t_243; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str4), v_t_245}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  } else {
    v_t_246 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop_rec(v_t_240, 9);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_241, 1, 9)});
  }
  case TAG_False: {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str5))) {
      if (heff_strEq_c(heff_dup(heff_rfield(v_u_241, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str6))) {
        heff_drop_rec(v_t_240, 9);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_u_241, 1, 9)});
      } else {
        heff_drop_rec(v_u_241, 9);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str7))) {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_t_240, 1, 9)});
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str8))) {
            return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_t_240, 1, 9)});
          } else {
            heff_drop_rec(v_t_240, 9);
            return NTAG(TAG_Nothing);
          }
        }
      }
    } else {
      heff_drop_rec(v_u_241, 9);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str9))) {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_t_240, 1, 9)});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredTwo_str10))) {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_t_240, 1, 9)});
        } else {
          heff_drop_rec(v_t_240, 9);
          return NTAG(TAG_Nothing);
        }
      }
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2esyntax_2ecst_2edeclaredTwo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclaredTwo(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredAt_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2edeclaredAt_str1, 3, "con");
Clo g_heff_2esyntax_2ecst_2edeclaredAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclaredAt_entry, 1, 0};

V g_heff_2esyntax_2ecst_2edeclaredAt(V v_s_240) {
top: ;
  V v_t_241 = heff_intAdd(heff_dup(heff_rfield(v_s_240, 2)), MK_INT(1LL));
  V v_t_242 = heff_arrayLength(heff_dup(heff_rfield(v_s_240, 0)));
  if (heff_intLt_c(v_t_241, v_t_242)) {
    V v_t_244 = heff_arrayIndex(heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 2)));
    V v_t_245 = heff_intAdd(heff_take_field(v_s_240, 2), MK_INT(1LL));
    V v_t_246 = heff_arrayIndex(heff_get_n(v_s_240, 0, 5), v_t_245);
    return (g_heff_2esyntax_2ecst_2edeclaredTwo(v_t_244, v_t_246));
  } else {
    V v_t_247 = heff_arrayLength(heff_dup(heff_rfield(v_s_240, 0)));
    if (heff_intLt_c(heff_dup(heff_rfield(v_s_240, 2)), v_t_247)) {
      V v_t_249 = heff_arrayIndex(heff_take_field(v_s_240, 0), heff_get_n(v_s_240, 2, 5));
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredAt_str0))) {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_t_249, 1, 9)});
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_249, 0)), ((V)&g_heff_2esyntax_2ecst_2edeclaredAt_str1))) {
          return heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_t_249, 1, 9)});
        } else {
          heff_drop_rec(v_t_249, 9);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_s_240, 5);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclaredAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclaredAt(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str1, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str2, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str5, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str7, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str8, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_str9, 1, ")");
Clo g_heff_2esyntax_2ecst_2eprogramGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eprogramGo_entry, 2, 0};

V g_heff_2esyntax_2ecst_2eprogramGo(V v_s_240, V v_acc_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_243 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 1)), v_t_242, heff_dup(heff_rfield(v_s_240, 1))});
  V v_t_244 = (g_heff_2esyntax_2ecst_2etokAt(v_t_243, heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_244, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str0))) {
    heff_drop_rec(v_s_240, 5);
    return heff_tag_n(TAG_Right, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241))});
  } else {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_t_247 = ({ V rv_2 = heff_dup(heff_rfield(v_s_240, 1)); V rv_3 = v_t_246; V rv_4 = heff_dup(heff_rfield(v_s_240, 1)); V rr_ = heff_rec_reuse_n(v_s_240, 3ULL, 5, shape_toks__i__top__stack__start); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_it_248 = heff_tr(g_heff_2esyntax_2ecst_2erunP_24s1418497539x1628383859(v_t_247));
    switch (heff_tag_of(v_it_248)) {
    case TAG_MkPair: {
      V v_it1_249 = heff_field(v_it_248, 0);
      V v_s2_2410 = heff_field(v_it_248, 1);
      V v_ru_24it_248_24MkPair = heff_take_reuse_n(v_it_248, 3ULL, 2);
      switch (heff_tag_of(v_it1_249)) {
      case TAG_Left: {
        V v_d_2411 = heff_field(v_it1_249, 0);
        V v_ru_24it1_249_24Left = heff_take_reuse_n(v_it1_249, 1ULL, 1);
        heff_drop(v_acc_241);
        heff_drop_rec(v_s2_2410, 5);
        heff_drop_cell(v_ru_24it_248_24MkPair, 2);
        V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_d_2411, 3)), 0, 2);
        V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str1), heff_strAppend(heff_intShow(v_t_2412), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str2), heff_strAppend(heff_get_n(v_d_2411, 2, 5), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str3)))));
        return heff_tag_at_n(v_ru_24it1_249_24Left, TAG_Left, 1, (V[]){v_t_2413});
      }
      case TAG_Right: {
        V v_d_2414 = heff_field(v_it1_249, 0);
        V v_ru_24it1_249_24Right = heff_take_reuse_n(v_it1_249, 1ULL, 1);
        V v_t_2415 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2410), heff_dup(heff_rfield(v_s2_2410, 1))));
        if (heff_strEq_c(heff_get_n(v_t_2415, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str4))) {
          heff_drop_cell(v_ru_24it1_249_24Right, 1);
          V t_0 = v_s2_2410;
          V t_1 = heff_tag_at_n(v_ru_24it_248_24MkPair, TAG_Cons, 2, (V[]){v_d_2414, v_acc_241});
          v_s_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24it_248_24MkPair, 2);
          heff_drop(v_d_2414);
          V v_t_2417 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2410), heff_dup(heff_rfield(v_s2_2410, 1))));
          V v_t_2418 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_2410), heff_get_n(v_s2_2410, 1, 5)));
          V v_msg_2419 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str5), heff_strAppend(heff_get_n(v_t_2418, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str6)));
          V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2417, 3), heff_get_n(v_t_2417, 4, 9)});
          V v_d_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2419, v_t_2420, NTAG(TAG_Nothing)});
          V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_d_2421, 3)), 0, 2);
          V v_t_2423 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str7), heff_strAppend(heff_intShow(v_t_2422), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_str8), heff_strAppend(heff_get_n(v_d_2421, 2, 5), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_str9)))));
          return heff_tag_at_n(v_ru_24it1_249_24Right, TAG_Left, 1, (V[]){v_t_2423});
        }
      }
      default: return heff_nomatch(v_it1_249);
      }
    }
    default: return heff_nomatch(v_it_248);
    }
  }
}
V g_heff_2esyntax_2ecst_2eprogramGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eprogramGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2ecst_2efirstP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstP_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_PAtom: {
    V v_t_243 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_243);
  }
  case TAG_PParen: {
    V v_o_244 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_244);
  }
  case TAG_PList: {
    V v_o_247 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_247);
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_x1_240, 0);
    V t_0 = v_l_2411;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_o_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2414);
  }
  case TAG_PField: {
    V v_x_2418 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2418);
  }
  case TAG_PAs: {
    V v_x_2421 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2421);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstP_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstP(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastP_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastP(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PCon: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_args_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Nil: {
      return v_t_241;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x1_243, 0);
      heff_take_n(v_x1_243, 1ULL, 2);
      heff_drop(v_t_241);
      V t_0 = v_x_244;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  case TAG_PAtom: {
    V v_t_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_246;
  }
  case TAG_PParen: {
    V v_c_249 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_249;
  }
  case TAG_PList: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_POp: {
    V v_r_2416 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_r_2416;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PRec: {
    V v_c_2420 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2420;
  }
  case TAG_PField: {
    V v_p_2423 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2423;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_PAs: {
    V v_p_2426 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_p_2426;
    v_x1_240 = t_0;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastP_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastP(a[0]);
}
Clo g_heff_2esyntax_2ecst_2efirstE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstE_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_EParen: {
    V v_o_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_242);
  }
  case TAG_Named: {
    V v_o_245 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_245);
  }
  case TAG_Tup: {
    V v_o_2410 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2410);
  }
  case TAG_Braces: {
    V v_o_2414 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2414);
  }
  case TAG_InstB: {
    V v_o_2418 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2418);
  }
  case TAG_EFSet: {
    V v_x_2423 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2423);
  }
  case TAG_EFDefault: {
    V v_e_2426 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2426;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Sum: {
    V v_kw_2429 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2429);
  }
  case TAG_ECon: {
    V v_c_2434 = heff_field(v_x1_240, 0);
    return heff_dup(v_c_2434);
  }
  case TAG_EField: {
    V v_e_2436 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2436;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_App: {
    V v_h_2438 = heff_field(v_x1_240, 0);
    V t_0 = v_h_2438;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Op: {
    V v_a_2440 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2440;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ops: {
    V v_a_2443 = heff_field(v_x1_240, 0);
    V t_0 = v_a_2443;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_OpRhs: {
    V v_op_2445 = heff_field(v_x1_240, 0);
    return heff_dup(v_op_2445);
  }
  case TAG_Ann: {
    V v_e_2447 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2447;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_BVar: {
    V v_t_2450 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_2450);
  }
  case TAG_BImp: {
    V v_o_2451 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2451);
  }
  case TAG_BAnn: {
    V v_o_2454 = heff_field(v_x1_240, 0);
    return heff_dup(v_o_2454);
  }
  case TAG_Lam: {
    V v_bs_2459 = heff_field(v_x1_240, 0);
    return heff_dup(v_bs_2459);
  }
  case TAG_Case: {
    V v_kw_2463 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2463);
  }
  case TAG_EAlt: {
    V v_p_2467 = heff_field(v_x1_240, 0);
    HEFF_LAST return g_heff_2esyntax_2ecst_2efirstP(v_p_2467);
  }
  case TAG_If: {
    V v_kw_2470 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2470);
  }
  case TAG_Do: {
    V v_kw_2476 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2476);
  }
  case TAG_ESBind: {
    V v_x_2478 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_2478);
  }
  case TAG_ELet: {
    V v_kw_2481 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2481);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstE(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2elastE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastE_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_EParen: {
    V v_c_244 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_244;
  }
  case TAG_Named: {
    V v_c_249 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_249;
  }
  case TAG_Tup: {
    V v_c_2413 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2413;
  }
  case TAG_Braces: {
    V v_c_2417 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    return v_c_2417;
  }
  case TAG_InstB: {
    V v_c_2422 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2422;
  }
  case TAG_EFSet: {
    V v_e_2425 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_2425;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EFDefault: {
    V v_d_2428 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_d_2428;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Sum: {
    V v_c_2433 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2433;
  }
  case TAG_ECon: {
    V v_c_2434 = heff_field(v_x1_240, 0);
    V v_args_2435 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2435));
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_Nil: {
      return v_c_2434;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x1_2436, 0);
      heff_take_n(v_x1_2436, 1ULL, 2);
      heff_drop(v_c_2434);
      V t_0 = v_x_2437;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2436);
    }
  }
  case TAG_EField: {
    V v_f_2440 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_f_2440;
  }
  case TAG_App: {
    V v_h_2441 = heff_field(v_x1_240, 0);
    V v_args_2442 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2442));
    switch (heff_tag_of(v_x1_2443)) {
    case TAG_Nil: {
      V t_0 = v_h_2441;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_x_2444 = heff_field(v_x1_2443, 0);
      heff_take_n(v_x1_2443, 1ULL, 2);
      heff_drop(v_h_2441);
      V t_0 = v_x_2444;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2443);
    }
  }
  case TAG_Op: {
    V v_b_2448 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_b_2448;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ops: {
    V v_a_2449 = heff_field(v_x1_240, 0);
    V v_rest_2450 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_rest_2450));
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nil: {
      V t_0 = v_a_2449;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 2);
      heff_drop(v_a_2449);
      V t_0 = v_x_2452;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2451);
    }
  }
  case TAG_OpRhs: {
    V v_e_2455 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    V t_0 = v_e_2455;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Ann: {
    V v_ty_2458 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_ty_2458;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_BVar: {
    V v_t_2459 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_2459;
  }
  case TAG_BImp: {
    V v_c_2462 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    return v_c_2462;
  }
  case TAG_BAnn: {
    V v_c_2467 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    return v_c_2467;
  }
  case TAG_Lam: {
    V v_body_2471 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    V t_0 = v_body_2471;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Case: {
    V v_of2_2474 = heff_field(v_x1_240, 2);
    V v_alts_2475 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 12ULL, 4);
    V v_x1_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_alts_2475));
    switch (heff_tag_of(v_x1_2476)) {
    case TAG_Nil: {
      return v_of2_2474;
    }
    case TAG_Cons: {
      V v_x_2477 = heff_field(v_x1_2476, 0);
      heff_take_n(v_x1_2476, 1ULL, 2);
      heff_drop(v_of2_2474);
      V t_0 = v_x_2477;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2476);
    }
  }
  case TAG_EAlt: {
    V v_body_2481 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_body_2481;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_If: {
    V v_b_2487 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 32ULL, 6);
    V t_0 = v_b_2487;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_Do: {
    V v_kw_2488 = heff_field(v_x1_240, 0);
    V v_stmts_2489 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_stmts_2489));
    switch (heff_tag_of(v_x1_2490)) {
    case TAG_Nil: {
      return v_kw_2488;
    }
    case TAG_Cons: {
      V v_x_2491 = heff_field(v_x1_2490, 0);
      heff_take_n(v_x1_2490, 1ULL, 2);
      heff_drop(v_kw_2488);
      V t_0 = v_x_2491;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x1_2490);
    }
  }
  case TAG_ESBind: {
    V v_e_2495 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    V t_0 = v_e_2495;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ELet: {
    V v_e_24100 = heff_field(v_x1_240, 4);
    V v_body_24101 = heff_field(v_x1_240, 5);
    heff_take_n(v_x1_240, 48ULL, 6);
    switch (heff_tag_of(v_body_24101)) {
    case TAG_Nothing: {
      V t_0 = v_e_24100;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_it1_24102 = heff_field(v_body_24101, 0);
      heff_take_n(v_body_24101, 1ULL, 1);
      heff_drop(v_e_24100);
      switch (heff_tag_of(v_it1_24102)) {
      case TAG_MkPair: {
        V v_b_24104 = heff_field(v_it1_24102, 1);
        heff_take_n(v_it1_24102, 2ULL, 2);
        V t_0 = v_b_24104;
        v_x1_240 = t_0;
        goto top;
      }
      default: return heff_nomatch(v_it1_24102);
      }
    }
    default: return heff_nomatch(v_body_24101);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastE(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2ecst_2efirstD_str5, 0, "");
Clo g_heff_2esyntax_2ecst_2efirstD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2efirstD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2efirstD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    return heff_dup(v_t_241);
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_242);
  }
  case TAG_DSig: {
    V v_n_244 = heff_field(v_x1_240, 0);
    V v_x2_249;
    switch (heff_tag_of(v_n_244)) {
    case TAG_Nil: {
      v_x2_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_n_244, 0);
      v_x2_249 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_247)});
      break;
    }
    default: heff_nomatch(v_n_244);
    }
    switch (heff_tag_of(v_x2_249)) {
    case TAG_Nothing: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str0), ((V)&g_heff_2esyntax_2ecst_2efirstD_str1), ((V)&g_heff_2esyntax_2ecst_2efirstD_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      heff_take_n(v_x2_249, 1ULL, 1);
      return v_x_2410;
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  case TAG_DEqn: {
    V v_n_2411 = heff_field(v_x1_240, 0);
    V v_x2_2418;
    switch (heff_tag_of(v_n_2411)) {
    case TAG_Nil: {
      v_x2_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_n_2411, 0);
      v_x2_2418 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)});
      break;
    }
    default: heff_nomatch(v_n_2411);
    }
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nothing: {
      return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2ecst_2efirstD_str3), ((V)&g_heff_2esyntax_2ecst_2efirstD_str4), ((V)&g_heff_2esyntax_2ecst_2efirstD_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      heff_take_n(v_x2_2418, 1ULL, 1);
      return v_x_2419;
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_DData: {
    V v_kw_2420 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2420);
  }
  case TAG_DType: {
    V v_kw_2425 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2425);
  }
  case TAG_DTheory: {
    V v_kw_2430 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2430);
  }
  case TAG_DPrimitive: {
    V v_kw_2435 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2435);
  }
  case TAG_DTest: {
    V v_kw_2439 = heff_field(v_x1_240, 0);
    return heff_dup(v_kw_2439);
  }
  case TAG_DWatch: {
    V v_w_2441 = heff_field(v_x1_240, 0);
    return heff_dup(v_w_2441);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2efirstD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2efirstD(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2ecst_2edataLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edataLast_entry, 4, 0};

V g_heff_2esyntax_2ecst_2edataLast(V v_name_240, V v_params_241, V v_universe_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_universe_242)) {
    case TAG_Nothing: {
      V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_241));
      V v_x2_247;
      switch (heff_tag_of(v_x1_244)) {
      case TAG_Nil: {
        v_x2_247 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_245 = heff_field(v_x1_244, 0);
        heff_take_n(v_x1_244, 1ULL, 2);
        v_x2_247 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
        break;
      }
      default: heff_nomatch(v_x1_244);
      }
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nothing: {
        return v_name_240;
      }
      case TAG_Just: {
        V v_e_248 = heff_field(v_x2_247, 0);
        heff_take_n(v_x2_247, 1ULL, 1);
        heff_drop(v_name_240);
        return (g_heff_2esyntax_2ecst_2elastE(v_e_248));
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    case TAG_Just: {
      V v_x31_249 = heff_field(v_universe_242, 0);
      heff_drop(v_name_240);
      heff_drop(v_params_241);
      switch (heff_tag_of(v_x31_249)) {
      case TAG_MkPair: {
        V v_u_2411 = heff_field(v_x31_249, 1);
        return (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_u_2411)));
      }
      default: return heff_nomatch(v_x31_249);
      }
    }
    default: return heff_nomatch(v_universe_242);
    }
  }
  case TAG_Just: {
    V v_x41_2412 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_2412)) {
    case TAG_MkDAlts: {
      V v_alts_2414 = heff_field(v_x41_2412, 1);
      heff_take_n(v_x41_2412, 2ULL, 3);
      V v_t_2424;
      switch (heff_tag_of(v_universe_242)) {
      case TAG_Nothing: {
        V v_x1_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_params_241));
        V v_x2_2419;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x4_243_24Just, 1);
          v_x2_2419 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 2);
          v_x2_2419 = heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_x_2417});
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        switch (heff_tag_of(v_x2_2419)) {
        case TAG_Nothing: {
          v_t_2424 = v_name_240;
          break;
        }
        case TAG_Just: {
          V v_e_2420 = heff_field(v_x2_2419, 0);
          heff_take_n(v_x2_2419, 1ULL, 1);
          heff_drop(v_name_240);
          v_t_2424 = (g_heff_2esyntax_2ecst_2elastE(v_e_2420));
          break;
        }
        default: heff_nomatch(v_x2_2419);
        }
        break;
      }
      case TAG_Just: {
        V v_x31_2421 = heff_field(v_universe_242, 0);
        heff_drop(v_name_240);
        heff_drop(v_params_241);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        switch (heff_tag_of(v_x31_2421)) {
        case TAG_MkPair: {
          V v_u_2423 = heff_field(v_x31_2421, 1);
          v_t_2424 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_u_2423)));
          break;
        }
        default: heff_nomatch(v_x31_2421);
        }
        break;
      }
      default: heff_nomatch(v_universe_242);
      }
      V v_x1_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_alts_2414));
      V v_x2_2428;
      switch (heff_tag_of(v_x1_2425)) {
      case TAG_Nil: {
        v_x2_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_x1_2425, 0);
        heff_take_n(v_x1_2425, 1ULL, 2);
        v_x2_2428 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2426});
        break;
      }
      default: heff_nomatch(v_x1_2425);
      }
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nothing: {
        return v_t_2424;
      }
      case TAG_Just: {
        V v_e_2429 = heff_field(v_x2_2428, 0);
        heff_take_n(v_x2_2428, 1ULL, 1);
        heff_drop(v_t_2424);
        return (g_heff_2esyntax_2ecst_2elastE(v_e_2429));
      }
      default: return heff_nomatch(v_x2_2428);
      }
    }
    default: return heff_nomatch(v_x41_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2esyntax_2ecst_2edataLast_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2ecst_2edataLast(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2ecst_2elastD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elastD_entry, 1, 0};

V g_heff_2esyntax_2ecst_2elastD(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_DImport: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_t_241;
  }
  case TAG_DFixity: {
    V v_kw_242 = heff_field(v_x1_240, 0);
    V v_ts_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ts_243));
    V v_x2_247;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nil: {
      v_x2_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x1_244, 0);
      heff_take_n(v_x1_244, 1ULL, 2);
      v_x2_247 = heff_tag_n(TAG_Just, 1, (V[]){v_x_245});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      return v_kw_242;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      heff_drop(v_kw_242);
      return v_x_248;
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_DSig: {
    V v_ty_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 4ULL, 3);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2411);
  }
  case TAG_DEqn: {
    V v_rhs_2415 = heff_field(v_x1_240, 3);
    V v_x15_2416 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    switch (heff_tag_of(v_x15_2416)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_rhs_2415);
    }
    case TAG_Just: {
      V v_x151_2417 = heff_field(v_x15_2416, 0);
      heff_take_n(v_x15_2416, 1ULL, 1);
      heff_drop(v_rhs_2415);
      switch (heff_tag_of(v_x151_2417)) {
      case TAG_MkPair: {
        V v_kw_2418 = heff_field(v_x151_2417, 0);
        V v_ds_2419 = heff_field(v_x151_2417, 1);
        heff_take_n(v_x151_2417, 3ULL, 2);
        V v_x1_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_2419));
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_Nil: {
          return v_kw_2418;
        }
        case TAG_Cons: {
          V v_x_2421 = heff_field(v_x1_2420, 0);
          heff_take_n(v_x1_2420, 1ULL, 2);
          heff_drop(v_kw_2418);
          V t_0 = v_x_2421;
          v_x1_240 = t_0;
          goto top;
        }
        default: return heff_nomatch(v_x1_2420);
        }
      }
      default: return heff_nomatch(v_x151_2417);
      }
    }
    default: return heff_nomatch(v_x15_2416);
    }
  }
  case TAG_DData: {
    V v_name_2424 = heff_field(v_x1_240, 1);
    V v_params_2425 = heff_field(v_x1_240, 2);
    V v_universe_2426 = heff_field(v_x1_240, 3);
    V v_alts_2427 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 30ULL, 5);
    return ({ V a_0 = v_name_2424; V a_1 = v_params_2425; V a_2 = v_universe_2426; V a_3 = v_alts_2427; V r_ = (g_heff_2esyntax_2ecst_2edataLast(a_0, a_1, a_2, a_3)); heff_drop(v_universe_2426); r_; });
  }
  case TAG_DType: {
    V v_body_2432 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 16ULL, 5);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_body_2432);
  }
  case TAG_DTheory: {
    V v_w_2436 = heff_field(v_x1_240, 3);
    V v_fields_2437 = heff_field(v_x1_240, 4);
    heff_take_n(v_x1_240, 24ULL, 5);
    V v_x1_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fields_2437));
    V v_x2_2441;
    switch (heff_tag_of(v_x1_2438)) {
    case TAG_Nil: {
      v_x2_2441 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2439 = heff_field(v_x1_2438, 0);
      heff_take_n(v_x1_2438, 1ULL, 2);
      v_x2_2441 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2439});
      break;
    }
    default: heff_nomatch(v_x1_2438);
    }
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_Nothing: {
      return v_w_2436;
    }
    case TAG_Just: {
      V v_f_2442 = heff_field(v_x2_2441, 0);
      heff_take_n(v_x2_2441, 1ULL, 1);
      heff_drop(v_w_2436);
      switch (heff_tag_of(v_f_2442)) {
      case TAG_MkTF: {
        V v_ty_2445 = heff_field(v_f_2442, 2);
        V v_x14_2446 = heff_field(v_f_2442, 3);
        heff_take_n(v_f_2442, 12ULL, 4);
        switch (heff_tag_of(v_x14_2446)) {
        case TAG_Nothing: {
          HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2445);
        }
        case TAG_Just: {
          V v_x141_2447 = heff_field(v_x14_2446, 0);
          heff_take_n(v_x14_2446, 1ULL, 1);
          heff_drop(v_ty_2445);
          switch (heff_tag_of(v_x141_2447)) {
          case TAG_MkPair: {
            V v_d_2449 = heff_field(v_x141_2447, 1);
            heff_take_n(v_x141_2447, 2ULL, 2);
            HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_d_2449);
          }
          default: return heff_nomatch(v_x141_2447);
          }
        }
        default: return heff_nomatch(v_x14_2446);
        }
      }
      default: return heff_nomatch(v_f_2442);
      }
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_DPrimitive: {
    V v_ty_2453 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 8ULL, 4);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_ty_2453);
  }
  case TAG_DTest: {
    V v_x_2455 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_x_2455;
  }
  case TAG_DWatch: {
    V v_e_2457 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2ecst_2elastE(v_e_2457);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elastD(a[0]);
}