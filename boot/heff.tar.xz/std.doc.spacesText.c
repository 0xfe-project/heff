// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_std_2edoc_2espacesText_2espacesInto_240(V, V);
V g_std_2edoc_2espacesText_2espacesInto_240_entry(V self, V *a);
extern Clo g_std_2edoc_2espacesText_2espacesInto_240_clo;
HEFF_LIT(g_std_2edoc_2espacesText_2espacesInto_240_str0, 1, " ");
Clo g_std_2edoc_2espacesText_2espacesInto_240_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2espacesText_2espacesInto_240_entry, 2, 0};

V g_std_2edoc_2espacesText_2espacesInto_240(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return v_acc_241;
  } else {
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = heff_strAppend(v_acc_241, ((V)&g_std_2edoc_2espacesText_2espacesInto_240_str0));
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_std_2edoc_2espacesText_2espacesInto_240_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2espacesText_2espacesInto_240(a[0], a[1]);
}