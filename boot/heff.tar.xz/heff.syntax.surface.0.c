// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclPrimitive 46335
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Left 13886
#define TAG_MkDAlts 45152
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_TypeWord 10401
#define TAG_Whole 6035
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_f 320
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_patVars 1587353522
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eappendRev(V, V);
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendRev_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldOrName(V, V);
V g_heff_2esyntax_2esurface_2efieldOrName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldOrName_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eipow10(V);
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eipow10_clo;
V g_heff_2esyntax_2esurface_2eisAnnE(V);
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisAnnE_clo;
V g_heff_2esyntax_2esurface_2eisSetting(V);
V g_heff_2esyntax_2esurface_2eisSetting_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisSetting_clo;
V g_heff_2esyntax_2esurface_2emutualPublic(V, V);
V g_heff_2esyntax_2esurface_2emutualPublic_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2emutualPublic_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
HeffT2 g_heff_2esyntax_2esurface_2epchainOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esharedFields(V);
V g_heff_2esyntax_2esurface_2esharedFields_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esharedFields_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2eipow10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eipow10_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eipow10(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2esyntax_2esurface_2eipow10(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(10LL), v_t_241);
  }
}
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eipow10(a[0]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2efoldr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efoldr(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(g_heff_2esyntax_2esurface_2efoldr(heff_dup(v_f_240), v_z_241, v_xs_244));
    return heff_tail(v_f_240, 2, (V[]){heff_dup(v_x_243), v_t_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2efoldr(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2esurface_2eisAnnE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisAnnE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisAnnE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_True);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_EAssign: {
      return NTAG(TAG_False);
    }
    case TAG_EWhile: {
      return NTAG(TAG_False);
    }
    case TAG_EFor: {
      return NTAG(TAG_False);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_False);
    }
    case TAG_EBreak: {
      return NTAG(TAG_False);
    }
    case TAG_EContinue: {
      return NTAG(TAG_False);
    }
    case TAG_EReturn: {
      return NTAG(TAG_False);
    }
    case TAG_ENest: {
      return NTAG(TAG_False);
    }
    case TAG_ELazy: {
      return NTAG(TAG_False);
    }
    case TAG_ETuple: {
      return NTAG(TAG_False);
    }
    case TAG_ETry: {
      return NTAG(TAG_False);
    }
    case TAG_EWith: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisAnnE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2econAtom_str0, 1, ".");
V g_heff_2esyntax_2esurface_2econAtom_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2econAtom_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2econAtom_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2econAtom_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econAtom(V v_t_240, V v_fs_241, V v_p_242) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam0, 1, 1, (V[]){heff_dup(v_t_240)}), heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam1, 2, 2, (V[]){v_fs_241, v_t_240}), v_p_242);
}
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2econAtom_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t_240, 1, 9)}));
  V v_t_245 = (g_list_2eany(v_t_244, heff_rfield(v_st_243, 1)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_245}), v_st_243});
}
V g_heff_2esyntax_2esurface_2econAtom_lam2(V self, V *args) {
  V v_st_248 = args[0];
  V v_fs_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_fs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_240, 9);
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_f_249 = heff_field(v_fs_241, 0);
    heff_take_n(v_fs_241, 1ULL, 2);
    V v_t_2411 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2econAtom_str0), heff_get_n(v_f_249, 1, 9));
    V v_t_2412 = heff_strAppend(heff_get_n(v_t_240, 1, 9), v_t_2411);
    v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_248, 2)), 1, (V[]){v_t_2412}));
    break;
  }
  default: heff_nomatch(v_fs_241);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_248});
}
V g_heff_2esyntax_2esurface_2econAtom_lam3(V self, V *args) {
  V v_qualified_2414 = args[0];
  V v_st_2415 = args[1];
  V v_local_246 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_fs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416;
  if ((heff_dup(v_local_246) == NTAG(TAG_True))) {
    v_t_2416 = NTAG(TAG_True);
  } else {
    v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_2415, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  }
  V v_x_2426;
  if ((heff_dup(v_local_246) == NTAG(TAG_True))) {
    heff_drop(v_qualified_2414);
    heff_drop(v_local_246);
    heff_drop(v_t_2416);
    V v_t_2417 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    V v_t_2419 = (g_list_2emap_24s513201124x806973253(v_fs_241));
    v_x_2426 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2418}), v_t_2419));
  } else {
    heff_drop(v_local_246);
    if ((heff_dup(v_qualified_2414) == NTAG(TAG_True))) {
      heff_drop(v_qualified_2414);
      heff_drop(v_t_2416);
      v_x_2426 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_240, v_fs_241));
    } else {
      heff_drop(v_qualified_2414);
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2420 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
        V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2422 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2426 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2421}), v_t_2422));
      } else {
        heff_drop(v_t_2416);
        V v_t_2423 = heff_tag_n(TAG_ETag, 1, (V[]){heff_take_field(v_t_240, 1)});
        V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2425 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2426 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424}), v_t_2425));
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2415});
}
V g_heff_2esyntax_2esurface_2econAtom_lam1(V self, V *args) {
  V v_local_246 = args[0];
  V v_z_247 = args[1];
  V v_fs_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam2, 1, 2, (V[]){heff_dup(v_fs_241), heff_dup(v_t_240)}), heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam3, 2, 3, (V[]){v_local_246, v_t_240, v_fs_241}), v_z_247));
}
V g_heff_2esyntax_2esurface_2ebracesL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracesL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ebracesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracesL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ebracesL(V v_r_240, V v_o_241, V v_fs_242, V v_c_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_fs_242)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    V v_t_245 = heff_tag_n(TAG_EStruct, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
    V v_t_247 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_t_246})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_z_244});
  }
  case TAG_Cons: {
    V v_f_248 = heff_dup(heff_field(v_fs_242, 0));
    V v_t_2410 = ({ V a_0 = v_f_248; V r_ = (g_heff_2esyntax_2esurface_2eisSetting(a_0)); heff_drop(v_f_248); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_m_2412 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam0, 1, 1, (V[]){v_r_240}), v_fs_242));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop_rec(v_o_241, 9);
          heff_drop_rec(v_c_243, 9);
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
          V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_EStruct, 1, (V[]){v_x_2417}), v_t_2418});
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2419}), v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    } else {
      heff_drop(v_t_2410);
      V v_m_2421 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam1, 1, 1, (V[]){v_r_240}), v_fs_242));
      V v_x1_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_MkPair: {
        V v_x11_2423 = heff_field(v_x1_2422, 0);
        V v_st_2424 = heff_field(v_x1_2422, 1);
        V v_ru_24x1_2422_24MkPair = heff_take_reuse_n(v_x1_2422, 3ULL, 2);
        switch (heff_tag_of(v_x11_2423)) {
        case TAG_Left: {
          V v_e_2425 = heff_field(v_x11_2423, 0);
          heff_take_n(v_x11_2423, 1ULL, 1);
          heff_drop_rec(v_o_241, 9);
          heff_drop_rec(v_c_243, 9);
          return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2425}), v_st_2424});
        }
        case TAG_Right: {
          V v_x_2426 = heff_field(v_x11_2423, 0);
          V v_ru_24x11_2423_24Right = heff_take_reuse_n(v_x11_2423, 1ULL, 1);
          HeffT2 v_t_2427 = (g_heff_2esyntax_2esurface_2erepeatedField_24cpr(NTAG(TAG_Nil), heff_dup(v_x_2426)));
          {
            V v_field_2429 = v_t_2427.f[1];
            int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
            if ((v_tag_2428 == ((int64_t)0ULL))) {
              heff_drop_rec(v_o_241, 9);
              heff_drop_rec(v_c_243, 9);
              heff_drop(v_x_2426);
              heff_drop_cell(v_ru_24x11_2423_24Right, 1);
              V v_d_2430 = v_field_2429;
              return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2430}), v_st_2424});
            } else {
              heff_drop(v_field_2429);
              V v_m_2431 = (g_heff_2esyntax_2esurface_2esharedFields(v_x_2426));
              V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_st_2424}));
              switch (heff_tag_of(v_x1_2432)) {
              case TAG_MkPair: {
                V v_x11_2433 = heff_field(v_x1_2432, 0);
                V v_st_2434 = heff_field(v_x1_2432, 1);
                V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
                switch (heff_tag_of(v_x11_2433)) {
                case TAG_Left: {
                  V v_e_2435 = heff_field(v_x11_2433, 0);
                  heff_take_n(v_x11_2433, 1ULL, 1);
                  heff_drop_rec(v_o_241, 9);
                  heff_drop_rec(v_c_243, 9);
                  heff_drop_cell(v_ru_24x11_2423_24Right, 1);
                  heff_drop_cell(v_ru_24x1_2432_24MkPair, 2);
                  return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
                }
                case TAG_Right: {
                  V v_x_2436 = heff_field(v_x11_2433, 0);
                  heff_take_n(v_x11_2433, 1ULL, 1);
                  V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
                  V v_t_2438 = heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2423_24Right, TAG_ESig, 1, (V[]){v_x_2436}), v_t_2437});
                  return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
                }
                default: return heff_nomatch(v_x11_2433);
                }
              }
              default: return heff_nomatch(v_x1_2432);
              }
            }
          }
        }
        default: return heff_nomatch(v_x11_2423);
        }
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
  }
  default: return heff_nomatch(v_fs_242);
  }
}
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebracesL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ebracesL_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_2411));
}
V g_heff_2esyntax_2esurface_2ebracesL_lam1(V self, V *args) {
  V v_m_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2efieldOrName(v_r_240, v_m_2420));
}

HeffT2 g_heff_2esyntax_2esurface_2epchainOf_24cpr(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PCon: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PAtom: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PParen: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PList: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_p_240, 0);
    V v_op_2412 = heff_field(v_p_240, 1);
    V v_r_2413 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    HeffT2 v_t_2414 = (g_heff_2esyntax_2esurface_2epchainOf_24cpr(v_r_2413));
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      V v_rh_2417 = v_field_2415;
      V v_rest_2418 = v_field_2416;
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_op_2412, v_rh_2417}), v_rest_2418});
      return ((HeffT2){{v_l_2411, v_t_2419}});
    }
  }
  case TAG_PRec: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PField: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PAs: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PSeg: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_p_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2eaddBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eaddBinders_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eaddBinders(V v_b_240, V v_s_241) {
top: ;
  V v_binders_242 = heff_take_field(v_s_241, 3);
  V v_toks_243 = heff_take_field(v_s_241, 0);
  V v_scope_244 = heff_take_field(v_s_241, 1);
  V v_known_245 = heff_take_field(v_s_241, 2);
  V v_patVars_246 = heff_take_field(v_s_241, 4);
  V v_fix_247 = heff_take_field(v_s_241, 5);
  V v_lenient_248 = heff_take_field(v_s_241, 6);
  V v_at_249 = heff_take_field(v_s_241, 7);
  V v_knot_2410 = heff_get_n(v_s_241, 8, 9);
  HeffT2 v_t_2411 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_binders_242, heff_rfield(v_b_240, 0)));
  V v_t_2415;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2415 = v_x_2414;
    } else {
      heff_drop(v_field_2413);
      v_t_2415 = NTAG(TAG_Nil);
    }
  }
  V v_b_2416 = (g_std_2emap_2einsert_24s93785294x875597928(v_binders_242, heff_dup(heff_rfield(v_b_240, 0)), heff_tag_n(TAG_Cons, 2, (V[]){v_b_240, v_t_2415})));
  return heff_rec_n(9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, (V[]){v_toks_243, v_scope_244, v_known_245, v_b_2416, v_patVars_246, v_fix_247, v_lenient_248, v_at_249, v_knot_2410});
}
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eaddBinders(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ewhereL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ewhereL(V v_r_240, V v_kw_241, V v_ds_242, V v_rhs_243, V v_st_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_st_244, 3));
  HeffT2 v_t_246 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_get_n(v_r_240, 2, 3), heff_dup(v_ds_242), v_st_244));
  {
    V v_field_247 = v_t_246.f[0];
    V v_field_248 = v_t_246.f[1];
    V v_x11_249 = v_field_247;
    V v_st_2410 = v_field_248;
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_ds_242);
      heff_drop(v_rhs_243);
      heff_drop(v_t_245);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_st_2413 = ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_st_2410, 503ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 261951u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_items_2414 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2412));
      V v_items_2415 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2414, NTAG(TAG_Nil)));
      V v_t_2416 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2420 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_lam0, 2, 1, (V[]){heff_dup(v_st_2413)}); V a_1 = v_t_2416; V a_2 = v_items_2415; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2415); r_; });
      V v_t_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2420, 3, 4)));
      V v_items_2422 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2412));
      V v_items_2423 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2422, NTAG(TAG_Nil)));
      V v_t_2424 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2425 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2423));
      V v_t_2426 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2423));
      V v_t_2427 = ({ V a_0 = v_t_2424; V a_1 = v_t_2425; V a_2 = v_t_2426; V a_3 = v_items_2423; V r_ = (g_list_2emap_24s2130193383x1335133353(a_0, a_1, a_2, a_3)); heff_drop(v_t_2424); heff_drop(v_t_2425); heff_drop(v_t_2426); r_; });
      V v_t_2428 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2427));
      V v_t_2429 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2421, v_t_2428));
      switch (heff_tag_of(v_t_2429)) {
      case TAG_Nil: {
        V v_items_2430 = ({ V a_0 = v_x_2412; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2412); r_; });
        V v_items_2431 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2430, NTAG(TAG_Nil)));
        V v_t_2432 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
        V v_t_2433 = ({ V a_0 = v_t_2432; V a_1 = v_items_2431; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
        V v_x1_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
        V v_b_2438;
        switch (heff_tag_of(v_x1_2434)) {
        case TAG_Nil: {
          v_b_2438 = heff_get_n(v_kw_241, 4, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2435 = heff_field(v_x1_2434, 0);
          heff_take_n(v_x1_2434, 1ULL, 2);
          heff_drop_rec(v_kw_241, 9);
          V v_t_2437 = (g_heff_2esyntax_2ecst_2elastD(v_x_2435));
          v_b_2438 = heff_get_n(v_t_2437, 4, 9);
          break;
        }
        default: heff_nomatch(v_x1_2434);
        }
        V v_t_2441;
        switch (heff_tag_of(v_rhs_243)) {
        case TAG_At: {
          V v_s_2440 = heff_dup(heff_field(v_rhs_243, 1));
          v_t_2441 = v_s_2440;
          break;
        }
        default: heff_nomatch(v_rhs_243);
        }
        V v_t_2442 = ({ V rv_1 = v_b_2438; V rr_ = heff_rec_reuse_nf(v_t_2441, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_243, v_t_2433}), v_t_2442});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){v_x_2443}), v_st_2413});
      }
      case TAG_Cons: {
        V v_d_2444 = heff_field(v_t_2429, 0);
        V v_ru_24t_2429_24Cons = heff_take_reuse_n(v_t_2429, 1ULL, 2);
        heff_drop_rec(v_kw_241, 9);
        heff_drop(v_ds_242);
        heff_drop(v_rhs_243);
        heff_drop(v_x_2412);
        heff_drop_cell(v_ru_24x11_249_24Right, 1);
        return heff_tag_at_n(v_ru_24t_2429_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2444}), v_st_2413});
      }
      default: return heff_nomatch(v_t_2429);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ewhereL_lam0(V self, V *args) {
  V v_d_2417 = args[0];
  V v_it_2418 = args[1];
  V v_st_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2417, 2)), v_it_2418));
  return ({ V a_0 = heff_get_n(v_st_2413, 7, 9); V a_1 = v_d_2417; V a_2 = v_t_2419; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_universe_245, V v_alts_246, V v_z_247) {
top: ;
  V v_start_248 = heff_take_field(v_name_243, 3);
  V v_end_249 = heff_take_field(v_name_243, 4);
  V v_text_2410 = heff_get_n(v_name_243, 1, 9);
  V v_m_2412 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_244));
  V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_247}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    heff_take_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_text_2410);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2414_24Left, TAG_Left, 1, (V[]){v_e_2416}), v_st_2415}});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2417)));
      V v_m_2425;
      switch (heff_tag_of(v_universe_245)) {
      case TAG_Nothing: {
        v_m_2425 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam1, 1, 2, (V[]){heff_dup(v_start_248), heff_dup(v_end_249)});
        break;
      }
      case TAG_Just: {
        V v_it1_2422 = heff_field(v_universe_245, 0);
        switch (heff_tag_of(v_it1_2422)) {
        case TAG_MkPair: {
          V v_u_2424 = heff_field(v_it1_2422, 1);
          v_m_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_u_2424)}));
          break;
        }
        default: heff_nomatch(v_it1_2422);
        }
        break;
      }
      default: heff_nomatch(v_universe_245);
      }
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2418, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam2, 1, 9, (V[]){v_m_2425, heff_dup(v_alts_246), v_r_240, v_d_241, v_kw_242, v_text_2410, v_start_248, v_end_249, v_x_2417}), v_st_2415));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2414)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
  }
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_2411));
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam1(V self, V *args) {
  V v_st_2419 = args[0];
  V v_start_248 = heff_env(self)[0];
  V v_end_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){v_t_2420, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2421}), v_st_2419});
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam3(V self, V *args) {
  V v_a_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_2437));
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam2(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  V v_alts_246 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_kw_242 = heff_env(self)[4];
  V v_text_2410 = heff_env(self)[5];
  V v_start_248 = heff_env(self)[6];
  V v_end_249 = heff_env(self)[7];
  V v_x_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x1_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    V v_st_2429 = heff_field(v_x1_2427, 1);
    V v_ru_24x1_2427_24MkPair = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_Left: {
      V v_e_2430 = heff_field(v_x11_2428, 0);
      heff_take_n(v_x11_2428, 1ULL, 1);
      heff_drop(v_alts_246);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_text_2410);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_x_2417);
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      V v_t_2436;
      switch (heff_tag_of(v_alts_246)) {
      case TAG_Nothing: {
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x11_2432 = heff_field(v_alts_246, 0);
        heff_take_n(v_alts_246, 1ULL, 1);
        switch (heff_tag_of(v_x11_2432)) {
        case TAG_MkDAlts: {
          V v_alts_2434 = heff_field(v_x11_2432, 1);
          heff_take_n(v_x11_2432, 2ULL, 3);
          v_t_2436 = v_alts_2434;
          break;
        }
        default: heff_nomatch(v_x11_2432);
        }
        break;
      }
      default: heff_nomatch(v_alts_246);
      }
      V v_m_2438 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam3, 1, 1, (V[]){v_r_240}), v_t_2436));
      V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_st_2429}));
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_MkPair: {
        V v_x11_2440 = heff_field(v_x1_2439, 0);
        V v_st_2441 = heff_field(v_x1_2439, 1);
        V v_ru_24x1_2439_24MkPair = heff_take_reuse_n(v_x1_2439, 3ULL, 2);
        switch (heff_tag_of(v_x11_2440)) {
        case TAG_Left: {
          V v_e_2442 = heff_field(v_x11_2440, 0);
          heff_take_n(v_x11_2440, 1ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_kw_242, 9);
          heff_drop(v_text_2410);
          heff_drop(v_start_248);
          heff_drop(v_end_249);
          heff_drop(v_x_2417);
          heff_drop(v_x_2431);
          heff_drop_cell(v_ru_24x11_2428_24Right, 1);
          heff_drop_cell(v_ru_24x1_2439_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
        }
        case TAG_Right: {
          V v_x_2443 = heff_field(v_x11_2440, 0);
          V v_ru_24x11_2440_24Right = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
          V v_t_2444 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_241)));
          V v_e_2445 = heff_get_n(v_t_2444, 4, 9);
          V v_t_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_242, 3)), v_e_2445});
          V v_t_2447 = heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_ESum, 1, (V[]){v_x_2443}), v_t_2446});
          V v_t_2448 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_2410, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249}), v_x_2417, v_x_2431, v_t_2447});
          V v_t_2449 = (g_heff_2esyntax_2ecst_2elastD(v_d_241));
          V v_e_2450 = heff_get_n(v_t_2449, 4, 9);
          V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2450});
          V v_t_2452 = heff_tag_at_n(v_ru_24x11_2440_24Right, TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_t_2451})});
          V v_x_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2453}), v_st_2441});
        }
        default: return heff_nomatch(v_x11_2440);
        }
      }
      default: return heff_nomatch(v_x1_2439);
      }
    }
    default: return heff_nomatch(v_x11_2428);
    }
  }
  default: return heff_nomatch(v_x1_2427);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2eprimitiveL_24cpr(V v_r_240, V v_kw_241, V v_x_242, V v_ty_243, V v_z_244) {
top: ;
  V v_text_245 = heff_take_field(v_x_242, 1);
  V v_start_246 = heff_take_field(v_x_242, 3);
  V v_end_247 = heff_get_n(v_x_242, 4, 9);
  V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_ty_243)}));
  V v_x1_249 = heff_tr(heff_call(v_m_248, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_ty_243);
      heff_drop(v_text_245);
      heff_drop(v_start_246);
      heff_drop(v_end_247);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411}});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_n(TAG_DeclPrimitive, 3, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), v_x_2413});
      V v_t_2415 = (g_heff_2esyntax_2ecst_2elastE(v_ty_243));
      V v_e_2416 = heff_get_n(v_t_2415, 4, 9);
      V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2416});
      V v_t_2418 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_At, 2, (V[]){v_t_2414, v_t_2417})});
      V v_x_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){v_x_2419}), v_st_2411}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2410)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_249)}});
  }
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2esyntax_2esurface_2emutualPublic(heff_dup(v_lit_240), heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(v_lit_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2eappendRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendRev_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendRev(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendRev(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(V v_lit_240, V v_lit_241, V v_src_242, V v_l_243) {
top: ;
  V v_tokens_244 = heff_take_field(v_l_243, 0);
  V v_errors_245 = heff_get_n(v_l_243, 1, 3);
  V v_ltoks_246 = heff_arrayFromList(heff_dup(v_tokens_244));
  V v_t_247 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), v_tokens_244));
  V v_toks_248 = heff_arrayFromList(v_t_247);
  V v_lexDiags_249 = (g_list_2emap_24s338694954x1326523169(v_errors_245));
  V v_t_2410 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_True), heff_dup(v_lit_240), v_lit_241});
  V v_t_2411 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_246, MK_INT(0LL), NTAG(TAG_False), NTAG(TAG_Nil)));
  V v_t_2412 = ({ V a_0 = v_ltoks_246; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ltoks_246); r_; });
  V v_t_2413 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(v_lit_240, v_t_2412));
  return ({ V a_0 = v_src_242; V a_1 = v_t_2410; V a_2 = v_toks_248; V a_3 = v_lexDiags_249; V a_4 = v_t_2411; V a_5 = v_t_2413; V r_ = (g_heff_2esyntax_2esurface_2ereadRun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2411); r_; });
}
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2(V v_tok_240, V v_e0_241, V v_rest_242, V v_st_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_243, 5));
  V v_t_245 = heff_dup(heff_rfield(v_st_243, 6));
  V v_m_246 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_244), v_t_245, heff_dup(v_rest_242)));
  V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_243}));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_MkPair: {
    V v_x11_248 = heff_field(v_x1_247, 0);
    V v_st_249 = heff_field(v_x1_247, 1);
    V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
    switch (heff_tag_of(v_x11_248)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x11_248, 0);
      heff_take_n(v_x11_248, 1ULL, 1);
      heff_drop(v_e0_241);
      heff_drop(v_rest_242);
      heff_drop(v_t_244);
      heff_drop(v_t_245);
      heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
    }
    case TAG_Right: {
      heff_take_n(v_x11_248, 0ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_e0_241), NTAG(TAG_Nil)});
      V v_t_2413 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_2412});
      V v_m_2414 = ({ V a_0 = v_t_244; V a_1 = v_t_245; V a_2 = v_t_2413; V a_3 = v_rest_242; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
      V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_st_249}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop(v_e0_241);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          V v_st_2420 = (g_heff_2esyntax_2esurface_2ereduceAll_24s1819170131x1877449734(v_x_2419));
          V v_t_2421 = heff_get_n(v_st_2420, 1, 2);
          V v_t_2424;
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            v_t_2424 = v_e0_241;
            break;
          }
          case TAG_Cons: {
            V v_x_2422 = heff_field(v_t_2421, 0);
            heff_take_n(v_t_2421, 1ULL, 2);
            heff_drop(v_e0_241);
            v_t_2424 = v_x_2422;
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2424}), v_st_2417});
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_248);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eresolve_24s1165310199x103144756_24tok2(a[0], a[1], a[2], a[3]);
}