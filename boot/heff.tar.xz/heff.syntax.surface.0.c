// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_AsDefinition 21504
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkDAlts 45152
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sig 30557
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_below 294979659
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_id 10114
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_waiting 1348170899
#define LBL_whole 314465745
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2etighterGo(V, V, V, V);
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2etighterGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eanyS(V, V);
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eanyS_clo;
V g_heff_2esyntax_2esurface_2eappendRev(V, V);
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendRev_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
HeffT2 g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2edataParamL(V, V);
V g_heff_2esyntax_2esurface_2edataParamL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edataParamL_clo;
V g_heff_2esyntax_2esurface_2edecimalOfDigits(V);
V g_heff_2esyntax_2esurface_2edecimalOfDigits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edecimalOfDigits_clo;
HeffT3 g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr(V);
HeffT3 g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edefNext(V, V, V);
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefNext_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edocNext(V, V, V);
V g_heff_2esyntax_2esurface_2edocNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edocNext_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
V g_heff_2esyntax_2esurface_2efixDiagsOf(V, V, V);
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eidentOf(V);
V g_heff_2esyntax_2esurface_2eidentOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eidentOf_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2epatTok(V);
V g_heff_2esyntax_2esurface_2epatTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatTok_clo;
HeffT2 g_heff_2esyntax_2esurface_2epchainOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eplaceStep(V, V, V);
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eplaceStep_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
HeffT2 g_heff_2esyntax_2esurface_2erepeatedField_24cpr(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esetBinders(V, V);
V g_heff_2esyntax_2esurface_2esetBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetBinders_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esharedFields(V);
V g_heff_2esyntax_2esurface_2esharedFields_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esharedFields_clo;
V g_heff_2esyntax_2esurface_2eshortcut(V, V, V, V);
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eshortcut_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2esplitExp(V, V);
V g_heff_2esyntax_2esurface_2esplitExp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esplitExp_clo;
V g_heff_2esyntax_2esurface_2espreadGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2espreadGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2espreadGo_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewordKw(V);
V g_heff_2esyntax_2esurface_2ewordKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewordKw_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f2053285389x511622380(V, V, V, V, V);
V g_list_2emap_24f2053285389x511622380_entry(V self, V *a);
extern Clo g_list_2emap_24f2053285389x511622380_clo;
V g_list_2emap_24f523576057x1362531023(V, V, V, V);
V g_list_2emap_24f523576057x1362531023_entry(V self, V *a);
extern Clo g_list_2emap_24f523576057x1362531023_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s2130193383x1335133353(V, V, V, V);
V g_list_2emap_24s2130193383x1335133353_entry(V self, V *a);
extern Clo g_list_2emap_24s2130193383x1335133353_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_list_2emap_24s878634257x1677201747(V);
V g_list_2emap_24s878634257x1677201747_entry(V self, V *a);
extern Clo g_list_2emap_24s878634257x1677201747_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_std_2eordmap_2eempty_get(void);
HEFF_LIT(g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr_str0, 1, "-");
HEFF_LIT(g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr_str1, 1, "+");

HeffT3 g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr(V v_s_240) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr_str0))) {
    V v_t_241 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_242 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
    V v_t_243 = ({ V a_0 = v_t_242; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_242); r_; });
    return ({ V a_0 = NTAG(TAG_True); V a_1 = v_t_241; V a_2 = v_t_243; HeffT3 r_ = (g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  } else {
    if (heff_strEq_c(heff_strSlice_lent(v_s_240, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2esyntax_2esurface_2edecimalOfDigits_24cpr_str1))) {
      V v_t_244 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_245 = heff_strSlice(heff_dup(v_s_240), MK_INT(1LL), heff_strLength_lent(v_s_240, 0));
      V v_t_246 = ({ V a_0 = v_t_245; V a_1 = MK_INT(0LL); V r_ = (g_heff_2esyntax_2esurface_2esplitExp(a_0, a_1)); heff_drop(v_t_245); r_; });
      return ({ V a_0 = NTAG(TAG_False); V a_1 = v_t_244; V a_2 = v_t_246; HeffT3 r_ = (g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
    } else {
      V v_t_247 = (g_heff_2esyntax_2esurface_2esplitExp(v_s_240, MK_INT(0LL)));
      return (g_heff_2esyntax_2esurface_2edecimalSplit_24cpr(NTAG(TAG_False), v_s_240, v_t_247));
    }
  }
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2efoldr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efoldr(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(g_heff_2esyntax_2esurface_2efoldr(heff_dup(v_f_240), v_z_241, v_xs_244));
    return heff_tail(v_f_240, 2, (V[]){heff_dup(v_x_243), v_t_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2efoldr(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_str0, 47, "an implicit argument is named: `{x : T} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_str1, 47, "an implicit argument is named: `{x : T} -> ...`");
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_entry, 6, 0};

V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001(V v_lit_240, V v_rhs_241, V v_g_242, V v_ty_243, V v_dflt_244, V v_orig_245) {
top: ;
  V v_t_2412;
  switch (heff_tag_of(v_g_242)) {
  case TAG_At: {
    V v_e1_246 = heff_dup(heff_field(v_g_242, 0));
    switch (heff_tag_of(v_e1_246)) {
    case TAG_EApp: {
      V v_h_248 = heff_field(v_e1_246, 0);
      V v_xs_249 = heff_field(v_e1_246, 1);
      heff_take_n(v_e1_246, 3ULL, 2);
      switch (heff_tag_of(v_g_242)) {
      case TAG_At: {
        v_t_2412 = heff_rec_n(2, shape_head__args, (V[]){v_h_248, v_xs_249});
        break;
      }
      default: heff_nomatch(v_g_242);
      }
      break;
    }
    default: {
      heff_drop(v_e1_246);
      v_t_2412 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_242), NTAG(TAG_Nil)});
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_g_242);
  }
  V v_t_2413 = ({ V b_0 = heff_get_n(v_t_2412, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2eisVarE(b_0)); heff_drop(b_0); r_; });
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    V v_t_2420;
    switch (heff_tag_of(v_g_242)) {
    case TAG_At: {
      V v_e1_2414 = heff_dup(heff_field(v_g_242, 0));
      switch (heff_tag_of(v_e1_2414)) {
      case TAG_EApp: {
        V v_h_2416 = heff_field(v_e1_2414, 0);
        V v_xs_2417 = heff_field(v_e1_2414, 1);
        heff_take_n(v_e1_2414, 3ULL, 2);
        switch (heff_tag_of(v_g_242)) {
        case TAG_At: {
          v_t_2420 = heff_rec_n(2, shape_head__args, (V[]){v_h_2416, v_xs_2417});
          break;
        }
        default: heff_nomatch(v_g_242);
        }
        break;
      }
      default: {
        heff_drop(v_e1_2414);
        v_t_2420 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_242), NTAG(TAG_Nil)});
        break;
      }
      }
      break;
    }
    default: heff_nomatch(v_g_242);
    }
    V v_t_2421 = ({ V b_0 = heff_get_n(v_t_2420, 1, 2); V r_ = (g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(b_0)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_t_2421);
      V v_f_2487 = heff_clo_n(g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_lam0, 2, 3, (V[]){v_lit_240, v_ty_243, v_dflt_244});
      V v_t_2494;
      switch (heff_tag_of(v_g_242)) {
      case TAG_At: {
        V v_e1_2488 = heff_dup(heff_field(v_g_242, 0));
        switch (heff_tag_of(v_e1_2488)) {
        case TAG_EApp: {
          V v_h_2490 = heff_field(v_e1_2488, 0);
          V v_xs_2491 = heff_field(v_e1_2488, 1);
          heff_take_n(v_e1_2488, 3ULL, 2);
          switch (heff_tag_of(v_g_242)) {
          case TAG_At: {
            v_t_2494 = heff_rec_n(2, shape_head__args, (V[]){v_h_2490, v_xs_2491});
            break;
          }
          default: heff_nomatch(v_g_242);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2488);
          v_t_2494 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_242), NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_242);
      }
      V v_t_24101;
      switch (heff_tag_of(v_g_242)) {
      case TAG_At: {
        V v_e1_2495 = heff_dup(heff_field(v_g_242, 0));
        switch (heff_tag_of(v_e1_2495)) {
        case TAG_EApp: {
          V v_h_2497 = heff_field(v_e1_2495, 0);
          V v_xs_2498 = heff_field(v_e1_2495, 1);
          heff_take_n(v_e1_2495, 3ULL, 2);
          switch (heff_tag_of(v_g_242)) {
          case TAG_At: {
            heff_take_n(v_g_242, 0ULL, 2);
            v_t_24101 = heff_rec_n(2, shape_head__args, (V[]){v_h_2497, v_xs_2498});
            break;
          }
          default: heff_nomatch(v_g_242);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2495);
          v_t_24101 = heff_rec_n(2, shape_head__args, (V[]){v_g_242, NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_242);
      }
      V v_t_24102 = ({ V a_0 = heff_dup(v_f_2487); V a_1 = v_rhs_241; V b_2 = heff_get_n(v_t_24101, 1, 2); V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_tail(v_f_2487, 2, (V[]){heff_get_n(v_t_2494, 0, 2), v_t_24102});
    } else {
      heff_drop(v_g_242);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_t_2421);
      V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_str0)}), heff_dup(v_lit_240)});
      V v_t_24104 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24103}), heff_dup(v_rhs_241)});
      V v_t_24107;
      switch (heff_tag_of(v_rhs_241)) {
      case TAG_At: {
        V v_s_24106 = heff_field(v_rhs_241, 1);
        heff_take_n(v_rhs_241, 2ULL, 2);
        v_t_24107 = v_s_24106;
        break;
      }
      default: heff_nomatch(v_rhs_241);
      }
      V v_t_24108 = ({ V rv_1 = heff_get_n(v_t_24107, 1, 2); V rr_ = heff_rec_reuse_nf(v_lit_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_n(TAG_At, 2, (V[]){v_t_24104, v_t_24108});
    }
  } else {
    heff_drop(v_g_242);
    heff_drop(v_ty_243);
    heff_drop(v_dflt_244);
    heff_drop(v_t_2413);
    V v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_str1)}), heff_dup(v_lit_240)});
    V v_t_24110 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiAnon, 1, (V[]){v_t_24109}), heff_dup(v_rhs_241)});
    V v_t_24113;
    switch (heff_tag_of(v_rhs_241)) {
    case TAG_At: {
      V v_s_24112 = heff_field(v_rhs_241, 1);
      heff_take_n(v_rhs_241, 2ULL, 2);
      v_t_24113 = v_s_24112;
      break;
    }
    default: heff_nomatch(v_rhs_241);
    }
    V v_t_24114 = ({ V rv_1 = heff_get_n(v_t_24113, 1, 2); V rr_ = heff_rec_reuse_nf(v_lit_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_At, 2, (V[]){v_t_24110, v_t_24114});
  }
}
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2esyntax_2esurface_2earrowNames_24s1702258180x1785213001_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_b_2423 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ty_243 = heff_env(self)[1];
  V v_dflt_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_At: {
    V v_it1_2424 = heff_field(v_x_2422, 0);
    V v_ysp_2425 = heff_field(v_x_2422, 1);
    V v_ru_24x_2422_24At = heff_take_reuse_n(v_x_2422, 3ULL, 2);
    switch (heff_tag_of(v_it1_2424)) {
    case TAG_EVar: {
      V v_y_2426 = heff_field(v_it1_2424, 0);
      heff_take_n(v_it1_2424, 1ULL, 1);
      V v_t_2427 = heff_tag_n(TAG_EPi, 2, (V[]){heff_tag_n(TAG_PiImplicit, 5, (V[]){v_y_2426, v_ysp_2425, heff_dup(v_lit_240), v_ty_243, v_dflt_244}), heff_dup(v_b_2423)});
      V v_t_2430;
      switch (heff_tag_of(v_b_2423)) {
      case TAG_At: {
        V v_s_2429 = heff_field(v_b_2423, 1);
        heff_take_n(v_b_2423, 2ULL, 2);
        v_t_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_b_2423);
      }
      V v_t_2431 = ({ V rv_1 = heff_get_n(v_t_2430, 1, 2); V rr_ = heff_rec_reuse_nf(v_lit_240, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return heff_tag_at_n(v_ru_24x_2422_24At, TAG_At, 2, (V[]){v_t_2427, v_t_2431});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ETag: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EInt: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EFloat: {
      heff_take_nf(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EString: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ERune: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWord: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EApp: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EProject: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EPi: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELam: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_2424, 0ULL, 4);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ESig: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ESum: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EDo: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_2424, 0ULL, 3);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EFor: {
      heff_take_n(v_it1_2424, 0ULL, 3);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_2424, 0ULL, 2);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EBreak: {
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EContinue: {
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ENest: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ELazy: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ETuple: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_ETry: {
      heff_take_n(v_it1_2424, 0ULL, 1);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    case TAG_EWith: {
      heff_take_n(v_it1_2424, 0ULL, 4);
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_ty_243);
      heff_drop(v_dflt_244);
      heff_drop(v_ysp_2425);
      heff_drop_cell(v_ru_24x_2422_24At, 2);
      return v_b_2423;
    }
    default: return heff_nomatch(v_it1_2424);
    }
  }
  default: return heff_nomatch(v_x_2422);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str0, 4, "Bool");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str1, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str2, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eshortcut_str3, 4, "Bool");
Clo g_heff_2esyntax_2esurface_2eshortcut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eshortcut_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eshortcut(V v_op_240, V v_c_241, V v_a_242, V v_b_243) {
top: ;
  V v_start_244 = heff_take_field(v_op_240, 3);
  V v_end_245 = heff_get_n(v_op_240, 4, 9);
  V v_osp_246 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_244), heff_dup(v_end_245)});
  V v_osp_247 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_244), heff_dup(v_end_245)});
  V v_t_2410;
  switch (heff_tag_of(v_c_241)) {
  case TAG_At: {
    V v_s_249 = heff_dup(heff_field(v_c_241, 1));
    v_t_2410 = v_s_249;
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  V v_t_2411 = ({ V rv_1 = heff_dup(heff_rfield(v_osp_247, 1)); V rr_ = heff_rec_reuse_nf(v_t_2410, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_tsp_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_244), heff_dup(v_end_245)});
  V v_t_2413 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_tsp_2412, 0)), heff_dup(heff_rfield(v_tsp_2412, 1))});
  V v_t_2416;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2415 = heff_dup(heff_field(v_a_242, 1));
    v_t_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_t_2417 = ({ V rv_0 = heff_dup(heff_rfield(v_t_2413, 0)); V rr_ = heff_rec_reuse_nf(v_t_2416, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_tsp_2418 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
  V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_tsp_2418, 0)), heff_dup(heff_rfield(v_tsp_2418, 1))});
  V v_t_2422;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2421 = heff_dup(heff_field(v_b_243, 1));
    v_t_2422 = v_s_2421;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_t_2423 = ({ V rv_0 = heff_dup(heff_rfield(v_t_2419, 0)); V rr_ = heff_rec_reuse_nf(v_t_2422, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2426;
  switch (heff_tag_of(v_a_242)) {
  case TAG_At: {
    V v_s_2425 = heff_dup(heff_field(v_a_242, 1));
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  V v_a_2427 = heff_get_n(v_t_2426, 1, 2);
  V v_t_2430;
  switch (heff_tag_of(v_b_243)) {
  case TAG_At: {
    V v_s_2429 = heff_dup(heff_field(v_b_243, 1));
    v_t_2430 = v_s_2429;
    break;
  }
  default: heff_nomatch(v_b_243);
  }
  V v_b_2431 = heff_get_n(v_t_2430, 1, 2);
  V v_t_2434;
  switch (heff_tag_of(v_c_241)) {
  case TAG_At: {
    V v_s_2433 = heff_dup(heff_field(v_c_241, 1));
    v_t_2434 = v_s_2433;
    break;
  }
  default: heff_nomatch(v_c_241);
  }
  V v_t_2435;
  if (heff_intLt_c_lent(v_a_2427, v_b_2431, 0)) {
    heff_drop(v_a_2427);
    v_t_2435 = v_b_2431;
  } else {
    heff_drop(v_b_2431);
    v_t_2435 = v_a_2427;
  }
  V v_t_2436 = ({ V rv_1 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_t_2434, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EImplicitVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str0)}), v_osp_247});
  V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_c_241, v_t_2437}), v_t_2411});
  V v_t_2439 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str1), v_tsp_2412, NTAG(TAG_Nil)});
  V v_t_2440 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2439, v_t_2413}), v_a_242});
  V v_t_2441 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str2), v_tsp_2418, NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2441, v_t_2419}), v_b_243});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2423}), NTAG(TAG_Nil)});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2440, v_t_2417}), v_t_2443});
  V v_e_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2438, v_t_2444}), v_t_2436});
  V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EImplicitVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eshortcut_str3)}), heff_dup(v_osp_246)});
  V v_t_2449;
  switch (heff_tag_of(v_e_2445)) {
  case TAG_At: {
    V v_s_2448 = heff_dup(heff_field(v_e_2445, 1));
    v_t_2449 = v_s_2448;
    break;
  }
  default: heff_nomatch(v_e_2445);
  }
  V v_t_2450 = ({ V rv_1 = heff_get_n(v_osp_246, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2449, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_e_2445, v_t_2446}), v_t_2450});
}
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eshortcut(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2esyntax_2esurface_2eplaceStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eplaceStep_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eplaceStep(V v_src_240, V v_p_241, V v_it_242) {
top: ;
  switch (heff_tag_of(v_it_242)) {
  case TAG_Sig: {
    V v_t_2440;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_Eqn: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      V v_d_2416 = heff_dup(heff_field(v_it_242, 0));
      switch (heff_tag_of(v_d_2416)) {
      case TAG_At: {
        V v_x11_2417 = heff_field(v_d_2416, 0);
        heff_take_n(v_d_2416, 1ULL, 2);
        switch (heff_tag_of(v_x11_2417)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2417, 0ULL, 5);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2417, 0ULL, 5);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2417, 0ULL, 4);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2417, 0ULL, 3);
          v_t_2440 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2417, 0ULL, 2);
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2417, 0ULL, 1);
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2417);
        }
        break;
      }
      default: heff_nomatch(v_d_2416);
      }
      break;
    }
    case TAG_Doc: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop(v_t_2440);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edefNext(v_src_240, v_p_241, v_it_242);
    } else {
      heff_drop(v_t_2440);
      V v_items_2441 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
      V v_diags_2442 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_diags_2442);
      V v_items_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2441});
      V v_items_2444 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_items_2444);
      V v_diags_2445 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
      return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2443, NTAG(TAG_Nil), v_diags_2445});
    }
  }
  case TAG_Eqn: {
    V v_t_2481;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      v_t_2481 = NTAG(TAG_True);
      break;
    }
    case TAG_Eqn: {
      v_t_2481 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      V v_d_2457 = heff_dup(heff_field(v_it_242, 0));
      switch (heff_tag_of(v_d_2457)) {
      case TAG_At: {
        V v_x11_2458 = heff_field(v_d_2457, 0);
        heff_take_n(v_d_2457, 1ULL, 2);
        switch (heff_tag_of(v_x11_2458)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2458, 0ULL, 5);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2458, 0ULL, 5);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2458, 0ULL, 4);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2458, 0ULL, 3);
          v_t_2481 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2458, 0ULL, 2);
          v_t_2481 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2458, 0ULL, 1);
          v_t_2481 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2458);
        }
        break;
      }
      default: heff_nomatch(v_d_2457);
      }
      break;
    }
    case TAG_Doc: {
      v_t_2481 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_2481) == NTAG(TAG_True))) {
      heff_drop(v_t_2481);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edefNext(v_src_240, v_p_241, v_it_242);
    } else {
      heff_drop(v_t_2481);
      V v_items_2482 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
      V v_diags_2483 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_diags_2483);
      V v_items_2484 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2482});
      V v_items_2485 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_items_2485);
      V v_diags_2486 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
      return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2484, NTAG(TAG_Nil), v_diags_2486});
    }
  }
  case TAG_Whole: {
    V v_t_24120;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      v_t_24120 = NTAG(TAG_True);
      break;
    }
    case TAG_Eqn: {
      v_t_24120 = NTAG(TAG_False);
      break;
    }
    case TAG_Whole: {
      V v_d_2496 = heff_dup(heff_field(v_it_242, 0));
      switch (heff_tag_of(v_d_2496)) {
      case TAG_At: {
        V v_x11_2497 = heff_field(v_d_2496, 0);
        heff_take_n(v_d_2496, 1ULL, 2);
        switch (heff_tag_of(v_x11_2497)) {
        case TAG_DeclEquations: {
          heff_take_n(v_x11_2497, 0ULL, 5);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclDefine: {
          heff_take_n(v_x11_2497, 0ULL, 5);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTheory: {
          heff_take_n(v_x11_2497, 0ULL, 4);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclPrimitive: {
          heff_take_n(v_x11_2497, 0ULL, 3);
          v_t_24120 = NTAG(TAG_True);
          break;
        }
        case TAG_DeclTest: {
          heff_take_n(v_x11_2497, 0ULL, 2);
          v_t_24120 = NTAG(TAG_False);
          break;
        }
        case TAG_DeclWatch: {
          heff_take_n(v_x11_2497, 0ULL, 1);
          v_t_24120 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x11_2497);
        }
        break;
      }
      default: heff_nomatch(v_d_2496);
      }
      break;
    }
    case TAG_Doc: {
      v_t_24120 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    if ((heff_dup(v_t_24120) == NTAG(TAG_True))) {
      heff_drop(v_t_24120);
      HEFF_LAST return g_heff_2esyntax_2esurface_2edefNext(v_src_240, v_p_241, v_it_242);
    } else {
      heff_drop(v_t_24120);
      V v_items_24121 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
      V v_diags_24122 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_diags_24122);
      V v_items_24123 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_24121});
      V v_items_24124 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
      heff_drop(v_items_24124);
      V v_diags_24125 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
      return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_24123, NTAG(TAG_Nil), v_diags_24125});
    }
  }
  case TAG_Doc: {
    V v_d_24126 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2esurface_2edocNext(v_src_240, v_p_241, v_d_24126);
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2esyntax_2esurface_2eplaceStep_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eplaceStep(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str1, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str2, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str3, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str4, 1, "_");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str7, 3, "str");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str8, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2esurface_2epatTok_str9, 3, "sym");
Clo g_heff_2esyntax_2esurface_2epatTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epatTok_entry, 1, 0};

V g_heff_2esyntax_2esurface_2epatTok(V v_t_240) {
top: ;
  V v_kind_241 = heff_take_field(v_t_240, 0);
  V v_text_242 = heff_take_field(v_t_240, 1);
  V v_start_243 = heff_take_field(v_t_240, 3);
  V v_end_244 = heff_get_n(v_t_240, 4, 9);
  if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2epatTok_str0), 2)) {
    heff_drop(v_kind_241);
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
  } else {
    if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2epatTok_str1), 2)) {
      heff_drop(v_kind_241);
      V v_t_245 = ({ V a_0 = v_text_242; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_text_242); r_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatInt, 1, (V[]){v_t_245}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
    } else {
      if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2epatTok_str2), 2)) {
        heff_drop(v_kind_241);
        V v_s_246 = v_text_242;
        V v_x2_247 = ({ V b_0 = ((V)&g_heff_2esyntax_2esurface_2epatTok_str3); V a_1 = v_s_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2epatTok_str4), v_s_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_246); r_; });
        V v_t_2410;
        switch (heff_tag_of(v_x2_247)) {
        case TAG_Nil: {
          v_t_2410 = ((V)&g_heff_2esyntax_2esurface_2epatTok_str5);
          break;
        }
        case TAG_Cons: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_xs_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2esurface_2epatTok_str6); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
          break;
        }
        default: heff_nomatch(v_x2_247);
        }
        V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2esyntax_2esurface_2edecimalOfDigits(a_0)); heff_drop(v_t_2410); r_; });
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatFloat, 1, (V[]){v_t_2411}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
      } else {
        if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2epatTok_str7), 2)) {
          heff_drop(v_kind_241);
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatString, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
        } else {
          if (heff_strEq_c_lent(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2epatTok_str8), 2)) {
            heff_drop(v_kind_241);
            V v_t_2412 = heff_runeToInt(heff_strRuneAt(v_text_242, MK_INT(0LL)));
            return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRune, 1, (V[]){v_t_2412}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
          } else {
            if (heff_strEq_c(v_kind_241, ((V)&g_heff_2esyntax_2esurface_2epatTok_str9))) {
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
            } else {
              V v_t_2413 = ({ V a_0 = v_text_242; V r_ = (g_heff_2esyntax_2esurface_2ewordKw(a_0)); heff_drop(v_text_242); r_; });
              return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatWord, 1, (V[]){v_t_2413}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2epatTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2epatTok(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2equalifiedE_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2equalifiedE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2equalifiedE_entry, 2, 0};

V g_heff_2esyntax_2esurface_2equalifiedE(V v_t_240, V v_x2_241) {
top: ;
  V v_text_242 = heff_take_field(v_t_240, 1);
  V v_start_243 = heff_take_field(v_t_240, 3);
  V v_end_244 = heff_get_n(v_t_240, 4, 9);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){v_text_242}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_244})});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    heff_drop(v_end_244);
    V v_text_247 = heff_take_field(v_f_245, 1);
    V v_end_248 = heff_get_n(v_f_245, 4, 9);
    V v_t_249 = heff_strAppend(heff_strAppend(v_text_242, ((V)&g_heff_2esyntax_2esurface_2equalifiedE_str0)), v_text_247);
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_249}), heff_rec_n(2, shape_start__end, (V[]){v_start_243, v_end_248})});
    V v_t_2411 = (g_list_2emap_24s513201124x806973253(v_rest_246));
    HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2411);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2equalifiedE(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2econAtom_str0, 1, ".");
V g_heff_2esyntax_2esurface_2econAtom_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2econAtom_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2econAtom_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2econAtom_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2econAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econAtom(V v_t_240, V v_fs_241, V v_p_242) {
top: ;
  HEFF_LAST return g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam0, 1, 1, (V[]){heff_dup(v_t_240)}), heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam1, 2, 2, (V[]){v_fs_241, v_t_240}), v_p_242);
}
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2econAtom_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_t_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_t_240, 1, 9)}));
  V v_t_245 = (g_list_2eany(v_t_244, heff_rfield(v_st_243, 1)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_245}), v_st_243});
}
V g_heff_2esyntax_2esurface_2econAtom_lam2(V self, V *args) {
  V v_st_248 = args[0];
  V v_fs_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_fs_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_t_240, 9);
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_f_249 = heff_field(v_fs_241, 0);
    heff_take_n(v_fs_241, 1ULL, 2);
    V v_t_2411 = heff_strAppend(heff_get_n(v_t_240, 1, 9), ((V)&g_heff_2esyntax_2esurface_2econAtom_str0));
    V v_t_2412 = heff_strAppend(v_t_2411, heff_get_n(v_f_249, 1, 9));
    v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_248, 2)), 1, (V[]){v_t_2412}));
    break;
  }
  default: heff_nomatch(v_fs_241);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_248});
}
V g_heff_2esyntax_2esurface_2econAtom_lam3(V self, V *args) {
  V v_qualified_2414 = args[0];
  V v_st_2415 = args[1];
  V v_local_246 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_fs_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416;
  if ((heff_dup(v_local_246) == NTAG(TAG_True))) {
    v_t_2416 = NTAG(TAG_True);
  } else {
    v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_2415, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  }
  V v_x_2426;
  if ((heff_dup(v_local_246) == NTAG(TAG_True))) {
    heff_drop(v_qualified_2414);
    heff_drop(v_local_246);
    heff_drop(v_t_2416);
    V v_t_2417 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
    V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
    V v_t_2419 = (g_list_2emap_24s513201124x806973253(v_fs_241));
    v_x_2426 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2417, v_t_2418}), v_t_2419));
  } else {
    heff_drop(v_local_246);
    if ((heff_dup(v_qualified_2414) == NTAG(TAG_True))) {
      heff_drop(v_qualified_2414);
      heff_drop(v_t_2416);
      v_x_2426 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_240, v_fs_241));
    } else {
      heff_drop(v_qualified_2414);
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop(v_t_2416);
        V v_t_2420 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
        V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2422 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2426 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_t_2421}), v_t_2422));
      } else {
        heff_drop(v_t_2416);
        V v_t_2423 = heff_tag_n(TAG_ETag, 1, (V[]){heff_take_field(v_t_240, 1)});
        V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2425 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2426 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424}), v_t_2425));
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2415});
}
V g_heff_2esyntax_2esurface_2econAtom_lam1(V self, V *args) {
  V v_local_246 = args[0];
  V v_z_247 = args[1];
  V v_fs_241 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam2, 1, 2, (V[]){heff_dup(v_fs_241), heff_dup(v_t_240)}), heff_clo_n(g_heff_2esyntax_2esurface_2econAtom_lam3, 2, 3, (V[]){v_local_246, v_t_240, v_fs_241}), v_z_247));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ebracesL_str0, 3, "var");
V g_heff_2esyntax_2esurface_2ebracesL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracesL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracesL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracesL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracesL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ebracesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracesL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ebracesL(V v_r_240, V v_o_241, V v_fs_242, V v_c_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_fs_242)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    V v_t_245 = heff_tag_n(TAG_EStruct, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
    V v_t_247 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_t_246})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_z_244});
  }
  case TAG_Cons: {
    V v_f_248 = heff_dup(heff_field(v_fs_242, 0));
    V v_x1_2410 = v_f_248;
    V v_t_24167;
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Atom: {
      heff_take_n(v_x1_2410, 0ULL, 1);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EParen: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Named: {
      heff_take_n(v_x1_2410, 0ULL, 5);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Tup: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Seg: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Braces: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Update: {
      heff_take_n(v_x1_2410, 0ULL, 6);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EUSet: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_InstB: {
      heff_take_n(v_x1_2410, 0ULL, 5);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EFSet: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_True);
      break;
    }
    case TAG_EFDefault: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Sum: {
      heff_take_n(v_x1_2410, 0ULL, 5);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ECon: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EField: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ENeg: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ETilde: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_App: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Op: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Ops: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_OpRhs: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Ann: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_BVar: {
      heff_take_n(v_x1_2410, 0ULL, 1);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_BImp: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_BAnn: {
      heff_take_n(v_x1_2410, 0ULL, 5);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_BPat: {
      heff_take_n(v_x1_2410, 0ULL, 1);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Lam: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Case: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EAlt: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_If: {
      heff_take_n(v_x1_2410, 0ULL, 6);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_Do: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ESBind: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x1_2410, 0ULL, 6);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ELetElse: {
      heff_take_n(v_x1_2410, 0ULL, 7);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ELetMut: {
      heff_take_n(v_x1_2410, 0ULL, 6);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EAssign: {
      heff_take_n(v_x1_2410, 0ULL, 3);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EWhile: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EFor: {
      heff_take_n(v_x1_2410, 0ULL, 6);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EJump: {
      heff_take_n(v_x1_2410, 0ULL, 1);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EReturn: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ENest: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EArrow: {
      heff_take_n(v_x1_2410, 0ULL, 2);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_IfThen: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ETry: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_ECatch: {
      heff_take_n(v_x1_2410, 0ULL, 4);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    case TAG_EWith: {
      heff_take_n(v_x1_2410, 0ULL, 6);
      v_t_24167 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_2410);
    }
    if ((heff_dup(v_t_24167) == NTAG(TAG_True))) {
      heff_drop(v_t_24167);
      V v_m_24169 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam0, 1, 1, (V[]){v_r_240}), v_fs_242));
      V v_x1_24170 = heff_tr(heff_call(v_m_24169, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_24170)) {
      case TAG_MkPair: {
        V v_x11_24171 = heff_field(v_x1_24170, 0);
        V v_st_24172 = heff_field(v_x1_24170, 1);
        V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
        switch (heff_tag_of(v_x11_24171)) {
        case TAG_Left: {
          V v_e_24173 = heff_field(v_x11_24171, 0);
          V v_ru_24x11_24171_24Left = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
          heff_drop_rec(v_o_241, 9);
          heff_drop_rec(v_c_243, 9);
          return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24171_24Left, TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
        }
        case TAG_Right: {
          V v_x_24174 = heff_field(v_x11_24171, 0);
          V v_ru_24x11_24171_24Right = heff_take_reuse_n(v_x11_24171, 1ULL, 1);
          V v_t_24175 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
          V v_t_24176 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EStruct, 1, (V[]){v_x_24174}), v_t_24175});
          return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24171_24Right, TAG_Right, 1, (V[]){v_t_24176}), v_st_24172});
        }
        default: return heff_nomatch(v_x11_24171);
        }
      }
      default: return heff_nomatch(v_x1_24170);
      }
    } else {
      heff_drop(v_t_24167);
      V v_m_24199 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam1, 1, 1, (V[]){v_r_240}), v_fs_242));
      V v_x1_24200 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_24200)) {
      case TAG_MkPair: {
        V v_x11_24201 = heff_field(v_x1_24200, 0);
        V v_st_24202 = heff_field(v_x1_24200, 1);
        V v_ru_24x1_24200_24MkPair = heff_take_reuse_n(v_x1_24200, 3ULL, 2);
        switch (heff_tag_of(v_x11_24201)) {
        case TAG_Left: {
          V v_e_24203 = heff_field(v_x11_24201, 0);
          V v_ru_24x11_24201_24Left = heff_take_reuse_n(v_x11_24201, 1ULL, 1);
          heff_drop_rec(v_o_241, 9);
          heff_drop_rec(v_c_243, 9);
          return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24201_24Left, TAG_Left, 1, (V[]){v_e_24203}), v_st_24202});
        }
        case TAG_Right: {
          V v_x_24204 = heff_field(v_x11_24201, 0);
          V v_ru_24x11_24201_24Right = heff_take_reuse_n(v_x11_24201, 1ULL, 1);
          HeffT2 v_t_24205 = (g_heff_2esyntax_2esurface_2erepeatedField_24cpr(NTAG(TAG_Nil), heff_dup(v_x_24204)));
          {
            V v_field_24207 = v_t_24205.f[1];
            int64_t v_tag_24206 = ((int64_t)v_t_24205.f[0]);
            if ((v_tag_24206 == ((int64_t)0ULL))) {
              heff_drop_rec(v_o_241, 9);
              heff_drop_rec(v_c_243, 9);
              heff_drop(v_x_24204);
              heff_drop_cell(v_ru_24x11_24201_24Right, 1);
              V v_d_24208 = v_field_24207;
              return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_24208}), v_st_24202});
            } else {
              heff_drop(v_field_24207);
              V v_m_24209 = (g_heff_2esyntax_2esurface_2esharedFields(v_x_24204));
              V v_x1_24210 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_st_24202}));
              switch (heff_tag_of(v_x1_24210)) {
              case TAG_MkPair: {
                V v_x11_24211 = heff_field(v_x1_24210, 0);
                V v_st_24212 = heff_field(v_x1_24210, 1);
                V v_ru_24x1_24210_24MkPair = heff_take_reuse_n(v_x1_24210, 3ULL, 2);
                switch (heff_tag_of(v_x11_24211)) {
                case TAG_Left: {
                  V v_e_24213 = heff_field(v_x11_24211, 0);
                  V v_ru_24x11_24211_24Left = heff_take_reuse_n(v_x11_24211, 1ULL, 1);
                  heff_drop_rec(v_o_241, 9);
                  heff_drop_rec(v_c_243, 9);
                  heff_drop_cell(v_ru_24x11_24201_24Right, 1);
                  heff_drop_cell(v_ru_24x1_24210_24MkPair, 2);
                  return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24211_24Left, TAG_Left, 1, (V[]){v_e_24213}), v_st_24212});
                }
                case TAG_Right: {
                  V v_x_24214 = heff_field(v_x11_24211, 0);
                  V v_ru_24x11_24211_24Right = heff_take_reuse_n(v_x11_24211, 1ULL, 1);
                  V v_t_24215 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
                  V v_t_24216 = heff_tag_at_n(v_ru_24x1_24210_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24211_24Right, TAG_ESig, 1, (V[]){v_x_24214}), v_t_24215});
                  return heff_tag_at_n(v_ru_24x1_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24201_24Right, TAG_Right, 1, (V[]){v_t_24216}), v_st_24212});
                }
                default: return heff_nomatch(v_x11_24211);
                }
              }
              default: return heff_nomatch(v_x1_24210);
              }
            }
          }
        }
        default: return heff_nomatch(v_x11_24201);
        }
      }
      default: return heff_nomatch(v_x1_24200);
      }
    }
  }
  default: return heff_nomatch(v_fs_242);
  }
}
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebracesL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ebracesL_lam0(V self, V *args) {
  V v_m_24168 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_24168));
}
V g_heff_2esyntax_2esurface_2ebracesL_lam2(V self, V *args) {
  V v_st_24181 = args[0];
  V v_x_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24182 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x_24180})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24182, v_st_24181});
}
V g_heff_2esyntax_2esurface_2ebracesL_lam3(V self, V *args) {
  V v_st_24184 = args[0];
  V v_m_24183 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24185 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_st_24184}));
  switch (heff_tag_of(v_x1_24185)) {
  case TAG_MkPair: {
    V v_x11_24186 = heff_field(v_x1_24185, 0);
    V v_st_24187 = heff_field(v_x1_24185, 1);
    V v_ru_24x1_24185_24MkPair = heff_take_reuse_n(v_x1_24185, 3ULL, 2);
    switch (heff_tag_of(v_x11_24186)) {
    case TAG_Left: {
      V v_e_24188 = heff_field(v_x11_24186, 0);
      V v_ru_24x11_24186_24Left = heff_take_reuse_n(v_x11_24186, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24185_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24186_24Left, TAG_Left, 1, (V[]){v_e_24188}), v_st_24187});
    }
    case TAG_Right: {
      V v_x_24189 = heff_field(v_x11_24186, 0);
      V v_ru_24x11_24186_24Right = heff_take_reuse_n(v_x11_24186, 1ULL, 1);
      V v_t_24190 = heff_tag_at_n(v_ru_24x11_24186_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24189})});
      return heff_tag_at_n(v_ru_24x1_24185_24MkPair, TAG_MkPair, 2, (V[]){v_t_24190, v_st_24187});
    }
    default: return heff_nomatch(v_x11_24186);
    }
  }
  default: return heff_nomatch(v_x1_24185);
  }
}
V g_heff_2esyntax_2esurface_2ebracesL_lam4(V self, V *args) {
  V v_st_24192 = args[0];
  V v_m_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24193 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_st_24192}));
  switch (heff_tag_of(v_x1_24193)) {
  case TAG_MkPair: {
    V v_x11_24194 = heff_field(v_x1_24193, 0);
    V v_st_24195 = heff_field(v_x1_24193, 1);
    V v_ru_24x1_24193_24MkPair = heff_take_reuse_n(v_x1_24193, 3ULL, 2);
    switch (heff_tag_of(v_x11_24194)) {
    case TAG_Left: {
      V v_e_24196 = heff_field(v_x11_24194, 0);
      V v_ru_24x11_24194_24Left = heff_take_reuse_n(v_x11_24194, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24194_24Left, TAG_Left, 1, (V[]){v_e_24196}), v_st_24195});
    }
    case TAG_Right: {
      V v_x_24197 = heff_field(v_x11_24194, 0);
      V v_ru_24x11_24194_24Right = heff_take_reuse_n(v_x11_24194, 1ULL, 1);
      V v_t_24198 = heff_tag_at_n(v_ru_24x11_24194_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24197})});
      return heff_tag_at_n(v_ru_24x1_24193_24MkPair, TAG_MkPair, 2, (V[]){v_t_24198, v_st_24195});
    }
    default: return heff_nomatch(v_x11_24194);
    }
  }
  default: return heff_nomatch(v_x1_24193);
  }
}
V g_heff_2esyntax_2esurface_2ebracesL_lam1(V self, V *args) {
  V v_m_24177 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24178 = v_r_240;
  V v_e_24179 = v_m_24177;
  switch (heff_tag_of(v_e_24179)) {
  case TAG_Atom: {
    V v_x_24180 = heff_field(v_e_24179, 0);
    V v_ru_24e_24179_24Atom = heff_take_reuse_n(v_e_24179, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_24180, 0)), ((V)&g_heff_2esyntax_2esurface_2ebracesL_str0))) {
      heff_drop(v_r_24178);
      heff_drop_cell(v_ru_24e_24179_24Atom, 1);
      return heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam2, 1, 1, (V[]){v_x_24180});
    } else {
      V v_m_24183 = heff_tr(g_heff_2esyntax_2esurface_2efieldL(v_r_24178, heff_tag_at_n(v_ru_24e_24179_24Atom, TAG_Atom, 1, (V[]){v_x_24180})));
      return heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam3, 1, 1, (V[]){v_m_24183});
    }
  }
  default: {
    V v_m_24191 = heff_tr(g_heff_2esyntax_2esurface_2efieldL(v_r_24178, v_e_24179));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam4, 1, 1, (V[]){v_m_24191});
  }
  }
}
V g_heff_2esyntax_2esurface_2eletHeadL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eletHeadL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletHeadL_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eletHeadL(V v_r_240, V v_p_241, V v_ann0_242, V v_e_243) {
top: ;
  V v_pat_244 = heff_take_field(v_r_240, 1);
  V v_e_245 = heff_get_n(v_r_240, 0, 3);
  V v_m_246 = heff_tr(heff_call(v_pat_244, 1, (V[]){v_p_241}));
  return heff_clo_n(g_heff_2esyntax_2esurface_2eletHeadL_lam0, 1, 4, (V[]){v_m_246, v_ann0_242, v_e_245, v_e_243});
}
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eletHeadL(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2esurface_2eletHeadL_lam0(V self, V *args) {
  V v_st_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_ann0_242 = heff_env(self)[1];
  V v_e_245 = heff_env(self)[2];
  V v_e_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_st_247}));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_ann0_242);
      heff_drop(v_e_245);
      heff_drop(v_e_243);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      switch (heff_tag_of(v_ann0_242)) {
      case TAG_Nothing: {
        V v_m_2413 = heff_tr(heff_call(v_e_245, 1, (V[]){v_e_243}));
        V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_st_2410}));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_MkPair: {
          V v_x11_2415 = heff_field(v_x1_2414, 0);
          V v_st_2416 = heff_field(v_x1_2414, 1);
          V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
          switch (heff_tag_of(v_x11_2415)) {
          case TAG_Left: {
            V v_e_2417 = heff_field(v_x11_2415, 0);
            V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
            heff_drop(v_x_2412);
            heff_drop_cell(v_ru_24x11_249_24Right, 1);
            heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
          }
          case TAG_Right: {
            V v_x_2418 = heff_field(v_x11_2415, 0);
            heff_take_n(v_x11_2415, 1ULL, 1);
            V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2412, v_x_2418})});
            return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2416});
          }
          default: return heff_nomatch(v_x11_2415);
          }
        }
        default: return heff_nomatch(v_x1_2414);
        }
      }
      case TAG_Just: {
        V v_it1_2420 = heff_field(v_ann0_242, 0);
        V v_ru_24ann0_242_24Just = heff_take_reuse_n(v_ann0_242, 1ULL, 1);
        switch (heff_tag_of(v_it1_2420)) {
        case TAG_MkPair: {
          V v_ty_2422 = heff_field(v_it1_2420, 1);
          V v_ru_24it1_2420_24MkPair = heff_take_reuse_n(v_it1_2420, 2ULL, 2);
          V v_m_2423 = heff_tr(heff_call(heff_dup(v_e_245), 1, (V[]){v_ty_2422}));
          V v_x1_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_st_2410}));
          switch (heff_tag_of(v_x1_2424)) {
          case TAG_MkPair: {
            V v_x11_2425 = heff_field(v_x1_2424, 0);
            V v_st_2426 = heff_field(v_x1_2424, 1);
            V v_ru_24x1_2424_24MkPair = heff_take_reuse_n(v_x1_2424, 3ULL, 2);
            switch (heff_tag_of(v_x11_2425)) {
            case TAG_Left: {
              V v_e_2427 = heff_field(v_x11_2425, 0);
              heff_take_n(v_x11_2425, 1ULL, 1);
              heff_drop(v_e_245);
              heff_drop(v_e_243);
              heff_drop(v_x_2412);
              heff_drop_cell(v_ru_24x11_249_24Right, 1);
              heff_drop_cell(v_ru_24it1_2420_24MkPair, 2);
              heff_drop_cell(v_ru_24x1_2424_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ann0_242_24Just, TAG_Left, 1, (V[]){v_e_2427}), v_st_2426});
            }
            case TAG_Right: {
              V v_x_2428 = heff_field(v_x11_2425, 0);
              heff_take_n(v_x11_2425, 1ULL, 1);
              V v_m_2429 = heff_tr(heff_call(v_e_245, 1, (V[]){v_e_243}));
              V v_x1_2430 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2426}));
              switch (heff_tag_of(v_x1_2430)) {
              case TAG_MkPair: {
                V v_x11_2431 = heff_field(v_x1_2430, 0);
                V v_st_2432 = heff_field(v_x1_2430, 1);
                V v_ru_24x1_2430_24MkPair = heff_take_reuse_n(v_x1_2430, 3ULL, 2);
                switch (heff_tag_of(v_x11_2431)) {
                case TAG_Left: {
                  V v_e_2433 = heff_field(v_x11_2431, 0);
                  heff_take_n(v_x11_2431, 1ULL, 1);
                  heff_drop(v_x_2412);
                  heff_drop_cell(v_ru_24x11_249_24Right, 1);
                  heff_drop_cell(v_ru_24it1_2420_24MkPair, 2);
                  heff_drop_cell(v_ru_24x1_2424_24MkPair, 2);
                  heff_drop(v_x_2428);
                  heff_drop_cell(v_ru_24x1_2430_24MkPair, 2);
                  return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ann0_242_24Just, TAG_Left, 1, (V[]){v_e_2433}), v_st_2432});
                }
                case TAG_Right: {
                  V v_x_2434 = heff_field(v_x11_2431, 0);
                  heff_take_n(v_x11_2431, 1ULL, 1);
                  heff_drop_cell(v_ru_24ann0_242_24Just, 1);
                  V v_t_2437;
                  switch (heff_tag_of(v_x_2428)) {
                  case TAG_At: {
                    V v_s_2436 = heff_dup(heff_field(v_x_2428, 1));
                    v_t_2437 = v_s_2436;
                    break;
                  }
                  default: heff_nomatch(v_x_2428);
                  }
                  V v_t_2440;
                  switch (heff_tag_of(v_x_2434)) {
                  case TAG_At: {
                    V v_s_2439 = heff_dup(heff_field(v_x_2434, 1));
                    v_t_2440 = v_s_2439;
                    break;
                  }
                  default: heff_nomatch(v_x_2434);
                  }
                  V v_t_2441 = ({ V rv_1 = heff_get_n(v_t_2440, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2437, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                  V v_t_2442 = heff_tag_at_n(v_ru_24x1_2424_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_EAnn, 2, (V[]){v_x_2434, v_x_2428}), v_t_2441});
                  V v_t_2443 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){v_x_2412, v_t_2442})});
                  return heff_tag_at_n(v_ru_24it1_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2443, v_st_2432});
                }
                default: return heff_nomatch(v_x11_2431);
                }
              }
              default: return heff_nomatch(v_x1_2430);
              }
            }
            default: return heff_nomatch(v_x11_2425);
            }
          }
          default: return heff_nomatch(v_x1_2424);
          }
        }
        default: return heff_nomatch(v_it1_2420);
        }
      }
      default: return heff_nomatch(v_ann0_242);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}

HeffT2 g_heff_2esyntax_2esurface_2epchainOf_24cpr(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PCon: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PAtom: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PParen: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PList: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_POp: {
    V v_l_2411 = heff_field(v_p_240, 0);
    V v_op_2412 = heff_field(v_p_240, 1);
    V v_r_2413 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    HeffT2 v_t_2414 = (g_heff_2esyntax_2esurface_2epchainOf_24cpr(v_r_2413));
    {
      V v_field_2415 = v_t_2414.f[0];
      V v_field_2416 = v_t_2414.f[1];
      V v_rh_2417 = v_field_2415;
      V v_rest_2418 = v_field_2416;
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_op_2412, v_rh_2417}), v_rest_2418});
      return ((HeffT2){{v_l_2411, v_t_2419}});
    }
  }
  case TAG_PRec: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PField: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PAs: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  case TAG_PSeg: {
    return ((HeffT2){{v_p_240, NTAG(TAG_Nil)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_p_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edeclNameOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2edeclNameOf(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_name__span, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edeclNameOf(a0); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2ewhereL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ewhereL(V v_r_240, V v_kw_241, V v_ds_242, V v_rhs_243, V v_st_244) {
top: ;
  V v_t_245 = heff_dup(heff_rfield(v_st_244, 3));
  V v_t_246 = heff_dup(heff_rfield(v_st_244, 1));
  V v_m_247 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 2, 3), heff_dup(v_ds_242)));
  V v_x1_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_244}));
  V v_x11_2414;
  V v_st_2415;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    heff_take_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Left = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      heff_drop(v_t_246);
      v_x11_2414 = heff_tag_at_n(v_ru_24x11_249_24Left, TAG_Left, 1, (V[]){v_e_2411});
      v_st_2415 = v_st_2410;
      break;
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_st_2413 = (g_heff_2esyntax_2esurface_2esetScope(v_t_246, v_st_2410));
      v_x11_2414 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Right, 1, (V[]){v_x_2412});
      v_st_2415 = v_st_2413;
      break;
    }
    default: heff_nomatch(v_x11_249);
    }
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_x11_2414)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x11_2414, 0);
    V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
    heff_drop_rec(v_kw_241, 9);
    heff_drop(v_ds_242);
    heff_drop(v_rhs_243);
    heff_drop(v_t_245);
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Left, TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x11_2414, 0);
    V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
    V v_st_2418 = (g_heff_2esyntax_2esurface_2esetBinders(v_t_245, v_st_2415));
    V v_t_2419 = heff_dup(heff_rfield(v_st_2418, 7));
    V v_items_2420 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2417));
    V v_items_2421 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2420, NTAG(TAG_Nil)));
    V v_t_2422 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(g_std_2eordmap_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    V v_d_2426 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_lam0, 2, 1, (V[]){v_t_2419}); V a_1 = v_t_2422; V a_2 = v_items_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2421); r_; });
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2426, 3, 4)));
    V v_items_2428 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_2417));
    V v_items_2429 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2428, NTAG(TAG_Nil)));
    V v_t_2430 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2429));
    V v_t_2431 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2429));
    V v_t_2432 = (g_list_2emap_24s2130193383x1335133353(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2430, v_t_2431, v_items_2429));
    V v_t_2433 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2432));
    V v_t_2434 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2427, v_t_2433));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_Nil: {
      V v_items_2435 = ({ V a_0 = v_x_2417; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_2417); r_; });
      V v_items_2436 = (g_heff_2esyntax_2esurface_2espreadGo(NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing), v_items_2435, NTAG(TAG_Nil)));
      V v_t_2437 = (g_heff_2esyntax_2esurface_2eassembleGo(heff_dup(g_std_2eordmap_2eempty_get()), v_items_2436, NTAG(TAG_Nil)));
      V v_x1_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
      V v_b_2442;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_Nil: {
        v_b_2442 = heff_get_n(v_kw_241, 4, 9);
        break;
      }
      case TAG_Cons: {
        V v_x_2439 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 2);
        heff_drop_rec(v_kw_241, 9);
        V v_t_2441 = (g_heff_2esyntax_2ecst_2elastD(v_x_2439));
        v_b_2442 = heff_get_n(v_t_2441, 4, 9);
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      V v_t_2445;
      switch (heff_tag_of(v_rhs_243)) {
      case TAG_At: {
        V v_s_2444 = heff_dup(heff_field(v_rhs_243, 1));
        v_t_2445 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_rhs_243);
      }
      V v_t_2446 = ({ V rv_1 = v_b_2442; V rr_ = heff_rec_reuse_nf(v_t_2445, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_243, v_t_2437}), v_t_2446});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){v_x_2447}), v_st_2418});
    }
    case TAG_Cons: {
      V v_d_2448 = heff_field(v_t_2434, 0);
      V v_ru_24t_2434_24Cons = heff_take_reuse_n(v_t_2434, 1ULL, 2);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_ds_242);
      heff_drop(v_rhs_243);
      heff_drop(v_x_2417);
      heff_drop_cell(v_ru_24x11_2414_24Right, 1);
      return heff_tag_at_n(v_ru_24t_2434_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2448}), v_st_2418});
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  default: return heff_nomatch(v_x11_2414);
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ewhereL_lam0(V self, V *args) {
  V v_d_2423 = args[0];
  V v_it_2424 = args[1];
  V v_t_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2423, 2)), v_it_2424));
  return ({ V a_0 = v_t_2419; V a_1 = v_d_2423; V a_2 = v_t_2425; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2425); r_; });
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2edataL_24cpr(V v_r_240, V v_d_241, V v_kw_242, V v_name_243, V v_params_244, V v_universe_245, V v_alts_246, V v_z_247) {
top: ;
  V v_start_248 = heff_take_field(v_name_243, 3);
  V v_end_249 = heff_take_field(v_name_243, 4);
  V v_text_2410 = heff_get_n(v_name_243, 1, 9);
  V v_m_2412 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_params_244));
  V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_247}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    heff_take_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_text_2410);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2414_24Left, TAG_Left, 1, (V[]){v_e_2416}), v_st_2415}});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2417)));
      V v_m_2425;
      switch (heff_tag_of(v_universe_245)) {
      case TAG_Nothing: {
        v_m_2425 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam1, 1, 2, (V[]){heff_dup(v_start_248), heff_dup(v_end_249)});
        break;
      }
      case TAG_Just: {
        V v_it1_2422 = heff_field(v_universe_245, 0);
        switch (heff_tag_of(v_it1_2422)) {
        case TAG_MkPair: {
          V v_u_2424 = heff_field(v_it1_2422, 1);
          v_m_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){heff_dup(v_u_2424)}));
          break;
        }
        default: heff_nomatch(v_it1_2422);
        }
        break;
      }
      default: heff_nomatch(v_universe_245);
      }
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2418, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam2, 1, 9, (V[]){v_m_2425, heff_dup(v_alts_246), v_r_240, v_d_241, v_kw_242, v_text_2410, v_start_248, v_end_249, v_x_2417}), v_st_2415));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2414)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2413)}});
  }
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2edataParamL(v_r_240, v_m_2411));
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam1(V self, V *args) {
  V v_st_2419 = args[0];
  V v_start_248 = heff_env(self)[0];
  V v_end_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){v_t_2420, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2421}), v_st_2419});
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam3(V self, V *args) {
  V v_a_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_2437));
}
V g_heff_2esyntax_2esurface_2edataL_24cpr_lam2(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  V v_alts_246 = heff_env(self)[1];
  V v_r_240 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_kw_242 = heff_env(self)[4];
  V v_text_2410 = heff_env(self)[5];
  V v_start_248 = heff_env(self)[6];
  V v_end_249 = heff_env(self)[7];
  V v_x_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x1_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    V v_st_2429 = heff_field(v_x1_2427, 1);
    V v_ru_24x1_2427_24MkPair = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_Left: {
      V v_e_2430 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Left = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      heff_drop(v_alts_246);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_d_241);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_text_2410);
      heff_drop(v_start_248);
      heff_drop(v_end_249);
      heff_drop(v_x_2417);
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2428_24Left, TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      V v_t_2436;
      switch (heff_tag_of(v_alts_246)) {
      case TAG_Nothing: {
        v_t_2436 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x11_2432 = heff_field(v_alts_246, 0);
        heff_take_n(v_alts_246, 1ULL, 1);
        switch (heff_tag_of(v_x11_2432)) {
        case TAG_MkDAlts: {
          V v_alts_2434 = heff_field(v_x11_2432, 1);
          heff_take_n(v_x11_2432, 2ULL, 3);
          v_t_2436 = v_alts_2434;
          break;
        }
        default: heff_nomatch(v_x11_2432);
        }
        break;
      }
      default: heff_nomatch(v_alts_246);
      }
      V v_m_2438 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24cpr_lam3, 1, 1, (V[]){v_r_240}), v_t_2436));
      V v_x1_2439 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_st_2429}));
      switch (heff_tag_of(v_x1_2439)) {
      case TAG_MkPair: {
        V v_x11_2440 = heff_field(v_x1_2439, 0);
        V v_st_2441 = heff_field(v_x1_2439, 1);
        V v_ru_24x1_2439_24MkPair = heff_take_reuse_n(v_x1_2439, 3ULL, 2);
        switch (heff_tag_of(v_x11_2440)) {
        case TAG_Left: {
          V v_e_2442 = heff_field(v_x11_2440, 0);
          V v_ru_24x11_2440_24Left = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_kw_242, 9);
          heff_drop(v_text_2410);
          heff_drop(v_start_248);
          heff_drop(v_end_249);
          heff_drop(v_x_2417);
          heff_drop(v_x_2431);
          heff_drop_cell(v_ru_24x11_2428_24Right, 1);
          heff_drop_cell(v_ru_24x1_2439_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2440_24Left, TAG_Left, 1, (V[]){v_e_2442}), v_st_2441});
        }
        case TAG_Right: {
          V v_x_2443 = heff_field(v_x11_2440, 0);
          V v_ru_24x11_2440_24Right = heff_take_reuse_n(v_x11_2440, 1ULL, 1);
          V v_t_2444 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_241)));
          V v_e_2445 = heff_get_n(v_t_2444, 4, 9);
          V v_t_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_242, 3)), v_e_2445});
          V v_t_2447 = heff_tag_at_n(v_ru_24x1_2439_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2440_24Right, TAG_ESum, 1, (V[]){v_x_2443}), v_t_2446});
          V v_t_2448 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_2410, heff_rec_n(2, shape_start__end, (V[]){v_start_248, v_end_249}), v_x_2417, v_x_2431, v_t_2447});
          V v_t_2449 = (g_heff_2esyntax_2ecst_2elastD(v_d_241));
          V v_e_2450 = heff_get_n(v_t_2449, 4, 9);
          V v_t_2451 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2450});
          V v_t_2452 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_t_2451})});
          V v_x_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){v_x_2453}), v_st_2441});
        }
        default: return heff_nomatch(v_x11_2440);
        }
      }
      default: return heff_nomatch(v_x1_2439);
      }
    }
    default: return heff_nomatch(v_x11_2428);
    }
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2erightsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Left: {
      heff_take_n(v_x11_242, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_rest_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf_24dps(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_k_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2420;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Left: {
      V v_it_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      heff_drop(v_k_244);
      v_t_2420 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_it_246, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Right: {
      V v_d_247 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24Right = heff_take_reuse_n(v_x2_245, 1ULL, 1);
      V v_name_248 = heff_take_field(v_d_247, 0);
      V v_span_249 = heff_take_field(v_d_247, 1);
      V v_ty_2410 = heff_take_field(v_d_247, 2);
      V v_whole_2411 = heff_get_n(v_d_247, 4, 5);
      V v_t_2412 = heff_tag_n(TAG_Sig, 5, (V[]){NTAG(TAG_AsDefinition), heff_dup(v_name_248), heff_dup(v_span_249), v_ty_2410, heff_dup(v_whole_2411)});
      V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x2_245_24Right, TAG_EVar, 1, (V[]){v_k_244}), heff_dup(v_span_249)});
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){heff_dup(v_name_248)}), heff_dup(v_span_249)});
      V v_t_2415 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      V v_t_2416 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, v_t_2415));
      V v_t_2417 = heff_tag_n(TAG_MkEquation, 4, (V[]){heff_dup(v_name_248), v_span_249, NTAG(TAG_Nil), v_t_2416});
      V v_t_2418 = heff_tag_n(TAG_Eqn, 3, (V[]){v_name_248, heff_tag_n(TAG_At, 2, (V[]){v_t_2417, heff_dup(v_whole_2411)}), v_whole_2411});
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2419});
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_2421 = (g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(v_lit_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2420, v_t_2421);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econcatMapS_24s166355990x533109119(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eanyS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eanyS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eanyS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eanyS(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str1, 28, "` is syntax, not an operator");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str3, 54, "` has no fixity to be above or below: declare it first");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str4, 31, "nothing can be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str5, 5, "`: it");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str7, 28, "` cannot be declared below `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str8, 4, "`: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str12, 2, " (");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str13, 1, ")");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str14, 83, " is the loosest operator, below every other, declared `below` with nothing after it");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str15, 54, "a fixity declaration names its operators: `infixl + -`");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str16, 15, "the fixity of `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str17, 19, "` is declared twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str18, 26, "these fixities go round: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2efixDiagsOf_str19, 22, "` ends up above itself");
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efixDiagsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixDiagsOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efixDiagsOf(V v_scope_240, V v_all_241, V v_d_242) {
top: ;
  V v_t_243 = (g_list_2emap_24f523576057x1362531023(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str0), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str1), heff_dup(heff_rfield(v_d_242, 1))));
  V v_t_244 = (g_heff_2esyntax_2esurface_2eappendS(heff_dup(heff_rfield(v_d_242, 2)), heff_dup(heff_rfield(v_d_242, 3))));
  V v_t_2412 = (g_list_2emap_24f2053285389x511622380(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str2), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str3), heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam0, 1, 1, (V[]){heff_dup(v_scope_240)}), v_t_244));
  V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam2, 1, 2, (V[]){v_scope_240, heff_dup(v_d_242)}), heff_dup(heff_rfield(v_d_242, 3))));
  V v_t_2440 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2439));
  V v_t_2441 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_d_242, 1)));
  V v_t_2443;
  if (heff_intEq_c(v_t_2441, MK_INT(0LL))) {
    V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str15), heff_dup(heff_rfield(v_d_242, 6)), NTAG(TAG_Nothing)});
    v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, NTAG(TAG_Nil)});
  } else {
    v_t_2443 = NTAG(TAG_Nil);
  }
  V v_all_2444 = v_all_241;
  V v_d_2445 = heff_dup(v_d_242);
  V v_ops_2446 = heff_take_field(v_d_2445, 1);
  V v_span_2447 = heff_get_n(v_d_2445, 6, 8);
  V v_t_2461;
  switch (heff_tag_of(v_ops_2446)) {
  case TAG_Nil: {
    heff_drop_rec(v_all_2444, 2);
    heff_drop(v_span_2447);
    v_t_2461 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_g_2448 = heff_dup(heff_field(v_ops_2446, 0));
    V v_t_2455 = (g_list_2emap_24f2053285389x511622380(MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str16), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str17), heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam4, 1, 2, (V[]){heff_dup(v_g_2448), heff_dup(v_all_2444)}), v_ops_2446));
    V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_g_2448, 1)), NTAG(TAG_Nil)});
    V v_t_2457 = (g_heff_2esyntax_2efixity_2etighterGo(v_all_2444, heff_dup(heff_rfield(v_g_2448, 1)), v_t_2456, NTAG(TAG_Nil)));
    V v_t_2460;
    if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
      heff_drop(v_t_2457);
      V v_t_2458 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str18), heff_get_n(v_g_2448, 1, 7));
      V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2458, ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str19)), v_span_2447, NTAG(TAG_Nothing)});
      v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_span_2447);
      heff_drop_rec(v_g_2448, 7);
      heff_drop(v_t_2457);
      v_t_2460 = NTAG(TAG_Nil);
    }
    v_t_2461 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2455, v_t_2460));
    break;
  }
  default: heff_nomatch(v_ops_2446);
  }
  V v_t_2462 = (g_heff_2esyntax_2esurface_2eappendS(heff_get_n(v_d_242, 5, 8), v_t_2461));
  V v_t_2463 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2443, v_t_2462));
  V v_t_2464 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2440, v_t_2463));
  V v_t_2465 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2412, v_t_2464));
  return (g_heff_2esyntax_2esurface_2eappendS(v_t_243, v_t_2465));
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixDiagsOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam1(V self, V *args) {
  V v_g_246 = args[0];
  V v_u_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_u_245, 1, 7)}));
  return ({ V a_0 = v_t_247; V b_1 = heff_get_n(v_g_246, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_scope_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_248 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam1, 1, 1, (V[]){v_u_245}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_249 == ((int64_t)0ULL)) ? ({ V v_x_2411 = heff_dup(v_field_2410); int c_ = 0; heff_drop(v_x_2411); c_; }) : 1));
    heff_drop(v_field_2410);
    return v_ret_24bool;
  }
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam3(V self, V *args) {
  V v_g_2414 = args[0];
  V v_u_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_u_2413, 1, 7)}));
  return ({ V a_0 = v_t_2415; V b_1 = heff_get_n(v_g_2414, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam2(V self, V *args) {
  V v_u_2413 = args[0];
  V v_scope_240 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam3, 1, 1, (V[]){heff_dup(v_u_2413)}); V b_1 = heff_get_n(v_scope_240, 0, 2); HeffT2 r_ = (g_heff_2esyntax_2efixity_2efindG_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_g_2419 = v_field_2418;
      V v_t_2420 = heff_dup(heff_rfield(v_g_2419, 3));
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_d_2421 = v_d_242;
        V v_u_2422 = v_u_2413;
        V v_start_2423 = heff_take_field(v_u_2422, 2);
        V v_end_2424 = heff_take_field(v_u_2422, 3);
        V v_text_2425 = heff_get_n(v_u_2422, 1, 7);
        V v_g_2426 = v_g_2419;
        V v_span_2427 = heff_rec_n(2, shape_start__end, (V[]){v_start_2423, v_end_2424});
        V v_t_2428 = heff_get_n(v_d_2421, 1, 8);
        V v_t_2434;
        switch (heff_tag_of(v_t_2428)) {
        case TAG_Nil: {
          v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str4), v_text_2425), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str5));
          break;
        }
        case TAG_Cons: {
          V v_op_2429 = heff_field(v_t_2428, 0);
          heff_take_n(v_t_2428, 1ULL, 2);
          V v_t_2431 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str6), heff_get_n(v_op_2429, 1, 7));
          V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str7)), heff_dup(v_text_2425));
          V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str8)), v_text_2425);
          v_t_2434 = heff_strAppend(v_t_2433, ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str9));
          break;
        }
        default: heff_nomatch(v_t_2428);
        }
        V v_at_2435 = heff_get_n(v_g_2426, 4, 5);
        V v_t_2436;
        if (heff_strEq_c_lent(v_at_2435, ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str10), 2)) {
          heff_drop(v_at_2435);
          v_t_2436 = ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str11);
        } else {
          v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str12), v_at_2435), ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str13));
        }
        V v_msg_2437 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2esyntax_2esurface_2efixDiagsOf_str14)), v_t_2436);
        V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2437, v_span_2427, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2438});
      } else {
        heff_drop_rec(v_u_2413, 7);
        heff_drop_rec(v_d_242, 8);
        heff_drop_rec(v_g_2419, 5);
        heff_drop(v_t_2420);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop_rec(v_u_2413, 7);
      heff_drop_rec(v_d_242, 8);
      heff_drop(v_field_2418);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam5(V self, V *args) {
  V v_h_2451 = args[0];
  V v_g_2448 = heff_env(self)[0];
  V v_u_2450 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_id_2452 = heff_take_field(v_h_2451, 0);
  V v_ops_2453 = heff_get_n(v_h_2451, 2, 5);
  if (!heff_strEq_c(heff_dup(v_id_2452), heff_dup(heff_rfield(v_g_2448, 1)))) {
    heff_drop_rec(v_g_2448, 7);
    heff_drop(v_id_2452);
    V v_t_2454 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_u_2450, 1, 7)}));
    return ({ V a_0 = v_t_2454; V a_1 = v_ops_2453; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_ops_2453); r_; });
  } else {
    heff_drop_rec(v_g_2448, 7);
    heff_drop_rec(v_u_2450, 7);
    heff_drop(v_id_2452);
    heff_drop(v_ops_2453);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2esurface_2efixDiagsOf_lam4(V self, V *args) {
  V v_u_2450 = args[0];
  V v_g_2448 = heff_env(self)[0];
  V v_all_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2efixDiagsOf_lam5, 1, 2, (V[]){v_g_2448, v_u_2450}); V b_1 = heff_get_n(v_all_2444, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2eanyS(a_0, b_1)); heff_drop(b_1); r_; });
}
Clo g_heff_2esyntax_2esurface_2eappendRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendRev_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendRev(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendRev(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry, 3, 0};

V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V v_tok_240, V v_e_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_At: {
    V v_e1_243 = heff_dup(heff_field(v_e_241, 0));
    switch (heff_tag_of(v_e1_243)) {
    case TAG_EAnn: {
      V v_g_245 = heff_field(v_e1_243, 0);
      V v_ru_24e1_243_24EAnn = heff_take_reuse_n(v_e1_243, 1ULL, 2);
      V v_g_247 = v_g_245;
      V v_t_2414;
      switch (heff_tag_of(v_g_247)) {
      case TAG_At: {
        V v_e1_248 = heff_dup(heff_field(v_g_247, 0));
        switch (heff_tag_of(v_e1_248)) {
        case TAG_EApp: {
          V v_h_2410 = heff_field(v_e1_248, 0);
          V v_xs_2411 = heff_field(v_e1_248, 1);
          heff_take_n(v_e1_248, 3ULL, 2);
          switch (heff_tag_of(v_g_247)) {
          case TAG_At: {
            v_t_2414 = heff_rec_n(2, shape_head__args, (V[]){v_h_2410, v_xs_2411});
            break;
          }
          default: heff_nomatch(v_g_247);
          }
          break;
        }
        default: {
          heff_drop(v_e1_248);
          v_t_2414 = heff_rec_n(2, shape_head__args, (V[]){heff_dup(v_g_247), NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_247);
      }
      V v_t_2415 = heff_get_n(v_t_2414, 0, 2);
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2esyntax_2esurface_2eidentOf(a_0)); heff_drop(v_t_2415); r_; });
      V v_t_2423;
      switch (heff_tag_of(v_g_247)) {
      case TAG_At: {
        V v_e1_2417 = heff_dup(heff_field(v_g_247, 0));
        switch (heff_tag_of(v_e1_2417)) {
        case TAG_EApp: {
          V v_h_2419 = heff_field(v_e1_2417, 0);
          V v_xs_2420 = heff_field(v_e1_2417, 1);
          heff_take_n(v_e1_2417, 3ULL, 2);
          switch (heff_tag_of(v_g_247)) {
          case TAG_At: {
            heff_take_n(v_g_247, 0ULL, 2);
            v_t_2423 = heff_rec_n(2, shape_head__args, (V[]){v_h_2419, v_xs_2420});
            break;
          }
          default: heff_nomatch(v_g_247);
          }
          break;
        }
        default: {
          heff_drop(v_e1_2417);
          v_t_2423 = heff_rec_n(2, shape_head__args, (V[]){v_g_247, NTAG(TAG_Nil)});
          break;
        }
        }
        break;
      }
      default: heff_nomatch(v_g_247);
      }
      V v_t_2424 = (g_list_2emap_24s878634257x1677201747(heff_get_n(v_t_2423, 1, 2)));
      V v_t_2425 = (g_heff_2esyntax_2esurface_2ecatMaybesS(heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_t_2416, v_t_2424})));
      V v_t_2426 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2425, heff_dup(heff_rfield(v_p_242, 1))));
      V v_st_2427 = (g_heff_2esyntax_2esurface_2esetScope(v_t_2426, v_p_242));
      return heff_tag_at_n(v_ru_24e1_243_24EAnn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_241}), v_st_2427});
    }
    default: {
      heff_drop(v_e1_243);
      return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_e_241}), v_p_242});
    }
    }
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2easBinderOn_24tok2(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V v_tok_240, V v_lit_241, V v_lit_242, V v_m_243, V v_st_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24cpr(v_lit_241, v_lit_242, v_m_243, v_st_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    return heff_tag_at_n(v_tok_240, TAG_MkPair, 2, (V[]){v_field_246, v_field_247});
  }
}
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(a[0], a[1], a[2], a[3], a[4]);
}