// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_decl 9574769
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_f 320
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_open 9913105
#define LBL_patVars 1587353522
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_toks 10061290
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2ealiasClash(V, V);
V g_heff_2esyntax_2esurface_2ealiasClash_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealiasClash_clo;
V g_heff_2esyntax_2esurface_2eappendRev(V, V);
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendRev_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eassembleDiagOne(V, V, V, V);
V g_heff_2esyntax_2esurface_2eassembleDiagOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleDiagOne_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2eeqnNames(V);
V g_heff_2esyntax_2esurface_2eeqnNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eeqnNames_clo;
V g_heff_2esyntax_2esurface_2efieldL(V, V);
V g_heff_2esyntax_2esurface_2efieldL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldL_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eipow10(V);
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eipow10_clo;
V g_heff_2esyntax_2esurface_2eisAnnE(V);
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisAnnE_clo;
V g_heff_2esyntax_2esurface_2eisSetting(V);
V g_heff_2esyntax_2esurface_2eisSetting_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisSetting_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_clo;
V g_heff_2esyntax_2esurface_2ereadRun(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereadRun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereadRun_clo;
V g_heff_2esyntax_2esurface_2esettingL(V, V);
V g_heff_2esyntax_2esurface_2esettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esettingL_clo;
V g_heff_2esyntax_2esurface_2esigNames(V);
V g_heff_2esyntax_2esurface_2esigNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNames_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2ewhereL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewhereL_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
Clo g_heff_2esyntax_2esurface_2eipow10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eipow10_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eipow10(V v_k_240) {
top: ;
  if (heff_intLe_c(heff_dup(v_k_240), MK_INT(0LL))) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2esyntax_2esurface_2eipow10(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(10LL), v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2eipow10_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eipow10(a[0]);
}
Clo g_heff_2esyntax_2esurface_2econcatMapS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econcatMapS_entry, 2, 0};

V g_heff_2esyntax_2esurface_2econcatMapS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2esyntax_2esurface_2econcatMapS(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2econcatMapS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2efoldr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efoldr_entry, 3, 0};

V g_heff_2esyntax_2esurface_2efoldr(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(g_heff_2esyntax_2esurface_2efoldr(heff_dup(v_f_240), v_z_241, v_xs_244));
    return heff_tail(v_f_240, 2, (V[]){heff_dup(v_x_243), v_t_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2efoldr(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2esurface_2eisAnnE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisAnnE_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisAnnE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EString: {
      return NTAG(TAG_False);
    }
    case TAG_EBinary: {
      return NTAG(TAG_False);
    }
    case TAG_ERune: {
      return NTAG(TAG_False);
    }
    case TAG_EWord: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_EProject: {
      return NTAG(TAG_False);
    }
    case TAG_ENamed: {
      return NTAG(TAG_False);
    }
    case TAG_EPi: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EAnn: {
      return NTAG(TAG_True);
    }
    case TAG_ESpec: {
      return NTAG(TAG_False);
    }
    case TAG_ESig: {
      return NTAG(TAG_False);
    }
    case TAG_ESum: {
      return NTAG(TAG_False);
    }
    case TAG_EStruct: {
      return NTAG(TAG_False);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_False);
    }
    case TAG_EDo: {
      return NTAG(TAG_False);
    }
    case TAG_ELocal: {
      return NTAG(TAG_False);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisAnnE_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisAnnE(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2econAtom_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2econAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2econAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2econAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  V v_t_244 = (g_list_2eany(v_t_243, heff_rfield(v_st_242, 1)));
  V v_x1_245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_244}), v_st_242});
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_fs_241);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2414;
      switch (heff_tag_of(v_fs_241)) {
      case TAG_Nil: {
        v_t_2414 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_f_2410 = heff_dup(heff_field(v_fs_241, 0));
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2econAtom_str0), heff_get_n(v_f_2410, 1, 9));
        V v_t_2413 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), v_t_2412);
        v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_247, 2)), 1, (V[]){v_t_2413}));
        break;
      }
      default: heff_nomatch(v_fs_241);
      }
      V v_x1_2415 = heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2414}), v_st_247});
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkPair: {
        V v_x11_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
        switch (heff_tag_of(v_x11_2416)) {
        case TAG_Left: {
          V v_e_2418 = heff_field(v_x11_2416, 0);
          heff_take_n(v_x11_2416, 1ULL, 1);
          heff_drop_rec(v_t_240, 9);
          heff_drop(v_fs_241);
          heff_drop(v_x_249);
          heff_drop_cell(v_ru_24x11_246_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
        }
        case TAG_Right: {
          V v_x_2419 = heff_field(v_x11_2416, 0);
          V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 1ULL, 1);
          V v_t_2420;
          if ((heff_dup(v_x_249) == NTAG(TAG_True))) {
            v_t_2420 = NTAG(TAG_True);
          } else {
            v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_2417, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
          }
          V v_x1_2421 = heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_t_2420}), v_st_2417});
          switch (heff_tag_of(v_x1_2421)) {
          case TAG_MkPair: {
            V v_x11_2422 = heff_field(v_x1_2421, 0);
            V v_st_2423 = heff_field(v_x1_2421, 1);
            V v_ru_24x1_2421_24MkPair = heff_take_reuse_n(v_x1_2421, 3ULL, 2);
            switch (heff_tag_of(v_x11_2422)) {
            case TAG_Left: {
              V v_e_2424 = heff_field(v_x11_2422, 0);
              heff_take_n(v_x11_2422, 1ULL, 1);
              heff_drop_rec(v_t_240, 9);
              heff_drop(v_fs_241);
              heff_drop(v_x_249);
              heff_drop(v_x_2419);
              heff_drop_cell(v_ru_24x11_2416_24Right, 1);
              return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2424}), v_st_2423});
            }
            case TAG_Right: {
              V v_x_2425 = heff_field(v_x11_2422, 0);
              V v_ru_24x11_2422_24Right = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
              V v_t_2426;
              if ((heff_dup(v_x_2419) == NTAG(TAG_True))) {
                v_t_2426 = v_x_249;
              } else {
                heff_drop(v_x_249);
                v_t_2426 = NTAG(TAG_False);
              }
              if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
                heff_drop(v_x_2419);
                heff_drop_cell(v_ru_24x11_2416_24Right, 1);
                heff_drop(v_x_2425);
                heff_drop_cell(v_ru_24x11_2422_24Right, 1);
                heff_drop(v_t_2426);
                V v_d_2427 = ({ V a_0 = v_t_240; V a_1 = v_fs_241; V r_ = (g_heff_2esyntax_2esurface_2ealiasClash(a_0, a_1)); heff_drop(v_fs_241); r_; });
                return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2427}), v_st_2423});
              } else {
                heff_drop(v_t_2426);
                V v_x_2434;
                if ((heff_dup(v_x_2419) == NTAG(TAG_True))) {
                  heff_drop(v_x_2419);
                  heff_drop(v_x_2425);
                  heff_drop_cell(v_ru_24x11_2422_24Right, 1);
                  v_x_2434 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_240, v_fs_241));
                } else {
                  heff_drop(v_x_2419);
                  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
                    heff_drop(v_x_2425);
                    V v_t_2428 = heff_tag_at_n(v_ru_24x11_2422_24Right, TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))});
                    V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2430 = (g_list_2emap_24s513201124x806973253(v_fs_241));
                    v_x_2434 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2428, v_t_2429}), v_t_2430));
                  } else {
                    heff_drop(v_x_2425);
                    V v_t_2431 = heff_tag_at_n(v_ru_24x11_2422_24Right, TAG_ETag, 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))});
                    V v_t_2432 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2433 = (g_list_2emap_24s513201124x806973253(v_fs_241));
                    v_x_2434 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2431, v_t_2432}), v_t_2433));
                  }
                }
                return heff_tag_at_n(v_ru_24x1_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_Right, 1, (V[]){v_x_2434}), v_st_2423});
              }
            }
            default: return heff_nomatch(v_x11_2422);
            }
          }
          default: return heff_nomatch(v_x1_2421);
          }
        }
        default: return heff_nomatch(v_x11_2416);
        }
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2econAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2ebracesL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracesL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ebracesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracesL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ebracesL(V v_r_240, V v_o_241, V v_fs_242, V v_c_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_fs_242)) {
  case TAG_Nil: {
    heff_drop(v_r_240);
    V v_t_245 = heff_tag_n(TAG_EStruct, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_246 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
    V v_t_247 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_t_246})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_z_244});
  }
  case TAG_Cons: {
    V v_f_248 = heff_dup(heff_field(v_fs_242, 0));
    V v_t_2410 = ({ V a_0 = v_f_248; V r_ = (g_heff_2esyntax_2esurface_2eisSetting(a_0)); heff_drop(v_f_248); r_; });
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V v_m_2412 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam0, 1, 1, (V[]){v_r_240}), v_fs_242));
      V v_x1_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkPair: {
        V v_x11_2414 = heff_field(v_x1_2413, 0);
        V v_st_2415 = heff_field(v_x1_2413, 1);
        V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
        switch (heff_tag_of(v_x11_2414)) {
        case TAG_Left: {
          V v_e_2416 = heff_field(v_x11_2414, 0);
          heff_take_n(v_x11_2414, 1ULL, 1);
          heff_drop_rec(v_o_241, 9);
          heff_drop_rec(v_c_243, 9);
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
        }
        case TAG_Right: {
          V v_x_2417 = heff_field(v_x11_2414, 0);
          V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
          V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
          V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_EStruct, 1, (V[]){v_x_2417}), v_t_2418});
          return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2419}), v_st_2415});
        }
        default: return heff_nomatch(v_x11_2414);
        }
      }
      default: return heff_nomatch(v_x1_2413);
      }
    } else {
      heff_drop(v_t_2410);
      V v_m_2421 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2ebracesL_lam1, 1, 1, (V[]){v_r_240}), v_fs_242));
      V v_x1_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_MkPair: {
        V v_x11_2423 = heff_field(v_x1_2422, 0);
        V v_st_2424 = heff_field(v_x1_2422, 1);
        V v_ru_24x1_2422_24MkPair = heff_take_reuse_n(v_x1_2422, 3ULL, 2);
        switch (heff_tag_of(v_x11_2423)) {
        case TAG_Left: {
          V v_e_2425 = heff_field(v_x11_2423, 0);
          heff_take_n(v_x11_2423, 1ULL, 1);
          heff_drop_rec(v_o_241, 9);
          heff_drop_rec(v_c_243, 9);
          return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2425}), v_st_2424});
        }
        case TAG_Right: {
          V v_x_2426 = heff_field(v_x11_2423, 0);
          V v_ru_24x11_2423_24Right = heff_take_reuse_n(v_x11_2423, 1ULL, 1);
          V v_t_2427 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241, 3, 9), heff_get_n(v_c_243, 4, 9)});
          V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2423_24Right, TAG_ESig, 1, (V[]){v_x_2426}), v_t_2427});
          return heff_tag_at_n(v_ru_24x1_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2428}), v_st_2424});
        }
        default: return heff_nomatch(v_x11_2423);
        }
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
  }
  default: return heff_nomatch(v_fs_242);
  }
}
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebracesL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ebracesL_lam0(V self, V *args) {
  V v_m_2411 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esettingL(v_r_240, v_m_2411));
}
V g_heff_2esyntax_2esurface_2ebracesL_lam1(V self, V *args) {
  V v_m_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2efieldL(v_r_240, v_m_2420));
}
Clo g_heff_2esyntax_2esurface_2eaddBinders_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eaddBinders_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eaddBinders(V v_b_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_b_240, 0)), heff_rfield(v_s_241, 3)));
  V v_t_244;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nothing: {
    v_t_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_x2_242, 0);
    heff_take_n(v_x2_242, 1ULL, 1);
    v_t_244 = v_x_243;
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_b_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_b_240, 0)), heff_tag_n(TAG_Cons, 2, (V[]){v_b_240, v_t_244}), heff_take_field(v_s_241, 3)));
  return ({ V rv_3 = v_b_245; V rr_ = heff_rec_reuse_nf(v_s_241, 247ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
}
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eaddBinders(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ewhereL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ewhereL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewhereL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2ewhereL(V v_r_240, V v_kw_241, V v_ds_242, V v_rhs_243, V v_st_244) {
top: ;
  V v_x1_245 = (g_heff_2esyntax_2esurface_2eblock(heff_get_n(v_r_240, 2, 3), heff_dup(v_ds_242), heff_dup(v_st_244)));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_ds_242);
      heff_drop(v_rhs_243);
      heff_drop_rec(v_st_244, 8);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_st_2410 = ({ V rv_3 = heff_get_n(v_st_244, 3, 8); V rr_ = heff_rec_reuse_nf(v_st_247, 247ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65343u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      V v_items_2411 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_249));
      V v_t_2412 = heff_rec_n(4, shape_seen__prims__open__diags, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
      V v_d_2416 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ewhereL_lam0, 2, 1, (V[]){heff_dup(v_st_2410)}); V a_1 = v_t_2412; V a_2 = v_items_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_items_2411); r_; });
      V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_d_2416, 3, 4)));
      V v_items_2418 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(v_x_249));
      V v_t_2419 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
      V v_t_2420 = (g_heff_2esyntax_2esurface_2esigNames(v_items_2418));
      V v_t_2421 = (g_heff_2esyntax_2esurface_2eeqnNames(v_items_2418));
      V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eassembleDiagOne_clo), 3, (V[]){v_t_2419, v_t_2420, v_t_2421}));
      V v_t_2423 = (g_list_2emap(v_t_2422, v_items_2418));
      V v_t_2424 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_2423));
      V v_t_2425 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2417, v_t_2424));
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nil: {
        V v_items_2426 = ({ V a_0 = v_x_249; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_249); r_; });
        V v_t_2427 = ({ V b_0 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2enameSet(b_0)); heff_drop(b_0); r_; });
        V v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_items_2426; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2eassembleGo(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
        V v_x1_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ds_242));
        V v_b_2433;
        switch (heff_tag_of(v_x1_2429)) {
        case TAG_Nil: {
          v_b_2433 = heff_get_n(v_kw_241, 4, 9);
          break;
        }
        case TAG_Cons: {
          V v_x_2430 = heff_field(v_x1_2429, 0);
          heff_take_n(v_x1_2429, 1ULL, 2);
          heff_drop_rec(v_kw_241, 9);
          V v_t_2432 = (g_heff_2esyntax_2ecst_2elastD(v_x_2430));
          v_b_2433 = heff_get_n(v_t_2432, 4, 9);
          break;
        }
        default: heff_nomatch(v_x1_2429);
        }
        V v_t_2436;
        switch (heff_tag_of(v_rhs_243)) {
        case TAG_At: {
          V v_s_2435 = heff_dup(heff_field(v_rhs_243, 1));
          v_t_2436 = v_s_2435;
          break;
        }
        default: heff_nomatch(v_rhs_243);
        }
        V v_t_2437 = ({ V rv_1 = v_b_2433; V rr_ = heff_rec_reuse_nf(v_t_2436, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELocal, 2, (V[]){v_rhs_243, v_t_2428}), v_t_2437});
        return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2438}), v_st_2410});
      }
      case TAG_Cons: {
        V v_d_2439 = heff_field(v_t_2425, 0);
        heff_take_n(v_t_2425, 1ULL, 2);
        heff_drop_rec(v_kw_241, 9);
        heff_drop(v_ds_242);
        heff_drop(v_rhs_243);
        heff_drop(v_x_249);
        return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_d_2439}), v_st_2410});
      }
      default: return heff_nomatch(v_t_2425);
      }
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2ewhereL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ewhereL(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2esyntax_2esurface_2ewhereL_lam0(V self, V *args) {
  V v_d_2413 = args[0];
  V v_it_2414 = args[1];
  V v_st_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = (g_heff_2esyntax_2esurface_2edefinesOf(heff_dup(heff_rfield(v_d_2413, 2)), v_it_2414));
  return ({ V a_0 = heff_get_n(v_st_2410, 7, 8); V a_1 = v_d_2413; V a_2 = v_t_2415; V r_ = (g_heff_2esyntax_2esurface_2edefinedStep(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
}
Clo g_heff_2esyntax_2esurface_2eappendRev_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendRev_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eappendRev(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V t_0 = v_xs_243;
    V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_acc_241});
    v_x1_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendRev(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry, 4, 0};

V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(V v_lit_240, V v_lit_241, V v_src_242, V v_l_243) {
top: ;
  V v_ltoks_244 = heff_arrayFromList(heff_dup(heff_rfield(v_l_243, 0)));
  V v_t_245 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), heff_take_field(v_l_243, 0)));
  V v_toks_246 = heff_arrayFromList(v_t_245);
  V v_lexDiags_247 = (g_list_2emap_24s338694954x1326523169(heff_get_n(v_l_243, 1, 3)));
  V v_t_248 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_True), heff_dup(v_lit_240), v_lit_241});
  V v_t_249 = (g_heff_2esyntax_2esurface_2eprescanGo(heff_dup(v_ltoks_244), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2410 = (g_heff_2esyntax_2esurface_2efixDecls(v_ltoks_244, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(v_lit_240, v_t_2410));
  return ({ V a_0 = v_src_242; V a_1 = v_t_248; V a_2 = v_toks_246; V a_3 = v_lexDiags_247; V a_4 = v_t_249; V a_5 = v_t_2411; V r_ = (g_heff_2esyntax_2esurface_2ereadRun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_249); r_; });
}
V g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642(a[0], a[1], a[2], a[3]);
}