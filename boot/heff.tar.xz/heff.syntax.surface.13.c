// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Passes 47566
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sig 30557
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_f 320
#define LBL_fix 310927
#define LBL_i 323
#define LBL_implicits 1321238867
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_f__names__implicits[] = {LBL_f, LBL_names, LBL_implicits};
static uint32_t shape_items__diags__broken[] = {LBL_items, LBL_diags, LBL_broken};
static uint32_t shape_name__span__ty[] = {LBL_name, LBL_span, LBL_ty};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
V g_heff_2esyntax_2ecst_2edeclStep(V);
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclStep_clo;
V g_heff_2esyntax_2ecst_2edeclaredAt(V);
V g_heff_2esyntax_2ecst_2edeclaredAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclaredAt_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2ecst_2eskipFrom(V);
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipFrom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2esurface_2eaddBinders(V, V);
V g_heff_2esyntax_2esurface_2eaddBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eaddBinders_clo;
V g_heff_2esyntax_2esurface_2eappendRev(V, V);
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendRev_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_clo;
V g_heff_2esyntax_2esurface_2earrowAfter(V, V);
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowAfter_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(V, V);
V g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2eisSetting(V);
V g_heff_2esyntax_2esurface_2eisSetting_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisSetting_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameAnn(V);
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameAnn_clo;
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epiBinders(V);
V g_heff_2esyntax_2esurface_2epiBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiBinders_clo;
V g_heff_2esyntax_2esurface_2epiImplicits(V);
V g_heff_2esyntax_2esurface_2epiImplicits_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epiImplicits_clo;
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_clo;
V g_heff_2esyntax_2esurface_2esymAtom(V);
V g_heff_2esyntax_2esurface_2esymAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esymAtom_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str0, 22, "` is first defined at ");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str1, 1, "`");
Clo g_heff_2esyntax_2esurface_2edefinedStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinedStep_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefinedStep(V v_at_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Names: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_next_245 = heff_field(v_x3_242, 2);
    V v_msg_246 = heff_field(v_x3_242, 3);
    V v_prim_247 = heff_field(v_x3_242, 4);
    V v_seen_248 = heff_dup(heff_rfield(v_d_241, 0));
    V v_x3_249 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), v_seen_248));
    V v_t_2411;
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_t_2411 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), heff_dup(v_sp_244), v_seen_248));
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_249, 0ULL, 1);
      v_t_2411 = v_seen_248;
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    V v_prims_2412 = heff_dup(heff_rfield(v_d_241, 1));
    V v_t_2413;
    if ((heff_dup(v_prim_247) == NTAG(TAG_True))) {
      v_t_2413 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_243), NTAG(TAG_MkUnit), v_prims_2412));
    } else {
      v_t_2413 = v_prims_2412;
    }
    V v_x5_2416;
    if ((heff_dup(v_prim_247) == NTAG(TAG_True))) {
      V v_x3_2414 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), heff_rfield(v_d_241, 1)));
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_Nothing: {
        v_x5_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_d_241, 0)));
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x3_2414, 0ULL, 1);
        v_x5_2416 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x3_2414);
      }
    } else {
      v_x5_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_d_241, 0)));
    }
    V v_diags_2417 = heff_get_n(v_d_241, 3, 4);
    V v_t_2423;
    switch (heff_tag_of(v_x5_2416)) {
    case TAG_Nothing: {
      heff_drop(v_at_240);
      v_t_2423 = v_diags_2417;
      break;
    }
    case TAG_Just: {
      V v_first_2418 = heff_field(v_x5_2416, 0);
      V v_ru_24x5_2416_24Just = heff_take_reuse_n(v_x5_2416, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(v_at_240, 1, (V[]){heff_get_n(v_first_2418, 0, 2)}));
      V v_t_2420 = heff_strAppend(heff_dup(v_x_243), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str0), v_t_2419));
      V v_t_2421 = heff_tag_at_n(v_ru_24x5_2416_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str1), v_t_2420)});
      V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(153LL), NTAG(TAG_SError), heff_dup(v_msg_246), heff_dup(v_sp_244), v_t_2421});
      v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_diags_2417});
      break;
    }
    default: heff_nomatch(v_x5_2416);
    }
    return heff_rec_n(4, shape_seen__prims__open__diags, (V[]){v_t_2411, v_t_2413, heff_dup(v_next_245), v_t_2423});
  }
  case TAG_Passes: {
    heff_drop(v_at_240);
    return v_d_241;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2edefinedStep(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldDeclOf(V v_e_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_247;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_246 = heff_dup(heff_field(v_e_240, 1));
        v_t_247 = v_s_246;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_247});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2411;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_e_240, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2411});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2415;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2414 = heff_dup(heff_field(v_e_240, 1));
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2415});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2419;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_e_240, 1));
        v_t_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2419});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2423;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_e_240, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2423});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2427;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2426 = heff_dup(heff_field(v_e_240, 1));
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2427});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2431;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2430 = heff_dup(heff_field(v_e_240, 1));
        v_t_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2431});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2435;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2434 = heff_dup(heff_field(v_e_240, 1));
        v_t_2435 = v_s_2434;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2435});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2439;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2438 = heff_dup(heff_field(v_e_240, 1));
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2439});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2444;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2443 = heff_dup(heff_field(v_e_240, 1));
        v_t_2444 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2444});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2448;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2447 = heff_dup(heff_field(v_e_240, 1));
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2448});
    }
    case TAG_ENamed: {
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2453;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_e_240, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2453});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2458;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2457 = heff_dup(heff_field(v_e_240, 1));
        v_t_2458 = v_s_2457;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2458});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2463;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2462 = heff_dup(heff_field(v_e_240, 1));
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2463});
    }
    case TAG_EAnn: {
      V v_e11_2464 = heff_field(v_e1_242, 0);
      V v_t_2465 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e11_2464)) {
      case TAG_At: {
        V v_e111_2466 = heff_field(v_e11_2464, 0);
        V v_xsp_2467 = heff_field(v_e11_2464, 1);
        heff_take_n(v_e11_2464, 3ULL, 2);
        switch (heff_tag_of(v_e111_2466)) {
        case TAG_EVar: {
          V v_x_2468 = heff_field(v_e111_2466, 0);
          heff_take_n(v_e111_2466, 1ULL, 1);
          heff_drop_tag(v_e_240, 2);
          V v_t_2473;
          switch (heff_tag_of(v_d_241)) {
          case TAG_Nothing: {
            v_t_2473 = v_sp_243;
            break;
          }
          case TAG_Just: {
            V v_d_2469 = heff_dup(heff_field(v_d_241, 0));
            V v_t_2472;
            switch (heff_tag_of(v_d_2469)) {
            case TAG_At: {
              V v_s_2471 = heff_field(v_d_2469, 1);
              heff_take_n(v_d_2469, 2ULL, 2);
              v_t_2472 = v_s_2471;
              break;
            }
            default: heff_nomatch(v_d_2469);
            }
            v_t_2473 = ({ V rv_1 = heff_get_n(v_t_2472, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          default: heff_nomatch(v_d_241);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclareField, 4, (V[]){v_x_2468, v_xsp_2467, v_t_2465, v_d_241}), v_t_2473});
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2477;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2476 = heff_dup(heff_field(v_e_240, 1));
            v_t_2477 = v_s_2476;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2477});
        }
        case TAG_ETag: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2481;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2480 = heff_dup(heff_field(v_e_240, 1));
            v_t_2481 = v_s_2480;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2481});
        }
        case TAG_EInt: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2485;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2484 = heff_dup(heff_field(v_e_240, 1));
            v_t_2485 = v_s_2484;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2485});
        }
        case TAG_EFloat: {
          heff_take_na(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2489;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2488 = heff_dup(heff_field(v_e_240, 1));
            v_t_2489 = v_s_2488;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2489});
        }
        case TAG_EString: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2493;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2492 = heff_dup(heff_field(v_e_240, 1));
            v_t_2493 = v_s_2492;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2493});
        }
        case TAG_EBinary: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2497;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2496 = heff_dup(heff_field(v_e_240, 1));
            v_t_2497 = v_s_2496;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2497});
        }
        case TAG_ERune: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24101;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24100 = heff_dup(heff_field(v_e_240, 1));
            v_t_24101 = v_s_24100;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24101});
        }
        case TAG_EWord: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24105;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24104 = heff_dup(heff_field(v_e_240, 1));
            v_t_24105 = v_s_24104;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24105});
        }
        case TAG_EApp: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24110;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24109 = heff_dup(heff_field(v_e_240, 1));
            v_t_24110 = v_s_24109;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24110});
        }
        case TAG_EProject: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24114;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24113 = heff_dup(heff_field(v_e_240, 1));
            v_t_24114 = v_s_24113;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24114});
        }
        case TAG_ENamed: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24119;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24118 = heff_dup(heff_field(v_e_240, 1));
            v_t_24119 = v_s_24118;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24119});
        }
        case TAG_EPi: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24124;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24123 = heff_dup(heff_field(v_e_240, 1));
            v_t_24124 = v_s_24123;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24124});
        }
        case TAG_ELam: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24129;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24128 = heff_dup(heff_field(v_e_240, 1));
            v_t_24129 = v_s_24128;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24129});
        }
        case TAG_EAnn: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24134;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24133 = heff_dup(heff_field(v_e_240, 1));
            v_t_24134 = v_s_24133;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24134});
        }
        case TAG_ESpec: {
          heff_take_n(v_e111_2466, 0ULL, 4);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24141;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24140 = heff_dup(heff_field(v_e_240, 1));
            v_t_24141 = v_s_24140;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24141});
        }
        case TAG_ESig: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24145;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24144 = heff_dup(heff_field(v_e_240, 1));
            v_t_24145 = v_s_24144;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24145});
        }
        case TAG_ESum: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24149;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24148 = heff_dup(heff_field(v_e_240, 1));
            v_t_24149 = v_s_24148;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24149});
        }
        case TAG_EStruct: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24153;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24152 = heff_dup(heff_field(v_e_240, 1));
            v_t_24153 = v_s_24152;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24153});
        }
        case TAG_EUpdate: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24158;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24157 = heff_dup(heff_field(v_e_240, 1));
            v_t_24158 = v_s_24157;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24158});
        }
        case TAG_EMatch: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24163;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24162 = heff_dup(heff_field(v_e_240, 1));
            v_t_24163 = v_s_24162;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24163});
        }
        case TAG_ELetIn: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24168;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24167 = heff_dup(heff_field(v_e_240, 1));
            v_t_24168 = v_s_24167;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24168});
        }
        case TAG_EDo: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24172;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24171 = heff_dup(heff_field(v_e_240, 1));
            v_t_24172 = v_s_24171;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24172});
        }
        case TAG_ELocal: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24177;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24176 = heff_dup(heff_field(v_e_240, 1));
            v_t_24177 = v_s_24176;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24177});
        }
        case TAG_EInvalid: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24181;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24180 = heff_dup(heff_field(v_e_240, 1));
            v_t_24181 = v_s_24180;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24181});
        }
        default: return heff_nomatch(v_e111_2466);
        }
      }
      default: return heff_nomatch(v_e11_2464);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24188;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24187 = heff_dup(heff_field(v_e_240, 1));
        v_t_24188 = v_s_24187;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24188});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24192;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24191 = heff_dup(heff_field(v_e_240, 1));
        v_t_24192 = v_s_24191;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24192});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24196;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24195 = heff_dup(heff_field(v_e_240, 1));
        v_t_24196 = v_s_24195;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24196});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24200;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24199 = heff_dup(heff_field(v_e_240, 1));
        v_t_24200 = v_s_24199;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24200});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_242_24EUpdate = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24205;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24204 = heff_dup(heff_field(v_e_240, 1));
        v_t_24205 = v_s_24204;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24205});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24210;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24209 = heff_dup(heff_field(v_e_240, 1));
        v_t_24210 = v_s_24209;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24210});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24215;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24214 = heff_dup(heff_field(v_e_240, 1));
        v_t_24215 = v_s_24214;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24215});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24219;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24218 = heff_dup(heff_field(v_e_240, 1));
        v_t_24219 = v_s_24218;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24219});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24224;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24223 = heff_dup(heff_field(v_e_240, 1));
        v_t_24224 = v_s_24223;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24224});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24228;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24227 = heff_dup(heff_field(v_e_240, 1));
        v_t_24228 = v_s_24227;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24228});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eisSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisSetting_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisSetting(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2eisSetting_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisSetting(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eparenL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparenL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eparenL(V v_r_240, V v_o_241, V v_e_242, V v_c_243, V v_z_244) {
top: ;
  V v_t_245 = (g_heff_2esyntax_2esurface_2esymAtom(heff_dup(v_e_242)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_242}));
    V v_x1_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_x11_248 = heff_field(v_x1_247, 0);
      V v_st_249 = heff_field(v_x1_247, 1);
      V v_ru_24x1_247_24MkPair = heff_take_reuse_n(v_x1_247, 3ULL, 2);
      switch (heff_tag_of(v_x11_248)) {
      case TAG_Left: {
        V v_e_2410 = heff_field(v_x11_248, 0);
        heff_take_n(v_x11_248, 1ULL, 1);
        heff_drop(v_c_243);
        return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2410}), v_st_249});
      }
      case TAG_Right: {
        V v_x_2411 = heff_field(v_x11_248, 0);
        heff_take_n(v_x11_248, 1ULL, 1);
        V v_t_2412 = (g_heff_2esyntax_2esurface_2earrowAfter(heff_dup(v_st_249), v_c_243));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x1_247_24MkPair, 2);
          heff_drop(v_t_2412);
          V v_t_2413 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2411));
          return (g_heff_2esyntax_2esurface_2easBinderOn(v_t_2413, v_st_249));
        } else {
          heff_drop(v_t_2412);
          return heff_tag_at_n(v_ru_24x1_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2411}), v_st_249});
        }
      }
      default: return heff_nomatch(v_x11_248);
      }
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  case TAG_Just: {
    V v_t_2414 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    heff_drop(v_e_242);
    heff_drop(v_c_243);
    V v_t_2415 = heff_tag_at_n(v_ru_24t_245_24Just, TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_t_2414, 1))});
    V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2414, 3), heff_get_n(v_t_2414, 4, 9)});
    V v_t_2417 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2415, v_t_2416})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_z_244});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eparenL(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2esyntax_2esurface_2enameAnn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameAnn_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameAnn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EString: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EAnn: {
      V v_x111_2421 = heff_field(v_x11_241, 0);
      V v_t_2422 = heff_field(v_x11_241, 1);
      switch (heff_tag_of(v_x111_2421)) {
      case TAG_At: {
        V v_x1111_2423 = heff_field(v_x111_2421, 0);
        V v_xsp_2424 = heff_field(v_x111_2421, 1);
        switch (heff_tag_of(v_x1111_2423)) {
        case TAG_EVar: {
          V v_x_2425 = heff_field(v_x1111_2423, 0);
          return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(3, shape_name__span__ty, (V[]){heff_dup(v_x_2425), heff_dup(v_xsp_2424), heff_dup(v_t_2422)})});
        }
        case TAG_EImplicitVar: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ETag: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EInt: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EFloat: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EString: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EBinary: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ERune: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EWord: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EApp: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EProject: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ENamed: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EPi: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ELam: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EAnn: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ESpec: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ESig: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ESum: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EStruct: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EUpdate: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EMatch: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ELetIn: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EDo: {
          return NTAG(TAG_Nothing);
        }
        case TAG_ELocal: {
          return NTAG(TAG_Nothing);
        }
        case TAG_EInvalid: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x1111_2423);
        }
      }
      default: return heff_nomatch(v_x111_2421);
      }
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ESum: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nothing);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2enameAnn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enameAnn(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(V v_declared_240, V v_start_241, V v_names_242, V v_ty_243, V v_st_244) {
top: ;
  V v_x1_245 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_ty_243), v_st_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      heff_drop(v_declared_240);
      heff_drop(v_start_241);
      heff_drop(v_ty_243);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_242));
      V v_f_2411 = heff_get_n(v_t_2410, 0, 2);
      V v_names_2412 = (g_heff_2esyntax_2esurface_2epiBinders(heff_dup(v_x_249)));
      V v_implicits_2413 = (g_heff_2esyntax_2esurface_2epiImplicits(heff_dup(v_x_249)));
      V v_t_2414 = (g_heff_2esyntax_2esurface_2eaddBinders(heff_rec_n(3, shape_f__names__implicits, (V[]){v_f_2411, v_names_2412, v_implicits_2413}), v_st_247));
      V v_t_2415 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_242));
      V v_t_2416 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_names_242));
      V v_t_2417 = (g_heff_2esyntax_2ecst_2elastE(v_ty_243));
      V v_b_2418 = heff_get_n(v_t_2417, 4, 9);
      V v_t_2419 = heff_tag_n(TAG_Sig, 5, (V[]){v_declared_240, heff_get_n(v_t_2415, 0, 2), heff_get_n(v_t_2416, 1, 2), v_x_249, heff_rec_n(2, shape_start__end, (V[]){v_start_241, v_b_2418})});
      V v_x_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2420}), v_t_2414});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2esigL_24s1657255458x1148554620(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str3, 12, "unexpected `");
Clo g_heff_2esyntax_2esurface_2eprogGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprogGo_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eprogGo(V v_cs_240, V v_s_241, V v_items_242, V v_diags_243, V v_broken_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_246 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs_240, 0)), heff_dup(heff_rfield(v_cs_240, 1)), heff_dup(heff_rfield(v_cs_240, 1)), v_t_245, heff_dup(heff_rfield(v_cs_240, 1))});
  V v_t_247 = (g_heff_2esyntax_2ecst_2etokAt(v_t_246, heff_dup(heff_rfield(v_cs_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_247, 0, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str0))) {
    heff_drop_rec(v_cs_240, 5);
    heff_drop_rec(v_s_241, 8);
    V v_items_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_diags_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_diags_243));
    V v_broken_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_broken_244));
    return heff_rec_n(3, shape_items__diags__broken, (V[]){v_items_249, v_diags_2410, v_broken_2411});
  } else {
    V v_it_2412 = heff_tr(g_heff_2esyntax_2ecst_2edeclStep(v_cs_240));
    switch (heff_tag_of(v_it_2412)) {
    case TAG_MkPair: {
      V v_it1_2413 = heff_field(v_it_2412, 0);
      V v_cs2_2414 = heff_field(v_it_2412, 1);
      V v_ru_24it_2412_24MkPair = heff_take_reuse_n(v_it_2412, 3ULL, 2);
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_Left: {
        V v_d_2415 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        V v_t_2416 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
        V v_t_2418;
        if (heff_intLt_c(heff_dup(heff_rfield(v_cs2_2414, 1)), v_t_2416)) {
          v_t_2418 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
        } else {
          v_t_2418 = heff_dup(heff_rfield(v_cs2_2414, 1));
        }
        V v_t_2419 = heff_tag_at_n(v_ru_24it_2412_24MkPair, TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        V v_t_2420 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs2_2414, 0)), v_t_2418, heff_dup(heff_rfield(v_cs2_2414, 2)), v_t_2419, heff_dup(heff_rfield(v_cs2_2414, 4))});
        V v_t_2421 = (g_heff_2esyntax_2ecst_2eskipFrom(v_t_2420));
        V v_x1_2422 = (g_heff_2esyntax_2ecst_2edeclaredAt(v_cs2_2414));
        V v_t_2424;
        switch (heff_tag_of(v_x1_2422)) {
        case TAG_Nothing: {
          v_t_2424 = v_broken_244;
          break;
        }
        case TAG_Just: {
          V v_x_2423 = heff_field(v_x1_2422, 0);
          heff_take_n(v_x1_2422, 1ULL, 1);
          v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, v_broken_244});
          break;
        }
        default: heff_nomatch(v_x1_2422);
        }
        V t_0 = v_t_2421;
        V t_1 = v_s_241;
        V t_2 = v_items_242;
        V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2415, v_diags_243});
        V t_4 = v_t_2424;
        v_cs_240 = t_0;
        v_s_241 = t_1;
        v_items_242 = t_2;
        v_diags_243 = t_3;
        v_broken_244 = t_4;
        goto top;
      }
      case TAG_Right: {
        V v_dc_2425 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        V v_t_2426 = ({ V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_s_241, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_it_2427 = (g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903(v_dc_2425, v_t_2426));
        switch (heff_tag_of(v_it_2427)) {
        case TAG_MkPair: {
          V v_it1_2428 = heff_field(v_it_2427, 0);
          V v_s2_2429 = heff_field(v_it_2427, 1);
          V v_ru_24it_2427_24MkPair = heff_take_reuse_n(v_it_2427, 3ULL, 2);
          switch (heff_tag_of(v_it1_2428)) {
          case TAG_Left: {
            V v_d_2430 = heff_field(v_it1_2428, 0);
            heff_take_n(v_it1_2428, 1ULL, 1);
            V v_t_2431 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
            V v_t_2433;
            if (heff_intLt_c(heff_dup(heff_rfield(v_cs2_2414, 1)), v_t_2431)) {
              v_t_2433 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
            } else {
              v_t_2433 = heff_dup(heff_rfield(v_cs2_2414, 1));
            }
            V v_t_2434 = heff_tag_at_n(v_ru_24it_2412_24MkPair, TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2435 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs2_2414, 0)), v_t_2433, heff_dup(heff_rfield(v_cs2_2414, 2)), v_t_2434, heff_dup(heff_rfield(v_cs2_2414, 4))});
            V v_t_2436 = (g_heff_2esyntax_2ecst_2eskipFrom(v_t_2435));
            V v_x1_2437 = (g_heff_2esyntax_2ecst_2edeclaredAt(v_cs2_2414));
            V v_t_2439;
            switch (heff_tag_of(v_x1_2437)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24it_2427_24MkPair, 2);
              v_t_2439 = v_broken_244;
              break;
            }
            case TAG_Just: {
              V v_x_2438 = heff_field(v_x1_2437, 0);
              heff_take_n(v_x1_2437, 1ULL, 1);
              v_t_2439 = heff_tag_at_n(v_ru_24it_2427_24MkPair, TAG_Cons, 2, (V[]){v_x_2438, v_broken_244});
              break;
            }
            default: heff_nomatch(v_x1_2437);
            }
            V t_0 = v_t_2436;
            V t_1 = v_s2_2429;
            V t_2 = v_items_242;
            V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2430, v_diags_243});
            V t_4 = v_t_2439;
            v_cs_240 = t_0;
            v_s_241 = t_1;
            v_items_242 = t_2;
            v_diags_243 = t_3;
            v_broken_244 = t_4;
            goto top;
          }
          case TAG_Right: {
            V v_ds_2440 = heff_field(v_it1_2428, 0);
            heff_take_n(v_it1_2428, 1ULL, 1);
            V v_t_2441 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2414), heff_dup(heff_rfield(v_cs2_2414, 1))));
            if (heff_strEq_c(heff_get_n(v_t_2441, 0, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str1))) {
              heff_drop_cell(v_ru_24it_2412_24MkPair, 2);
              heff_drop_cell(v_ru_24it_2427_24MkPair, 2);
              V v_t_2443 = (g_heff_2esyntax_2esurface_2eappendRev(v_ds_2440, v_items_242));
              V t_0 = v_cs2_2414;
              V t_1 = v_s2_2429;
              V t_2 = v_t_2443;
              V t_3 = v_diags_243;
              V t_4 = v_broken_244;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            } else {
              V v_t_2444 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
              V v_t_2446;
              if (heff_intLt_c(heff_dup(heff_rfield(v_cs2_2414, 1)), v_t_2444)) {
                v_t_2446 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
              } else {
                v_t_2446 = heff_dup(heff_rfield(v_cs2_2414, 1));
              }
              V v_t_2447 = heff_tag_at_n(v_ru_24it_2412_24MkPair, TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
              V v_t_2448 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs2_2414, 0)), v_t_2446, heff_dup(heff_rfield(v_cs2_2414, 2)), v_t_2447, heff_dup(heff_rfield(v_cs2_2414, 4))});
              V v_t_2449 = (g_heff_2esyntax_2ecst_2eskipFrom(v_t_2448));
              V v_t_2450 = (g_heff_2esyntax_2esurface_2eappendRev(v_ds_2440, v_items_242));
              V v_t_2451 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2414), heff_dup(heff_rfield(v_cs2_2414, 1))));
              V v_t_2452 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2414), heff_get_n(v_cs2_2414, 1, 5)));
              V v_t_2453 = heff_strAppend(heff_get_n(v_t_2452, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str2));
              V v_msg_2454 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eprogGo_str3), v_t_2453);
              V v_t_2455 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2451, 3), heff_get_n(v_t_2451, 4, 9)});
              V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2454, v_t_2455, NTAG(TAG_Nothing)});
              V t_0 = v_t_2449;
              V t_1 = v_s2_2429;
              V t_2 = v_t_2450;
              V t_3 = heff_tag_at_n(v_ru_24it_2427_24MkPair, TAG_Cons, 2, (V[]){v_t_2456, v_diags_243});
              V t_4 = v_broken_244;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            }
          }
          default: return heff_nomatch(v_it1_2428);
          }
        }
        default: return heff_nomatch(v_it_2427);
        }
      }
      default: return heff_nomatch(v_it1_2413);
      }
    }
    default: return heff_nomatch(v_it_2412);
    }
  }
}
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprogGo(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(a[0], a[1], a[2]);
}