// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadFieldDecl 11244
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkEquation 38417
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Passes 47566
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_broken 566525696
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_i 323
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_open 9913105
#define LBL_patVars 1587353522
#define LBL_prims 308293287
#define LBL_scope 310622830
#define LBL_seen 10021698
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__diags__broken[] = {LBL_items, LBL_diags, LBL_broken};
static uint32_t shape_seen__prims__open__diags[] = {LBL_seen, LBL_prims, LBL_open, LBL_diags};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot};
V g_heff_2esyntax_2ecst_2edeclStep(V);
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclStep_clo;
HeffT2 g_heff_2esyntax_2ecst_2edeclaredAt_24cpr(V);
V g_heff_2esyntax_2ecst_2eskipFrom(V);
V g_heff_2esyntax_2ecst_2eskipFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eskipFrom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2esurface_2eappendRev(V, V);
V g_heff_2esyntax_2esurface_2eappendRev_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendRev_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(V, V);
V g_heff_2esyntax_2esurface_2edefinedStep(V, V, V);
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinedStep_clo;
V g_heff_2esyntax_2esurface_2efieldDeclOf(V, V);
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo;
V g_heff_2esyntax_2esurface_2eisSetting(V);
V g_heff_2esyntax_2esurface_2eisSetting_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisSetting_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eparenL_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprogGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2esymAtom_24cpr(V);
V g_heff_2esyntax_2esurface_2eunevenAt(V, V, V);
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunevenAt_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str0, 22, "` is first defined at ");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str1, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str2, 22, "` is first defined at ");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinedStep_str3, 1, "`");
V g_heff_2esyntax_2esurface_2edefinedStep_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefinedStep_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinedStep_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefinedStep_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edefinedStep_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefinedStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinedStep_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefinedStep(V v_at_240, V v_d_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Names: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    V v_next_245 = heff_field(v_x3_242, 2);
    V v_msg_246 = heff_field(v_x3_242, 3);
    V v_prim_247 = heff_field(v_x3_242, 4);
    V v_seen_248 = heff_dup(heff_rfield(v_d_241, 0));
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_seen_248, v_x_243));
    V v_t_2414;
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x_2413 = v_field_2411;
        heff_drop(v_x_2413);
        v_t_2414 = v_seen_248;
      } else {
        heff_drop(v_field_2411);
        v_t_2414 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_seen_248, heff_dup(v_x_243), heff_dup(v_sp_244)));
      }
    }
    V v_prims_2415 = heff_dup(heff_rfield(v_d_241, 1));
    V v_t_2416;
    if ((heff_dup(v_prim_247) == NTAG(TAG_True))) {
      v_t_2416 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_prims_2415, heff_dup(v_x_243), NTAG(TAG_MkUnit)));
    } else {
      v_t_2416 = v_prims_2415;
    }
    V v_t_2443;
    if ((heff_dup(v_prim_247) == NTAG(TAG_True))) {
      HeffT2 v_t_2417 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(heff_rfield(v_d_241, 1), v_x_243));
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          heff_drop(v_at_240);
          V v_x_2421 = v_field_2419;
          heff_drop(v_x_2421);
          v_t_2443 = ((V)&g_heff_2esyntax_2esurface_2edefinedStep_lam0_clo);
        } else {
          heff_drop(v_field_2419);
          HeffT2 v_t_2423 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_d_241, 0), v_x_243));
          {
            V v_field_2425 = v_t_2423.f[1];
            V v_tag_2424 = heff_box_i64(((int64_t)v_t_2423.f[0]));
            v_t_2443 = heff_clo_n(g_heff_2esyntax_2esurface_2edefinedStep_lam1, 1, 6, (V[]){v_tag_2424, v_field_2425, v_at_240, heff_dup(v_x_243), heff_dup(v_msg_246), heff_dup(v_sp_244)});
          }
        }
      }
    } else {
      HeffT2 v_t_2433 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_d_241, 0), v_x_243));
      {
        V v_field_2435 = v_t_2433.f[1];
        V v_tag_2434 = heff_box_i64(((int64_t)v_t_2433.f[0]));
        v_t_2443 = heff_clo_n(g_heff_2esyntax_2esurface_2edefinedStep_lam2, 1, 6, (V[]){v_tag_2434, v_field_2435, v_at_240, heff_dup(v_x_243), heff_dup(v_msg_246), heff_dup(v_sp_244)});
      }
    }
    V v_t_2444 = heff_tr(heff_call(v_t_2443, 1, (V[]){heff_get_n(v_d_241, 3, 4)}));
    return heff_rec_n(4, shape_seen__prims__open__diags, (V[]){v_t_2414, v_t_2416, heff_dup(v_next_245), v_t_2444});
  }
  case TAG_Passes: {
    heff_drop(v_at_240);
    return v_d_241;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2edefinedStep_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2edefinedStep(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2esurface_2edefinedStep_lam0(V self, V *args) {
  V v_diags_2422 = args[0];
  return v_diags_2422;
}
V g_heff_2esyntax_2esurface_2edefinedStep_lam1(V self, V *args) {
  V v_diags_2426 = args[0];
  V v_tag_2424 = heff_env(self)[0];
  V v_field_2425 = heff_env(self)[1];
  V v_at_240 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_msg_246 = heff_env(self)[4];
  V v_sp_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_unbox_i64(v_tag_2424) == ((int64_t)0ULL))) {
    V v_first_2428 = v_field_2425;
    V v_t_2429 = heff_tr(heff_call(v_at_240, 1, (V[]){heff_get_n(v_first_2428, 0, 2)}));
    V v_t_2430 = heff_strAppend(v_x_243, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str0), v_t_2429));
    V v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str1), v_t_2430)});
    V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(153LL), NTAG(TAG_SError), v_msg_246, v_sp_244, v_t_2431});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, v_diags_2426});
  } else {
    heff_drop(v_field_2425);
    heff_drop(v_at_240);
    heff_drop(v_x_243);
    heff_drop(v_msg_246);
    heff_drop(v_sp_244);
    return v_diags_2426;
  }
}
V g_heff_2esyntax_2esurface_2edefinedStep_lam2(V self, V *args) {
  V v_diags_2436 = args[0];
  V v_tag_2434 = heff_env(self)[0];
  V v_field_2435 = heff_env(self)[1];
  V v_at_240 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_msg_246 = heff_env(self)[4];
  V v_sp_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if ((heff_unbox_i64(v_tag_2434) == ((int64_t)0ULL))) {
    V v_first_2438 = v_field_2435;
    V v_t_2439 = heff_tr(heff_call(v_at_240, 1, (V[]){heff_get_n(v_first_2438, 0, 2)}));
    V v_t_2440 = heff_strAppend(v_x_243, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str2), v_t_2439));
    V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinedStep_str3), v_t_2440)});
    V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(153LL), NTAG(TAG_SError), v_msg_246, v_sp_244, v_t_2441});
    return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, v_diags_2436});
  } else {
    heff_drop(v_field_2435);
    heff_drop(v_at_240);
    heff_drop(v_x_243);
    heff_drop(v_msg_246);
    heff_drop(v_sp_244);
    return v_diags_2436;
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esymAtom_24cpr_str0, 3, "sym");

HeffT2 g_heff_2esyntax_2esurface_2esymAtom_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    V v_t_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_241, 0)), ((V)&g_heff_2esyntax_2esurface_2esymAtom_24cpr_str0))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_241}});
    } else {
      heff_drop_rec(v_t_241, 9);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_EParen: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Named: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Tup: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Seg: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Braces: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Update: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EUSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_InstB: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFSet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFDefault: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Sum: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECon: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EField: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENeg: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_App: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Op: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ops: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_OpRhs: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Ann: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BImp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_BAnn: {
    heff_take_n(v_x1_240, 0ULL, 5);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Lam: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Case: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAlt: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_If: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Do: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESBind: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetMut: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAssign: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWhile: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFor: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EJump: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EReturn: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ENest: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_IfThen: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELetCond: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETry: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECatch: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EWith: {
    heff_take_n(v_x1_240, 0ULL, 6);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2efieldDeclOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efieldDeclOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efieldDeclOf(V v_e_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_At: {
    V v_e1_242 = heff_dup(heff_field(v_e_240, 0));
    V v_sp_243 = heff_dup(heff_field(v_e_240, 1));
    switch (heff_tag_of(v_e1_242)) {
    case TAG_EVar: {
      V v_ru_24e1_242_24EVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_247;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_246 = heff_dup(heff_field(v_e_240, 1));
        v_t_247 = v_s_246;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EVar, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_247});
    }
    case TAG_EImplicitVar: {
      V v_ru_24e1_242_24EImplicitVar = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2411;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2410 = heff_dup(heff_field(v_e_240, 1));
        v_t_2411 = v_s_2410;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EImplicitVar, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2411});
    }
    case TAG_ETag: {
      V v_ru_24e1_242_24ETag = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2415;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2414 = heff_dup(heff_field(v_e_240, 1));
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETag, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2415});
    }
    case TAG_EInt: {
      V v_ru_24e1_242_24EInt = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2419;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2418 = heff_dup(heff_field(v_e_240, 1));
        v_t_2419 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInt, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2419});
    }
    case TAG_EFloat: {
      V v_ru_24e1_242_24EFloat = heff_take_reuse_na(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2423;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2422 = heff_dup(heff_field(v_e_240, 1));
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EFloat, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2423});
    }
    case TAG_EString: {
      V v_ru_24e1_242_24EString = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2427;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2426 = heff_dup(heff_field(v_e_240, 1));
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EString, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2427});
    }
    case TAG_EBinary: {
      V v_ru_24e1_242_24EBinary = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2431;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2430 = heff_dup(heff_field(v_e_240, 1));
        v_t_2431 = v_s_2430;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EBinary, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2431});
    }
    case TAG_ERune: {
      V v_ru_24e1_242_24ERune = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2435;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2434 = heff_dup(heff_field(v_e_240, 1));
        v_t_2435 = v_s_2434;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ERune, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2435});
    }
    case TAG_EWord: {
      V v_ru_24e1_242_24EWord = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2439;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2438 = heff_dup(heff_field(v_e_240, 1));
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EWord, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2439});
    }
    case TAG_EApp: {
      V v_ru_24e1_242_24EApp = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2444;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2443 = heff_dup(heff_field(v_e_240, 1));
        v_t_2444 = v_s_2443;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EApp, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2444});
    }
    case TAG_EProject: {
      V v_ru_24e1_242_24EProject = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2448;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2447 = heff_dup(heff_field(v_e_240, 1));
        v_t_2448 = v_s_2447;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EProject, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2448});
    }
    case TAG_ENamed: {
      V v_ru_24e1_242_24ENamed = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2453;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2452 = heff_dup(heff_field(v_e_240, 1));
        v_t_2453 = v_s_2452;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ENamed, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2453});
    }
    case TAG_EPi: {
      V v_ru_24e1_242_24EPi = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2458;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2457 = heff_dup(heff_field(v_e_240, 1));
        v_t_2458 = v_s_2457;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EPi, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2458});
    }
    case TAG_ELam: {
      V v_ru_24e1_242_24ELam = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_2463;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2462 = heff_dup(heff_field(v_e_240, 1));
        v_t_2463 = v_s_2462;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ELam, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2463});
    }
    case TAG_EAnn: {
      V v_e11_2464 = heff_field(v_e1_242, 0);
      V v_t_2465 = heff_field(v_e1_242, 1);
      V v_ru_24e1_242_24EAnn = heff_take_reuse_n(v_e1_242, 3ULL, 2);
      switch (heff_tag_of(v_e11_2464)) {
      case TAG_At: {
        V v_e111_2466 = heff_field(v_e11_2464, 0);
        V v_xsp_2467 = heff_field(v_e11_2464, 1);
        heff_take_n(v_e11_2464, 3ULL, 2);
        switch (heff_tag_of(v_e111_2466)) {
        case TAG_EVar: {
          V v_x_2468 = heff_field(v_e111_2466, 0);
          heff_take_n(v_e111_2466, 1ULL, 1);
          heff_drop_tag(v_e_240, 2);
          V v_t_2473;
          switch (heff_tag_of(v_d_241)) {
          case TAG_Nothing: {
            v_t_2473 = v_sp_243;
            break;
          }
          case TAG_Just: {
            V v_d_2469 = heff_dup(heff_field(v_d_241, 0));
            V v_t_2472;
            switch (heff_tag_of(v_d_2469)) {
            case TAG_At: {
              V v_s_2471 = heff_field(v_d_2469, 1);
              heff_take_n(v_d_2469, 2ULL, 2);
              v_t_2472 = v_s_2471;
              break;
            }
            default: heff_nomatch(v_d_2469);
            }
            v_t_2473 = ({ V rv_1 = heff_get_n(v_t_2472, 1, 2); V rr_ = heff_rec_reuse_nf(v_sp_243, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          default: heff_nomatch(v_d_241);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclareField, 4, (V[]){v_x_2468, v_xsp_2467, v_t_2465, v_d_241}), v_t_2473});
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2477;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2476 = heff_dup(heff_field(v_e_240, 1));
            v_t_2477 = v_s_2476;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2477});
        }
        case TAG_ETag: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2481;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2480 = heff_dup(heff_field(v_e_240, 1));
            v_t_2481 = v_s_2480;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2481});
        }
        case TAG_EInt: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2485;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2484 = heff_dup(heff_field(v_e_240, 1));
            v_t_2485 = v_s_2484;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2485});
        }
        case TAG_EFloat: {
          heff_take_na(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2489;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2488 = heff_dup(heff_field(v_e_240, 1));
            v_t_2489 = v_s_2488;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2489});
        }
        case TAG_EString: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2493;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2492 = heff_dup(heff_field(v_e_240, 1));
            v_t_2493 = v_s_2492;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2493});
        }
        case TAG_EBinary: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_2497;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_2496 = heff_dup(heff_field(v_e_240, 1));
            v_t_2497 = v_s_2496;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_2497});
        }
        case TAG_ERune: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24101;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24100 = heff_dup(heff_field(v_e_240, 1));
            v_t_24101 = v_s_24100;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24101});
        }
        case TAG_EWord: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24105;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24104 = heff_dup(heff_field(v_e_240, 1));
            v_t_24105 = v_s_24104;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24105});
        }
        case TAG_EApp: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24110;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24109 = heff_dup(heff_field(v_e_240, 1));
            v_t_24110 = v_s_24109;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24110});
        }
        case TAG_EProject: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24114;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24113 = heff_dup(heff_field(v_e_240, 1));
            v_t_24114 = v_s_24113;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24114});
        }
        case TAG_ENamed: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24119;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24118 = heff_dup(heff_field(v_e_240, 1));
            v_t_24119 = v_s_24118;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24119});
        }
        case TAG_EPi: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24124;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24123 = heff_dup(heff_field(v_e_240, 1));
            v_t_24124 = v_s_24123;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24124});
        }
        case TAG_ELam: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24129;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24128 = heff_dup(heff_field(v_e_240, 1));
            v_t_24129 = v_s_24128;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24129});
        }
        case TAG_EAnn: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24134;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24133 = heff_dup(heff_field(v_e_240, 1));
            v_t_24134 = v_s_24133;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24134});
        }
        case TAG_ESpec: {
          heff_take_n(v_e111_2466, 0ULL, 4);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24141;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24140 = heff_dup(heff_field(v_e_240, 1));
            v_t_24141 = v_s_24140;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24141});
        }
        case TAG_ESig: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24145;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24144 = heff_dup(heff_field(v_e_240, 1));
            v_t_24145 = v_s_24144;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24145});
        }
        case TAG_ESum: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24149;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24148 = heff_dup(heff_field(v_e_240, 1));
            v_t_24149 = v_s_24148;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24149});
        }
        case TAG_EStruct: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24153;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24152 = heff_dup(heff_field(v_e_240, 1));
            v_t_24153 = v_s_24152;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24153});
        }
        case TAG_EUpdate: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24158;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24157 = heff_dup(heff_field(v_e_240, 1));
            v_t_24158 = v_s_24157;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24158});
        }
        case TAG_EMatch: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24163;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24162 = heff_dup(heff_field(v_e_240, 1));
            v_t_24163 = v_s_24162;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24163});
        }
        case TAG_ELetIn: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24168;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24167 = heff_dup(heff_field(v_e_240, 1));
            v_t_24168 = v_s_24167;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24168});
        }
        case TAG_EDo: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24172;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24171 = heff_dup(heff_field(v_e_240, 1));
            v_t_24172 = v_s_24171;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24172});
        }
        case TAG_ELocal: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24177;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24176 = heff_dup(heff_field(v_e_240, 1));
            v_t_24177 = v_s_24176;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24177});
        }
        case TAG_EInvalid: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24181;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24180 = heff_dup(heff_field(v_e_240, 1));
            v_t_24181 = v_s_24180;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24181});
        }
        case TAG_EAssign: {
          heff_take_n(v_e111_2466, 0ULL, 3);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24187;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24186 = heff_dup(heff_field(v_e_240, 1));
            v_t_24187 = v_s_24186;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24187});
        }
        case TAG_EWhile: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24192;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24191 = heff_dup(heff_field(v_e_240, 1));
            v_t_24192 = v_s_24191;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24192});
        }
        case TAG_EFor: {
          heff_take_n(v_e111_2466, 0ULL, 3);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24198;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24197 = heff_dup(heff_field(v_e_240, 1));
            v_t_24198 = v_s_24197;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24198});
        }
        case TAG_EIfThen: {
          heff_take_n(v_e111_2466, 0ULL, 2);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24203;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24202 = heff_dup(heff_field(v_e_240, 1));
            v_t_24203 = v_s_24202;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24203});
        }
        case TAG_EBreak: {
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24206;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24205 = heff_dup(heff_field(v_e_240, 1));
            v_t_24206 = v_s_24205;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24206});
        }
        case TAG_EContinue: {
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24209;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24208 = heff_dup(heff_field(v_e_240, 1));
            v_t_24209 = v_s_24208;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24209});
        }
        case TAG_EReturn: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24213;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24212 = heff_dup(heff_field(v_e_240, 1));
            v_t_24213 = v_s_24212;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24213});
        }
        case TAG_ENest: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24217;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24216 = heff_dup(heff_field(v_e_240, 1));
            v_t_24217 = v_s_24216;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24217});
        }
        case TAG_EIfLet: {
          heff_take_n(v_e111_2466, 0ULL, 4);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24224;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24223 = heff_dup(heff_field(v_e_240, 1));
            v_t_24224 = v_s_24223;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24224});
        }
        case TAG_ETry: {
          heff_take_n(v_e111_2466, 0ULL, 1);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24228;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24227 = heff_dup(heff_field(v_e_240, 1));
            v_t_24228 = v_s_24227;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24228});
        }
        case TAG_EWith: {
          heff_take_n(v_e111_2466, 0ULL, 4);
          heff_drop(v_d_241);
          heff_drop_rec(v_sp_243, 2);
          heff_drop(v_t_2465);
          heff_drop(v_xsp_2467);
          V v_t_24235;
          switch (heff_tag_of(v_e_240)) {
          case TAG_At: {
            V v_s_24234 = heff_dup(heff_field(v_e_240, 1));
            v_t_24235 = v_s_24234;
            break;
          }
          default: heff_nomatch(v_e_240);
          }
          return heff_tag_at_n(v_ru_24e1_242_24EAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24235});
        }
        default: return heff_nomatch(v_e111_2466);
        }
      }
      default: return heff_nomatch(v_e11_2464);
      }
    }
    case TAG_ESpec: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24242;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24241 = heff_dup(heff_field(v_e_240, 1));
        v_t_24242 = v_s_24241;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24242});
    }
    case TAG_ESig: {
      V v_ru_24e1_242_24ESig = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24246;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24245 = heff_dup(heff_field(v_e_240, 1));
        v_t_24246 = v_s_24245;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESig, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24246});
    }
    case TAG_ESum: {
      V v_ru_24e1_242_24ESum = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24250;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24249 = heff_dup(heff_field(v_e_240, 1));
        v_t_24250 = v_s_24249;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ESum, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24250});
    }
    case TAG_EStruct: {
      V v_ru_24e1_242_24EStruct = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24254;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24253 = heff_dup(heff_field(v_e_240, 1));
        v_t_24254 = v_s_24253;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EStruct, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24254});
    }
    case TAG_EUpdate: {
      V v_ru_24e1_242_24EUpdate = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24259;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24258 = heff_dup(heff_field(v_e_240, 1));
        v_t_24259 = v_s_24258;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EUpdate, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24259});
    }
    case TAG_EMatch: {
      V v_ru_24e1_242_24EMatch = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24264;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24263 = heff_dup(heff_field(v_e_240, 1));
        v_t_24264 = v_s_24263;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24264});
    }
    case TAG_ELetIn: {
      V v_ru_24e1_242_24ELetIn = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24269;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24268 = heff_dup(heff_field(v_e_240, 1));
        v_t_24269 = v_s_24268;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ELetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24269});
    }
    case TAG_EDo: {
      V v_ru_24e1_242_24EDo = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24273;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24272 = heff_dup(heff_field(v_e_240, 1));
        v_t_24273 = v_s_24272;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EDo, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24273});
    }
    case TAG_ELocal: {
      V v_ru_24e1_242_24ELocal = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24278;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24277 = heff_dup(heff_field(v_e_240, 1));
        v_t_24278 = v_s_24277;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24ELocal, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24278});
    }
    case TAG_EInvalid: {
      V v_ru_24e1_242_24EInvalid = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24282;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24281 = heff_dup(heff_field(v_e_240, 1));
        v_t_24282 = v_s_24281;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EInvalid, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24282});
    }
    case TAG_EAssign: {
      heff_take_n(v_e1_242, 0ULL, 3);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24288;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24287 = heff_dup(heff_field(v_e_240, 1));
        v_t_24288 = v_s_24287;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24288});
    }
    case TAG_EWhile: {
      V v_ru_24e1_242_24EWhile = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24293;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24292 = heff_dup(heff_field(v_e_240, 1));
        v_t_24293 = v_s_24292;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EWhile, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24293});
    }
    case TAG_EFor: {
      heff_take_n(v_e1_242, 0ULL, 3);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24299;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24298 = heff_dup(heff_field(v_e_240, 1));
        v_t_24299 = v_s_24298;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24299});
    }
    case TAG_EIfThen: {
      V v_ru_24e1_242_24EIfThen = heff_take_reuse_n(v_e1_242, 0ULL, 2);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24304;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24303 = heff_dup(heff_field(v_e_240, 1));
        v_t_24304 = v_s_24303;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24e1_242_24EIfThen, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24304});
    }
    case TAG_EBreak: {
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24307;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24306 = heff_dup(heff_field(v_e_240, 1));
        v_t_24307 = v_s_24306;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24307});
    }
    case TAG_EContinue: {
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24310;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24309 = heff_dup(heff_field(v_e_240, 1));
        v_t_24310 = v_s_24309;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24310});
    }
    case TAG_EReturn: {
      V v_ru_24e1_242_24EReturn = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24314;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24313 = heff_dup(heff_field(v_e_240, 1));
        v_t_24314 = v_s_24313;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24EReturn, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24314});
    }
    case TAG_ENest: {
      V v_ru_24e1_242_24ENest = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24318;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24317 = heff_dup(heff_field(v_e_240, 1));
        v_t_24318 = v_s_24317;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ENest, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24318});
    }
    case TAG_EIfLet: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24325;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24324 = heff_dup(heff_field(v_e_240, 1));
        v_t_24325 = v_s_24324;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24325});
    }
    case TAG_ETry: {
      V v_ru_24e1_242_24ETry = heff_take_reuse_n(v_e1_242, 0ULL, 1);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24329;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24328 = heff_dup(heff_field(v_e_240, 1));
        v_t_24329 = v_s_24328;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e1_242_24ETry, TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24329});
    }
    case TAG_EWith: {
      heff_take_n(v_e1_242, 0ULL, 4);
      heff_drop(v_d_241);
      heff_drop_rec(v_sp_243, 2);
      V v_t_24336;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24335 = heff_dup(heff_field(v_e_240, 1));
        v_t_24336 = v_s_24335;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_e_240}), v_t_24336});
    }
    default: return heff_nomatch(v_e1_242);
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2esurface_2efieldDeclOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efieldDeclOf(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2eisSetting_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eisSetting_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eisSetting(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_True);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    return NTAG(TAG_False);
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ELetCond: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2eisSetting_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eisSetting(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2eparenL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparenL_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eparenL(V v_r_240, V v_o_241, V v_e_242, V v_c_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2eparenL_24cpr(v_r_240, v_o_241, v_e_242, v_c_243, v_z_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_246, v_field_247});
  }
}
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eparenL(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunevenAt_str0, 40, " pattern(s), as its first: this one has ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunevenAt_str1, 6, "` has ");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunevenAt_str2, 19, "every equation of `");
Clo g_heff_2esyntax_2esurface_2eunevenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunevenAt_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunevenAt(V v_f_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_At: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      V v_sp_246 = heff_field(v_x31_243, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_MkEquation: {
        V v_pats_249 = heff_field(v_x311_245, 2);
        V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_pats_249));
        if (heff_intEq_c_lent(v_t_2411, v_n_241, 1)) {
          V t_0 = v_f_240;
          V t_1 = v_n_241;
          V t_2 = v_rest_244;
          v_f_240 = t_0;
          v_n_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_pats_249));
          V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eunevenAt_str0), heff_intShow(v_t_2413));
          V v_t_2415 = heff_strAppend(heff_intShow(v_n_241), v_t_2414);
          V v_t_2416 = heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eunevenAt_str1), v_t_2415));
          V v_msg_2417 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eunevenAt_str2), v_t_2416);
          V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2417, heff_dup(v_sp_246), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
        }
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2eunevenAt(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprogGo_str3, 12, "unexpected `");
Clo g_heff_2esyntax_2esurface_2eprogGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprogGo_entry, 5, 0};

V g_heff_2esyntax_2esurface_2eprogGo(V v_cs_240, V v_s_241, V v_items_242, V v_diags_243, V v_broken_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_246 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs_240, 0)), heff_dup(heff_rfield(v_cs_240, 1)), heff_dup(heff_rfield(v_cs_240, 1)), v_t_245, heff_dup(heff_rfield(v_cs_240, 1))});
  V v_t_247 = (g_heff_2esyntax_2ecst_2etokAt(v_t_246, heff_dup(heff_rfield(v_cs_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_247, 0, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str0))) {
    heff_drop_rec(v_cs_240, 5);
    heff_drop_rec(v_s_241, 9);
    V v_items_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_diags_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_diags_243));
    V v_broken_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_broken_244));
    return heff_rec_n(3, shape_items__diags__broken, (V[]){v_items_249, v_diags_2410, v_broken_2411});
  } else {
    V v_it_2412 = heff_tr(g_heff_2esyntax_2ecst_2edeclStep(v_cs_240));
    switch (heff_tag_of(v_it_2412)) {
    case TAG_MkPair: {
      V v_it1_2413 = heff_field(v_it_2412, 0);
      V v_cs2_2414 = heff_field(v_it_2412, 1);
      V v_ru_24it_2412_24MkPair = heff_take_reuse_n(v_it_2412, 3ULL, 2);
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_Left: {
        V v_d_2415 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        V v_t_2416 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
        V v_t_2418;
        if (heff_intLt_c(heff_dup(heff_rfield(v_cs2_2414, 1)), v_t_2416)) {
          v_t_2418 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
        } else {
          v_t_2418 = heff_dup(heff_rfield(v_cs2_2414, 1));
        }
        V v_t_2419 = heff_tag_at_n(v_ru_24it_2412_24MkPair, TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
        V v_t_2420 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs2_2414, 0)), v_t_2418, heff_dup(heff_rfield(v_cs2_2414, 2)), v_t_2419, heff_dup(heff_rfield(v_cs2_2414, 4))});
        V v_t_2421 = (g_heff_2esyntax_2ecst_2eskipFrom(v_t_2420));
        HeffT2 v_t_2422 = (g_heff_2esyntax_2ecst_2edeclaredAt_24cpr(v_cs2_2414));
        V v_t_2427;
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            V v_x_2426 = v_field_2424;
            v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2426, v_broken_244});
          } else {
            heff_drop(v_field_2424);
            v_t_2427 = v_broken_244;
          }
        }
        V t_0 = v_t_2421;
        V t_1 = v_s_241;
        V t_2 = v_items_242;
        V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2415, v_diags_243});
        V t_4 = v_t_2427;
        v_cs_240 = t_0;
        v_s_241 = t_1;
        v_items_242 = t_2;
        v_diags_243 = t_3;
        v_broken_244 = t_4;
        goto top;
      }
      case TAG_Right: {
        V v_dc_2428 = heff_field(v_it1_2413, 0);
        heff_take_n(v_it1_2413, 1ULL, 1);
        V v_t_2429 = ({ V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_s_241, 509ULL, 9, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot, 262131u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
        HeffT2 v_t_2430 = (g_heff_2esyntax_2esurface_2edeclL_24s1856152445x94588903_24cpr(v_dc_2428, v_t_2429));
        {
          V v_field_2431 = v_t_2430.f[0];
          V v_field_2432 = v_t_2430.f[1];
          V v_it1_2433 = v_field_2431;
          V v_s2_2434 = v_field_2432;
          switch (heff_tag_of(v_it1_2433)) {
          case TAG_Left: {
            V v_d_2435 = heff_field(v_it1_2433, 0);
            heff_take_n(v_it1_2433, 1ULL, 1);
            V v_t_2436 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
            V v_t_2438;
            if (heff_intLt_c(heff_dup(heff_rfield(v_cs2_2414, 1)), v_t_2436)) {
              v_t_2438 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
            } else {
              v_t_2438 = heff_dup(heff_rfield(v_cs2_2414, 1));
            }
            V v_t_2439 = heff_tag_at_n(v_ru_24it_2412_24MkPair, TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
            V v_t_2440 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs2_2414, 0)), v_t_2438, heff_dup(heff_rfield(v_cs2_2414, 2)), v_t_2439, heff_dup(heff_rfield(v_cs2_2414, 4))});
            V v_t_2441 = (g_heff_2esyntax_2ecst_2eskipFrom(v_t_2440));
            HeffT2 v_t_2442 = (g_heff_2esyntax_2ecst_2edeclaredAt_24cpr(v_cs2_2414));
            V v_t_2447;
            {
              V v_field_2444 = v_t_2442.f[1];
              int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
              if ((v_tag_2443 == ((int64_t)0ULL))) {
                V v_x_2446 = v_field_2444;
                v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2446, v_broken_244});
              } else {
                heff_drop(v_field_2444);
                v_t_2447 = v_broken_244;
              }
            }
            V t_0 = v_t_2441;
            V t_1 = v_s2_2434;
            V t_2 = v_items_242;
            V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2435, v_diags_243});
            V t_4 = v_t_2447;
            v_cs_240 = t_0;
            v_s_241 = t_1;
            v_items_242 = t_2;
            v_diags_243 = t_3;
            v_broken_244 = t_4;
            goto top;
          }
          case TAG_Right: {
            V v_ds_2448 = heff_field(v_it1_2433, 0);
            heff_take_n(v_it1_2433, 1ULL, 1);
            V v_t_2449 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2414), heff_dup(heff_rfield(v_cs2_2414, 1))));
            if (heff_strEq_c(heff_get_n(v_t_2449, 0, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str1))) {
              heff_drop_cell(v_ru_24it_2412_24MkPair, 2);
              V v_t_2451 = (g_heff_2esyntax_2esurface_2eappendRev(v_ds_2448, v_items_242));
              V t_0 = v_cs2_2414;
              V t_1 = v_s2_2434;
              V t_2 = v_t_2451;
              V t_3 = v_diags_243;
              V t_4 = v_broken_244;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            } else {
              V v_t_2452 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
              V v_t_2454;
              if (heff_intLt_c(heff_dup(heff_rfield(v_cs2_2414, 1)), v_t_2452)) {
                v_t_2454 = heff_intAdd(heff_dup(heff_rfield(v_cs2_2414, 2)), MK_INT(1LL));
              } else {
                v_t_2454 = heff_dup(heff_rfield(v_cs2_2414, 1));
              }
              V v_t_2455 = heff_tag_at_n(v_ru_24it_2412_24MkPair, TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
              V v_t_2456 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_cs2_2414, 0)), v_t_2454, heff_dup(heff_rfield(v_cs2_2414, 2)), v_t_2455, heff_dup(heff_rfield(v_cs2_2414, 4))});
              V v_t_2457 = (g_heff_2esyntax_2ecst_2eskipFrom(v_t_2456));
              V v_t_2458 = (g_heff_2esyntax_2esurface_2eappendRev(v_ds_2448, v_items_242));
              V v_t_2459 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2414), heff_dup(heff_rfield(v_cs2_2414, 1))));
              V v_t_2460 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_cs2_2414), heff_get_n(v_cs2_2414, 1, 5)));
              V v_t_2461 = heff_strAppend(heff_get_n(v_t_2460, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eprogGo_str2));
              V v_msg_2462 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eprogGo_str3), v_t_2461);
              V v_t_2463 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2459, 3), heff_get_n(v_t_2459, 4, 9)});
              V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2462, v_t_2463, NTAG(TAG_Nothing)});
              V t_0 = v_t_2457;
              V t_1 = v_s2_2434;
              V t_2 = v_t_2458;
              V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2464, v_diags_243});
              V t_4 = v_broken_244;
              v_cs_240 = t_0;
              v_s_241 = t_1;
              v_items_242 = t_2;
              v_diags_243 = t_3;
              v_broken_244 = t_4;
              goto top;
            }
          }
          default: return heff_nomatch(v_it1_2433);
          }
        }
      }
      default: return heff_nomatch(v_it1_2413);
      }
    }
    default: return heff_nomatch(v_it_2412);
    }
  }
}
V g_heff_2esyntax_2esurface_2eprogGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eprogGo(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_241_24Cons, 2);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 1);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_ys_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_ys_240 = t_0;
      v_x1_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24f612308536x233502637_24dps(a[0], a[1], a[2]);
}