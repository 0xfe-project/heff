// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_base 9511832
#define LBL_by 9918
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_doneMods 1906059763
#define LBL_errors 652506774
#define LBL_heff 9694020
#define LBL_imports 10411951
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_named 305943379
#define LBL_own 320000
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_pkg 320582
#define LBL_place 308106529
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_scope 310622830
#define LBL_source 1050636102
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_version 583465758
static uint32_t shape_done__doneMods__errors[] = {LBL_done, LBL_doneMods, LBL_errors};
static uint32_t shape_path__base__parts__module[] = {LBL_path, LBL_base, LBL_parts, LBL_module};
static uint32_t shape_path__source__place__module__named[] = {LBL_path, LBL_source, LBL_place, LBL_module, LBL_named};
static uint32_t shape_path__version__pkg[] = {LBL_path, LBL_version, LBL_pkg};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596_clo;
V g_heff_2ebuild_2eload_2eclashMsg(V, V, V, V);
V g_heff_2ebuild_2eload_2eclashMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eclashMsg_clo;
V g_heff_2ebuild_2eload_2ecycleAmong(V, V, V);
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecycleAmong_clo;
V g_heff_2ebuild_2eload_2eheffAt(V, V);
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eheffAt_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131_clo;
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_clo;
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epartsNamed(V, V, V, V, V);
V g_heff_2ebuild_2eload_2epartsNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epartsNamed_clo;
HeffT2 g_heff_2ebuild_2eload_2epkgByPath_24cpr(V, V);
V g_heff_2ebuild_2eload_2epkgOfGo(V, V, V, V);
V g_heff_2ebuild_2eload_2epkgOfGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epkgOfGo_clo;
V g_heff_2ebuild_2eload_2eplacesOf(V, V, V, V);
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eplacesOf_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2epushDone(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2epushDone_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epushDone_clo;
V g_heff_2ebuild_2eload_2ereadEvery(V, V, V);
V g_heff_2ebuild_2eload_2ereadEvery_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_clo;
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(V, V);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_clo;
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo;
HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace(V, V, V, V, V);
V g_heff_2ebuild_2eload_2erequiredPlace_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2erequiredPlace_clo;
V g_heff_2ebuild_2eload_2esameButCase(V, V);
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameButCase_clo;
V g_heff_2ebuild_2eload_2esameDir(V, V, V);
V g_heff_2ebuild_2eload_2esameDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2esameDir_clo;
V g_heff_2ebuild_2eload_2etakeUntil(V, V);
V g_heff_2ebuild_2eload_2etakeUntil_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2etakeUntil_clo;
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(V, V, V, V, V, V, V);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_clo;
HeffT2 g_heff_2ebuild_2eproject_2esumGo_24cpr(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
V g_heff_2eutil_2ehostpath_2eisUnder(V, V, V);
V g_heff_2eutil_2ehostpath_2eisUnder_entry(V self, V *a);
extern Clo g_heff_2eutil_2ehostpath_2eisUnder_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap_24f201346761x152404242(V, V, V, V, V, V, V);
V g_list_2emap_24f201346761x152404242_entry(V self, V *a);
extern Clo g_list_2emap_24f201346761x152404242_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1817208647x1282894070(V);
V g_list_2emap_24s1817208647x1282894070_entry(V self, V *a);
extern Clo g_list_2emap_24s1817208647x1282894070_clo;
V g_list_2emap_24s435407392x1528135477(V);
V g_list_2emap_24s435407392x1528135477_entry(V self, V *a);
extern Clo g_list_2emap_24s435407392x1528135477_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
HeffT2 g_std_2epath_2erelative_24cpr(V, V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

HeffT2 g_heff_2ebuild_2eload_2erelFrom_24cpr(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  V v_st_245 = heff_dup(v_style_243);
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_d_241)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
  V v_st_2410 = heff_dup(v_style_243);
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_2410), heff_dup(v_cwd_244)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2410), heff_dup(v_path_242)));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_heff_2eutil_2ehostpath_2eisUnder(heff_dup(v_style_243), v_t_249, v_t_2414));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    V v_st_2416 = heff_dup(v_style_243);
    V v_st_2417 = heff_dup(v_style_243);
    V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2417), heff_dup(v_cwd_244)));
    V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_2417), v_d_241));
    V v_t_2420 = (g_std_2epath_2ejoin(v_t_2418, v_t_2419));
    V v_from_2421 = ({ V a_0 = v_st_2417; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2420); r_; });
    V v_st_2422 = v_style_243;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_cwd_244));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_path_242));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    V v_to_2426 = ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_from_2421));
    V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2416), v_to_2426));
    HeffT2 v_t_2429 = (g_std_2epath_2erelative_24cpr(heff_dup(v_st_2416), v_t_2427, v_t_2428));
    {
      V v_field_2431 = v_t_2429.f[1];
      int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
      if ((v_tag_2430 == ((int64_t)0ULL))) {
        V v_x_2432 = v_field_2431;
        V v_f_2433 = ({ V a_0 = v_st_2416; V a_1 = v_x_2432; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); heff_drop(v_x_2432); r_; });
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2433}});
      } else {
        heff_drop(v_st_2416);
        heff_drop(v_field_2431);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    heff_drop(v_t_2415);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2emoduleOf_str6, 1, ".");
Clo g_heff_2ebuild_2eload_2emoduleOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emoduleOf_entry, 2, 0};

V g_heff_2ebuild_2eload_2emoduleOf(V v_ps_240, V v_path_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_ps_240, 5));
  HeffT2 v_t_243 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_path_241)));
  V v_p_2415;
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_path_241);
      V v_rel_246 = v_field_245;
      v_p_2415 = v_rel_246;
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_247 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 1)), heff_dup(v_path_241)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_path_241);
          V v_rel_2410 = v_field_249;
          v_p_2415 = v_rel_2410;
        } else {
          heff_drop(v_field_249);
          HeffT2 v_t_2411 = (g_heff_2ebuild_2eload_2erelFrom_24cpr(heff_dup(v_ps_240), heff_get_n(v_ps_240, 0, 6), heff_dup(v_path_241)));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              heff_drop(v_path_241);
              V v_rel_2414 = v_field_2413;
              v_p_2415 = v_rel_2414;
            } else {
              heff_drop(v_field_2413);
              v_p_2415 = v_path_241;
            }
          }
        }
      }
    }
  }
  int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_p_2415, 0)) - ((int64_t)3ULL));
  V v_t_2417 = heff_strSlice(heff_dup(v_p_2415), heff_box_word(v_t_2416), heff_strLength_lent(v_p_2415, 0));
  V v_t_2419;
  if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2eload_2emoduleOf_str0))) {
    int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_p_2415, 0)) - ((int64_t)3ULL));
    v_t_2419 = heff_strSlice(v_p_2415, MK_INT(0LL), heff_box_word(v_t_2418));
  } else {
    v_t_2419 = v_p_2415;
  }
  HeffT3 v_t_2420 = (g_std_2epath_2eparse_24cpr(v_st_242, v_t_2419));
  {
    V v_field_2421 = v_t_2420.f[0];
    V v_field_2422 = v_t_2420.f[1];
    V v_field_2423 = v_t_2420.f[2];
    V v_d_2424 = v_field_2421;
    heff_drop(v_d_2424);
    V v_a_2425 = v_field_2422;
    V v_xs_2426 = v_field_2423;
    V v_xs_2427 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str1); V a_1 = v_a_2425; V a_2 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str2); V b_3 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str3); V a_4 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2426; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2425); heff_drop(b_3); r_; });
    V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2427));
    V v_x2_2429 = v_t_2428;
    switch (heff_tag_of(v_x2_2429)) {
    case TAG_Nil: {
      return ((V)&g_heff_2ebuild_2eload_2emoduleOf_str5);
    }
    case TAG_Cons: {
      V v_x_2430 = heff_field(v_x2_2429, 0);
      V v_xs_2431 = heff_field(v_x2_2429, 1);
      heff_take_n(v_x2_2429, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2emoduleOf_str6); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
    }
    default: return heff_nomatch(v_x2_2429);
    }
  }
}
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emoduleOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2einside_str0, 1, ".");
Clo g_heff_2ebuild_2eload_2einside_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2einside_entry, 3, 0};

V g_heff_2ebuild_2eload_2einside(V v_ps_240, V v_d_241, V v_path_242) {
top: ;
  V v_style_243 = heff_take_field(v_ps_240, 5);
  V v_cwd_244 = heff_get_n(v_ps_240, 4, 6);
  if (heff_strEq_c_lent(v_d_241, ((V)&g_heff_2ebuild_2eload_2einside_str0), 2)) {
    heff_drop(v_d_241);
    heff_drop(v_path_242);
    heff_drop(v_style_243);
    heff_drop(v_cwd_244);
    return NTAG(TAG_True);
  } else {
    V v_st_245 = heff_dup(v_style_243);
    V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_245), heff_dup(v_cwd_244)));
    V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_245), v_d_241));
    V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
    V v_t_249 = ({ V a_0 = v_st_245; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_245); heff_drop(v_t_248); r_; });
    V v_st_2410 = heff_dup(v_style_243);
    V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_cwd_244));
    V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_2410), v_path_242));
    V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
    V v_t_2414 = ({ V a_0 = v_st_2410; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2413); r_; });
    HEFF_LAST return g_heff_2eutil_2ehostpath_2eisUnder(v_style_243, v_t_249, v_t_2414);
  }
}
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2einside(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eheffAt_str0, 3, "lib");
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2eload_2eheffAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eheffAt_entry, 2, 0};

V g_heff_2ebuild_2eload_2eheffAt(V v_h_240, V v_d_241) {
top: ;
  V v_t_243 = (g_list_2eany(heff_clo_n(g_heff_2ebuild_2eload_2eheffAt_lam0, 1, 2, (V[]){heff_dup(v_h_240), heff_dup(v_d_241)}), heff_rfield(v_h_240, 4)));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop_rec(v_h_240, 5);
    heff_drop(v_d_241);
    heff_drop(v_t_243);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_243);
    V v_st_244 = heff_dup(heff_rfield(v_h_240, 3));
    V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_d_241));
    V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2eload_2eheffAt_str0)));
    V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
    V v_t_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
    return (g_heff_2ebuild_2eload_2esameDir(heff_dup(v_h_240), heff_get_n(v_h_240, 0, 5), v_t_248));
  }
}
V g_heff_2ebuild_2eload_2eheffAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eheffAt(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2eheffAt_lam0(V self, V *args) {
  V v_o_242 = args[0];
  V v_h_240 = heff_env(self)[0];
  V v_d_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2eload_2esameDir(v_h_240, v_o_242, v_d_241));
}
Clo g_heff_2ebuild_2eload_2ecycleAmong_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ecycleAmong_entry, 3, 0};

V g_heff_2ebuild_2eload_2ecycleAmong(V v_pkgs_240, V v_stack_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_stack_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_path_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_243)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_stack_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_rest_244);
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ebuild_2eload_2etakeUntil(v_path_243, v_stack_241));
      V v_xs_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, v_t_247});
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_t_246);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2eload_2epkgByPath_24cpr(v_pkgs_240, v_path_243));
      V v_t_2414;
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          V v_k_2413 = v_field_2412;
          v_t_2414 = (g_list_2emap_24s1173914895x100384474(heff_get_n(v_k_2413, 6, 7)));
        } else {
          heff_drop(v_field_2412);
          v_t_2414 = NTAG(TAG_Nil);
        }
      }
      V v_x1_2415 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_243, heff_dup(v_stack_241)}), v_t_2414));
      V v_x2_2416 = (g_heff_2ebuild_2eload_2ecycleAmong(v_pkgs_240, v_stack_241, v_rest_244));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Nothing: {
        return v_x2_2416;
      }
      case TAG_Just: {
        V v_x_2417 = heff_field(v_x1_2415, 0);
        V v_ru_24x1_2415_24Just = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
        heff_drop(v_x2_2416);
        return heff_tag_at_n(v_ru_24x1_2415_24Just, TAG_Just, 1, (V[]){v_x_2417});
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2eload_2ecycleAmong_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eload_2ecycleAmong(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str3, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str7, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str8, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str9, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str10, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str11, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str12, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str14, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str15, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str16, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str17, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str18, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str19, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str20, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str21, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str22, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2eplacesOf_str23, 3, ".hf");
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args);
Clo g_heff_2ebuild_2eload_2eplacesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eplacesOf_entry, 4, 0};

V g_heff_2ebuild_2eload_2eplacesOf(V v_ps_240, V v_pkgs_241, V v_from_242, V v_w_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_dup(heff_rfield(v_ps_240, 2)), heff_dup(v_from_242)));
  if (((heff_dup(v_t_244) == NTAG(TAG_True)) && !heff_strEq_c(heff_dup(heff_rfield(v_ps_240, 2)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str0)))) {
    heff_drop(v_pkgs_241);
    heff_drop(v_from_242);
    heff_drop(v_t_244);
    V v_base_245 = heff_dup(heff_rfield(v_ps_240, 2));
    V v_xs_246 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str1); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str2), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_246));
    V v_parts_2411;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      v_parts_2411 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_last_248 = heff_field(v_t_247, 0);
      V v_before_249 = heff_field(v_t_247, 1);
      V v_ru_24t_247_24Cons = heff_take_reuse_n(v_t_247, 3ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24t_247_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_248, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str3)), NTAG(TAG_Nil)});
      v_parts_2411 = (g_list_2efoldl_24s1370882877x364361272(v_t_2410, v_before_249));
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2418 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam0, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_245), v_parts_2411));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2418, v_base_245, v_parts_2411, v_w_243}), NTAG(TAG_Nil)});
  } else {
    heff_drop(v_t_244);
    switch (heff_tag_of(v_pkgs_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_ps_240, 6);
      heff_drop(v_from_242);
      heff_drop(v_w_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_project_2419 = heff_dup(heff_field(v_pkgs_241, 0));
      V v_deps_2420 = heff_dup(heff_field(v_pkgs_241, 1));
      V v_k_2421 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_deps_2420; V a_2 = v_project_2419; V a_3 = heff_dup(v_from_242); V r_ = (g_heff_2ebuild_2eload_2epkgOfGo(a_0, a_1, a_2, a_3)); heff_drop(v_deps_2420); r_; });
      V v_t_2455;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str4))) {
        V v_base_2422 = heff_dup(heff_rfield(v_k_2421, 2));
        V v_xs_2423 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str5); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str6), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
        V v_parts_2428;
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nil: {
          v_parts_2428 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Cons: {
          V v_last_2425 = heff_field(v_t_2424, 0);
          V v_before_2426 = heff_field(v_t_2424, 1);
          V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 3ULL, 2);
          V v_t_2427 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2425, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str7)), NTAG(TAG_Nil)});
          v_parts_2428 = (g_list_2efoldl_24s1370882877x364361272(v_t_2427, v_before_2426));
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        V v_t_2435 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam1, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2422), v_parts_2428));
        v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2435, v_base_2422, v_parts_2428, heff_dup(v_w_243)}), NTAG(TAG_Nil)});
      } else {
        V v_j_2436 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str8), v_w_243, MK_INT(0LL), 5);
        V v_t_2437;
        if (heff_intLt_c_lent(v_j_2436, MK_INT(0LL), 2)) {
          heff_drop(v_j_2436);
          v_t_2437 = heff_dup(v_w_243);
        } else {
          v_t_2437 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2436, 6);
        }
        if (heff_strEq_c(v_t_2437, heff_dup(heff_rfield(v_k_2421, 3)))) {
          V v_base_2438 = heff_dup(heff_rfield(v_k_2421, 2));
          V v_xs_2439 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str9); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str10), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2439));
          V v_parts_2444;
          switch (heff_tag_of(v_t_2440)) {
          case TAG_Nil: {
            v_parts_2444 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2441 = heff_field(v_t_2440, 0);
            V v_before_2442 = heff_field(v_t_2440, 1);
            V v_ru_24t_2440_24Cons = heff_take_reuse_n(v_t_2440, 3ULL, 2);
            V v_t_2443 = heff_tag_at_n(v_ru_24t_2440_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2441, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str11)), NTAG(TAG_Nil)});
            v_parts_2444 = (g_list_2efoldl_24s1370882877x364361272(v_t_2443, v_before_2442));
            break;
          }
          default: heff_nomatch(v_t_2440);
          }
          V v_j_2445 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str12), v_w_243, MK_INT(0LL), 5);
          V v_t_2446;
          if (heff_intLt_c_lent(v_j_2445, MK_INT(0LL), 2)) {
            heff_drop(v_j_2445);
            v_t_2446 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str13);
          } else {
            v_t_2446 = heff_strSlice(heff_dup(v_w_243), v_j_2445, heff_strLength_lent(v_w_243, 0));
          }
          V v_m_2447 = heff_strAppend(heff_dup(heff_rfield(v_k_2421, 4)), v_t_2446);
          V v_t_2454 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam2, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2438), v_parts_2444));
          v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2454, v_base_2438, v_parts_2444, v_m_2447}), NTAG(TAG_Nil)});
        } else {
          v_t_2455 = NTAG(TAG_Nil);
        }
      }
      V v_j_2456 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str14), v_w_243, MK_INT(0LL), 5);
      V v_t_2457;
      if (heff_intLt_c_lent(v_j_2456, MK_INT(0LL), 2)) {
        heff_drop(v_j_2456);
        v_t_2457 = heff_dup(v_w_243);
      } else {
        v_t_2457 = heff_strSlice_lent(v_w_243, MK_INT(0LL), v_j_2456, 6);
      }
      V v_j_2458 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str15), v_w_243, MK_INT(0LL), 5);
      V v_t_2459;
      if (heff_intLt_c_lent(v_j_2458, MK_INT(0LL), 2)) {
        heff_drop(v_j_2458);
        v_t_2459 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str16);
      } else {
        v_t_2459 = heff_strSlice(heff_dup(v_w_243), v_j_2458, heff_strLength_lent(v_w_243, 0));
      }
      V v_t_2460 = ({ V a_0 = heff_dup(v_ps_240); V a_1 = v_pkgs_241; V a_2 = heff_dup(v_k_2421); V a_3 = v_t_2457; V a_4 = v_t_2459; V r_ = (g_heff_2ebuild_2eload_2erequiredPlace(a_0, a_1, a_2, a_3, a_4)); heff_drop_tag(v_pkgs_241, 2); heff_drop(v_t_2457); r_; });
      V v_base_2461 = heff_dup(heff_rfield(v_ps_240, 2));
      V v_xs_2462 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str17); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str18), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2462));
      V v_parts_2467;
      switch (heff_tag_of(v_t_2463)) {
      case TAG_Nil: {
        v_parts_2467 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Cons: {
        V v_last_2464 = heff_field(v_t_2463, 0);
        V v_before_2465 = heff_field(v_t_2463, 1);
        V v_ru_24t_2463_24Cons = heff_take_reuse_n(v_t_2463, 3ULL, 2);
        V v_t_2466 = heff_tag_at_n(v_ru_24t_2463_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2464, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str19)), NTAG(TAG_Nil)});
        v_parts_2467 = (g_list_2efoldl_24s1370882877x364361272(v_t_2466, v_before_2465));
        break;
      }
      default: heff_nomatch(v_t_2463);
      }
      V v_t_2474 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam3, 2, 1, (V[]){heff_dup(v_ps_240)}), heff_dup(v_base_2461), v_parts_2467));
      V v_t_2475 = heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2474, v_base_2461, v_parts_2467, heff_dup(v_w_243)});
      V v_ys_2491;
      if (heff_strEq_c(heff_dup(heff_rfield(v_k_2421, 3)), ((V)&g_heff_2ebuild_2eload_2eplacesOf_str20))) {
        V v_x1_2476 = (g_heff_2ebuild_2eload_2einside(heff_dup(v_ps_240), heff_take_field(v_k_2421, 2), v_from_242));
        if (!(heff_dup(v_x1_2476) == NTAG(TAG_True))) {
          heff_drop(v_x1_2476);
          V v_base_2477 = heff_get_n(v_k_2421, 1, 7);
          V v_xs_2478 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2eplacesOf_str21); V a_1 = v_w_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2eplacesOf_str22), v_w_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
          V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2478));
          V v_parts_2483;
          switch (heff_tag_of(v_t_2479)) {
          case TAG_Nil: {
            v_parts_2483 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Cons: {
            V v_last_2480 = heff_field(v_t_2479, 0);
            V v_before_2481 = heff_field(v_t_2479, 1);
            V v_ru_24t_2479_24Cons = heff_take_reuse_n(v_t_2479, 3ULL, 2);
            V v_t_2482 = heff_tag_at_n(v_ru_24t_2479_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_last_2480, ((V)&g_heff_2ebuild_2eload_2eplacesOf_str23)), NTAG(TAG_Nil)});
            v_parts_2483 = (g_list_2efoldl_24s1370882877x364361272(v_t_2482, v_before_2481));
            break;
          }
          default: heff_nomatch(v_t_2479);
          }
          V v_t_2490 = (g_list_2efoldl(heff_clo_n(g_heff_2ebuild_2eload_2eplacesOf_lam4, 2, 1, (V[]){v_ps_240}), heff_dup(v_base_2477), v_parts_2483));
          v_ys_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_path__base__parts__module, (V[]){v_t_2490, v_base_2477, v_parts_2483, v_w_243}), NTAG(TAG_Nil)});
        } else {
          heff_drop_rec(v_ps_240, 6);
          heff_drop(v_w_243);
          heff_drop_rec(v_k_2421, 7);
          heff_drop(v_x1_2476);
          v_ys_2491 = NTAG(TAG_Nil);
        }
      } else {
        heff_drop_rec(v_ps_240, 6);
        heff_drop(v_from_242);
        heff_drop(v_w_243);
        heff_drop_rec(v_k_2421, 7);
        v_ys_2491 = NTAG(TAG_Nil);
      }
      V v_t_2492 = (g_prelude_2e_2b_2b(v_t_2460, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2475, v_ys_2491})));
      return (g_prelude_2e_2b_2b(v_t_2455, v_t_2492));
    }
    default: return heff_nomatch(v_pkgs_241);
    }
  }
}
V g_heff_2ebuild_2eload_2eplacesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eplacesOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2eload_2eplacesOf_lam0(V self, V *args) {
  V v_d_2412 = args[0];
  V v_p_2413 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2414 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_d_2412));
  V v_t_2416 = (g_std_2epath_2eparse(heff_dup(v_st_2414), v_p_2413));
  V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
  return ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam1(V self, V *args) {
  V v_d_2429 = args[0];
  V v_p_2430 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2431 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2431), v_d_2429));
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_2431), v_p_2430));
  V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
  return ({ V a_0 = v_st_2431; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2431); heff_drop(v_t_2434); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam2(V self, V *args) {
  V v_d_2448 = args[0];
  V v_p_2449 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2450 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2451 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_d_2448));
  V v_t_2452 = (g_std_2epath_2eparse(heff_dup(v_st_2450), v_p_2449));
  V v_t_2453 = (g_std_2epath_2ejoin(v_t_2451, v_t_2452));
  return ({ V a_0 = v_st_2450; V a_1 = v_t_2453; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2450); heff_drop(v_t_2453); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam3(V self, V *args) {
  V v_d_2468 = args[0];
  V v_p_2469 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2470 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2471 = (g_std_2epath_2eparse(heff_dup(v_st_2470), v_d_2468));
  V v_t_2472 = (g_std_2epath_2eparse(heff_dup(v_st_2470), v_p_2469));
  V v_t_2473 = (g_std_2epath_2ejoin(v_t_2471, v_t_2472));
  return ({ V a_0 = v_st_2470; V a_1 = v_t_2473; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2470); heff_drop(v_t_2473); r_; });
}
V g_heff_2ebuild_2eload_2eplacesOf_lam4(V self, V *args) {
  V v_d_2484 = args[0];
  V v_p_2485 = args[1];
  V v_ps_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_st_2486 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2487 = (g_std_2epath_2eparse(heff_dup(v_st_2486), v_d_2484));
  V v_t_2488 = (g_std_2epath_2eparse(heff_dup(v_st_2486), v_p_2485));
  V v_t_2489 = (g_std_2epath_2ejoin(v_t_2487, v_t_2488));
  return ({ V a_0 = v_st_2486; V a_1 = v_t_2489; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2486); heff_drop(v_t_2489); r_; });
}
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2esameButCase_str3, 0, "");
Clo g_heff_2ebuild_2eload_2esameButCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2esameButCase_entry, 2, 0};

V g_heff_2ebuild_2eload_2esameButCase(V v_a_240, V v_b_241) {
top: ;
  V v_x2_242 = (g_list_2emap_24f201346761x152404242(MK_INT(65LL), v_a_240, MK_INT(90LL), MK_INT(32LL), MK_INT(1LL), MK_INT(0LL), heff_strLength_lent(v_a_240, 0)));
  V v_t_245;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    v_t_245 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    v_t_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
    break;
  }
  default: heff_nomatch(v_x2_242);
  }
  V v_x2_246 = (g_list_2emap_24f201346761x152404242(MK_INT(65LL), v_b_241, MK_INT(90LL), MK_INT(32LL), MK_INT(1LL), MK_INT(0LL), heff_strLength_lent(v_b_241, 0)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2esameButCase_str3); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_245, v_t_249, 0));
  heff_drop(v_t_245);
  heff_drop(v_t_249);
  return v_ret_24bool;
}
V g_heff_2ebuild_2eload_2esameButCase_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eload_2esameButCase(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str0, 12, ": no module ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str3, 13, " (looked for ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str4, 1, ")");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str5, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str7, 4, " -> ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str8, 13, " is a cycle: ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str9, 12, ": importing ");
HEFF_LIT(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str10, 2, ": ");
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_entry, 11, 0};

V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(V v_lit_240, V v_e_241, V v_ev_242, V v_read_243, V v_ps_244, V v_pkgs_245, V v_stack_246, V v_from_247, V v_x7_248, V v_st_249, V v_rs_2410) {
top: ;
  switch (heff_tag_of(v_x7_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_e_241);
    heff_drop(v_ev_242);
    heff_drop(v_read_243);
    heff_drop(v_ps_244);
    heff_drop(v_pkgs_245);
    heff_drop(v_stack_246);
    heff_drop(v_from_247);
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam0, 2, 2, (V[]){v_st_249, v_rs_2410});
  }
  case TAG_Cons: {
    V v_w_2413 = heff_field(v_x7_248, 0);
    V v_rest_2414 = heff_field(v_x7_248, 1);
    heff_take_n(v_x7_248, 3ULL, 2);
    V v_t_2415 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_244), heff_dup(v_pkgs_245), heff_dup(v_from_247), heff_dup(v_w_2413)));
    V v_c_2416 = (g_heff_2ebuild_2eload_2ereadEvery(v_e_241, heff_dup(v_read_243), v_t_2415));
    return heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam1, 2, 13, (V[]){v_c_2416, v_ps_244, v_pkgs_245, v_from_247, v_w_2413, v_st_249, v_lit_240, v_e_241, v_ev_242, v_read_243, v_stack_246, v_rest_2414, v_rs_2410});
  }
  default: return heff_nomatch(v_x7_248);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_st_249 = heff_env(self)[0];
  V v_rs_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_st_249, v_rs_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam4(V self, V *args) {
  V v_x_2474 = args[0];
  V v_ps_244 = heff_env(self)[0];
  V v_module_2434 = heff_env(self)[1];
  V v_named_2438 = heff_env(self)[2];
  V v_path_2436 = heff_env(self)[3];
  V v_source_2437 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_w_2413 = heff_env(self)[6];
  V v_rs_2410 = heff_env(self)[7];
  V v_e_241 = heff_env(self)[8];
  V v_ev_242 = heff_env(self)[9];
  V v_read_243 = heff_env(self)[10];
  V v_pkgs_245 = heff_env(self)[11];
  V v_stack_246 = heff_env(self)[12];
  V v_from_247 = heff_env(self)[13];
  V v_rest_2414 = heff_env(self)[14];
  V v_hd_2417 = heff_env(self)[15];
  V v_k_2418 = heff_env(self)[16];
  heff_clo_take(self, 17);
  V v_t_2477;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_dup(heff_field(v_x_2474, 0));
    v_t_2477 = v_x_2475;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_t_2480;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_MkPair: {
    V v_y_2479 = heff_field(v_x_2474, 1);
    heff_take_n(v_x_2474, 2ULL, 2);
    v_t_2480 = v_y_2479;
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_t_2481 = (g_heff_2ebuild_2eload_2epushDone(v_t_2477, heff_dup(v_ps_244), heff_dup(v_module_2434), v_named_2438, v_path_2436, v_source_2437, heff_dup(v_lit_240), v_t_2480));
  V v_m_2482 = v_module_2434;
  V v_t_2483;
  if (heff_strEq_c_lent(v_w_2413, v_m_2482, 0)) {
    heff_drop(v_w_2413);
    heff_drop(v_m_2482);
    v_t_2483 = v_rs_2410;
  } else {
    v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2482}), v_rs_2410});
  }
  V v_t_2484 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(v_lit_240, v_e_241, v_ev_242, v_read_243, v_ps_244, v_pkgs_245, v_stack_246, v_from_247, v_rest_2414, v_t_2481, v_t_2483));
  V f_ = v_t_2484;
  heff_room[0] = v_hd_2417;
  heff_room[1] = v_k_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam3(V self, V *args) {
  V v_x_2462 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_source_2437 = heff_env(self)[1];
  V v_st_249 = heff_env(self)[2];
  V v_from_247 = heff_env(self)[3];
  V v_w_2413 = heff_env(self)[4];
  V v_e_241 = heff_env(self)[5];
  V v_ev_242 = heff_env(self)[6];
  V v_read_243 = heff_env(self)[7];
  V v_ps_244 = heff_env(self)[8];
  V v_pkgs_245 = heff_env(self)[9];
  V v_module_2434 = heff_env(self)[10];
  V v_stack_246 = heff_env(self)[11];
  V v_path_2436 = heff_env(self)[12];
  V v_hd_2417 = heff_env(self)[13];
  V v_named_2438 = heff_env(self)[14];
  V v_rs_2410 = heff_env(self)[15];
  V v_rest_2414 = heff_env(self)[16];
  V v_k_2418 = heff_env(self)[17];
  heff_clo_take(self, 18);
  V v_t_2463 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_dup(v_lit_240), heff_dup(v_source_2437)));
  V v_imps_2464 = heff_get_n(v_t_2463, 0, 4);
  V v_t_2465 = (g_list_2emap_24s1817208647x1282894070(v_imps_2464));
  V v_t_2466 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2465));
  V v_t_2472;
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Nothing: {
    v_t_2472 = v_st_249;
    break;
  }
  case TAG_Just: {
    V v_why_2467 = heff_field(v_x_2462, 0);
    heff_take_n(v_x_2462, 1ULL, 1);
    V v_t_2468 = heff_strAppend(heff_strAppend(heff_dup(v_from_247), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str9)), heff_dup(v_w_2413));
    V v_t_2469 = heff_strAppend(heff_strAppend(v_t_2468, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str10)), v_why_2467);
    V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
    V v_t_2471 = (g_prelude_2e_2b_2b(heff_take_field(v_st_249, 2), v_t_2470));
    v_t_2472 = ({ V rv_2 = v_t_2471; V rr_ = heff_rec_reuse_nf(v_st_249, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_x_2462);
  }
  V v_c_2473 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(heff_dup(v_lit_240), heff_dup(v_e_241), heff_dup(v_ev_242), heff_dup(v_read_243), heff_dup(v_ps_244), heff_dup(v_pkgs_245), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2434), heff_dup(v_stack_246)}), heff_dup(v_path_2436), v_t_2466, v_t_2472, NTAG(TAG_Nil)));
  V f_ = v_c_2473;
  heff_room[0] = heff_dup(v_hd_2417);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam4, 1, 17, (V[]){v_ps_244, v_module_2434, v_named_2438, v_path_2436, v_source_2437, v_lit_240, v_w_2413, v_rs_2410, v_e_241, v_ev_242, v_read_243, v_pkgs_245, v_stack_246, v_from_247, v_rest_2414, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ps_244 = heff_env(self)[0];
  V v_pkgs_245 = heff_env(self)[1];
  V v_from_247 = heff_env(self)[2];
  V v_w_2413 = heff_env(self)[3];
  V v_st_249 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_e_241 = heff_env(self)[6];
  V v_ev_242 = heff_env(self)[7];
  V v_read_243 = heff_env(self)[8];
  V v_stack_246 = heff_env(self)[9];
  V v_rest_2414 = heff_env(self)[10];
  V v_rs_2410 = heff_env(self)[11];
  V v_hd_2417 = heff_env(self)[12];
  V v_k_2418 = heff_env(self)[13];
  heff_clo_take(self, 14);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nil: {
    V v_places_2420 = (g_heff_2ebuild_2eload_2eplacesOf(heff_dup(v_ps_244), heff_dup(v_pkgs_245), heff_dup(v_from_247), heff_dup(v_w_2413)));
    V v_t_2421 = heff_strAppend(heff_strAppend(heff_dup(v_from_247), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str0)), v_w_2413);
    V v_x2_2422 = (g_list_2emap_24s435407392x1528135477(v_places_2420));
    V v_t_2425;
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_Nil: {
      v_t_2425 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_xs_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      v_t_2425 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str2); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2422);
    }
    V v_t_2426 = heff_strAppend(heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str3)), v_t_2425);
    V v_e_2427 = heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str4));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2427, NTAG(TAG_Nil)});
    V v_t_2429 = (g_prelude_2e_2b_2b(heff_take_field(v_st_249, 2), v_t_2428));
    V v_t_2430 = ({ V rv_2 = v_t_2429; V rr_ = heff_rec_reuse_nf(v_st_249, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2431 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(v_lit_240, v_e_241, v_ev_242, v_read_243, v_ps_244, v_pkgs_245, v_stack_246, v_from_247, v_rest_2414, v_t_2430, v_rs_2410));
    V f_ = v_t_2431;
    heff_room[0] = v_hd_2417;
    heff_room[1] = v_k_2418;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_f_2432 = heff_dup(heff_field(v_x_2419, 0));
    V v_others_2433 = heff_dup(heff_field(v_x_2419, 1));
    V v_module_2434 = heff_take_field(v_f_2432, 3);
    V v_place_2435 = heff_take_field(v_f_2432, 2);
    V v_path_2436 = heff_take_field(v_f_2432, 0);
    V v_source_2437 = heff_take_field(v_f_2432, 1);
    V v_named_2438 = heff_get_n(v_f_2432, 4, 5);
    V v_t_2439 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2434)}));
    V v_t_2440 = (g_list_2eany(v_t_2439, heff_rfield(v_st_249, 1)));
    if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
      heff_drop_tag(v_x_2419, 2);
      heff_drop(v_others_2433);
      heff_drop_rec(v_place_2435, 4);
      heff_drop(v_path_2436);
      heff_drop(v_source_2437);
      heff_drop(v_named_2438);
      heff_drop(v_t_2440);
      V v_m_2441 = v_module_2434;
      V v_t_2442;
      if (heff_strEq_c_lent(v_w_2413, v_m_2441, 0)) {
        heff_drop(v_w_2413);
        heff_drop(v_m_2441);
        v_t_2442 = v_rs_2410;
      } else {
        v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2441}), v_rs_2410});
      }
      V v_t_2443 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(v_lit_240, v_e_241, v_ev_242, v_read_243, v_ps_244, v_pkgs_245, v_stack_246, v_from_247, v_rest_2414, v_st_249, v_t_2442));
      V f_ = v_t_2443;
      heff_room[0] = v_hd_2417;
      heff_room[1] = v_k_2418;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2440);
      V v_t_2444 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_module_2434)}));
      V v_t_2445 = (g_list_2eany(v_t_2444, v_stack_246));
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop_tag(v_x_2419, 2);
        heff_drop(v_others_2433);
        heff_drop_rec(v_place_2435, 4);
        heff_drop(v_path_2436);
        heff_drop(v_source_2437);
        heff_drop(v_named_2438);
        heff_drop(v_t_2445);
        V v_m_2446 = heff_dup(v_module_2434);
        V v_t_2447 = heff_strAppend(heff_strAppend(heff_dup(v_from_247), ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str5)), heff_dup(v_m_2446));
        V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stack_246)));
        V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_2446, NTAG(TAG_Nil)});
        V v_x2_2450 = (g_prelude_2e_2b_2b(v_t_2448, v_t_2449));
        V v_t_2453;
        switch (heff_tag_of(v_x2_2450)) {
        case TAG_Nil: {
          v_t_2453 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2451 = heff_field(v_x2_2450, 0);
          V v_xs_2452 = heff_field(v_x2_2450, 1);
          heff_take_n(v_x2_2450, 3ULL, 2);
          v_t_2453 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str7); V a_1 = v_x_2451; V a_2 = v_xs_2452; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2452); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2450);
        }
        V v_e_2454 = heff_strAppend(heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_str8)), v_t_2453);
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_2454, NTAG(TAG_Nil)});
        V v_t_2456 = (g_prelude_2e_2b_2b(heff_take_field(v_st_249, 2), v_t_2455));
        V v_t_2457 = ({ V rv_2 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_st_249, 3ULL, 3, shape_done__doneMods__errors, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_m_2458 = v_module_2434;
        V v_t_2459;
        if (heff_strEq_c_lent(v_w_2413, v_m_2458, 0)) {
          heff_drop(v_w_2413);
          heff_drop(v_m_2458);
          v_t_2459 = v_rs_2410;
        } else {
          v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2458}), v_rs_2410});
        }
        V v_t_2460 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(v_lit_240, v_e_241, v_ev_242, v_read_243, v_ps_244, v_pkgs_245, v_stack_246, v_from_247, v_rest_2414, v_t_2457, v_t_2459));
        V f_ = v_t_2460;
        heff_room[0] = v_hd_2417;
        heff_room[1] = v_k_2418;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2445);
        switch (heff_tag_of(v_others_2433)) {
        case TAG_Nil: {
          heff_drop_tag(v_x_2419, 2);
          V v_c_2461 = ({ V a_0 = heff_dup(v_e_241); V a_1 = heff_dup(v_ev_242); V a_2 = heff_dup(v_ps_244); V a_3 = heff_take_field(v_place_2435, 1); V b_4 = heff_get_n(v_place_2435, 2, 4); V r_ = (g_heff_2ebuild_2eload_2epartsNamed(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
          V f_ = v_c_2461;
          heff_room[0] = heff_dup(v_hd_2417);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam3, 1, 18, (V[]){v_lit_240, v_source_2437, v_st_249, v_from_247, v_w_2413, v_e_241, v_ev_242, v_read_243, v_ps_244, v_pkgs_245, v_module_2434, v_stack_246, v_path_2436, v_hd_2417, v_named_2438, v_rs_2410, v_rest_2414, v_k_2418});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        case TAG_Cons: {
          V v_ru_24others_2433_24Cons = heff_take_reuse_n(v_others_2433, 0ULL, 2);
          heff_drop_rec(v_place_2435, 4);
          heff_drop(v_path_2436);
          heff_drop(v_source_2437);
          heff_drop(v_named_2438);
          V v_e_2487 = (g_heff_2ebuild_2eload_2eclashMsg(heff_dup(v_ps_244), v_x_2419, heff_dup(v_from_247), heff_dup(v_w_2413)));
          V v_t_2488 = heff_take_field(v_st_249, 0);
          V v_t_2489 = heff_take_field(v_st_249, 1);
          V v_t_2490 = heff_tag_at_n(v_ru_24others_2433_24Cons, TAG_Cons, 2, (V[]){v_e_2487, NTAG(TAG_Nil)});
          V v_t_2491 = (g_prelude_2e_2b_2b(heff_get_n(v_st_249, 2, 3), v_t_2490));
          V v_t_2492 = heff_rec_n(3, shape_done__doneMods__errors, (V[]){v_t_2488, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_module_2434), v_t_2489}), v_t_2491});
          V v_m_2493 = v_module_2434;
          V v_t_2494;
          if (heff_strEq_c_lent(v_w_2413, v_m_2493, 0)) {
            heff_drop(v_w_2413);
            heff_drop(v_m_2493);
            v_t_2494 = v_rs_2410;
          } else {
            v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_w_2413, v_m_2493}), v_rs_2410});
          }
          V v_t_2495 = (g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331(v_lit_240, v_e_241, v_ev_242, v_read_243, v_ps_244, v_pkgs_245, v_stack_246, v_from_247, v_rest_2414, v_t_2492, v_t_2494));
          V f_ = v_t_2495;
          heff_room[0] = v_hd_2417;
          heff_room[1] = v_k_2418;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
        default: return heff_nomatch(v_others_2433);
        }
      }
    }
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_ps_244 = heff_env(self)[1];
  V v_pkgs_245 = heff_env(self)[2];
  V v_from_247 = heff_env(self)[3];
  V v_w_2413 = heff_env(self)[4];
  V v_st_249 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_e_241 = heff_env(self)[7];
  V v_ev_242 = heff_env(self)[8];
  V v_read_243 = heff_env(self)[9];
  V v_stack_246 = heff_env(self)[10];
  V v_rest_2414 = heff_env(self)[11];
  V v_rs_2410 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eloadMany_24s1459522458x2012804331_lam2, 1, 14, (V[]){v_ps_244, v_pkgs_245, v_from_247, v_w_2413, v_st_249, v_lit_240, v_e_241, v_ev_242, v_read_243, v_stack_246, v_rest_2414, v_rs_2410, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str0, 8, "heff.sum");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str3, 8, "heff.sum");
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1, 1, 0};
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam4(V self, V *args);
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam3(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry, 1, 0};

V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), heff_dup(v_root_242)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_s_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0_clo)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam3, 2, 3, (V[]){v_c_2424, v_root_242, v_style_241});
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563(a[0]);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam2, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_style_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    V v_ru_24x_2427_24Left = heff_take_reuse_n(v_x_2427, 0ULL, 1);
    heff_drop(v_root_242);
    heff_drop(v_style_241);
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2427_24Left, TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
    V f_ = v_k_2426;
    args[0] = v_t_2429;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2430 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    V v_t_2431 = ({ V b_0 = ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str1); V a_1 = v_y_2430; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str2), v_y_2430, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    HeffT2 v_t_2432 = (g_heff_2ebuild_2eproject_2esumGo_24cpr(MK_INT(0LL), v_t_2431));
    V v_x_2444;
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((v_tag_2433 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2427_24Right, 1);
        V v_p_2435 = v_field_2434;
        V v_d_2436 = v_root_242;
        V v_st_2437 = v_style_241;
        V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2437), v_d_2436));
        V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_2437), ((V)&g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_str3)));
        V v_t_2440 = (g_std_2epath_2ejoin(v_t_2438, v_t_2439));
        V v_t_2441 = ({ V a_0 = v_st_2437; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2437); heff_drop(v_t_2440); r_; });
        V v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_y_2430; V a_2 = v_p_2435; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_y_2430); r_; });
        v_x_2444 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2442});
      } else {
        heff_drop(v_root_242);
        heff_drop(v_style_241);
        heff_drop(v_y_2430);
        V v_sums_2443 = v_field_2434;
        v_x_2444 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Right, 1, (V[]){v_sums_2443});
      }
    }
    V f_ = v_k_2426;
    args[0] = v_x_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_root_242 = heff_env(self)[1];
  V v_style_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadSumAt_24s207518346x358666563_lam4, 1, 3, (V[]){v_k_2426, v_root_242, v_style_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_str0, 1, " ");
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry, 7, 0};

V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(V v_lit_240, V v_lit_241, V v_lit_242, V v_root_243, V v_x3_244, V v_seen_245, V v_errs_246) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam0, 2, 2, (V[]){v_seen_245, v_errs_246});
  }
  case TAG_Cons: {
    V v_n_249 = heff_field(v_x3_244, 0);
    V v_rest_2410 = heff_field(v_x3_244, 1);
    heff_take_n(v_x3_244, 3ULL, 2);
    V v_path_2411 = heff_take_field(v_n_249, 1);
    V v_version_2412 = heff_take_field(v_n_249, 2);
    V v_by_2413 = heff_get_n(v_n_249, 0, 3);
    if (heff_strEq_c_lent(v_path_2411, v_root_243, 0)) {
      heff_drop(v_path_2411);
      heff_drop(v_version_2412);
      heff_drop(v_by_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_root_243;
      V t_4 = v_rest_2410;
      V t_5 = v_seen_245;
      V t_6 = v_errs_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_root_243 = t_3;
      v_x3_244 = t_4;
      v_seen_245 = t_5;
      v_errs_246 = t_6;
      goto top;
    } else {
      V v_t_2414 = (g_list_2eany_24s241416889x826324235(v_path_2411, v_version_2412, v_seen_245));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_path_2411);
        heff_drop(v_version_2412);
        heff_drop(v_by_2413);
        heff_drop(v_t_2414);
        V t_0 = v_lit_240;
        V t_1 = v_lit_241;
        V t_2 = v_lit_242;
        V t_3 = v_root_243;
        V t_4 = v_rest_2410;
        V t_5 = v_seen_245;
        V t_6 = v_errs_246;
        v_lit_240 = t_0;
        v_lit_241 = t_1;
        v_lit_242 = t_2;
        v_root_243 = t_3;
        v_x3_244 = t_4;
        v_seen_245 = t_5;
        v_errs_246 = t_6;
        goto top;
      } else {
        heff_drop(v_t_2414);
        V v_c_2415 = (g_heff_2ebuild_2eload_2ecachedPkg_24s701675316x651490596(heff_dup(v_lit_240), heff_dup(v_lit_241), heff_dup(v_lit_242), v_by_2413, heff_dup(v_path_2411), heff_dup(v_version_2412)));
        return heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam1, 2, 10, (V[]){v_c_2415, v_path_2411, v_version_2412, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, heff_dup(v_root_243), v_rest_2410});
      }
    }
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_seen_245 = heff_env(self)[0];
  V v_errs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_seen_245, v_errs_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_path_2411 = heff_env(self)[0];
  V v_version_2412 = heff_env(self)[1];
  V v_seen_245 = heff_env(self)[2];
  V v_errs_246 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_root_243 = heff_env(self)[7];
  V v_rest_2410 = heff_env(self)[8];
  V v_hd_2416 = heff_env(self)[9];
  V v_k_2417 = heff_env(self)[10];
  heff_clo_take(self, 11);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_why_2419 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2411, v_version_2412, NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    V v_t_2422 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2421));
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_why_2419, NTAG(TAG_Nil)});
    V v_t_2424 = (g_prelude_2e_2b_2b(v_errs_246, v_t_2423));
    V v_t_2425 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_rest_2410; V a_5 = v_t_2422; V a_6 = v_t_2424; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2425;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_pk_2426 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_t_2427 = heff_strAppend(heff_strAppend(heff_dup(v_path_2411), ((V)&g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_str0)), heff_dup(v_version_2412));
    V v_t_2428 = (g_list_2emap_24s675147852x248982264(v_t_2427, heff_dup(heff_rfield(v_pk_2426, 2))));
    V v_t_2429 = (g_prelude_2e_2b_2b(v_rest_2410, v_t_2428));
    V v_t_2430 = heff_rec_n(3, shape_path__version__pkg, (V[]){v_path_2411, v_version_2412, heff_tag_n(TAG_Just, 1, (V[]){v_pk_2426})});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2430, NTAG(TAG_Nil)});
    V v_t_2432 = (g_prelude_2e_2b_2b(v_seen_245, v_t_2431));
    V v_t_2433 = ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_root_243; V a_4 = v_t_2429; V a_5 = v_t_2432; V a_6 = v_errs_246; V r_ = (g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_root_243); r_; });
    V f_ = v_t_2433;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_path_2411 = heff_env(self)[1];
  V v_version_2412 = heff_env(self)[2];
  V v_seen_245 = heff_env(self)[3];
  V v_errs_246 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_root_243 = heff_env(self)[8];
  V v_rest_2410 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2eversionsGo_24s2140542769x315215559_lam2, 1, 11, (V[]){v_path_2411, v_version_2412, v_seen_245, v_errs_246, v_lit_240, v_lit_241, v_lit_242, v_root_243, v_rest_2410, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str2, 3, ".hf");
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0(V self, V *args); static Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0, 2, 0};
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam3(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry, 2, 0};

V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(V v_read_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    return ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0_clo);
  }
  case TAG_Cons: {
    V v_pl_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_read_240), 1, (V[]){heff_dup(heff_rfield(v_pl_244, 0))}));
    return heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam1, 2, 4, (V[]){v_c_246, v_read_240, v_rest_245, v_pl_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(a[0], a[1]);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_pl_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2422;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop_rec(v_pl_244, 4);
    v_x_2422 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_s_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2413 = heff_dup(heff_rfield(v_pl_244, 2));
    V v_p_2416;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nil: {
      v_p_2416 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_t_2413, 0);
      V v_xs_2415 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 3ULL, 2);
      v_p_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str1); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    int64_t v_t_2417 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
    V v_t_2418 = heff_strSlice(heff_dup(v_p_2416), heff_box_word(v_t_2417), heff_strLength_lent(v_p_2416, 0));
    V v_t_2420;
    if (heff_strEq_c(v_t_2418, ((V)&g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_str2))) {
      int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_p_2416, 0)) - ((int64_t)3ULL));
      v_t_2420 = heff_strSlice(v_p_2416, MK_INT(0LL), heff_box_word(v_t_2419));
    } else {
      v_t_2420 = v_p_2416;
    }
    V v_t_2421 = heff_rec_n(5, shape_path__source__place__module__named, (V[]){heff_dup(heff_rfield(v_pl_244, 0)), v_s_2412, heff_dup(v_pl_244), heff_get_n(v_pl_244, 3, 4), v_t_2420});
    v_x_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749(v_read_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam3, 1, 3, (V[]){v_x_249, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_pl_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2ereadEvery_24s1123276491x1216606749_lam2, 1, 5, (V[]){v_read_240, v_rest_245, v_hd_247, v_pl_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam0(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam2(V self, V *args);
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam1(V self, V *args);
Clo g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry, 7, 0};

V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(V v_read_240, V v_ps_241, V v_pkgs_242, V v_from_243, V v_before_244, V v_x6_245, V v_st_246) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_ps_241);
    heff_drop(v_pkgs_242);
    heff_drop(v_from_243);
    heff_drop(v_before_244);
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam0, 2, 1, (V[]){v_st_246});
  }
  case TAG_Cons: {
    V v_m_249 = heff_field(v_x6_245, 0);
    V v_ms_2410 = heff_field(v_x6_245, 1);
    V v_ru_24x6_245_24Cons = heff_take_reuse_n(v_x6_245, 3ULL, 2);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_m_249), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2ebuild_2eload_2eloadMany_24s1151546962x1114546131(heff_dup(v_before_244), heff_dup(v_read_240), heff_dup(v_ps_241), heff_dup(v_pkgs_242), NTAG(TAG_Nil), heff_dup(v_from_243), v_t_2411, v_st_246, NTAG(TAG_Nil)));
    return heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam1, 2, 8, (V[]){v_c_2412, v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_st_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_before_244 = heff_env(self)[1];
  V v_read_240 = heff_env(self)[2];
  V v_ps_241 = heff_env(self)[3];
  V v_pkgs_242 = heff_env(self)[4];
  V v_from_243 = heff_env(self)[5];
  V v_ms_2410 = heff_env(self)[6];
  V v_hd_2413 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_m_249, NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2e_2b_2b(v_before_244, v_t_2416));
  V v_t_2420;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 2);
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2421 = (g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029(v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_t_2417, v_ms_2410, v_t_2420));
  V f_ = v_t_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_m_249 = heff_env(self)[1];
  V v_before_244 = heff_env(self)[2];
  V v_read_240 = heff_env(self)[3];
  V v_ps_241 = heff_env(self)[4];
  V v_pkgs_242 = heff_env(self)[5];
  V v_from_243 = heff_env(self)[6];
  V v_ms_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2eload_2emadeOfGo_24s1680012839x278136029_lam2, 1, 9, (V[]){v_m_249, v_before_244, v_read_240, v_ps_241, v_pkgs_242, v_from_243, v_ms_2410, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}