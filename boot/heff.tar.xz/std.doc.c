// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AlreadyFlat 46113
#define TAG_Cat 14946
#define TAG_Column 1635
#define TAG_Fail 27959
#define TAG_FlatAlt 51908
#define TAG_Flattened 46143
#define TAG_Line 17963
#define TAG_Nest 8345
#define TAG_Nesting 4340
#define TAG_NeverFlat 31901
#define TAG_None 17785
#define TAG_SEmpty 4509
#define TAG_SFail 3389
#define TAG_SLine 58919
#define TAG_SText 31624
#define TAG_Text 56194
#define TAG_Union 35751
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ebest(V, V, V, V);
V g_std_2edoc_2ebest_entry(V self, V *a);
extern Clo g_std_2edoc_2ebest_clo;
V g_std_2edoc_2echanges(V);
V g_std_2edoc_2echanges_entry(V self, V *a);
extern Clo g_std_2edoc_2echanges_clo;
V g_std_2edoc_2econcatWith_24s650596433x61515523(V, V);
V g_std_2edoc_2econcatWith_24s650596433x61515523_entry(V self, V *a);
extern Clo g_std_2edoc_2econcatWith_24s650596433x61515523_clo;
V g_std_2edoc_2edisplayInto(V, V);
V g_std_2edoc_2edisplayInto_entry(V self, V *a);
extern Clo g_std_2edoc_2edisplayInto_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2efitsGo(V, V);
V g_std_2edoc_2efitsGo_entry(V self, V *a);
extern Clo g_std_2edoc_2efitsGo_clo;
V g_std_2edoc_2eflatten(V);
V g_std_2edoc_2eflatten_entry(V self, V *a);
extern Clo g_std_2edoc_2eflatten_clo;
V g_std_2edoc_2egroup(V);
V g_std_2edoc_2egroup_entry(V self, V *a);
extern Clo g_std_2edoc_2egroup_clo;
V g_std_2edoc_2ehardline_get(void);
V g_std_2edoc_2eline_get(void);
V g_std_2edoc_2elinebreak_get(void);
V g_std_2edoc_2espacesInto(V, V);
V g_std_2edoc_2espacesInto_entry(V self, V *a);
extern Clo g_std_2edoc_2espacesInto_clo;

static V g_std_2edoc_2eemptyDoc_val;
static int g_std_2edoc_2eemptyDoc_st;
static V g_std_2edoc_2eemptyDoc_init(void) {
  return NTAG(TAG_None);
}
V g_std_2edoc_2eemptyDoc_get(void) {
  if (g_std_2edoc_2eemptyDoc_st == 2) return g_std_2edoc_2eemptyDoc_val;
  if (g_std_2edoc_2eemptyDoc_st == 1) heff_fail("defined by itself");
  g_std_2edoc_2eemptyDoc_st = 1;
  g_std_2edoc_2eemptyDoc_val = heff_tr(g_std_2edoc_2eemptyDoc_init());
  g_std_2edoc_2eemptyDoc_st = 2;
  return g_std_2edoc_2eemptyDoc_val;
}

static V g_std_2edoc_2ehardline_val;
static int g_std_2edoc_2ehardline_st;
static V g_std_2edoc_2ehardline_init(void) {
  return NTAG(TAG_Line);
}
V g_std_2edoc_2ehardline_get(void) {
  if (g_std_2edoc_2ehardline_st == 2) return g_std_2edoc_2ehardline_val;
  if (g_std_2edoc_2ehardline_st == 1) heff_fail("defined by itself");
  g_std_2edoc_2ehardline_st = 1;
  g_std_2edoc_2ehardline_val = heff_tr(g_std_2edoc_2ehardline_init());
  g_std_2edoc_2ehardline_st = 2;
  return g_std_2edoc_2ehardline_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2edoc_2eline_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};

static V g_std_2edoc_2eline_val;
static int g_std_2edoc_2eline_st;
static V g_std_2edoc_2eline_init(void) {
  return heff_tag(TAG_FlatAlt, 2, (V[]){NTAG(TAG_Line), heff_tag(TAG_Text, 1, (V[]){((V)&g_std_2edoc_2eline_str0)})});
}
V g_std_2edoc_2eline_get(void) {
  if (g_std_2edoc_2eline_st == 2) return g_std_2edoc_2eline_val;
  if (g_std_2edoc_2eline_st == 1) heff_fail("defined by itself");
  g_std_2edoc_2eline_st = 1;
  g_std_2edoc_2eline_val = heff_tr(g_std_2edoc_2eline_init());
  g_std_2edoc_2eline_st = 2;
  return g_std_2edoc_2eline_val;
}

static V g_std_2edoc_2elinebreak_val;
static int g_std_2edoc_2elinebreak_st;
static V g_std_2edoc_2elinebreak_init(void) {
  return heff_tag(TAG_FlatAlt, 2, (V[]){NTAG(TAG_Line), NTAG(TAG_None)});
}
V g_std_2edoc_2elinebreak_get(void) {
  if (g_std_2edoc_2elinebreak_st == 2) return g_std_2edoc_2elinebreak_val;
  if (g_std_2edoc_2elinebreak_st == 1) heff_fail("defined by itself");
  g_std_2edoc_2elinebreak_st = 1;
  g_std_2edoc_2elinebreak_val = heff_tr(g_std_2edoc_2elinebreak_init());
  g_std_2edoc_2elinebreak_st = 2;
  return g_std_2edoc_2elinebreak_val;
}
Clo g_std_2edoc_2e_3c_3e_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2e_3c_3e_entry, 2, 0};

V g_std_2edoc_2e_3c_3e(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fail: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_None: {
    return v_x2_241;
  }
  case TAG_Text: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Line: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_FlatAlt: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cat: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Nest: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Union: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Column: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Nesting: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Fail: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_None: {
      return v_x1_240;
    }
    case TAG_Text: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Line: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_FlatAlt: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Cat: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nest: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Union: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Column: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    case TAG_Nesting: {
      return heff_tag(TAG_Cat, 2, (V[]){v_x1_240, v_x2_241});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2edoc_2e_3c_3e_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2e_3c_3e(a[0], a[1]);
}
V g_std_2edoc_2eflatten_lam0(V self, V *args);
V g_std_2edoc_2eflatten_lam1(V self, V *args);
Clo g_std_2edoc_2eflatten_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2eflatten_entry, 1, 0};

V g_std_2edoc_2eflatten(V v_other_240) {
top: ;
  switch (heff_tag_of(v_other_240)) {
  case TAG_Fail: {
    return v_other_240;
  }
  case TAG_None: {
    return v_other_240;
  }
  case TAG_Text: {
    return v_other_240;
  }
  case TAG_Line: {
    return NTAG(TAG_Fail);
  }
  case TAG_FlatAlt: {
    V v_y_243 = heff_field(v_other_240, 1);
    heff_take_n(v_other_240, 2ULL, 2);
    V t_0 = v_y_243;
    v_other_240 = t_0;
    goto top;
  }
  case TAG_Cat: {
    V v_x_244 = heff_field(v_other_240, 0);
    V v_y_245 = heff_field(v_other_240, 1);
    V v_ru_24other_240_24Cat = heff_take_reuse_n(v_other_240, 3ULL, 2);
    V v_t_246 = (g_std_2edoc_2eflatten(v_x_244));
    return heff_tag_at(v_ru_24other_240_24Cat, TAG_Cat, 2, (V[]){v_t_246, (g_std_2edoc_2eflatten(v_y_245))});
  }
  case TAG_Nest: {
    V v_i_247 = heff_field(v_other_240, 0);
    V v_x_248 = heff_field(v_other_240, 1);
    V v_ru_24other_240_24Nest = heff_take_reuse_n(v_other_240, 3ULL, 2);
    return heff_tag_at(v_ru_24other_240_24Nest, TAG_Nest, 2, (V[]){v_i_247, (g_std_2edoc_2eflatten(v_x_248))});
  }
  case TAG_Union: {
    V v_x_249 = heff_field(v_other_240, 0);
    heff_take_n(v_other_240, 1ULL, 2);
    V t_0 = v_x_249;
    v_other_240 = t_0;
    goto top;
  }
  case TAG_Column: {
    V v_f_2411 = heff_field(v_other_240, 0);
    V v_ru_24other_240_24Column = heff_take_reuse_n(v_other_240, 1ULL, 1);
    return heff_tag_at(v_ru_24other_240_24Column, TAG_Column, 1, (V[]){heff_clo(g_std_2edoc_2eflatten_lam0, 1, 1, (V[]){v_f_2411})});
  }
  case TAG_Nesting: {
    V v_f_2414 = heff_field(v_other_240, 0);
    V v_ru_24other_240_24Nesting = heff_take_reuse_n(v_other_240, 1ULL, 1);
    return heff_tag_at(v_ru_24other_240_24Nesting, TAG_Nesting, 1, (V[]){heff_clo(g_std_2edoc_2eflatten_lam1, 1, 1, (V[]){v_f_2414})});
  }
  default: return heff_nomatch(v_other_240);
  }
}
V g_std_2edoc_2eflatten_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2eflatten(a[0]);
}
V g_std_2edoc_2eflatten_lam0(V self, V *args) {
  V v_k_2412 = args[0];
  V v_f_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413 = heff_tr(heff_apply(v_f_2411, 1, (V[]){v_k_2412}));
  return (g_std_2edoc_2eflatten(v_t_2413));
}
V g_std_2edoc_2eflatten_lam1(V self, V *args) {
  V v_k_2415 = args[0];
  V v_f_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_apply(v_f_2414, 1, (V[]){v_k_2415}));
  return (g_std_2edoc_2eflatten(v_t_2416));
}
V g_std_2edoc_2echanges_lam0(V self, V *args);
V g_std_2edoc_2echanges_lam1(V self, V *args);
Clo g_std_2edoc_2echanges_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2echanges_entry, 1, 0};

V g_std_2edoc_2echanges(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fail: {
    return NTAG(TAG_NeverFlat);
  }
  case TAG_None: {
    return NTAG(TAG_AlreadyFlat);
  }
  case TAG_Text: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_AlreadyFlat);
  }
  case TAG_Line: {
    return NTAG(TAG_NeverFlat);
  }
  case TAG_FlatAlt: {
    V v_y_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return heff_tag(TAG_Flattened, 1, (V[]){(g_std_2edoc_2eflatten(v_y_243))});
  }
  case TAG_Cat: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_y_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cat = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_fx_246 = (g_std_2edoc_2echanges(heff_dup(v_x_244)));
    V v_fy_247 = (g_std_2edoc_2echanges(heff_dup(v_y_245)));
    switch (heff_tag_of(v_fx_246)) {
    case TAG_Flattened: {
      V v_x2_248 = heff_field(v_fx_246, 0);
      V v_ru_24fx_246_24Flattened = heff_take_reuse_n(v_fx_246, 1ULL, 1);
      heff_drop(v_x_244);
      switch (heff_tag_of(v_fy_247)) {
      case TAG_Flattened: {
        V v_y2_249 = heff_field(v_fy_247, 0);
        heff_take_n(v_fy_247, 1ULL, 1);
        heff_drop(v_y_245);
        return heff_tag_at(v_ru_24fx_246_24Flattened, TAG_Flattened, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cat, TAG_Cat, 2, (V[]){v_x2_248, v_y2_249})});
      }
      case TAG_AlreadyFlat: {
        return heff_tag_at(v_ru_24fx_246_24Flattened, TAG_Flattened, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cat, TAG_Cat, 2, (V[]){v_x2_248, v_y_245})});
      }
      case TAG_NeverFlat: {
        heff_drop(v_y_245);
        heff_drop_cell(v_ru_24x1_240_24Cat, 2);
        heff_drop(v_x2_248);
        heff_drop_cell(v_ru_24fx_246_24Flattened, 1);
        return NTAG(TAG_NeverFlat);
      }
      default: return heff_nomatch(v_fy_247);
      }
    }
    case TAG_AlreadyFlat: {
      heff_drop(v_y_245);
      switch (heff_tag_of(v_fy_247)) {
      case TAG_Flattened: {
        V v_y2_2410 = heff_field(v_fy_247, 0);
        V v_ru_24fy_247_24Flattened = heff_take_reuse_n(v_fy_247, 1ULL, 1);
        return heff_tag_at(v_ru_24fy_247_24Flattened, TAG_Flattened, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Cat, TAG_Cat, 2, (V[]){v_x_244, v_y2_2410})});
      }
      case TAG_AlreadyFlat: {
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x1_240_24Cat, 2);
        return NTAG(TAG_AlreadyFlat);
      }
      case TAG_NeverFlat: {
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x1_240_24Cat, 2);
        return NTAG(TAG_NeverFlat);
      }
      default: return heff_nomatch(v_fy_247);
      }
    }
    case TAG_NeverFlat: {
      heff_drop(v_x_244);
      heff_drop(v_y_245);
      heff_drop_cell(v_ru_24x1_240_24Cat, 2);
      heff_drop(v_fy_247);
      return NTAG(TAG_NeverFlat);
    }
    default: return heff_nomatch(v_fx_246);
    }
  }
  case TAG_Nest: {
    V v_i_2411 = heff_field(v_x1_240, 0);
    V v_x_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Nest = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_other_2413 = (g_std_2edoc_2echanges(v_x_2412));
    switch (heff_tag_of(v_other_2413)) {
    case TAG_Flattened: {
      V v_d_2414 = heff_field(v_other_2413, 0);
      V v_ru_24other_2413_24Flattened = heff_take_reuse_n(v_other_2413, 1ULL, 1);
      return heff_tag_at(v_ru_24other_2413_24Flattened, TAG_Flattened, 1, (V[]){heff_tag_at(v_ru_24x1_240_24Nest, TAG_Nest, 2, (V[]){v_i_2411, v_d_2414})});
    }
    case TAG_AlreadyFlat: {
      heff_drop(v_i_2411);
      heff_drop_cell(v_ru_24x1_240_24Nest, 2);
      return v_other_2413;
    }
    case TAG_NeverFlat: {
      heff_drop(v_i_2411);
      heff_drop_cell(v_ru_24x1_240_24Nest, 2);
      return v_other_2413;
    }
    default: return heff_nomatch(v_other_2413);
    }
  }
  case TAG_Union: {
    V v_x_2415 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return heff_tag(TAG_Flattened, 1, (V[]){v_x_2415});
  }
  case TAG_Column: {
    V v_f_2417 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Column = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24Column, TAG_Flattened, 1, (V[]){heff_tag(TAG_Column, 1, (V[]){heff_clo(g_std_2edoc_2echanges_lam0, 1, 1, (V[]){v_f_2417})})});
  }
  case TAG_Nesting: {
    V v_f_2420 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Nesting = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at(v_ru_24x1_240_24Nesting, TAG_Flattened, 1, (V[]){heff_tag(TAG_Nesting, 1, (V[]){heff_clo(g_std_2edoc_2echanges_lam1, 1, 1, (V[]){v_f_2420})})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_std_2edoc_2echanges_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2echanges(a[0]);
}
V g_std_2edoc_2echanges_lam0(V self, V *args) {
  V v_k_2418 = args[0];
  V v_f_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tr(heff_apply(v_f_2417, 1, (V[]){v_k_2418}));
  return (g_std_2edoc_2eflatten(v_t_2419));
}
V g_std_2edoc_2echanges_lam1(V self, V *args) {
  V v_k_2421 = args[0];
  V v_f_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2422 = heff_tr(heff_apply(v_f_2420, 1, (V[]){v_k_2421}));
  return (g_std_2edoc_2eflatten(v_t_2422));
}
Clo g_std_2edoc_2egroup_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2egroup_entry, 1, 0};

V g_std_2edoc_2egroup(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_Fail: {
    V v_t_241 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_241)) {
    case TAG_Flattened: {
      V v_d2_242 = heff_field(v_t_241, 0);
      heff_take_n(v_t_241, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_242, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_None: {
    V v_t_243 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Flattened: {
      V v_d2_244 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_244, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_Text: {
    V v_t_246 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_Flattened: {
      V v_d2_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_247, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_Line: {
    V v_t_248 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Flattened: {
      V v_d2_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_249, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_FlatAlt: {
    V v_a_2410 = heff_field(v_d_240, 0);
    V v_b_2411 = heff_field(v_d_240, 1);
    V v_ru_24d_240_24FlatAlt = heff_take_reuse_n(v_d_240, 3ULL, 2);
    V v_t_2412 = (g_std_2edoc_2echanges(heff_dup(v_b_2411)));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Flattened: {
      V v_b2_2413 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      heff_drop(v_b_2411);
      return heff_tag_at(v_ru_24d_240_24FlatAlt, TAG_Union, 2, (V[]){v_b2_2413, v_a_2410});
    }
    case TAG_AlreadyFlat: {
      return heff_tag_at(v_ru_24d_240_24FlatAlt, TAG_Union, 2, (V[]){v_b_2411, v_a_2410});
    }
    case TAG_NeverFlat: {
      heff_drop(v_b_2411);
      heff_drop_cell(v_ru_24d_240_24FlatAlt, 2);
      return v_a_2410;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_Cat: {
    V v_t_2416 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Flattened: {
      V v_d2_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_2417, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  case TAG_Nest: {
    V v_t_2420 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Flattened: {
      V v_d2_2421 = heff_field(v_t_2420, 0);
      heff_take_n(v_t_2420, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_2421, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_Union: {
    return v_d_240;
  }
  case TAG_Column: {
    V v_t_2425 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Flattened: {
      V v_d2_2426 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_2426, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_2425);
    }
  }
  case TAG_Nesting: {
    V v_t_2428 = (g_std_2edoc_2echanges(heff_dup(v_d_240)));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Flattened: {
      V v_d2_2429 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      return heff_tag(TAG_Union, 2, (V[]){v_d2_2429, v_d_240});
    }
    case TAG_AlreadyFlat: {
      return v_d_240;
    }
    case TAG_NeverFlat: {
      return v_d_240;
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_std_2edoc_2egroup_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2egroup(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2edoc_2espacesInto_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_std_2edoc_2espacesInto_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2espacesInto_entry, 2, 0};

V g_std_2edoc_2espacesInto(V v_n_240, V v_acc_241) {
top: ;
  V v_t_242 = heff_intLe(heff_dup(v_n_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_n_240);
    return v_acc_241;
  }
  case TAG_False: {
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = heff_strAppend(v_acc_241, ((V)&g_std_2edoc_2espacesInto_str0));
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2edoc_2espacesInto_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2espacesInto(a[0], a[1]);
}
Clo g_std_2edoc_2efitsGo_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2efitsGo_entry, 2, 0};

V g_std_2edoc_2efitsGo(V v_rem_240, V v_s_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_rem_240), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_rem_240);
    heff_drop(v_s_241);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    switch (heff_tag_of(v_s_241)) {
    case TAG_SEmpty: {
      heff_drop(v_rem_240);
      return NTAG(TAG_True);
    }
    case TAG_SFail: {
      heff_drop(v_rem_240);
      return NTAG(TAG_False);
    }
    case TAG_SText: {
      V v_t_243 = heff_field(v_s_241, 0);
      V v_c_244 = heff_field(v_s_241, 1);
      heff_take_n(v_s_241, 3ULL, 2);
      V v_t_245 = heff_intSub(v_rem_240, heff_strLength(v_t_243));
      V v_t_246 = heff_tr(heff_apply(v_c_244, 1, (V[]){NTAG(TAG_MkUnit)}));
      V t_0 = v_t_245;
      V t_1 = v_t_246;
      v_rem_240 = t_0;
      v_s_241 = t_1;
      goto top;
    }
    case TAG_SLine: {
      heff_take_n(v_s_241, 0ULL, 2);
      heff_drop(v_rem_240);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_s_241);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_std_2edoc_2efitsGo_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2efitsGo(a[0], a[1]);
}
V g_std_2edoc_2ebest_lam0(V self, V *args);
V g_std_2edoc_2ebest_lam1(V self, V *args);
Clo g_std_2edoc_2ebest_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2ebest_entry, 4, 0};

V g_std_2edoc_2ebest(V v_w_240, V v_nl_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_w_240);
    heff_drop(v_nl_241);
    heff_drop(v_k_242);
    return NTAG(TAG_SEmpty);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_ds_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_i_246 = heff_field(v_x41_244, 0);
      V v_d_247 = heff_field(v_x41_244, 1);
      V v_ru_24x41_244_24MkPair = heff_take_reuse_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_d_247)) {
      case TAG_Fail: {
        heff_drop(v_w_240);
        heff_drop(v_nl_241);
        heff_drop(v_k_242);
        heff_drop(v_ds_245);
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_i_246);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        return NTAG(TAG_SFail);
      }
      case TAG_None: {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_i_246);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        V t_0 = v_w_240;
        V t_1 = v_nl_241;
        V t_2 = v_k_242;
        V t_3 = v_ds_245;
        v_w_240 = t_0;
        v_nl_241 = t_1;
        v_k_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Text: {
        V v_s_248 = heff_field(v_d_247, 0);
        heff_take_n(v_d_247, 1ULL, 1);
        heff_drop(v_i_246);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        return heff_tag_at(v_ru_24x4_243_24Cons, TAG_SText, 2, (V[]){heff_dup(v_s_248), heff_clo(g_std_2edoc_2ebest_lam0, 1, 5, (V[]){v_k_242, v_s_248, v_w_240, v_nl_241, v_ds_245})});
      }
      case TAG_Line: {
        heff_drop(v_nl_241);
        heff_drop(v_k_242);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        return heff_tag_at(v_ru_24x4_243_24Cons, TAG_SLine, 2, (V[]){heff_dup(v_i_246), heff_clo(g_std_2edoc_2ebest_lam1, 1, 3, (V[]){v_w_240, v_i_246, v_ds_245})});
      }
      case TAG_FlatAlt: {
        V v_x_2412 = heff_field(v_d_247, 0);
        heff_take_n(v_d_247, 1ULL, 2);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        V v_t_2414 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_246, v_x_2412}), v_ds_245});
        V t_0 = v_w_240;
        V t_1 = v_nl_241;
        V t_2 = v_k_242;
        V t_3 = v_t_2414;
        v_w_240 = t_0;
        v_nl_241 = t_1;
        v_k_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Cat: {
        V v_x_2415 = heff_field(v_d_247, 0);
        V v_y_2416 = heff_field(v_d_247, 1);
        heff_take_n(v_d_247, 3ULL, 2);
        V v_t_2417 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_i_246), v_y_2416}), v_ds_245});
        V v_t_2418 = heff_tag_at(v_ru_24x41_244_24MkPair, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_246, v_x_2415}), v_t_2417});
        V t_0 = v_w_240;
        V t_1 = v_nl_241;
        V t_2 = v_k_242;
        V t_3 = v_t_2418;
        v_w_240 = t_0;
        v_nl_241 = t_1;
        v_k_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Nest: {
        V v_j_2419 = heff_field(v_d_247, 0);
        V v_x_2420 = heff_field(v_d_247, 1);
        heff_take_n(v_d_247, 3ULL, 2);
        V v_t_2421 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_intAdd(v_i_246, v_j_2419), v_x_2420});
        V t_0 = v_w_240;
        V t_1 = v_nl_241;
        V t_2 = v_k_242;
        V t_3 = heff_tag_at(v_ru_24x41_244_24MkPair, TAG_Cons, 2, (V[]){v_t_2421, v_ds_245});
        v_w_240 = t_0;
        v_nl_241 = t_1;
        v_k_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Union: {
        V v_x_2422 = heff_field(v_d_247, 0);
        V v_y_2423 = heff_field(v_d_247, 1);
        heff_take_n(v_d_247, 3ULL, 2);
        V v_t_2424 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){heff_dup(v_i_246), v_x_2422}), heff_dup(v_ds_245)});
        V v_l_2425 = (g_std_2edoc_2ebest(heff_dup(v_w_240), heff_dup(v_nl_241), heff_dup(v_k_242), v_t_2424));
        V v_a_2426 = heff_intSub(heff_dup(v_w_240), heff_dup(v_k_242));
        V v_b_2427 = heff_intSub(heff_dup(v_w_240), heff_intSub(heff_dup(v_k_242), heff_dup(v_nl_241)));
        V v_t_2428 = heff_intLe(heff_dup(v_a_2426), heff_dup(v_b_2427));
        V v_t_2429;
        switch (heff_tag_of(v_t_2428)) {
        case TAG_True: {
          heff_drop(v_b_2427);
          v_t_2429 = v_a_2426;
          break;
        }
        case TAG_False: {
          heff_drop(v_a_2426);
          v_t_2429 = v_b_2427;
          break;
        }
        default: heff_nomatch(v_t_2428);
        }
        V v_t_2430 = (g_std_2edoc_2efitsGo(v_t_2429, heff_dup(v_l_2425)));
        switch (heff_tag_of(v_t_2430)) {
        case TAG_True: {
          heff_drop(v_w_240);
          heff_drop(v_nl_241);
          heff_drop(v_k_242);
          heff_drop(v_ds_245);
          heff_drop(v_i_246);
          heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
          heff_drop(v_y_2423);
          return v_l_2425;
        }
        case TAG_False: {
          heff_drop(v_l_2425);
          V v_t_2431 = heff_tag_at(v_ru_24x41_244_24MkPair, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_246, v_y_2423}), v_ds_245});
          V t_0 = v_w_240;
          V t_1 = v_nl_241;
          V t_2 = v_k_242;
          V t_3 = v_t_2431;
          v_w_240 = t_0;
          v_nl_241 = t_1;
          v_k_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_t_2430);
        }
      }
      case TAG_Column: {
        V v_f_2432 = heff_field(v_d_247, 0);
        heff_take_n(v_d_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        V v_t_2433 = heff_tr(heff_apply(v_f_2432, 1, (V[]){heff_dup(v_k_242)}));
        V v_t_2434 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_246, v_t_2433}), v_ds_245});
        V t_0 = v_w_240;
        V t_1 = v_nl_241;
        V t_2 = v_k_242;
        V t_3 = v_t_2434;
        v_w_240 = t_0;
        v_nl_241 = t_1;
        v_k_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      case TAG_Nesting: {
        V v_f_2435 = heff_field(v_d_247, 0);
        heff_take_n(v_d_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x41_244_24MkPair, 2);
        V v_t_2436 = heff_tr(heff_apply(v_f_2435, 1, (V[]){heff_dup(v_i_246)}));
        V v_t_2437 = heff_tag_at(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_i_246, v_t_2436}), v_ds_245});
        V t_0 = v_w_240;
        V t_1 = v_nl_241;
        V t_2 = v_k_242;
        V t_3 = v_t_2437;
        v_w_240 = t_0;
        v_nl_241 = t_1;
        v_k_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_d_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_std_2edoc_2ebest_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2ebest(a[0], a[1], a[2], a[3]);
}
V g_std_2edoc_2ebest_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_s_248 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_nl_241 = heff_env(self)[3];
  V v_ds_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_249);
  V v_t_2410 = heff_intAdd(v_k_242, heff_strLength(v_s_248));
  return (g_std_2edoc_2ebest(v_w_240, v_nl_241, v_t_2410, v_ds_245));
}
V g_std_2edoc_2ebest_lam1(V self, V *args) {
  V v_u_2411 = args[0];
  V v_w_240 = heff_env(self)[0];
  V v_i_246 = heff_env(self)[1];
  V v_ds_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2411);
  return (g_std_2edoc_2ebest(v_w_240, heff_dup(v_i_246), v_i_246, v_ds_245));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2edoc_2edisplayInto_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_std_2edoc_2edisplayInto_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_std_2edoc_2edisplayInto_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2edisplayInto_entry, 2, 0};

V g_std_2edoc_2edisplayInto(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SEmpty: {
    return v_acc_240;
  }
  case TAG_SFail: {
    return v_acc_240;
  }
  case TAG_SText: {
    V v_t_242 = heff_field(v_x2_241, 0);
    V v_c_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(v_c_243, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = heff_strAppend(v_acc_240, v_t_242);
    V t_1 = v_t_244;
    v_acc_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SLine: {
    V v_i_245 = heff_field(v_x2_241, 0);
    V v_c_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(v_acc_240, heff_strAppend(((V)&g_std_2edoc_2edisplayInto_str0), (g_std_2edoc_2espacesInto(v_i_245, ((V)&g_std_2edoc_2edisplayInto_str1)))));
    V v_t_248 = heff_tr(heff_apply(v_c_246, 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_t_247;
    V t_1 = v_t_248;
    v_acc_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2edoc_2edisplayInto_entry(V self, V *a) {
  (void)self;
  return g_std_2edoc_2edisplayInto(a[0], a[1]);
}
Clo g_std_2edoc_2econcatWith_24s650596433x61515523_clo = {{0x80000000u, K_CLO, 0}, g_std_2edoc_2econcatWith_24s650596433x61515523_entry, 2, 0};

V g_std_2edoc_2econcatWith_24s650596433x61515523(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_None);
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      return heff_dup(v_d_242);
    }
    case TAG_Cons: {
      V v_a_246 = (g_std_2edoc_2econcatWith_24s650596433x61515523(heff_dup(v_lit_240), v_x22_243));
      V v_t_247 = (g_std_2edoc_2e_3c_3e(heff_tag(TAG_Text, 1, (V[]){v_lit_240}), v_a_246));
      HEFF_LAST return g_std_2edoc_2e_3c_3e(heff_dup(v_d_242), v_t_247);
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_std_2edoc_2econcatWith_24s650596433x61515523_entry(V self, V *a) {
  (void)self;
  V r = g_std_2edoc_2econcatWith_24s650596433x61515523(a[0], a[1]); heff_drop(a[1]); return r;
}