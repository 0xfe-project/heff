// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_HS 9084
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_args 9498020
#define LBL_asks 9499105
#define LBL_at 9882
#define LBL_base 9511832
#define LBL_count 296209705
#define LBL_deeper 611485124
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_env 310119
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_self 10021907
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_unrolled 706233391
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_deeper__env__self__at[] = {LBL_deeper, LBL_env, LBL_self, LBL_at};
static uint32_t shape_name__ver__recipe__asks__depth__safe__made[] = {LBL_name, LBL_ver, LBL_recipe, LBL_asks, LBL_depth, LBL_safe, LBL_made};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp, LBL_unrolled};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2edefaultTag_get(void);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enamesTag(V, V);
V g_heff_2ecompile_2eir_2enamesTag_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enamesTag_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(V, V, V);
V g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
HeffT2 g_heff_2ecompile_2eirtext_2ehashW_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallAsked_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(V, V);
V g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedAs_clo;
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedAs_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedAs_24tok2_clo;
HeffT2 g_heff_2ecompile_2esimplify_2easkedFor_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eatomsGiven(V, V);
V g_heff_2ecompile_2esimplify_2eatomsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eatomsGiven_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindPushable(V);
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo;
V g_heff_2ecompile_2esimplify_2ebodyTakes(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ebodyTakes_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebodyTakes_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ecopy_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2ecountArm(V, V, V);
V g_heff_2ecompile_2esimplify_2ecountArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecountArm_clo;
V g_heff_2ecompile_2esimplify_2eenvOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eenvOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eenvOf_clo;
V g_heff_2ecompile_2esimplify_2eetaCapturing(V);
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo;
V g_heff_2ecompile_2esimplify_2efieldBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldBound_clo;
V g_heff_2ecompile_2esimplify_2efieldValue(V);
V g_heff_2ecompile_2esimplify_2efieldValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldValue_clo;
V g_heff_2ecompile_2esimplify_2efieldsBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo;
V g_heff_2ecompile_2esimplify_2efoldCond(V);
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldCond_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2egivenTelling(V, V, V);
V g_heff_2ecompile_2esimplify_2egivenTelling_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egivenTelling_clo;
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandedOn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedOn_clo;
V g_heff_2ecompile_2esimplify_2ehandlerLike(V);
V g_heff_2ecompile_2esimplify_2ehandlerLike_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandlerLike_clo;
V g_heff_2ecompile_2esimplify_2einitL(V);
V g_heff_2ecompile_2esimplify_2einitL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_clo;
V g_heff_2ecompile_2esimplify_2einitL_24dps(V, V);
V g_heff_2ecompile_2esimplify_2einitL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_24dps_clo;
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarksOf(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarksOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarksOf_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eorMarks(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_clo;
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2epartialIn(V, V);
V g_heff_2ecompile_2esimplify_2epartialIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialIn_clo;
V g_heff_2ecompile_2esimplify_2epastLastUse(V, V, V);
V g_heff_2ecompile_2esimplify_2epastLastUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epastLastUse_clo;
V g_heff_2ecompile_2esimplify_2eposOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eposOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eposOf_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecipeAsks(V, V, V);
V g_heff_2ecompile_2esimplify_2erecipeAsks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecipeAsks_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven(V, V, V, V);
V g_heff_2ecompile_2esimplify_2erunsGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erunsGiven_clo;
V g_heff_2ecompile_2esimplify_2esettleDef(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleDef_clo;
HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esharedIn(V, V);
V g_heff_2ecompile_2esimplify_2esharedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esharedIn_clo;
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(V);
V g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945_clo;
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_clo;
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etagMarks(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etagMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagMarks_clo;
V g_heff_2ecompile_2esimplify_2etakenW(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2etakenW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakenW_clo;
V g_heff_2ecompile_2esimplify_2evaluesGiven(V, V, V);
V g_heff_2ecompile_2esimplify_2evaluesGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesGiven_clo;
V g_heff_2ecompile_2esimplify_2evaluesGiven_24dps(V, V, V, V);
V g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evaluesGiven_24dps_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eversAll_24cpr(V);
V g_heff_2ecompile_2espec_2ecallsOnce(V);
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsOnce_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
HeffT2 g_heff_2ecompile_2espec_2edictGo_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2espec_2enthS_24cpr(V, V);
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1155681438x1635771547(V, V, V, V, V, V);
V g_list_2eall_24s1155681438x1635771547_entry(V self, V *a);
extern Clo g_list_2eall_24s1155681438x1635771547_clo;
V g_list_2eall_24s1512314936x520990916(V);
V g_list_2eall_24s1512314936x520990916_entry(V self, V *a);
extern Clo g_list_2eall_24s1512314936x520990916_clo;
V g_list_2eall_24s44244667x1445755514(V, V);
V g_list_2eall_24s44244667x1445755514_entry(V self, V *a);
extern Clo g_list_2eall_24s44244667x1445755514_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24f1287822497x2111322144(V, V, V);
V g_list_2efoldl_24f1287822497x2111322144_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1287822497x2111322144_clo;
V g_list_2efoldl_24f1323813142x1311067101(V, V, V, V);
V g_list_2efoldl_24f1323813142x1311067101_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1323813142x1311067101_clo;
V g_list_2efoldl_24f2082849937x387822498(V, V, V, V);
V g_list_2efoldl_24f2082849937x387822498_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2082849937x387822498_clo;
V g_list_2efoldl_24s1061937638x829298692(V, V);
V g_list_2efoldl_24s1061937638x829298692_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1061937638x829298692_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_list_2ezipWith_24s528321443x971020870(V, V);
V g_list_2ezipWith_24s528321443x971020870_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s528321443x971020870_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2etraverse_24s2064368144x1684679122(V, V);
V g_prelude_2etraverse_24s2064368144x1684679122_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2064368144x1684679122_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1(V, V, V);
V g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_entry(V self, V *a);
extern Clo g_std_2eordmap_2elookup_24s305164685x44869932_24tok1_clo;
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
Clo g_heff_2ecompile_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2ebinOp_24cpr(v_p_240, v_x2_241, v_x3_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_245});
    } else {
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2efoldCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efoldCond_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2efoldCond(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return v_x1_240;
  }
  case TAG_CFalse: {
    return v_x1_240;
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_b_243 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CRel = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2ebinOp_24cpr(heff_dup(v_p_241), heff_dup(v_a_242), heff_dup(v_b_243)));
    V v_t_2410;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_p_241);
        heff_drop(v_a_242);
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x1_240_24CRel, 3);
        V v_v_247 = v_field_246;
        v_t_2410 = v_v_247;
      } else {
        heff_drop(v_field_246);
        V v_t_248 = (g_heff_2ecompile_2eir_2eisRel(v_p_241));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24CRel, TAG_CRel, 3, (V[]){v_p_241, v_a_242, v_b_243})});
        } else {
          heff_drop_cell(v_ru_24x1_240_24CRel, 3);
          heff_drop(v_t_248);
          V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
          v_t_2410 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_t_249})});
        }
      }
    }
    HEFF_LAST return g_heff_2ecompile_2eir_2econdOf(v_t_2410);
  }
  case TAG_CTest: {
    V v_e_2411 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2econdOf(v_e_2411);
  }
  case TAG_CNot: {
    V v_c_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CNot = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_x1_2413 = (g_heff_2ecompile_2esimplify_2efoldCond(v_c_2412));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_CTrue: {
      heff_drop_cell(v_ru_24x1_240_24CNot, 1);
      return NTAG(TAG_CFalse);
    }
    case TAG_CFalse: {
      heff_drop_cell(v_ru_24x1_240_24CNot, 1);
      return NTAG(TAG_CTrue);
    }
    case TAG_CRel: {
      return heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_x1_2413});
    }
    case TAG_CTest: {
      return heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_x1_2413});
    }
    case TAG_CNot: {
      V v_c_2418 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24CNot, 1);
      return v_c_2418;
    }
    case TAG_CIf: {
      return heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_x1_2413});
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  case TAG_CIf: {
    V v_a_2422 = heff_field(v_x1_240, 0);
    V v_b_2423 = heff_field(v_x1_240, 1);
    V v_c_2424 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2efoldCond(v_a_2422));
    V v_t_2426 = (g_heff_2ecompile_2esimplify_2efoldCond(v_b_2423));
    V v_t_2427 = (g_heff_2ecompile_2esimplify_2efoldCond(v_c_2424));
    return (g_heff_2ecompile_2eir_2econdIf(v_t_2425, v_t_2426, v_t_2427));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efoldCond(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2einitL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einitL_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2einitL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x12_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2einitL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einitL_24dps(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(V v_tags_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_tags_240)) {
  case TAG_Nil: {
    heff_drop(v_e_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_tags1_242 = heff_field(v_tags_240, 0);
    V v_tags2_243 = heff_field(v_tags_240, 1);
    switch (heff_tag_of(v_tags1_242)) {
    case TAG_MkPair: {
      V v_t_244 = heff_field(v_tags1_242, 0);
      V v_n_245 = heff_field(v_tags1_242, 1);
      switch (heff_tag_of(v_tags2_243)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_e_241)) {
        case TAG_EVar: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EGlobal: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELet: {
          heff_take_n(v_e_241, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERecord: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProj: {
          heff_take_n(v_e_241, 0ULL, 4);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          V v_u_2421 = heff_field(v_e_241, 0);
          V v_args_2422 = heff_field(v_e_241, 1);
          heff_take_n(v_e_241, 3ULL, 3);
          if ((heff_strEq_c_lent(v_t_244, v_u_2421, 0) && ({ V v_t_2496 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422)); int c_ = heff_intEq_c_lent(v_t_2496, v_n_245, 0); heff_drop(v_t_2496); c_; }))) {
            heff_drop(v_u_2421);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_args_2422}});
          } else {
            heff_drop(v_u_2421);
            heff_drop(v_args_2422);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_EMatch: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrim: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrimCall: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ECall: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          heff_take_nf(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStr: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBytes: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFixed: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat32: {
          heff_take_na(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAbandon: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBool: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESet: {
          heff_take_n(v_e_241, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EValues: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFix: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_e_241)}});
        }
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_e_241)) {
        case TAG_EVar: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EGlobal: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELet: {
          heff_take_n(v_e_241, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERecord: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProj: {
          heff_take_n(v_e_241, 0ULL, 4);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          V v_u_2462 = heff_field(v_e_241, 0);
          V v_args_2463 = heff_field(v_e_241, 1);
          heff_take_n(v_e_241, 3ULL, 3);
          if ((heff_strEq_c_lent(v_t_244, v_u_2462, 0) && ({ V v_t_2497 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2463)); int c_ = heff_intEq_c_lent(v_t_2497, v_n_245, 0); heff_drop(v_t_2497); c_; }))) {
            heff_drop(v_u_2462);
            V v_vs_2465 = (g_heff_2ecompile_2esimplify_2einitL(heff_dup(v_args_2463)));
            V v_x1_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2463));
            V v_t_2469;
            switch (heff_tag_of(v_x1_2466)) {
            case TAG_Nil: {
              v_t_2469 = NTAG(TAG_EAbandon);
              break;
            }
            case TAG_Cons: {
              V v_x_2467 = heff_field(v_x1_2466, 0);
              heff_take_n(v_x1_2466, 1ULL, 2);
              v_t_2469 = v_x_2467;
              break;
            }
            default: heff_nomatch(v_x1_2466);
            }
            HeffT2 v_t_2470 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_tags2_243, v_t_2469));
            {
              V v_field_2472 = v_t_2470.f[1];
              int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
              if ((v_tag_2471 == ((int64_t)0ULL))) {
                V v_ws_2473 = v_field_2472;
                V v_f_2474 = (g_prelude_2e_2b_2b(v_vs_2465, v_ws_2473));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2474}});
              } else {
                heff_drop(v_vs_2465);
                heff_drop(v_field_2472);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_u_2462);
            heff_drop(v_args_2463);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_EMatch: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrim: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrimCall: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ECall: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          heff_take_nf(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStr: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBytes: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFixed: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat32: {
          heff_take_na(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAbandon: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBool: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESet: {
          heff_take_n(v_e_241, 0ULL, 3);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EValues: {
          heff_take_n(v_e_241, 0ULL, 1);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFix: {
          heff_take_n(v_e_241, 0ULL, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_e_241)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_tags2_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_tags1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tags_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2ecountArm_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecountArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecountArm_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ecountArm(V v_arms_240, V v_a_241, V v_ts_242) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_a_241)) {
  case TAG_MkArm: {
    V v_t_243 = heff_field(v_a_241, 0);
    v_t_246 = heff_bool(heff_strEq_c(heff_dup(v_t_243), heff_dup(g_heff_2ecompile_2eir_2edefaultTag_get())));
    break;
  }
  default: heff_nomatch(v_a_241);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    return (g_list_2efoldl_24f1323813142x1311067101(MK_INT(1LL), MK_INT(0LL), heff_clo_n(g_heff_2ecompile_2esimplify_2ecountArm_lam0, 1, 1, (V[]){heff_dup(v_arms_240)}), v_ts_242));
  } else {
    heff_drop(v_t_246);
    V v_t_2412;
    switch (heff_tag_of(v_a_241)) {
    case TAG_MkArm: {
      V v_t_249 = heff_field(v_a_241, 0);
      v_t_2412 = heff_dup(v_t_249);
      break;
    }
    default: heff_nomatch(v_a_241);
    }
    return ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V a_3 = v_ts_242; V r_ = (g_list_2efoldl_24f2082849937x387822498(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
  }
}
V g_heff_2ecompile_2esimplify_2ecountArm_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2ecountArm(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2ecountArm_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_arms_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_248 = ({ V a_0 = v_u_247; V a_1 = v_arms_240; V r_ = (g_heff_2ecompile_2eir_2enamesTag(a_0, a_1)); heff_drop(v_u_247); heff_drop(v_arms_240); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
  heff_drop(v_x1_248);
  return v_ret_24bool;
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2efieldsBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldsBound_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2efieldsBound_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldsBound_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldsBound(V v_tag_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_tag_240);
    return ((V)&g_heff_2ecompile_2esimplify_2efieldsBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x2_241, 0);
    V v_argv_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(g_heff_2ecompile_2esimplify_2efieldBound(heff_dup(v_tag_240), v_a_244));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldsBound_lam1, 1, 3, (V[]){v_m_246, v_tag_240, v_argv_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efieldsBound(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_s_242});
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_tag_240 = heff_env(self)[1];
  V v_argv_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2esimplify_2efieldsBound(v_tag_240, v_argv_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_x_2420;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_bs_2415 = heff_field(v_x_249, 0);
        V v_e_2416 = heff_field(v_x_249, 1);
        V v_ru_24x_249_24MkPair = heff_take_reuse_n(v_x_249, 3ULL, 2);
        switch (heff_tag_of(v_x_2413)) {
        case TAG_MkPair: {
          V v_rest_2417 = heff_field(v_x_2413, 0);
          V v_es_2418 = heff_field(v_x_2413, 1);
          V v_ru_24x_2413_24MkPair = heff_take_reuse_n(v_x_2413, 3ULL, 2);
          V v_t_2419 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x_2413_24MkPair, v_bs_2415, v_rest_2417));
          v_x_2420 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, heff_tag_at_n(v_ru_24x_249_24MkPair, TAG_Cons, 2, (V[]){v_e_2416, v_es_2418})});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2ecompile_2esimplify_2emarksOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarksOf_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2emarksOf(V v_all_240, V v_back_241, V v_g_242, V v_xs_243, V v_b_244, V v_argv_245) {
top: ;
  V v_t_246 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
  V v_xs_247 = (g_heff_2ecompile_2eir_2enubI(v_t_246));
  V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_g_242)}));
  V v_loop_249 = ({ V a_0 = v_t_248; V a_1 = v_xs_247; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_247); r_; });
  V v_t_2411;
  if ((heff_dup(v_loop_249) == NTAG(TAG_True))) {
    V v_t_2410 = (g_heff_2ecompile_2espec_2eusesOf(v_g_242, v_b_244));
    v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_xs_243; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
  } else {
    heff_drop(v_g_242);
    heff_drop(v_b_244);
    v_t_2411 = (g_list_2emap_24s73473062x206541869(v_xs_243));
  }
  HEFF_LAST return g_heff_2ecompile_2esimplify_2emarkGo(v_loop_249, v_all_240, v_back_241, v_argv_245, v_t_2411, MK_INT(0LL));
}
V g_heff_2ecompile_2esimplify_2emarksOf_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2esimplify_2emarksOf(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2esimplify_2eallAsked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallAsked_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallAsked(V v_x1_240, V v_p_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(v_x1_240, v_p_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallAsked(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eorMarks(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return v_x1_240;
  }
  case TAG_Cons: {
    V v_m_242 = heff_dup(heff_field(v_x1_240, 0));
    V v_ms_243 = heff_dup(heff_field(v_x1_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      return v_x1_240;
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_x2_241, 0);
      V v_ns_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_x1_240, 2);
      V v_t_246 = heff_bool(((heff_dup(v_m_242) == NTAG(TAG_True)) || (heff_dup(v_n_244) == NTAG(TAG_True))));
      heff_drop(v_m_242);
      heff_drop(v_n_244);
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2esimplify_2eorMarks_24dps(v_ms_243, v_ns_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2efieldValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldValue_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2efieldValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_argv_2417 = heff_field(v_x1_240, 1);
    return (g_list_2eall(((V)&g_heff_2ecompile_2esimplify_2efieldValue_clo), v_argv_2417));
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2efieldValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2efieldValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebodyTakes_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ebodyTakes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebodyTakes_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2ebodyTakes(V v_go_240, V v_fo_241, V v_h_242, V v_argv_243, V v_k_244, V v_x6_245) {
top: ;
  V v_deeper_246 = heff_take_field(v_fo_241, 0);
  V v_env_247 = heff_get_n(v_fo_241, 1, 4);
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop(v_go_240);
    heff_drop(v_h_242);
    heff_drop(v_argv_243);
    heff_drop(v_k_244);
    heff_drop(v_deeper_246);
    heff_drop(v_env_247);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x61_248 = heff_field(v_x6_245, 0);
    switch (heff_tag_of(v_x61_248)) {
    case TAG_EVar: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_ys_2411 = heff_field(v_x61_248, 0);
      V v_hb_2412 = heff_field(v_x61_248, 1);
      if (heff_intLt_c_lent(MK_INT(0LL), v_deeper_246, 1)) {
        V v_x_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ys_2411));
        if (heff_intLt_c_lent(v_k_244, v_x_2413, 2)) {
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_hb_2412), NTAG(TAG_Nil)});
          V v_x_2415 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(400LL), MK_INT(0LL), v_t_2414));
          if (!heff_intLt_c_lent(MK_INT(400LL), v_x_2415, 1)) {
            heff_drop(v_x_2415);
            V v_t_2416 = (g_heff_2ecompile_2esimplify_2eenvOf(v_env_247, heff_dup(v_ys_2411), v_argv_243));
            V v_t_2417 = heff_rec_n(4, shape_deeper__env__self__at, (V[]){heff_intSub(v_deeper_246, MK_INT(1LL)), v_t_2416, v_h_242, heff_dup(v_k_244)});
            HeffT2 v_t_2418 = (g_heff_2ecompile_2espec_2enthS_24cpr(v_k_244, v_ys_2411));
            V v_t_2422;
            {
              V v_field_2420 = v_t_2418.f[1];
              int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
              if ((v_tag_2419 == ((int64_t)0ULL))) {
                V v_x_2421 = v_field_2420;
                v_t_2422 = v_x_2421;
              } else {
                heff_drop(v_field_2420);
                v_t_2422 = ((V)&g_heff_2ecompile_2esimplify_2ebodyTakes_str0);
              }
            }
            V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_hb_2412), NTAG(TAG_Nil)});
            V v_x_2424 = heff_tr(heff_call(v_go_240, 3, (V[]){v_t_2417, v_t_2422, v_t_2423}));
            V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2424, 1));
            heff_drop(v_x_2424);
            return v_ret_24bool;
          } else {
            heff_drop(v_go_240);
            heff_drop(v_h_242);
            heff_drop(v_argv_243);
            heff_drop(v_k_244);
            heff_drop(v_deeper_246);
            heff_drop(v_env_247);
            heff_drop(v_x_2415);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop(v_go_240);
          heff_drop(v_h_242);
          heff_drop(v_argv_243);
          heff_drop(v_k_244);
          heff_drop(v_deeper_246);
          heff_drop(v_env_247);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_go_240);
        heff_drop(v_h_242);
        heff_drop(v_argv_243);
        heff_drop(v_k_244);
        heff_drop(v_deeper_246);
        heff_drop(v_env_247);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_go_240);
      heff_drop(v_h_242);
      heff_drop(v_argv_243);
      heff_drop(v_k_244);
      heff_drop(v_deeper_246);
      heff_drop(v_env_247);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x61_248);
    }
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ecompile_2esimplify_2ebodyTakes_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2esimplify_2ebodyTakes(a[0], a[1], a[2], a[3], a[4], a5); heff_drop(a5); return r;
}
V g_heff_2ecompile_2esimplify_2etakenW_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etakenW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakenW_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2etakenW(V v_s_240, V v_fo_241, V v_x_242, V v_n_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_s_240);
    heff_drop(v_fo_241);
    return v_n_243;
  }
  case TAG_Cons: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    V v_rest_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      V v_y_247 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 1);
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      if (heff_strEq_c_lent(v_x_242, v_y_247, 2)) {
        heff_drop(v_s_240);
        heff_drop(v_fo_241);
        heff_drop(v_n_243);
        heff_drop(v_rest_246);
        return MK_INT(-1LL);
      } else {
        V t_0 = v_s_240;
        V t_1 = v_fo_241;
        V t_2 = v_x_242;
        V t_3 = v_n_243;
        V t_4 = v_rest_246;
        v_s_240 = t_0;
        v_fo_241 = t_1;
        v_x_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
    }
    case TAG_EApp: {
      V v_f_248 = heff_field(v_x51_245, 0);
      V v_argv_249 = heff_field(v_x51_245, 1);
      V v_ru_24x51_245_24EApp = heff_take_reuse_n(v_x51_245, 3ULL, 2);
      V v_x1_2410 = (g_heff_2ecompile_2esimplify_2eposOf(v_x_242, MK_INT(0LL), heff_dup(v_argv_249)));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_Nil: {
        V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x51_245_24EApp, v_argv_249, v_rest_246));
        V t_0 = v_s_240;
        V t_1 = v_fo_241;
        V t_2 = v_x_242;
        V t_3 = v_n_243;
        V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2411});
        v_s_240 = t_0;
        v_fo_241 = t_1;
        v_x_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2410, 0ULL, 2);
        heff_drop_cell(v_ru_24x51_245_24EApp, 2);
        V v_t_2414 = (g_heff_2ecompile_2esimplify_2eposOf(v_x_242, MK_INT(0LL), heff_dup(v_argv_249)));
        V v_t_2418 = (g_list_2eall_24s1155681438x1635771547(heff_clo_n(g_heff_2ecompile_2esimplify_2etakenW_lam0, 3, 1, (V[]){heff_dup(v_s_240)}), heff_dup(v_s_240), heff_dup(v_fo_241), heff_dup(v_f_248), heff_dup(v_argv_249), v_t_2414));
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_t_2418);
          V v_t_2419 = (g_heff_2ecompile_2eir_2eappendI_24f590782778x1081006568(v_rest_246, v_x_242, v_argv_249));
          V t_0 = v_s_240;
          V t_1 = v_fo_241;
          V t_2 = v_x_242;
          V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
          V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_f_248, v_t_2419});
          v_s_240 = t_0;
          v_fo_241 = t_1;
          v_x_242 = t_2;
          v_n_243 = t_3;
          v_x5_244 = t_4;
          goto top;
        } else {
          heff_drop(v_s_240);
          heff_drop(v_fo_241);
          heff_drop(v_n_243);
          heff_drop(v_rest_246);
          heff_drop_cell(v_ru_24x5_244_24Cons, 2);
          heff_drop(v_f_248);
          heff_drop(v_argv_249);
          heff_drop(v_t_2418);
          return MK_INT(-1LL);
        }
      }
      default: return heff_nomatch(v_x1_2410);
      }
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x51_245, 0);
      heff_take_n(v_x51_245, 1ULL, 4);
      V v_t_2463;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_EVar: {
        V v_y_2424 = heff_dup(heff_field(v_e_2420, 0));
        v_t_2463 = heff_bool(heff_strEq_c_lent(v_x_242, v_y_2424, 0));
        heff_drop(v_y_2424);
        break;
      }
      case TAG_EGlobal: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_e_2420);
        heff_drop(v_t_2463);
        V t_0 = v_s_240;
        V t_1 = v_fo_241;
        V t_2 = v_x_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        V t_4 = v_rest_246;
        v_s_240 = t_0;
        v_fo_241 = t_1;
        v_x_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2463);
        V t_0 = v_s_240;
        V t_1 = v_fo_241;
        V t_2 = v_x_242;
        V t_3 = v_n_243;
        V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_246});
        v_s_240 = t_0;
        v_fo_241 = t_1;
        v_x_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
    }
    case TAG_EMatch: {
      V v_sc_2464 = heff_field(v_x51_245, 0);
      V v_arms_2465 = heff_field(v_x51_245, 1);
      heff_take_n(v_x51_245, 3ULL, 2);
      V v_t_24105;
      switch (heff_tag_of(v_sc_2464)) {
      case TAG_EVar: {
        V v_y_2466 = heff_dup(heff_field(v_sc_2464, 0));
        v_t_24105 = heff_bool(heff_strEq_c_lent(v_x_242, v_y_2466, 0));
        heff_drop(v_y_2466);
        break;
      }
      case TAG_EGlobal: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_24105 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sc_2464);
      }
      if ((heff_dup(v_t_24105) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24Cons, 2);
        heff_drop(v_sc_2464);
        heff_drop(v_t_24105);
        V v_t_24106 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2465, v_rest_246));
        V t_0 = v_s_240;
        V t_1 = v_fo_241;
        V t_2 = v_x_242;
        V t_3 = heff_intAdd(v_n_243, MK_INT(1LL));
        V t_4 = v_t_24106;
        v_s_240 = t_0;
        v_fo_241 = t_1;
        v_x_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_24105);
        V v_t_24107 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2465, v_rest_246));
        V t_0 = v_s_240;
        V t_1 = v_fo_241;
        V t_2 = v_x_242;
        V t_3 = v_n_243;
        V t_4 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, (V[]){v_sc_2464, v_t_24107});
        v_s_240 = t_0;
        v_fo_241 = t_1;
        v_x_242 = t_2;
        v_n_243 = t_3;
        v_x5_244 = t_4;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x5_244_24Cons, 2);
      V v_t_24108 = (g_heff_2ecompile_2eir_2epartsOnto(v_x51_245, v_rest_246));
      V t_0 = v_s_240;
      V t_1 = v_fo_241;
      V t_2 = v_x_242;
      V t_3 = v_n_243;
      V t_4 = v_t_24108;
      v_s_240 = t_0;
      v_fo_241 = t_1;
      v_x_242 = t_2;
      v_n_243 = t_3;
      v_x5_244 = t_4;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2etakenW_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2etakenW(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2etakenW_lam0(V self, V *args) {
  V v_fo2_2415 = args[0];
  V v_y_2416 = args[1];
  V v_w_2417 = args[2];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_s_240; V a_1 = v_fo2_2415; V a_2 = v_y_2416; V a_3 = MK_INT(0LL); V a_4 = v_w_2417; V r_ = (g_heff_2ecompile_2esimplify_2etakenW(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_y_2416); r_; });
}
Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaCapturing_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eetaCapturing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (!heff_intLt_c_lent(MK_INT(60LL), v_x_246, 1)) {
      heff_drop(v_x_246);
      V v_t_247 = (g_heff_2ecompile_2eir_2epartsOnto_24s1437190978x1983322794(v_xs_243, heff_dup(v_b_244), NTAG(TAG_Nil)));
      V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_list_2eall_24s1512314936x520990916(a_0)); heff_drop(v_t_247); r_; });
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_xs_243);
        heff_drop(v_b_244);
        heff_drop(v_t_248);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_248);
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
        V v_x_2410 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_249));
        if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2410, 1)) {
          heff_drop(v_x_2410);
          return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsOnce(b_0)); heff_drop(b_0); r_; });
        } else {
          heff_drop(v_xs_243);
          heff_drop(v_b_244);
          heff_drop(v_x_2410);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_x_246);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
      V v_x_2412 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2411));
      if (!heff_intLt_c_lent(MK_INT(60LL), v_x_2412, 1)) {
        heff_drop(v_x_2412);
        return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsOnce(b_0)); heff_drop(b_0); r_; });
      } else {
        heff_drop(v_xs_243);
        heff_drop(v_b_244);
        heff_drop(v_x_2412);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaCapturing(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2eletsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOut_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eletsOut(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletsOut(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindPushable_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindPushable_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2ebindPushable_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindPushable_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2ebindPushable_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindPushable_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindPushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ebindPushable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2ebindPushable_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_245 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_a_243)));
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2ecompile_2esimplify_2ebindPushable_lam1, 1, 2, (V[]){v_x1_245, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindPushable_lam2, 2, 1, (V[]){v_argv_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindPushable(a[0]);
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_s_241});
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam1(V self, V *args) {
  V v_p_246 = args[0];
  V v_x1_245 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_x1_245);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_246});
  } else {
    heff_drop(v_x1_245);
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ebindPushable_str0), v_p_246));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2411), v_a_243})});
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2412});
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam2(V self, V *args) {
  V v_one_2415 = args[0];
  V v_z_2416 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2417 = heff_tr(g_heff_2ecompile_2esimplify_2ebindPushable(v_argv_244));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_2416}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_x11_2421 = heff_field(v_one_2415, 0);
      V v_a_2422 = heff_field(v_one_2415, 1);
      V v_ru_24one_2415_24MkPair = heff_take_reuse_n(v_one_2415, 3ULL, 2);
      switch (heff_tag_of(v_x11_2421)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2419)) {
        case TAG_MkPair: {
          V v_bds_2423 = heff_field(v_x_2419, 0);
          V v_argv_2424 = heff_field(v_x_2419, 1);
          heff_take_n(v_x_2419, 3ULL, 2);
          v_t_2428 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2423, heff_tag_at_n(v_ru_24one_2415_24MkPair, TAG_Cons, 2, (V[]){v_a_2422, v_argv_2424})});
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2425 = heff_field(v_x11_2421, 0);
        heff_take_n(v_x11_2421, 1ULL, 1);
        switch (heff_tag_of(v_x_2419)) {
        case TAG_MkPair: {
          V v_bds_2426 = heff_field(v_x_2419, 0);
          V v_argv_2427 = heff_field(v_x_2419, 1);
          V v_ru_24x_2419_24MkPair = heff_take_reuse_n(v_x_2419, 3ULL, 2);
          v_t_2428 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24one_2415_24MkPair, TAG_Cons, 2, (V[]){v_bd_2425, v_bds_2426}), heff_tag_at_n(v_ru_24x_2419_24MkPair, TAG_Cons, 2, (V[]){v_a_2422, v_argv_2427})});
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        break;
      }
      default: heff_nomatch(v_x11_2421);
      }
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
Clo g_heff_2ecompile_2esimplify_2eatomsGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eatomsGiven_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eatomsGiven(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x1_240, 0);
    V v_ys_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return heff_dup(g_std_2eordmap_2eempty_get());
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_x2_241, 0);
      V v_vs_245 = heff_field(v_x2_241, 1);
      V v_t_2445;
      switch (heff_tag_of(v_v_244)) {
      case TAG_EVar: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_ELam: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EFixed: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_244);
      }
      if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
        heff_drop(v_t_2445);
        V v_t_2446 = (g_heff_2ecompile_2esimplify_2eatomsGiven(v_ys_243, v_vs_245));
        return (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2446, heff_dup(v_y_242), heff_dup(v_v_244)));
      } else {
        heff_drop(v_t_2445);
        V t_0 = v_ys_243;
        V t_1 = v_vs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eatomsGiven_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eatomsGiven(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2evaluesGiven_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evaluesGiven_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2evaluesGiven(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_y_243);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x3_242, 0);
      V v_vs_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2446;
      switch (heff_tag_of(v_v_245)) {
      case TAG_EVar: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ELam: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EStr: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_245);
      }
      if (((heff_dup(v_t_2446) == NTAG(TAG_True)) || ({ V v_c_2453 = (g_heff_2ecompile_2eir_2eisValue(v_v_245)); int c_ = ((heff_dup(v_c_2453) == NTAG(TAG_True)) && ({ V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2448 = (g_heff_2ecompile_2eir_2ecountW(v_y_243, MK_INT(0LL), heff_dup(v_t_2447))); int c_ = ({ V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2450 = (g_heff_2ecompile_2eir_2elamW(v_y_243, heff_dup(v_t_2449))); int c_ = ({ V v_t_2454 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2448), heff_dup(v_t_2450)}), 0, 2); int c_ = heff_intEq_c_lent(v_t_2454, MK_INT(0LL), 2); heff_drop(v_t_2454); c_; }); heff_drop(v_t_2450); c_; }); heff_drop(v_t_2449); c_; }); heff_drop(v_t_2448); c_; }); heff_drop(v_t_2447); c_; })); heff_drop(v_c_2453); c_; }))) {
        heff_drop(v_y_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_v_245);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2446);
        V t_0 = v_b_240;
        V t_1 = v_ys_244;
        V t_2 = v_vs_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_t_2446);
        V v_cell_2451 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){v_y_243, v_v_245}), heff_hole()});
        V v_u_2452 = (g_heff_2ecompile_2esimplify_2evaluesGiven_24dps(v_b_240, v_ys_244, v_vs_246, heff_dup(v_cell_2451)));
        heff_drop(v_u_2452);
        return v_cell_2451;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2evaluesGiven_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2evaluesGiven(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2egivenTelling_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2egivenTelling_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2egivenTelling(V v_b_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_b_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_b_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x3_242, 0);
      V v_vs_246 = heff_field(v_x3_242, 1);
      V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
      V v_t_2446;
      switch (heff_tag_of(v_v_245)) {
      case TAG_EVar: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_v_245, 0ULL, 3);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_v_245, 0ULL, 4);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_v_245, 0ULL, 3);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_v_245, 0ULL, 3);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_v_245, 0ULL, 1);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_v_245, 0ULL, 2);
        v_t_2446 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_v_245);
      }
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_t_2447 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        V v_t_2448 = (g_heff_2ecompile_2eir_2ecountW(v_x_243, MK_INT(0LL), v_t_2447));
        V v_t_2449 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_b_240), NTAG(TAG_Nil)});
        V v_t_2450 = ({ V a_0 = v_x_243; V a_1 = v_t_2449; V r_ = (g_heff_2ecompile_2eir_2elamW(a_0, a_1)); heff_drop(v_x_243); r_; });
        V v_x_2451 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2448, v_t_2450}), 0, 2);
        if (heff_intLt_c(MK_INT(0LL), v_x_2451)) {
          heff_drop(v_b_240);
          heff_drop(v_xs_244);
          heff_drop(v_vs_246);
          return NTAG(TAG_True);
        } else {
          V t_0 = v_b_240;
          V t_1 = v_xs_244;
          V t_2 = v_vs_246;
          v_b_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2446);
        V t_0 = v_b_240;
        V t_1 = v_xs_244;
        V t_2 = v_vs_246;
        v_b_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2egivenTelling_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2egivenTelling(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_x_244 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_243));
  V v_t_2413;
  if (!heff_intLt_c_lent(MK_INT(1200LL), v_x_244, 1)) {
    heff_drop(v_x_244);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esharedIn_clo), 1, (V[]){heff_dup(v_s_242)}));
    HeffT2 v_t_247 = (g_heff_2ecompile_2espec_2edictGo_24cpr(v_t_246, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_b_241)));
    V v_t_2412;
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_r_2410 = v_field_249;
        V v_t_2411 = heff_tr(g_heff_2ecompile_2espec_2eclosedIn(NTAG(TAG_Nil), heff_dup(v_r_2410)));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          v_t_2412 = v_r_2410;
        } else {
          heff_drop(v_r_2410);
          heff_drop(v_t_2411);
          v_t_2412 = heff_dup(v_b_241);
        }
      } else {
        heff_drop(v_field_249);
        v_t_2412 = heff_dup(v_b_241);
      }
    }
    v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_245, heff_dup(v_key_240), v_t_2412));
  } else {
    heff_drop(v_x_244);
    v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  }
  V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esharedIn_clo), 1, (V[]){heff_dup(v_s_242)}));
  HeffT2 v_t_2415 = (g_heff_2ecompile_2espec_2edictGo_24cpr(v_t_2414, heff_dup(g_std_2eordmap_2eempty_get()), heff_dup(v_b_241)));
  V v_t_2462;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_x1_2420;
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_r_2418 = v_field_2417;
      V v_t_2419 = heff_tr(g_heff_2ecompile_2espec_2eclosedIn(NTAG(TAG_Nil), heff_dup(v_r_2418)));
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_b_241);
        heff_drop(v_t_2419);
        v_x1_2420 = v_r_2418;
      } else {
        heff_drop(v_r_2418);
        heff_drop(v_t_2419);
        v_x1_2420 = v_b_241;
      }
    } else {
      heff_drop(v_field_2417);
      v_x1_2420 = v_b_241;
    }
    V v_t_2460;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_EVar: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x1_2420, 0ULL, 3);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_True);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x1_2420, 0ULL, 4);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x1_2420, 0ULL, 3);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x1_2420, 0ULL, 3);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x1_2420, 0ULL, 1);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_t_2460 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
      heff_drop(v_t_2460);
      V v_t_2461 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
      v_t_2462 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_2461, v_key_240, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_key_240);
      heff_drop(v_t_2460);
      v_t_2462 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
    }
  }
  V v_t_2463 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 3, 7);
  V v_t_2465 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 4, 7);
  V v_t_2466 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 5, 7);
  V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 6, 7);
  V v_p_2468 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_2413, v_t_2462, v_t_2463, v_t_2464, v_t_2465, v_t_2466, v_t_2467});
  return ({ V rv_7 = v_p_2468; V rr_ = heff_rec_reuse_nf(v_s_242, 895ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 999423u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_str0, 1, "-");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_str2, 0, "");
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam3(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr(V v_own_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_vers_249 = heff_get_n(heff_dup(heff_rfield(v_s_248, 8)), 0, 5);
  V v_h_2410 = heff_dup(v_h_246);
  V v_g_2411 = heff_dup(v_g_241);
  V v_t_2412 = (g_list_2efoldl_24f1287822497x2111322144(NTAG(TAG_Nil), heff_dup(v_marks_244), heff_dup(heff_rfield(v_sh_245, 0))));
  V v_t_2413 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2412; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = ({ V a_0 = v_vers_249; V a_1 = v_g_2411; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_g_2411); r_; });
  V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam0, 1, 1, (V[]){v_vers_249}), v_t_2413));
  HeffT2 v_t_2417 = (g_heff_2ecompile_2esimplify_2eversAll_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2416})));
  V v_t_2429;
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_vs_2420 = v_field_2419;
      V v_t_2421 = (g_list_2emap_24s1123370502x1982532655(v_vs_2420));
      V v_items_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_h_2410}), v_t_2421});
      HeffT2 v_t_2423 = (g_heff_2ecompile_2eirtext_2ehashW_24cpr(MK_INT(5381LL), MK_INT(7919LL), v_items_2422));
      {
        V v_field_2424 = v_t_2423.f[0];
        V v_field_2425 = v_t_2423.f[1];
        V v_a_2426 = v_field_2424;
        V v_b_2427 = v_field_2425;
        V v_t_2428 = heff_strAppend(heff_intShow(v_a_2426), ((V)&g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_str0));
        v_t_2429 = heff_strAppend(v_t_2428, heff_intShow(v_b_2427));
      }
    } else {
      heff_drop(v_h_2410);
      heff_drop(v_field_2419);
      v_t_2429 = ((V)&g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_str1);
    }
  }
  V v_h_2430 = heff_dup(v_h_246);
  V v_v_2431 = v_t_2429;
  V v_s_2432 = heff_dup(v_s_248);
  V v_k_2433 = heff_take_field(v_s_2432, 8);
  V v_t_2434 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_2433, 0), heff_dup(v_h_2430), v_v_2431));
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_h_2430, heff_take_field(v_k_2433, 2)});
  V v_t_2436 = ({ V rv_0 = v_t_2434; V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_k_2433, 26ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 972u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2437 = ({ V rv_8 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_s_2432, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
  V v_x2_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2437});
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_s_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 2ULL, 2);
    V v_t_2441 = heff_get_n(heff_get_n(v_s_248, 7, 10), 2, 7);
    HeffT2 v_t_2442 = ({ V a_0 = v_t_2441; V a_1 = v_h_246; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_t_2441); r_; });
    {
      V v_field_2444 = v_t_2442.f[1];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        heff_drop(v_own_240);
        heff_drop(v_g_241);
        heff_drop(v_xs_242);
        heff_drop(v_b_243);
        heff_drop(v_marks_244);
        heff_drop_rec(v_sh_245, 3);
        heff_drop(v_h_246);
        heff_drop(v_d_247);
        heff_drop_cell(v_ru_24x2_2438_24MkPair, 2);
        V v_x_2445 = v_field_2444;
        heff_drop(v_x_2445);
        return ((HeffT2){{NTAG(TAG_MkUnit), v_s_2440}});
      } else {
        heff_drop(v_field_2444);
        V v_h_2446 = heff_dup(v_h_246);
        V v_s_2447 = v_s_2440;
        V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_2447, 8)), 0, 5);
        HeffT2 v_t_2449 = ({ V a_0 = v_t_2448; V a_1 = v_h_2446; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2448); r_; });
        V v_x2_2474;
        {
          V v_field_2451 = v_t_2449.f[1];
          int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
          if ((v_tag_2450 == ((int64_t)0ULL))) {
            V v_v_2452 = v_field_2451;
            V v_t_2453 = heff_get_n(heff_dup(heff_rfield(v_s_2447, 8)), 1, 5);
            HeffT2 v_t_2454 = ({ V a_0 = v_t_2453; V a_1 = v_h_2446; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2453); r_; });
            {
              V v_field_2456 = v_t_2454.f[1];
              int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
              if ((v_tag_2455 == ((int64_t)0ULL))) {
                V v_kc_2457 = v_field_2456;
                if ((heff_strEq_c(heff_dup(heff_rfield(v_kc_2457, 0)), heff_dup(v_v_2452)) && !heff_strEq_c_lent(v_v_2452, ((V)&g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_str2), 2))) {
                  heff_drop(v_v_2452);
                  V v_h_2458 = v_h_2446;
                  V v_kc_2459 = heff_dup(v_kc_2457);
                  V v_x4_2460 = heff_tr(heff_call(heff_get_n(v_kc_2457, 1, 6), 1, (V[]){NTAG(TAG_MkUnit)}));
                  V v_p_2461 = v_s_2447;
                  switch (heff_tag_of(v_x4_2460)) {
                  case TAG_Nothing: {
                    heff_drop(v_h_2458);
                    heff_drop_rec(v_kc_2459, 6);
                    v_x2_2474 = heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_p_2461});
                    break;
                  }
                  case TAG_Just: {
                    V v_b_2462 = heff_field(v_x4_2460, 0);
                    heff_take_n(v_x4_2460, 1ULL, 1);
                    heff_drop_cell(v_ru_24x2_2438_24MkPair, 2);
                    HeffT2 v_t_2464 = (g_heff_2ecompile_2esimplify_2erecipesWith_24cpr(heff_clo_n(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam1, 1, 2, (V[]){heff_dup(v_h_2458), heff_dup(v_b_2462)}), v_p_2461));
                    {
                      V v_field_2465 = v_t_2464.f[0];
                      V v_field_2466 = v_t_2464.f[1];
                      V v_x_2467 = v_field_2465;
                      heff_drop(v_x_2467);
                      V v_s_2468 = v_field_2466;
                      HeffT2 v_t_2469 = (g_heff_2ecompile_2esimplify_2eallAsked_24cpr(heff_dup(heff_rfield(v_kc_2459, 2)), v_s_2468));
                      {
                        V v_field_2470 = v_t_2469.f[0];
                        V v_field_2471 = v_t_2469.f[1];
                        V v_x_2472 = v_field_2470;
                        V v_s_2473 = v_field_2471;
                        v_x2_2474 = ({ V a_0 = v_h_2458; V a_1 = v_kc_2459; V a_2 = v_b_2462; V a_3 = v_x_2472; V a_4 = v_s_2473; V r_ = (g_heff_2ecompile_2esimplify_2easkedAs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2472); r_; });
                      }
                    }
                    break;
                  }
                  default: heff_nomatch(v_x4_2460);
                  }
                } else {
                  heff_drop(v_h_2446);
                  heff_drop(v_v_2452);
                  heff_drop_rec(v_kc_2457, 6);
                  v_x2_2474 = heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2447});
                }
              } else {
                heff_drop(v_h_2446);
                heff_drop(v_v_2452);
                heff_drop(v_field_2456);
                v_x2_2474 = heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2447});
              }
            }
          } else {
            heff_drop(v_h_2446);
            heff_drop(v_field_2451);
            v_x2_2474 = heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2447});
          }
        }
        switch (heff_tag_of(v_x2_2474)) {
        case TAG_MkPair: {
          V v_x_2475 = heff_field(v_x2_2474, 0);
          V v_s_2476 = heff_field(v_x2_2474, 1);
          V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
          if ((heff_dup(v_x_2475) == NTAG(TAG_True))) {
            heff_drop(v_own_240);
            heff_drop(v_g_241);
            heff_drop(v_xs_242);
            heff_drop(v_b_243);
            heff_drop(v_marks_244);
            heff_drop_rec(v_sh_245, 3);
            heff_drop(v_h_246);
            heff_drop(v_d_247);
            heff_drop(v_x_2475);
            heff_drop_cell(v_ru_24x2_2474_24MkPair, 2);
            return ((HeffT2){{NTAG(TAG_MkUnit), v_s_2476}});
          } else {
            heff_drop(v_x_2475);
            HeffT2 v_t_2477 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_n(TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_s_2476));
            {
              V v_field_2478 = v_t_2477.f[0];
              V v_field_2479 = v_t_2477.f[1];
              V v_x_2480 = v_field_2478;
              V v_s_2481 = v_field_2479;
              V v_own_2482 = v_own_240;
              V v_g_2483 = v_g_241;
              V v_h_2484 = heff_dup(v_h_246);
              V v_marks_2485 = v_marks_244;
              V v_sh_2486 = v_sh_245;
              V v_args_2487 = heff_take_field(v_sh_2486, 0);
              V v_vars_2488 = heff_get_n(v_sh_2486, 1, 3);
              V v_lam1_2489 = v_x_2480;
              V v_m_24107;
              switch (heff_tag_of(v_lam1_2489)) {
              case TAG_ELam: {
                V v_xs1_2490 = heff_field(v_lam1_2489, 0);
                V v_b1_2491 = heff_field(v_lam1_2489, 1);
                V v_ru_24lam1_2489_24ELam = heff_take_reuse_n(v_lam1_2489, 3ULL, 2);
                V v_pre_2492 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24lam1_2489_24ELam, heff_dup(v_vars_2488)));
                V v_t_2493;
                if ((heff_dup(v_own_2482) == NTAG(TAG_True))) {
                  heff_drop(v_own_2482);
                  v_t_2493 = (g_heff_2ecompile_2espec_2eselfTo(v_g_2483, v_h_2484, v_pre_2492, heff_dup(v_marks_2485), v_b1_2491));
                } else {
                  heff_drop(v_own_2482);
                  heff_drop(v_g_2483);
                  heff_drop(v_h_2484);
                  heff_drop(v_pre_2492);
                  v_t_2493 = v_b1_2491;
                }
                V v_m_2494 = ({ V a_0 = heff_dup(v_marks_2485); V a_1 = heff_dup(v_xs1_2490); V a_2 = v_args_2487; V a_3 = v_t_2493; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_args_2487); r_; });
                v_m_24107 = heff_clo_n(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam2, 1, 4, (V[]){v_m_2494, v_marks_2485, v_xs1_2490, v_vars_2488});
                break;
              }
              default: {
                heff_drop(v_own_2482);
                heff_drop(v_g_2483);
                heff_drop(v_h_2484);
                heff_drop(v_marks_2485);
                heff_drop(v_args_2487);
                heff_drop(v_vars_2488);
                v_m_24107 = heff_clo_n(g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam3, 1, 1, (V[]){v_lam1_2489});
                break;
              }
              }
              V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_2481}));
              switch (heff_tag_of(v_x2_24108)) {
              case TAG_MkPair: {
                V v_x_24109 = heff_field(v_x2_24108, 0);
                V v_s_24110 = heff_field(v_x2_24108, 1);
                V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
                V v_b0_24111 = v_x_24109;
                V v_s_24112 = v_s_24110;
                HeffT2 v_t_24113 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(heff_dup(v_s_24112)));
                V v_x2_24154;
                {
                  V v_field_24114 = v_t_24113.f[0];
                  V v_field_24115 = v_t_24113.f[1];
                  V v_x_24116 = v_field_24114;
                  heff_drop(v_x_24116);
                  V v_s_24117 = v_field_24115;
                  V v_o_24118 = NTAG(TAG_True);
                  V v_s_24119 = v_s_24117;
                  V v_t_24120 = heff_get_n(heff_dup(heff_rfield(v_s_24119, 7)), 0, 7);
                  V v_t_24121 = heff_get_n(heff_dup(heff_rfield(v_s_24119, 7)), 1, 7);
                  V v_t_24122 = heff_get_n(heff_dup(heff_rfield(v_s_24119, 7)), 2, 7);
                  V v_t_24123 = heff_get_n(heff_dup(heff_rfield(v_s_24119, 7)), 3, 7);
                  V v_t_24124 = heff_get_n(heff_dup(heff_rfield(v_s_24119, 7)), 4, 7);
                  V v_t_24125 = heff_get_n(heff_dup(heff_rfield(v_s_24119, 7)), 5, 7);
                  V v_t_24126 = ({ V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_24120, v_t_24121, v_t_24122, v_t_24123, v_t_24124, v_t_24125, v_o_24118}); V rr_ = heff_rec_reuse_nf(v_s_24119, 895ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 999423u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
                  V v_x2_24127 = heff_tag_at_n(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_24126});
                  switch (heff_tag_of(v_x2_24127)) {
                  case TAG_MkPair: {
                    V v_s_24129 = heff_field(v_x2_24127, 1);
                    heff_take_n(v_x2_24127, 2ULL, 2);
                    V v_m_24130 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b0_24111));
                    V v_x2_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_s_24129}));
                    switch (heff_tag_of(v_x2_24131)) {
                    case TAG_MkPair: {
                      V v_x_24132 = heff_field(v_x2_24131, 0);
                      V v_s_24133 = heff_field(v_x2_24131, 1);
                      heff_take_n(v_x2_24131, 3ULL, 2);
                      V v_m_24134 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_24132));
                      V v_x2_24135 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_s_24133}));
                      switch (heff_tag_of(v_x2_24135)) {
                      case TAG_MkPair: {
                        V v_x_24136 = heff_field(v_x2_24135, 0);
                        V v_s_24137 = heff_field(v_x2_24135, 1);
                        heff_take_n(v_x2_24135, 3ULL, 2);
                        HeffT2 v_t_24138 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_24136, v_s_24137));
                        {
                          V v_field_24139 = v_t_24138.f[0];
                          V v_field_24140 = v_t_24138.f[1];
                          V v_x_24141 = v_field_24139;
                          V v_s_24142 = v_field_24140;
                          V v_saved_24143 = v_s_24112;
                          V v_s_24144 = v_s_24142;
                          V v_x_24145 = NTAG(TAG_MkUnit);
                          V v_t_24146 = heff_get_n(heff_dup(heff_rfield(v_s_24144, 7)), 0, 7);
                          V v_t_24147 = heff_get_n(heff_dup(heff_rfield(v_s_24144, 7)), 1, 7);
                          V v_t_24148 = heff_get_n(heff_dup(heff_rfield(v_s_24144, 7)), 2, 7);
                          V v_t_24149 = heff_get_n(heff_dup(heff_rfield(v_s_24144, 7)), 3, 7);
                          V v_t_24150 = heff_get_n(heff_dup(heff_rfield(v_s_24144, 7)), 4, 7);
                          V v_t_24151 = heff_get_n(heff_dup(heff_rfield(v_saved_24143, 7)), 5, 7);
                          V v_t_24152 = heff_get_n(heff_dup(heff_rfield(v_saved_24143, 7)), 6, 7);
                          V v_s_24153 = ({ V rv_1 = heff_take_field(v_saved_24143, 1); V rv_6 = heff_take_field(v_saved_24143, 6); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_24146, v_t_24147, v_t_24148, v_t_24149, v_t_24150, v_t_24151, v_t_24152}); V rv_9 = heff_get_n(v_saved_24143, 9, 10); V rr_ = heff_rec_reuse_nf(v_s_24144, 317ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 200691u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 9) = rv_9; rr_; });
                          v_x2_24154 = heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){v_x_24141, v_s_24153});
                        }
                        break;
                      }
                      default: heff_nomatch(v_x2_24135);
                      }
                      break;
                    }
                    default: heff_nomatch(v_x2_24131);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x2_24127);
                  }
                }
                switch (heff_tag_of(v_x2_24154)) {
                case TAG_MkPair: {
                  V v_x_24155 = heff_field(v_x2_24154, 0);
                  V v_s_24156 = heff_field(v_x2_24154, 1);
                  heff_take_n(v_x2_24154, 3ULL, 2);
                  HeffT2 v_t_24157 = (g_heff_2ecompile_2esimplify_2easkedFor_24cpr(heff_dup(v_h_246), heff_dup(v_x_24155), v_d_247, v_s_24156));
                  {
                    V v_field_24158 = v_t_24157.f[0];
                    V v_field_24159 = v_t_24157.f[1];
                    V v_x_24160 = v_field_24158;
                    heff_drop(v_x_24160);
                    V v_s_24161 = v_field_24159;
                    V v_k_24162 = heff_take_field(v_s_24161, 8);
                    V v_t_24163 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_24162, 3), heff_dup(v_h_246), NTAG(TAG_MkUnit)));
                    V v_k_24164 = ({ V rv_3 = v_t_24163; V rr_ = heff_rec_reuse_nf(v_k_24162, 23ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                    V v_h_24165 = v_h_246;
                    V v_b_24166 = v_x_24155;
                    V v_s_24167 = ({ V rv_8 = v_k_24164; V rr_ = heff_rec_reuse_nf(v_s_24161, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
                    V v_t_24168 = (g_heff_2ecompile_2eir_2eisValue(v_b_24166));
                    V v_t_24169;
                    if ((heff_dup(v_t_24168) == NTAG(TAG_True))) {
                      heff_drop(v_b_24166);
                      heff_drop(v_t_24168);
                      v_t_24169 = NTAG(TAG_True);
                    } else {
                      heff_drop(v_t_24168);
                      v_t_24169 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_24167, 4), heff_rfield(v_s_24167, 5), v_b_24166));
                    }
                    V v_f_24180;
                    if ((heff_dup(v_t_24169) == NTAG(TAG_True))) {
                      heff_drop(v_t_24169);
                      V v_t_24170 = heff_take_field(v_s_24167, 0);
                      V v_t_24171 = heff_take_field(v_s_24167, 1);
                      V v_t_24172 = heff_take_field(v_s_24167, 2);
                      V v_t_24173 = heff_take_field(v_s_24167, 3);
                      V v_t_24174 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_24167, 4), heff_dup(v_h_24165), NTAG(TAG_MkUnit)));
                      V v_t_24175 = heff_take_field(v_s_24167, 5);
                      V v_t_24176 = heff_take_field(v_s_24167, 6);
                      V v_t_24177 = heff_take_field(v_s_24167, 7);
                      V v_t_24178 = heff_take_field(v_s_24167, 8);
                      V v_t_24179 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_24173, v_h_24165, NTAG(TAG_MkUnit)));
                      v_f_24180 = ({ V rv_0 = v_t_24170; V rv_1 = v_t_24171; V rv_2 = v_t_24172; V rv_3 = v_t_24179; V rv_4 = v_t_24174; V rv_5 = v_t_24175; V rv_6 = v_t_24176; V rv_7 = v_t_24177; V rv_8 = v_t_24178; V rr_ = heff_rec_reuse_nf(v_s_24167, 512ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 786432u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
                    } else {
                      heff_drop(v_h_24165);
                      heff_drop(v_t_24169);
                      v_f_24180 = v_s_24167;
                    }
                    return ((HeffT2){{NTAG(TAG_MkUnit), v_f_24180}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_x2_24154)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_24108)}});
              }
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2474)}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_2438)}});
  }
}
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam0(V self, V *args) {
  V v_k_2415 = args[0];
  V v_vers_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_vers_249; V a_1 = v_k_2415; V r_ = (g_std_2eordmap_2elookup_24s305164685x44869932(a_0, a_1)); heff_drop(v_vers_249); heff_drop(v_k_2415); r_; });
}
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam1(V self, V *args) {
  V v_m_2463 = args[0];
  V v_h_2458 = heff_env(self)[0];
  V v_b_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2463, v_h_2458, v_b_2462));
}
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam2(V self, V *args) {
  V v_s_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  V v_marks_2485 = heff_env(self)[1];
  V v_xs1_2490 = heff_env(self)[2];
  V v_vars_2488 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_s_2495}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_MkPair: {
    V v_x_2497 = heff_field(v_x2_2496, 0);
    V v_s_2498 = heff_field(v_x2_2496, 1);
    V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
    V v_t_2499 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_2485), heff_dup(v_xs1_2490)));
    V v_x1_24100 = (g_prelude_2e_2b_2b(heff_dup(v_vars_2488), v_t_2499));
    V v_x_24105;
    switch (heff_tag_of(v_x1_24100)) {
    case TAG_Nil: {
      heff_drop(v_marks_2485);
      heff_drop(v_xs1_2490);
      heff_drop(v_vars_2488);
      v_x_24105 = v_x_2497;
      break;
    }
    case TAG_Cons: {
      V v_ru_24x1_24100_24Cons = heff_take_reuse_n(v_x1_24100, 0ULL, 2);
      V v_t_24103 = (g_heff_2ecompile_2esimplify_2ekeepParams(v_marks_2485, v_xs1_2490));
      V v_t_24104 = (g_prelude_2e_2b_2b(v_vars_2488, v_t_24103));
      v_x_24105 = heff_tag_at_n(v_ru_24x1_24100_24Cons, TAG_ELam, 2, (V[]){v_t_24104, v_x_2497});
      break;
    }
    default: heff_nomatch(v_x1_24100);
    }
    return heff_tag_at_n(v_ru_24x2_2496_24MkPair, TAG_MkPair, 2, (V[]){v_x_24105, v_s_2498});
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2ecompile_2esimplify_2eask_24s1572368542x438987874_24cpr_lam3(V self, V *args) {
  V v_s_24106 = args[0];
  V v_lam1_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_2489, v_s_24106});
}
Clo g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371(V v_g_240, V v_xs_241, V v_b_242, V v_as0_243, V v_x6_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkPair: {
    V v_bds_246 = heff_field(v_x6_244, 0);
    V v_argv_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24MkPair = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_made_248 = (g_list_2ezipWith_24s528321443x971020870(v_as0_243, heff_dup(v_argv_247)));
    V v_t_249 = (g_heff_2ecompile_2esimplify_2etagMarks(heff_dup(v_z_245), heff_dup(v_g_240), heff_dup(v_xs_241), heff_dup(v_b_242), heff_dup(v_argv_247)));
    V v_x2_2410 = heff_tr(g_heff_2ecompile_2esimplify_2especTagged_24s841482917x1348649645(v_g_240, v_xs_241, v_b_242, v_argv_247, v_made_248, v_t_249, v_z_245));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_x_2413 = ({ V a_0 = v_bds_246; V a_1 = v_x_2411; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_bds_246); r_; });
      return heff_tag_at_n(v_ru_24x6_244_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBound_24s2036378242x1940793371(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(V v_s_240, V v_arms_241, V v_argv_242, V v_z_243) {
top: ;
  V v_m_244 = heff_tr(g_heff_2ecompile_2esimplify_2ebindPushable(v_argv_242));
  V v_x2_245 = heff_tr(heff_call(v_m_244, 1, (V[]){v_z_243}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_m_2420 = (g_prelude_2etraverse_24s2064368144x1684679122(heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_lam0, 1, 1, (V[]){heff_dup(v_x_246)}), v_arms_241));
    V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){v_s_247}));
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_s_2423 = heff_field(v_x2_2421, 1);
      V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
      V v_t_2426;
      switch (heff_tag_of(v_x_246)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 2);
        v_t_2426 = v_x_2424;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      V v_x_2427 = ({ V a_0 = v_t_2426; V a_1 = heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_EMatch, 2, (V[]){v_s_240, v_x_2422}); V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2426); r_; });
      return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2423});
    }
    default: return heff_nomatch(v_x2_2421);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_vs_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_249, v_vs_2410, v_x_2418}), v_s_2419});
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_lam0(V self, V *args) {
  V v_a_248 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_248)) {
  case TAG_MkArm: {
    V v_t_249 = heff_field(v_a_248, 0);
    V v_vs_2410 = heff_field(v_a_248, 1);
    V v_b_2411 = heff_field(v_a_248, 2);
    heff_take_n(v_a_248, 7ULL, 3);
    V v_t_2414;
    switch (heff_tag_of(v_x_246)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_x_246, 1);
      heff_take_n(v_x_246, 2ULL, 2);
      v_t_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    V v_m_2415 = (g_heff_2ecompile_2esimplify_2eapplyArm_24s1516391641x211261432(v_b_2411, v_t_2414));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_24s1206863964x1295438039_lam1, 1, 3, (V[]){v_m_2415, v_t_249, v_vs_2410});
  }
  default: return heff_nomatch(v_a_248);
  }
}
Clo g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(V v_x_240, V v_a_241, V v_b_242, V v_o_243, V v_s_244) {
top: ;
  if (heff_intEq_c_lent(v_o_243, MK_INT(0LL), 2)) {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    heff_drop(v_o_243);
    V v_t_245 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
    return heff_tail(v_t_245, 1, (V[]){v_s_244});
  } else {
    V v_t_2445;
    switch (heff_tag_of(v_a_241)) {
    case TAG_EVar: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2445 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2445 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_241);
    }
    V v_t_2449;
    if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
      heff_drop(v_t_2445);
      v_t_2449 = NTAG(TAG_True);
    } else {
      heff_drop(v_t_2445);
      if (heff_intEq_c_lent(v_o_243, MK_INT(1LL), 2)) {
        V v_t_2446 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
        if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
          heff_drop(v_t_2446);
          v_t_2449 = NTAG(TAG_True);
        } else {
          heff_drop(v_t_2446);
          V v_x1_2447 = (g_heff_2ecompile_2esimplify_2epartialIn(heff_dup(v_s_244), v_a_241));
          if (!(heff_dup(v_x1_2447) == NTAG(TAG_True))) {
            heff_drop(v_x1_2447);
            V v_x1_2448 = (g_heff_2ecompile_2esimplify_2epastLastUse(v_x_240, heff_dup(v_a_241), heff_dup(v_b_242)));
            v_t_2449 = heff_bool(!(heff_dup(v_x1_2448) == NTAG(TAG_True)));
            heff_drop(v_x1_2448);
          } else {
            heff_drop(v_x1_2447);
            v_t_2449 = NTAG(TAG_True);
          }
        }
      } else {
        v_t_2449 = NTAG(TAG_False);
      }
    }
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_o_243);
      heff_drop(v_t_2449);
      V v_m_2450 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), v_x_240, v_a_241));
      V v_t_2451 = (g_std_2eordmap_2esize(v_m_2450));
      V v_e_2452;
      if (heff_intEq_c(v_t_2451, MK_INT(0LL))) {
        heff_drop(v_m_2450);
        v_e_2452 = v_b_242;
      } else {
        v_e_2452 = ({ V a_0 = v_m_2450; V a_1 = v_b_242; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2450); r_; });
      }
      V v_t_2453 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_e_2452));
      return heff_tail(v_t_2453, 1, (V[]){v_s_244});
    } else {
      heff_drop(v_t_2449);
      V v_t_2454 = (g_heff_2ecompile_2eir_2eisValue(v_a_241));
      V v_t_2463;
      if ((heff_dup(v_t_2454) == NTAG(TAG_True))) {
        heff_drop(v_t_2454);
        V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_241), NTAG(TAG_Nil)});
        V v_x_2456 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2455));
        if (!heff_intLt_c_lent(MK_INT(12LL), v_x_2456, 1)) {
          heff_drop(v_o_243);
          heff_drop(v_x_2456);
          v_t_2463 = NTAG(TAG_True);
        } else {
          heff_drop(v_x_2456);
          V v_t_2457;
          if (heff_intLe_c_lent(v_o_243, MK_INT(4LL), 2)) {
            v_t_2457 = heff_tr(g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_241)));
          } else {
            v_t_2457 = NTAG(TAG_False);
          }
          if ((heff_dup(v_t_2457) == NTAG(TAG_True))) {
            heff_drop(v_o_243);
            heff_drop(v_t_2457);
            v_t_2463 = NTAG(TAG_True);
          } else {
            heff_drop(v_t_2457);
            if (heff_intLe_c_lent(v_o_243, MK_INT(8LL), 2)) {
              V v_t_2458 = (g_heff_2ecompile_2esimplify_2ehandlerLike(heff_dup(v_a_241)));
              if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
                heff_drop(v_o_243);
                heff_drop(v_t_2458);
                v_t_2463 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2458);
                V v_t_2459 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 1, 7);
                V v_t_2460 = (g_heff_2ecompile_2esimplify_2ehandedOn(v_t_2459, v_x_240, heff_dup(v_a_241), heff_dup(v_b_242), heff_dup(v_o_243)));
                if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
                  heff_drop(v_o_243);
                  heff_drop(v_t_2460);
                  v_t_2463 = NTAG(TAG_True);
                } else {
                  heff_drop(v_t_2460);
                  v_t_2463 = (g_heff_2ecompile_2esimplify_2erunsGiven(v_x_240, heff_dup(v_a_241), heff_dup(v_b_242), v_o_243));
                }
              }
            } else {
              V v_t_2461 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 1, 7);
              V v_t_2462 = (g_heff_2ecompile_2esimplify_2ehandedOn(v_t_2461, v_x_240, heff_dup(v_a_241), heff_dup(v_b_242), heff_dup(v_o_243)));
              if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
                heff_drop(v_o_243);
                heff_drop(v_t_2462);
                v_t_2463 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2462);
                v_t_2463 = (g_heff_2ecompile_2esimplify_2erunsGiven(v_x_240, heff_dup(v_a_241), heff_dup(v_b_242), v_o_243));
              }
            }
          }
        }
      } else {
        heff_drop(v_o_243);
        heff_drop(v_t_2454);
        v_t_2463 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
        heff_drop(v_t_2463);
        V v_m_2464 = ({ V a_0 = v_x_240; V a_1 = v_a_241; V a_2 = v_b_242; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_240); r_; });
        V v_x2_2465 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_s_244}));
        switch (heff_tag_of(v_x2_2465)) {
        case TAG_MkPair: {
          V v_x_2466 = heff_field(v_x2_2465, 0);
          V v_s_2467 = heff_field(v_x2_2465, 1);
          heff_take_n(v_x2_2465, 3ULL, 2);
          V v_t_2468 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_2466));
          return heff_tail(v_t_2468, 1, (V[]){v_s_2467});
        }
        default: return heff_nomatch(v_x2_2465);
        }
      } else {
        heff_drop(v_t_2463);
        V v_m_2469 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
        V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_244}));
        switch (heff_tag_of(v_x2_2470)) {
        case TAG_MkPair: {
          V v_x_2471 = heff_field(v_x2_2470, 0);
          V v_s_2472 = heff_field(v_x2_2470, 1);
          V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
          HeffT2 v_t_2473 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_240), heff_dup(v_a_241), heff_dup(v_x_2471)));
          {
            V v_field_2475 = v_t_2473.f[1];
            int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
            V v_t_2477;
            if ((v_tag_2474 == ((int64_t)0ULL))) {
              heff_drop(v_x_240);
              heff_drop(v_a_241);
              heff_drop(v_x_2471);
              V v_x_2476 = v_field_2475;
              v_t_2477 = v_x_2476;
            } else {
              heff_drop(v_field_2475);
              v_t_2477 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_240, v_a_241, v_x_2471});
            }
            return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){v_t_2477, v_s_2472});
          }
        }
        default: return heff_nomatch(v_x2_2470);
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletPure_24s1572214135x1290363189(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeFresh_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeFresh(V v_h_240, V v_b0_241, V v_s_242) {
top: ;
  V v_x_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 8)), 2, 5);
  V v_k_244 = heff_take_field(v_s_242, 8);
  V v_t_245 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_k_244, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_246 = ({ V rv_8 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_242, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
  HeffT2 v_t_247 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_t_246));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x_2410 = v_field_248;
    heff_drop(v_x_2410);
    V v_s_2411 = v_field_249;
    V v_m_2412 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b0_241));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
      V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_x_2414));
      V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2415}));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_x_2418 = heff_field(v_x2_2417, 0);
        V v_s_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        HeffT2 v_t_2420 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2418, v_s_2419));
        {
          V v_field_2421 = v_t_2420.f[0];
          V v_field_2422 = v_t_2420.f[1];
          V v_x_2423 = v_field_2421;
          V v_s_2424 = v_field_2422;
          V v_k_2425 = heff_dup(heff_rfield(v_s_2424, 8));
          V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_2424, 8)), 2, 5);
          V v_t_2427 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_k_2425, 4), v_h_240, v_t_2426));
          V v_k_2428 = ({ V rv_2 = v_x_243; V rv_4 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_k_2425, 11ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 207u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_t_2429 = ({ V rv_8 = v_k_2428; V rr_ = heff_rec_reuse_nf(v_s_2424, 767ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 851967u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
          return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_t_2429});
        }
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
}
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeFresh(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V v_n_240, V v_key_241, V v_b_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2erecordDef_24cpr(heff_dup(v_key_241), heff_dup(v_b_242), v_s_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    heff_drop(v_x_247);
    V v_s_248 = v_field_246;
    V v_h_249 = heff_dup(v_key_241);
    V v_b_2410 = heff_dup(v_b_242);
    V v_s_2411 = v_s_248;
    V v_t_2412 = (g_heff_2ecompile_2eir_2eisValue(v_b_2410));
    V v_t_2416;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_b_2410);
      heff_drop(v_t_2412);
      V v_t_2413 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_2411, 3), v_h_249, NTAG(TAG_MkUnit)));
      v_t_2416 = ({ V rv_3 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_2411, 1015ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048383u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_t_2412);
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_2411, 3), heff_rfield(v_s_2411, 5), v_b_2410));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_t_2414);
        V v_t_2415 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_2411, 3), v_h_249, NTAG(TAG_MkUnit)));
        v_t_2416 = ({ V rv_3 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_s_2411, 1015ULL, 10, shape_supply__fuel__defs__safe__base__total__plain__sp__kp__unrolled, 1048383u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        heff_drop(v_h_249);
        heff_drop(v_t_2414);
        v_t_2416 = v_s_2411;
      }
    }
    V v_x2_2417 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2416});
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_MkPair: {
      V v_s_2419 = heff_field(v_x2_2417, 1);
      V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 2ULL, 2);
      V v_t_2420 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
      V v_t_2421 = (g_heff_2ecompile_2eir_2enubI(v_t_2420));
      HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_t_2421, heff_dup(v_s_2419)));
      {
        V v_field_2423 = v_t_2422.f[0];
        V v_field_2424 = v_t_2422.f[1];
        V v_x_2425 = v_field_2423;
        V v_s_2426 = v_field_2424;
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_240, 1)) {
          V v_t_2427 = (g_heff_2ecompile_2esimplify_2egrewIn(v_s_2419, heff_dup(v_s_2426), heff_dup(v_b_242)));
          if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
            heff_drop(v_t_2427);
            HeffT2 v_t_2428 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_s_2426));
            {
              V v_field_2429 = v_t_2428.f[0];
              V v_field_2430 = v_t_2428.f[1];
              V v_x_2431 = v_field_2429;
              heff_drop(v_x_2431);
              V v_s_2432 = v_field_2430;
              V v_m_2433 = (g_heff_2ecompile_2esimplify_2esimpF_24s62988902x791446945(v_b_242));
              V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_s_2432}));
              switch (heff_tag_of(v_x2_2434)) {
              case TAG_MkPair: {
                V v_x_2435 = heff_field(v_x2_2434, 0);
                V v_s_2436 = heff_field(v_x2_2434, 1);
                V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
                HeffT2 v_t_2437 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2435, v_s_2436));
                {
                  V v_field_2438 = v_t_2437.f[0];
                  V v_field_2439 = v_t_2437.f[1];
                  V v_x_2440 = v_field_2438;
                  V v_s_2441 = v_field_2439;
                  V v_m_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleDef_clo), 3, (V[]){heff_intSub(v_n_240, MK_INT(1LL)), v_key_241, v_x_2440}));
                  V v_x2_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_s_2441}));
                  switch (heff_tag_of(v_x2_2443)) {
                  case TAG_MkPair: {
                    V v_x_2444 = heff_field(v_x2_2443, 0);
                    V v_s_2445 = heff_field(v_x2_2443, 1);
                    heff_take_n(v_x2_2443, 3ULL, 2);
                    V v_t_2448;
                    switch (heff_tag_of(v_x_2444)) {
                    case TAG_MkPair: {
                      V v_x_2446 = heff_dup(heff_field(v_x_2444, 0));
                      v_t_2448 = v_x_2446;
                      break;
                    }
                    default: heff_nomatch(v_x_2444);
                    }
                    V v_t_2451;
                    switch (heff_tag_of(v_x_2444)) {
                    case TAG_MkPair: {
                      V v_y_2450 = heff_field(v_x_2444, 1);
                      heff_take_n(v_x_2444, 2ULL, 2);
                      v_t_2451 = v_y_2450;
                      break;
                    }
                    default: heff_nomatch(v_x_2444);
                    }
                    V v_t_2452 = (g_prelude_2e_2b_2b_24tok2(v_ru_24x2_2434_24MkPair, v_x_2425, v_t_2451));
                    V v_x_2453 = heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2448, v_t_2452});
                    return ((HeffT2){{v_x_2453, v_s_2445}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x2_2443)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_2434)}});
              }
            }
          } else {
            heff_drop(v_n_240);
            heff_drop(v_key_241);
            heff_drop(v_t_2427);
            return ((HeffT2){{heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_b_242, v_x_2425}), v_s_2426}});
          }
        } else {
          heff_drop(v_n_240);
          heff_drop(v_key_241);
          heff_drop(v_s_2419);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){v_b_242, v_x_2425}), v_s_2426}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2417)}});
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str4, 0, "");
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopiesDone_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopiesDone(V v_st_240, V v_defs_241) {
top: ;
  V v_bodies_242 = (g_list_2efoldl_24s1061937638x829298692(heff_dup(g_std_2eordmap_2eempty_get()), v_defs_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 3, 5);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2eordmap_2eempty_get()), v_t_249));
  V v_t_2465 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam0, 1, 2, (V[]){v_st_240, v_bodies_242}), v_t_2410));
  return (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2465));
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopiesDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam1(V self, V *args) {
  V v_h_2451 = args[0];
  V v_st_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2452 = heff_get_n(heff_get_n(v_st_2441, 8, 10), 0, 5);
  HeffT2 v_t_2453 = ({ V a_0 = v_t_2452; V a_1 = v_h_2451; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
  V v_t_2457;
  {
    V v_field_2455 = v_t_2453.f[1];
    int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
    if ((v_tag_2454 == ((int64_t)0ULL))) {
      V v_x_2456 = v_field_2455;
      v_t_2457 = v_x_2456;
    } else {
      heff_drop(v_field_2455);
      v_t_2457 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str3);
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_2451, v_t_2457});
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bodies_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 2, 7);
  HeffT2 v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_r_2416 = v_field_2415;
      V v_st_2417 = heff_dup(v_st_240);
      V v_bodies_2418 = v_bodies_242;
      V v_h_2419 = heff_dup(v_h_2411);
      V v_t_2420 = heff_get_n(heff_get_n(v_st_240, 8, 10), 0, 5);
      HeffT2 v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2420); heff_drop(v_h_2411); r_; });
      V v_v_2425;
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          V v_x_2424 = v_field_2423;
          v_v_2425 = v_x_2424;
        } else {
          heff_drop(v_field_2423);
          v_v_2425 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str0);
        }
      }
      V v_r_2426 = v_r_2416;
      if (heff_strEq_c_lent(v_v_2425, ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str1), 2)) {
        heff_drop_rec(v_st_2417, 10);
        heff_drop(v_bodies_2418);
        heff_drop(v_h_2419);
        heff_drop(v_v_2425);
        heff_drop(v_r_2426);
        return NTAG(TAG_Nothing);
      } else {
        V v_ps_2427 = (g_heff_2ecompile_2esimplify_2erecipeAsks(heff_dup(v_st_2417), v_h_2419, heff_dup(v_r_2426)));
        V v_x1_2428 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str2); V a_1 = v_ps_2427; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); heff_drop(v_ps_2427); r_; });
        if (!(heff_dup(v_x1_2428) == NTAG(TAG_True))) {
          heff_drop_rec(v_st_2417, 10);
          heff_drop(v_bodies_2418);
          heff_drop(v_h_2419);
          heff_drop(v_v_2425);
          heff_drop(v_r_2426);
          heff_drop(v_x1_2428);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_2428);
          V v_t_2429 = (g_heff_2ecompile_2esimplify_2erecipeAsks(heff_dup(v_st_2417), v_h_2419, heff_dup(v_r_2426)));
          V v_t_2430 = heff_get_n(heff_dup(heff_rfield(v_st_2417, 7)), 3, 7);
          HeffT2 v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_h_2419; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2430); r_; });
          V v_t_2435;
          {
            V v_field_2433 = v_t_2431.f[1];
            int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
            if ((v_tag_2432 == ((int64_t)0ULL))) {
              V v_x_2434 = v_field_2433;
              v_t_2435 = v_x_2434;
            } else {
              heff_drop(v_field_2433);
              v_t_2435 = MK_INT(0LL);
            }
          }
          HeffT2 v_t_2436 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(heff_rfield(v_st_2417, 4), v_h_2419));
          V v_t_2440;
          {
            V v_field_2438 = v_t_2436.f[1];
            int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
            v_t_2440 = heff_bool(((v_tag_2437 == ((int64_t)0ULL)) && ({ V v_x_2439 = heff_dup(v_field_2438); int c_ = 1; heff_drop(v_x_2439); c_; })));
            heff_drop(v_field_2438);
          }
          V v_st_2441 = v_st_2417;
          V v_bodies_2442 = v_bodies_2418;
          V v_h_2443 = heff_dup(v_h_2419);
          V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_st_2441, 8)), 4, 5);
          HeffT2 v_t_2445 = ({ V a_0 = v_t_2444; V a_1 = v_h_2443; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_t_2444); r_; });
          V v_t_2464;
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              V v_t_2448 = v_field_2447;
              V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_2448));
              V v_t_2450 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2eordmap_2eempty_get()), v_t_2449));
              V v_tv_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam1, 1, 1, (V[]){v_st_2441}), v_t_2450));
              HeffT2 v_t_2459 = ({ V a_0 = v_bodies_2442; V a_1 = v_h_2443; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_bodies_2442); heff_drop(v_h_2443); r_; });
              {
                V v_field_2461 = v_t_2459.f[1];
                int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                if ((v_tag_2460 == ((int64_t)0ULL))) {
                  V v_b_2462 = v_field_2461;
                  V v_t_2463 = ({ V b_0 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str4); V a_1 = v_tv_2458; V r_ = (g_list_2eall_24s44244667x1445755514(b_0, a_1)); heff_drop(b_0); r_; });
                  if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
                    heff_drop(v_t_2463);
                    v_t_2464 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2462, v_tv_2458})});
                  } else {
                    heff_drop(v_tv_2458);
                    heff_drop(v_b_2462);
                    heff_drop(v_t_2463);
                    v_t_2464 = NTAG(TAG_Nothing);
                  }
                } else {
                  heff_drop(v_tv_2458);
                  heff_drop(v_field_2461);
                  v_t_2464 = NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop_rec(v_st_2441, 10);
              heff_drop(v_bodies_2442);
              heff_drop(v_h_2443);
              heff_drop(v_field_2447);
              v_t_2464 = NTAG(TAG_Nothing);
            }
          }
          return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(7, shape_name__ver__recipe__asks__depth__safe__made, (V[]){v_h_2419, v_v_2425, v_r_2426, v_t_2429, v_t_2435, v_t_2440, v_t_2464})});
        }
      }
    } else {
      heff_drop(v_h_2411);
      heff_drop_rec(v_st_240, 10);
      heff_drop(v_bodies_242);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2(V v_tok_240, V v_lit_241, V v_lit_242, V v_h_243, V v_argv_244, V v_z_245) {
top: ;
  V v_t_246 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_argv_244));
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_lit_241));
  if (heff_intEq_c(v_t_246, v_t_247)) {
    heff_drop(v_h_243);
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2ecopy_24cpr(heff_tag_at_n(v_tok_240, TAG_ELam, 2, (V[]){v_lit_241, v_lit_242}), v_z_245));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_x_2416;
      switch (heff_tag_of(v_x_2411)) {
      case TAG_ELam: {
        V v_ys_2413 = heff_field(v_x_2411, 0);
        V v_b_2414 = heff_field(v_x_2411, 1);
        heff_take_n(v_x_2411, 3ULL, 2);
        V v_t_2415 = (g_list_2ezipWith_24s1876717925x1404326288(v_ys_2413, v_argv_244));
        v_x_2416 = ({ V a_0 = v_t_2415; V a_1 = v_b_2414; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2415); r_; });
        break;
      }
      default: {
        v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2411, v_argv_244));
        break;
      }
      }
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_s_2412});
    }
  } else {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    V v_t_2417 = heff_tag_at_n(v_tok_240, TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_243}), v_argv_244});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, v_z_245});
  }
}
V g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlinedCall_24s1120172687x1851593024_24tok2(a[0], a[1], a[2], a[3], a[4], a[5]);
}