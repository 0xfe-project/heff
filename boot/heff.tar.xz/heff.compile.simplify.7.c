// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2earityIn(V, V);
V g_heff_2ecompile_2esimplify_2earityIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2earityIn_clo;
V g_heff_2ecompile_2esimplify_2easkKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkKept_clo;
V g_heff_2ecompile_2esimplify_2easkedFor(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedFor_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindPushable(V);
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eetaCapturing(V);
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo;
V g_heff_2ecompile_2esimplify_2efieldBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldBound_clo;
V g_heff_2ecompile_2esimplify_2efieldsBound(V, V);
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo;
V g_heff_2ecompile_2esimplify_2efindArm(V, V);
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindArm_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2ehandedW(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedW_clo;
V g_heff_2ecompile_2esimplify_2einOrder(V, V);
V g_heff_2ecompile_2esimplify_2einOrder_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einOrder_clo;
V g_heff_2ecompile_2esimplify_2einlinedCall(V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlinedCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlinedCall_clo;
V g_heff_2ecompile_2esimplify_2eintOp(V, V, V);
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eintOp_clo;
V g_heff_2ecompile_2esimplify_2ekeptAsk(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo;
V g_heff_2ecompile_2esimplify_2eknownCopy(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo;
V g_heff_2ecompile_2esimplify_2eknownMade(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownMade_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownMade_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emarkSafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eorMarks(V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_clo;
V g_heff_2ecompile_2esimplify_2eorMarks_24dps(V, V, V);
V g_heff_2ecompile_2esimplify_2eorMarks_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eorMarks_24dps_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushArm_clo;
V g_heff_2ecompile_2esimplify_2epushBound(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushBound_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2erecordSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordSplit_clo;
V g_heff_2ecompile_2esimplify_2erecordTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordTakenApart_clo;
V g_heff_2ecompile_2esimplify_2ereplayBody(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo;
V g_heff_2ecompile_2esimplify_2esafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esafeAs_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2esumPushed(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etagApart(V, V, V);
V g_heff_2ecompile_2esimplify_2etagApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagApart_clo;
V g_heff_2ecompile_2esimplify_2etagBound(V);
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagBound_clo;
V g_heff_2ecompile_2esimplify_2etieGo(V, V, V);
V g_heff_2ecompile_2esimplify_2etieGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etieGo_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2espec_2ecallsOnce(V);
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsOnce_clo;
V g_list_2eany_24s604143829x1495140576(V, V);
V g_list_2eany_24s604143829x1495140576_entry(V self, V *a);
extern Clo g_list_2eany_24s604143829x1495140576_clo;
V g_list_2efoldl_24s1748401606x190338434(V, V);
V g_list_2efoldl_24s1748401606x190338434_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1748401606x190338434_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str6, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str7, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str8, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str9, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str11, 5, "False");
Clo g_heff_2ecompile_2esimplify_2eintOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eintOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str0), 2)) {
    heff_drop(v_p_240);
    V v_t_244 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str1), 2)) {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str2), 2)) {
        heff_drop(v_p_240);
        V v_t_248 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str3), 2)) {
          heff_drop(v_p_240);
          V v_t_2411;
          if (heff_intEq_c(v_a_241, v_b_242)) {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str4);
          } else {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str5);
          }
          V v_t_2412 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str6), 2)) {
            heff_drop(v_p_240);
            V v_t_2415;
            if (heff_intLt_c(v_a_241, v_b_242)) {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str7);
            } else {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str8);
            }
            V v_t_2416 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2415, NTAG(TAG_Nil), NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
          } else {
            if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str9))) {
              V v_t_2419;
              if (heff_intLe_c(v_a_241, v_b_242)) {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str10);
              } else {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str11);
              }
              V v_t_2420 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
            } else {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return NTAG(TAG_Nothing);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eintOp(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str1, 9, "strLength");
Clo g_heff_2ecompile_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str0))) {
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2427)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2429});
    } else {
      heff_drop(v_a_2427);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2431 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str1))) {
      V v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2431)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2433});
    } else {
      heff_drop(v_a_2431);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str0, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str1, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str3, 5, "False");
Clo g_heff_2ecompile_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      V v_b_2454 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eintOp(v_p_240, v_a_2428, v_b_2454);
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2464 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      V v_b_2492 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24EStr = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str0), 2)) {
        heff_drop(v_p_240);
        V v_t_2494 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2464, v_b_2492)});
        return heff_tag_at_n(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2494});
      } else {
        heff_drop_cell(v_ru_24x2_241_24EStr, 1);
        if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str1))) {
          V v_t_2497;
          if (heff_strEq_c(v_a_2464, v_b_2492)) {
            v_t_2497 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str2);
          } else {
            v_t_2497 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str3);
          }
          V v_t_2498 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2497, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2498});
        } else {
          heff_drop(v_a_2464);
          heff_drop(v_b_2492);
          heff_drop_cell(v_ru_24x3_242_24EStr, 1);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ehandedW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ehandedW_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ehandedW(V v_x_240, V v_kinds_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_245});
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x41_244, 0);
      V v_as_2411 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2446;
      switch (heff_tag_of(v_f_2410)) {
      case TAG_EVar: {
        V v_y_2412 = heff_dup(heff_field(v_f_2410, 0));
        v_t_2446 = heff_strEq_lent(v_x_240, v_y_2412, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2446 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_f_2410);
      }
      V v_t_2448;
      if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
        heff_drop(v_t_2446);
        V v_t_2447 = (g_list_2eany_24s604143829x1495140576(v_kinds_241, v_as_2411));
        if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
          heff_drop(v_t_2447);
          v_t_2448 = heff_intAdd(v_n_242, MK_INT(1LL));
        } else {
          heff_drop(v_t_2447);
          v_t_2448 = v_n_242;
        }
      } else {
        heff_drop(v_t_2446);
        v_t_2448 = v_n_242;
      }
      V v_t_2449 = (g_heff_2ecompile_2eir_2eappendI(v_as_2411, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_t_2448;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2449});
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2451 = heff_field(v_x41_244, 1);
      V v_b_2452 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_2453 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_a_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2452, v_rest_245})});
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2453;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2454 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2456 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2454, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2456;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2457 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2457, v_rest_245});
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2462 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2464 = (g_heff_2ecompile_2eir_2eappendI(v_as_2462, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2464;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_sc_2465 = heff_field(v_x41_244, 0);
      V v_arms_2466 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2467 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2466, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_sc_2465, v_t_2467});
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2470 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2471 = (g_heff_2ecompile_2eir_2eappendI(v_as_2470, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2471;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2473 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2474 = (g_heff_2ecompile_2eir_2eappendI(v_as_2473, v_rest_245));
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2474;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_kinds_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_x_240 = t_0;
      v_kinds_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2esimplify_2ehandedW_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ehandedW(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2efieldsBound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldsBound_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2efieldsBound_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2efieldsBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldsBound_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldsBound(V v_tag_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_tag_240);
    return ((V)&g_heff_2ecompile_2esimplify_2efieldsBound_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x2_241, 0);
    V v_as_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(g_heff_2ecompile_2esimplify_2efieldBound(heff_dup(v_tag_240), v_a_244));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2efieldsBound_lam1, 1, 3, (V[]){v_m_246, v_tag_240, v_as_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldsBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efieldsBound(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam0(V self, V *args) {
  V v_s_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_s_242});
}
V g_heff_2ecompile_2esimplify_2efieldsBound_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_tag_240 = heff_env(self)[1];
  V v_as_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_s_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_m_2411 = (g_heff_2ecompile_2esimplify_2efieldsBound(v_tag_240, v_as_245));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_x_2420;
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_bs_2415 = heff_field(v_x_249, 0);
        V v_e_2416 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 3ULL, 2);
        switch (heff_tag_of(v_x_2413)) {
        case TAG_MkPair: {
          V v_rest_2417 = heff_field(v_x_2413, 0);
          V v_es_2418 = heff_field(v_x_2413, 1);
          heff_take_n(v_x_2413, 3ULL, 2);
          V v_t_2419 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2415, v_rest_2417));
          v_x_2420 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, heff_tag_n(TAG_Cons, 2, (V[]){v_e_2416, v_es_2418})});
          break;
        }
        default: heff_nomatch(v_x_2413);
        }
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){v_x_2420, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2ecompile_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_244), v_a_242));
  V v_t_246 = (g_heff_2ecompile_2esimplify_2esumTakenApart(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_b_243)));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    heff_drop(v_t_246);
    V v_t_247 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_243, v_a_242));
    return heff_tail(v_t_247, 1, (V[]){v_s_244});
  } else {
    heff_drop(v_t_246);
    V v_t_248 = (g_heff_2ecompile_2esimplify_2etagApart(heff_dup(v_x_241), v_a_242, heff_dup(v_b_243)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      heff_drop(v_t_248);
      V v_m_249 = (g_heff_2ecompile_2esimplify_2etagBound(v_a_242));
      V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_244}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_s_2412 = heff_field(v_x2_2410, 1);
        V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
        V v_t_2415;
        switch (heff_tag_of(v_x_2411)) {
        case TAG_MkPair: {
          V v_y_2414 = heff_dup(heff_field(v_x_2411, 1));
          v_t_2415 = v_y_2414;
          break;
        }
        default: heff_nomatch(v_x_2411);
        }
        V v_m_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_t_2415, v_b_243}));
        V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2412}));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          V v_t_2422;
          switch (heff_tag_of(v_x_2411)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x_2411, 0);
            heff_take_n(v_x_2411, 1ULL, 2);
            v_t_2422 = v_x_2420;
            break;
          }
          default: heff_nomatch(v_x_2411);
          }
          V v_x_2423 = ({ V a_0 = v_t_2422; V a_1 = v_x_2418; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2422); r_; });
          return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2419});
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: return heff_nomatch(v_x2_2410);
      }
    } else {
      heff_drop(v_t_248);
      V v_t_2424 = (g_heff_2ecompile_2esimplify_2erecordTakenApart(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_b_243)));
      if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        heff_drop(v_t_2424);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2erecordSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_244);
      } else {
        heff_drop(v_t_2424);
        if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
          heff_drop(v_t_245);
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
          V v_t_2426 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2425));
          V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
          V v_t_2428 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2427));
          V v_t_2429 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2426, v_t_2428}), 0, 2);
          return (g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2429, v_s_244));
        } else {
          heff_drop(v_t_245);
          V v_t_2430 = (g_heff_2ecompile_2esimplify_2epartialApp(heff_dup(v_s_244), v_a_242));
          if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
            heff_drop(v_t_2430);
            HEFF_LAST return g_heff_2ecompile_2esimplify_2eletSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_244);
          } else {
            heff_drop(v_t_2430);
            V v_m_2431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
            V v_x2_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_244}));
            switch (heff_tag_of(v_x2_2432)) {
            case TAG_MkPair: {
              V v_x_2433 = heff_field(v_x2_2432, 0);
              V v_s_2434 = heff_field(v_x2_2432, 1);
              V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
              return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2433}), v_s_2434});
            }
            default: return heff_nomatch(v_x2_2432);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownCopy_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknownCopy(V v_s_240, V v_g_241, V v_as_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  V v_x3_244 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
    V v_t_248 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_247; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_247); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_g_241);
      heff_drop(v_as_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_b_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 7, 9), 1, 7);
      V v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = v_b_249; V a_2 = v_as_242; V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
      V v_lim_2412;
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        v_lim_2412 = MK_INT(160LL);
      } else {
        heff_drop(v_t_2411);
        v_lim_2412 = MK_INT(50LL);
      }
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_249), NTAG(TAG_Nil)});
      V v_x_2414 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2412), MK_INT(0LL), v_t_2413));
      if (heff_intLt_c(v_lim_2412, v_x_2414)) {
        heff_drop(v_g_241);
        heff_drop(v_b_249);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_2416 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_249)));
        V v_t_2417 = (g_heff_2ecompile_2eir_2enubI(v_t_2416));
        V v_x1_2418 = ({ V a_0 = v_g_241; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2417); r_; });
        if ((heff_dup(v_x1_2418) == NTAG(TAG_True))) {
          heff_drop(v_b_249);
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          heff_drop(v_x1_2418);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_2418);
          return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_b_249});
        }
      }
    }
    default: return heff_nomatch(v_t_248);
    }
  } else {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_g_241);
    heff_drop(v_as_242);
    heff_drop(v_t_246);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownCopy(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2easkedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkedFor_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkedFor(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_x_245 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_244));
  V v_t_248;
  if (heff_intLt_c(MK_INT(1200LL), v_x_245)) {
    v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  } else {
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
    v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b0_241), v_t_247));
  }
  V v_t_2443;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2443 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2443 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2445;
  if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
    heff_drop(v_t_2443);
    V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    v_t_2445 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), v_t_2444));
  } else {
    heff_drop(v_t_2443);
    v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
  }
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 2, 7);
  V v_t_2447 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_b0_241, v_t_2446));
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 3, 7);
  V v_t_2449 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_d_242, v_t_2448));
  V v_t_2450 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 4, 7);
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 5, 7);
  V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 6, 7);
  V v_p_2453 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_248, v_t_2445, v_t_2447, v_t_2449, v_t_2450, heff_intAdd(v_t_2451, MK_INT(1LL)), v_t_2452});
  V v_t_2454 = ({ V rv_7 = v_p_2453; V rr_ = heff_rec_reuse_nf(v_s_243, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2454});
}
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2easkedFor(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2easkKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkKept(V v_h_240, V v_kc_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_kc_241, 5);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_p_243});
  }
  case TAG_Just: {
    V v_b_244 = heff_field(v_x3_242, 0);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2ecopy(heff_dup(v_b_244), v_p_243));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_240), v_x_246, heff_take_field(v_kc_241, 2), v_s_247));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_s_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 2ULL, 2);
        V v_x2_2411 = ({ V b_0 = heff_get_n(v_kc_241, 3, 5); V a_1 = v_h_240; V a_2 = v_s_2410; V r_ = (g_heff_2ecompile_2esimplify_2emarkSafeAs(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_MkPair: {
          V v_s_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 2ULL, 2);
          return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_2413});
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2easkKept(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eallAsked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallAsked_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallAsked(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_p_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_h_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2ekeptAsk(v_h_244, v_v_245, v_p_241));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_247);
          V t_0 = v_rest_243;
          V t_1 = v_s_248;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        } else {
          heff_drop(v_rest_243);
          heff_drop(v_x_247);
          return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_248});
        }
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallAsked(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eorMarks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eorMarks_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eorMarks(V v_ms_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_ms_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return v_ms_240;
  }
  case TAG_Cons: {
    V v_m_242 = heff_dup(heff_field(v_ms_240, 0));
    V v_ms2_243 = heff_dup(heff_field(v_ms_240, 1));
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms2_243);
      return v_ms_240;
    }
    case TAG_Cons: {
      V v_n_244 = heff_field(v_x2_241, 0);
      V v_ns_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      heff_drop_tag(v_ms_240, 2);
      V v_t_246;
      if ((heff_dup(v_m_242) == NTAG(TAG_True))) {
        heff_drop(v_m_242);
        heff_drop(v_n_244);
        v_t_246 = NTAG(TAG_True);
      } else {
        heff_drop(v_m_242);
        v_t_246 = v_n_244;
      }
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_heff_2ecompile_2esimplify_2eorMarks_24dps(v_ms2_243, v_ns_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_ms_240);
  }
}
V g_heff_2ecompile_2esimplify_2eorMarks_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eorMarks(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eetaCapturing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaCapturing_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eetaCapturing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_x_246 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(MK_INT(60LL), v_x_246)) {
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
      V v_x_249 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(60LL), v_x_249)) {
        heff_drop(v_xs_243);
        heff_drop(v_b_244);
        return NTAG(TAG_False);
      } else {
        return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsOnce(b_0)); heff_drop(b_0); r_; });
      }
    } else {
      V v_t_2411 = ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}); V r_ = (g_heff_2ecompile_2espec_2ecallsNothing(b_0)); heff_drop(b_0); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_xs_243);
        heff_drop(v_b_244);
        heff_drop(v_t_2411);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2411);
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
        V v_x_2413 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(60LL), MK_INT(0LL), v_t_2412));
        if (heff_intLt_c(MK_INT(60LL), v_x_2413)) {
          heff_drop(v_xs_243);
          heff_drop(v_b_244);
          return NTAG(TAG_False);
        } else {
          return ({ V b_0 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2ecallsOnce(b_0)); heff_drop(b_0); r_; });
        }
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eetaCapturing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eetaCapturing(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2eletsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOut_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eletsOut(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ELet: {
    V v_x_247 = heff_field(v_e_240, 0);
    V v_a_248 = heff_field(v_e_240, 1);
    V v_e3_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_x3_2410 = (g_heff_2ecompile_2esimplify_2eletsOut(v_e3_249));
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_MkPair: {
      V v_bds_2411 = heff_field(v_x3_2410, 0);
      V v_e_2412 = heff_field(v_x3_2410, 1);
      V v_ru_24x3_2410_24MkPair = heff_take_reuse_n(v_x3_2410, 3ULL, 2);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, v_a_248}), v_bds_2411});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_e_2412});
    }
    default: return heff_nomatch(v_x3_2410);
    }
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletsOut(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  V v_it_245 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_r_240);
    V v_x_246 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_243});
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_EVar: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_243});
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_it1_247, 0);
      V v_b_2413 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      heff_drop_cell(v_ru_24it_245_24Just, 1);
      return (g_heff_2ecompile_2esimplify_2especLam(v_r_240, v_g_241, v_xs_2412, v_b_2413, v_as_242, v_s_243));
    }
    case TAG_EApp: {
      V v_ru_24it1_247_24EApp = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EApp, TAG_MkPair, 2, (V[]){v_x_2416, v_s_243});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2420 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_243});
    }
    case TAG_ERecord: {
      V v_ru_24it1_247_24ERecord = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2423 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ERecord, TAG_MkPair, 2, (V[]){v_x_2423, v_s_243});
    }
    case TAG_EProj: {
      heff_take_n(v_it1_247, 0ULL, 4);
      heff_drop(v_r_240);
      V v_x_2428 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_s_243});
    }
    case TAG_ETag: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2432 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2432, v_s_243});
    }
    case TAG_EMatch: {
      V v_ru_24it1_247_24EMatch = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2435 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EMatch, TAG_MkPair, 2, (V[]){v_x_2435, v_s_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2437 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2437, v_s_243});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_247_24EPrimCall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2440 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2440, v_s_243});
    }
    case TAG_ECall: {
      V v_ru_24it1_247_24ECall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2443 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ECall, TAG_MkPair, 2, (V[]){v_x_2443, v_s_243});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2445 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2445, v_s_243});
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2447 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_s_243});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2449 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2449, v_s_243});
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2451 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_s_243});
    }
    case TAG_EFixed: {
      V v_ru_24it1_247_24EFixed = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2454 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFixed, TAG_MkPair, 2, (V[]){v_x_2454, v_s_243});
    }
    case TAG_EFloat32: {
      heff_take_na(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2456 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2456, v_s_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_2457 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2457, v_s_243});
    }
    case TAG_EFix: {
      V v_ru_24it1_247_24EFix = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2460 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFix, TAG_MkPair, 2, (V[]){v_x_2460, v_s_243});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindPushable_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindPushable_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2ebindPushable_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindPushable_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2ebindPushable_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindPushable_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindPushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ebindPushable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2ebindPushable_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_245 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_a_243)));
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2ecompile_2esimplify_2ebindPushable_lam1, 1, 2, (V[]){v_x1_245, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindPushable_lam2, 2, 1, (V[]){v_as_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindPushable(a[0]);
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_s_241});
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam1(V self, V *args) {
  V v_p_246 = args[0];
  V v_x1_245 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_x1_245);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_246});
  } else {
    heff_drop(v_x1_245);
    V v_x2_248 = (g_heff_2ecompile_2esimplify_2efreshName(((V)&g_heff_2ecompile_2esimplify_2ebindPushable_str0), v_p_246));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_dup(v_x_249), v_a_243})});
      V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, heff_tag_n(TAG_EVar, 1, (V[]){v_x_249})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_s_2410});
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam2(V self, V *args) {
  V v_one_2413 = args[0];
  V v_z_2414 = args[1];
  V v_as_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2415 = heff_tr(g_heff_2ecompile_2esimplify_2ebindPushable(v_as_244));
  V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_2414}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_s_2418 = heff_field(v_x2_2416, 1);
    V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_one_2413)) {
    case TAG_MkPair: {
      V v_x11_2419 = heff_field(v_one_2413, 0);
      V v_a_2420 = heff_field(v_one_2413, 1);
      heff_take_n(v_one_2413, 3ULL, 2);
      switch (heff_tag_of(v_x11_2419)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2417)) {
        case TAG_MkPair: {
          V v_bds_2421 = heff_field(v_x_2417, 0);
          V v_as_2422 = heff_field(v_x_2417, 1);
          heff_take_n(v_x_2417, 3ULL, 2);
          v_t_2426 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2420, v_as_2422})});
          break;
        }
        default: heff_nomatch(v_x_2417);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2423 = heff_field(v_x11_2419, 0);
        heff_take_n(v_x11_2419, 1ULL, 1);
        switch (heff_tag_of(v_x_2417)) {
        case TAG_MkPair: {
          V v_bds_2424 = heff_field(v_x_2417, 0);
          V v_as_2425 = heff_field(v_x_2417, 1);
          heff_take_n(v_x_2417, 3ULL, 2);
          v_t_2426 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2423, v_bds_2424}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2420, v_as_2425})});
          break;
        }
        default: heff_nomatch(v_x_2417);
        }
        break;
      }
      default: heff_nomatch(v_x11_2419);
      }
      break;
    }
    default: heff_nomatch(v_one_2413);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_s_2418});
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epushBound_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epushBound_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epushBound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushBound_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epushBound(V v_r_240, V v_s_241, V v_arms_242, V v_as_243) {
top: ;
  V v_m_244 = heff_tr(g_heff_2ecompile_2esimplify_2ebindPushable(v_as_243));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_lam0, 1, 4, (V[]){v_m_244, v_r_240, v_arms_242, v_s_241});
}
V g_heff_2ecompile_2esimplify_2epushBound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushBound(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2epushBound_lam2(V self, V *args) {
  V v_s_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_2412 = heff_env(self)[2];
  V v_t_2410 = heff_env(self)[3];
  V v_vs_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_y_2415 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 2ULL, 2);
    v_t_2416 = v_y_2415;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_x2_2417 = (g_heff_2ecompile_2esimplify_2etraverseS_24s837521711x2092122562(v_t_2416, v_s_2413));
  V v_x2_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_s_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_x2_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 3, (V[]){v_b_2412, v_x_2418, v_s_2419}));
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_s_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24MkPair = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_vs_2411, v_x_2421}), v_s_2422});
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_lam1(V self, V *args) {
  V v_a_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_249)) {
  case TAG_MkArm: {
    V v_t_2410 = heff_field(v_a_249, 0);
    V v_vs_2411 = heff_field(v_a_249, 1);
    V v_b_2412 = heff_field(v_a_249, 2);
    heff_take_n(v_a_249, 7ULL, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_lam2, 1, 5, (V[]){v_x_247, v_r_240, v_b_2412, v_t_2410, v_vs_2411});
  }
  default: return heff_nomatch(v_a_249);
  }
}
V g_heff_2ecompile_2esimplify_2epushBound_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2epushBound_lam1, 1, 2, (V[]){heff_dup(v_x_247), v_r_240}), v_arms_242));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
      V v_t_2429;
      switch (heff_tag_of(v_x_247)) {
      case TAG_MkPair: {
        V v_x_2427 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 2);
        v_t_2429 = v_x_2427;
        break;
      }
      default: heff_nomatch(v_x_247);
      }
      V v_x_2430 = ({ V a_0 = v_t_2429; V a_1 = heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_EMatch, 2, (V[]){v_s_241, v_x_2425}); V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2429); r_; });
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2430, v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojectF_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_sh_242, V v_t_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam0, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_247 = heff_dup(heff_field(v_e_244, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam1, 1, 6, (V[]){v_g_247, v_e_244, v_l_241, v_sh_242, v_t_243, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam2, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam3, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_e_244, 0);
    V v_a_2422 = heff_field(v_e_244, 1);
    V v_b_2423 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 4, (V[]){v_l_241, v_sh_242, v_t_243, v_b_2423}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam4, 1, 3, (V[]){v_m_2424, v_x_2421, v_a_2422});
  }
  case TAG_ERecord: {
    V v_fs_2429 = heff_field(v_e_244, 0);
    V v_ts_2430 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    heff_drop_rec(v_r_240, 4);
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2efindField(heff_dup(v_l_241), v_fs_2429));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam5, 1, 5, (V[]){v_fs_2429, v_ts_2430, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_Just: {
      V v_v_2434 = heff_field(v_t_2431, 0);
      heff_take_n(v_t_2431, 1ULL, 1);
      V v_m_2435 = (g_heff_2ecompile_2esimplify_2eothersPure(heff_dup(v_l_241), heff_dup(v_fs_2429)));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam6, 1, 7, (V[]){v_m_2435, v_v_2434, v_fs_2429, v_ts_2430, v_l_241, v_sh_242, v_t_243});
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam7, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam8, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam9, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam10, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam11, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam12, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam13, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam14, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam15, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam16, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam17, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam18, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam19, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam20, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojectF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_246});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_r_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(v_g_247, heff_rfield(v_s_248, 2)));
  V v_x2_2410 = (g_heff_2ecompile_2esimplify_2efueled(v_t_249, v_s_248));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2412});
    }
    case TAG_Just: {
      V v_b_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2410_24MkPair, 2);
      V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 4, (V[]){heff_dup(v_l_241), heff_dup(v_sh_242), heff_dup(v_t_243), v_b_2413}));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_m_2414, v_s_2412));
    }
    default: return heff_nomatch(v_x_2411);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2417});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2420});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_a_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_s_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_s_2428 = heff_field(v_x2_2426, 1);
    V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2421, v_a_2422, v_x_2427}), v_s_2428});
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_fs_2429 = heff_env(self)[0];
  V v_ts_2430 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2429, v_ts_2430}), v_l_241, v_sh_242, v_t_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_2432});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_v_2434 = heff_env(self)[1];
  V v_fs_2429 = heff_env(self)[2];
  V v_ts_2430 = heff_env(self)[3];
  V v_l_241 = heff_env(self)[4];
  V v_sh_242 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440;
    if ((heff_dup(v_x_2438) == NTAG(TAG_True))) {
      heff_drop(v_fs_2429);
      heff_drop(v_ts_2430);
      heff_drop(v_l_241);
      heff_drop(v_sh_242);
      heff_drop(v_t_243);
      heff_drop(v_x_2438);
      v_t_2440 = v_v_2434;
    } else {
      heff_drop(v_v_2434);
      heff_drop(v_x_2438);
      v_t_2440 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2429, v_ts_2430}), v_l_241, v_sh_242, v_t_243});
    }
    return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){v_t_2440, v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2445});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2449 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2449});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2452 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2452});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2454 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2454});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2457 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2457});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2460 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2460});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2462 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2462});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2464});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2466 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2466});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2468 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2468});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2471 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2471});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args) {
  V v_s_2473 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2473});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args) {
  V v_s_2474 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2474});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args) {
  V v_s_2477 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2477});
}
Clo g_heff_2ecompile_2esimplify_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindArm_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 0)) {
        heff_drop(v_t_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(v_t2_244), heff_dup(v_vs_245), heff_dup(v_b_246)})});
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindArm(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2epushArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushArm_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    V v_x2_248 = (g_heff_2ecompile_2esimplify_2ecopy(v_t_247, v_p_243));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2445;
      switch (heff_tag_of(v_x_249)) {
      case TAG_EVar: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_249, 0ULL, 4);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2430 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2445 = v_arms_2430;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_m_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_246, v_t_2445}));
      V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x2_2447, 0);
        V v_s_2449 = heff_field(v_x2_2447, 1);
        heff_take_n(v_x2_2447, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2448}), v_s_2449});
      }
      default: return heff_nomatch(v_x2_2447);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushArm(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924(V v_lit_240, V v_lit_241, V v_x2_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_243});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2epushArm(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244, v_p_243));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      V v_x2_249 = (g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924(v_lit_240, v_lit_241, v_xs_245, v_s_248));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_x_2410}), v_s_2411});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s579860258x1674816924(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_x_244 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_243));
  V v_t_247;
  if (heff_intLt_c(MK_INT(1200LL), v_x_244)) {
    v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
    v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), v_t_246));
  }
  V v_t_2442;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 4);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2444;
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
    v_t_2444 = (g_map_2einsert_24s1341440536x470972936(v_key_240, NTAG(TAG_MkUnit), v_t_2443));
  } else {
    heff_drop(v_key_240);
    heff_drop(v_t_2442);
    v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
  }
  V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 3, 7);
  V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 4, 7);
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 5, 7);
  V v_t_2449 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 6, 7);
  V v_p_2450 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_247, v_t_2444, v_t_2445, v_t_2446, v_t_2447, v_t_2448, v_t_2449});
  return ({ V rv_7 = v_p_2450; V rr_ = heff_rec_reuse_nf(v_s_242, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeFresh_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeFresh(V v_h_240, V v_b0_241, V v_s_242) {
top: ;
  V v_k_243 = heff_dup(heff_rfield(v_s_242, 8));
  V v_t_244 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_k_243, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_245 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), heff_take_field(v_s_242, 3), heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 6), heff_take_field(v_s_242, 7), v_t_244});
  V v_t_246 = (g_heff_2ecompile_2esimplify_2eownSt(v_t_245));
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkPair: {
    V v_s_248 = heff_field(v_t_246, 1);
    V v_ru_24t_246_24MkPair = heff_take_reuse_n(v_t_246, 2ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b0_241));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      V v_m_2413 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2411));
      V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        heff_take_n(v_x2_2414, 3ULL, 2);
        V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2415, v_s_2416));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          V v_k_2420 = heff_dup(heff_rfield(v_s_2419, 8));
          V v_t_2421 = heff_get_n(heff_get_n(v_s_242, 8, 9), 2, 5);
          V v_t_2422 = heff_get_n(heff_dup(heff_rfield(v_s_2419, 8)), 2, 5);
          V v_t_2423 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_t_2422, heff_take_field(v_k_2420, 4)));
          V v_k_2424 = ({ V rv_2 = v_t_2421; V rv_4 = v_t_2423; V rr_ = heff_rec_reuse_nf(v_k_2420, 11ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 207u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_t_2425 = ({ V rv_8 = v_k_2424; V rr_ = heff_rec_reuse_nf(v_s_2419, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
          return heff_tag_at_n(v_ru_24t_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_t_2425});
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeFresh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eknownMade_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownMade_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknownMade(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = heff_dup(v_h_240); V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b_241), heff_dup(g_map_2eempty_get())));
  V v_t_246 = ({ V a_0 = v_t_245; V a_1 = heff_dup(v_h_240); V r_ = (g_heff_2ecompile_2esimplify_2earityIn(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_2411;
  if (heff_intLt_c(v_t_244, v_t_246)) {
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
    V v_x_249 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_248));
    if (heff_intLt_c(MK_INT(1200LL), v_x_249)) {
      heff_drop(v_h_240);
      heff_drop(v_b_241);
      v_t_2411 = v_s_242;
    } else {
      v_t_2411 = (g_heff_2ecompile_2esimplify_2erecordAll(v_h_240, v_b_241, v_s_242));
    }
  } else {
    heff_drop(v_h_240);
    heff_drop(v_b_241);
    v_t_2411 = v_s_242;
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2411});
}
V g_heff_2ecompile_2esimplify_2eknownMade_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownMade(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etieGo_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2etieGo_lam42(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etieGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etieGo_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etieGo(V v_h_240, V v_lam1_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam0, 1, 1, (V[]){v_e_242});
  }
  case TAG_EGlobal: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam1, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_b_248));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam2, 1, 2, (V[]){v_m_249, v_xs_247});
  }
  case TAG_EApp: {
    V v_e1_2414 = heff_field(v_e_242, 0);
    V v_as_2415 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2414)) {
    case TAG_EVar: {
      V v_m_2417 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam3, 1, 4, (V[]){v_m_2417, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EGlobal: {
      V v_g_2427 = heff_field(v_e1_2414, 0);
      heff_take_n(v_e1_2414, 1ULL, 1);
      V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){heff_dup(v_h_240), heff_dup(v_lam1_241)}));
      V v_m_2429 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2428, v_as_2415));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam4, 1, 4, (V[]){v_m_2429, v_g_2427, v_h_240, v_lam1_241});
    }
    case TAG_ELam: {
      V v_m_2438 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam5, 1, 4, (V[]){v_m_2438, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EApp: {
      V v_m_2450 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam6, 1, 4, (V[]){v_m_2450, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_ELet: {
      V v_m_2463 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam7, 1, 4, (V[]){v_m_2463, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_ERecord: {
      V v_m_2475 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam8, 1, 4, (V[]){v_m_2475, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EProj: {
      V v_m_2489 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam9, 1, 4, (V[]){v_m_2489, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_ETag: {
      V v_m_24102 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam10, 1, 4, (V[]){v_m_24102, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EMatch: {
      V v_m_24114 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam11, 1, 4, (V[]){v_m_24114, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EPrim: {
      V v_m_24125 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam12, 1, 4, (V[]){v_m_24125, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EPrimCall: {
      V v_m_24137 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam13, 1, 4, (V[]){v_m_24137, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_ECall: {
      V v_m_24149 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam14, 1, 4, (V[]){v_m_24149, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EInt: {
      V v_m_24160 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam15, 1, 4, (V[]){v_m_24160, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EFloat: {
      V v_m_24171 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam16, 1, 4, (V[]){v_m_24171, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EStr: {
      V v_m_24182 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam17, 1, 4, (V[]){v_m_24182, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EBytes: {
      V v_m_24193 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam18, 1, 4, (V[]){v_m_24193, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EFixed: {
      V v_m_24205 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam19, 1, 4, (V[]){v_m_24205, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EFloat32: {
      V v_m_24216 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam20, 1, 4, (V[]){v_m_24216, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EAbandon: {
      V v_m_24226 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam21, 1, 4, (V[]){v_m_24226, v_h_240, v_lam1_241, v_as_2415});
    }
    case TAG_EFix: {
      V v_m_24238 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_e1_2414));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam22, 1, 4, (V[]){v_m_24238, v_h_240, v_lam1_241, v_as_2415});
    }
    default: return heff_nomatch(v_e1_2414);
    }
  }
  case TAG_ELet: {
    V v_x_24248 = heff_field(v_e_242, 0);
    V v_a_24249 = heff_field(v_e_242, 1);
    V v_b_24250 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_24251 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_a_24249));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam23, 1, 5, (V[]){v_m_24251, v_h_240, v_lam1_241, v_b_24250, v_x_24248});
  }
  case TAG_ERecord: {
    V v_fs_24260 = heff_field(v_e_242, 0);
    V v_ts_24261 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_f_24262 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24271 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam24, 1, 1, (V[]){v_f_24262}), v_fs_24260));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam26, 1, 2, (V[]){v_m_24271, v_ts_24261});
  }
  case TAG_EProj: {
    V v_e1_24276 = heff_field(v_e_242, 0);
    V v_l_24277 = heff_field(v_e_242, 1);
    V v_sh_24278 = heff_field(v_e_242, 2);
    V v_t_24279 = heff_field(v_e_242, 3);
    heff_take_n(v_e_242, 15ULL, 4);
    V v_m_24280 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_e1_24276));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam27, 1, 4, (V[]){v_m_24280, v_l_24277, v_sh_24278, v_t_24279});
  }
  case TAG_ETag: {
    V v_t_24285 = heff_field(v_e_242, 0);
    V v_as_24286 = heff_field(v_e_242, 1);
    V v_ts_24287 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_24288 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24289 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24288, v_as_24286));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam28, 1, 3, (V[]){v_m_24289, v_t_24285, v_ts_24287});
  }
  case TAG_EMatch: {
    V v_sc_24294 = heff_field(v_e_242, 0);
    V v_arms_24295 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24296 = (g_heff_2ecompile_2esimplify_2etieGo(heff_dup(v_h_240), heff_dup(v_lam1_241), v_sc_24294));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam29, 1, 4, (V[]){v_m_24296, v_h_240, v_lam1_241, v_arms_24295});
  }
  case TAG_EPrim: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam32, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_24317 = heff_field(v_e_242, 0);
    V v_as_24318 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24319 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24320 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24319, v_as_24318));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam33, 1, 2, (V[]){v_m_24320, v_p_24317});
  }
  case TAG_ECall: {
    V v_g_24325 = heff_field(v_e_242, 0);
    V v_as_24326 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24327 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24328 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24327, v_as_24326));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam34, 1, 2, (V[]){v_m_24328, v_g_24325});
  }
  case TAG_EInt: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam35, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam36, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam37, 1, 1, (V[]){v_e_242});
  }
  case TAG_EBytes: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam38, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam39, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam40, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam41, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_h_240);
    heff_drop(v_lam1_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam42, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etieGo(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2etieGo_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_244});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_246});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_xs_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_MkPair: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_s_2413 = heff_field(v_x2_2411, 1);
    V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_247, v_x_2412}), v_s_2413});
  }
  default: return heff_nomatch(v_x2_2411);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_t_2422 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2422, v_as_2415));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2421}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2420, v_x_2425}), v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam4(V self, V *args) {
  V v_s_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_g_2427 = heff_env(self)[1];
  V v_h_240 = heff_env(self)[2];
  V v_lam1_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_s_2430}));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_s_2433 = heff_field(v_x2_2431, 1);
    V v_ru_24x2_2431_24MkPair = heff_take_reuse_n(v_x2_2431, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2427, v_h_240, 0)) {
      heff_drop(v_g_2427);
      heff_drop_cell(v_ru_24x2_2431_24MkPair, 2);
      return (g_heff_2ecompile_2esimplify_2einlinedCall(v_h_240, v_lam1_241, v_x_2432, v_s_2433));
    } else {
      heff_drop(v_h_240);
      heff_drop(v_lam1_241);
      V v_t_2435 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2427}), v_x_2432});
      return heff_tag_at_n(v_ru_24x2_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2435, v_s_2433});
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam5(V self, V *args) {
  V v_s_2439 = args[0];
  V v_m_2438 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2440 = heff_tr(heff_call(v_m_2438, 1, (V[]){v_s_2439}));
  switch (heff_tag_of(v_x2_2440)) {
  case TAG_MkPair: {
    V v_x_2441 = heff_field(v_x2_2440, 0);
    V v_s_2442 = heff_field(v_x2_2440, 1);
    V v_ru_24x2_2440_24MkPair = heff_take_reuse_n(v_x2_2440, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2444 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2443, v_as_2415));
    V v_x2_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2442}));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_MkPair: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_s_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2441, v_x_2446}), v_s_2447});
    }
    default: return heff_nomatch(v_x2_2445);
    }
  }
  default: return heff_nomatch(v_x2_2440);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam6(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2456 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2455, v_as_2415));
    V v_x2_2457 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_s_2454}));
    switch (heff_tag_of(v_x2_2457)) {
    case TAG_MkPair: {
      V v_x_2458 = heff_field(v_x2_2457, 0);
      V v_s_2459 = heff_field(v_x2_2457, 1);
      heff_take_n(v_x2_2457, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2453, v_x_2458}), v_s_2459});
    }
    default: return heff_nomatch(v_x2_2457);
    }
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam7(V self, V *args) {
  V v_s_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_s_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2469 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2468, v_as_2415));
    V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2467}));
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_s_2472 = heff_field(v_x2_2470, 1);
      heff_take_n(v_x2_2470, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2466, v_x_2471}), v_s_2472});
    }
    default: return heff_nomatch(v_x2_2470);
    }
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam8(V self, V *args) {
  V v_s_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2477 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_s_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkPair: {
    V v_x_2478 = heff_field(v_x2_2477, 0);
    V v_s_2479 = heff_field(v_x2_2477, 1);
    V v_ru_24x2_2477_24MkPair = heff_take_reuse_n(v_x2_2477, 3ULL, 2);
    V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2481 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2480, v_as_2415));
    V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2479}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_s_2484 = heff_field(v_x2_2482, 1);
      heff_take_n(v_x2_2482, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2478, v_x_2483}), v_s_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam9(V self, V *args) {
  V v_s_2490 = args[0];
  V v_m_2489 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2491 = heff_tr(heff_call(v_m_2489, 1, (V[]){v_s_2490}));
  switch (heff_tag_of(v_x2_2491)) {
  case TAG_MkPair: {
    V v_x_2492 = heff_field(v_x2_2491, 0);
    V v_s_2493 = heff_field(v_x2_2491, 1);
    V v_ru_24x2_2491_24MkPair = heff_take_reuse_n(v_x2_2491, 3ULL, 2);
    V v_t_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_2495 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2494, v_as_2415));
    V v_x2_2496 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2493}));
    switch (heff_tag_of(v_x2_2496)) {
    case TAG_MkPair: {
      V v_x_2497 = heff_field(v_x2_2496, 0);
      V v_s_2498 = heff_field(v_x2_2496, 1);
      heff_take_n(v_x2_2496, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2492, v_x_2497}), v_s_2498});
    }
    default: return heff_nomatch(v_x2_2496);
    }
  }
  default: return heff_nomatch(v_x2_2491);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam10(V self, V *args) {
  V v_s_24103 = args[0];
  V v_m_24102 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24104 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_s_24103}));
  switch (heff_tag_of(v_x2_24104)) {
  case TAG_MkPair: {
    V v_x_24105 = heff_field(v_x2_24104, 0);
    V v_s_24106 = heff_field(v_x2_24104, 1);
    V v_ru_24x2_24104_24MkPair = heff_take_reuse_n(v_x2_24104, 3ULL, 2);
    V v_t_24107 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24108 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24107, v_as_2415));
    V v_x2_24109 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_s_24106}));
    switch (heff_tag_of(v_x2_24109)) {
    case TAG_MkPair: {
      V v_x_24110 = heff_field(v_x2_24109, 0);
      V v_s_24111 = heff_field(v_x2_24109, 1);
      heff_take_n(v_x2_24109, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24104_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24105, v_x_24110}), v_s_24111});
    }
    default: return heff_nomatch(v_x2_24109);
    }
  }
  default: return heff_nomatch(v_x2_24104);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam11(V self, V *args) {
  V v_s_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24116 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_s_24115}));
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_MkPair: {
    V v_x_24117 = heff_field(v_x2_24116, 0);
    V v_s_24118 = heff_field(v_x2_24116, 1);
    V v_ru_24x2_24116_24MkPair = heff_take_reuse_n(v_x2_24116, 3ULL, 2);
    V v_t_24119 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24120 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24119, v_as_2415));
    V v_x2_24121 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_s_24118}));
    switch (heff_tag_of(v_x2_24121)) {
    case TAG_MkPair: {
      V v_x_24122 = heff_field(v_x2_24121, 0);
      V v_s_24123 = heff_field(v_x2_24121, 1);
      heff_take_n(v_x2_24121, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24116_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24117, v_x_24122}), v_s_24123});
    }
    default: return heff_nomatch(v_x2_24121);
    }
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam12(V self, V *args) {
  V v_s_24126 = args[0];
  V v_m_24125 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24127 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_s_24126}));
  switch (heff_tag_of(v_x2_24127)) {
  case TAG_MkPair: {
    V v_x_24128 = heff_field(v_x2_24127, 0);
    V v_s_24129 = heff_field(v_x2_24127, 1);
    V v_ru_24x2_24127_24MkPair = heff_take_reuse_n(v_x2_24127, 3ULL, 2);
    V v_t_24130 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24131 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24130, v_as_2415));
    V v_x2_24132 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_s_24129}));
    switch (heff_tag_of(v_x2_24132)) {
    case TAG_MkPair: {
      V v_x_24133 = heff_field(v_x2_24132, 0);
      V v_s_24134 = heff_field(v_x2_24132, 1);
      heff_take_n(v_x2_24132, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24127_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24128, v_x_24133}), v_s_24134});
    }
    default: return heff_nomatch(v_x2_24132);
    }
  }
  default: return heff_nomatch(v_x2_24127);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam13(V self, V *args) {
  V v_s_24138 = args[0];
  V v_m_24137 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24139 = heff_tr(heff_call(v_m_24137, 1, (V[]){v_s_24138}));
  switch (heff_tag_of(v_x2_24139)) {
  case TAG_MkPair: {
    V v_x_24140 = heff_field(v_x2_24139, 0);
    V v_s_24141 = heff_field(v_x2_24139, 1);
    V v_ru_24x2_24139_24MkPair = heff_take_reuse_n(v_x2_24139, 3ULL, 2);
    V v_t_24142 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24143 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24142, v_as_2415));
    V v_x2_24144 = heff_tr(heff_call(v_m_24143, 1, (V[]){v_s_24141}));
    switch (heff_tag_of(v_x2_24144)) {
    case TAG_MkPair: {
      V v_x_24145 = heff_field(v_x2_24144, 0);
      V v_s_24146 = heff_field(v_x2_24144, 1);
      heff_take_n(v_x2_24144, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24139_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24140, v_x_24145}), v_s_24146});
    }
    default: return heff_nomatch(v_x2_24144);
    }
  }
  default: return heff_nomatch(v_x2_24139);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam14(V self, V *args) {
  V v_s_24150 = args[0];
  V v_m_24149 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24151 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_s_24150}));
  switch (heff_tag_of(v_x2_24151)) {
  case TAG_MkPair: {
    V v_x_24152 = heff_field(v_x2_24151, 0);
    V v_s_24153 = heff_field(v_x2_24151, 1);
    V v_ru_24x2_24151_24MkPair = heff_take_reuse_n(v_x2_24151, 3ULL, 2);
    V v_t_24154 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24155 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24154, v_as_2415));
    V v_x2_24156 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_s_24153}));
    switch (heff_tag_of(v_x2_24156)) {
    case TAG_MkPair: {
      V v_x_24157 = heff_field(v_x2_24156, 0);
      V v_s_24158 = heff_field(v_x2_24156, 1);
      heff_take_n(v_x2_24156, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24152, v_x_24157}), v_s_24158});
    }
    default: return heff_nomatch(v_x2_24156);
    }
  }
  default: return heff_nomatch(v_x2_24151);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam15(V self, V *args) {
  V v_s_24161 = args[0];
  V v_m_24160 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24162 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_s_24161}));
  switch (heff_tag_of(v_x2_24162)) {
  case TAG_MkPair: {
    V v_x_24163 = heff_field(v_x2_24162, 0);
    V v_s_24164 = heff_field(v_x2_24162, 1);
    V v_ru_24x2_24162_24MkPair = heff_take_reuse_n(v_x2_24162, 3ULL, 2);
    V v_t_24165 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24166 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24165, v_as_2415));
    V v_x2_24167 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_s_24164}));
    switch (heff_tag_of(v_x2_24167)) {
    case TAG_MkPair: {
      V v_x_24168 = heff_field(v_x2_24167, 0);
      V v_s_24169 = heff_field(v_x2_24167, 1);
      heff_take_n(v_x2_24167, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24162_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24163, v_x_24168}), v_s_24169});
    }
    default: return heff_nomatch(v_x2_24167);
    }
  }
  default: return heff_nomatch(v_x2_24162);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam16(V self, V *args) {
  V v_s_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_s_24172}));
  switch (heff_tag_of(v_x2_24173)) {
  case TAG_MkPair: {
    V v_x_24174 = heff_field(v_x2_24173, 0);
    V v_s_24175 = heff_field(v_x2_24173, 1);
    V v_ru_24x2_24173_24MkPair = heff_take_reuse_n(v_x2_24173, 3ULL, 2);
    V v_t_24176 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24177 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24176, v_as_2415));
    V v_x2_24178 = heff_tr(heff_call(v_m_24177, 1, (V[]){v_s_24175}));
    switch (heff_tag_of(v_x2_24178)) {
    case TAG_MkPair: {
      V v_x_24179 = heff_field(v_x2_24178, 0);
      V v_s_24180 = heff_field(v_x2_24178, 1);
      heff_take_n(v_x2_24178, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24174, v_x_24179}), v_s_24180});
    }
    default: return heff_nomatch(v_x2_24178);
    }
  }
  default: return heff_nomatch(v_x2_24173);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam17(V self, V *args) {
  V v_s_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_s_24183}));
  switch (heff_tag_of(v_x2_24184)) {
  case TAG_MkPair: {
    V v_x_24185 = heff_field(v_x2_24184, 0);
    V v_s_24186 = heff_field(v_x2_24184, 1);
    V v_ru_24x2_24184_24MkPair = heff_take_reuse_n(v_x2_24184, 3ULL, 2);
    V v_t_24187 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24188 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24187, v_as_2415));
    V v_x2_24189 = heff_tr(heff_call(v_m_24188, 1, (V[]){v_s_24186}));
    switch (heff_tag_of(v_x2_24189)) {
    case TAG_MkPair: {
      V v_x_24190 = heff_field(v_x2_24189, 0);
      V v_s_24191 = heff_field(v_x2_24189, 1);
      heff_take_n(v_x2_24189, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24185, v_x_24190}), v_s_24191});
    }
    default: return heff_nomatch(v_x2_24189);
    }
  }
  default: return heff_nomatch(v_x2_24184);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam18(V self, V *args) {
  V v_s_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_s_24194}));
  switch (heff_tag_of(v_x2_24195)) {
  case TAG_MkPair: {
    V v_x_24196 = heff_field(v_x2_24195, 0);
    V v_s_24197 = heff_field(v_x2_24195, 1);
    V v_ru_24x2_24195_24MkPair = heff_take_reuse_n(v_x2_24195, 3ULL, 2);
    V v_t_24198 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24199 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24198, v_as_2415));
    V v_x2_24200 = heff_tr(heff_call(v_m_24199, 1, (V[]){v_s_24197}));
    switch (heff_tag_of(v_x2_24200)) {
    case TAG_MkPair: {
      V v_x_24201 = heff_field(v_x2_24200, 0);
      V v_s_24202 = heff_field(v_x2_24200, 1);
      heff_take_n(v_x2_24200, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24196, v_x_24201}), v_s_24202});
    }
    default: return heff_nomatch(v_x2_24200);
    }
  }
  default: return heff_nomatch(v_x2_24195);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam19(V self, V *args) {
  V v_s_24206 = args[0];
  V v_m_24205 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24207 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_s_24206}));
  switch (heff_tag_of(v_x2_24207)) {
  case TAG_MkPair: {
    V v_x_24208 = heff_field(v_x2_24207, 0);
    V v_s_24209 = heff_field(v_x2_24207, 1);
    V v_ru_24x2_24207_24MkPair = heff_take_reuse_n(v_x2_24207, 3ULL, 2);
    V v_t_24210 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24211 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24210, v_as_2415));
    V v_x2_24212 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_s_24209}));
    switch (heff_tag_of(v_x2_24212)) {
    case TAG_MkPair: {
      V v_x_24213 = heff_field(v_x2_24212, 0);
      V v_s_24214 = heff_field(v_x2_24212, 1);
      heff_take_n(v_x2_24212, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24208, v_x_24213}), v_s_24214});
    }
    default: return heff_nomatch(v_x2_24212);
    }
  }
  default: return heff_nomatch(v_x2_24207);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam20(V self, V *args) {
  V v_s_24217 = args[0];
  V v_m_24216 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24218 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_s_24217}));
  switch (heff_tag_of(v_x2_24218)) {
  case TAG_MkPair: {
    V v_x_24219 = heff_field(v_x2_24218, 0);
    V v_s_24220 = heff_field(v_x2_24218, 1);
    V v_ru_24x2_24218_24MkPair = heff_take_reuse_n(v_x2_24218, 3ULL, 2);
    V v_t_24221 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24222 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24221, v_as_2415));
    V v_x2_24223 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_s_24220}));
    switch (heff_tag_of(v_x2_24223)) {
    case TAG_MkPair: {
      V v_x_24224 = heff_field(v_x2_24223, 0);
      V v_s_24225 = heff_field(v_x2_24223, 1);
      heff_take_n(v_x2_24223, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24219, v_x_24224}), v_s_24225});
    }
    default: return heff_nomatch(v_x2_24223);
    }
  }
  default: return heff_nomatch(v_x2_24218);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam21(V self, V *args) {
  V v_s_24227 = args[0];
  V v_m_24226 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24228 = heff_tr(heff_call(v_m_24226, 1, (V[]){v_s_24227}));
  switch (heff_tag_of(v_x2_24228)) {
  case TAG_MkPair: {
    V v_x_24229 = heff_field(v_x2_24228, 0);
    V v_s_24230 = heff_field(v_x2_24228, 1);
    V v_ru_24x2_24228_24MkPair = heff_take_reuse_n(v_x2_24228, 3ULL, 2);
    V v_t_24231 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24232 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24231, v_as_2415));
    V v_x2_24233 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_s_24230}));
    switch (heff_tag_of(v_x2_24233)) {
    case TAG_MkPair: {
      V v_x_24234 = heff_field(v_x2_24233, 0);
      V v_s_24235 = heff_field(v_x2_24233, 1);
      heff_take_n(v_x2_24233, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24229, v_x_24234}), v_s_24235});
    }
    default: return heff_nomatch(v_x2_24233);
    }
  }
  default: return heff_nomatch(v_x2_24228);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam22(V self, V *args) {
  V v_s_24239 = args[0];
  V v_m_24238 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_as_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24240 = heff_tr(heff_call(v_m_24238, 1, (V[]){v_s_24239}));
  switch (heff_tag_of(v_x2_24240)) {
  case TAG_MkPair: {
    V v_x_24241 = heff_field(v_x2_24240, 0);
    V v_s_24242 = heff_field(v_x2_24240, 1);
    V v_ru_24x2_24240_24MkPair = heff_take_reuse_n(v_x2_24240, 3ULL, 2);
    V v_t_24243 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24244 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_24243, v_as_2415));
    V v_x2_24245 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_s_24242}));
    switch (heff_tag_of(v_x2_24245)) {
    case TAG_MkPair: {
      V v_x_24246 = heff_field(v_x2_24245, 0);
      V v_s_24247 = heff_field(v_x2_24245, 1);
      heff_take_n(v_x2_24245, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_24241, v_x_24246}), v_s_24247});
    }
    default: return heff_nomatch(v_x2_24245);
    }
  }
  default: return heff_nomatch(v_x2_24240);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam23(V self, V *args) {
  V v_s_24252 = args[0];
  V v_m_24251 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_b_24250 = heff_env(self)[3];
  V v_x_24248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24253 = heff_tr(heff_call(v_m_24251, 1, (V[]){v_s_24252}));
  switch (heff_tag_of(v_x2_24253)) {
  case TAG_MkPair: {
    V v_x_24254 = heff_field(v_x2_24253, 0);
    V v_s_24255 = heff_field(v_x2_24253, 1);
    V v_ru_24x2_24253_24MkPair = heff_take_reuse_n(v_x2_24253, 3ULL, 2);
    V v_m_24256 = (g_heff_2ecompile_2esimplify_2etieGo(v_h_240, v_lam1_241, v_b_24250));
    V v_x2_24257 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_s_24255}));
    switch (heff_tag_of(v_x2_24257)) {
    case TAG_MkPair: {
      V v_x_24258 = heff_field(v_x2_24257, 0);
      V v_s_24259 = heff_field(v_x2_24257, 1);
      heff_take_n(v_x2_24257, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24253_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_24248, v_x_24254, v_x_24258}), v_s_24259});
    }
    default: return heff_nomatch(v_x2_24257);
    }
  }
  default: return heff_nomatch(v_x2_24253);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam25(V self, V *args) {
  V v_s_24267 = args[0];
  V v_m_24266 = heff_env(self)[0];
  V v_l_24264 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24268 = heff_tr(heff_call(v_m_24266, 1, (V[]){v_s_24267}));
  switch (heff_tag_of(v_x2_24268)) {
  case TAG_MkPair: {
    V v_x_24269 = heff_field(v_x2_24268, 0);
    V v_s_24270 = heff_field(v_x2_24268, 1);
    V v_ru_24x2_24268_24MkPair = heff_take_reuse_n(v_x2_24268, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24264, v_x_24269}), v_s_24270});
  }
  default: return heff_nomatch(v_x2_24268);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam24(V self, V *args) {
  V v_p_24263 = args[0];
  V v_f_24262 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24263)) {
  case TAG_MkPair: {
    V v_l_24264 = heff_field(v_p_24263, 0);
    V v_e_24265 = heff_field(v_p_24263, 1);
    heff_take_n(v_p_24263, 3ULL, 2);
    V v_m_24266 = heff_tr(heff_call(v_f_24262, 1, (V[]){v_e_24265}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam25, 1, 2, (V[]){v_m_24266, v_l_24264});
  }
  default: return heff_nomatch(v_p_24263);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam26(V self, V *args) {
  V v_s_24272 = args[0];
  V v_m_24271 = heff_env(self)[0];
  V v_ts_24261 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24273 = heff_tr(heff_call(v_m_24271, 1, (V[]){v_s_24272}));
  switch (heff_tag_of(v_x2_24273)) {
  case TAG_MkPair: {
    V v_x_24274 = heff_field(v_x2_24273, 0);
    V v_s_24275 = heff_field(v_x2_24273, 1);
    V v_ru_24x2_24273_24MkPair = heff_take_reuse_n(v_x2_24273, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24273_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_24274, v_ts_24261}), v_s_24275});
  }
  default: return heff_nomatch(v_x2_24273);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam27(V self, V *args) {
  V v_s_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  V v_l_24277 = heff_env(self)[1];
  V v_sh_24278 = heff_env(self)[2];
  V v_t_24279 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24282 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_s_24281}));
  switch (heff_tag_of(v_x2_24282)) {
  case TAG_MkPair: {
    V v_x_24283 = heff_field(v_x2_24282, 0);
    V v_s_24284 = heff_field(v_x2_24282, 1);
    V v_ru_24x2_24282_24MkPair = heff_take_reuse_n(v_x2_24282, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_24283, v_l_24277, v_sh_24278, v_t_24279}), v_s_24284});
  }
  default: return heff_nomatch(v_x2_24282);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam28(V self, V *args) {
  V v_s_24290 = args[0];
  V v_m_24289 = heff_env(self)[0];
  V v_t_24285 = heff_env(self)[1];
  V v_ts_24287 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24291 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_s_24290}));
  switch (heff_tag_of(v_x2_24291)) {
  case TAG_MkPair: {
    V v_x_24292 = heff_field(v_x2_24291, 0);
    V v_s_24293 = heff_field(v_x2_24291, 1);
    V v_ru_24x2_24291_24MkPair = heff_take_reuse_n(v_x2_24291, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_24285, v_x_24292, v_ts_24287}), v_s_24293});
  }
  default: return heff_nomatch(v_x2_24291);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam31(V self, V *args) {
  V v_s_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  V v_t_24303 = heff_env(self)[1];
  V v_vs_24304 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24308 = heff_tr(heff_call(v_m_24306, 1, (V[]){v_s_24307}));
  switch (heff_tag_of(v_x2_24308)) {
  case TAG_MkPair: {
    V v_x_24309 = heff_field(v_x2_24308, 0);
    V v_s_24310 = heff_field(v_x2_24308, 1);
    V v_ru_24x2_24308_24MkPair = heff_take_reuse_n(v_x2_24308, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24303, v_vs_24304, v_x_24309}), v_s_24310});
  }
  default: return heff_nomatch(v_x2_24308);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam30(V self, V *args) {
  V v_a_24302 = args[0];
  V v_f_24301 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24302)) {
  case TAG_MkArm: {
    V v_t_24303 = heff_field(v_a_24302, 0);
    V v_vs_24304 = heff_field(v_a_24302, 1);
    V v_b_24305 = heff_field(v_a_24302, 2);
    heff_take_n(v_a_24302, 7ULL, 3);
    V v_m_24306 = heff_tr(heff_call(v_f_24301, 1, (V[]){v_b_24305}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam31, 1, 3, (V[]){v_m_24306, v_t_24303, v_vs_24304});
  }
  default: return heff_nomatch(v_a_24302);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam29(V self, V *args) {
  V v_s_24297 = args[0];
  V v_m_24296 = heff_env(self)[0];
  V v_h_240 = heff_env(self)[1];
  V v_lam1_241 = heff_env(self)[2];
  V v_arms_24295 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24298 = heff_tr(heff_call(v_m_24296, 1, (V[]){v_s_24297}));
  switch (heff_tag_of(v_x2_24298)) {
  case TAG_MkPair: {
    V v_x_24299 = heff_field(v_x2_24298, 0);
    V v_s_24300 = heff_field(v_x2_24298, 1);
    V v_ru_24x2_24298_24MkPair = heff_take_reuse_n(v_x2_24298, 3ULL, 2);
    V v_f_24301 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2etieGo_clo), 2, (V[]){v_h_240, v_lam1_241}));
    V v_m_24311 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2etieGo_lam30, 1, 1, (V[]){v_f_24301}), v_arms_24295));
    V v_x2_24312 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_s_24300}));
    switch (heff_tag_of(v_x2_24312)) {
    case TAG_MkPair: {
      V v_x_24313 = heff_field(v_x2_24312, 0);
      V v_s_24314 = heff_field(v_x2_24312, 1);
      heff_take_n(v_x2_24312, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24298_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24299, v_x_24313}), v_s_24314});
    }
    default: return heff_nomatch(v_x2_24312);
    }
  }
  default: return heff_nomatch(v_x2_24298);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam32(V self, V *args) {
  V v_s_24316 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24316});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam33(V self, V *args) {
  V v_s_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  V v_p_24317 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_s_24321}));
  switch (heff_tag_of(v_x2_24322)) {
  case TAG_MkPair: {
    V v_x_24323 = heff_field(v_x2_24322, 0);
    V v_s_24324 = heff_field(v_x2_24322, 1);
    V v_ru_24x2_24322_24MkPair = heff_take_reuse_n(v_x2_24322, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_24317, v_x_24323}), v_s_24324});
  }
  default: return heff_nomatch(v_x2_24322);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam34(V self, V *args) {
  V v_s_24329 = args[0];
  V v_m_24328 = heff_env(self)[0];
  V v_g_24325 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24330 = heff_tr(heff_call(v_m_24328, 1, (V[]){v_s_24329}));
  switch (heff_tag_of(v_x2_24330)) {
  case TAG_MkPair: {
    V v_x_24331 = heff_field(v_x2_24330, 0);
    V v_s_24332 = heff_field(v_x2_24330, 1);
    V v_ru_24x2_24330_24MkPair = heff_take_reuse_n(v_x2_24330, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24325, v_x_24331}), v_s_24332});
  }
  default: return heff_nomatch(v_x2_24330);
  }
}
V g_heff_2ecompile_2esimplify_2etieGo_lam35(V self, V *args) {
  V v_s_24334 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24334});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam36(V self, V *args) {
  V v_s_24336 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24336});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam37(V self, V *args) {
  V v_s_24338 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24338});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam38(V self, V *args) {
  V v_s_24340 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24340});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam39(V self, V *args) {
  V v_s_24343 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24343});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam40(V self, V *args) {
  V v_s_24345 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24345});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam41(V self, V *args) {
  V v_s_24346 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24346});
}
V g_heff_2ecompile_2esimplify_2etieGo_lam42(V self, V *args) {
  V v_s_24349 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24349});
}
Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayBody_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayBody(V v_k_240, V v_b0_241, V v_s_242) {
top: ;
  V v_x2_243 = (g_heff_2ecompile_2esimplify_2ecopy(v_b0_241, v_s_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(heff_rfield(v_k_240, 0)), heff_dup(v_x_244), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
      V v_x2_249 = (g_heff_2ecompile_2esimplify_2esafeAs(heff_rfield(v_k_240, 3), heff_dup(heff_rfield(v_k_240, 0)), v_s_248));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 2ULL, 2);
        V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_244)));
        V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
        V v_x2_2414 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2413, v_s_2411));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_m_2417 = (g_heff_2ecompile_2esimplify_2einOrder(heff_dup(v_x_244), v_x_2415));
          V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            V v_s_2420 = heff_field(v_x2_2418, 1);
            heff_take_n(v_x2_2418, 3ULL, 2);
            V v_t_2421 = heff_rec_n(3, shape_key__name__body, (V[]){heff_take_field(v_k_240, 0), heff_get_n(v_k_240, 1, 7), v_x_244});
            V v_t_2422 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
            V v_x_2423 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2419, v_t_2422));
            return heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2423, v_s_2420});
          }
          default: return heff_nomatch(v_x2_2418);
          }
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayBody(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str0, 0, "");
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopiesDone_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopiesDone(V v_st_240, V v_defs_241) {
top: ;
  V v_bodies_242 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 3, 5);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_249));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam0, 1, 2, (V[]){v_st_240, v_bodies_242}), v_t_2410));
  return (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2419));
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopiesDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bodies_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 2, 7);
  V v_t_2413 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2412; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_h_2411);
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_bodies_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_r_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 0, 5);
    V v_x2_2416 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return ({ V a_0 = v_st_240; V a_1 = v_bodies_242; V a_2 = v_h_2411; V a_3 = v_t_2418; V a_4 = v_r_2414; V r_ = (g_heff_2ecompile_2esimplify_2ecopyWith(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bodies_242); r_; });
  }
  default: return heff_nomatch(v_t_2413);
  }
}