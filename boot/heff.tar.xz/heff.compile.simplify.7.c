// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_base 9511832
#define LBL_caps 9541544
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_e 319
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_madeFresh 950075604
#define LBL_n 328
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipes 1314274025
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_vers 10111479
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
V g_heff_2ecompile_2eir_2econdIf(V, V, V);
V g_heff_2ecompile_2eir_2econdIf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdIf_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eallJust_24cpr(V);
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eappendL_24tok2(V, V, V);
V g_heff_2ecompile_2esimplify_2eappendL_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_24tok2_clo;
V g_heff_2ecompile_2esimplify_2eattemptBy(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eattemptBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattemptBy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebinOp_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind(V, V, V);
V g_heff_2ecompile_2esimplify_2ebind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebind_clo;
V g_heff_2ecompile_2esimplify_2ebindPushable(V);
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo;
V g_heff_2ecompile_2esimplify_2ebuiltBy(V, V);
V g_heff_2ecompile_2esimplify_2ebuiltBy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebuiltBy_clo;
HeffT2 g_heff_2ecompile_2esimplify_2ebuiltField_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efindArm_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efindField_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2efoldCond(V);
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efoldCond_clo;
HeffT2 g_heff_2ecompile_2esimplify_2efreshName_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2efueled_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2egivenSet_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn(V, V, V);
V g_heff_2ecompile_2esimplify_2egrewIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2egrewIn_clo;
V g_heff_2ecompile_2esimplify_2ehandedPast(V, V, V);
V g_heff_2ecompile_2esimplify_2ehandedPast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ehandedPast_clo;
V g_heff_2ecompile_2esimplify_2einitL(V);
V g_heff_2ecompile_2esimplify_2einitL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_clo;
V g_heff_2ecompile_2esimplify_2einitL_24dps(V, V);
V g_heff_2ecompile_2esimplify_2einitL_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einitL_24dps_clo;
V g_heff_2ecompile_2esimplify_2eknownCopy(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eletsOut_24cpr(V);
HeffT2 g_heff_2ecompile_2esimplify_2emakeEach_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2emarkSafe_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eownSt_24cpr(V);
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
V g_heff_2ecompile_2esimplify_2eprunedAbove(V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedAbove_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedAbove_clo;
V g_heff_2ecompile_2esimplify_2eprunedCopy(V, V);
V g_heff_2ecompile_2esimplify_2eprunedCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedCopy_clo;
V g_heff_2ecompile_2esimplify_2eprunedMax(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprunedMax_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprunedMax_clo;
V g_heff_2ecompile_2esimplify_2epureOrPartial(V, V);
V g_heff_2ecompile_2esimplify_2epureOrPartial_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureOrPartial_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
HeffT2 g_heff_2ecompile_2esimplify_2eraise_24cpr(V, V);
HeffT2 g_heff_2ecompile_2esimplify_2erecordDef_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2erecordSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordSplit_clo;
V g_heff_2ecompile_2esimplify_2erecordTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordTakenApart_clo;
V g_heff_2ecompile_2esimplify_2esetGiven(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esetGiven_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetGiven_clo;
V g_heff_2ecompile_2esimplify_2esettleDef(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esettleDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esettleDef_clo;
HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V, V, V, V);
HeffT2 g_heff_2ecompile_2esimplify_2eshapeOne_24cpr(V, V, V);
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esumPushed(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etagApart(V, V, V);
V g_heff_2ecompile_2esimplify_2etagApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagApart_clo;
V g_heff_2ecompile_2esimplify_2etagBound(V);
V g_heff_2ecompile_2esimplify_2etagBound_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etagBound_clo;
V g_heff_2ecompile_2esimplify_2etoValues(V, V);
V g_heff_2ecompile_2esimplify_2etoValues_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etoValues_clo;
HeffT2 g_heff_2ecompile_2esimplify_2etoValues_24cpr(V, V);
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
HeffT2 g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(V, V);
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1433066060x138395605(V, V);
V g_list_2efoldl_24s1433066060x138395605_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1433066060x138395605_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1(V, V, V);
V g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_entry(V self, V *a);
extern Clo g_std_2emap_2elookup_24s1930949324x2078207031_24tok1_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str1, 9, "strLength");
Clo g_heff_2ecompile_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str0), 2)) {
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2427)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
    } else {
      heff_drop(v_a_2427);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2430 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str1), 2)) {
      V v_t_2431 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2430)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2431});
    } else {
      heff_drop(v_a_2430);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eunOp(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2efoldCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efoldCond_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2efoldCond(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return v_x1_240;
  }
  case TAG_CFalse: {
    return v_x1_240;
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_b_243 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CRel = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2ebinOp_24cpr(v_p_241, heff_dup(v_a_242), heff_dup(v_b_243)));
    V v_t_2410;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_p_241);
        heff_drop(v_a_242);
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x1_240_24CRel, 3);
        V v_v_247 = v_field_246;
        v_t_2410 = v_v_247;
      } else {
        heff_drop(v_field_246);
        V v_t_248 = (g_heff_2ecompile_2eir_2eisRel(v_p_241));
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_t_248);
          v_t_2410 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24CRel, TAG_CRel, 3, (V[]){v_p_241, v_a_242, v_b_243})});
        } else {
          heff_drop_cell(v_ru_24x1_240_24CRel, 3);
          heff_drop(v_t_248);
          V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
          v_t_2410 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_t_249})});
        }
      }
    }
    HEFF_LAST return g_heff_2ecompile_2eir_2econdOf(v_t_2410);
  }
  case TAG_CTest: {
    V v_e_2411 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2econdOf(v_e_2411);
  }
  case TAG_CNot: {
    V v_c_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CNot = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_x1_2413 = (g_heff_2ecompile_2esimplify_2efoldCond(v_c_2412));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_CTrue: {
      heff_drop_cell(v_ru_24x1_240_24CNot, 1);
      return NTAG(TAG_CFalse);
    }
    case TAG_CFalse: {
      heff_drop_cell(v_ru_24x1_240_24CNot, 1);
      return NTAG(TAG_CTrue);
    }
    case TAG_CRel: {
      return heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_x1_2413});
    }
    case TAG_CTest: {
      return heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_x1_2413});
    }
    case TAG_CNot: {
      V v_c_2418 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24CNot, 1);
      return v_c_2418;
    }
    case TAG_CIf: {
      return heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_x1_2413});
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
  case TAG_CIf: {
    V v_a_2422 = heff_field(v_x1_240, 0);
    V v_b_2423 = heff_field(v_x1_240, 1);
    V v_c_2424 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2efoldCond(v_a_2422));
    V v_t_2426 = (g_heff_2ecompile_2esimplify_2efoldCond(v_b_2423));
    V v_t_2427 = (g_heff_2ecompile_2esimplify_2efoldCond(v_c_2424));
    return (g_heff_2ecompile_2eir_2econdIf(v_t_2425, v_t_2426, v_t_2427));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2efoldCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efoldCond(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2einitL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einitL_24dps_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2einitL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_x12_243;
      V t_1 = v_cell_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2einitL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einitL_24dps(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(V v_tags_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_tags_240)) {
  case TAG_Nil: {
    heff_drop(v_e_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_tags1_242 = heff_field(v_tags_240, 0);
    V v_tags2_243 = heff_field(v_tags_240, 1);
    V v_ru_24tags_240_24Cons = heff_take_reuse_n(v_tags_240, 3ULL, 2);
    switch (heff_tag_of(v_tags1_242)) {
    case TAG_MkPair: {
      V v_t_244 = heff_field(v_tags1_242, 0);
      V v_n_245 = heff_field(v_tags1_242, 1);
      heff_take_n(v_tags1_242, 3ULL, 2);
      switch (heff_tag_of(v_tags2_243)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24tags_240_24Cons, 2);
        switch (heff_tag_of(v_e_241)) {
        case TAG_EVar: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EGlobal: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELet: {
          heff_take_n(v_e_241, 0ULL, 3);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERecord: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProj: {
          heff_take_n(v_e_241, 0ULL, 4);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          V v_u_2421 = heff_field(v_e_241, 0);
          V v_args_2422 = heff_field(v_e_241, 1);
          heff_take_n(v_e_241, 3ULL, 3);
          if ((heff_strEq_c_lent(v_t_244, v_u_2421, 0) && ({ V v_t_2496 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422)); int c_ = heff_intEq_c_lent(v_t_2496, v_n_245, 0); heff_drop(v_t_2496); c_; }))) {
            heff_drop(v_t_244);
            heff_drop(v_n_245);
            heff_drop(v_u_2421);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_args_2422}});
          } else {
            heff_drop(v_t_244);
            heff_drop(v_n_245);
            heff_drop(v_u_2421);
            heff_drop(v_args_2422);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_EMatch: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrim: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrimCall: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ECall: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          heff_take_na(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStr: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBytes: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFixed: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat32: {
          heff_take_na(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAbandon: {
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBool: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESet: {
          heff_take_n(v_e_241, 0ULL, 3);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EValues: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFix: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_e_241)}});
        }
      }
      case TAG_Cons: {
        switch (heff_tag_of(v_e_241)) {
        case TAG_EVar: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EGlobal: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELam: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EApp: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ELet: {
          heff_take_n(v_e_241, 0ULL, 3);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ERecord: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EProj: {
          heff_take_n(v_e_241, 0ULL, 4);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ETag: {
          V v_u_2462 = heff_field(v_e_241, 0);
          V v_args_2463 = heff_field(v_e_241, 1);
          heff_take_n(v_e_241, 3ULL, 3);
          if ((heff_strEq_c_lent(v_t_244, v_u_2462, 0) && ({ V v_t_2497 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2463)); int c_ = heff_intEq_c_lent(v_t_2497, v_n_245, 0); heff_drop(v_t_2497); c_; }))) {
            heff_drop(v_t_244);
            heff_drop(v_n_245);
            heff_drop(v_u_2462);
            V v_vs_2465 = (g_heff_2ecompile_2esimplify_2einitL(heff_dup(v_args_2463)));
            V v_x1_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2463));
            V v_t_2469;
            switch (heff_tag_of(v_x1_2466)) {
            case TAG_Nil: {
              v_t_2469 = NTAG(TAG_EAbandon);
              break;
            }
            case TAG_Cons: {
              V v_x_2467 = heff_field(v_x1_2466, 0);
              heff_take_n(v_x1_2466, 1ULL, 2);
              v_t_2469 = v_x_2467;
              break;
            }
            default: heff_nomatch(v_x1_2466);
            }
            HeffT2 v_t_2470 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_tags2_243, v_t_2469));
            {
              V v_field_2472 = v_t_2470.f[1];
              int64_t v_tag_2471 = ((int64_t)v_t_2470.f[0]);
              if ((v_tag_2471 == ((int64_t)0ULL))) {
                V v_ws_2473 = v_field_2472;
                V v_f_2474 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24tags_240_24Cons, v_vs_2465, v_ws_2473));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2474}});
              } else {
                heff_drop_cell(v_ru_24tags_240_24Cons, 2);
                heff_drop(v_vs_2465);
                heff_drop(v_field_2472);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop_tag(v_tags2_243, 2);
            heff_drop_cell(v_ru_24tags_240_24Cons, 2);
            heff_drop(v_t_244);
            heff_drop(v_n_245);
            heff_drop(v_u_2462);
            heff_drop(v_args_2463);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
        case TAG_EMatch: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrim: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EPrimCall: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ECall: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EInt: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat: {
          heff_take_na(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EStr: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBytes: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFixed: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFloat32: {
          heff_take_na(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EAbandon: {
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EBool: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_ESet: {
          heff_take_n(v_e_241, 0ULL, 3);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EValues: {
          heff_take_n(v_e_241, 0ULL, 1);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_EFix: {
          heff_take_n(v_e_241, 0ULL, 2);
          heff_drop_tag(v_tags2_243, 2);
          heff_drop_cell(v_ru_24tags_240_24Cons, 2);
          heff_drop(v_t_244);
          heff_drop(v_n_245);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        default: return ((HeffT2){{heff_nomatch(v_e_241)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_tags2_243)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_tags1_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_tags_240)}});
  }
}
V g_heff_2ecompile_2esimplify_2etoValues_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2esimplify_2etoValues_24cpr(V v_ts_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    HeffT2 v_t_243 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_246 = v_field_245;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_246})}});
      } else {
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EGlobal: {
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x_2411 = v_field_2410;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2411})}});
      } else {
        heff_drop(v_field_2410);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ELam: {
    HeffT2 v_t_2414 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        V v_x_2417 = v_field_2416;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2417})}});
      } else {
        heff_drop(v_field_2416);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EApp: {
    HeffT2 v_t_2420 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2422;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2423})}});
      } else {
        heff_drop(v_field_2422);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ELet: {
    V v_y_2424 = heff_field(v_e_241, 0);
    V v_v_2425 = heff_field(v_e_241, 1);
    V v_b_2426 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_2427 = (g_heff_2ecompile_2esimplify_2etoValues_24cpr(v_ts_240, v_b_2426));
    {
      V v_field_2429 = v_t_2427.f[1];
      int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
      if ((v_tag_2428 == ((int64_t)0ULL))) {
        V v_x_2430 = v_field_2429;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_y_2424, v_v_2425, v_x_2430})}});
      } else {
        heff_drop(v_y_2424);
        heff_drop(v_v_2425);
        heff_drop_cell(v_ru_24e_241_24ELet, 3);
        heff_drop(v_field_2429);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ERecord: {
    HeffT2 v_t_2433 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2435 = v_t_2433.f[1];
      int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
      if ((v_tag_2434 == ((int64_t)0ULL))) {
        V v_x_2436 = v_field_2435;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2436})}});
      } else {
        heff_drop(v_field_2435);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EProj: {
    HeffT2 v_t_2441 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2443 = v_t_2441.f[1];
      int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
      if ((v_tag_2442 == ((int64_t)0ULL))) {
        V v_x_2444 = v_field_2443;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2444})}});
      } else {
        heff_drop(v_field_2443);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ETag: {
    HeffT2 v_t_2448 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2450 = v_t_2448.f[1];
      int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
      if ((v_tag_2449 == ((int64_t)0ULL))) {
        V v_x_2451 = v_field_2450;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2451})}});
      } else {
        heff_drop(v_field_2450);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EMatch: {
    V v_s_2452 = heff_field(v_e_241, 0);
    V v_arms_2453 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2459 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2etoValues_24cpr_lam0, 1, 1, (V[]){v_ts_240}), heff_dup(v_arms_2453)));
    HeffT2 v_t_2460 = (g_heff_2ecompile_2esimplify_2eallJust_24cpr(v_t_2459));
    {
      V v_field_2462 = v_t_2460.f[1];
      int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
      if ((v_tag_2461 == ((int64_t)0ULL))) {
        V v_x_2463 = v_field_2462;
        V v_t_2464 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2453, v_x_2463));
        V v_f_2465 = heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2452, v_t_2464});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2465}});
      } else {
        heff_drop(v_s_2452);
        heff_drop(v_arms_2453);
        heff_drop_cell(v_ru_24e_241_24EMatch, 2);
        heff_drop(v_field_2462);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EPrim: {
    HeffT2 v_t_2467 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2469 = v_t_2467.f[1];
      int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
      if ((v_tag_2468 == ((int64_t)0ULL))) {
        V v_x_2470 = v_field_2469;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2470})}});
      } else {
        heff_drop(v_field_2469);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EPrimCall: {
    HeffT2 v_t_2473 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2475 = v_t_2473.f[1];
      int64_t v_tag_2474 = ((int64_t)v_t_2473.f[0]);
      if ((v_tag_2474 == ((int64_t)0ULL))) {
        V v_x_2476 = v_field_2475;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2476})}});
      } else {
        heff_drop(v_field_2475);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ECall: {
    HeffT2 v_t_2479 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2481 = v_t_2479.f[1];
      int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
      if ((v_tag_2480 == ((int64_t)0ULL))) {
        V v_x_2482 = v_field_2481;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2482})}});
      } else {
        heff_drop(v_field_2481);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EInt: {
    HeffT2 v_t_2484 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2486 = v_t_2484.f[1];
      int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
      if ((v_tag_2485 == ((int64_t)0ULL))) {
        V v_x_2487 = v_field_2486;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2487})}});
      } else {
        heff_drop(v_field_2486);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EFloat: {
    HeffT2 v_t_2489 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2491 = v_t_2489.f[1];
      int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
      if ((v_tag_2490 == ((int64_t)0ULL))) {
        V v_x_2492 = v_field_2491;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2492})}});
      } else {
        heff_drop(v_field_2491);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EStr: {
    HeffT2 v_t_2494 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_2496 = v_t_2494.f[1];
      int64_t v_tag_2495 = ((int64_t)v_t_2494.f[0]);
      if ((v_tag_2495 == ((int64_t)0ULL))) {
        V v_x_2497 = v_field_2496;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_2497})}});
      } else {
        heff_drop(v_field_2496);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EBytes: {
    HeffT2 v_t_2499 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_24101 = v_t_2499.f[1];
      int64_t v_tag_24100 = ((int64_t)v_t_2499.f[0]);
      if ((v_tag_24100 == ((int64_t)0ULL))) {
        V v_x_24102 = v_field_24101;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_24102})}});
      } else {
        heff_drop(v_field_24101);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EFixed: {
    HeffT2 v_t_24105 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_24107 = v_t_24105.f[1];
      int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
      if ((v_tag_24106 == ((int64_t)0ULL))) {
        V v_x_24108 = v_field_24107;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_24108})}});
      } else {
        heff_drop(v_field_24107);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EFloat32: {
    HeffT2 v_t_24110 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_24112 = v_t_24110.f[1];
      int64_t v_tag_24111 = ((int64_t)v_t_24110.f[0]);
      if ((v_tag_24111 == ((int64_t)0ULL))) {
        V v_x_24113 = v_field_24112;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_24113})}});
      } else {
        heff_drop(v_field_24112);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EAbandon: {
    heff_drop(v_ts_240);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_EAbandon)}});
  }
  case TAG_EBool: {
    HeffT2 v_t_24115 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_24117 = v_t_24115.f[1];
      int64_t v_tag_24116 = ((int64_t)v_t_24115.f[0]);
      if ((v_tag_24116 == ((int64_t)0ULL))) {
        V v_x_24118 = v_field_24117;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_24118})}});
      } else {
        heff_drop(v_field_24117);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_ESet: {
    V v_ys_24119 = heff_field(v_e_241, 0);
    V v_v_24120 = heff_field(v_e_241, 1);
    V v_b_24121 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    HeffT2 v_t_24122 = (g_heff_2ecompile_2esimplify_2etoValues_24cpr(v_ts_240, v_b_24121));
    {
      V v_field_24124 = v_t_24122.f[1];
      int64_t v_tag_24123 = ((int64_t)v_t_24122.f[0]);
      if ((v_tag_24123 == ((int64_t)0ULL))) {
        V v_x_24125 = v_field_24124;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24e_241_24ESet, TAG_ESet, 3, (V[]){v_ys_24119, v_v_24120, v_x_24125})}});
      } else {
        heff_drop(v_ys_24119);
        heff_drop(v_v_24120);
        heff_drop_cell(v_ru_24e_241_24ESet, 3);
        heff_drop(v_field_24124);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EValues: {
    HeffT2 v_t_24127 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_24129 = v_t_24127.f[1];
      int64_t v_tag_24128 = ((int64_t)v_t_24127.f[0]);
      if ((v_tag_24128 == ((int64_t)0ULL))) {
        V v_x_24130 = v_field_24129;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_24130})}});
      } else {
        heff_drop(v_field_24129);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EFix: {
    HeffT2 v_t_24133 = (g_heff_2ecompile_2esimplify_2evaluesOf_24cpr(v_ts_240, v_e_241));
    {
      V v_field_24135 = v_t_24133.f[1];
      int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
      if ((v_tag_24134 == ((int64_t)0ULL))) {
        V v_x_24136 = v_field_24135;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_EValues, 1, (V[]){v_x_24136})}});
      } else {
        heff_drop(v_field_24135);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
V g_heff_2ecompile_2esimplify_2etoValues_24cpr_lam0(V self, V *args) {
  V v_a_2454 = args[0];
  V v_ts_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_a_2454)) {
  case TAG_MkArm: {
    V v_b_2457 = heff_field(v_a_2454, 2);
    heff_take_n(v_a_2454, 4ULL, 3);
    v_t_2458 = v_b_2457;
    break;
  }
  default: heff_nomatch(v_a_2454);
  }
  return (g_heff_2ecompile_2esimplify_2etoValues(v_ts_240, v_t_2458));
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eletIn_str0, 6, "MkLazy");
Clo g_heff_2ecompile_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_x_245 = (g_heff_2ecompile_2esimplify_2epureOrPartial(heff_dup(v_s_244), v_a_242));
  V v_t_2450;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    V v_t_2421 = heff_dup(heff_field(v_a_242, 0));
    if (heff_strEq_c(v_t_2421, ((V)&g_heff_2ecompile_2esimplify_2eletIn_str0))) {
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2425 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), v_t_2424));
      V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2427 = (g_heff_2ecompile_2eir_2elamW(v_x_241, v_t_2426));
      V v_x_2428 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2425, v_t_2427}), 0, 2);
      v_t_2450 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2428, 1));
      heff_drop(v_x_2428);
    } else {
      v_t_2450 = NTAG(TAG_False);
    }
    break;
  }
  case TAG_EMatch: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_242);
  }
  if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
    heff_drop(v_x_245);
    heff_drop(v_t_2450);
    V v_m_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2452 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_s_244}));
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_MkPair: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_s_2454 = heff_field(v_x2_2452, 1);
      V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2453}), v_s_2454});
    }
    default: return heff_nomatch(v_x2_2452);
    }
  } else {
    heff_drop(v_t_2450);
    V v_t_2455 = (g_heff_2ecompile_2esimplify_2esumTakenApart(v_x_241, heff_dup(v_a_242), heff_dup(v_b_243)));
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop(v_x_245);
      heff_drop(v_t_2455);
      V v_t_2456 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_243, v_a_242));
      return heff_tail(v_t_2456, 1, (V[]){v_s_244});
    } else {
      heff_drop(v_t_2455);
      HeffT2 v_t_2457 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_b_243)));
      {
        V v_field_2459 = v_t_2457.f[1];
        int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
        if ((v_tag_2458 == ((int64_t)0ULL))) {
          heff_drop(v_x_245);
          V v_x11_2460 = v_field_2459;
          heff_drop(v_x11_2460);
          HEFF_LAST return g_heff_2ecompile_2esimplify_2esetGiven(v_r_240, v_x_241, v_a_242, v_b_243, v_s_244);
        } else {
          heff_drop(v_field_2459);
          V v_t_2461 = (g_heff_2ecompile_2esimplify_2etagApart(v_x_241, v_a_242, heff_dup(v_b_243)));
          if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
            heff_drop(v_x_245);
            heff_drop(v_t_2461);
            V v_m_2462 = (g_heff_2ecompile_2esimplify_2etagBound(v_a_242));
            V v_x2_2463 = heff_tr(heff_call(v_m_2462, 1, (V[]){v_s_244}));
            switch (heff_tag_of(v_x2_2463)) {
            case TAG_MkPair: {
              V v_x_2464 = heff_field(v_x2_2463, 0);
              V v_s_2465 = heff_field(v_x2_2463, 1);
              V v_ru_24x2_2463_24MkPair = heff_take_reuse_n(v_x2_2463, 3ULL, 2);
              V v_t_2468;
              switch (heff_tag_of(v_x_2464)) {
              case TAG_MkPair: {
                V v_y_2467 = heff_dup(heff_field(v_x_2464, 1));
                v_t_2468 = v_y_2467;
                break;
              }
              default: heff_nomatch(v_x_2464);
              }
              V v_m_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_t_2468, v_b_243}));
              V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_s_2465}));
              switch (heff_tag_of(v_x2_2470)) {
              case TAG_MkPair: {
                V v_x_2471 = heff_field(v_x2_2470, 0);
                V v_s_2472 = heff_field(v_x2_2470, 1);
                heff_take_n(v_x2_2470, 3ULL, 2);
                V v_t_2475;
                switch (heff_tag_of(v_x_2464)) {
                case TAG_MkPair: {
                  V v_x_2473 = heff_field(v_x_2464, 0);
                  heff_take_n(v_x_2464, 1ULL, 2);
                  v_t_2475 = v_x_2473;
                  break;
                }
                default: heff_nomatch(v_x_2464);
                }
                V v_x_2476 = ({ V a_0 = v_t_2475; V a_1 = v_x_2471; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2475); r_; });
                return heff_tag_at_n(v_ru_24x2_2463_24MkPair, TAG_MkPair, 2, (V[]){v_x_2476, v_s_2472});
              }
              default: return heff_nomatch(v_x2_2470);
              }
            }
            default: return heff_nomatch(v_x2_2463);
            }
          } else {
            heff_drop(v_t_2461);
            V v_t_2477 = (g_heff_2ecompile_2esimplify_2erecordTakenApart(v_x_241, heff_dup(v_a_242), heff_dup(v_b_243)));
            if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
              heff_drop(v_x_245);
              heff_drop(v_t_2477);
              HEFF_LAST return g_heff_2ecompile_2esimplify_2erecordSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_244);
            } else {
              heff_drop(v_t_2477);
              V v_t_2478 = heff_get_n(heff_dup(heff_rfield(v_s_244, 7)), 0, 7);
              V v_t_2479 = ({ V a_0 = v_t_2478; V a_1 = v_a_242; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2478); r_; });
              if (((heff_dup(v_t_2479) == NTAG(TAG_True)) && ({ V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2481 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), heff_dup(v_t_2480))); int c_ = ({ V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)}); int c_ = ({ V v_t_2483 = (g_heff_2ecompile_2eir_2elamW(v_x_241, heff_dup(v_t_2482))); int c_ = ({ V v_t_24103 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){heff_dup(v_t_2481), heff_dup(v_t_2483)}), 0, 2); int c_ = heff_intLe_c_lent(v_t_24103, MK_INT(8LL), 2); heff_drop(v_t_24103); c_; }); heff_drop(v_t_2483); c_; }); heff_drop(v_t_2482); c_; }); heff_drop(v_t_2481); c_; }); heff_drop(v_t_2480); c_; }))) {
                heff_drop(v_x_245);
                heff_drop(v_t_2479);
                V v_m_2484 = ({ V a_0 = v_x_241; V a_1 = v_a_242; V a_2 = v_b_243; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(a_0, a_1, a_2)); heff_drop(v_x_241); r_; });
                V v_x2_2485 = heff_tr(heff_call(v_m_2484, 1, (V[]){v_s_244}));
                switch (heff_tag_of(v_x2_2485)) {
                case TAG_MkPair: {
                  V v_x_2486 = heff_field(v_x2_2485, 0);
                  V v_s_2487 = heff_field(v_x2_2485, 1);
                  heff_take_n(v_x2_2485, 3ULL, 2);
                  return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_x_2486, v_s_2487});
                }
                default: return heff_nomatch(v_x2_2485);
                }
              } else {
                heff_drop(v_t_2479);
                if ((heff_dup(v_x_245) == NTAG(TAG_True))) {
                  heff_drop(v_x_245);
                  V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
                  V v_t_2489 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), v_t_2488));
                  V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
                  V v_t_2491 = (g_heff_2ecompile_2eir_2elamW(v_x_241, v_t_2490));
                  V v_t_2492 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2489, v_t_2491}), 0, 2);
                  return (g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2492, v_s_244));
                } else {
                  heff_drop(v_x_245);
                  V v_t_2493 = (g_heff_2ecompile_2esimplify_2epartialApp(heff_dup(v_s_244), v_a_242));
                  if ((heff_dup(v_t_2493) == NTAG(TAG_True))) {
                    heff_drop(v_t_2493);
                    HEFF_LAST return g_heff_2ecompile_2esimplify_2eletSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_244);
                  } else {
                    heff_drop(v_t_2493);
                    V v_m_2494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
                    V v_x2_2495 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_s_244}));
                    switch (heff_tag_of(v_x2_2495)) {
                    case TAG_MkPair: {
                      V v_x_2496 = heff_field(v_x2_2495, 0);
                      V v_s_2497 = heff_field(v_x2_2495, 1);
                      V v_ru_24x2_2495_24MkPair = heff_take_reuse_n(v_x2_2495, 3ULL, 2);
                      HeffT2 v_t_2498 = (g_heff_2ecompile_2esimplify_2egivenSet_24cpr(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_x_2496)));
                      {
                        V v_field_24100 = v_t_2498.f[1];
                        int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
                        V v_t_24102;
                        if ((v_tag_2499 == ((int64_t)0ULL))) {
                          heff_drop(v_x_241);
                          heff_drop(v_a_242);
                          heff_drop(v_x_2496);
                          V v_x_24101 = v_field_24100;
                          v_t_24102 = v_x_24101;
                        } else {
                          heff_drop(v_field_24100);
                          v_t_24102 = heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2496});
                        }
                        return heff_tag_at_n(v_ru_24x2_2495_24MkPair, TAG_MkPair, 2, (V[]){v_t_24102, v_s_2497});
                      }
                    }
                    default: return heff_nomatch(v_x2_2495);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_heff_2ecompile_2esimplify_2efindArm_24cpr(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_ru_24x21_242_24MkArm = heff_take_reuse_n(v_x21_242, 7ULL, 3);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 0)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x21_242_24MkArm, TAG_MkArm, 3, (V[]){v_t2_244, v_vs_245, v_b_246})}});
      } else {
        heff_drop(v_t2_244);
        heff_drop(v_vs_245);
        heff_drop(v_b_246);
        heff_drop_cell(v_ru_24x21_242_24MkArm, 3);
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownCopy_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknownCopy(V v_s_240, V v_g_241, V v_argv_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_246;
      heff_drop(v_x_247);
      V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
      HeffT2 v_t_249 = ({ V a_0 = v_t_248; V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
      {
        V v_field_2411 = v_t_249.f[1];
        int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
        if ((v_tag_2410 == ((int64_t)0ULL))) {
          V v_b_2412 = v_field_2411;
          V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 1, 7);
          V v_t_2414 = ({ V a_0 = v_t_2413; V a_1 = v_b_2412; V a_2 = heff_dup(v_argv_242); V r_ = (g_heff_2ecompile_2esimplify_2ehandedPast(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
          V v_lim_2415;
          if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
            heff_drop(v_t_2414);
            v_lim_2415 = MK_INT(160LL);
          } else {
            heff_drop(v_t_2414);
            v_lim_2415 = MK_INT(50LL);
          }
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_2412), NTAG(TAG_Nil)});
          V v_x_2417 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2415), MK_INT(0LL), v_t_2416));
          if (!heff_intLt_c_lent(v_lim_2415, v_x_2417, 0)) {
            heff_drop_rec(v_s_240, 9);
            heff_drop(v_lim_2415);
            heff_drop(v_x_2417);
            V v_t_2418 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2412)));
            V v_t_2419 = (g_heff_2ecompile_2eir_2enubI(v_t_2418));
            V v_x1_2420 = ({ V a_0 = v_g_241; V a_1 = v_t_2419; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_g_241); heff_drop(v_t_2419); r_; });
            if (!(heff_dup(v_x1_2420) == NTAG(TAG_True))) {
              heff_drop(v_x1_2420);
              V v_t_2421 = ({ V a_0 = v_b_2412; V a_1 = v_argv_242; V r_ = (g_heff_2ecompile_2esimplify_2eprunedCopy(a_0, a_1)); heff_drop(v_argv_242); r_; });
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2421});
            } else {
              heff_drop(v_argv_242);
              heff_drop(v_b_2412);
              heff_drop(v_x1_2420);
              return NTAG(TAG_Nothing);
            }
          } else {
            heff_drop(v_lim_2415);
            heff_drop(v_x_2417);
            V v_t_2422 = heff_get_n(heff_get_n(v_s_240, 7, 9), 1, 7);
            V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_g_241); V a_2 = v_b_2412; V a_3 = heff_dup(v_argv_242); V r_ = (g_heff_2ecompile_2esimplify_2eprunedMax(a_0, a_1, a_2, a_3)); heff_drop(v_t_2422); r_; });
            V v_x1_2424 = (g_heff_2ecompile_2esimplify_2eprunedAbove(v_t_2423, heff_dup(v_b_2412), v_argv_242));
            if (!(heff_dup(v_x1_2424) == NTAG(TAG_True))) {
              heff_drop(v_x1_2424);
              V v_t_2425 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_2412)));
              V v_t_2426 = (g_heff_2ecompile_2eir_2enubI(v_t_2425));
              V v_x1_2427 = ({ V a_0 = v_g_241; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_g_241); heff_drop(v_t_2426); r_; });
              if (!(heff_dup(v_x1_2427) == NTAG(TAG_True))) {
                heff_drop(v_x1_2427);
                V v_t_2428 = ({ V a_0 = v_b_2412; V a_1 = v_argv_242; V r_ = (g_heff_2ecompile_2esimplify_2eprunedCopy(a_0, a_1)); heff_drop(v_argv_242); r_; });
                return heff_tag_n(TAG_Just, 1, (V[]){v_t_2428});
              } else {
                heff_drop(v_argv_242);
                heff_drop(v_b_2412);
                heff_drop(v_x1_2427);
                return NTAG(TAG_Nothing);
              }
            } else {
              heff_drop(v_g_241);
              heff_drop(v_argv_242);
              heff_drop(v_b_2412);
              heff_drop(v_x1_2424);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop_rec(v_s_240, 9);
          heff_drop(v_g_241);
          heff_drop(v_argv_242);
          heff_drop(v_field_2411);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_g_241);
      heff_drop(v_argv_242);
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownCopy(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2esimplify_2eshapeOne_24cpr(V v_m_240, V v_a_241, V v_s_242) {
top: ;
  if ((heff_dup(v_m_240) == NTAG(TAG_True))) {
    V v_t_243 = heff_rec_n(5, shape_ren__caps__vars__holes__n, (V[]){heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_s_242, 0)});
    HeffT2 v_t_244 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_241, v_t_243));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_e_247 = v_field_245;
      V v_st_248 = v_field_246;
      V v_vars_249 = heff_take_field(v_st_248, 2);
      V v_holes_2410 = heff_take_field(v_st_248, 3);
      V v_n_2411 = heff_get_n(v_st_248, 4, 5);
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_249));
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_holes_2410));
      V v_x_2414 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_e_247, v_t_2412, v_t_2413, v_n_2411});
      V v_f_2415 = ({ V rv_0 = heff_dup(heff_rfield(v_x_2414, 3)); V rr_ = heff_rec_reuse_nf(v_s_242, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 262140u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return ((HeffT2){{v_x_2414, v_f_2415}});
    }
  } else {
    V v_f_2416 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_a_241, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 0))});
    return ((HeffT2){{v_f_2416, v_s_242}});
  }
}
Clo g_heff_2ecompile_2esimplify_2eletsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOut_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eletsOut(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2esimplify_2eletsOut_24cpr(v_x1_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletsOut(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebindPushable_str0, 1, "t");
V g_heff_2ecompile_2esimplify_2ebindPushable_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2ebindPushable_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindPushable_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2ebindPushable_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ebindPushable_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ebindPushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebindPushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ebindPushable(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2ebindPushable_lam0_clo);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_argv_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x1_245 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_a_243)));
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ebind_clo), 2, (V[]){heff_clo_n(g_heff_2ecompile_2esimplify_2ebindPushable_lam1, 1, 2, (V[]){v_x1_245, v_a_243}), heff_clo_n(g_heff_2ecompile_2esimplify_2ebindPushable_lam2, 2, 1, (V[]){v_argv_244})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ebindPushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebindPushable(a[0]);
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam0(V self, V *args) {
  V v_s_241 = args[0];
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_s_241});
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam1(V self, V *args) {
  V v_p_246 = args[0];
  V v_x1_245 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop(v_x1_245);
    V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_p_246});
  } else {
    heff_drop(v_x1_245);
    HeffT2 v_t_248 = (g_heff_2ecompile_2esimplify_2efreshName_24cpr(((V)&g_heff_2ecompile_2esimplify_2ebindPushable_str0), v_p_246));
    {
      V v_field_249 = v_t_248.f[0];
      V v_field_2410 = v_t_248.f[1];
      V v_x_2411 = v_field_249;
      V v_s_2412 = v_field_2410;
      V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_2411), v_a_243})});
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_s_2412});
    }
  }
}
V g_heff_2ecompile_2esimplify_2ebindPushable_lam2(V self, V *args) {
  V v_one_2415 = args[0];
  V v_z_2416 = args[1];
  V v_argv_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_2417 = heff_tr(g_heff_2ecompile_2esimplify_2ebindPushable(v_argv_244));
  V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_2416}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_s_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    V v_t_2428;
    switch (heff_tag_of(v_one_2415)) {
    case TAG_MkPair: {
      V v_x11_2421 = heff_field(v_one_2415, 0);
      V v_a_2422 = heff_field(v_one_2415, 1);
      heff_take_n(v_one_2415, 3ULL, 2);
      switch (heff_tag_of(v_x11_2421)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x_2419)) {
        case TAG_MkPair: {
          V v_bds_2423 = heff_field(v_x_2419, 0);
          V v_argv_2424 = heff_field(v_x_2419, 1);
          heff_take_n(v_x_2419, 3ULL, 2);
          v_t_2428 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_bds_2423, heff_tag_n(TAG_Cons, 2, (V[]){v_a_2422, v_argv_2424})});
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        break;
      }
      case TAG_Just: {
        V v_bd_2425 = heff_field(v_x11_2421, 0);
        heff_take_n(v_x11_2421, 1ULL, 1);
        switch (heff_tag_of(v_x_2419)) {
        case TAG_MkPair: {
          V v_bds_2426 = heff_field(v_x_2419, 0);
          V v_argv_2427 = heff_field(v_x_2419, 1);
          heff_take_n(v_x_2419, 3ULL, 2);
          v_t_2428 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_bd_2425, v_bds_2426}), heff_tag_n(TAG_Cons, 2, (V[]){v_a_2422, v_argv_2427})});
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        break;
      }
      default: heff_nomatch(v_x11_2421);
      }
      break;
    }
    default: heff_nomatch(v_one_2415);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_s_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam46(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojectF_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_sh_242, V v_t_243, V v_e_244) {
top: ;
  V v_project_245 = heff_take_field(v_r_240, 2);
  V v_simp_246 = heff_get_n(v_r_240, 0, 4);
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam0, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_249 = heff_dup(heff_field(v_e_244, 0));
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam1, 1, 6, (V[]){v_g_249, v_e_244, v_l_241, v_sh_242, v_t_243, v_project_245});
  }
  case TAG_ELam: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam2, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EApp: {
    V v_e1_2422 = heff_dup(heff_field(v_e_244, 0));
    heff_drop(v_project_245);
    switch (heff_tag_of(v_e1_2422)) {
    case TAG_EVar: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam3, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam4, 1, 5, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243, v_simp_246});
    }
    case TAG_ELam: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam6, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EApp: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam7, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_ELet: {
      heff_take_n(v_e1_2422, 0ULL, 3);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam8, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_ERecord: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam9, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EProj: {
      heff_take_n(v_e1_2422, 0ULL, 4);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam10, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_ETag: {
      heff_take_n(v_e1_2422, 0ULL, 3);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam11, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EMatch: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam12, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam13, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam14, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_ECall: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam15, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EInt: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam16, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EFloat: {
      heff_take_na(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam17, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EStr: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam18, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EBytes: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam19, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EFixed: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam20, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EFloat32: {
      heff_take_na(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam21, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam22, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EBool: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam23, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_ESet: {
      heff_take_n(v_e1_2422, 0ULL, 3);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam24, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EValues: {
      heff_take_n(v_e1_2422, 0ULL, 1);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam25, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_EFix: {
      heff_take_n(v_e1_2422, 0ULL, 2);
      heff_drop(v_simp_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam26, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
    }
    default: return heff_nomatch(v_e1_2422);
    }
  }
  case TAG_ELet: {
    V v_x_2495 = heff_field(v_e_244, 0);
    V v_a_2496 = heff_field(v_e_244, 1);
    V v_b_2497 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    heff_drop(v_simp_246);
    V v_m_2498 = heff_tr(heff_call(v_project_245, 4, (V[]){v_l_241, v_sh_242, v_t_243, v_b_2497}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam27, 1, 3, (V[]){v_m_2498, v_x_2495, v_a_2496});
  }
  case TAG_ERecord: {
    V v_fs_24103 = heff_field(v_e_244, 0);
    V v_ts_24104 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    HeffT2 v_t_24105 = (g_heff_2ecompile_2esimplify_2efindField_24cpr(v_l_241, heff_dup(v_fs_24103)));
    {
      V v_field_24107 = v_t_24105.f[1];
      int64_t v_tag_24106 = ((int64_t)v_t_24105.f[0]);
      if ((v_tag_24106 == ((int64_t)0ULL))) {
        V v_v_24108 = v_field_24107;
        V v_m_24109 = (g_heff_2ecompile_2esimplify_2eothersPure(v_l_241, heff_dup(v_fs_24103)));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam28, 1, 7, (V[]){v_m_24109, v_v_24108, v_fs_24103, v_ts_24104, v_l_241, v_sh_242, v_t_243});
      } else {
        heff_drop(v_field_24107);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam29, 1, 5, (V[]){v_fs_24103, v_ts_24104, v_l_241, v_sh_242, v_t_243});
      }
    }
  }
  case TAG_EProj: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam30, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ETag: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam31, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EMatch: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam32, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrim: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam33, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam34, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ECall: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam35, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EInt: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam36, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam37, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EStr: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam38, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EBytes: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam39, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFixed: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam40, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam41, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam42, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EBool: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam43, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ESet: {
    V v_xs_24153 = heff_field(v_e_244, 0);
    V v_a_24154 = heff_field(v_e_244, 1);
    V v_b_24155 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    heff_drop(v_simp_246);
    V v_m_24156 = heff_tr(heff_call(v_project_245, 4, (V[]){v_l_241, v_sh_242, v_t_243, v_b_24155}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam44, 1, 3, (V[]){v_m_24156, v_xs_24153, v_a_24154});
  }
  case TAG_EValues: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam45, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFix: {
    heff_drop(v_project_245);
    heff_drop(v_simp_246);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam46, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojectF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_248 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_248});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_2410 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_project_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2411 = ({ V a_0 = heff_rfield(v_s_2410, 2); V a_1 = v_g_249; V r_ = (g_std_2emap_2elookup_24s1930949324x2078207031(a_0, a_1)); heff_drop(v_g_249); r_; });
  HeffT2 v_t_2412 = (g_heff_2ecompile_2esimplify_2efueled_24cpr(v_t_2411, v_s_2410));
  {
    V v_field_2413 = v_t_2412.f[0];
    V v_field_2414 = v_t_2412.f[1];
    V v_x_2415 = v_field_2413;
    V v_s_2416 = v_field_2414;
    switch (heff_tag_of(v_x_2415)) {
    case TAG_Nothing: {
      heff_drop(v_project_245);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2416});
    }
    case TAG_Just: {
      V v_b_2417 = heff_field(v_x_2415, 0);
      heff_take_n(v_x_2415, 1ULL, 1);
      V v_m_2418 = heff_tr(heff_call(v_project_245, 4, (V[]){heff_dup(v_l_241), heff_dup(v_sh_242), heff_dup(v_t_243), v_b_2417}));
      return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_m_2418, v_s_2416));
    }
    default: return heff_nomatch(v_x_2415);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2421 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2421});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2425 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2425});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2430 = args[0];
  V v_l_241 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_simp_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2431 = (g_heff_2ecompile_2esimplify_2ebuiltField_24cpr(v_l_241, heff_dup(v_e_244), v_s_2430));
  {
    V v_field_2432 = v_t_2431.f[0];
    V v_field_2433 = v_t_2431.f[1];
    V v_x_2434 = v_field_2432;
    V v_s_2435 = v_field_2433;
    switch (heff_tag_of(v_x_2434)) {
    case TAG_Nothing: {
      heff_drop(v_simp_246);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2435});
    }
    case TAG_Just: {
      V v_v_2436 = heff_field(v_x_2434, 0);
      heff_take_n(v_x_2434, 1ULL, 1);
      heff_drop(v_l_241);
      heff_drop_tag(v_e_244, 2);
      heff_drop(v_sh_242);
      heff_drop(v_t_243);
      V f_ = v_simp_246;
      heff_room[0] = v_v_2436;
      heff_room[1] = v_s_2435;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_x_2434);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2427 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_simp_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_s_2427, 7)), 0, 7);
  V v_t_2429 = ({ V a_0 = v_t_2428; V a_1 = v_e_244; V r_ = (g_heff_2ecompile_2esimplify_2ebuiltBy(a_0, a_1)); heff_drop(v_t_2428); r_; });
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    return (g_heff_2ecompile_2esimplify_2eattemptBy(MK_INT(24LL), heff_tag_n(TAG_EProj, 4, (V[]){heff_dup(v_e_244), heff_dup(v_l_241), heff_dup(v_sh_242), heff_dup(v_t_243)}), heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam5, 1, 5, (V[]){v_l_241, v_e_244, v_sh_242, v_t_243, v_simp_246}), v_s_2427));
  } else {
    heff_drop(v_simp_246);
    heff_drop(v_t_2429);
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2427});
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2439 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2439});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2442 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2442});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2446 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2446});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2449 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2449});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2454 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2454});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2458 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2458});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2461 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2461});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2463 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2463});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2466 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2466});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2469 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2469});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2471 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2471});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2473 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2473});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args) {
  V v_s_2475 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2475});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args) {
  V v_s_2477 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2477});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args) {
  V v_s_2480 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2480});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam21(V self, V *args) {
  V v_s_2482 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2482});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam22(V self, V *args) {
  V v_s_2483 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2483});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam23(V self, V *args) {
  V v_s_2485 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2485});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam24(V self, V *args) {
  V v_s_2489 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2489});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam25(V self, V *args) {
  V v_s_2491 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2491});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam26(V self, V *args) {
  V v_s_2494 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2494});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam27(V self, V *args) {
  V v_s_2499 = args[0];
  V v_m_2498 = heff_env(self)[0];
  V v_x_2495 = heff_env(self)[1];
  V v_a_2496 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24100 = heff_tr(heff_call(v_m_2498, 1, (V[]){v_s_2499}));
  switch (heff_tag_of(v_x2_24100)) {
  case TAG_MkPair: {
    V v_x_24101 = heff_field(v_x2_24100, 0);
    V v_s_24102 = heff_field(v_x2_24100, 1);
    V v_ru_24x2_24100_24MkPair = heff_take_reuse_n(v_x2_24100, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24100_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2495, v_a_2496, v_x_24101}), v_s_24102});
  }
  default: return heff_nomatch(v_x2_24100);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam28(V self, V *args) {
  V v_s_24110 = args[0];
  V v_m_24109 = heff_env(self)[0];
  V v_v_24108 = heff_env(self)[1];
  V v_fs_24103 = heff_env(self)[2];
  V v_ts_24104 = heff_env(self)[3];
  V v_l_241 = heff_env(self)[4];
  V v_sh_242 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_24111 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_s_24110}));
  switch (heff_tag_of(v_x2_24111)) {
  case TAG_MkPair: {
    V v_x_24112 = heff_field(v_x2_24111, 0);
    V v_s_24113 = heff_field(v_x2_24111, 1);
    V v_ru_24x2_24111_24MkPair = heff_take_reuse_n(v_x2_24111, 3ULL, 2);
    V v_t_24114;
    if ((heff_dup(v_x_24112) == NTAG(TAG_True))) {
      heff_drop(v_fs_24103);
      heff_drop(v_ts_24104);
      heff_drop(v_l_241);
      heff_drop(v_sh_242);
      heff_drop(v_t_243);
      heff_drop(v_x_24112);
      v_t_24114 = v_v_24108;
    } else {
      heff_drop(v_v_24108);
      heff_drop(v_x_24112);
      v_t_24114 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_24103, v_ts_24104}), v_l_241, v_sh_242, v_t_243});
    }
    return heff_tag_at_n(v_ru_24x2_24111_24MkPair, TAG_MkPair, 2, (V[]){v_t_24114, v_s_24113});
  }
  default: return heff_nomatch(v_x2_24111);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam29(V self, V *args) {
  V v_s_24115 = args[0];
  V v_fs_24103 = heff_env(self)[0];
  V v_ts_24104 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24116 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_24103, v_ts_24104}), v_l_241, v_sh_242, v_t_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24116, v_s_24115});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam30(V self, V *args) {
  V v_s_24121 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24121});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam31(V self, V *args) {
  V v_s_24125 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24125});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam32(V self, V *args) {
  V v_s_24128 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24128});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam33(V self, V *args) {
  V v_s_24130 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24130});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam34(V self, V *args) {
  V v_s_24133 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24133});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam35(V self, V *args) {
  V v_s_24136 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24136});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam36(V self, V *args) {
  V v_s_24138 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24138});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam37(V self, V *args) {
  V v_s_24140 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24140});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam38(V self, V *args) {
  V v_s_24142 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24142});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam39(V self, V *args) {
  V v_s_24144 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24144});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam40(V self, V *args) {
  V v_s_24147 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24147});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam41(V self, V *args) {
  V v_s_24149 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24149});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam42(V self, V *args) {
  V v_s_24150 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24150});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam43(V self, V *args) {
  V v_s_24152 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24152});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam44(V self, V *args) {
  V v_s_24157 = args[0];
  V v_m_24156 = heff_env(self)[0];
  V v_xs_24153 = heff_env(self)[1];
  V v_a_24154 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24158 = heff_tr(heff_call(v_m_24156, 1, (V[]){v_s_24157}));
  switch (heff_tag_of(v_x2_24158)) {
  case TAG_MkPair: {
    V v_x_24159 = heff_field(v_x2_24158, 0);
    V v_s_24160 = heff_field(v_x2_24158, 1);
    V v_ru_24x2_24158_24MkPair = heff_take_reuse_n(v_x2_24158, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24158_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_24153, v_a_24154, v_x_24159}), v_s_24160});
  }
  default: return heff_nomatch(v_x2_24158);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam45(V self, V *args) {
  V v_s_24162 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24162});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam46(V self, V *args) {
  V v_s_24165 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_24165});
}

HeffT2 g_heff_2ecompile_2esimplify_2esettleDef_24cpr(V v_n_240, V v_key_241, V v_b_242, V v_s_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2esimplify_2erecordDef_24cpr(heff_dup(v_key_241), heff_dup(v_b_242), v_s_243));
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    heff_drop(v_x_247);
    V v_s_248 = v_field_246;
    HeffT2 v_t_249 = (g_heff_2ecompile_2esimplify_2emarkSafe_24cpr(heff_dup(v_key_241), v_b_242, v_s_248));
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_x_2412 = v_field_2410;
      heff_drop(v_x_2412);
      V v_s_2413 = v_field_2411;
      V v_t_2414 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_242)));
      V v_t_2415 = (g_heff_2ecompile_2eir_2enubI(v_t_2414));
      HeffT2 v_t_2416 = (g_heff_2ecompile_2esimplify_2emakeEach_24cpr(v_t_2415, heff_dup(v_s_2413)));
      {
        V v_field_2417 = v_t_2416.f[0];
        V v_field_2418 = v_t_2416.f[1];
        V v_x_2419 = v_field_2417;
        V v_s_2420 = v_field_2418;
        if (heff_intLt_c_lent(MK_INT(0LL), v_n_240, 1)) {
          V v_t_2421 = (g_heff_2ecompile_2esimplify_2egrewIn(v_s_2413, heff_dup(v_s_2420), heff_dup(v_b_242)));
          if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
            heff_drop(v_t_2421);
            HeffT2 v_t_2422 = (g_heff_2ecompile_2esimplify_2eownSt_24cpr(v_s_2420));
            {
              V v_field_2423 = v_t_2422.f[0];
              V v_field_2424 = v_t_2422.f[1];
              V v_x_2425 = v_field_2423;
              heff_drop(v_x_2425);
              V v_s_2426 = v_field_2424;
              V v_m_2427 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b_242));
              V v_x2_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_s_2426}));
              switch (heff_tag_of(v_x2_2428)) {
              case TAG_MkPair: {
                V v_x_2429 = heff_field(v_x2_2428, 0);
                V v_s_2430 = heff_field(v_x2_2428, 1);
                V v_ru_24x2_2428_24MkPair = heff_take_reuse_n(v_x2_2428, 3ULL, 2);
                HeffT2 v_t_2431 = (g_heff_2ecompile_2esimplify_2eraise_24cpr(v_x_2429, v_s_2430));
                {
                  V v_field_2432 = v_t_2431.f[0];
                  V v_field_2433 = v_t_2431.f[1];
                  V v_x_2434 = v_field_2432;
                  V v_s_2435 = v_field_2433;
                  V v_m_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esettleDef_clo), 3, (V[]){heff_intSub(v_n_240, MK_INT(1LL)), v_key_241, v_x_2434}));
                  V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
                  switch (heff_tag_of(v_x2_2437)) {
                  case TAG_MkPair: {
                    V v_x_2438 = heff_field(v_x2_2437, 0);
                    V v_s_2439 = heff_field(v_x2_2437, 1);
                    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
                    V v_t_2442;
                    switch (heff_tag_of(v_x_2438)) {
                    case TAG_MkPair: {
                      V v_x_2440 = heff_dup(heff_field(v_x_2438, 0));
                      v_t_2442 = v_x_2440;
                      break;
                    }
                    default: heff_nomatch(v_x_2438);
                    }
                    V v_t_2445;
                    switch (heff_tag_of(v_x_2438)) {
                    case TAG_MkPair: {
                      V v_y_2444 = heff_field(v_x_2438, 1);
                      heff_take_n(v_x_2438, 2ULL, 2);
                      v_t_2445 = v_y_2444;
                      break;
                    }
                    default: heff_nomatch(v_x_2438);
                    }
                    V v_t_2446 = (g_heff_2ecompile_2esimplify_2eappendL_24tok2(v_ru_24x2_2437_24MkPair, v_x_2419, v_t_2445));
                    V v_x_2447 = heff_tag_at_n(v_ru_24x2_2428_24MkPair, TAG_MkPair, 2, (V[]){v_t_2442, v_t_2446});
                    return ((HeffT2){{v_x_2447, v_s_2439}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x2_2437)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x2_2428)}});
              }
            }
          } else {
            heff_drop(v_n_240);
            heff_drop(v_key_241);
            heff_drop(v_t_2421);
            return ((HeffT2){{heff_tag_n(TAG_MkPair, 2, (V[]){v_b_242, v_x_2419}), v_s_2420}});
          }
        } else {
          heff_drop(v_n_240);
          heff_drop(v_key_241);
          heff_drop(v_s_2413);
          return ((HeffT2){{heff_tag_n(TAG_MkPair, 2, (V[]){v_b_242, v_x_2419}), v_s_2420}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str0, 0, "");
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopiesDone_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopiesDone(V v_st_240, V v_defs_241) {
top: ;
  V v_bodies_242 = (g_list_2efoldl_24s1433066060x138395605(heff_dup(g_std_2emap_2eempty_get()), v_defs_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 3, 5);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_std_2emap_2eempty_get()), v_t_249));
  V v_t_2423 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam0, 1, 2, (V[]){v_st_240, v_bodies_242}), v_t_2410));
  return (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2423));
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopiesDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bodies_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 2, 7);
  HeffT2 v_t_2413 = ({ V a_0 = v_t_2412; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_r_2416 = v_field_2415;
      V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 0, 5);
      HeffT2 v_t_2418 = ({ V a_0 = v_t_2417; V a_1 = v_h_2411; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2417); r_; });
      V v_t_2422;
      {
        V v_field_2420 = v_t_2418.f[1];
        int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
        if ((v_tag_2419 == ((int64_t)0ULL))) {
          V v_x_2421 = v_field_2420;
          v_t_2422 = v_x_2421;
        } else {
          heff_drop(v_field_2420);
          v_t_2422 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str0);
        }
      }
      return ({ V a_0 = v_st_240; V a_1 = v_bodies_242; V a_2 = v_h_2411; V a_3 = v_t_2422; V a_4 = v_r_2416; V r_ = (g_heff_2ecompile_2esimplify_2ecopyWith(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bodies_242); r_; });
    } else {
      heff_drop(v_h_2411);
      heff_drop_rec(v_st_240, 9);
      heff_drop(v_bodies_242);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}