// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_all 306203
#define LBL_base 9511832
#define LBL_body 9524841
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipes 1314274025
#define LBL_safe 10017876
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2easkKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkKept_clo;
V g_heff_2ecompile_2esimplify_2easkedFor(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedFor_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2efindArm(V, V);
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindArm_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2efueled(V, V);
V g_heff_2ecompile_2esimplify_2efueled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efueled_clo;
V g_heff_2ecompile_2esimplify_2eintOp(V, V, V);
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eintOp_clo;
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2ekeptAsk(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo;
V g_heff_2ecompile_2esimplify_2eknownCopy(V, V);
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOut(V);
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOut_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emarkSafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
V g_heff_2ecompile_2esimplify_2epushArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushArm_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2ereplayBody(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo;
V g_heff_2ecompile_2esimplify_2esafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esafeAs_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2esumPushed(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esumPushed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumPushed_clo;
V g_heff_2ecompile_2esimplify_2esumTakenApart(V, V, V);
V g_heff_2ecompile_2esimplify_2esumTakenApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esumTakenApart_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_list_2efoldl_24s1748401606x190338434(V, V);
V g_list_2efoldl_24s1748401606x190338434_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1748401606x190338434_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str6, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str7, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str8, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str9, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str11, 5, "False");
Clo g_heff_2ecompile_2esimplify_2eintOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eintOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str0), 2)) {
    heff_drop(v_p_240);
    V v_t_244 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str1), 2)) {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str2), 2)) {
        heff_drop(v_p_240);
        V v_t_248 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str3), 2)) {
          heff_drop(v_p_240);
          V v_t_2411;
          if (heff_intEq_c(v_a_241, v_b_242)) {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str4);
          } else {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str5);
          }
          V v_t_2412 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2411, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str6), 2)) {
            heff_drop(v_p_240);
            V v_t_2415;
            if (heff_intLt_c(v_a_241, v_b_242)) {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str7);
            } else {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str8);
            }
            V v_t_2416 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2415, NTAG(TAG_Nil), NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
          } else {
            if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str9))) {
              V v_t_2419;
              if (heff_intLe_c(v_a_241, v_b_242)) {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str10);
              } else {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str11);
              }
              V v_t_2420 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2419, NTAG(TAG_Nil), NTAG(TAG_Nil)});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
            } else {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return NTAG(TAG_Nothing);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eintOp(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str1, 9, "strLength");
Clo g_heff_2ecompile_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2427 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str0))) {
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2427)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2429});
    } else {
      heff_drop(v_a_2427);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2431 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str1))) {
      V v_t_2433 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2431)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2433});
    } else {
      heff_drop(v_a_2431);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str0, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str1, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str3, 5, "False");
Clo g_heff_2ecompile_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      V v_b_2454 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eintOp(v_p_240, v_a_2428, v_b_2454);
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2428);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2464 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 4);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      V v_b_2492 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24EStr = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str0), 2)) {
        heff_drop(v_p_240);
        V v_t_2494 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2464, v_b_2492)});
        return heff_tag_at_n(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2494});
      } else {
        heff_drop_cell(v_ru_24x2_241_24EStr, 1);
        if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str1))) {
          V v_t_2497;
          if (heff_strEq_c(v_a_2464, v_b_2492)) {
            v_t_2497 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str2);
          } else {
            v_t_2497 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str3);
          }
          V v_t_2498 = heff_tag_n(TAG_ETag, 3, (V[]){v_t_2497, NTAG(TAG_Nil), NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2498});
        } else {
          heff_drop(v_a_2464);
          heff_drop(v_b_2492);
          heff_drop_cell(v_ru_24x3_242_24EStr, 1);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_EBytes: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_na(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2464);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_x2_245 = (g_heff_2ecompile_2esimplify_2eisPure(v_a_242, v_s_244));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2esimplify_2esumTakenApart(heff_dup(v_x_241), heff_dup(v_a_242), heff_dup(v_b_243)));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_x_246);
      heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
      heff_drop(v_t_248);
      V v_t_249 = (g_heff_2ecompile_2esimplify_2esumPushed(v_r_240, v_x_241, v_b_243, v_a_242));
      return heff_tail(v_t_249, 1, (V[]){v_s_247});
    } else {
      heff_drop(v_t_248);
      if ((heff_dup(v_x_246) == NTAG(TAG_True))) {
        heff_drop(v_x_246);
        heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
        V v_t_2411 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2410));
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
        V v_t_2413 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2412));
        V v_t_2414 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2411, v_t_2413}), 0, 2);
        V v_t_2415 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2414));
        return heff_tail(v_t_2415, 1, (V[]){v_s_247});
      } else {
        heff_drop(v_x_246);
        V v_t_2416 = (g_heff_2ecompile_2esimplify_2epartialApp(heff_dup(v_s_247), v_a_242));
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
          heff_drop(v_t_2416);
          HEFF_LAST return g_heff_2ecompile_2esimplify_2eletSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_247);
        } else {
          heff_drop(v_t_2416);
          V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
          V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_247}));
          switch (heff_tag_of(v_x2_2418)) {
          case TAG_MkPair: {
            V v_x_2419 = heff_field(v_x2_2418, 0);
            V v_s_2420 = heff_field(v_x2_2418, 1);
            heff_take_n(v_x2_2418, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2419}), v_s_2420});
          }
          default: return heff_nomatch(v_x2_2418);
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eknownCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownCopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknownCopy(V v_s_240, V v_g_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  V v_x3_243 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_242; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_242); r_; });
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_g_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 0ULL, 1);
    V v_t_245 = heff_get_n(heff_get_n(v_s_240, 7, 9), 0, 7);
    V v_t_246 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_g_241);
      heff_drop_cell(v_ru_24x3_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_b_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
      V v_x_249 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(50LL), MK_INT(0LL), v_t_248));
      if (heff_intLt_c(MK_INT(50LL), v_x_249)) {
        heff_drop(v_g_241);
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_b_247);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_2411 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_247)));
        V v_t_2412 = (g_heff_2ecompile_2eir_2enubI(v_t_2411));
        V v_x1_2413 = ({ V a_0 = v_g_241; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2412); r_; });
        if ((heff_dup(v_x1_2413) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_243_24Just, 1);
          heff_drop(v_b_247);
          heff_drop(v_x1_2413);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_2413);
          return heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_b_247});
        }
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2esimplify_2eknownCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownCopy(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2easkedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkedFor_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkedFor(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_x_245 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_244));
  V v_t_248;
  if (heff_intLt_c(MK_INT(1200LL), v_x_245)) {
    v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  } else {
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
    v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b0_241), v_t_247));
  }
  V v_t_2443;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2443 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2443 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2443 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2445;
  if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
    heff_drop(v_t_2443);
    V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    v_t_2445 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), v_t_2444));
  } else {
    heff_drop(v_t_2443);
    v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
  }
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 2, 7);
  V v_t_2447 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_b0_241, v_t_2446));
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 3, 7);
  V v_t_2449 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_d_242, v_t_2448));
  V v_t_2450 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 4, 7);
  V v_t_2451 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 5, 7);
  V v_t_2452 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 6, 7);
  V v_p_2453 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_248, v_t_2445, v_t_2447, v_t_2449, v_t_2450, heff_intAdd(v_t_2451, MK_INT(1LL)), v_t_2452});
  V v_t_2454 = ({ V rv_7 = v_p_2453; V rr_ = heff_rec_reuse_nf(v_s_243, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2454});
}
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2easkedFor(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2easkKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkKept(V v_h_240, V v_kc_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_kc_241, 5);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_p_243});
  }
  case TAG_Just: {
    V v_b_244 = heff_field(v_x3_242, 0);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2ecopy(heff_dup(v_b_244), v_p_243));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_240), v_x_246, heff_take_field(v_kc_241, 2), v_s_247));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_s_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 2ULL, 2);
        V v_x2_2411 = ({ V b_0 = heff_get_n(v_kc_241, 3, 5); V a_1 = v_h_240; V a_2 = v_s_2410; V r_ = (g_heff_2ecompile_2esimplify_2emarkSafeAs(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_MkPair: {
          V v_s_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 2ULL, 2);
          return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_2413});
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2easkKept(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eallAsked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallAsked_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallAsked(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_p_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_h_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2ekeptAsk(v_h_244, v_v_245, v_p_241));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_247);
          V t_0 = v_rest_243;
          V t_1 = v_s_248;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        } else {
          heff_drop(v_rest_243);
          heff_drop(v_x_247);
          return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_248});
        }
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallAsked(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eletsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOut_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eletsOut(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ELam: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ELet: {
    V v_x_247 = heff_field(v_e_240, 0);
    V v_a_248 = heff_field(v_e_240, 1);
    V v_e3_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_x3_2410 = (g_heff_2ecompile_2esimplify_2eletsOut(v_e3_249));
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_MkPair: {
      V v_bds_2411 = heff_field(v_x3_2410, 0);
      V v_e_2412 = heff_field(v_x3_2410, 1);
      V v_ru_24x3_2410_24MkPair = heff_take_reuse_n(v_x3_2410, 3ULL, 2);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x3_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, v_a_248}), v_bds_2411});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_e_2412});
    }
    default: return heff_nomatch(v_x3_2410);
    }
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_e_240});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOut_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletsOut(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  V v_it_245 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_r_240);
    V v_x_246 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_243});
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_EVar: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_243});
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_it1_247, 0);
      V v_b_2413 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      heff_drop_cell(v_ru_24it_245_24Just, 1);
      return (g_heff_2ecompile_2esimplify_2especLam(v_r_240, v_g_241, v_xs_2412, v_b_2413, v_as_242, v_s_243));
    }
    case TAG_EApp: {
      V v_ru_24it1_247_24EApp = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EApp, TAG_MkPair, 2, (V[]){v_x_2416, v_s_243});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2420 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_243});
    }
    case TAG_ERecord: {
      V v_ru_24it1_247_24ERecord = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2423 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ERecord, TAG_MkPair, 2, (V[]){v_x_2423, v_s_243});
    }
    case TAG_EProj: {
      heff_take_n(v_it1_247, 0ULL, 4);
      heff_drop(v_r_240);
      V v_x_2428 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2428, v_s_243});
    }
    case TAG_ETag: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2432 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2432, v_s_243});
    }
    case TAG_EMatch: {
      V v_ru_24it1_247_24EMatch = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2435 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EMatch, TAG_MkPair, 2, (V[]){v_x_2435, v_s_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2437 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2437, v_s_243});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_247_24EPrimCall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2440 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2440, v_s_243});
    }
    case TAG_ECall: {
      V v_ru_24it1_247_24ECall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2443 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ECall, TAG_MkPair, 2, (V[]){v_x_2443, v_s_243});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2445 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2445, v_s_243});
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2447 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_s_243});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2449 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2449, v_s_243});
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2451 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_s_243});
    }
    case TAG_EFixed: {
      V v_ru_24it1_247_24EFixed = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2454 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFixed, TAG_MkPair, 2, (V[]){v_x_2454, v_s_243});
    }
    case TAG_EFloat32: {
      heff_take_na(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2456 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2456, v_s_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_2457 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2457, v_s_243});
    }
    case TAG_EFix: {
      V v_ru_24it1_247_24EFix = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2460 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFix, TAG_MkPair, 2, (V[]){v_x_2460, v_s_243});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojectF_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_sh_242, V v_t_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam0, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EGlobal: {
    V v_g_247 = heff_dup(heff_field(v_e_244, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam1, 1, 6, (V[]){v_g_247, v_e_244, v_l_241, v_sh_242, v_t_243, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam2, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam3, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_e_244, 0);
    V v_a_2422 = heff_field(v_e_244, 1);
    V v_b_2423 = heff_field(v_e_244, 2);
    heff_take_n(v_e_244, 7ULL, 3);
    V v_m_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 4, (V[]){v_l_241, v_sh_242, v_t_243, v_b_2423}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam4, 1, 3, (V[]){v_m_2424, v_x_2421, v_a_2422});
  }
  case TAG_ERecord: {
    V v_fs_2429 = heff_field(v_e_244, 0);
    V v_ts_2430 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    heff_drop_rec(v_r_240, 4);
    V v_t_2431 = (g_heff_2ecompile_2esimplify_2efindField(heff_dup(v_l_241), v_fs_2429));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam5, 1, 5, (V[]){v_fs_2429, v_ts_2430, v_l_241, v_sh_242, v_t_243});
    }
    case TAG_Just: {
      V v_v_2434 = heff_field(v_t_2431, 0);
      heff_take_n(v_t_2431, 1ULL, 1);
      V v_m_2435 = (g_heff_2ecompile_2esimplify_2eothersPure(heff_dup(v_l_241), heff_dup(v_fs_2429)));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam6, 1, 7, (V[]){v_m_2435, v_v_2434, v_fs_2429, v_ts_2430, v_l_241, v_sh_242, v_t_243});
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam7, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ETag: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam8, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam9, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam10, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam11, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam12, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam13, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam14, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam15, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EBytes: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam16, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam17, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam18, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam19, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam20, 1, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243});
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojectF(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_246});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_g_247 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  V v_r_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = (g_map_2elookup_24s1546226666x2146984184(v_g_247, heff_rfield(v_s_248, 2)));
  V v_x2_2410 = (g_heff_2ecompile_2esimplify_2efueled(v_t_249, v_s_248));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    switch (heff_tag_of(v_x_2411)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2412});
    }
    case TAG_Just: {
      V v_b_2413 = heff_field(v_x_2411, 0);
      heff_take_n(v_x_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2410_24MkPair, 2);
      V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 4, (V[]){heff_dup(v_l_241), heff_dup(v_sh_242), heff_dup(v_t_243), v_b_2413}));
      return (g_heff_2ecompile_2esimplify_2eattempt(heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_t_2414, v_s_2412));
    }
    default: return heff_nomatch(v_x_2411);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2417 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2417});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2420});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_a_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_s_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_x_2427 = heff_field(v_x2_2426, 0);
    V v_s_2428 = heff_field(v_x2_2426, 1);
    V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2421, v_a_2422, v_x_2427}), v_s_2428});
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_fs_2429 = heff_env(self)[0];
  V v_ts_2430 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_t_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2429, v_ts_2430}), v_l_241, v_sh_242, v_t_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_2432});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_v_2434 = heff_env(self)[1];
  V v_fs_2429 = heff_env(self)[2];
  V v_ts_2430 = heff_env(self)[3];
  V v_l_241 = heff_env(self)[4];
  V v_sh_242 = heff_env(self)[5];
  V v_t_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_s_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_s_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    V v_t_2440;
    if ((heff_dup(v_x_2438) == NTAG(TAG_True))) {
      heff_drop(v_fs_2429);
      heff_drop(v_ts_2430);
      heff_drop(v_l_241);
      heff_drop(v_sh_242);
      heff_drop(v_t_243);
      heff_drop(v_x_2438);
      v_t_2440 = v_v_2434;
    } else {
      heff_drop(v_v_2434);
      heff_drop(v_x_2438);
      v_t_2440 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_fs_2429, v_ts_2430}), v_l_241, v_sh_242, v_t_243});
    }
    return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){v_t_2440, v_s_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2445});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2449 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2449});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2452 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2452});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2454 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2454});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2457 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2457});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2460 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2460});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2462 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2462});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2464});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2466 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2466});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2468 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2468});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2471 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2471});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args) {
  V v_s_2473 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2473});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args) {
  V v_s_2474 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2474});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam20(V self, V *args) {
  V v_s_2477 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_244, v_l_241, v_sh_242, v_t_243}), v_s_2477});
}
Clo g_heff_2ecompile_2esimplify_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindArm_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c_lent(v_t2_244, v_t_240, 0)) {
        heff_drop(v_t_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(v_t2_244), heff_dup(v_vs_245), heff_dup(v_b_246)})});
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindArm(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2epushArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushArm_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    V v_x2_248 = (g_heff_2ecompile_2esimplify_2ecopy(v_t_247, v_p_243));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2445;
      switch (heff_tag_of(v_x_249)) {
      case TAG_EVar: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_249, 0ULL, 4);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2430 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2445 = v_arms_2430;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x_249, 0ULL, 1);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2445 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_m_2446 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_246, v_t_2445}));
      V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x2_2447, 0);
        V v_s_2449 = heff_field(v_x2_2447, 1);
        heff_take_n(v_x2_2447, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2448}), v_s_2449});
      }
      default: return heff_nomatch(v_x2_2447);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushArm(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_x_244 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(1200LL), MK_INT(0LL), v_t_243));
  V v_t_247;
  if (heff_intLt_c(MK_INT(1200LL), v_x_244)) {
    v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
    v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), v_t_246));
  }
  V v_t_2442;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 4);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_na(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_b_241, 0ULL, 1);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2442 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2444;
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
    v_t_2444 = (g_map_2einsert_24s1341440536x470972936(v_key_240, NTAG(TAG_MkUnit), v_t_2443));
  } else {
    heff_drop(v_key_240);
    heff_drop(v_t_2442);
    v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
  }
  V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 3, 7);
  V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 4, 7);
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 5, 7);
  V v_t_2449 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 6, 7);
  V v_p_2450 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_247, v_t_2444, v_t_2445, v_t_2446, v_t_2447, v_t_2448, v_t_2449});
  return ({ V rv_7 = v_p_2450; V rr_ = heff_rec_reuse_nf(v_s_242, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 212991u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeFresh_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeFresh(V v_h_240, V v_b0_241, V v_s_242) {
top: ;
  V v_k_243 = heff_dup(heff_rfield(v_s_242, 8));
  V v_t_244 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_k_243, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_245 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), heff_take_field(v_s_242, 3), heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 6), heff_take_field(v_s_242, 7), v_t_244});
  V v_x2_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2esimplify_2eownSt(v_s_248));
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_s_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24MkPair = heff_take_reuse_n(v_t_249, 2ULL, 2);
      V v_m_2412 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b0_241));
      V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2414));
        V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2415}));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          V v_x2_2420 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2418, v_s_2419));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x2_2420, 0);
            V v_s_2422 = heff_field(v_x2_2420, 1);
            heff_take_n(v_x2_2420, 3ULL, 2);
            V v_k_2423 = heff_dup(heff_rfield(v_s_2422, 8));
            V v_t_2424 = heff_get_n(heff_get_n(v_s_242, 8, 9), 2, 5);
            V v_k_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_k_2423, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_2422, 8)), 2, 5);
            V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_t_2426, heff_take_field(v_k_2425, 4)));
            V v_k_2428 = ({ V rv_4 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_k_2425, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
            V v_t_2429 = ({ V rv_8 = v_k_2428; V rr_ = heff_rec_reuse_nf(v_s_2422, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
            V v_x2_2430 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2429});
            switch (heff_tag_of(v_x2_2430)) {
            case TAG_MkPair: {
              V v_s_2432 = heff_field(v_x2_2430, 1);
              heff_take_n(v_x2_2430, 2ULL, 2);
              return heff_tag_at_n(v_ru_24t_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2432});
            }
            default: return heff_nomatch(v_x2_2430);
            }
          }
          default: return heff_nomatch(v_x2_2420);
          }
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeFresh(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayBody_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayBody(V v_k_240, V v_b0_241, V v_s_242) {
top: ;
  V v_x2_243 = (g_heff_2ecompile_2esimplify_2ecopy(v_b0_241, v_s_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(heff_rfield(v_k_240, 0)), heff_dup(v_x_244), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
      V v_x2_249 = (g_heff_2ecompile_2esimplify_2esafeAs(heff_rfield(v_k_240, 3), heff_dup(heff_rfield(v_k_240, 0)), v_s_248));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 2ULL, 2);
        V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_244)));
        V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
        V v_x2_2414 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2413, v_s_2411));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_t_2417 = heff_rec_n(3, shape_key__name__body, (V[]){heff_take_field(v_k_240, 0), heff_get_n(v_k_240, 1, 7), v_x_244});
          V v_t_2418 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
          V v_x_2419 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2415, v_t_2418));
          return heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2416});
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayBody(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str0, 0, "");
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopiesDone_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopiesDone(V v_st_240, V v_defs_241) {
top: ;
  V v_bodies_242 = (g_list_2efoldl_24s1748401606x190338434(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 3, 5);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_249));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam0, 1, 2, (V[]){v_st_240, v_bodies_242}), v_t_2410));
  return (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2419));
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopiesDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bodies_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 2, 7);
  V v_t_2413 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2412; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_h_2411);
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_bodies_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_r_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 0, 5);
    V v_x2_2416 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return ({ V a_0 = v_st_240; V a_1 = v_bodies_242; V a_2 = v_h_2411; V a_3 = v_t_2418; V a_4 = v_r_2414; V r_ = (g_heff_2ecompile_2esimplify_2ecopyWith(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bodies_242); r_; });
  }
  default: return heff_nomatch(v_t_2413);
  }
}