// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CDrop 58400
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_ExplicitParam 63083
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IApp 21275
#define TAG_IPrim 59489
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PatVar 49363
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_doc 309170
#define LBL_e 319
#define LBL_end 310101
#define LBL_eqns 9616440
#define LBL_filter 672649891
#define LBL_forwards 1228451848
#define LBL_hash 9690581
#define LBL_key 315609
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_meta 9843404
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_path 9928940
#define LBL_required 351999471
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_use 325633
#define LBL_values 1123329101
#define LBL_version 583465758
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__key[] = {LBL_name, LBL_key};
V g_heff_2ebuild_2edriver_2eoutcomeOfV(V);
V g_heff_2ebuild_2edriver_2eoutcomeOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eoutcomeOfV_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eemit_2eloops(V);
V g_heff_2ecompile_2eemit_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2eloops_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eglueProvider(V);
V g_heff_2ecompile_2eemitc_2eglueProvider_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eglueProvider_clo;
V g_heff_2ecompile_2eemitc_2eidentAt(V, V, V);
V g_heff_2ecompile_2eemitc_2eidentAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eidentAt_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2esimplify_2efieldValue(V);
V g_heff_2ecompile_2esimplify_2efieldValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldValue_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2eimport_2eimplicitImports_get(void);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(V, V, V);
V g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
HeffT2 g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(V, V);
V g_heff_2esyntax_2esurface_2easNameE(V);
V g_heff_2esyntax_2esurface_2easNameE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easNameE_clo;
V g_heff_2esyntax_2esurface_2eunevenAt(V, V, V);
V g_heff_2esyntax_2esurface_2eunevenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunevenAt_clo;
V g_list_2eall_24s1447613073x1712348205(V);
V g_list_2eall_24s1447613073x1712348205_entry(V self, V *a);
extern Clo g_list_2eall_24s1447613073x1712348205_clo;
V g_list_2eall_24s2093734251x1702493483(V, V, V, V);
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a);
extern Clo g_list_2eall_24s2093734251x1702493483_clo;
V g_list_2eall_24s853093203x77424416(V);
V g_list_2eall_24s853093203x77424416_entry(V self, V *a);
extern Clo g_list_2eall_24s853093203x77424416_clo;
V g_list_2eany_24s100684943x1504448948(V, V);
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a);
extern Clo g_list_2eany_24s100684943x1504448948_clo;
V g_list_2eany_24s1662685276x243749136(V, V);
V g_list_2eany_24s1662685276x243749136_entry(V self, V *a);
extern Clo g_list_2eany_24s1662685276x243749136_clo;
V g_list_2eany_24s184951243x1948563855(V);
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a);
extern Clo g_list_2eany_24s184951243x1948563855_clo;
V g_list_2eany_24s1955261718x109443523(V, V, V);
V g_list_2eany_24s1955261718x109443523_entry(V self, V *a);
extern Clo g_list_2eany_24s1955261718x109443523_clo;
V g_list_2eany_24s2135465121x1956745568(V);
V g_list_2eany_24s2135465121x1956745568_entry(V self, V *a);
extern Clo g_list_2eany_24s2135465121x1956745568_clo;
V g_list_2eany_24s750144226x405092487(V);
V g_list_2eany_24s750144226x405092487_entry(V self, V *a);
extern Clo g_list_2eany_24s750144226x405092487_clo;
V g_list_2edescending_24s1679501129x89119467(V, V, V);
V g_list_2edescending_24s1679501129x89119467_entry(V self, V *a);
extern Clo g_list_2edescending_24s1679501129x89119467_clo;
HeffT2 g_list_2efind_24s764539875x1185200879_24cpr(V, V);
V g_list_2efoldl_24f1443542135x1147816397(V, V, V, V);
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1443542135x1147816397_clo;
V g_list_2efoldl_24f1763211578x1610911617(V, V, V, V, V, V);
V g_list_2efoldl_24f1763211578x1610911617_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1763211578x1610911617_clo;
V g_list_2efoldl_24f409057300x985797598(V, V);
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a);
extern Clo g_list_2efoldl_24f409057300x985797598_clo;
V g_list_2efoldl_24f450671696x846133639(V, V, V, V, V);
V g_list_2efoldl_24f450671696x846133639_entry(V self, V *a);
extern Clo g_list_2efoldl_24f450671696x846133639_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s1880194630x798487332(V, V);
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1880194630x798487332_clo;
V g_list_2efoldl_24s2063245892x1543682505(V, V);
V g_list_2efoldl_24s2063245892x1543682505_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2063245892x1543682505_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s871632021x1241775640(V, V, V, V);
V g_list_2efoldl_24s871632021x1241775640_entry(V self, V *a);
extern Clo g_list_2efoldl_24s871632021x1241775640_clo;
V g_list_2ekeepIf_24f1368804635x922296653(V, V);
V g_list_2ekeepIf_24f1368804635x922296653_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1368804635x922296653_clo;
V g_list_2ekeepIf_24f1368804635x922296653_24dps(V, V, V);
V g_list_2ekeepIf_24f1368804635x922296653_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1368804635x922296653_24dps_clo;
V g_list_2ekeepIf_24s1606737509x658906972_24dps(V, V);
V g_list_2ekeepIf_24s1606737509x658906972_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1606737509x658906972_24dps_clo;
V g_list_2emap_24f1512150482x179770396_24dps(V, V, V, V, V);
V g_list_2emap_24f1512150482x179770396_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1512150482x179770396_24dps_clo;
V g_list_2emap_24f719546030x1732151491_24dps(V, V, V);
V g_list_2emap_24f719546030x1732151491_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f719546030x1732151491_24dps_clo;
V g_list_2emap_24s1006818869x590968200_24dps(V, V);
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_24dps_clo;
V g_list_2emap_24s1127556009x863725781(V, V, V, V, V, V);
V g_list_2emap_24s1127556009x863725781_entry(V self, V *a);
extern Clo g_list_2emap_24s1127556009x863725781_clo;
V g_list_2emap_24s1127556009x863725781_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24s1127556009x863725781_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1127556009x863725781_24dps_clo;
V g_list_2emap_24s1218298322x1569510752_24dps(V, V, V);
V g_list_2emap_24s1218298322x1569510752_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1218298322x1569510752_24dps_clo;
V g_list_2emap_24s1230649048x711093514_24dps(V, V, V);
V g_list_2emap_24s1230649048x711093514_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230649048x711093514_24dps_clo;
V g_list_2emap_24s1281445768x1036802655_24dps(V, V);
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1281445768x1036802655_24dps_clo;
V g_list_2emap_24s1366476796x894764441_24dps(V, V, V);
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1366476796x894764441_24dps_clo;
V g_list_2emap_24s143096761x246530315_24dps(V, V);
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_24dps_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s1435185561x202019164_24dps(V, V);
V g_list_2emap_24s1435185561x202019164_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_24dps_clo;
V g_list_2emap_24s1624059865x1140896478(V);
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_clo;
V g_list_2emap_24s1624059865x1140896478_24dps(V, V);
V g_list_2emap_24s1624059865x1140896478_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1624059865x1140896478_24dps_clo;
V g_list_2emap_24s1732792088x1893487364_24dps(V, V, V, V);
V g_list_2emap_24s1732792088x1893487364_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1732792088x1893487364_24dps_clo;
V g_list_2emap_24s1753874608x910016727_24dps(V, V);
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1753874608x910016727_24dps_clo;
V g_list_2emap_24s1782778565x402128078(V);
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_clo;
V g_list_2emap_24s1782778565x402128078_24dps(V, V);
V g_list_2emap_24s1782778565x402128078_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1782778565x402128078_24dps_clo;
V g_list_2emap_24s1796125103x644876049_24dps(V, V);
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_24dps_clo;
V g_list_2emap_24s1895313378x47656836_24dps(V, V);
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1895313378x47656836_24dps_clo;
V g_list_2emap_24s1902028738x441242582_24dps(V, V);
V g_list_2emap_24s1902028738x441242582_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1902028738x441242582_24dps_clo;
V g_list_2emap_24s2016443462x370533815(V);
V g_list_2emap_24s2016443462x370533815_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_clo;
V g_list_2emap_24s2016443462x370533815_24dps(V, V);
V g_list_2emap_24s2016443462x370533815_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_24dps_clo;
V g_list_2emap_24s2081681776x559624592(V);
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_clo;
V g_list_2emap_24s2081681776x559624592_24dps(V, V);
V g_list_2emap_24s2081681776x559624592_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2081681776x559624592_24dps_clo;
V g_list_2emap_24s2098427539x1767581560_24dps(V, V, V, V, V);
V g_list_2emap_24s2098427539x1767581560_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2098427539x1767581560_24dps_clo;
V g_list_2emap_24s228910449x1110031924(V, V);
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_clo;
V g_list_2emap_24s228910449x1110031924_24dps(V, V, V);
V g_list_2emap_24s228910449x1110031924_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s228910449x1110031924_24dps_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s262223576x596329185_24dps(V, V, V, V, V, V);
V g_list_2emap_24s262223576x596329185_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s262223576x596329185_24dps_clo;
V g_list_2emap_24s328934344x1728860012_24dps(V, V, V);
V g_list_2emap_24s328934344x1728860012_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_24dps_clo;
V g_list_2emap_24s347605591x806617237_24dps(V, V);
V g_list_2emap_24s347605591x806617237_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s347605591x806617237_24dps_clo;
V g_list_2emap_24s577269653x49010166(V);
V g_list_2emap_24s577269653x49010166_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s693155583x821663253(V, V, V);
V g_list_2emap_24s693155583x821663253_entry(V self, V *a);
extern Clo g_list_2emap_24s693155583x821663253_clo;
V g_list_2emap_24s693155583x821663253_24dps(V, V, V, V);
V g_list_2emap_24s693155583x821663253_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s693155583x821663253_24dps_clo;
V g_list_2emap_24s720989758x1967438448(V);
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_clo;
V g_list_2emap_24s720989758x1967438448_24dps(V, V);
V g_list_2emap_24s720989758x1967438448_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s720989758x1967438448_24dps_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24s831190316x576961335_24dps(V, V);
V g_list_2emap_24s831190316x576961335_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s864521685x1610969087_24dps(V, V);
V g_list_2emap_24s864521685x1610969087_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_24dps_clo;
V g_list_2emap_24s961097229x1129443801_24dps(V, V);
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_24dps_clo;
V g_list_2emerge_24s275559350x890699445(V, V);
V g_list_2emerge_24s275559350x890699445_entry(V self, V *a);
extern Clo g_list_2emerge_24s275559350x890699445_clo;
V g_list_2epushRun_24s368060031x1022896115(V, V, V);
V g_list_2epushRun_24s368060031x1022896115_entry(V self, V *a);
extern Clo g_list_2epushRun_24s368060031x1022896115_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f892794188x1384814865(V, V, V);
V g_prelude_2e_2b_2b_24f892794188x1384814865_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f892794188x1384814865_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2ecli_2eline2(V, V);
V g_std_2ecli_2eline2_entry(V self, V *a);
extern Clo g_std_2ecli_2eline2_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2e_3c_3e_24tok2(V, V, V);
V g_std_2edoc_2e_3c_3e_24tok2_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_24tok2_clo;
Clo g_list_2eall_24s853093203x77424416_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s853093203x77424416_entry, 1, 0};

V g_list_2eall_24s853093203x77424416(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_Unreached: {
      return NTAG(TAG_False);
    }
    case TAG_Within: {
      V v_r1_243 = heff_field(v_x_241, 0);
      V v_r2_244 = heff_field(v_x_241, 1);
      switch (heff_tag_of(v_r1_243)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_r2_244)) {
        case TAG_Nothing: {
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
        case TAG_Just: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_r2_244);
        }
      }
      case TAG_Just: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_r1_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s853093203x77424416_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s853093203x77424416(a0); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1606737509x658906972_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1606737509x658906972_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1606737509x658906972_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_247 = heff_get_n(v_t_246, 2, 3);
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_247, 0ULL, 2);
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1606737509x658906972_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1606737509x658906972_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s750144226x405092487_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s750144226x405092487_entry, 1, 0};

V g_list_2eany_24s750144226x405092487(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    HeffT2 v_t_243 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_x_241); HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2estmtAcc_24s1724669254x444492892_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_244 = v_t_243.f[0];
      V v_field_245 = v_t_243.f[1];
      V v_a_246 = v_field_244;
      V v_a_247 = v_field_245;
      heff_drop(v_a_247);
      if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
        heff_drop(v_a_246);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_a_246);
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s750144226x405092487_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s750144226x405092487(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1732792088x1893487364_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1732792088x1893487364_24dps_entry, 4, 0};

V g_list_2emap_24s1732792088x1893487364_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2esyntax_2epresyntax_2earmT_24s497697580x170440955(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1732792088x1893487364_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1732792088x1893487364_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s961097229x1129443801_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s961097229x1129443801_24dps_entry, 2, 0};

V g_list_2emap_24s961097229x1129443801_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = v_x_242;
    V v_t_2437;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_At: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      V v_sp_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24At = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_SetField: {
        V v_x_247 = heff_field(v_x21_245, 0);
        V v_xsp_248 = heff_field(v_x21_245, 1);
        V v_e_249 = heff_field(v_x21_245, 2);
        V v_ru_24x21_245_24SetField = heff_take_reuse_n(v_x21_245, 7ULL, 3);
        HeffT2 v_t_2410 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_249));
        V v_t_2422;
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_244_24At, 2);
            V v_c_2413 = v_field_2412;
            v_t_2422 = v_c_2413;
          } else {
            if ((v_tag_2411 == ((int64_t)1ULL))) {
              V v_i_2414 = v_field_2412;
              V v_t_2417;
              switch (heff_tag_of(v_i_2414)) {
              case TAG_At: {
                V v_s_2416 = heff_dup(heff_field(v_i_2414, 1));
                v_t_2417 = v_s_2416;
                break;
              }
              default: heff_nomatch(v_i_2414);
              }
              v_t_2422 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2414}), v_t_2417});
            } else {
              V v_t_2418 = v_field_2412;
              V v_t_2421;
              switch (heff_tag_of(v_t_2418)) {
              case TAG_At: {
                V v_s_2420 = heff_dup(heff_field(v_t_2418, 1));
                v_t_2421 = v_s_2420;
                break;
              }
              default: heff_nomatch(v_t_2418);
              }
              v_t_2422 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2418}), v_t_2421});
            }
          }
        }
        v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_245_24SetField, TAG_SetField, 3, (V[]){v_x_247, v_xsp_248, v_t_2422}), v_sp_246});
        break;
      }
      case TAG_BadFieldSet: {
        V v_e_2423 = heff_field(v_x21_245, 0);
        V v_ru_24x21_245_24BadFieldSet = heff_take_reuse_n(v_x21_245, 1ULL, 1);
        HeffT2 v_t_2424 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_e_2423));
        V v_t_2436;
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          if ((v_tag_2425 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_244_24At, 2);
            V v_c_2427 = v_field_2426;
            v_t_2436 = v_c_2427;
          } else {
            if ((v_tag_2425 == ((int64_t)1ULL))) {
              V v_i_2428 = v_field_2426;
              V v_t_2431;
              switch (heff_tag_of(v_i_2428)) {
              case TAG_At: {
                V v_s_2430 = heff_dup(heff_field(v_i_2428, 1));
                v_t_2431 = v_s_2430;
                break;
              }
              default: heff_nomatch(v_i_2428);
              }
              v_t_2436 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2428}), v_t_2431});
            } else {
              V v_t_2432 = v_field_2426;
              V v_t_2435;
              switch (heff_tag_of(v_t_2432)) {
              case TAG_At: {
                V v_s_2434 = heff_dup(heff_field(v_t_2432, 1));
                v_t_2435 = v_s_2434;
                break;
              }
              default: heff_nomatch(v_t_2432);
              }
              v_t_2436 = heff_tag_at_n(v_ru_24x2_244_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_t_2432}), v_t_2435});
            }
          }
        }
        v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x21_245_24BadFieldSet, TAG_BadFieldSet, 1, (V[]){v_t_2436}), v_sp_246});
        break;
      }
      default: heff_nomatch(v_x21_245);
      }
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_cell_2438 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2437, heff_hole()});
    V v_u_2439 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2438));
    heff_drop(v_u_2439);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2438;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s961097229x1129443801_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1782778565x402128078_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1782778565x402128078_entry, 1, 0};

V g_list_2emap_24s1782778565x402128078(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        V v_ru_24a_243_24MkEquation = heff_take_reuse_n(v_a_243, 15ULL, 4);
        V v_t_2412;
        switch (heff_tag_of(v_a_248)) {
        case TAG_At: {
          V v_a_249 = heff_field(v_a_248, 0);
          V v_a_2410 = heff_field(v_a_248, 1);
          heff_take_n(v_a_248, 3ULL, 2);
          V v_t_2411 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_a_249));
          v_t_2412 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2411, v_a_2410});
          break;
        }
        default: heff_nomatch(v_a_248);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24MkEquation, TAG_MkEquation, 4, (V[]){v_a_245, v_a_246, v_a_247, v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s1782778565x402128078_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1782778565x402128078_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1782778565x402128078(a[0]);
}
Clo g_list_2emap_24s1624059865x1140896478_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1624059865x1140896478_entry, 1, 0};

V g_list_2emap_24s1624059865x1140896478(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2esurface_2easNameE(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1624059865x1140896478_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1624059865x1140896478_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1624059865x1140896478(a[0]);
}
Clo g_list_2emap_24s2081681776x559624592_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2081681776x559624592_entry, 1, 0};

V g_list_2emap_24s2081681776x559624592(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_241)) {
    case TAG_Left: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2416 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Right: {
      V v_d_244 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 1);
      V v_eqns_245 = heff_take_field(v_d_244, 3);
      V v_name_246 = heff_get_n(v_d_244, 0, 5);
      switch (heff_tag_of(v_eqns_245)) {
      case TAG_Nil: {
        heff_drop(v_name_246);
        v_t_2416 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_it1_247 = heff_field(v_eqns_245, 0);
        V v_rest_248 = heff_field(v_eqns_245, 1);
        heff_take_n(v_eqns_245, 3ULL, 2);
        switch (heff_tag_of(v_it1_247)) {
        case TAG_At: {
          V v_it11_249 = heff_field(v_it1_247, 0);
          heff_take_n(v_it1_247, 1ULL, 2);
          switch (heff_tag_of(v_it11_249)) {
          case TAG_MkEquation: {
            V v_pats_2413 = heff_field(v_it11_249, 2);
            heff_take_n(v_it11_249, 4ULL, 4);
            V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_pats_2413; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_pats_2413); r_; });
            v_t_2416 = ({ V a_0 = v_name_246; V a_1 = v_t_2415; V a_2 = v_rest_248; V r_ = (g_heff_2esyntax_2esurface_2eunevenAt(a_0, a_1, a_2)); heff_drop(v_rest_248); r_; });
            break;
          }
          default: heff_nomatch(v_it11_249);
          }
          break;
        }
        default: heff_nomatch(v_it1_247);
        }
        break;
      }
      default: heff_nomatch(v_eqns_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = (g_list_2emap_24s2081681776x559624592_24dps(v_xs_242, heff_dup(v_cell_2417)));
    heff_drop(v_u_2418);
    return v_cell_2417;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2081681776x559624592_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2081681776x559624592(a[0]);
}
Clo g_list_2emap_24s1006818869x590968200_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006818869x590968200_24dps_entry, 2, 0};

V g_list_2emap_24s1006818869x590968200_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 7), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1006818869x590968200_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006818869x590968200_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str0, 7, "Float64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str1, 4, "Int8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str2, 5, "Int16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str3, 5, "Int32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str4, 5, "Int64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str5, 5, "UInt8");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str6, 6, "UInt16");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str7, 6, "UInt32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str8, 6, "UInt64");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str9, 7, "Float32");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str10, 1, "_");
HEFF_LIT(g_list_2emap_24s143096761x246530315_24dps_str11, 1, "\?");
Clo g_list_2emap_24s143096761x246530315_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s143096761x246530315_24dps_entry, 2, 0};

V g_list_2emap_24s143096761x246530315_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_FtFloat: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str0);
      break;
    }
    case TAG_FtFixed: {
      V v_w_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      switch (heff_tag_of(v_w_244)) {
      case TAG_I8: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str1);
        break;
      }
      case TAG_I16: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str2);
        break;
      }
      case TAG_I32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str3);
        break;
      }
      case TAG_I64: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str4);
        break;
      }
      case TAG_U8: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str5);
        break;
      }
      case TAG_U16: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str6);
        break;
      }
      case TAG_U32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str7);
        break;
      }
      case TAG_U64: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str8);
        break;
      }
      case TAG_F32: {
        v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str9);
        break;
      }
      default: heff_nomatch(v_w_244);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str10);
      break;
    }
    case TAG_FtAny: {
      v_t_245 = ((V)&g_list_2emap_24s143096761x246530315_24dps_str11);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s143096761x246530315_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s143096761x246530315_24dps(a[0], a[1]);
}
Clo g_list_2eall_24s1447613073x1712348205_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s1447613073x1712348205_entry, 1, 0};

V g_list_2eall_24s1447613073x1712348205(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2efieldValue(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eall_24s1447613073x1712348205_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eall_24s1447613073x1712348205(a0); heff_drop(a0); return r;
}
Clo g_list_2eany_24s100684943x1504448948_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s100684943x1504448948_entry, 2, 0};

V g_list_2eany_24s100684943x1504448948(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = (g_heff_2ecompile_2erepr_2ereprEq(v_lit_240, v_x_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s100684943x1504448948_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s100684943x1504448948(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1796125103x644876049_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1796125103x644876049_24dps_entry, 2, 0};

V g_list_2emap_24s1796125103x644876049_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_CDrop, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1796125103x644876049_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1796125103x644876049_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1902028738x441242582_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1902028738x441242582_24dps_entry, 2, 0};

V g_list_2emap_24s1902028738x441242582_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_242)) {
    case TAG_RepV: {
      v_t_245 = NTAG(TAG_FtOther);
      break;
    }
    case TAG_RepFix: {
      V v_w_244 = heff_field(v_x_242, 0);
      V v_ru_24x_242_24RepFix = heff_take_reuse_n(v_x_242, 1ULL, 1);
      v_t_245 = heff_tag_at_n(v_ru_24x_242_24RepFix, TAG_FtFixed, 1, (V[]){v_w_244});
      break;
    }
    case TAG_RepF64: {
      v_t_245 = NTAG(TAG_FtFloat);
      break;
    }
    case TAG_RepInt: {
      v_t_245 = NTAG(TAG_FtOther);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_xs_243;
    V t_1 = v_cell_246;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1902028738x441242582_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1902028738x441242582_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s2135465121x1956745568_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2135465121x1956745568_entry, 1, 0};

V g_list_2eany_24s2135465121x1956745568(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      heff_take_n(v_t_243, 0ULL, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s2135465121x1956745568_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s2135465121x1956745568(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1880194630x798487332_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1880194630x798487332_entry, 2, 0};

V g_list_2efoldl_24s1880194630x798487332(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b(v_t_244, v_z_240));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1880194630x798487332_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1880194630x798487332(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s184951243x1948563855_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s184951243x1948563855_entry, 1, 0};

V g_list_2eany_24s184951243x1948563855(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = (g_heff_2ecompile_2eemit_2eloops(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s184951243x1948563855_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s184951243x1948563855(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1366476796x894764441_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1366476796x894764441_24dps_entry, 3, 0};

V g_list_2emap_24s1366476796x894764441_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_x_243, heff_dup(v_lit_240)), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1366476796x894764441_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1366476796x894764441_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s720989758x1967438448_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s720989758x1967438448_entry, 1, 0};

V g_list_2emap_24s720989758x1967438448(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 1, 2), heff_hole()});
    V v_u_244 = (g_list_2emap_24s720989758x1967438448_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s720989758x1967438448_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s720989758x1967438448(a[0]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str1, 10, "heff_drop(");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str2, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_str3, 2, ");");
Clo g_list_2emap_24s577269653x49010166_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_entry, 1, 0};

V g_list_2emap_24s577269653x49010166(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkDrop: {
      V v_x_243 = heff_field(v_x_241, 0);
      V v_x12_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      switch (heff_tag_of(v_x12_244)) {
      case TAG_Nothing: {
        V v_t_245 = ({ V a_0 = v_x_243; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s577269653x49010166_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_243); r_; });
        V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_str1), heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_str2), v_t_245));
        v_t_248 = heff_strAppend(v_t_246, ((V)&g_list_2emap_24s577269653x49010166_str3));
        break;
      }
      case TAG_Just: {
        V v_k_247 = heff_field(v_x12_244, 0);
        heff_take_n(v_x12_244, 1ULL, 1);
        v_t_248 = ({ V a_0 = v_x_243; V a_1 = v_k_247; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_243); heff_drop(v_k_247); r_; });
        break;
      }
      default: heff_nomatch(v_x12_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_list_2emap_24s577269653x49010166_24dps(v_xs_242, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166(a[0]);
}
Clo g_list_2emap_24s693155583x821663253_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s693155583x821663253_entry, 3, 0};

V g_list_2emap_24s693155583x821663253(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, heff_dup(v_lit_241)), heff_hole()});
    V v_u_247 = (g_list_2emap_24s693155583x821663253_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s693155583x821663253_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s693155583x821663253(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1218298322x1569510752_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1218298322x1569510752_24dps_entry, 3, 0};

V g_list_2emap_24s1218298322x1569510752_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1218298322x1569510752_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1218298322x1569510752_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1127556009x863725781_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1127556009x863725781_entry, 6, 0};

V g_list_2emap_24s1127556009x863725781(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    V v_t_2410;
    if (heff_strEq_c_lent(v_t_248, v_lit_242, 1)) {
      V v_t_249 = ({ V a_0 = v_x_246; V a_1 = v_lit_243; V a_2 = heff_dup(v_lit_244); V r_ = (g_heff_2ecompile_2eemitc_2eidentAt(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
      v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
    } else {
      heff_drop(v_x_246);
      v_t_2410 = NTAG(TAG_Nothing);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s1127556009x863725781_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_xs_247, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24s1127556009x863725781_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2emap_24s1127556009x863725781(a0, a1, a2, a3, a[4], a[5]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s2063245892x1543682505_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2063245892x1543682505_entry, 2, 0};

V g_list_2efoldl_24s2063245892x1543682505(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_prelude_2e_2b_2b_24f892794188x1384814865(v_z_240, v_x_242, heff_dup(g_heff_2esyntax_2eimport_2eimplicitImports_get())));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2063245892x1543682505_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2063245892x1543682505(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1230649048x711093514_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230649048x711093514_24dps_entry, 3, 0};

V g_list_2emap_24s1230649048x711093514_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_243}), heff_dup(v_lit_240)});
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s1230649048x711093514_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230649048x711093514_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s347605591x806617237_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s347605591x806617237_24dps_entry, 2, 0};

V g_list_2emap_24s347605591x806617237_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2eelab_2eprimitive_2eprimName(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s347605591x806617237_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s347605591x806617237_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s262223576x596329185_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s262223576x596329185_24dps_entry, 6, 0};

V g_list_2emap_24s262223576x596329185_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_box_24lit_243, V v_x2_244, V v_d_245) {
  int64_t v_lit_243 = heff_unbox_word(v_box_24lit_243);
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_a_248 = heff_strAppend(heff_dup(v_lit_240), heff_dup(v_lit_241));
    V v_t_249 = heff_strSlice(heff_dup(v_x_246), heff_dup(v_lit_242), heff_strLength_lent(v_a_248, 0));
    V v_t_2412;
    if (heff_strEq_c(v_t_249, v_a_248)) {
      int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_lit_240, 0)) + v_lit_243);
      V v_t_2411 = heff_strSlice(heff_dup(v_x_246), heff_box_word(v_t_2410), heff_strLength_lent(v_x_246, 0));
      v_t_2412 = heff_rec_n(2, shape_name__key, (V[]){v_t_2411, v_x_246});
    } else {
      v_t_2412 = heff_rec_n(2, shape_name__key, (V[]){heff_dup(v_x_246), v_x_246});
    }
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    int64_t t_3 = v_lit_243;
    V t_4 = v_xs_247;
    V t_5 = v_cell_2413;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_x2_244 = t_4;
    v_d_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24s262223576x596329185_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2emap_24s262223576x596329185_24dps(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
HEFF_LIT(g_list_2emap_24s864521685x1610969087_str0, 93, "a recursive call is checked against a type: give it one, `(f ... : T)` or `let x : T = f ...`");
HEFF_LIT(g_list_2emap_24s864521685x1610969087_str1, 115, "name the type: `type T = ...` at top level, or a type field of the struct it is in (`t = { ... }`, then `m.t` here)");
Clo g_list_2emap_24s864521685x1610969087_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_entry, 1, 0};

V g_list_2emap_24s864521685x1610969087(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_d_243 = v_x_241;
    V v_t_244 = heff_dup(heff_rfield(v_d_243, 4));
    V v_t_246;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_243, 0)), MK_INT(319LL))) {
        v_t_246 = ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s864521685x1610969087_str0)}); V rr_ = heff_rec_reuse_nf(v_d_243, 15ULL, 5, shape_code__severity__msg__span__note, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      } else {
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_243, 0)), MK_INT(204LL))) {
          v_t_246 = ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s864521685x1610969087_str1)}); V rr_ = heff_rec_reuse_nf(v_d_243, 15ULL, 5, shape_code__severity__msg__span__note, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        } else {
          v_t_246 = v_d_243;
        }
      }
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_246 = v_d_243;
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s864521685x1610969087_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087(a[0]);
}
HEFF_LIT(g_list_2emap_24s864521685x1610969087_24dps_str0, 93, "a recursive call is checked against a type: give it one, `(f ... : T)` or `let x : T = f ...`");
HEFF_LIT(g_list_2emap_24s864521685x1610969087_24dps_str1, 115, "name the type: `type T = ...` at top level, or a type field of the struct it is in (`t = { ... }`, then `m.t` here)");
Clo g_list_2emap_24s864521685x1610969087_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s864521685x1610969087_24dps_entry, 2, 0};

V g_list_2emap_24s864521685x1610969087_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_d_244 = v_x_242;
    V v_t_245 = heff_dup(heff_rfield(v_d_244, 4));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_Nothing: {
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_244, 0)), MK_INT(319LL))) {
        v_t_247 = ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s864521685x1610969087_24dps_str0)}); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_code__severity__msg__span__note, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      } else {
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_244, 0)), MK_INT(204LL))) {
          v_t_247 = ({ V rv_4 = heff_tag_n(TAG_Just, 1, (V[]){((V)&g_list_2emap_24s864521685x1610969087_24dps_str1)}); V rr_ = heff_rec_reuse_nf(v_d_244, 15ULL, 5, shape_code__severity__msg__span__note, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
        } else {
          v_t_247 = v_d_244;
        }
      }
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_245, 0ULL, 1);
      v_t_247 = v_d_244;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s864521685x1610969087_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s864521685x1610969087_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s328934344x1728860012_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s328934344x1728860012_24dps_entry, 3, 0};

V g_list_2emap_24s328934344x1728860012_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(heff_strAppend(v_t_245, heff_dup(v_lit_240)), heff_get_n(v_x_243, 2, 5));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_247;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s328934344x1728860012_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s328934344x1728860012_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1955261718x109443523_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1955261718x109443523_entry, 3, 0};

V g_list_2eany_24s1955261718x109443523(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    heff_drop(v_lit_241);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_lit_240, 1)), 0, 2);
    if ((heff_intLt_c_lent(v_t_245, v_x_243, 0) && heff_intLt_c_lent(v_x_243, v_lit_241, 0))) {
      heff_drop_rec(v_lit_240, 2);
      heff_drop(v_lit_241);
      heff_drop(v_t_245);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s1955261718x109443523_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2eany_24s1955261718x109443523(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emap_24s1895313378x47656836_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1895313378x47656836_24dps_entry, 2, 0};

V g_list_2emap_24s1895313378x47656836_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2eoutcomeOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1895313378x47656836_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1895313378x47656836_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1662685276x243749136_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1662685276x243749136_entry, 2, 0};

V g_list_2eany_24s1662685276x243749136(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_name_244 = heff_dup(heff_rfield(v_x_242, 0));
    V v_tags_245 = heff_dup(heff_rfield(v_x_242, 1));
    if (heff_strEq_c_lent(v_name_244, v_lit_240, 1)) {
      if ((heff_dup(v_tags_245) == NTAG(TAG_True))) {
        heff_drop(v_tags_245);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_tags_245);
        V t_0 = v_lit_240;
        V t_1 = v_xs_243;
        v_lit_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    } else {
      heff_drop(v_tags_245);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1662685276x243749136_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1662685276x243749136(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2emap_24s2098427539x1767581560_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2098427539x1767581560_24dps_entry, 5, 0};

V g_list_2emap_24s2098427539x1767581560_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_path_247 = heff_take_field(v_x_245, 0);
    V v_version_248 = heff_take_field(v_x_245, 1);
    V v_hash_249 = heff_get_n(v_x_245, 2, 3);
    V v_t_2410 = heff_strAppend(heff_strAppend(v_path_247, heff_dup(v_lit_240)), v_version_248);
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, heff_dup(v_lit_241)), v_hash_249);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2411, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2413 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_xs_246;
    V t_4 = v_cell_2412;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_x2_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2098427539x1767581560_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2098427539x1767581560_24dps(a[0], a[1], a[2], a[3], a[4]);
}

HeffT2 g_list_2efind_24s764539875x1185200879_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_a_244 = heff_dup(heff_rfield(v_x_242, 2));
    V v_start_245 = heff_take_field(v_a_244, 0);
    V v_end_246 = heff_get_n(v_a_244, 1, 2);
    if ((heff_intLe_c_lent(v_start_245, v_lit_240, 0) && heff_intLe_c_lent(v_lit_240, v_end_246, 0))) {
      heff_drop(v_lit_240);
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      heff_drop(v_start_245);
      heff_drop(v_end_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1777318809x1106245647_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1777318809x1106245647_entry, 2, 0};

V g_list_2efoldl_24s1777318809x1106245647(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        V v_t_2410 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_248));
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_t_2412 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_a_2411 = heff_field(v_a_249, 0);
          v_t_2412 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2411));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2414 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2412));
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2413));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415 = (g_prelude_2e_2b_2b(v_t_2414, v_z_240));
    V t_0 = v_t_2415;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1777318809x1106245647(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2edescending_24s1679501129x89119467_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s1679501129x89119467_entry, 3, 0};

V g_list_2edescending_24s1679501129x89119467(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 5);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_x_240, 2, 5), 0, 2);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_y_243, 2)), 0, 2);
    if (heff_intLe_c(v_t_245, v_t_246)) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_ys_244})});
    } else {
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s1679501129x89119467_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s1679501129x89119467(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str0, 7, "integer");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str1, 6, "binary");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str2, 4, "bits");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str3, 5, "float");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str4, 3, "utf");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str5, 7, "default");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str6, 1, "*");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str7, 4, "true");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str8, 5, "false");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str9, 4, "true");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str10, 5, "false");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str11, 1, " ");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str12, 0, "");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str13, 0, "");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str14, 8, "(segment");
HEFF_LIT(g_list_2emap_24s2016443462x370533815_str15, 1, ")");
Clo g_list_2emap_24s2016443462x370533815_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016443462x370533815_entry, 1, 0};

V g_list_2emap_24s2016443462x370533815(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = v_x_241;
    V v_t_2428;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_At: {
      V v_x21_244 = heff_field(v_x2_243, 0);
      V v_ru_24x2_243_24At = heff_take_reuse_n(v_x2_243, 1ULL, 2);
      switch (heff_tag_of(v_x21_244)) {
      case TAG_MkSegment: {
        V v_v_246 = heff_field(v_x21_244, 0);
        V v_ty_247 = heff_field(v_x21_244, 1);
        V v_size_248 = heff_field(v_x21_244, 2);
        V v_little_249 = heff_field(v_x21_244, 3);
        V v_signed_2410 = heff_field(v_x21_244, 4);
        heff_take_n(v_x21_244, 31ULL, 5);
        V v_t_2411 = (g_heff_2esyntax_2eformat_2epatKey(v_v_246));
        V v_t_2413;
        switch (heff_tag_of(v_ty_247)) {
        case TAG_SegmentInteger: {
          v_t_2413 = ((V)&g_list_2emap_24s2016443462x370533815_str0);
          break;
        }
        case TAG_SegmentBinary: {
          v_t_2413 = ((V)&g_list_2emap_24s2016443462x370533815_str1);
          break;
        }
        case TAG_SegmentBits: {
          v_t_2413 = ((V)&g_list_2emap_24s2016443462x370533815_str2);
          break;
        }
        case TAG_SegmentFloat: {
          v_t_2413 = ((V)&g_list_2emap_24s2016443462x370533815_str3);
          break;
        }
        case TAG_SegmentUtf: {
          V v_n_2412 = heff_field(v_ty_247, 0);
          heff_take_n(v_ty_247, 1ULL, 1);
          v_t_2413 = heff_strAppend(((V)&g_list_2emap_24s2016443462x370533815_str4), heff_intShow(v_n_2412));
          break;
        }
        default: heff_nomatch(v_ty_247);
        }
        V v_t_2418;
        switch (heff_tag_of(v_size_248)) {
        case TAG_SizeDefault: {
          v_t_2418 = ((V)&g_list_2emap_24s2016443462x370533815_str5);
          break;
        }
        case TAG_SizeNumber: {
          V v_n_2414 = heff_field(v_size_248, 0);
          heff_take_n(v_size_248, 1ULL, 1);
          v_t_2418 = heff_intShow(v_n_2414);
          break;
        }
        case TAG_SizeName: {
          V v_x_2415 = heff_field(v_size_248, 0);
          V v_unit_2417 = heff_field(v_size_248, 2);
          heff_take_n(v_size_248, 5ULL, 3);
          v_t_2418 = heff_strAppend(heff_strAppend(v_x_2415, ((V)&g_list_2emap_24s2016443462x370533815_str6)), heff_intShow(v_unit_2417));
          break;
        }
        default: heff_nomatch(v_size_248);
        }
        V v_t_2419;
        if ((heff_dup(v_little_249) == NTAG(TAG_True))) {
          heff_drop(v_little_249);
          v_t_2419 = ((V)&g_list_2emap_24s2016443462x370533815_str7);
        } else {
          heff_drop(v_little_249);
          v_t_2419 = ((V)&g_list_2emap_24s2016443462x370533815_str8);
        }
        V v_t_2420;
        if ((heff_dup(v_signed_2410) == NTAG(TAG_True))) {
          heff_drop(v_signed_2410);
          v_t_2420 = ((V)&g_list_2emap_24s2016443462x370533815_str9);
        } else {
          heff_drop(v_signed_2410);
          v_t_2420 = ((V)&g_list_2emap_24s2016443462x370533815_str10);
        }
        V v_t_2421 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
        V v_t_2422 = heff_tag_at_n(v_ru_24x2_243_24At, TAG_Cons, 2, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
        V v_parts_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2422})});
        V v_x2_2424 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s2016443462x370533815_str11), v_parts_2423));
        V v_t_2427;
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_Nil: {
          v_t_2427 = ((V)&g_list_2emap_24s2016443462x370533815_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_xs_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          v_t_2427 = ({ V a_0 = ((V)&g_list_2emap_24s2016443462x370533815_str13); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2424);
        }
        v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s2016443462x370533815_str14), v_t_2427), ((V)&g_list_2emap_24s2016443462x370533815_str15));
        break;
      }
      default: heff_nomatch(v_x21_244);
      }
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_cell_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
    V v_u_2430 = (g_list_2emap_24s2016443462x370533815_24dps(v_xs_242, heff_dup(v_cell_2429)));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2016443462x370533815_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016443462x370533815(a[0]);
}
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str0, 1, " ");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str1, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str2, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str3, 9, "(explicit");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str4, 1, ")");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str5, 1, " ");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str6, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str7, 0, "");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str8, 9, "(implicit");
HEFF_LIT(g_list_2emap_24s228910449x1110031924_str9, 1, ")");
Clo g_list_2emap_24s228910449x1110031924_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s228910449x1110031924_entry, 2, 0};

V g_list_2emap_24s228910449x1110031924(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_r_244 = heff_dup(v_lit_240);
    V v_x2_245 = v_x_242;
    V v_t_2428;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_At: {
      V v_x21_246 = heff_field(v_x2_245, 0);
      V v_ru_24x2_245_24At = heff_take_reuse_n(v_x2_245, 1ULL, 2);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_ExplicitParam: {
        V v_x_248 = heff_field(v_x21_246, 0);
        V v_t_2410 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 5ULL, 3);
        V v_t_2411 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_t_2410}));
        V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
        V v_parts_2413 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_x_248, v_t_2412});
        V v_x2_2414 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s228910449x1110031924_str0), v_parts_2413));
        V v_t_2417;
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_Nil: {
          v_t_2417 = ((V)&g_list_2emap_24s228910449x1110031924_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_xs_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          v_t_2417 = ({ V a_0 = ((V)&g_list_2emap_24s228910449x1110031924_str2); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2414);
        }
        v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s228910449x1110031924_str3), v_t_2417), ((V)&g_list_2emap_24s228910449x1110031924_str4));
        break;
      }
      case TAG_ImplicitParam: {
        V v_x_2418 = heff_field(v_x21_246, 0);
        V v_t_2420 = heff_field(v_x21_246, 2);
        heff_take_n(v_x21_246, 5ULL, 3);
        V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_244, 0, 2), 1, (V[]){v_t_2420}));
        V v_t_2422 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
        V v_parts_2423 = heff_tag_at_n(v_ru_24x2_245_24At, TAG_Cons, 2, (V[]){v_x_2418, v_t_2422});
        V v_x2_2424 = (g_list_2emap_24s231073986x752637537(((V)&g_list_2emap_24s228910449x1110031924_str5), v_parts_2423));
        V v_t_2427;
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_Nil: {
          v_t_2427 = ((V)&g_list_2emap_24s228910449x1110031924_str6);
          break;
        }
        case TAG_Cons: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_xs_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          v_t_2427 = ({ V a_0 = ((V)&g_list_2emap_24s228910449x1110031924_str7); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2424);
        }
        v_t_2428 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s228910449x1110031924_str8), v_t_2427), ((V)&g_list_2emap_24s228910449x1110031924_str9));
        break;
      }
      default: heff_nomatch(v_x21_246);
      }
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_cell_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
    V v_u_2430 = (g_list_2emap_24s228910449x1110031924_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2429)));
    heff_drop(v_u_2430);
    return v_cell_2429;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s228910449x1110031924_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s228910449x1110031924(a[0], a[1]);
}
Clo g_list_2emap_24s1435185561x202019164_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1435185561x202019164_entry, 1, 0};

V g_list_2emap_24s1435185561x202019164(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eemitc_2eglueProvider(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1435185561x202019164_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1435185561x202019164(a[0]);
}
Clo g_list_2eall_24s2093734251x1702493483_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s2093734251x1702493483_entry, 4, 0};

V g_list_2eall_24s2093734251x1702493483(V v_box_24lit_240, V v_lit_241, V v_box_24lit_242, V v_x2_243) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
  int64_t v_lit_242 = heff_unbox_word(v_box_24lit_242);
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (((v_lit_240 <= heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_x_244, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_lit_241, v_x_244, 0)) <= v_lit_242))) {
      int64_t t_0 = v_lit_240;
      V t_1 = v_lit_241;
      int64_t t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_list_2eall_24s2093734251x1702493483(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2epushRun_24s368060031x1022896115_clo = {{0x80000000u, K_CLO, 0}, g_list_2epushRun_24s368060031x1022896115_entry, 3, 0};

V g_list_2epushRun_24s368060031x1022896115(V v_k_240, V v_run_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkPair: {
      V v_j_245 = heff_field(v_x41_243, 0);
      V v_below_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24MkPair = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      if (heff_intEq_c_lent(v_j_245, v_k_240, 0)) {
        heff_drop_cell(v_ru_24x4_242_24Cons, 2);
        heff_drop(v_j_245);
        heff_drop_cell(v_ru_24x41_243_24MkPair, 2);
        V v_t_247 = (g_list_2emerge_24s275559350x890699445(v_below_246, v_run_241));
        V t_0 = heff_intAdd(v_k_240, MK_INT(1LL));
        V t_1 = v_t_247;
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_run_241 = t_1;
        v_x4_242 = t_2;
        goto top;
      } else {
        V v_t_248 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x41_243_24MkPair, TAG_MkPair, 2, (V[]){v_j_245, v_below_246}), v_rest_244});
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_240, v_run_241}), v_t_248});
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2epushRun_24s368060031x1022896115_entry(V self, V *a) {
  (void)self;
  return g_list_2epushRun_24s368060031x1022896115(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s831190316x576961335_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s831190316x576961335_entry, 1, 0};

V g_list_2emap_24s831190316x576961335(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s831190316x576961335_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s831190316x576961335_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s831190316x576961335(a[0]);
}
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str1, 3, "[--");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str2, 1, "]");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str3, 2, "--");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str4, 1, "=");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str5, 3, "[--");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str6, 1, " ");
HEFF_LIT(g_list_2emap_24s1281445768x1036802655_24dps_str7, 1, "]");
Clo g_list_2emap_24s1281445768x1036802655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1281445768x1036802655_24dps_entry, 2, 0};

V g_list_2emap_24s1281445768x1036802655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_f_244 = v_x_242;
    V v_meta_245 = heff_take_field(v_f_244, 2);
    V v_long_246 = heff_take_field(v_f_244, 0);
    V v_required_247 = heff_get_n(v_f_244, 6, 8);
    V v_t_2410;
    if (heff_strEq_c_lent(v_meta_245, ((V)&g_list_2emap_24s1281445768x1036802655_24dps_str0), 2)) {
      heff_drop(v_meta_245);
      heff_drop(v_required_247);
      v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1281445768x1036802655_24dps_str1), v_long_246), ((V)&g_list_2emap_24s1281445768x1036802655_24dps_str2));
    } else {
      if ((heff_dup(v_required_247) == NTAG(TAG_True))) {
        heff_drop(v_required_247);
        V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1281445768x1036802655_24dps_str3), v_long_246), ((V)&g_list_2emap_24s1281445768x1036802655_24dps_str4));
        v_t_2410 = heff_strAppend(v_t_248, v_meta_245);
      } else {
        heff_drop(v_required_247);
        V v_t_249 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1281445768x1036802655_24dps_str5), v_long_246), ((V)&g_list_2emap_24s1281445768x1036802655_24dps_str6));
        v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, v_meta_245), ((V)&g_list_2emap_24s1281445768x1036802655_24dps_str7));
      }
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1281445768x1036802655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1281445768x1036802655_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str1, 4, "    ");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str2, 1, "-");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str3, 2, ", ");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str4, 2, "--");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str7, 1, "=");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str10, 2, ", ");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str11, 2, " (");
HEFF_LIT(g_list_2emap_24s1753874608x910016727_24dps_str12, 1, ")");
Clo g_list_2emap_24s1753874608x910016727_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1753874608x910016727_24dps_entry, 2, 0};

V g_list_2emap_24s1753874608x910016727_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_f_244 = v_x_242;
    V v_short_245 = heff_take_field(v_f_244, 1);
    V v_long_246 = heff_take_field(v_f_244, 0);
    V v_meta_247 = heff_take_field(v_f_244, 2);
    V v_doc_248 = heff_take_field(v_f_244, 3);
    V v_values_249 = heff_get_n(v_f_244, 4, 8);
    V v_t_2410;
    if (heff_strEq_c_lent(v_short_245, ((V)&g_list_2emap_24s1753874608x910016727_24dps_str0), 2)) {
      heff_drop(v_short_245);
      v_t_2410 = ((V)&g_list_2emap_24s1753874608x910016727_24dps_str1);
    } else {
      v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1753874608x910016727_24dps_str2), v_short_245), ((V)&g_list_2emap_24s1753874608x910016727_24dps_str3));
    }
    V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_list_2emap_24s1753874608x910016727_24dps_str4)), v_long_246);
    V v_t_2412;
    if (heff_strEq_c_lent(v_meta_247, ((V)&g_list_2emap_24s1753874608x910016727_24dps_str5), 2)) {
      heff_drop(v_meta_247);
      v_t_2412 = ((V)&g_list_2emap_24s1753874608x910016727_24dps_str6);
    } else {
      v_t_2412 = heff_strAppend(((V)&g_list_2emap_24s1753874608x910016727_24dps_str7), v_meta_247);
    }
    V v_t_2418;
    switch (heff_tag_of(v_values_249)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_list_2emap_24s1753874608x910016727_24dps_str8);
      break;
    }
    case TAG_Cons: {
      V v_t_2417;
      switch (heff_tag_of(v_values_249)) {
      case TAG_Nil: {
        v_t_2417 = ((V)&g_list_2emap_24s1753874608x910016727_24dps_str9);
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_values_249, 0);
        V v_xs_2416 = heff_field(v_values_249, 1);
        heff_take_n(v_values_249, 3ULL, 2);
        v_t_2417 = ({ V a_0 = ((V)&g_list_2emap_24s1753874608x910016727_24dps_str10); V a_1 = v_x_2415; V a_2 = v_xs_2416; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2416); r_; });
        break;
      }
      default: heff_nomatch(v_values_249);
      }
      v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s1753874608x910016727_24dps_str11), v_t_2417), ((V)&g_list_2emap_24s1753874608x910016727_24dps_str12));
      break;
    }
    default: heff_nomatch(v_values_249);
    }
    V v_t_2419 = (g_std_2ecli_2eline2(heff_strAppend(v_t_2411, v_t_2412), heff_strAppend(v_doc_248, v_t_2418)));
    V v_cell_2420 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2419, heff_hole()});
    V v_u_2421 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2420));
    heff_drop(v_u_2421);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2420;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1753874608x910016727_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1753874608x910016727_24dps(a[0], a[1]);
}
Clo g_list_2emap_24f719546030x1732151491_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f719546030x1732151491_24dps_entry, 3, 0};

V g_list_2emap_24f719546030x1732151491_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_tighter_245 = heff_take_field(v_x_243, 0);
    V v_looser_246 = heff_get_n(v_x_243, 1, 2);
    if (heff_strEq_c_lent(v_tighter_245, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_looser_246, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_looser_246);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f719546030x1732151491_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f719546030x1732151491_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f1512150482x179770396_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1512150482x179770396_24dps_entry, 5, 0};

V g_list_2emap_24f1512150482x179770396_24dps(V v_lit_240, V v_lit_241, V v_a_242, V v_b_243, V v_d_244) {
top: ;
  if (heff_intLt_c_lent(v_b_243, v_a_242, 0)) {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_t_245 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(heff_dup(v_a_242)));
    V v_cell_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, heff_dup(v_lit_241)), heff_hole()});
    V v_u_247 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
    V t_3 = v_b_243;
    V t_4 = v_cell_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    v_d_244 = t_4;
    goto top;
  }
}
V g_list_2emap_24f1512150482x179770396_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1512150482x179770396_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f409057300x985797598_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f409057300x985797598_entry, 2, 0};

V g_list_2efoldl_24f409057300x985797598(V v_z_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 2, 3);
    V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efoldl_24f409057300x985797598_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f409057300x985797598(a[0], a[1]);
}
Clo g_list_2efoldl_24f450671696x846133639_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f450671696x846133639_entry, 5, 0};

V g_list_2efoldl_24f450671696x846133639(V v_lit_240, V v_lit_241, V v_z_242, V v_x1_243, V v_ys_244) {
top: ;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s871632021x1241775640(v_lit_240, v_lit_241, v_z_242, v_ys_244));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_243, 0);
    V v_xs_246 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24Cons = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){heff_dup(v_lit_240)}), heff_dup(v_lit_241)});
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_z_242}), heff_dup(v_lit_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgExplicit, 1, (V[]){v_x_245}), heff_dup(v_lit_241)});
    V v_t_2410 = heff_tag_at_n(v_ru_24x1_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_IApp, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_lit_241)})});
    V t_0 = v_lit_240;
    V t_1 = heff_dup(v_lit_241);
    V t_2 = heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_lit_241});
    V t_3 = v_xs_246;
    V t_4 = v_ys_244;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x1_243 = t_3;
    v_ys_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_list_2efoldl_24f450671696x846133639_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f450671696x846133639(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f1443542135x1147816397_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1443542135x1147816397_entry, 4, 0};

V g_list_2efoldl_24f1443542135x1147816397(V v_z_240, V v_f_241, V v_x2_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x3_243)) {
    case TAG_Nil: {
      heff_drop(v_f_241);
      return v_z_240;
    }
    case TAG_Cons: {
      V v_y_246 = heff_field(v_x3_243, 0);
      V v_ys_247 = heff_field(v_x3_243, 1);
      V v_x_248 = heff_tr(heff_call(heff_dup(v_f_241), 2, (V[]){heff_dup(v_x_244), heff_dup(v_y_246)}));
      V v_t_249 = (g_std_2edoc_2e_3c_3e(v_z_240, v_x_248));
      V t_0 = v_t_249;
      V t_1 = v_f_241;
      V t_2 = v_xs_245;
      V t_3 = v_ys_247;
      v_z_240 = t_0;
      v_f_241 = t_1;
      v_x2_242 = t_2;
      v_x3_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x3_243);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1443542135x1147816397_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f1443542135x1147816397(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24f1368804635x922296653_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1368804635x922296653_entry, 2, 0};

V g_list_2ekeepIf_24f1368804635x922296653(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x_244 = heff_get_n(v_x_242, 1, 8);
    if (!heff_strEq_c_lent(v_x_244, v_lit_240, 0)) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_list_2ekeepIf_24f1368804635x922296653_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_x_244);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24f1368804635x922296653_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24f1368804635x922296653(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24f1763211578x1610911617_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1763211578x1610911617_entry, 6, 0};

V g_list_2efoldl_24f1763211578x1610911617(V v_lit_240, V v_z_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_242);
    heff_drop_rec(v_lit_243, 6);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_lit_243, 2)), 0, 2);
    V v_t_249 = heff_strFind(heff_strOfRunes(v_t_248), heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_244));
    if (heff_intLe_c_lent(v_lit_242, v_t_249, 2)) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2efoldl_24f1763211578x1610911617_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a5 = a[5]; V r = g_list_2efoldl_24f1763211578x1610911617(a[0], a[1], a[2], a[3], a4, a5); heff_drop(a4); heff_drop(a5); return r;
}