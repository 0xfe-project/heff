// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_args 9498020
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_command 1182252425
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failure 1292767177
#define LBL_files 298792593
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_lib 316671
#define LBL_mod 317820
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_shipTo 1043811586
#define LBL_skipped 231818613
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_unchecked 1931098040
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352_clo;
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688(V, V, V);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128_clo;
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589_clo;
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261(V, V);
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736(V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777_clo;
V g_heff_2ebuild_2ecommands_2eranLine(V);
V g_heff_2ebuild_2ecommands_2eranLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranLine_clo;
V g_heff_2ebuild_2ecommands_2ereaches(V, V);
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereaches_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130(V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130_clo;
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s148011877x1447840770(V, V, V, V);
V g_list_2efoldl_24s148011877x1447840770_entry(V self, V *a);
extern Clo g_list_2efoldl_24s148011877x1447840770_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s631322900x900609068(V);
V g_list_2emap_24s631322900x900609068_entry(V self, V *a);
extern Clo g_list_2emap_24s631322900x900609068_clo;
V g_list_2emap_24s763976875x1978337183(V);
V g_list_2emap_24s763976875x1978337183_entry(V self, V *a);
extern Clo g_list_2emap_24s763976875x1978337183_clo;
V g_list_2esortBy_24s735547525x1777295590(V);
V g_list_2esortBy_24s735547525x1777295590_entry(V self, V *a);
extern Clo g_list_2esortBy_24s735547525x1777295590_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2erun_24s350272650x457371011(V, V, V, V, V);
V g_std_2eprocess_2erun_24s350272650x457371011_entry(V self, V *a);
extern Clo g_std_2eprocess_2erun_24s350272650x457371011_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereaches_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereaches_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2ereaches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereaches_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereaches(V v_sel_240, V v_o_241) {
top: ;
  V v_s_242 = heff_get_n(v_o_241, 0, 12);
  V v_xs_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ereaches_str0); V a_1 = v_s_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2ereaches_str1), v_s_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_242); r_; });
  V v_x_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_y_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sel_240));
  return heff_intLe(v_y_245, v_x_244);
}
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereaches(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str2, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str3, 27, " files check as they should");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str5, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efilesSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efilesSaid(V v_r_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_240, 4)));
  V v_t_242 = heff_intSub(heff_dup(heff_rfield(v_r_240, 0)), v_t_241);
  V v_t_243 = heff_intShow(heff_take_field(v_r_240, 0));
  V v_t_246;
  if (heff_intEq_c(heff_dup(heff_rfield(v_r_240, 1)), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 8);
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str0);
  } else {
    V v_t_245 = heff_intShow(heff_get_n(v_r_240, 1, 8));
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str2)));
  }
  V v_t_247 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str3), v_t_246));
  V v_t_248 = heff_strAppend(heff_intShow(v_t_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str4), v_t_247));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str5), v_t_248);
}
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efilesSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s495635622x733177935(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  return v_s_2411;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2419; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2422;
  if (heff_strEq_c(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_str0))) {
    v_t_2422 = NTAG(TAG_Windows);
  } else {
    v_t_2422 = NTAG(TAG_Posix);
  }
  V v_x_2423 = ({ V a_0 = v_t_2422; V a_1 = v_x_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_x_2420); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s495635622x733177935(v_t_2418, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581_lam3, 1, 2, (V[]){v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s559925334x1144852132(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam3(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam7(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam9(V self, V *args) {
  V v_t_2440 = args[0];
  return v_t_2440;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam10(V self, V *args) {
  V v_x_2448 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2449 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, v_x_2416));
  V v_t_2450 = ({ V a_0 = v_x_2433; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2433); r_; });
  V v_t_2451 = ({ V a_0 = v_x_2448; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2448); r_; });
  V v_t_2452 = (g_prelude_2e_2b_2b(v_t_2450, v_t_2451));
  V v_x_2453 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_244, v_st_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2452})});
  V f_ = v_k_241;
  args[0] = v_x_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_244 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2434 = (g_std_2epath_2eparse(v_st_2415, v_x_2417));
  V v_t_2435 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_str2)));
  V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
  V v_s_2437 = ({ V a_0 = v_st_2415; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2436); r_; });
  V v_path_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2437; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2439 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2438; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2438); r_; });
  V v_a_2441 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2439, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam9_clo)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s495635622x733177935(v_t_2447, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam10, 1, 7, (V[]){v_st_2415, v_x_2416, v_x_2433, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam6(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2418 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2415, heff_dup(v_x_2416)));
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2415, v_home_2418));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_str1)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2415; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam7_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(v_t_2432, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam8, 1, 8, (V[]){v_st_2415, v_x_2417, v_hd_240, v_x_2416, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2415 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam6, 1, 7, (V[]){v_st_2415, v_x_2416, v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam4(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s520132541x569116581(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam5, 1, 6, (V[]){v_hd_240, v_st_2415, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam2(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam3_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam4, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_244, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s1742865769x1491503352(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam2, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s109208816x923471983(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam2(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam3(V self, V *args) {
  V v_ok_2427 = args[0];
  return v_ok_2427;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2436);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2417;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_t_2418 = (g_list_2eany_24s1230506745x754542351(v_n_245, v_parts_241));
  V v_c_2435;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_n_245);
    heff_drop(v_st_2417);
    heff_drop(v_t_2418);
    v_c_2435 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam2_clo);
  } else {
    heff_drop(v_t_2418);
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2417, heff_dup(v_dir_240)));
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2417, v_n_245));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    V v_s_2424 = ({ V a_0 = v_st_2417; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2417); heff_drop(v_t_2423); r_; });
    V v_path_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2424; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2425; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2425); r_; });
    V v_a_2428 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam3_clo)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    v_c_2435 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2434}));
  }
  V f_ = v_c_2435;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s618597644x2090969687_lam4, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam2, 1, 0};
Clo g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159(V v_path_240, V v_text_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_path_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
    V v_a_246 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_244, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam0_clo)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2412});
  }
  case TAG_Just: {
    V v_was_2413 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    if (heff_strEq_c_lent(v_was_2413, v_text_241, 1)) {
      heff_drop(v_path_240);
      heff_drop(v_text_241);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      return ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam1_clo);
    } else {
      V v_path_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_240; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2418 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2417; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2417); r_; });
      V v_a_2420 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2418, v_text_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam2_clo)});
      V v_t_2421 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2426});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159_lam2(V self, V *args) {
  V v_ok_2419 = args[0];
  return v_ok_2419;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam1, 1, 6, (V[]){v_dir_240, v_name_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam2(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam4(V self, V *args) {
  V v_x_2439 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258(v_dir_240, v_rest_245, v_p_242, v_p_243));
  } else {
    heff_drop(v_x_2439);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2434 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2435 = (g_std_2epath_2eparse(v_st_2418, v_name_246));
  V v_t_2436 = (g_std_2epath_2ejoin(v_t_2434, v_t_2435));
  V v_t_2437 = ({ V a_0 = v_st_2418; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2436); r_; });
  V v_c_2438 = heff_tr(g_heff_2ebuild_2ecommands_2ewriteChanged_24s309070049x676314159(v_t_2437, v_text_247, v_x_2433));
  V f_ = v_c_2438;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam4, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_name_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
  V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam2_clo)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(v_t_2432, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1794163889x54194258_lam3, 1, 7, (V[]){v_st_2418, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619(V v_outPath_240, V v_zig_241, V v_done_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
  V v_t_247 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_246), heff_strLength_lent(v_outPath_240, 0));
  V v_t_2410;
  if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str0))) {
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    v_t_2410 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_249), 6);
  } else {
    v_t_2410 = heff_dup(v_outPath_240);
  }
  V v_path_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2411; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2411); r_; });
  V v_a_2414 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2412, v_zig_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam0_clo)});
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(heff_dup(v_outPath_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam1, 2, 3, (V[]){v_a_2414, v_done_242, v_outPath_240}), v_o_243, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam0(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2423) == NTAG(TAG_True))) {
    heff_drop(v_x_2423);
    heff_drop(v_outPath_240);
    V f_ = v_done_242;
    heff_room[0] = v_hd_2415;
    heff_room[1] = v_k_2416;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2423);
    heff_drop(v_done_242);
    int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_2425 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_2424), heff_strLength_lent(v_outPath_240, 0));
    V v_t_2428;
    if (heff_strEq_c(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str2))) {
      int64_t v_t_2427 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_2428 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2427));
    } else {
      v_t_2428 = v_outPath_240;
    }
    V v_t_2429 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str3), heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str4)));
    V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_str5)), NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam3, 1, 2, (V[]){v_hd_2415, v_k_2416})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_a_2414 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  V v_outPath_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(v_t_2422, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_lam2, 1, 4, (V[]){v_done_242, v_hd_2415, v_k_2416, v_outPath_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str0, 3, "  (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str1, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str2, 8, "  skip  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str4, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_o_244, 2));
    V v_str_2410;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_str_2410 = (g_heff_2ebuild_2ecommands_2eranLine(heff_dup(v_o_244)));
      break;
    }
    case TAG_Just: {
      V v_why_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str0), heff_strAppend(v_why_247, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str1)));
      V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_o_244, 0)), v_t_248);
      v_str_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str2), v_t_249);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam1, 2, 4, (V[]){v_str_2410, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2440);
  V v_t_2441 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588(a_0, a_1)); heff_drop(v_color_240); r_; });
  V f_ = v_t_2441;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_take_field(v_o_244, 1);
  V v_c_2439;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_244, 12);
    heff_drop(v_t_2421);
    v_c_2439 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam3_clo);
  } else {
    heff_drop(v_t_2421);
    V v_t_2424 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str4), heff_take_field(v_o_244, 8)));
    V v_t_2425 = heff_get_n(v_o_244, 9, 12);
    V v_t_2427;
    switch (heff_tag_of(v_t_2425)) {
    case TAG_Nothing: {
      v_t_2427 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2426 = heff_field(v_t_2425, 0);
      heff_take_n(v_t_2425, 1ULL, 1);
      v_t_2427 = (g_heff_2ebuild_2ecommands_2efailLines(v_color_240, v_f_2426));
      break;
    }
    default: heff_nomatch(v_t_2425);
    }
    V v_x2_2428 = (g_prelude_2e_2b_2b(v_t_2424, v_t_2427));
    V v_str_2431;
    switch (heff_tag_of(v_x2_2428)) {
    case TAG_Nil: {
      v_str_2431 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2429 = heff_field(v_x2_2428, 0);
      V v_xs_2430 = heff_field(v_x2_2428, 1);
      heff_take_n(v_x2_2428, 3ULL, 2);
      v_str_2431 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str6); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2428);
    }
    V v_t_2432 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2431, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str7)), NTAG(TAG_MkUnit)});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    v_c_2439 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
  }
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam4, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_str_2410 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2410, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_str3)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s1976116984x1161598588_lam2, 1, 5, (V[]){v_o_244, v_color_240, v_hd_2411, v_rest_245, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam5, 2, 0};
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688(V v_rep_240, V v_x1_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    V v_x_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam0, 2, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_f_246 = heff_field(v_x1_241, 0);
    V v_rest_247 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_c_248 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(v_f_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam1, 2, 4, (V[]){v_c_248, v_rep_240, v_acc_242, v_rest_247});
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_x_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam5(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_cs_2415 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_hd_249 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2420);
  V v_t_2429;
  if (heff_intLt_c(MK_INT(0LL), v_x_2412)) {
    V v_found_2422 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_2415));
    heff_drop(v_found_2422);
    v_t_2429 = v_acc_242;
  } else {
    V v_bad_2423 = (g_list_2eany_24s469495312x865582084(v_cs_2415));
    HeffT2 v_t_2424 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2415));
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      if ((heff_dup(v_bad_2423) == NTAG(TAG_True))) {
        heff_drop(v_bad_2423);
        heff_drop(v_field_2426);
        v_t_2429 = v_acc_242;
      } else {
        heff_drop(v_bad_2423);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_c_2428 = v_field_2426;
          v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_c_2428, v_acc_242});
        } else {
          heff_drop(v_field_2426);
          v_t_2429 = v_acc_242;
        }
      }
    }
  }
  V v_t_2430 = (g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688(v_rep_240, v_rest_247, v_t_2429));
  V f_ = v_t_2430;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_cs_2415 = heff_get_n(v_x_2414, 0, 2);
  V v_t_2416 = (g_list_2eany_24s469495312x865582084(v_cs_2415));
  V v_c_2419;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    v_c_2419 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(heff_dup(v_rep_240), heff_dup(v_cs_2415)));
  } else {
    heff_drop(v_t_2416);
    v_c_2419 = ((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam5_clo);
  }
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam6, 1, 7, (V[]){v_x_2412, v_cs_2415, v_acc_242, v_rep_240, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2413 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(v_x_2411));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam4, 1, 6, (V[]){v_rep_240, v_hd_249, v_x_2412, v_acc_242, v_rest_247, v_k_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_str0), heff_dup(heff_rfield(v_x_2411, 1)), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam3, 1, 6, (V[]){v_x_2411, v_hd_249, v_rep_240, v_acc_242, v_rest_247, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2edocChecked_24s632768197x610431688_lam2, 1, 5, (V[]){v_hd_249, v_rep_240, v_acc_242, v_rest_247, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str3, 8, "index.md");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str6, 46, "---\012title: API\012sidebar:\012  label: Modules\012---\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str7, 81, "The modules, each a page: what it exposes, with its type and its documentation.\012\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str8, 27, " pages and their index, in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str9, 10, "heff doc: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261(V v_x1_240, V v_cs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    V v_x2_242 = (g_list_2emap_24s763976875x1978337183(v_cs_241));
    V v_str_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_str_245 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_str_245 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str1); V a_1 = v_x_243; V a_2 = v_xs_244; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_t_246 = heff_tag_n(TAG_Write, 2, (V[]){v_str_245, NTAG(TAG_MkUnit)});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  }
  case TAG_Just: {
    V v_dir_2413 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam0, 2, 2, (V[]){v_dir_2413, v_cs_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam1(V self, V *args) {
  V v_s_2416 = args[0];
  return v_s_2416;
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dir_2413 = heff_env(self)[1];
  V v_hd_2414 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2438);
  V v_t_2439 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_cs_241; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_cs_241); r_; });
  V v_t_2440 = heff_strAppend(heff_intShow(v_t_2439), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str8), v_dir_2413));
  V v_str_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str9), v_t_2440);
  V v_t_2442 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2441, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str10)), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_2414, v_k_2415));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_2426 = heff_env(self)[0];
  V v_dir_2413 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_hd_2414 = heff_env(self)[3];
  V v_k_2415 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  V v_t_2428 = (g_std_2epath_2eparse(v_st_2426, heff_dup(v_dir_2413)));
  V v_t_2429 = (g_std_2epath_2eparse(v_st_2426, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str3)));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  V v_t_2431 = ({ V a_0 = v_st_2426; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2426); heff_drop(v_t_2430); r_; });
  V v_t_2432 = (g_list_2esortBy_24s735547525x1777295590(heff_dup(v_cs_241)));
  V v_x2_2433 = (g_list_2emap_24s631322900x900609068(v_t_2432));
  V v_t_2436;
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_Nil: {
    v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_xs_2435 = heff_field(v_x2_2433, 1);
    heff_take_n(v_x2_2433, 3ULL, 2);
    v_t_2436 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str5); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2433);
  }
  V v_t_2437 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str7), v_t_2436));
  return (g_heff_2ebuild_2ecommands_2edocPageWritten_24s1136537912x1566443128(v_t_2431, v_t_2437, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam4, 1, 4, (V[]){v_cs_241, v_dir_2413, v_hd_2414, v_k_2415})));
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_dir_2413 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_hd_2414 = heff_env(self)[2];
  V v_k_2415 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2426;
  if (heff_strEq_c(v_x_2424, ((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_str2))) {
    v_st_2426 = NTAG(TAG_Windows);
  } else {
    v_st_2426 = NTAG(TAG_Posix);
  }
  return ({ V a_0 = heff_dup(v_dir_2413); V a_1 = v_cs_241; V a_2 = heff_dup(v_hd_2414); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam3, 1, 5, (V[]){v_st_2426, v_dir_2413, heff_dup(v_cs_241), v_hd_2414, v_k_2415}); V r_ = (g_heff_2ebuild_2ecommands_2edocPagesWritten_24s1897511284x1285011589(a_0, a_1, a_2, a_3)); heff_drop(v_cs_241); r_; });
}
V g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_dir_2413 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam1_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(v_t_2423, heff_dup(v_hd_2414), heff_clo_n(g_heff_2ebuild_2ecommands_2edocWritten_24s270934607x353631261_lam2, 1, 4, (V[]){v_dir_2413, v_cs_241, v_hd_2414, v_k_2415})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str0, 30, "finding the newest version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str1, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str2, 6, "--tags");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str3, 6, "--refs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str4, 9, "ls-remote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str6, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str7, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str8, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str9, 24, "cannot list the tags of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str12, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str13, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str14, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str15, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str16, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str17, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str18, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str19, 9, "that of /");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str20, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str21, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str22, 6, "0 or 1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str23, 20, " (vA.B.C, its major ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str24, 1, ")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str25, 17, " is a version of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str26, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str27, 10, "no tag of ");
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736(V v_prog_240, V v_path_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str0), heff_dup(v_path_241)), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam0_clo)});
  V v_t_244 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_243}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam1, 2, 3, (V[]){v_t_244, v_path_241, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam0(V self, V *args) {
  V v_t_242 = args[0];
  return v_t_242;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam3(V self, V *args) {
  V v_r_2415 = args[0];
  return v_r_2415;
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam6(V self, V *args) {
  V v_best_2441 = args[0];
  V v_line_2442 = args[1];
  V v_path_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_it_2443 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str12); V a_1 = v_line_2442; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str13), v_line_2442, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_line_2442); r_; });
  switch (heff_tag_of(v_it_2443)) {
  case TAG_Nil: {
    heff_drop(v_path_241);
    return v_best_2441;
  }
  case TAG_Cons: {
    V v_it2_2445 = heff_field(v_it_2443, 1);
    heff_take_n(v_it_2443, 2ULL, 2);
    switch (heff_tag_of(v_it2_2445)) {
    case TAG_Nil: {
      heff_drop(v_path_241);
      return v_best_2441;
    }
    case TAG_Cons: {
      V v_v_2446 = heff_field(v_it2_2445, 0);
      V v_it22_2447 = heff_field(v_it2_2445, 1);
      heff_take_n(v_it2_2445, 3ULL, 2);
      switch (heff_tag_of(v_it22_2447)) {
      case TAG_Nil: {
        V v_t_2448 = (g_prelude_2eskipSpaces(v_v_2446, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_2449 = (heff_unbox_word(heff_strLength_lent(v_v_2446, 0)) - ((int64_t)1ULL));
        V v_t_2450 = (g_prelude_2eskipSpaces(v_v_2446, heff_box_word(v_t_2449), MK_INT(-1LL)));
        V v_t_2451 = heff_strSlice(heff_dup(v_v_2446), v_t_2448, heff_intAdd(v_t_2450, MK_INT(1LL)));
        HeffT2 v_t_2452 = ({ V a_0 = v_t_2451; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_t_2451); r_; });
        {
          V v_field_2454 = v_t_2452.f[1];
          int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
          if ((v_tag_2453 == ((int64_t)0ULL))) {
            V v_x_2456 = v_field_2454;
            heff_drop(v_x_2456);
            V v_t_2457 = (g_prelude_2eskipSpaces(v_v_2446, MK_INT(0LL), MK_INT(1LL)));
            int64_t v_t_2458 = (heff_unbox_word(heff_strLength_lent(v_v_2446, 0)) - ((int64_t)1ULL));
            V v_t_2459 = (g_prelude_2eskipSpaces(v_v_2446, heff_box_word(v_t_2458), MK_INT(-1LL)));
            V v_t_2460 = heff_strSlice(heff_dup(v_v_2446), v_t_2457, heff_intAdd(v_t_2459, MK_INT(1LL)));
            HeffT2 v_t_2461 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(v_path_241, v_t_2460));
            {
              V v_field_2463 = v_t_2461.f[1];
              int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
              if ((v_tag_2462 == ((int64_t)0ULL))) {
                heff_drop(v_v_2446);
                V v_x_2465 = v_field_2463;
                heff_drop(v_x_2465);
                return v_best_2441;
              } else {
                heff_drop(v_field_2463);
                switch (heff_tag_of(v_best_2441)) {
                case TAG_Nothing: {
                  V v_t_2466 = (g_prelude_2eskipSpaces(v_v_2446, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2467 = (heff_unbox_word(heff_strLength_lent(v_v_2446, 0)) - ((int64_t)1ULL));
                  V v_t_2468 = (g_prelude_2eskipSpaces(v_v_2446, heff_box_word(v_t_2467), MK_INT(-1LL)));
                  V v_t_2469 = heff_strSlice(v_v_2446, v_t_2466, heff_intAdd(v_t_2468, MK_INT(1LL)));
                  return heff_tag_n(TAG_Just, 1, (V[]){v_t_2469});
                }
                case TAG_Just: {
                  V v_b_2470 = heff_dup(heff_field(v_best_2441, 0));
                  V v_t_2471 = (g_prelude_2eskipSpaces(v_v_2446, MK_INT(0LL), MK_INT(1LL)));
                  int64_t v_t_2472 = (heff_unbox_word(heff_strLength_lent(v_v_2446, 0)) - ((int64_t)1ULL));
                  V v_t_2473 = (g_prelude_2eskipSpaces(v_v_2446, heff_box_word(v_t_2472), MK_INT(-1LL)));
                  V v_a_2474 = heff_strSlice(heff_dup(v_v_2446), v_t_2471, heff_intAdd(v_t_2473, MK_INT(1LL)));
                  HeffT2 v_t_2475 = ({ V a_0 = v_a_2474; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_a_2474); r_; });
                  V v_t_2480;
                  {
                    V v_field_2477 = v_t_2475.f[1];
                    int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                    if ((v_tag_2476 == ((int64_t)0ULL))) {
                      V v_x_2479 = v_field_2477;
                      v_t_2480 = v_x_2479;
                    } else {
                      heff_drop(v_field_2477);
                      v_t_2480 = NTAG(TAG_Nil);
                    }
                  }
                  HeffT2 v_t_2481 = ({ V a_0 = v_b_2470; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eversion_24cpr(a_0)); heff_drop(v_b_2470); r_; });
                  V v_t_2486;
                  {
                    V v_field_2483 = v_t_2481.f[1];
                    int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                    if ((v_tag_2482 == ((int64_t)0ULL))) {
                      V v_x_2485 = v_field_2483;
                      v_t_2486 = v_x_2485;
                    } else {
                      heff_drop(v_field_2483);
                      v_t_2486 = NTAG(TAG_Nil);
                    }
                  }
                  V v_t_2487 = ({ V a_0 = v_t_2480; V a_1 = v_t_2486; V r_ = (g_heff_2ebuild_2eproject_2enewerGo(a_0, a_1)); heff_drop(v_t_2480); heff_drop(v_t_2486); r_; });
                  if ((heff_dup(v_t_2487) == NTAG(TAG_True))) {
                    heff_drop_tag(v_best_2441, 1);
                    heff_drop(v_t_2487);
                    V v_t_2488 = (g_prelude_2eskipSpaces(v_v_2446, MK_INT(0LL), MK_INT(1LL)));
                    int64_t v_t_2489 = (heff_unbox_word(heff_strLength_lent(v_v_2446, 0)) - ((int64_t)1ULL));
                    V v_t_2490 = (g_prelude_2eskipSpaces(v_v_2446, heff_box_word(v_t_2489), MK_INT(-1LL)));
                    V v_t_2491 = heff_strSlice(v_v_2446, v_t_2488, heff_intAdd(v_t_2490, MK_INT(1LL)));
                    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2491});
                  } else {
                    heff_drop(v_v_2446);
                    heff_drop(v_t_2487);
                    return v_best_2441;
                  }
                }
                default: return heff_nomatch(v_best_2441);
                }
              }
            }
          } else {
            heff_drop(v_path_241);
            heff_drop(v_v_2446);
            heff_drop(v_field_2454);
            return v_best_2441;
          }
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2447, 0ULL, 2);
        heff_drop(v_path_241);
        heff_drop(v_v_2446);
        return v_best_2441;
      }
      default: return heff_nomatch(v_it22_2447);
      }
    }
    default: return heff_nomatch(v_it2_2445);
    }
  }
  default: return heff_nomatch(v_it_2443);
  }
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_take_field(v_x_2423, 0);
  V v_t_2431;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Exited: {
    V v_n_2428 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2431 = heff_bool(!heff_intEq_c_lent(v_n_2428, MK_INT(0LL), 2));
    heff_drop(v_n_2428);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2427, 0ULL, 1);
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V v_x_24115;
  if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
    heff_drop(v_t_2431);
    V v_t_2432 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_241));
    V v_s_2433 = heff_get_n(v_x_2423, 2, 3);
    V v_t_2434 = (g_prelude_2eskipSpaces(v_s_2433, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_s_2433, 0)) - ((int64_t)1ULL));
    V v_t_2436 = (g_prelude_2eskipSpaces(v_s_2433, heff_box_word(v_t_2435), MK_INT(-1LL)));
    V v_t_2437 = heff_strSlice(v_s_2433, v_t_2434, heff_intAdd(v_t_2436, MK_INT(1LL)));
    V v_t_2438 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str7), v_t_2432), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str8), v_t_2437));
    v_x_24115 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str9), v_t_2438)});
  } else {
    heff_drop(v_t_2431);
    V v_s_2439 = heff_get_n(v_x_2423, 1, 3);
    V v_t_2440 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str10); V a_1 = v_s_2439; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str11), v_s_2439, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_2439); r_; });
    V v_t_2494 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam6, 2, 1, (V[]){heff_dup(v_path_241)}); V a_1 = NTAG(TAG_Nothing); V a_2 = v_t_2440; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
    switch (heff_tag_of(v_t_2494)) {
    case TAG_Nothing: {
      V v_t_2495 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
      V v_xs_2496 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str14); V a_1 = v_path_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str15), v_path_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2497 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2496));
      V v_x_24100;
      switch (heff_tag_of(v_t_2497)) {
      case TAG_Nil: {
        v_x_24100 = heff_dup(v_path_241);
        break;
      }
      case TAG_Cons: {
        V v_x_2498 = heff_field(v_t_2497, 0);
        heff_take_n(v_t_2497, 1ULL, 2);
        v_x_24100 = v_x_2498;
        break;
      }
      default: heff_nomatch(v_t_2497);
      }
      V v_t_24110;
      if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_24100, 0)))) {
        if (heff_strEq_c(heff_strSlice_lent(v_x_24100, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str16))) {
          V v_t_24103 = heff_strSlice(heff_dup(v_x_24100), MK_INT(1LL), heff_strLength(v_x_24100));
          V v_t_24104 = ({ V a_0 = v_t_24103; V r_ = (g_heff_2ebuild_2eproject_2eisNumber(a_0)); heff_drop(v_t_24103); r_; });
          if ((heff_dup(v_t_24104) == NTAG(TAG_True))) {
            heff_drop(v_t_24104);
            V v_xs_24105 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str17); V a_1 = v_path_241; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str18), v_path_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
            V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24105));
            V v_t_24109;
            switch (heff_tag_of(v_t_24106)) {
            case TAG_Nil: {
              v_t_24109 = heff_dup(v_path_241);
              break;
            }
            case TAG_Cons: {
              V v_x_24107 = heff_field(v_t_24106, 0);
              heff_take_n(v_t_24106, 1ULL, 2);
              v_t_24109 = v_x_24107;
              break;
            }
            default: heff_nomatch(v_t_24106);
            }
            v_t_24110 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str19), v_t_24109);
          } else {
            heff_drop(v_t_24104);
            v_t_24110 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str20);
          }
        } else {
          heff_drop(v_x_24100);
          v_t_24110 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str21);
        }
      } else {
        heff_drop(v_x_24100);
        v_t_24110 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str22);
      }
      V v_t_24111 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str23), heff_strAppend(v_t_24110, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str24)));
      V v_t_24112 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str25), heff_strAppend(v_path_241, v_t_24111));
      V v_t_24113 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str26), v_t_2495), v_t_24112);
      v_x_24115 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str27), v_t_24113)});
      break;
    }
    case TAG_Just: {
      V v_v_24114 = heff_field(v_t_2494, 0);
      V v_ru_24t_2494_24Just = heff_take_reuse_n(v_t_2494, 1ULL, 1);
      heff_drop(v_path_241);
      v_x_24115 = heff_tag_at_n(v_ru_24t_2494_24Just, TAG_Right, 1, (V[]){v_v_24114});
      break;
    }
    default: heff_nomatch(v_t_2494);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_24115;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424 = heff_tag_n(TAG_End, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2424}));
  return (g_co_2eop_24s495635622x733177935(v_t_2425, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam5, 1, 3, (V[]){v_x_2423, v_path_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str1), v_t_248), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str3), v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str4), v_t_2410});
  V v_t_2412 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str5);
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2414 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_str6), v_t_2411, v_t_2413, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2416 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam3_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2422}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam4, 1, 5, (V[]){v_x_247, v_prog_240, v_hd_245, v_path_241, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_t_244 = heff_env(self)[0];
  V v_path_241 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s495635622x733177935(v_t_244, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2enewestTag_24s397474991x2003009736_lam2, 1, 4, (V[]){v_path_241, v_hd_245, v_prog_240, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173(V v_rep_240, V v_prog_241, V v_chk_242, V v_acc_243, V v_f_244) {
top: ;
  V v_c_245 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s573064528x1591372553_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam0, 2, 6, (V[]){v_c_245, v_f_244, v_acc_243, v_chk_242, v_prog_241, v_rep_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_247;
  args[0] = v_acc_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam4(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam9(V self, V *args) {
  V v_c_2425 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_x_2421, 2)), 1, 6);
  V v_t_2427 = (g_heff_2ebuild_2eload_2einside(heff_get_n(v_x_2421, 2, 5), v_t_2426, heff_take_field(v_c_2425, 1)));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2427) == NTAG(TAG_True)) ? ({ V v_x1_2428 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2425, 0), heff_rfield(v_acc_243, 0))); int c_ = !(heff_dup(v_x1_2428) == NTAG(TAG_True)); heff_drop(v_x1_2428); c_; }) : ({ V v_t_2429 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_2410), heff_dup(v_f_244))); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_c_2425, 0)), heff_dup(v_t_2429)) && ({ V v_x1_2431 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2425, 0), heff_rfield(v_acc_243, 0))); int c_ = !(heff_dup(v_x1_2431) == NTAG(TAG_True)); heff_drop(v_x1_2431); c_; })); heff_drop(v_t_2429); c_; })));
  heff_drop_rec(v_c_2425, 14);
  heff_drop_rec(v_acc_243, 2);
  heff_drop(v_x_2410);
  heff_drop(v_f_244);
  heff_drop(v_t_2427);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam11(V self, V *args) {
  V v_x_2437 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_prelude_2e_2b_2b_24f427551988x255400191(heff_take_field(v_acc_243, 0), heff_dup(v_x_2432)));
  V v_t_2439 = heff_intAdd(heff_get_n(v_acc_243, 1, 2), v_x_2422);
  V v_t_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2432; V r_ = (g_list_2efoldl_24s148011877x1447840770(a_0, a_1, a_2, a_3)); heff_drop(v_x_2432); r_; });
  V v_x_2441 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2438, heff_intAdd(v_t_2439, v_t_2440)});
  V f_ = v_k_247;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_2432 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2435}));
  return (g_co_2eop_24s495635622x733177935(v_t_2436, v_hd_246, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam11, 1, 4, (V[]){v_acc_243, v_x_2432, v_x_2422, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_x_2422 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x_2432 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam9, 1, 4, (V[]){v_x_2421, heff_dup(v_acc_243), v_x_2410, v_f_244}), heff_get_n(v_x_2424, 0, 2)));
  V v_c_2433 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s728145769x694012777(v_rep_240, heff_dup(v_x_2432)));
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam10, 1, 7, (V[]){v_x_2419, v_prog_241, v_hd_246, v_acc_243, v_x_2432, v_x_2422, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2423 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_x_2421)));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam8, 1, 10, (V[]){v_x_2421, v_acc_243, v_x_2410, v_f_244, v_rep_240, v_hd_246, v_x_2419, v_prog_241, v_x_2422, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_str0), heff_dup(heff_rfield(v_x_2421, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam7, 1, 9, (V[]){v_x_2421, v_hd_246, v_acc_243, v_x_2410, v_f_244, v_rep_240, v_x_2419, v_prog_241, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2420 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_f_244)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam6, 1, 8, (V[]){v_hd_246, v_acc_243, v_x_2410, v_f_244, v_rep_240, v_x_2419, v_prog_241, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_chk_242 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_2410), heff_dup(v_f_244)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_rfield(v_acc_243, 0); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); r_; });
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_drop(v_f_244);
    heff_drop(v_rep_240);
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_242, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2413}));
    return (g_co_2eop_24s495635622x733177935(v_t_2414, v_hd_246, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam3, 1, 2, (V[]){v_k_247, v_acc_243})));
  } else {
    heff_drop(v_t_2412);
    V v_name_2416 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_2410), heff_dup(v_f_244)));
    V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_242, v_name_2416, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam4_clo)})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2418, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam5, 1, 7, (V[]){v_f_244, v_hd_246, v_acc_243, v_x_2410, v_rep_240, v_prog_241, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_chk_242 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(v_x_248, heff_dup(v_f_244)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam2, 1, 7, (V[]){v_f_244, v_acc_243, v_chk_242, v_prog_241, v_hd_246, v_k_247, v_rep_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_chk_242 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s95308897x453568173_lam1, 1, 7, (V[]){v_f_244, v_hd_246, v_acc_243, v_chk_242, v_prog_241, v_k_247, v_rep_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str5, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str6, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_z_246);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_249});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str0)));
    V v_x2_2413 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str1), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str2), v_missing_245));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str6)));
    V v_str_2418 = heff_strAppend(v_t_2412, v_t_2417);
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2418, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_str7)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_lam0, 1, 2, (V[]){v_acc_242, v_z_247})));
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappShips_24s537896459x1744551837_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2428 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(V v_prog_240, V v_st_241, V v_t_242, V v_home_243, V v_sh_244, V v_next_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_home_243);
    heff_drop(v_sh_244);
    return v_next_245;
  }
  case TAG_Cons: {
    V v_n_247 = heff_field(v_x6_246, 0);
    V v_rest_248 = heff_field(v_x6_246, 1);
    V v_t_249 = (g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_home_243), heff_dup(v_sh_244), v_next_245, v_rest_248));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eshipOne_24s1427468145x227505435(v_prog_240, v_st_241, v_t_242, v_home_243, v_sh_244, v_t_249, heff_dup(v_n_247));
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(a[0], a1, a[2], a[3], a[4], a[5], a6); heff_drop(a1); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866(V v_prog_240, V v_st_241, V v_t_242, V v_done_243, V v_progs_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nothing: {
    heff_drop(v_prog_240);
    heff_drop(v_t_242);
    heff_drop(v_progs_244);
    return v_done_243;
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_245, 0);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_244)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    V v_t_2411 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_str0), heff_dup(v_home_246)), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam0_clo)});
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2411}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam1, 2, 7, (V[]){v_t_2412, v_prog_240, v_progs_244, heff_dup(v_st_241), v_t_242, heff_dup(v_home_246), v_done_243});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam0(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_done_243 = heff_env(self)[0];
  V v_hd_2421 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V f_ = v_done_243;
  heff_room[0] = v_hd_2421;
  heff_room[1] = v_k_2422;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2417 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s495635622x733177935(v_t_2417, heff_dup(v_hd_2421), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam4, 1, 3, (V[]){v_done_243, v_hd_2421, v_k_2422})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_progs_244 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_246 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_hd_2413 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2416 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2415), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2416}));
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_244));
  V v_xs_2419 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2418; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2419));
  V v_t_2424 = ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_246; V a_4 = v_x_2415; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam3, 2, 2, (V[]){v_t_2417, v_done_243}); V a_6 = v_t_2420; V r_ = (g_heff_2ebuild_2ecommands_2eshipAll_24s1757241500x34779154(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_st_241); heff_drop(v_t_2420); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_progs_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_home_246 = heff_env(self)[5];
  V v_done_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s1546052048x694945866_lam2, 1, 8, (V[]){v_prog_240, v_progs_244, v_st_241, v_t_242, v_home_246, v_done_243, v_hd_2413, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349(V v_rep_240, V v_prog_241, V v_dir_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s495635622x733177935(v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam1, 1, 5, (V[]){v_hd_243, v_dir_242, v_k_244, v_rep_240, v_prog_241})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam3(V self, V *args) {
  V v_t_2423 = args[0];
  return v_t_2423;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam5(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam7(V self, V *args) {
  V v_x_2480 = args[0];
  V v_hd_2470 = heff_env(self)[0];
  V v_k_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2480);
  V v_t_2481 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), v_hd_2470, v_k_2471));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam6(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_dir_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2472 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str8), heff_strAppend(v_dir_242, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str9)));
  V v_t_2473 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2472, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str10)), NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2479}), heff_dup(v_hd_2470), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam7, 1, 2, (V[]){v_hd_2470, v_k_2471})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2432 = (g_std_2epath_2eparse(v_st_2415, heff_dup(v_x_2416)));
  V v_t_2433 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str2)));
  V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
  V v_t_2435 = ({ V a_0 = v_st_2415; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2434); r_; });
  V v_x_2436 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_242), v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str4)});
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Nothing: {
    heff_drop(v_st_2415);
    heff_drop(v_x_2416);
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop_rec(v_x_2436, 6);
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str5), v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str6));
    V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam5, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
  case TAG_Just: {
    V v_t_2469;
    switch (heff_tag_of(v_x_2431)) {
    case TAG_Nothing: {
      heff_drop(v_x_2416);
      v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2436, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2454 = heff_field(v_x_2431, 0);
      heff_take_n(v_x_2431, 1ULL, 1);
      HeffT2 v_t_2455 = ({ V a_0 = v_text_2454; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_text_2454); r_; });
      {
        V v_field_2457 = v_t_2455.f[1];
        int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
        if ((v_tag_2456 == ((int64_t)0ULL))) {
          heff_drop(v_x_2416);
          V v_p_2459 = v_field_2457;
          heff_drop(v_p_2459);
          v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2436, 1))}));
        } else {
          V v_x_2460 = v_field_2457;
          HeffT2 v_t_2461 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2460));
          {
            V v_field_2463 = v_t_2461.f[1];
            int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
            if ((v_tag_2462 == ((int64_t)0ULL))) {
              heff_drop(v_x_2416);
              V v_x11_2465 = v_field_2463;
              heff_drop(v_x11_2465);
              v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2436, 1))}));
            } else {
              V v_pk_2466 = v_field_2463;
              if (heff_strEq_c(heff_get_n(v_pk_2466, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2436, 1))}));
                v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s580342086x217813621_clo), 5, (V[]){heff_dup(v_st_2415), heff_dup(v_x_2436), v_x_2416, heff_dup(v_dir_242), v_t_2468}));
              } else {
                heff_drop(v_x_2416);
                v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s111039137x1531727353_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2436, 1))}));
              }
            }
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x_2431);
    }
    return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_2415; V a_3 = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str7); V a_4 = v_x_2436; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam6, 2, 1, (V[]){v_dir_242}); V a_6 = v_t_2469; V a_7 = v_hd_243; V a_8 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ebuildProject_24s1979386549x737665210(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_2415); r_; });
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_std_2epath_2eparse(v_st_2415, heff_dup(v_dir_242)));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str1)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2415; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_path_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
  V v_a_2424 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam3_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  return (g_co_2eop_24s495635622x733177935(v_t_2430, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam4, 1, 7, (V[]){v_st_2415, v_x_2416, v_dir_242, v_hd_243, v_k_244, v_rep_240, v_prog_241})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1973327636x1631727742(heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s858568038x2108102349_lam2, 1, 6, (V[]){v_st_2415, v_dir_242, v_hd_243, v_k_244, v_rep_240, v_prog_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str1, 6, "status");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str2, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str7, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str8, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str9, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str13, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str14, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str15, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str17, 67, "heff publish: what is published is what is committed: commit first\012");
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552(V v_rep_240, V v_v_241, V v_pk_242, V v_src_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = heff_tr(g_std_2eprocess_2erun_24s350272650x457371011(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str0), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str1), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str2), MK_INT(0LL), MK_INT(0LL)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam0, 1, 6, (V[]){v_v_241, v_z_244, v_z_245, v_src_243, v_rep_240, v_pk_242})});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam1(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam3(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam4(V self, V *args) {
  V v_x_2468 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2468);
  V v_t_2469 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam6(V self, V *args) {
  V v_x_2480 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_pk_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2epublishTested_24s1105476968x907407669(v_v_241, v_pk_242, v_x_2480, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam5(V self, V *args) {
  V v_x_2478 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2479 = ({ V a_0 = v_rep_240; V a_1 = v_x_2478; V a_2 = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()); V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s291885405x1646052130(a_0, a_1, a_2)); heff_drop(v_x_2478); r_; });
  V f_ = v_c_2479;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam6, 1, 4, (V[]){v_v_241, v_pk_242, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam7(V self, V *args) {
  V v_x_2488 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2488);
  V v_t_2489 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  V v_src_243 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_pk_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = heff_take_field(v_x_247, 0);
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    v_t_2426 = heff_bool(!heff_intEq_c_lent(v_n_2423, MK_INT(0LL), 2));
    heff_drop(v_n_2423);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2426 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2421, 3);
    heff_drop(v_v_241);
    heff_drop(v_src_243);
    heff_drop(v_rep_240);
    heff_drop(v_pk_242);
    heff_drop(v_t_2426);
    V v_s_2427 = heff_get_n(v_x_247, 2, 3);
    V v_t_2428 = (g_prelude_2eskipSpaces(v_s_2427, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2429 = (heff_unbox_word(heff_strLength_lent(v_s_2427, 0)) - ((int64_t)1ULL));
    V v_t_2430 = (g_prelude_2eskipSpaces(v_s_2427, heff_box_word(v_t_2429), MK_INT(-1LL)));
    V v_t_2431 = heff_strSlice(v_s_2427, v_t_2428, heff_intAdd(v_t_2430, MK_INT(1LL)));
    V v_why_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str9), v_t_2431);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str10), v_why_2432), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str11));
    V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam3, 1, 2, (V[]){v_z_244, v_z_245})));
  } else {
    heff_drop(v_t_2426);
    V v_s_2449 = heff_get_n(v_x_247, 1, 3);
    V v_t_2450 = (g_prelude_2eskipSpaces(v_s_2449, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2451 = (heff_unbox_word(heff_strLength_lent(v_s_2449, 0)) - ((int64_t)1ULL));
    V v_t_2452 = (g_prelude_2eskipSpaces(v_s_2449, heff_box_word(v_t_2451), MK_INT(-1LL)));
    V v_t_2453 = heff_strSlice(v_s_2449, v_t_2450, heff_intAdd(v_t_2452, MK_INT(1LL)));
    if (heff_strEq_c(v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str12))) {
      V v_t_2455 = heff_get_n(v_x_2421, 0, 3);
      V v_t_2458;
      switch (heff_tag_of(v_t_2455)) {
      case TAG_Exited: {
        V v_n_2456 = heff_field(v_t_2455, 0);
        heff_take_n(v_t_2455, 1ULL, 1);
        v_t_2458 = heff_intEq(v_n_2456, MK_INT(0LL));
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2455, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2455);
      }
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop(v_src_243);
        heff_drop(v_rep_240);
        heff_drop(v_pk_242);
        heff_drop(v_t_2458);
        V v_t_2459 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str13), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str14)));
        V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str15), v_t_2459), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str16));
        V v_t_2461 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2460, NTAG(TAG_MkUnit)});
        V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
        V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
        V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
        V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
        V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
        return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam4, 1, 2, (V[]){v_z_244, v_z_245})));
      } else {
        heff_drop(v_t_2458);
        V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_243, NTAG(TAG_Nil)});
        V v_c_2477 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s997486351x1221457492(v_t_2476, NTAG(TAG_Nil)));
        V f_ = v_c_2477;
        heff_room[0] = heff_dup(v_z_244);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam5, 1, 5, (V[]){v_rep_240, v_z_244, v_v_241, v_pk_242, v_z_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_2421, 3);
      heff_drop(v_v_241);
      heff_drop(v_src_243);
      heff_drop(v_rep_240);
      heff_drop(v_pk_242);
      V v_t_2481 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str17), NTAG(TAG_MkUnit)});
      V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
      V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
      V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam7, 1, 2, (V[]){v_z_244, v_z_245})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_src_243 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str3), heff_dup(v_v_241)), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str5), v_t_248})});
  V v_t_2410 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2411;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str6);
  } else {
    heff_drop(v_t_2410);
    v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2412 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_str8), v_t_249}), v_t_2411, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2414 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam1_clo)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s47523600x1201665552_lam2, 1, 7, (V[]){v_x_247, v_z_244, v_z_245, v_v_241, v_src_243, v_rep_240, v_pk_242})));
}