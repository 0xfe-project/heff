// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_Finish 61316
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkGroup 19195
#define TAG_NoInput 41055
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_copies 592412158
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_files 298792593
#define LBL_globals 352931696
#define LBL_group 299987609
#define LBL_hashes 722717031
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_key 315609
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_malg 9839318
#define LBL_message 1186782793
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_opt 319789
#define LBL_output 941629484
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_unchecked 1931098040
#define LBL_units 312791945
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_units__copies[] = {LBL_units, LBL_copies};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_clo;
V g_heff_2ebuild_2ecommands_2ereaches(V, V);
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereaches_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708(V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_clo;
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo;
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(V, V);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914(V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506(V, V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163(V, V);
V g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemit_2ecompileProgramKept(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eemit_2ecompileProgramKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileProgramKept_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s47995487x1780857361(V, V);
V g_list_2efoldl_24s47995487x1780857361_entry(V self, V *a);
extern Clo g_list_2efoldl_24s47995487x1780857361_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s937655778x647278584(V, V);
V g_list_2efoldl_24s937655778x647278584_entry(V self, V *a);
extern Clo g_list_2efoldl_24s937655778x647278584_clo;
V g_list_2efoldl_24s987234042x1914266228(V, V);
V g_list_2efoldl_24s987234042x1914266228_entry(V self, V *a);
extern Clo g_list_2efoldl_24s987234042x1914266228_clo;
V g_list_2ekeepIf_24s122741325x871243494(V, V, V, V);
V g_list_2ekeepIf_24s122741325x871243494_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s122741325x871243494_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f58476578x2140998212(V, V, V);
V g_prelude_2e_2b_2b_24f58476578x2140998212_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f58476578x2140998212_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2emove_24s1656294343x318667886(V, V);
V g_std_2efilesystem_2emove_24s1656294343x318667886_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emove_24s1656294343x318667886_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2eremove_24s1441356369x419789784(V);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289(V, V);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereaches_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereaches_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2ereaches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereaches_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereaches(V v_sel_240, V v_o_241) {
top: ;
  V v_s_242 = heff_get_n(v_o_241, 0, 12);
  V v_xs_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ereaches_str0); V a_1 = v_s_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2ereaches_str1), v_s_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_242); r_; });
  V v_x_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_y_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sel_240));
  V v_ret_24bool = heff_bool(heff_intLe_c_lent(v_y_245, v_x_244, 0));
  heff_drop(v_x_244);
  heff_drop(v_y_245);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereaches(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str1, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str2, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str3, 27, " files check as they should");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str5, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efilesSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efilesSaid(V v_r_240) {
top: ;
  V v_files_241 = heff_take_field(v_r_240, 0);
  V v_unchecked_242 = heff_take_field(v_r_240, 4);
  V v_expectErrors_243 = heff_get_n(v_r_240, 1, 8);
  V v_t_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_unchecked_242; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_unchecked_242); r_; });
  V v_t_245 = heff_intShow(heff_intSub(heff_dup(v_files_241), v_t_244));
  V v_t_247;
  if (heff_intEq_c_lent(v_expectErrors_243, MK_INT(0LL), 2)) {
    heff_drop(v_expectErrors_243);
    v_t_247 = ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str0);
  } else {
    V v_t_246 = heff_strAppend(heff_intShow(v_expectErrors_243), ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str1));
    v_t_247 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str2), v_t_246);
  }
  V v_t_248 = heff_strAppend(heff_intShow(v_files_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str3), v_t_247));
  V v_t_249 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str4), v_t_248));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str5), v_t_249);
}
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efilesSaid(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam0(V self, V *args) {
  V v_v_244 = args[0];
  return v_v_244;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4(V self, V *args) {
  V v_v_2424 = args[0];
  return v_v_2424;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6(V self, V *args) {
  V v_s_2434 = args[0];
  return v_s_2434;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2444;
  if (heff_strEq_c(v_x_2443, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str3))) {
    v_st_2444 = NTAG(TAG_Windows);
  } else {
    v_st_2444 = NTAG(TAG_Posix);
  }
  V v_x_2460;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    V v_t_2447;
    switch (heff_tag_of(v_x_2423)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2433)) {
      case TAG_Nothing: {
        v_t_2447 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2445 = heff_field(v_x_2433, 0);
        heff_take_n(v_x_2433, 1ULL, 1);
        v_t_2447 = v_x_2445;
        break;
      }
      default: heff_nomatch(v_x_2433);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2446 = heff_field(v_x_2423, 0);
      heff_take_n(v_x_2423, 1ULL, 1);
      heff_drop(v_x_2433);
      v_t_2447 = v_x_2446;
      break;
    }
    default: heff_nomatch(v_x_2423);
    }
    V v_t_2448 = (g_std_2epath_2eparse(v_st_2444, v_t_2447));
    V v_t_2449 = (g_std_2epath_2eparse(v_st_2444, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str5)));
    V v_t_2450 = (g_std_2epath_2ejoin(v_t_2448, v_t_2449));
    V v_a_2451 = ({ V a_0 = v_st_2444; V a_1 = v_t_2450; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2450); r_; });
    V v_t_2452 = (g_std_2epath_2eparse(v_st_2444, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str6)));
    V v_t_2453 = (g_std_2epath_2eparse(v_st_2444, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str7)));
    V v_t_2454 = (g_std_2epath_2ejoin(v_t_2452, v_t_2453));
    V v_b_2455 = ({ V a_0 = v_st_2444; V a_1 = v_t_2454; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2454); r_; });
    V v_t_2456 = (g_std_2epath_2eparse(v_st_2444, v_a_2451));
    V v_t_2457 = (g_std_2epath_2eparse(v_st_2444, v_b_2455));
    V v_t_2458 = (g_std_2epath_2ejoin(v_t_2456, v_t_2457));
    v_x_2460 = ({ V a_0 = v_st_2444; V a_1 = v_t_2458; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2458); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2459 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    heff_drop(v_x_2423);
    heff_drop(v_x_2433);
    heff_drop(v_st_2444);
    v_x_2460 = v_d_2459;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V f_ = v_k_241;
  args[0] = v_x_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_x_2423 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam6_clo)})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2441}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2442;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam7, 1, 4, (V[]){v_x_2413, v_x_2423, v_x_2433, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam4_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2431}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam5, 1, 5, (V[]){v_malg_243, v_bind_242, v_x_2413, v_x_2423, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(v_bind_242);
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s1021613631x2040984864_lam3, 1, 4, (V[]){v_malg_243, v_bind_242, v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2423; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2425;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_str0))) {
    v_t_2425 = NTAG(TAG_Windows);
  } else {
    v_t_2425 = NTAG(TAG_Posix);
  }
  V v_x_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2425); heff_drop(v_x_2424); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2421}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_lam3, 1, 2, (V[]){v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str2, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str3, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str4, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str5, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str6, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str7, 8, "heff run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str8, 4, "main");
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708(V v_rep_240, V v_prog_241, V v_file_242, V v_progArgs_243) {
top: ;
  V v_c_244 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam0, 2, 5, (V[]){v_c_244, v_prog_241, v_file_242, v_progArgs_243, v_rep_240});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam2(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam4(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_cmd_2434 = heff_env(self)[0];
  V v_progArgs_243 = heff_env(self)[1];
  V v_hd_2439 = heff_env(self)[2];
  V v_k_2440 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exec, 3, (V[]){v_cmd_2434, v_progArgs_243, NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_hd_2439, v_k_2440));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam6(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_t_2436 = heff_env(self)[0];
  V v_cmd_2434 = heff_env(self)[1];
  V v_progArgs_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, heff_dup(v_hd_2439), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam7, 1, 4, (V[]){v_cmd_2434, v_progArgs_243, v_hd_2439, v_k_2440})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam9(V self, V *args) {
  V v_x_2454 = args[0];
  V v_next_2449 = heff_env(self)[0];
  V v_hd_2452 = heff_env(self)[1];
  V v_k_2453 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2454);
  V f_ = v_next_2449;
  heff_room[0] = v_hd_2452;
  heff_room[1] = v_k_2453;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam8(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_t_2451 = heff_env(self)[0];
  V v_next_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2451, heff_dup(v_hd_2452), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam9, 1, 3, (V[]){v_next_2449, v_hd_2452, v_k_2453})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam5(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_progArgs_243 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_247, 2)), heff_dup(v_file_242)));
  V v_outPath_2415 = heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str1));
  V v_dir_2416 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_247, 2)), heff_dup(v_file_242)));
  V v_paths_2417 = heff_dup(heff_rfield(v_x_247, 2));
  V v_d_2418 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2417), heff_dup(v_file_242)));
  V v_st_2419 = heff_dup(heff_rfield(v_paths_2417, 5));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2419, v_d_2418));
  V v_t_2421 = heff_get_n(v_paths_2417, 5, 6);
  V v_t_2422;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Posix: {
    v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str2);
    break;
  }
  case TAG_Windows: {
    v_t_2422 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str3);
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2423 = (g_std_2epath_2eparse(v_st_2419, v_t_2422));
  V v_t_2424 = (g_std_2epath_2ejoin(v_t_2420, v_t_2423));
  V v_out_2425 = ({ V a_0 = v_st_2419; V a_1 = v_t_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); heff_drop(v_t_2424); r_; });
  V v_paths_2426 = heff_dup(heff_rfield(v_x_247, 2));
  V v_d_2427 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(v_paths_2426), heff_dup(v_file_242)));
  V v_st_2428 = heff_dup(heff_rfield(v_paths_2426, 5));
  V v_t_2429 = (g_std_2epath_2eparse(v_st_2428, v_d_2427));
  V v_t_2430 = heff_get_n(v_paths_2426, 5, 6);
  V v_t_2431;
  switch (heff_tag_of(v_t_2430)) {
  case TAG_Posix: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str4);
    break;
  }
  case TAG_Windows: {
    v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str5);
    break;
  }
  default: heff_nomatch(v_t_2430);
  }
  V v_t_2432 = (g_std_2epath_2eparse(v_st_2428, v_t_2431));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2429, v_t_2432));
  V v_cmd_2434 = ({ V a_0 = v_st_2428; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2428); heff_drop(v_t_2433); r_; });
  V v_t_2435 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2410), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2435}));
  V v_t_2437 = heff_get_n(heff_dup(heff_rfield(v_x_247, 2)), 5, 6);
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str6), NTAG(TAG_Nil)});
  V v_next_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = heff_dup(v_prog_241); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str7); V a_3 = v_t_2437; V a_4 = v_t_2438; V a_5 = v_x_2410; V a_6 = v_dir_2416; V a_7 = v_out_2425; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam6, 2, 3, (V[]){v_t_2436, v_cmd_2434, v_progArgs_243}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s127493106x375129802(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2437); r_; });
  V v_t_2450 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2450}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s526828503x680159661(MK_INT(1LL), v_rep_240, v_x_247, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str8)}), v_outPath_2415, v_file_242, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam8, 2, 2, (V[]){v_t_2451, v_next_2449}), v_hd_245, v_k_246));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_progArgs_243 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam4_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2412, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam5, 1, 8, (V[]){v_x_247, v_file_242, v_x_2410, v_prog_241, v_progArgs_243, v_rep_240, v_hd_245, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_file_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_progArgs_243 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_249 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_242), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam2_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_249, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam3, 1, 7, (V[]){v_prog_241, v_hd_245, v_x_247, v_file_242, v_progArgs_243, v_rep_240, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_file_242 = heff_env(self)[2];
  V v_progArgs_243 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s239283789x13723708_lam1, 1, 6, (V[]){v_prog_241, v_file_242, v_hd_245, v_progArgs_243, v_rep_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_str2, 1, ".");
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_MkPair: {
      V v_top_247 = heff_field(v_x11_245, 0);
      V v_p_248 = heff_field(v_x11_245, 1);
      heff_take_n(v_x11_245, 3ULL, 2);
      V v_path_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_p_248); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_2410 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_249));
      V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam1_clo)}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam3, 2, 5, (V[]){v_c_2415, v_p_248, v_rest_246, v_acc_241, v_top_247});
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_2412 = (g_list_2emap_24s219049803x1458391381(v_x_2411));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam2, 2, 1, (V[]){v_x_2412});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam5(V self, V *args) {
  V v_s_2419 = args[0];
  return v_s_2419;
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam7(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam9(V self, V *args) {
  V v_n_2442 = args[0];
  V v_st_2429 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2443 = (g_std_2epath_2eparse(v_st_2429, v_p_248));
  V v_t_2444 = (g_std_2epath_2eparse(v_st_2429, v_n_2442));
  V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
  V v_t_2446 = ({ V a_0 = v_st_2429; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2429); heff_drop(v_t_2445); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_t_2446});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_rest_246 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_hd_2416 = heff_env(self)[2];
  V v_k_2417 = heff_env(self)[3];
  V v_y_2435 = heff_env(self)[4];
  V v_st_2429 = heff_env(self)[5];
  V v_p_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    heff_drop(v_y_2435);
    heff_drop(v_st_2429);
    heff_drop(v_p_248);
    V v_t_2440 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_rest_246, v_acc_241));
    V f_ = v_t_2440;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2439);
    V v_t_2441 = ({ V b_0 = MK_INT(0LL); V b_1 = MK_INT(1LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_str2); V a_3 = v_y_2435; V r_ = (g_list_2ekeepIf_24s122741325x871243494(b_0, b_1, b_2, a_3)); heff_drop(b_0); heff_drop(b_1); heff_drop(b_2); r_; });
    V v_t_2447 = (g_prelude_2e_2b_2b_24f58476578x2140998212(v_rest_246, heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam9, 1, 2, (V[]){v_st_2429, v_p_248}), v_t_2441));
    V v_t_2448 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_t_2447, v_acc_241));
    V f_ = v_t_2448;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam6(V self, V *args) {
  V v_x_2428 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_hd_2416 = heff_env(self)[4];
  V v_k_2417 = heff_env(self)[5];
  V v_top_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2429;
  if (heff_strEq_c(v_x_2428, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_str0))) {
    v_st_2429 = NTAG(TAG_Windows);
  } else {
    v_st_2429 = NTAG(TAG_Posix);
  }
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop(v_top_247);
    heff_drop(v_st_2429);
    int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_p_248, 0)) - ((int64_t)3ULL));
    V v_t_2432 = heff_strSlice(heff_dup(v_p_248), heff_box_word(v_t_2431), heff_strLength_lent(v_p_248, 0));
    if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_str1))) {
      V v_t_2433 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_rest_246, heff_tag_n(TAG_Cons, 2, (V[]){v_p_248, v_acc_241})));
      V f_ = v_t_2433;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_p_248);
      V v_t_2434 = (g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006(v_rest_246, v_acc_241));
      V f_ = v_t_2434;
      heff_room[0] = v_hd_2416;
      heff_room[1] = v_k_2417;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Right: {
    V v_y_2435 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    V v_c_2438;
    if ((heff_dup(v_top_247) == NTAG(TAG_True))) {
      heff_drop(v_top_247);
      v_c_2438 = ((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam7_clo);
    } else {
      heff_drop(v_top_247);
      v_c_2438 = (g_heff_2ebuild_2eload_2eisRoot_24s2122256650x38214163(v_st_2429, heff_dup(v_p_248)));
    }
    V f_ = v_c_2438;
    heff_room[0] = heff_dup(v_hd_2416);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam8, 1, 7, (V[]){v_rest_246, v_acc_241, v_hd_2416, v_k_2417, v_y_2435, v_st_2429, v_p_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  V v_top_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam5_clo)})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){v_t_2426}));
  V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
  heff_room[0] = v_t_2427;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam6, 1, 7, (V[]){v_x_2418, v_p_248, v_rest_246, v_acc_241, v_hd_2416, v_k_2417, v_top_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_p_248 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_top_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestFilesGo_24s2147396967x1764978006_lam4, 1, 6, (V[]){v_hd_2416, v_p_248, v_rest_246, v_acc_241, v_k_2417, v_top_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_str1, 30, "its program could not be run: ");
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam9(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627(V v_ex_240, V v_sel_241, V v_j_242, V v_dir_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 0, 2);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_242, 3)), heff_dup(heff_rfield(v_j_242, 4))});
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_243); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_243), ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_str0))});
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 1, 2);
  V v_t_2411 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_246, v_t_247, v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_242, 5)), MK_INT(0LL), NTAG(TAG_True)});
  V v_c_2412 = (g_std_2eprocess_2ewithProcess_24s1345957496x637138289(heff_dup(v_ex_240), v_t_2411));
  V v_t_2436 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam0, 2, 4, (V[]){v_c_2412, heff_dup(v_sel_241), heff_dup(v_j_242), heff_dup(v_dir_243)}), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam4, 1, 2, (V[]){v_dir_243, v_j_242})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam9, 1, 2, (V[]){v_z_244, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2418);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2414;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam3, 3, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sel_241 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416 = ({ V a_0 = v_sel_241; V a_1 = v_j_242; V a_2 = v_dir_243; V a_3 = v_x_2415; V r_ = (g_heff_2ebuild_2ecommands_2eendedJob_24s366728331x1470048759(a_0, a_1, a_2, a_3)); heff_drop(v_sel_241); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam2, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_sel_241 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  V v_dir_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam1, 1, 5, (V[]){v_sel_241, v_j_242, v_dir_243, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2425 = args[1];
  V v_k_2426 = args[2];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam8(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2434 = args[1];
  V v_k_2435 = args[2];
  V v_x_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = v_x_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_err_2421 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_k_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_str1), heff_get_n(v_err_2421, 2, 3));
  V v_x_2432 = (g_heff_2ebuild_2ecommands_2ebrokenJob(v_j_242, v_t_2431));
  V f_ = v_k_2429;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam8, 3, 1, (V[]){v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_err_2421 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam7, 1, 3, (V[]){v_err_2421, v_j_242, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam4(V self, V *args) {
  V v_err_2421 = args[0];
  V v_dir_243 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_dir_243; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2423 = ({ V a_0 = v_path_2422; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2422); r_; });
  V v_c_2427 = heff_tr(heff_call(v_c_2423, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam5_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam6, 2, 3, (V[]){v_c_2427, v_err_2421, v_j_242});
}
V g_heff_2ebuild_2ecommands_2eranJob_24s340602498x1430940627_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2437;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam11(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(V v_ex_240, V v_rx_241, V v_sel_242, V v_jobs_243, V v_g_244, V v_x4_245, V v_pending_246, V v_done_247) {
top: ;
  switch (heff_tag_of(v_x4_245)) {
  case TAG_Nil: {
    if (heff_intEq_c_lent(v_pending_246, MK_INT(0LL), 2)) {
      heff_drop(v_ex_240);
      heff_drop(v_rx_241);
      heff_drop(v_sel_242);
      heff_drop(v_jobs_243);
      heff_drop(v_pending_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam0, 2, 1, (V[]){v_done_247});
    } else {
      V v_c_2415;
      switch (heff_tag_of(v_g_244)) {
      case TAG_MkGroup: {
        V v_i_2410 = heff_field(v_g_244, 0);
        V v_t_2413 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_i_2410), NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam1_clo)});
        V v_t_2414 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){v_t_2413}));
        v_c_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2414}));
        break;
      }
      default: heff_nomatch(v_g_244);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam3, 2, 8, (V[]){v_c_2415, v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, heff_dup(v_g_244), v_pending_246});
    }
  }
  case TAG_Cons: {
    V v_j_2424 = heff_field(v_x4_245, 0);
    V v_rest_2425 = heff_field(v_x4_245, 1);
    heff_take_n(v_x4_245, 3ULL, 2);
    if (heff_intLt_c_lent(v_pending_246, v_jobs_243, 0)) {
      V v_c_2431;
      switch (heff_tag_of(v_g_244)) {
      case TAG_MkGroup: {
        V v_i_2426 = heff_field(v_g_244, 0);
        V v_t_2430 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){heff_dup(v_i_2426), heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam5, 1, 3, (V[]){heff_dup(v_ex_240), heff_dup(v_sel_242), v_j_2424})})}));
        v_c_2431 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2430}));
        break;
      }
      default: heff_nomatch(v_g_244);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam7, 2, 9, (V[]){v_c_2431, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, heff_dup(v_g_244), v_rest_2425, v_pending_246, v_done_247});
    } else {
      V v_c_2444;
      switch (heff_tag_of(v_g_244)) {
      case TAG_MkGroup: {
        V v_i_2439 = heff_field(v_g_244, 0);
        V v_t_2442 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_i_2439), NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam9_clo)});
        V v_t_2443 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){v_t_2442}));
        v_c_2444 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2443}));
        break;
      }
      default: heff_nomatch(v_g_244);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam11, 2, 10, (V[]){v_c_2444, v_j_2424, v_rest_2425, v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, heff_dup(v_g_244), v_pending_246});
    }
  }
  default: return heff_nomatch(v_x4_245);
  }
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_done_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_done_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam2(V self, V *args) {
  V v_l_2412 = args[0];
  return v_l_2412;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam1(V self, V *args) {
  V v_use_2411 = args[0];
  V f_ = v_use_2411;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam2_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam4(V self, V *args) {
  V v_x_2418 = args[0];
  V v_done_247 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_sel_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_pending_246 = heff_env(self)[6];
  V v_hd_2416 = heff_env(self)[7];
  V v_k_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2418)));
  V v_t_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2418));
  V v_t_2422 = (g_prelude_2e_2b_2b(v_x_2418, v_done_247));
  V v_t_2423 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_t_2420; V a_6 = heff_intSub(v_pending_246, v_t_2421); V a_7 = v_t_2422; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
  V f_ = v_t_2423;
  heff_room[0] = v_hd_2416;
  heff_room[1] = v_k_2417;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_done_247 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_rx_241 = heff_env(self)[3];
  V v_sel_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  V v_pending_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam4, 1, 9, (V[]){v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, v_g_244, v_pending_246, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam6(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam5(V self, V *args) {
  V v_use_2427 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_sel_242 = heff_env(self)[1];
  V v_j_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2erunJob_24s631954993x273490459_clo), 3, (V[]){v_ex_240, v_sel_242, v_j_2424}));
  V f_ = v_use_2427;
  heff_room[0] = v_t_2428;
  heff_room[1] = ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam6_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam8(V self, V *args) {
  V v_x_2434 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_sel_242 = heff_env(self)[2];
  V v_jobs_243 = heff_env(self)[3];
  V v_g_244 = heff_env(self)[4];
  V v_rest_2425 = heff_env(self)[5];
  V v_pending_246 = heff_env(self)[6];
  V v_done_247 = heff_env(self)[7];
  V v_hd_2432 = heff_env(self)[8];
  V v_k_2433 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2434)) {
  case TAG_Nothing: {
    V v_t_2435 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_rest_2425; V a_6 = heff_intAdd(v_pending_246, MK_INT(1LL)); V a_7 = v_done_247; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
    V f_ = v_t_2435;
    heff_room[0] = v_hd_2432;
    heff_room[1] = v_k_2433;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_f_2436 = heff_field(v_x_2434, 0);
    heff_take_n(v_x_2434, 1ULL, 1);
    V v_t_2437 = (g_prelude_2e_2b_2b(v_rest_2425, heff_dup(heff_rfield(v_f_2436, 3))));
    V v_t_2438 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_t_2437; V a_6 = v_pending_246; V a_7 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2436, v_done_247}); V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
    V f_ = v_t_2438;
    heff_room[0] = v_hd_2432;
    heff_room[1] = v_k_2433;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2434);
  }
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam7(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_c_2431 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_sel_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_rest_2425 = heff_env(self)[6];
  V v_pending_246 = heff_env(self)[7];
  V v_done_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2431;
  args[0] = heff_dup(v_hd_2432);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam8, 1, 10, (V[]){v_ex_240, v_rx_241, v_sel_242, v_jobs_243, v_g_244, v_rest_2425, v_pending_246, v_done_247, v_hd_2432, v_k_2433});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam10(V self, V *args) {
  V v_l_2441 = args[0];
  return v_l_2441;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam9(V self, V *args) {
  V v_use_2440 = args[0];
  V f_ = v_use_2440;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam10_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam12(V self, V *args) {
  V v_x_2447 = args[0];
  V v_j_2424 = heff_env(self)[0];
  V v_rest_2425 = heff_env(self)[1];
  V v_done_247 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_rx_241 = heff_env(self)[4];
  V v_sel_242 = heff_env(self)[5];
  V v_jobs_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  V v_pending_246 = heff_env(self)[8];
  V v_hd_2445 = heff_env(self)[9];
  V v_k_2446 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2447)));
  V v_t_2449 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2448; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2448); r_; });
  V v_t_2450 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_j_2424, v_rest_2425}), v_t_2449));
  V v_t_2451 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2447));
  V v_t_2452 = (g_prelude_2e_2b_2b(v_x_2447, v_done_247));
  V v_t_2453 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_t_2450; V a_6 = heff_intSub(v_pending_246, v_t_2451); V a_7 = v_t_2452; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
  V f_ = v_t_2453;
  heff_room[0] = v_hd_2445;
  heff_room[1] = v_k_2446;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam11(V self, V *args) {
  V v_hd_2445 = args[0];
  V v_k_2446 = args[1];
  V v_c_2444 = heff_env(self)[0];
  V v_j_2424 = heff_env(self)[1];
  V v_rest_2425 = heff_env(self)[2];
  V v_done_247 = heff_env(self)[3];
  V v_ex_240 = heff_env(self)[4];
  V v_rx_241 = heff_env(self)[5];
  V v_sel_242 = heff_env(self)[6];
  V v_jobs_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  V v_pending_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2444;
  args[0] = heff_dup(v_hd_2445);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s1683714037x963196063_lam12, 1, 11, (V[]){v_j_2424, v_rest_2425, v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, v_g_244, v_pending_246, v_hd_2445, v_k_2446});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914(V v_rep_240, V v_opts_241, V v_f_242) {
top: ;
  V v_path_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_f_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_244 = ({ V a_0 = v_path_243; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_243); r_; });
  V v_c_248 = heff_tr(heff_call(v_c_244, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam1, 2, 4, (V[]){v_c_248, v_f_242, heff_dup(v_rep_240), v_opts_241});
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_246 = args[1];
  V v_k_247 = args[2];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_245});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_opts_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_j_2415 = heff_strFind(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str0), ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str1), MK_INT(0LL));
  V v_t_2416;
  if (heff_intLt_c_lent(v_j_2415, MK_INT(0LL), 2)) {
    heff_drop(v_j_2415);
    v_t_2416 = MK_INT(0LL);
  } else {
    v_t_2416 = v_j_2415;
  }
  V v_t_2417 = heff_bool(heff_strEq_c(heff_strSlice_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str2), MK_INT(0LL), v_t_2416, 3), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get())));
  heff_drop(v_t_2416);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_t_2417; V a_4 = v_x_2414; V a_5 = v_hd_249; V a_6 = v_k_2410; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_240); heff_drop(v_t_2417); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_y_2418 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_j_2421 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_str3), v_y_2418, MK_INT(0LL), 5);
  V v_t_2422;
  if (heff_intLt_c_lent(v_j_2421, MK_INT(0LL), 2)) {
    heff_drop(v_j_2421);
    v_t_2422 = heff_strLength_lent(v_y_2418, 0);
  } else {
    v_t_2422 = v_j_2421;
  }
  V v_t_2423 = heff_bool(heff_strEq_c(heff_strSlice_lent(v_y_2418, MK_INT(0LL), v_t_2422, 2), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get())));
  heff_drop(v_y_2418);
  heff_drop(v_t_2422);
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_t_2423; V a_4 = v_x_2420; V a_5 = v_hd_249; V a_6 = v_k_2410; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s436980046x995616954(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_240); heff_drop(v_t_2423); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Left: {
    heff_take_n(v_x_2411, 0ULL, 1);
    V v_c_2413 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_242)));
    V f_ = v_c_2413;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam3, 1, 5, (V[]){v_rep_240, v_opts_241, v_f_242, v_hd_249, v_k_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2418 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    V v_c_2419 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_242)));
    V f_ = v_c_2419;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam4, 1, 6, (V[]){v_y_2418, v_rep_240, v_opts_241, v_f_242, v_hd_249, v_k_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1544006156x2005246914_lam2, 1, 5, (V[]){v_f_242, v_hd_249, v_rep_240, v_opts_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(V v_bi_240, V v_outPath_241, V v_done_242, V v_c_243, V v_available_244, V v_r_245, V v_hd_246, V v_k_247) {
top: ;
  V v_key_248 = heff_take_field(v_r_245, 0);
  V v_effect_249 = heff_get_n(v_r_245, 1, 2);
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(heff_dup(heff_rfield(v_bi_240, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam0, 1, 9, (V[]){v_bi_240, v_hd_246, v_c_243, v_available_244, v_key_248, v_effect_249, v_outPath_241, v_done_242, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_c_243 = heff_env(self)[1];
  V v_available_244 = heff_env(self)[2];
  V v_key_248 = heff_env(self)[3];
  V v_effect_249 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_242 = heff_env(self)[7];
  V v_hd_246 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2417 = heff_get_n(heff_get_n(v_c_243, 5, 14), 0, 9);
  V v_m_2418 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2419 = ({ V a_0 = v_m_2418; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2418); r_; });
  V v_bs_2420 = (g_list_2emap_24s1173914895x100384474(v_t_2419));
  V v_t_2421 = (g_list_2efoldl_24s47995487x1780857361(heff_dup(g_std_2emap_2eempty_get()), v_bs_2420));
  V v_t_2422 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2420; V r_ = (g_list_2efoldl_24s937655778x647278584(a_0, a_1)); heff_drop(v_bs_2420); r_; });
  V v_m_2423 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  V v_t_2424 = ({ V a_0 = v_m_2423; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2423); r_; });
  V v_bs_2425 = (g_list_2emap_24s1173914895x100384474(v_t_2424));
  V v_t_2426 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_bs_2425; V r_ = (g_list_2efoldl_24s987234042x1914266228(a_0, a_1)); heff_drop(v_bs_2425); r_; });
  V v_t_2427 = ({ V a_0 = v_available_244; V a_1 = v_t_2417; V a_2 = v_key_248; V a_3 = v_effect_249; V a_4 = heff_dup(heff_rfield(v_bi_240, 1)); V a_5 = heff_rec_n(2, shape_units__copies, (V[]){v_t_2421, v_t_2422}); V a_6 = v_t_2426; V r_ = (g_heff_2ecompile_2eemit_2ecompileProgramKept(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2426); r_; });
  return ({ V a_0 = v_bi_240; V a_1 = v_outPath_241; V a_2 = v_x_2410; V a_3 = v_x_2415; V a_4 = v_t_2416; V a_5 = v_done_242; V a_6 = v_t_2427; V a_7 = v_hd_246; V a_8 = v_k_247; V r_ = (g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1056776615x1195349855(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_bi_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_available_244 = heff_env(self)[3];
  V v_key_248 = heff_env(self)[4];
  V v_effect_249 = heff_env(self)[5];
  V v_outPath_241 = heff_env(self)[6];
  V v_done_242 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_str1), heff_dup(heff_rfield(v_bi_240, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s46023474x581868577(heff_dup(heff_rfield(v_bi_240, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_lam2, 1, 10, (V[]){v_x_2410, v_c_243, v_available_244, v_key_248, v_effect_249, v_bi_240, v_outPath_241, v_done_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str1, 10, "   (local)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str2, 11, "   (global)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str3, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str4, 13, "nothing there");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str5, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506(V v_rep_240, V v_file_241, V v_offs_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_file_241));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam0, 2, 3, (V[]){v_c_243, v_rep_240, v_offs_242});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam5(V self, V *args) {
  V v_off_2417 = args[0];
  V v_c_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2418 = ({ V a_0 = v_off_2417; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_off_2417); r_; });
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_o_2421 = v_field_2420;
      HeffT2 v_t_2422 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2416, v_o_2421));
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_i_2425 = v_field_2424;
          V v_name_2426 = heff_take_field(v_i_2425, 1);
          V v_ty_2427 = heff_take_field(v_i_2425, 4);
          V v_key_2428 = heff_get_n(v_i_2425, 2, 5);
          V v_t_2429 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2426));
          V v_t_2430 = heff_tr(heff_call(v_ty_2427, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2432;
          switch (heff_tag_of(v_key_2428)) {
          case TAG_Nothing: {
            v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str1);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_key_2428, 0ULL, 1);
            v_t_2432 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str2);
            break;
          }
          default: heff_nomatch(v_key_2428);
          }
          V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str3), heff_strAppend(v_t_2430, v_t_2432));
          V v_t_2434 = heff_strAppend(v_t_2429, v_t_2433);
          return v_t_2434;
        } else {
          heff_drop(v_field_2424);
          return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str4);
        }
      }
    } else {
      heff_drop(v_c_2416);
      heff_drop(v_field_2420);
      return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str5);
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam4(V self, V *args) {
  V v_x_2412 = args[0];
  V v_cs_2410 = heff_env(self)[0];
  V v_offs_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2412);
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_2410));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_c_2416 = v_field_2415;
      V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam5, 1, 1, (V[]){v_c_2416}), v_offs_242));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2435, v_hd_244, v_k_245));
    } else {
      heff_drop(v_offs_242);
      heff_drop(v_field_2415);
      V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_244, v_k_245));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam3(V self, V *args) {
  V v_x_249 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_cs_2410 = heff_get_n(v_x_249, 0, 2);
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_2410)));
  V f_ = v_c_2411;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam4, 1, 4, (V[]){v_cs_2410, v_offs_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_offs_242 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_247);
  V v_c_248 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_246));
  V f_ = v_c_248;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam3, 1, 4, (V[]){v_rep_240, v_hd_244, v_offs_242, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_str0), heff_dup(heff_rfield(v_x_246, 1)), MK_INT(0LL), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam2, 1, 5, (V[]){v_x_246, v_hd_244, v_rep_240, v_offs_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s846757408x1151281506_lam1, 1, 4, (V[]){v_hd_244, v_rep_240, v_offs_242, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str2, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_path_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_old_242; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_249 = ({ V a_0 = v_path_248; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_248); r_; });
    V v_c_2413 = heff_tr(heff_call(v_c_249, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0_clo)}));
    return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_z_246, v_next_244, v_z_247})});
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_path_2425 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_old_242; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_to_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_to_243); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2427 = ({ V a_0 = v_path_2425; V a_1 = v_to_2426; V r_ = (g_std_2efilesystem_2emove_24s1656294343x318667886(a_0, a_1)); heff_drop(v_path_2425); heff_drop(v_to_2426); r_; });
    V v_c_2431 = heff_tr(heff_call(v_c_2427, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3_clo)}));
    return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam4, 1, 4, (V[]){v_fresh_241, v_z_246, v_to_243, v_z_247})});
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V f_ = v_next_244;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_strAppend(heff_get_n(v_t_240, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str0), v_to_243));
  V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str1)), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  V f_ = heff_dup(heff_rfield(v_z_246, 1));
  heff_room[0] = v_t_2423;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam2, 1, 3, (V[]){v_next_244, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k_2437 = args[2];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam7(V self, V *args) {
  V v_x_2450 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_z_246, v_z_247));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_strAppend(v_fresh_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str2), v_to_243));
  V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str3), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str4), v_t_2440));
  V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_str5)), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
  V f_ = heff_dup(heff_rfield(v_z_246, 1));
  heff_room[0] = v_t_2449;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam7, 1, 2, (V[]){v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2432);
  V v_path_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_fresh_241); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2434 = ({ V a_0 = v_path_2433; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2433); r_; });
  V v_c_2438 = heff_tr(heff_call(v_c_2434, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam5_clo)}));
  V f_ = v_c_2438;
  heff_room[0] = heff_dup(v_z_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s322385524x1163007494_lam6, 1, 4, (V[]){v_fresh_241, v_to_243, v_z_246, v_z_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247(V v_rep_240, V v_prog_241, V v_dir_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam1, 1, 5, (V[]){v_hd_243, v_dir_242, v_k_244, v_rep_240, v_prog_241})});
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam5(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam7(V self, V *args) {
  V v_x_2478 = args[0];
  V v_hd_2467 = heff_env(self)[0];
  V v_k_2468 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2478);
  V v_t_2479 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2484})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2485}), v_hd_2467, v_k_2468));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam6(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_dir_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str8), heff_strAppend(v_dir_242, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str9)));
  V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str10)), NTAG(TAG_MkUnit)});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2467, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
  V f_ = heff_dup(heff_rfield(v_hd_2467, 1));
  args[0] = v_t_2477;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam7, 1, 2, (V[]){v_hd_2467, v_k_2468});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x_2430;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    v_x_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    v_x_2430 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){v_y_2429});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V v_t_2431 = (g_std_2epath_2eparse(v_st_2415, heff_dup(v_x_2416)));
  V v_t_2432 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str2)));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = v_st_2415; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_x_2435 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_242), v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2416)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str4)});
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Nothing: {
    heff_drop(v_st_2415);
    heff_drop(v_x_2416);
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    heff_drop_rec(v_x_2435, 6);
    V v_t_2436 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str5), v_dir_242), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str6));
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2436, NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})}));
    V f_ = heff_dup(heff_rfield(v_hd_243, 1));
    heff_room[0] = v_t_2444;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam5, 1, 2, (V[]){v_hd_243, v_k_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_t_2466;
    switch (heff_tag_of(v_x_2430)) {
    case TAG_Nothing: {
      heff_drop(v_x_2416);
      v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2435, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2454 = heff_field(v_x_2430, 0);
      heff_take_n(v_x_2430, 1ULL, 1);
      HeffT2 v_t_2455 = ({ V a_0 = v_text_2454; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_text_2454); r_; });
      {
        V v_field_2457 = v_t_2455.f[1];
        int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
        if ((v_tag_2456 == ((int64_t)0ULL))) {
          heff_drop(v_x_2416);
          V v_p_2458 = v_field_2457;
          heff_drop(v_p_2458);
          v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2435, 1))}));
        } else {
          V v_x_2459 = v_field_2457;
          HeffT2 v_t_2460 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2459));
          {
            V v_field_2462 = v_t_2460.f[1];
            int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
            if ((v_tag_2461 == ((int64_t)0ULL))) {
              heff_drop(v_x_2416);
              V v_x11_2463 = v_field_2462;
              heff_drop(v_x11_2463);
              v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2435, 1))}));
            } else {
              V v_pk_2464 = v_field_2462;
              if (heff_strEq_c(heff_get_n(v_pk_2464, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
                V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2435, 1))}));
                v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1174987838x263480540_clo), 5, (V[]){heff_dup(v_st_2415), heff_dup(v_x_2435), v_x_2416, heff_dup(v_dir_242), v_t_2465}));
              } else {
                heff_drop(v_x_2416);
                v_t_2466 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo), 2, (V[]){heff_dup(v_st_2415), heff_dup(heff_rfield(v_x_2435, 1))}));
              }
            }
          }
        }
      }
      break;
    }
    default: heff_nomatch(v_x_2430);
    }
    return ({ V a_0 = v_rep_240; V a_1 = v_prog_241; V a_2 = v_st_2415; V a_3 = ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str7); V a_4 = v_x_2435; V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam6, 2, 1, (V[]){v_dir_242}); V a_6 = v_t_2466; V a_7 = v_hd_243; V a_8 = v_k_244; V r_ = (g_heff_2ebuild_2ecommands_2ebuildProject_24s1626802978x29287678(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_2415); r_; });
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_2415 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2417 = (g_std_2epath_2eparse(v_st_2415, heff_dup(v_dir_242)));
  V v_t_2418 = (g_std_2epath_2eparse(v_st_2415, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str1)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2415; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_path_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2422 = ({ V a_0 = v_path_2421; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2421); r_; });
  V v_c_2426 = heff_tr(heff_call(v_c_2422, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam3_clo)}));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam4, 1, 7, (V[]){v_st_2415, v_x_2416, v_dir_242, v_hd_243, v_k_244, v_rep_240, v_prog_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_rep_240 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_str0))) {
    v_st_2415 = NTAG(TAG_Windows);
  } else {
    v_st_2415 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s738248804x601756994(heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s1316475582x1790499247_lam2, 1, 6, (V[]){v_st_2415, v_dir_242, v_hd_243, v_k_244, v_rep_240, v_prog_241})));
}