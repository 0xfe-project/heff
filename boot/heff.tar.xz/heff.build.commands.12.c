// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_MakeDirectory 16793
#define TAG_Start 63542
#define TAG_Write 36323
#define LBL_copies 592412158
#define LBL_emits 297985818
#define LBL_expectErrors 18827791
#define LBL_files 298792593
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_library 398066429
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_output 941629484
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_shipTo 1043811586
#define LBL_style 311138763
#define LBL_unchecked 1931098040
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
V g_co_2eop_24s868939913x277534373(V, V, V, V, V, V, V, V, V);
V g_co_2eop_24s868939913x277534373_entry(V self, V *a);
extern Clo g_co_2eop_24s868939913x277534373_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_clo;
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222(V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_clo;
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2ereaches(V, V);
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereaches_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_clo;
V g_heff_2ebuild_2edriver_2einterface(V);
V g_heff_2ebuild_2edriver_2einterface_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2einterface_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s86307863x1047527532(V, V);
V g_list_2efoldl_24s86307863x1047527532_entry(V self, V *a);
extern Clo g_list_2efoldl_24s86307863x1047527532_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereaches_str0, 3, " / ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereaches_str1, 3, " / ");
Clo g_heff_2ebuild_2ecommands_2ereaches_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereaches_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereaches(V v_sel_240, V v_o_241) {
top: ;
  V v_s_242 = heff_get_n(v_o_241, 0, 12);
  V v_xs_243 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ereaches_str0); V a_1 = v_s_242; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2ereaches_str1), v_s_242, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_242); r_; });
  V v_x_244 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
  V v_y_245 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_sel_240));
  return heff_intLe(v_y_245, v_x_244);
}
V g_heff_2ebuild_2ecommands_2ereaches_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereaches(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str1, 2, " (");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str2, 22, " with expected errors)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str3, 27, " files check as they should");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efilesSaid_str5, 2, ", ");
Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efilesSaid_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2efilesSaid(V v_r_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_240, 4)));
  V v_t_242 = heff_intSub(heff_dup(heff_rfield(v_r_240, 0)), v_t_241);
  V v_t_243 = heff_intShow(heff_take_field(v_r_240, 0));
  V v_t_246;
  if (heff_intEq_c(heff_dup(heff_rfield(v_r_240, 1)), MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 8);
    v_t_246 = ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str0);
  } else {
    V v_t_245 = heff_intShow(heff_get_n(v_r_240, 1, 8));
    v_t_246 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str1), heff_strAppend(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str2)));
  }
  V v_t_247 = heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str3), v_t_246));
  V v_t_248 = heff_strAppend(heff_intShow(v_t_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str4), v_t_247));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efilesSaid_str5), v_t_248);
}
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efilesSaid(a[0]);
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222(V v_badLoad_240, V v_cs_241, V v_hd_242, V v_k_243) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_lam0, 1, 4, (V[]){v_cs_241, v_hd_242, heff_dup(v_badLoad_240), v_k_243})));
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_badLoad_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2417);
  if ((heff_dup(v_badLoad_240) == NTAG(TAG_True))) {
    heff_drop(v_badLoad_240);
    heff_drop(v_cs_241);
    V v_t_2418 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_badLoad_240);
    V v_t_2424 = ({ V a_0 = v_cs_241; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_241); r_; });
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2430}), v_hd_242, v_k_243));
    } else {
      heff_drop(v_hd_242);
      heff_drop(v_t_2424);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_badLoad_240 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_244);
  HeffT2 v_t_245 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_241)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_c_249 = v_field_247;
      V v_str_2410 = (g_heff_2ebuild_2edriver_2einterface(v_c_249));
      V v_t_2411 = heff_tag_n(TAG_Write, 2, (V[]){v_str_2410, NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckLast_24s1208954573x2038283222_lam1, 1, 4, (V[]){v_badLoad_240, v_hd_242, v_k_243, v_cs_241})));
    } else {
      heff_drop(v_cs_241);
      heff_drop(v_badLoad_240);
      heff_drop(v_field_247);
      V v_t_2431 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_242, v_k_243));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366(V v_host_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366(v_host_240, v_rest_245));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam1, 2, 3, (V[]){v_c_246, v_s_244, heff_dup(v_host_240)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2414;
  if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_244, 0, 7), v_x_249});
  } else {
    heff_drop(v_x_2413);
    heff_drop_rec(v_s_244, 7);
    v_t_2414 = v_x_249;
  }
  V f_ = v_k_248;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_s_244 = heff_env(self)[0];
  V v_host_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_dup(heff_rfield(v_s_244, 6));
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strSlice(heff_dup(heff_rfield(v_s_244, 0)), MK_INT(0LL), MK_INT(4LL));
    if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_str0))) {
      return ({ V a_0 = v_host_240; V a_1 = heff_dup(v_s_244); V a_2 = v_hd_247; V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam3, 1, 3, (V[]){v_s_244, v_x_249, v_k_248}); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s1402011834x1279192649(a_0, a_1, a_2, a_3)); heff_drop(v_host_240); r_; });
    } else {
      heff_drop_rec(v_s_244, 7);
      heff_drop(v_host_240);
      heff_drop(v_hd_247);
      V f_ = v_k_248;
      args[0] = v_x_249;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop_rec(v_s_244, 7);
    heff_drop(v_host_240);
    heff_drop(v_hd_247);
    heff_drop(v_t_2410);
    V f_ = v_k_248;
    args[0] = v_x_249;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_s_244 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1415869466x1520382366_lam2, 1, 4, (V[]){v_s_244, v_host_240, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_str2, 1, "_");
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118(V v_bi_240, V v_outPath_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2429;
  if (heff_strEq_c_lent(v_id_242, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_str0), 2)) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    v_t_2429 = v_done_245;
  } else {
    V v_ps_2410 = heff_dup(heff_rfield(v_bi_240, 0));
    V v_d_2411 = (g_std_2epath_2ejoin(heff_rfield(v_ps_2410, 5), heff_take_field(v_ps_2410, 0), ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_str1)));
    V v_path_2412 = ({ V b_0 = heff_get_n(v_ps_2410, 5, 6); V a_1 = v_d_2411; V a_2 = heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get()); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_t_2429 = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam0, 2, 7, (V[]){v_path_2412, heff_dup(v_texts_243), v_bi_240, heff_dup(v_out_246), v_id_242, v_backs_244, v_done_245});
  }
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(v_outPath_241, v_t_2429, heff_get_n(v_out_246, 0, 4), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam1(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2428);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_246 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_backs_244 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  V v_k_2414 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2421);
  V v_t_2422 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s86307863x1047527532(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_str2), heff_take_field(v_bi_240, 2)});
  V v_t_2424 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s477184376x1963488659(a_0, a_1)); heff_drop_tag(v_t_2423, 2); r_; });
  V v_t_2425 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_246, 1), heff_take_field(v_out_246, 2), NTAG(TAG_Nil), heff_get_n(v_out_246, 3, 4)});
  V v_t_2426 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2424, v_backs_244}), v_t_2425));
  V v_c_2427 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2422; V a_2 = v_t_2426; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s243477402x512114870(a_0, a_1, a_2)); heff_drop(v_t_2422); heff_drop(v_t_2426); r_; });
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam3, 1, 3, (V[]){v_done_245, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_path_2412 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_id_242 = heff_env(self)[4];
  V v_backs_244 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2412, ((V)&g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam1_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2ejsKeptWritten_24s1764486682x1798331118_lam2, 1, 8, (V[]){v_texts_243, v_bi_240, v_out_246, v_id_242, v_backs_244, v_hd_2413, v_done_245, v_k_2414})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_str2, 17, "building programs");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086(V v_prog_240, V v_st_241, V v_t_242, V v_progs_243, V v_z_244, V v_z_245) {
top: ;
  V v_p_246 = (g_std_2epath_2ejoin(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_str0), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_str1)));
  V v_path_247 = (g_std_2epath_2ejoin(v_st_241, heff_dup(heff_rfield(v_t_242, 0)), v_p_246));
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_247, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam1, 1, 6, (V[]){v_progs_243, v_prog_240, v_z_244, v_st_241, v_t_242, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam0(V self, V *args) {
  V v_ok_248 = args[0];
  return v_ok_248;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam2(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_t_2419 = heff_env(self)[3];
  V v_progs_243 = heff_env(self)[4];
  V v_t_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_prog_240; V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_t_2419; V a_4 = v_progs_243; V a_5 = heff_dup(v_hd_2422); V a_6 = v_k_2423; V a_7 = v_t_2421; V a_8 = v_hd_2422; V r_ = (g_co_2eop_24s868939913x277534373(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_st_241); heff_drop(v_progs_243); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2eshipIn_24s917998919x268217030(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_progs_243), heff_rfield(v_t_242, 4)));
  V v_t_2420 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2418), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2420}));
  V v_t_2424 = ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_dup(v_st_241); V a_2 = heff_dup(v_t_242); V a_3 = v_x_2418; V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam4, 2, 6, (V[]){v_prog_240, v_st_241, v_t_242, v_t_2419, heff_dup(v_progs_243), v_t_2421}); V a_5 = v_progs_243; V r_ = (g_heff_2ebuild_2ecommands_2ebuildEach_24s977377227x1307457545(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  V v_total_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2417 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_str2), v_total_2415, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam2_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2417, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1780172163x783207086_lam3, 1, 6, (V[]){v_prog_240, v_st_241, v_t_242, v_progs_243, v_z_244, v_z_245})));
}