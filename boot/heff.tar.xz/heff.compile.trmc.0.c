// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_arity 294440695
#define LBL_key 315609
V g_heff_2ecompile_2etrmc_2eanyTail(V, V);
V g_heff_2ecompile_2etrmc_2eanyTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eanyTail_clo;
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2eatTails(V, V);
V g_heff_2ecompile_2etrmc_2eatTails_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eatTails_clo;
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(V, V, V);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2egather(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egather_clo;
V g_heff_2ecompile_2etrmc_2ehole_get(void);
V g_heff_2ecompile_2etrmc_2eholesAt(V, V);
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eholesAt_clo;
HeffT2 g_heff_2ecompile_2etrmc_2elastOf_24cpr(V);
V g_heff_2ecompile_2etrmc_2eselfCall(V, V);
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eselfCall_clo;
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void);
V g_heff_2ecompile_2etrmc_2estartAcc(V, V, V);
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartAcc_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2etraverse_24s1019364152x1582657694(V, V);
V g_prelude_2etraverse_24s1019364152x1582657694_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1019364152x1582657694_clo;
HEFF_LIT(g_heff_2ecompile_2etrmc_2esetFieldPrim_str0, 8, "setField");

static V g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2esetFieldPrim_st;
static V g_heff_2ecompile_2etrmc_2esetFieldPrim_init(void) {
  return ((V)&g_heff_2ecompile_2etrmc_2esetFieldPrim_str0);
}
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2esetFieldPrim_st)) return g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2esetFieldPrim_val, &g_heff_2ecompile_2etrmc_2esetFieldPrim_st, g_heff_2ecompile_2etrmc_2esetFieldPrim_init);
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2ehole_str0, 4, "hole");

static V g_heff_2ecompile_2etrmc_2ehole_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2ehole_st;
static V g_heff_2ecompile_2etrmc_2ehole_init(void) {
  return heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2etrmc_2ehole_str0), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2etrmc_2ehole_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2ehole_st)) return g_heff_2ecompile_2etrmc_2ehole_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2ehole_val, &g_heff_2ecompile_2etrmc_2ehole_st, g_heff_2ecompile_2etrmc_2ehole_init);
}
Clo g_heff_2ecompile_2etrmc_2eselfCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eselfCall_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eselfCall(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2425 = heff_field(v_x2_241, 0);
    V v_args_2426 = heff_field(v_x2_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(v_g_2425), heff_dup(heff_rfield(v_s_240, 0))) && ({ V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2426)); int c_ = heff_intEq_c(heff_dup(v_t_2428), heff_dup(heff_rfield(v_s_240, 1))); heff_drop(v_t_2428); c_; })));
    heff_drop_rec(v_s_240, 2);
    return v_ret_24bool;
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eselfCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2etrmc_2econsEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2econsEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2econsEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    HeffT2 v_t_2420 = (g_heff_2ecompile_2etrmc_2elastOf_24cpr(v_args_2418));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_l_2424 = v_field_2422;
        V v_t_2425 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_l_2424));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_s_240);
          heff_drop(v_l_2424);
          heff_drop(v_t_2425);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_2425);
          V t_0 = v_s_240;
          V t_1 = v_l_2424;
          v_s_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_field_2422);
        return NTAG(TAG_False);
      }
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2econsEnds(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eanyTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eanyTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eanyTail_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eanyTail(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_p_240;
    V t_1 = v_b_2410;
    v_p_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_arms_2421 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eanyTail_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2421; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2421); r_; });
  }
  case TAG_EPrim: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eanyTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eanyTail(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eanyTail_lam0(V self, V *args) {
  V v_a_2422 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_a_2422)) {
  case TAG_MkArm: {
    V v_b_2425 = heff_field(v_a_2422, 2);
    heff_take_n(v_a_2422, 4ULL, 3);
    v_t_2426 = v_b_2425;
    break;
  }
  default: heff_nomatch(v_a_2422);
  }
  return (g_heff_2ecompile_2etrmc_2eanyTail(v_p_240, v_t_2426));
}
V g_heff_2ecompile_2etrmc_2eatTails_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam3(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eatTails_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eatTails_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eatTails(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_sc_2425 = heff_field(v_e_241, 0);
    V v_arms_2426 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2436 = (g_prelude_2etraverse_24s1019364152x1582657694(heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam1, 1, 1, (V[]){v_f_240}), v_arms_2426));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam3, 1, 2, (V[]){v_m_2436, v_sc_2425});
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eatTails(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eatTails_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam2(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_t_2428 = heff_env(self)[1];
  V v_vs_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2428, v_vs_2429, v_x_2434}), v_n_2435});
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam1(V self, V *args) {
  V v_arm_2427 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_arm_2427)) {
  case TAG_MkArm: {
    V v_t_2428 = heff_field(v_arm_2427, 0);
    V v_vs_2429 = heff_field(v_arm_2427, 1);
    V v_b_2430 = heff_field(v_arm_2427, 2);
    heff_take_n(v_arm_2427, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2430));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam2, 1, 3, (V[]){v_m_2431, v_t_2428, v_vs_2429});
  }
  default: return heff_nomatch(v_arm_2427);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam3(V self, V *args) {
  V v_n_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_sc_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_n_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2425, v_x_2439}), v_n_2440});
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eholesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eholesAt_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eholesAt(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 4ULL, 3);
    V t_0 = v_s_240;
    V t_1 = v_b_2410;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    HeffT2 v_t_2420 = (g_heff_2ecompile_2etrmc_2elastOf_24cpr(heff_dup(v_args_2418)));
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      if ((v_tag_2421 == ((int64_t)0ULL))) {
        V v_l_2424 = v_field_2422;
        V v_t_2425 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_l_2424));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_s_240);
          heff_drop(v_l_2424);
          heff_drop(v_t_2425);
          V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2418; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2418); r_; });
          return heff_tag_n(TAG_Cons, 2, (V[]){heff_intSub(v_t_2426, MK_INT(1LL)), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_args_2418);
          heff_drop(v_t_2425);
          V v_t_2427 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_l_2424)));
          if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
            heff_drop(v_t_2427);
            V t_0 = v_s_240;
            V t_1 = v_l_2424;
            v_s_240 = t_0;
            v_x2_241 = t_1;
            goto top;
          } else {
            heff_drop(v_s_240);
            heff_drop(v_l_2424);
            heff_drop(v_t_2427);
            return NTAG(TAG_Nil);
          }
        }
      } else {
        heff_drop(v_s_240);
        heff_drop(v_args_2418);
        heff_drop(v_field_2422);
        return NTAG(TAG_Nil);
      }
    }
  }
  case TAG_EMatch: {
    V v_arms_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2429));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eholesAt_lam0, 2, 1, (V[]){v_s_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eholesAt(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eholesAt_lam0(V self, V *args) {
  V v_acc_2431 = args[0];
  V v_x_2432 = args[1];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_MkArm: {
    V v_b_2435 = heff_field(v_x_2432, 2);
    heff_take_n(v_x_2432, 4ULL, 3);
    v_t_2436 = v_b_2435;
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  V v_t_2437 = (g_heff_2ecompile_2etrmc_2eholesAt(v_s_240, v_t_2436));
  return (g_prelude_2e_2b_2b(v_t_2437, v_acc_2431));
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str1, 1, "s");
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam22(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam23(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartAcc_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartAcc(V v_s_240, V v_ak_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2eappendEnds(heff_dup(v_s_240), v_e_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam0, 1, 1, (V[]){v_e_242});
    }
    case TAG_EGlobal: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam1, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELam: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam2, 1, 1, (V[]){v_e_242});
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam3, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam4, 1, 1, (V[]){v_e_242});
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam5, 1, 1, (V[]){v_e_242});
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam6, 1, 1, (V[]){v_e_242});
    }
    case TAG_ETag: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam7, 1, 1, (V[]){v_e_242});
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam8, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam9, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrimCall: {
      V v_it2_2436 = heff_dup(heff_field(v_e_242, 1));
      switch (heff_tag_of(v_it2_2436)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam10, 1, 1, (V[]){v_e_242});
      }
      case TAG_Cons: {
        V v_a_2438 = heff_field(v_it2_2436, 0);
        V v_it22_2439 = heff_field(v_it2_2436, 1);
        heff_take_n(v_it2_2436, 3ULL, 2);
        switch (heff_tag_of(v_it22_2439)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_a_2438);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam11, 1, 1, (V[]){v_e_242});
        }
        case TAG_Cons: {
          V v_r_2441 = heff_field(v_it22_2439, 0);
          V v_it222_2442 = heff_field(v_it22_2439, 1);
          heff_take_n(v_it22_2439, 3ULL, 2);
          switch (heff_tag_of(v_it222_2442)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 2);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam12, 1, 4, (V[]){v_s_240, v_ak_241, v_r_2441, v_a_2438});
          }
          case TAG_Cons: {
            heff_take_n(v_it222_2442, 0ULL, 2);
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_a_2438);
            heff_drop(v_r_2441);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam13, 1, 1, (V[]){v_e_242});
          }
          default: return heff_nomatch(v_it222_2442);
          }
        }
        default: return heff_nomatch(v_it22_2439);
        }
      }
      default: return heff_nomatch(v_it2_2436);
      }
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam14, 1, 1, (V[]){v_e_242});
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam15, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam16, 1, 1, (V[]){v_e_242});
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam17, 1, 1, (V[]){v_e_242});
    }
    case TAG_EBytes: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam18, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFixed: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam19, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat32: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam20, 1, 1, (V[]){v_e_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam21, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam22, 1, 1, (V[]){v_e_242});
    }
    default: return heff_nomatch(v_e_242);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_ak_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam23, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartAcc(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_245});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_247});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args) {
  V v_n_2410 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2410});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2413});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args) {
  V v_n_2417 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2417});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args) {
  V v_n_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam6(V self, V *args) {
  V v_n_2425 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2425});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam7(V self, V *args) {
  V v_n_2429 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2429});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam8(V self, V *args) {
  V v_n_2432 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2432});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam9(V self, V *args) {
  V v_n_2434 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2434});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam10(V self, V *args) {
  V v_n_2437 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2437});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam11(V self, V *args) {
  V v_n_2440 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2440});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam12(V self, V *args) {
  V v_n_2443 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2441 = heff_env(self)[2];
  V v_a_2438 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2444 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str0), heff_intShow(heff_dup(v_n_2443)));
  V v_t_2445 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str1), v_t_2444);
  V v_m_2446 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2445)}), v_r_2441));
  V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){heff_intAdd(v_n_2443, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkPair: {
    V v_x_2448 = heff_field(v_x2_2447, 0);
    V v_n_2449 = heff_field(v_x2_2447, 1);
    V v_ru_24x2_2447_24MkPair = heff_take_reuse_n(v_x2_2447, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2447_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2445, v_a_2438, v_x_2448}), v_n_2449});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam13(V self, V *args) {
  V v_n_2452 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2452});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam14(V self, V *args) {
  V v_n_2455 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2455});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam15(V self, V *args) {
  V v_n_2457 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2457});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam16(V self, V *args) {
  V v_n_2459 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2459});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam17(V self, V *args) {
  V v_n_2461 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2461});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam18(V self, V *args) {
  V v_n_2463 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2463});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam19(V self, V *args) {
  V v_n_2466 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2466});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam20(V self, V *args) {
  V v_n_2468 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2468});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam21(V self, V *args) {
  V v_n_2469 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2469});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam22(V self, V *args) {
  V v_n_2472 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2472});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam23(V self, V *args) {
  V v_n_2473 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2473});
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam3(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(v_lit_240, v_lit_241, v_b_2411));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam0, 1, 3, (V[]){v_m_2412, v_x_249, v_a_2410});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EMatch: {
    V v_sc_2426 = heff_field(v_e_242, 0);
    V v_arms_2427 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s1019364152x1582657694(heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam1, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2427));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam3, 1, 2, (V[]){v_m_2437, v_sc_2426});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_249, v_a_2410, v_x_2415}), v_n_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_vs_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2429, v_vs_2430, v_x_2435}), v_n_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam1(V self, V *args) {
  V v_arm_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2428)) {
  case TAG_MkArm: {
    V v_t_2429 = heff_field(v_arm_2428, 0);
    V v_vs_2430 = heff_field(v_arm_2428, 1);
    V v_b_2431 = heff_field(v_arm_2428, 2);
    heff_take_n(v_arm_2428, 7ULL, 3);
    V v_m_2432 = (g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700(v_lit_240, v_lit_241, v_b_2431));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam2, 1, 3, (V[]){v_m_2432, v_t_2429, v_vs_2430});
  }
  default: return heff_nomatch(v_arm_2428);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_24s1851510598x747725700_lam3(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_sc_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2426, v_x_2440}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}