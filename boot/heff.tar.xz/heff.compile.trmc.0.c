// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_arity 294440695
#define LBL_key 315609
V g_heff_2ecompile_2etrmc_2eanyTail(V, V);
V g_heff_2ecompile_2etrmc_2eanyTail_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eanyTail_clo;
V g_heff_2ecompile_2etrmc_2eappendEnds(V, V);
V g_heff_2ecompile_2etrmc_2eappendEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eappendEnds_clo;
V g_heff_2ecompile_2etrmc_2eatTails(V, V);
V g_heff_2ecompile_2etrmc_2eatTails_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eatTails_clo;
V g_heff_2ecompile_2etrmc_2econsEnds(V, V);
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2econsEnds_clo;
V g_heff_2ecompile_2etrmc_2egather(V, V, V, V);
V g_heff_2ecompile_2etrmc_2egather_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2egather_clo;
V g_heff_2ecompile_2etrmc_2ehole_get(void);
V g_heff_2ecompile_2etrmc_2eholesAt(V, V);
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eholesAt_clo;
V g_heff_2ecompile_2etrmc_2elastOf(V);
V g_heff_2ecompile_2etrmc_2elastOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2elastOf_clo;
V g_heff_2ecompile_2etrmc_2eselfCall(V, V);
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2eselfCall_clo;
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void);
V g_heff_2ecompile_2etrmc_2estartAcc(V, V, V);
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartAcc_clo;
V g_heff_2ecompile_2etrmc_2etraverseS(V, V);
V g_heff_2ecompile_2etrmc_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2etraverseS_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2ecompile_2etrmc_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2etrmc_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2etrmc_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2etrmc_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2etraverseS_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2etrmc_2etraverseS_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2etrmc_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2esetFieldPrim_str0, 8, "setField");

static V g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2esetFieldPrim_st;
static V g_heff_2ecompile_2etrmc_2esetFieldPrim_init(void) {
  return ((V)&g_heff_2ecompile_2etrmc_2esetFieldPrim_str0);
}
V g_heff_2ecompile_2etrmc_2esetFieldPrim_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2esetFieldPrim_st)) return g_heff_2ecompile_2etrmc_2esetFieldPrim_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2esetFieldPrim_val, &g_heff_2ecompile_2etrmc_2esetFieldPrim_st, g_heff_2ecompile_2etrmc_2esetFieldPrim_init);
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2ehole_str0, 4, "hole");

static V g_heff_2ecompile_2etrmc_2ehole_val;
static HEFF_ONCE g_heff_2ecompile_2etrmc_2ehole_st;
static V g_heff_2ecompile_2etrmc_2ehole_init(void) {
  return heff_tag_n(TAG_EPrimCall, 2, (V[]){((V)&g_heff_2ecompile_2etrmc_2ehole_str0), NTAG(TAG_Nil)});
}
V g_heff_2ecompile_2etrmc_2ehole_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2etrmc_2ehole_st)) return g_heff_2ecompile_2etrmc_2ehole_val;
  return heff_global(&g_heff_2ecompile_2etrmc_2ehole_val, &g_heff_2ecompile_2etrmc_2ehole_st, g_heff_2ecompile_2etrmc_2ehole_init);
}
Clo g_heff_2ecompile_2etrmc_2eselfCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eselfCall_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eselfCall(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    V v_g_2424 = heff_field(v_x2_241, 0);
    V v_as_2425 = heff_field(v_x2_241, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(v_g_2424), heff_dup(heff_rfield(v_s_240, 0))) && ({ V v_t_2427 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2425)); int c_ = heff_intEq_c(heff_dup(v_t_2427), heff_dup(heff_rfield(v_s_240, 1))); heff_drop(v_t_2427); c_; })));
    heff_drop_rec(v_s_240, 2);
    return v_ret_24bool;
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eselfCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2etrmc_2eselfCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2etrmc_2econsEnds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2econsEnds_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2econsEnds(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_as_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2419 = ({ V a_0 = v_as_2418; V r_ = (g_heff_2ecompile_2etrmc_2elastOf(a_0)); heff_drop(v_as_2418); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      heff_drop(v_s_240);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_l_2420 = heff_field(v_t_2419, 0);
      heff_take_n(v_t_2419, 1ULL, 1);
      V v_t_2421 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_l_2420));
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_s_240);
        heff_drop(v_l_2420);
        heff_drop(v_t_2421);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2421);
        V t_0 = v_s_240;
        V t_1 = v_l_2420;
        v_s_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2econsEnds_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2econsEnds(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eanyTail_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eanyTail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eanyTail_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eanyTail(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 4ULL, 3);
    V t_0 = v_p_240;
    V t_1 = v_b_2410;
    v_p_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_arms_2420 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eanyTail_lam0, 1, 1, (V[]){v_p_240}); V a_1 = v_arms_2420; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_arms_2420); r_; });
  }
  case TAG_EPrim: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_p_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eanyTail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eanyTail(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eanyTail_lam0(V self, V *args) {
  V v_a_2421 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2425;
  switch (heff_tag_of(v_a_2421)) {
  case TAG_MkArm: {
    V v_b_2424 = heff_field(v_a_2421, 2);
    heff_take_n(v_a_2421, 4ULL, 3);
    v_t_2425 = v_b_2424;
    break;
  }
  default: heff_nomatch(v_a_2421);
  }
  return (g_heff_2ecompile_2etrmc_2eanyTail(v_p_240, v_t_2425));
}
V g_heff_2ecompile_2etrmc_2eatTails_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2eatTails_lam3(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eatTails_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eatTails_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eatTails(V v_f_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EApp: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ELet: {
    V v_x_248 = heff_field(v_e_241, 0);
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_2411 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2410));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam0, 1, 3, (V[]){v_m_2411, v_x_248, v_a_249});
  }
  case TAG_ERecord: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EProj: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ETag: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EMatch: {
    V v_sc_2424 = heff_field(v_e_241, 0);
    V v_arms_2425 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_2435 = (g_heff_2ecompile_2etrmc_2etraverseS(heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam1, 1, 1, (V[]){v_f_240}), v_arms_2425));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam3, 1, 2, (V[]){v_m_2435, v_sc_2424});
  }
  case TAG_EPrim: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_ECall: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    return heff_tail(v_f_240, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eatTails(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eatTails_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_a_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_n_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_248, v_a_249, v_x_2414}), v_n_2415});
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam2(V self, V *args) {
  V v_n_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_t_2427 = heff_env(self)[1];
  V v_vs_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_n_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_n_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2427, v_vs_2428, v_x_2433}), v_n_2434});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam1(V self, V *args) {
  V v_arm_2426 = args[0];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_arm_2426)) {
  case TAG_MkArm: {
    V v_t_2427 = heff_field(v_arm_2426, 0);
    V v_vs_2428 = heff_field(v_arm_2426, 1);
    V v_b_2429 = heff_field(v_arm_2426, 2);
    heff_take_n(v_arm_2426, 7ULL, 3);
    V v_m_2430 = heff_tr(g_heff_2ecompile_2etrmc_2eatTails(v_f_240, v_b_2429));
    return heff_clo_n(g_heff_2ecompile_2etrmc_2eatTails_lam2, 1, 3, (V[]){v_m_2430, v_t_2427, v_vs_2428});
  }
  default: return heff_nomatch(v_arm_2426);
  }
}
V g_heff_2ecompile_2etrmc_2eatTails_lam3(V self, V *args) {
  V v_n_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_sc_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_n_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x2_2437, 0);
    V v_n_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24MkPair = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2424, v_x_2438}), v_n_2439});
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_lam0(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2eholesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2eholesAt_entry, 2, 0};

V g_heff_2ecompile_2etrmc_2eholesAt(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_2410 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 4ULL, 3);
    V t_0 = v_s_240;
    V t_1 = v_b_2410;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    V v_as_2418 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    V v_t_2419 = (g_heff_2ecompile_2etrmc_2elastOf(v_as_2418));
    switch (heff_tag_of(v_t_2419)) {
    case TAG_Nothing: {
      heff_drop(v_s_240);
      heff_drop(v_as_2418);
      heff_drop_cell(v_ru_24x2_241_24ETag, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_l_2420 = heff_field(v_t_2419, 0);
      heff_take_n(v_t_2419, 1ULL, 1);
      V v_t_2421 = (g_heff_2ecompile_2etrmc_2eselfCall(heff_dup(v_s_240), v_l_2420));
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_s_240);
        heff_drop(v_l_2420);
        heff_drop(v_t_2421);
        V v_t_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_2418; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_as_2418); r_; });
        return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_Cons, 2, (V[]){heff_intSub(v_t_2422, MK_INT(1LL)), NTAG(TAG_Nil)});
      } else {
        heff_drop(v_as_2418);
        heff_drop_cell(v_ru_24x2_241_24ETag, 2);
        heff_drop(v_t_2421);
        V v_t_2423 = (g_heff_2ecompile_2etrmc_2econsEnds(heff_dup(v_s_240), heff_dup(v_l_2420)));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_t_2423);
          V t_0 = v_s_240;
          V t_1 = v_l_2420;
          v_s_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_s_240);
          heff_drop(v_l_2420);
          heff_drop(v_t_2423);
          return NTAG(TAG_Nil);
        }
      }
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_EMatch: {
    V v_arms_2425 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2425));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2etrmc_2eholesAt_lam0, 2, 1, (V[]){v_s_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_s_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2etrmc_2eholesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2eholesAt(a[0], a[1]);
}
V g_heff_2ecompile_2etrmc_2eholesAt_lam0(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432;
  switch (heff_tag_of(v_x_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_x_2428, 2);
    heff_take_n(v_x_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_x_2428);
  }
  V v_t_2433 = (g_heff_2ecompile_2etrmc_2eholesAt(v_s_240, v_t_2432));
  return (g_prelude_2e_2b_2b(v_t_2433, v_acc_2427));
}
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2etrmc_2estartAcc_str1, 1, "s");
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam6(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam7(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam8(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam9(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam10(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam11(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam12(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam13(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam14(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam15(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam16(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam17(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam18(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam19(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam20(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam21(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam22(V self, V *args);
V g_heff_2ecompile_2etrmc_2estartAcc_lam23(V self, V *args);
Clo g_heff_2ecompile_2etrmc_2estartAcc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2etrmc_2estartAcc_entry, 3, 0};

V g_heff_2ecompile_2etrmc_2estartAcc(V v_s_240, V v_ak_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2etrmc_2eappendEnds(heff_dup(v_s_240), v_e_242));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    switch (heff_tag_of(v_e_242)) {
    case TAG_EVar: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam0, 1, 1, (V[]){v_e_242});
    }
    case TAG_EGlobal: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam1, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELam: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam2, 1, 1, (V[]){v_e_242});
    }
    case TAG_EApp: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam3, 1, 1, (V[]){v_e_242});
    }
    case TAG_ELet: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam4, 1, 1, (V[]){v_e_242});
    }
    case TAG_ERecord: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam5, 1, 1, (V[]){v_e_242});
    }
    case TAG_EProj: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam6, 1, 1, (V[]){v_e_242});
    }
    case TAG_ETag: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam7, 1, 1, (V[]){v_e_242});
    }
    case TAG_EMatch: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam8, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrim: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam9, 1, 1, (V[]){v_e_242});
    }
    case TAG_EPrimCall: {
      V v_it2_2435 = heff_dup(heff_field(v_e_242, 1));
      switch (heff_tag_of(v_it2_2435)) {
      case TAG_Nil: {
        heff_drop(v_s_240);
        heff_drop(v_ak_241);
        return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam10, 1, 1, (V[]){v_e_242});
      }
      case TAG_Cons: {
        V v_a_2437 = heff_field(v_it2_2435, 0);
        V v_it22_2438 = heff_field(v_it2_2435, 1);
        heff_take_n(v_it2_2435, 3ULL, 2);
        switch (heff_tag_of(v_it22_2438)) {
        case TAG_Nil: {
          heff_drop(v_s_240);
          heff_drop(v_ak_241);
          heff_drop(v_a_2437);
          return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam11, 1, 1, (V[]){v_e_242});
        }
        case TAG_Cons: {
          V v_r_2440 = heff_field(v_it22_2438, 0);
          V v_it222_2441 = heff_field(v_it22_2438, 1);
          heff_take_n(v_it22_2438, 3ULL, 2);
          switch (heff_tag_of(v_it222_2441)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 2);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam12, 1, 4, (V[]){v_s_240, v_ak_241, v_r_2440, v_a_2437});
          }
          case TAG_Cons: {
            heff_take_n(v_it222_2441, 0ULL, 2);
            heff_drop(v_s_240);
            heff_drop(v_ak_241);
            heff_drop(v_a_2437);
            heff_drop(v_r_2440);
            return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam13, 1, 1, (V[]){v_e_242});
          }
          default: return heff_nomatch(v_it222_2441);
          }
        }
        default: return heff_nomatch(v_it22_2438);
        }
      }
      default: return heff_nomatch(v_it2_2435);
      }
    }
    case TAG_ECall: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam14, 1, 1, (V[]){v_e_242});
    }
    case TAG_EInt: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam15, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam16, 1, 1, (V[]){v_e_242});
    }
    case TAG_EStr: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam17, 1, 1, (V[]){v_e_242});
    }
    case TAG_EBytes: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam18, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFixed: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam19, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFloat32: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam20, 1, 1, (V[]){v_e_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam21, 1, 1, (V[]){v_e_242});
    }
    case TAG_EFix: {
      heff_drop(v_s_240);
      heff_drop(v_ak_241);
      return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam22, 1, 1, (V[]){v_e_242});
    }
    default: return heff_nomatch(v_e_242);
    }
  } else {
    heff_drop(v_s_240);
    heff_drop(v_ak_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2ecompile_2etrmc_2estartAcc_lam23, 1, 1, (V[]){v_e_242});
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2etrmc_2estartAcc(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_245});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_247});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam2(V self, V *args) {
  V v_n_2410 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2410});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam3(V self, V *args) {
  V v_n_2413 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2413});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam4(V self, V *args) {
  V v_n_2417 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2417});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam5(V self, V *args) {
  V v_n_2420 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2420});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam6(V self, V *args) {
  V v_n_2425 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2425});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam7(V self, V *args) {
  V v_n_2428 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2428});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam8(V self, V *args) {
  V v_n_2431 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2431});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam9(V self, V *args) {
  V v_n_2433 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2433});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam10(V self, V *args) {
  V v_n_2436 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2436});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam11(V self, V *args) {
  V v_n_2439 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2439});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam12(V self, V *args) {
  V v_n_2442 = args[0];
  V v_s_240 = heff_env(self)[0];
  V v_ak_241 = heff_env(self)[1];
  V v_r_2440 = heff_env(self)[2];
  V v_a_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str0), heff_intShow(heff_dup(v_n_2442)));
  V v_x_2444 = heff_strAppend(((V)&g_heff_2ecompile_2etrmc_2estartAcc_str1), v_t_2443);
  V v_m_2445 = (g_heff_2ecompile_2etrmc_2egather(v_s_240, v_ak_241, heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2444)}), v_r_2440));
  V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){heff_intAdd(v_n_2442, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_n_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2444, v_a_2437, v_x_2447}), v_n_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam13(V self, V *args) {
  V v_n_2451 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2451});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam14(V self, V *args) {
  V v_n_2454 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2454});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam15(V self, V *args) {
  V v_n_2456 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2456});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam16(V self, V *args) {
  V v_n_2458 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2458});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam17(V self, V *args) {
  V v_n_2460 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2460});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam18(V self, V *args) {
  V v_n_2462 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2462});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam19(V self, V *args) {
  V v_n_2465 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2465});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam20(V self, V *args) {
  V v_n_2467 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2467});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam21(V self, V *args) {
  V v_n_2468 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2468});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam22(V self, V *args) {
  V v_n_2471 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2471});
}
V g_heff_2ecompile_2etrmc_2estartAcc_lam23(V self, V *args) {
  V v_n_2472 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_n_2472});
}