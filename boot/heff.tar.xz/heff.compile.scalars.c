// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_GivenBuilt 47694
#define TAG_GivenMany 26952
#define TAG_GivenOne 45466
#define TAG_GivenOther 31238
#define TAG_GivenSame 9069
#define TAG_MkArm 55352
#define TAG_NoneGiven 36085
#define TAG_OfRecords 55355
#define TAG_OfTags 60669
#define TAG_ShapeRecord 31660
#define TAG_ShapeTag 9776
#define TAG_Tip 31527
#define LBL_args 9498020
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_def 308863
#define LBL_key 315609
#define LBL_last 9809757
#define LBL_name 9869138
#define LBL_param 307795111
#define LBL_shape 310758331
#define LBL_slots 310891087
#define LBL_tys 324872
#define LBL_vars 10107635
#define LBL_worker 1165056681
static uint32_t shape_at__param__shape__tys__vars[] = {LBL_at, LBL_param, LBL_shape, LBL_tys, LBL_vars};
static uint32_t shape_def__slots[] = {LBL_def, LBL_slots};
static uint32_t shape_key__body__last__args[] = {LBL_key, LBL_body, LBL_last, LBL_args};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__worker__slots[] = {LBL_key, LBL_worker, LBL_slots};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(V, V);
V g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903_clo;
V g_heff_2ecompile_2eir_2ewaysOnto(V, V);
V g_heff_2ecompile_2eir_2ewaysOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysOnto_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2escalars_2eargsRw(V, V, V, V);
V g_heff_2ecompile_2escalars_2eargsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eargsRw_clo;
V g_heff_2ecompile_2escalars_2ebindsPassedW(V, V, V);
V g_heff_2ecompile_2escalars_2ebindsPassedW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ebindsPassedW_clo;
V g_heff_2ecompile_2escalars_2ecallersRw(V, V);
V g_heff_2ecompile_2escalars_2ecallersRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallersRw_clo;
V g_heff_2ecompile_2escalars_2ecallsLoopW(V, V);
V g_heff_2ecompile_2escalars_2ecallsLoopW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallsLoopW_clo;
V g_heff_2ecompile_2escalars_2ecallsW(V, V, V);
V g_heff_2ecompile_2escalars_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallsW_clo;
V g_heff_2ecompile_2escalars_2edefWith(V, V, V);
V g_heff_2ecompile_2escalars_2edefWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2edefWith_clo;
V g_heff_2ecompile_2escalars_2eexitsWhole(V, V, V, V);
V g_heff_2ecompile_2escalars_2eexitsWhole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eexitsWhole_clo;
V g_heff_2ecompile_2escalars_2efirstApart(V, V, V);
V g_heff_2ecompile_2escalars_2efirstApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2efirstApart_clo;
V g_heff_2ecompile_2escalars_2efoundWith(V, V, V);
V g_heff_2ecompile_2escalars_2efoundWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2efoundWith_clo;
V g_heff_2ecompile_2escalars_2egivenOf(V, V);
V g_heff_2ecompile_2escalars_2egivenOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2egivenOf_clo;
V g_heff_2ecompile_2escalars_2ejustsOf(V);
V g_heff_2ecompile_2escalars_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ejustsOf_clo;
V g_heff_2ecompile_2escalars_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2escalars_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2escalars_2elabelVar(V, V, V);
V g_heff_2ecompile_2escalars_2elabelVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2elabelVar_clo;
V g_heff_2ecompile_2escalars_2elamWholeW(V, V, V, V);
V g_heff_2ecompile_2escalars_2elamWholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2elamWholeW_clo;
V g_heff_2ecompile_2escalars_2eloopDefs(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eloopDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eloopDefs_clo;
V g_heff_2ecompile_2escalars_2ematchRw(V, V, V, V);
V g_heff_2ecompile_2escalars_2ematchRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ematchRw_clo;
V g_heff_2ecompile_2escalars_2ematchRw_24tok2(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ematchRw_24tok2_clo;
V g_heff_2ecompile_2escalars_2eparamsRw(V, V, V);
V g_heff_2ecompile_2escalars_2eparamsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eparamsRw_clo;
V g_heff_2ecompile_2escalars_2epassedOnly(V, V, V);
V g_heff_2ecompile_2escalars_2epassedOnly_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2epassedOnly_clo;
V g_heff_2ecompile_2escalars_2epassedW(V, V, V, V);
V g_heff_2ecompile_2escalars_2epassedW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2epassedW_clo;
V g_heff_2ecompile_2escalars_2erw(V, V);
V g_heff_2ecompile_2escalars_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2erw_clo;
V g_heff_2ecompile_2escalars_2esameLabels(V, V);
V g_heff_2ecompile_2escalars_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esameLabels_clo;
V g_heff_2ecompile_2escalars_2eslotWith(V, V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotWith_clo;
V g_heff_2ecompile_2escalars_2eslotsOf(V, V);
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsOf_clo;
V g_heff_2ecompile_2escalars_2esomeApart(V, V);
V g_heff_2ecompile_2escalars_2esomeApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esomeApart_clo;
V g_heff_2ecompile_2escalars_2esplitIn(V, V, V);
V g_heff_2ecompile_2escalars_2esplitIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esplitIn_clo;
V g_heff_2ecompile_2escalars_2esplits(V, V);
V g_heff_2ecompile_2escalars_2esplits_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esplits_clo;
V g_heff_2ecompile_2escalars_2etakesApart(V, V, V, V);
V g_heff_2ecompile_2escalars_2etakesApart_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2etakesApart_clo;
V g_heff_2ecompile_2escalars_2ewholeW(V, V, V, V);
V g_heff_2ecompile_2escalars_2ewholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewholeW_clo;
V g_heff_2ecompile_2escalars_2ewithVars(V);
V g_heff_2ecompile_2escalars_2ewithVars_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewithVars_clo;
V g_heff_2ecompile_2escalars_2ewrapArgs(V, V, V);
V g_heff_2ecompile_2escalars_2ewrapArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewrapArgs_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efind_24s1498631415x1735266116(V, V);
V g_list_2efind_24s1498631415x1735266116_entry(V self, V *a);
extern Clo g_list_2efind_24s1498631415x1735266116_clo;
HeffT2 g_list_2efind_24s1498631415x1735266116_24cpr(V, V);
V g_list_2efind_24s1498631415x1735266116_24tok1(V, V, V);
V g_list_2efind_24s1498631415x1735266116_24tok1_entry(V self, V *a);
extern Clo g_list_2efind_24s1498631415x1735266116_24tok1_clo;
HeffT2 g_list_2efind_24s1508082563x149957932_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f2005293661x823011722(V, V, V);
V g_list_2efoldl_24f2005293661x823011722_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2005293661x823011722_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24f811568015x381874646(V, V, V, V);
V g_list_2efoldl_24f811568015x381874646_entry(V self, V *a);
extern Clo g_list_2efoldl_24f811568015x381874646_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1682887903x724363097(V, V, V);
V g_list_2efoldl_24s1682887903x724363097_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1682887903x724363097_clo;
V g_list_2efoldl_24s2127176832x914341824(V, V);
V g_list_2efoldl_24s2127176832x914341824_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127176832x914341824_clo;
V g_list_2efoldl_24s2146051398x720013633(V, V);
V g_list_2efoldl_24s2146051398x720013633_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2146051398x720013633_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1809017761x1063871171_24tok1(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok1_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok1_clo;
V g_list_2emap_24s1809017761x1063871171_24tok2(V, V);
V g_list_2emap_24s1809017761x1063871171_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s813634804x1844296865(V);
V g_list_2emap_24s813634804x1844296865_entry(V self, V *a);
extern Clo g_list_2emap_24s813634804x1844296865_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
V g_list_2ezipWith_24s634961829x758866838(V, V);
V g_list_2ezipWith_24s634961829x758866838_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s634961829x758866838_clo;
V g_list_2ezipWith_24s919837080x1979082626(V, V, V, V);
V g_list_2ezipWith_24s919837080x1979082626_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s919837080x1979082626_clo;
HeffT2 g_prelude_2etraverse_24s1206798274x929612205_24cpr(V, V);
V g_prelude_2etraverse_24s1232682027x654714928(V);
V g_prelude_2etraverse_24s1232682027x654714928_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1232682027x654714928_clo;
V g_prelude_2etraverse_24s205209257x1087869143(V, V);
V g_prelude_2etraverse_24s205209257x1087869143_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s205209257x1087869143_clo;
V g_prelude_2etraverse_24s75890152x1871550235(V, V, V, V);
V g_prelude_2etraverse_24s75890152x1871550235_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s75890152x1871550235_clo;
V g_prelude_2etraverse_24s763866529x146151572(V);
V g_prelude_2etraverse_24s763866529x146151572_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s763866529x146151572_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
Clo g_heff_2ecompile_2escalars_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2escalars_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_args_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_args_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2escalars_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ecallsW_entry, 3, 0};

V g_heff_2ecompile_2escalars_2ecallsW(V v_f_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_ECall: {
      V v_g_245 = heff_field(v_x31_243, 0);
      V v_args_246 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ECall = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_247;
      if (heff_strEq_c_lent(v_g_245, v_f_240, 1)) {
        v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_args_246), v_acc_241});
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        v_t_247 = v_acc_241;
      }
      V v_t_248 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24ECall, v_args_246, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_t_247;
      V t_2 = v_t_248;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_249 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_acc_241;
      V t_2 = v_t_249;
      v_f_240 = t_0;
      v_acc_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2ecallsW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2escalars_2etakesApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2etakesApart_entry, 4, 0};

V g_heff_2ecompile_2escalars_2etakesApart(V v_p_240, V v_sh_241, V v_s_242, V v_arms_243) {
top: ;
  switch (heff_tag_of(v_sh_241)) {
  case TAG_ShapeRecord: {
    return NTAG(TAG_False);
  }
  case TAG_ShapeTag: {
    V v_t_245 = heff_field(v_sh_241, 0);
    V v_k_246 = heff_field(v_sh_241, 1);
    switch (heff_tag_of(v_s_242)) {
    case TAG_EVar: {
      V v_y_247 = heff_field(v_s_242, 0);
      if (heff_strEq_c_lent(v_p_240, v_y_247, 0)) {
        switch (heff_tag_of(v_arms_243)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          V v_arms1_248 = heff_field(v_arms_243, 0);
          V v_arms2_249 = heff_field(v_arms_243, 1);
          switch (heff_tag_of(v_arms1_248)) {
          case TAG_MkArm: {
            V v_t2_2410 = heff_field(v_arms1_248, 0);
            V v_vs_2411 = heff_field(v_arms1_248, 1);
            switch (heff_tag_of(v_arms2_249)) {
            case TAG_Nil: {
              V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_t_245, v_t2_2410, 0) && ({ V v_t_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2411)); int c_ = heff_intEq_c_lent(v_t_2453, v_k_246, 0); heff_drop(v_t_2453); c_; })));
              return v_ret_24bool;
            }
            case TAG_Cons: {
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_arms2_249);
            }
          }
          default: return heff_nomatch(v_arms1_248);
          }
        }
        default: return heff_nomatch(v_arms_243);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_s_242);
    }
  }
  default: return heff_nomatch(v_sh_241);
  }
}
V g_heff_2ecompile_2escalars_2etakesApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2escalars_2etakesApart(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2escalars_2ewholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ewholeW_entry, 4, 0};

V g_heff_2ecompile_2escalars_2ewholeW(V v_p_240, V v_sh_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_247;
      if (heff_strEq_c_lent(v_y_246, v_p_240, 1)) {
        v_t_247 = heff_intAdd(v_n_242, MK_INT(1LL));
      } else {
        v_t_247 = v_n_242;
      }
      V t_0 = v_p_240;
      V t_1 = v_sh_241;
      V t_2 = v_t_247;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_sh_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_248 = heff_field(v_x41_244, 0);
      V v_l_249 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 4);
      V v_t_2455;
      switch (heff_tag_of(v_e_248)) {
      case TAG_EVar: {
        V v_y_2412 = heff_dup(heff_field(v_e_248, 0));
        if (heff_strEq_c_lent(v_p_240, v_y_2412, 2)) {
          V v_t_2416;
          switch (heff_tag_of(v_sh_241)) {
          case TAG_ShapeRecord: {
            V v_ls_2413 = heff_field(v_sh_241, 0);
            v_t_2416 = heff_dup(v_ls_2413);
            break;
          }
          case TAG_ShapeTag: {
            v_t_2416 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_sh_241);
          }
          v_t_2455 = ({ V a_0 = v_l_249; V a_1 = v_t_2416; V r_ = (g_list_2eany_24s1477604419x1568736711(a_0, a_1)); heff_drop(v_l_249); heff_drop(v_t_2416); r_; });
        } else {
          heff_drop(v_l_249);
          v_t_2455 = NTAG(TAG_False);
        }
        break;
      }
      case TAG_EGlobal: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_drop(v_l_249);
        v_t_2455 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_248);
      }
      if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_e_248);
        heff_drop(v_t_2455);
        V t_0 = v_p_240;
        V t_1 = v_sh_241;
        V t_2 = v_n_242;
        V t_3 = v_rest_245;
        v_p_240 = t_0;
        v_sh_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_2455);
        V t_0 = v_p_240;
        V t_1 = v_sh_241;
        V t_2 = v_n_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_248, v_rest_245});
        v_p_240 = t_0;
        v_sh_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    case TAG_EMatch: {
      V v_s_2456 = heff_field(v_x41_244, 0);
      V v_arms_2457 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2458 = (g_heff_2ecompile_2escalars_2etakesApart(v_p_240, v_sh_241, v_s_2456, v_arms_2457));
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        heff_drop(v_s_2456);
        heff_drop(v_t_2458);
        V v_t_2459 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2457, v_rest_245));
        V t_0 = v_p_240;
        V t_1 = v_sh_241;
        V t_2 = v_n_242;
        V t_3 = v_t_2459;
        v_p_240 = t_0;
        v_sh_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      } else {
        heff_drop(v_t_2458);
        V v_t_2460 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2457, v_rest_245));
        V t_0 = v_p_240;
        V t_1 = v_sh_241;
        V t_2 = v_n_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2456, v_t_2460});
        v_p_240 = t_0;
        v_sh_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2461 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_sh_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2461;
      v_p_240 = t_0;
      v_sh_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2ewholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2ewholeW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2elamWholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2elamWholeW_entry, 4, 0};

V g_heff_2ecompile_2escalars_2elamWholeW(V v_p_240, V v_sh_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_ELam: {
      V v_b_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_247, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2ecompile_2escalars_2ewholeW(v_p_240, v_sh_241, v_n_242, v_t_248));
      V t_0 = v_p_240;
      V t_1 = v_sh_241;
      V t_2 = v_t_249;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_sh_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2410 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_sh_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2410;
      v_p_240 = t_0;
      v_sh_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2elamWholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2elamWholeW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2eexitsWhole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eexitsWhole_entry, 4, 0};

V g_heff_2ecompile_2escalars_2eexitsWhole(V v_f_240, V v_p_241, V v_sh_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_ECall: {
    V v_g_244 = heff_field(v_e_243, 0);
    V v_args_245 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_244, v_f_240, 0)) {
      heff_drop(v_g_244);
      heff_drop(v_args_245);
      heff_drop_cell(v_ru_24e_243_24ECall, 2);
      return MK_INT(0LL);
    } else {
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_g_244, v_args_245}), NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_sh_242, MK_INT(0LL), v_t_246);
    }
  }
  default: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_sh_242, MK_INT(0LL), v_t_247);
  }
  }
}
V g_heff_2ecompile_2escalars_2eexitsWhole_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2escalars_2eexitsWhole(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2escalars_2efirstApart_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2efirstApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2efirstApart_entry, 3, 0};

V g_heff_2ecompile_2escalars_2efirstApart(V v_p_240, V v_sh_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    V v_t_2412 = (g_heff_2ecompile_2eir_2eisValue(v_a_2410));
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      V t_0 = v_p_240;
      V t_1 = v_sh_241;
      V t_2 = v_b_2411;
      v_p_240 = t_0;
      v_sh_241 = t_1;
      v_e_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_2412);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_242, 0);
    V v_arms_2423 = heff_field(v_e_242, 1);
    V v_t_2424 = (g_heff_2ecompile_2escalars_2etakesApart(v_p_240, v_sh_241, v_s_2422, v_arms_2423));
    if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
      heff_drop(v_t_2424);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2424);
      switch (heff_tag_of(v_s_2422)) {
      case TAG_EVar: {
        switch (heff_tag_of(v_arms_2423)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          return (g_list_2eall(heff_clo_n(g_heff_2ecompile_2escalars_2efirstApart_lam0, 1, 2, (V[]){heff_dup(v_p_240), heff_dup(v_sh_241)}), v_arms_2423));
        }
        default: return heff_nomatch(v_arms_2423);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_2422);
      }
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2escalars_2efirstApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2escalars_2efirstApart(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2escalars_2efirstApart_lam0(V self, V *args) {
  V v_a_2428 = args[0];
  V v_p_240 = heff_env(self)[0];
  V v_sh_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432;
  switch (heff_tag_of(v_a_2428)) {
  case TAG_MkArm: {
    V v_b_2431 = heff_field(v_a_2428, 2);
    heff_take_n(v_a_2428, 4ULL, 3);
    v_t_2432 = v_b_2431;
    break;
  }
  default: heff_nomatch(v_a_2428);
  }
  return ({ V a_0 = v_p_240; V a_1 = v_sh_241; V a_2 = v_t_2432; V r_ = (g_heff_2ecompile_2escalars_2efirstApart(a_0, a_1, a_2)); heff_drop(v_p_240); heff_drop(v_sh_241); heff_drop(v_t_2432); r_; });
}
V g_heff_2ecompile_2escalars_2esomeApart_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2esomeApart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2esomeApart_entry, 2, 0};

V g_heff_2ecompile_2escalars_2esomeApart(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_e_241, 1);
    V v_b_2410 = heff_field(v_e_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2eir_2eisValue(v_a_249));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V t_0 = v_p_240;
      V t_1 = v_b_2410;
      v_p_240 = t_0;
      v_e_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_2411);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_e_241, 0);
    V v_arms_2422 = heff_field(v_e_241, 1);
    V v_t_2466;
    switch (heff_tag_of(v_s_2421)) {
    case TAG_EVar: {
      V v_y_2423 = heff_field(v_s_2421, 0);
      if (heff_strEq_c_lent(v_p_240, v_y_2423, 0)) {
        switch (heff_tag_of(v_arms_2422)) {
        case TAG_Nil: {
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          V v_arms2_2425 = heff_field(v_arms_2422, 1);
          switch (heff_tag_of(v_arms2_2425)) {
          case TAG_Nil: {
            v_t_2466 = NTAG(TAG_True);
            break;
          }
          case TAG_Cons: {
            v_t_2466 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_arms2_2425);
          }
          break;
        }
        default: heff_nomatch(v_arms_2422);
        }
      } else {
        v_t_2466 = NTAG(TAG_False);
      }
      break;
    }
    case TAG_EGlobal: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2466 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_s_2421);
    }
    if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
      heff_drop(v_t_2466);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2466);
      switch (heff_tag_of(v_s_2421)) {
      case TAG_EVar: {
        switch (heff_tag_of(v_arms_2422)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          HEFF_LAST return g_list_2eall(heff_clo_n(g_heff_2ecompile_2escalars_2esomeApart_lam0, 1, 1, (V[]){heff_dup(v_p_240)}), v_arms_2422);
        }
        default: return heff_nomatch(v_arms_2422);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EBytes: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EBool: {
        return NTAG(TAG_False);
      }
      case TAG_ESet: {
        return NTAG(TAG_False);
      }
      case TAG_EValues: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_s_2421);
      }
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2escalars_2esomeApart_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2esomeApart(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2escalars_2esomeApart_lam0(V self, V *args) {
  V v_a_2470 = args[0];
  V v_p_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474;
  switch (heff_tag_of(v_a_2470)) {
  case TAG_MkArm: {
    V v_b_2473 = heff_field(v_a_2470, 2);
    heff_take_n(v_a_2470, 4ULL, 3);
    v_t_2474 = v_b_2473;
    break;
  }
  default: heff_nomatch(v_a_2470);
  }
  return ({ V a_0 = v_p_240; V a_1 = v_t_2474; V r_ = (g_heff_2ecompile_2escalars_2esomeApart(a_0, a_1)); heff_drop(v_p_240); heff_drop(v_t_2474); r_; });
}
V g_heff_2ecompile_2escalars_2egivenOf_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2egivenOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2egivenOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2egivenOf_entry, 2, 0};

V g_heff_2ecompile_2escalars_2egivenOf(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_y_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_242, v_p_240, 1)) {
      return NTAG(TAG_GivenSame);
    } else {
      return NTAG(TAG_GivenOther);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_GivenOther);
  }
  case TAG_ERecord: {
    V v_fs_2411 = heff_field(v_e_241, 0);
    V v_ts_2412 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2411)));
    V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2411; V r_ = (g_list_2efoldl_24f2092936166x2062766724(a_0, a_1, a_2)); heff_drop(v_fs_2411); r_; });
    V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
    V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2egivenOf_lam0, 1, 1, (V[]){v_ts_2412}), v_t_2415));
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_GivenBuilt, 2, (V[]){heff_tag_n(TAG_ShapeRecord, 1, (V[]){v_t_2413}), v_t_2417});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_GivenOther);
  }
  case TAG_ETag: {
    V v_t_2422 = heff_field(v_e_241, 0);
    V v_args_2423 = heff_field(v_e_241, 1);
    V v_ts_2424 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
    V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2423; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2423); r_; });
    V v_t_2427 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2426, MK_INT(1LL))));
    V v_t_2429 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2egivenOf_lam1, 1, 1, (V[]){v_ts_2424}), v_t_2427));
    return heff_tag_n(TAG_GivenBuilt, 2, (V[]){heff_tag_n(TAG_ShapeTag, 2, (V[]){v_t_2422, v_t_2425}), v_t_2429});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_GivenOther);
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_GivenOther);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_GivenOther);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2escalars_2egivenOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2egivenOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2egivenOf_lam0(V self, V *args) {
  V v_i_2416 = args[0];
  V v_ts_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2416; V a_1 = v_ts_2412; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2412); r_; });
}
V g_heff_2ecompile_2escalars_2egivenOf_lam1(V self, V *args) {
  V v_i_2428 = args[0];
  V v_ts_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2428; V a_1 = v_ts_2424; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2424); r_; });
}
Clo g_heff_2ecompile_2escalars_2eslotWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eslotWith_entry, 6, 0};

V g_heff_2ecompile_2escalars_2eslotWith(V v_kind_240, V v_c_241, V v_i_242, V v_p_243, V v_sames_244, V v_g_245) {
top: ;
  V v_body_246 = heff_take_field(v_c_241, 1);
  V v_last_247 = heff_take_field(v_c_241, 2);
  V v_key_248 = heff_get_n(v_c_241, 0, 4);
  switch (heff_tag_of(v_g_245)) {
  case TAG_NoneGiven: {
    heff_drop(v_i_242);
    heff_drop(v_p_243);
    heff_drop(v_sames_244);
    heff_drop(v_body_246);
    heff_drop(v_last_247);
    heff_drop(v_key_248);
    return NTAG(TAG_Nothing);
  }
  case TAG_GivenOne: {
    V v_sh_249 = heff_field(v_g_245, 0);
    V v_ts_2410 = heff_field(v_g_245, 1);
    V v_ru_24g_245_24GivenOne = heff_take_reuse_n(v_g_245, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_kind_240)) {
    case TAG_OfRecords: {
      switch (heff_tag_of(v_sh_249)) {
      case TAG_ShapeRecord: {
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      case TAG_ShapeTag: {
        v_t_2417 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_sh_249);
      }
      break;
    }
    case TAG_OfTags: {
      switch (heff_tag_of(v_sh_249)) {
      case TAG_ShapeRecord: {
        v_t_2417 = NTAG(TAG_False);
        break;
      }
      case TAG_ShapeTag: {
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_sh_249);
      }
      break;
    }
    default: heff_nomatch(v_kind_240);
    }
    V v_t_2440;
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      if (({ V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ts_2410)); int c_ = heff_intLe_c_lent(v_t_2459, MK_INT(8LL), 2); heff_drop(v_t_2459); c_; })) {
        V v_t_2466;
        switch (heff_tag_of(v_ts_2410)) {
        case TAG_Nil: {
          v_t_2466 = NTAG(TAG_False);
          break;
        }
        case TAG_Cons: {
          v_t_2466 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_ts_2410);
        }
        switch (heff_tag_of(v_t_2466)) {
        case TAG_True: {
          V v_t_2472;
          switch (heff_tag_of(v_sh_249)) {
          case TAG_ShapeRecord: {
            v_t_2472 = NTAG(TAG_True);
            break;
          }
          case TAG_ShapeTag: {
            v_t_2472 = (g_heff_2ecompile_2escalars_2efirstApart(v_p_243, v_sh_249, v_body_246));
            break;
          }
          default: heff_nomatch(v_sh_249);
          }
          switch (heff_tag_of(v_t_2472)) {
          case TAG_True: {
            V v_t_2423 = heff_dup(v_body_246);
            V v_t_2478;
            switch (heff_tag_of(v_t_2423)) {
            case TAG_ELam: {
              V v_b_2425 = heff_field(v_t_2423, 1);
              heff_take_n(v_t_2423, 2ULL, 2);
              V v_t_2426 = heff_tag_at_n(v_ru_24g_245_24GivenOne, TAG_Cons, 2, (V[]){v_b_2425, NTAG(TAG_Nil)});
              V v_n_2427 = (g_heff_2ecompile_2escalars_2ewholeW(v_p_243, v_sh_249, MK_INT(0LL), v_t_2426));
              v_t_2478 = v_n_2427;
              break;
            }
            default: {
              heff_drop_cell(v_ru_24g_245_24GivenOne, 2);
              V v_t_2428 = (g_heff_2ecompile_2eir_2epartsOnto(v_t_2423, NTAG(TAG_Nil)));
              v_t_2478 = (g_heff_2ecompile_2escalars_2elamWholeW(v_p_243, v_sh_249, MK_INT(0LL), v_t_2428));
              break;
            }
            }
            V v_t_2477 = heff_intEq(v_t_2478, MK_INT(0LL));
            switch (heff_tag_of(v_t_2477)) {
            case TAG_True: {
              V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_body_246), NTAG(TAG_Nil)});
              V v_t_2479 = (g_heff_2ecompile_2escalars_2ewholeW(v_p_243, v_sh_249, MK_INT(0LL), v_t_2429));
              V v_t_2432;
              if ((heff_dup(v_last_247) == NTAG(TAG_True))) {
                heff_drop(v_last_247);
                V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2eexitsWhole_clo), 3, (V[]){v_key_248, heff_dup(v_p_243), heff_dup(v_sh_249)}));
                V v_t_2431 = (g_heff_2ecompile_2eir_2ewaysOnto(v_body_246, NTAG(TAG_Nil)));
                v_t_2432 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2430; V a_2 = v_t_2431; V r_ = (g_list_2efoldl_24f2005293661x823011722(a_0, a_1, a_2)); heff_drop(v_t_2431); r_; });
              } else {
                heff_drop(v_body_246);
                heff_drop(v_last_247);
                heff_drop(v_key_248);
                v_t_2432 = MK_INT(0LL);
              }
              V v_t_2480 = heff_intAdd(v_sames_244, v_t_2432);
              v_t_2440 = heff_intEq(v_t_2479, v_t_2480);
              break;
            }
            case TAG_False: {
              heff_drop(v_sames_244);
              heff_drop(v_body_246);
              heff_drop(v_last_247);
              heff_drop(v_key_248);
              v_t_2440 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_2477);
            }
            break;
          }
          case TAG_False: {
            heff_drop(v_sames_244);
            heff_drop(v_body_246);
            heff_drop(v_last_247);
            heff_drop(v_key_248);
            heff_drop_cell(v_ru_24g_245_24GivenOne, 2);
            v_t_2440 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2472);
          }
          break;
        }
        case TAG_False: {
          heff_drop(v_sames_244);
          heff_drop(v_body_246);
          heff_drop(v_last_247);
          heff_drop(v_key_248);
          heff_drop_cell(v_ru_24g_245_24GivenOne, 2);
          v_t_2440 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_t_2466);
        }
      } else {
        heff_drop(v_sames_244);
        heff_drop(v_body_246);
        heff_drop(v_last_247);
        heff_drop(v_key_248);
        heff_drop_cell(v_ru_24g_245_24GivenOne, 2);
        v_t_2440 = NTAG(TAG_False);
      }
    } else {
      heff_drop(v_sames_244);
      heff_drop(v_body_246);
      heff_drop(v_last_247);
      heff_drop(v_key_248);
      heff_drop_cell(v_ru_24g_245_24GivenOne, 2);
      heff_drop(v_t_2417);
      v_t_2440 = NTAG(TAG_False);
    }
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      V v_t_2433 = heff_rec_n(5, shape_at__param__shape__tys__vars, (V[]){v_i_242, v_p_243, v_sh_249, v_ts_2410, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2433});
    }
    case TAG_False: {
      heff_drop(v_i_242);
      heff_drop(v_p_243);
      heff_drop(v_sh_249);
      heff_drop(v_ts_2410);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_GivenMany: {
    heff_drop(v_i_242);
    heff_drop(v_p_243);
    heff_drop(v_sames_244);
    heff_drop(v_body_246);
    heff_drop(v_last_247);
    heff_drop(v_key_248);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_g_245);
  }
}
V g_heff_2ecompile_2escalars_2eslotWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eslotWith(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2escalars_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2escalars_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ms_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2escalars_2ejustsOf_24dps(v_ms_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2escalars_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ejustsOf(a[0]);
}
Clo g_heff_2ecompile_2escalars_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2escalars_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_ms_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2escalars_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ejustsOf_24dps(a[0], a[1]);
}
V g_heff_2ecompile_2escalars_2eslotsOf_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2eslotsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2eslotsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eslotsOf_entry, 2, 0};

V g_heff_2ecompile_2escalars_2eslotsOf(V v_kind_240, V v_d_241) {
top: ;
  V v_body_242 = heff_take_field(v_d_241, 2);
  V v_key_243 = heff_get_n(v_d_241, 0, 3);
  switch (heff_tag_of(v_body_242)) {
  case TAG_EVar: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_body_242, 0);
    V v_b_247 = heff_field(v_body_242, 1);
    V v_ru_24body_242_24ELam = heff_take_reuse_n(v_body_242, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_kind_240)) {
    case TAG_OfRecords: {
      v_t_249 = NTAG(TAG_True);
      break;
    }
    case TAG_OfTags: {
      v_t_249 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2escalars_2eslotsOf_lam0, 1, 1, (V[]){heff_dup(v_b_247)}), v_xs_246));
      break;
    }
    default: heff_nomatch(v_kind_240);
    }
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_x1_2410 = heff_dup(v_kind_240);
      V v_xs_2411 = heff_dup(v_xs_246);
      V v_f_2412 = heff_dup(v_key_243);
      V v_b_2413 = heff_dup(v_b_247);
      V v_t_2414 = (g_heff_2ecompile_2eir_2ewaysOnto(heff_dup(v_b_247), NTAG(TAG_Nil)));
      V v_lasts_2415 = (g_list_2efoldl_24s1682887903x724363097(heff_dup(v_key_243), NTAG(TAG_Nil), v_t_2414));
      V v_f_2416 = v_key_243;
      V v_all_2422;
      switch (heff_tag_of(v_b_247)) {
      case TAG_ECall: {
        V v_g_2417 = heff_field(v_b_247, 0);
        V v_args_2418 = heff_field(v_b_247, 1);
        V v_ru_24b_247_24ECall = heff_take_reuse_n(v_b_247, 3ULL, 2);
        V v_t_2419;
        if (heff_strEq_c_lent(v_g_2417, v_f_2416, 1)) {
          v_t_2419 = heff_tag_at_n(v_ru_24body_242_24ELam, TAG_Cons, 2, (V[]){heff_dup(v_args_2418), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24body_242_24ELam, 2);
          v_t_2419 = NTAG(TAG_Nil);
        }
        V v_t_2420 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24b_247_24ECall, v_args_2418, NTAG(TAG_Nil)));
        v_all_2422 = ({ V a_0 = v_f_2416; V a_1 = v_t_2419; V a_2 = v_t_2420; V r_ = (g_heff_2ecompile_2escalars_2ecallsW(a_0, a_1, a_2)); heff_drop(v_f_2416); r_; });
        break;
      }
      default: {
        heff_drop_cell(v_ru_24body_242_24ELam, 2);
        V v_t_2421 = (g_heff_2ecompile_2eir_2epartsOnto(v_b_247, NTAG(TAG_Nil)));
        v_all_2422 = ({ V a_0 = v_f_2416; V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2421; V r_ = (g_heff_2ecompile_2escalars_2ecallsW(a_0, a_1, a_2)); heff_drop(v_f_2416); r_; });
        break;
      }
      }
      V v_c_2434;
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_OfRecords: {
        heff_drop(v_xs_2411);
        V v_t_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_all_2422; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_all_2422); r_; });
        V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_lasts_2415));
        V v_t_2425;
        if (heff_intEq_c(v_t_2423, v_t_2424)) {
          v_t_2425 = v_lasts_2415;
        } else {
          heff_drop(v_lasts_2415);
          v_t_2425 = NTAG(TAG_Nil);
        }
        v_c_2434 = heff_rec_n(4, shape_key__body__last__args, (V[]){v_f_2412, v_b_2413, NTAG(TAG_True), v_t_2425});
        break;
      }
      case TAG_OfTags: {
        V v_t_2426 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_lasts_2415; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_lasts_2415); r_; });
        V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_all_2422));
        V v_t_2428 = heff_bool(heff_intEq_c_lent(v_t_2426, v_t_2427, 0));
        heff_drop(v_t_2426);
        heff_drop(v_t_2427);
        V v_t_2432 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2escalars_2eslotsOf_lam1, 1, 1, (V[]){v_xs_2411}), v_all_2422));
        V v_t_2433;
        if ((heff_dup(v_t_2432) == NTAG(TAG_True))) {
          heff_drop(v_all_2422);
          heff_drop(v_t_2432);
          v_t_2433 = NTAG(TAG_Nil);
        } else {
          heff_drop(v_t_2432);
          v_t_2433 = v_all_2422;
        }
        v_c_2434 = heff_rec_n(4, shape_key__body__last__args, (V[]){v_f_2412, v_b_2413, v_t_2428, v_t_2433});
        break;
      }
      default: heff_nomatch(v_x1_2410);
      }
      V v_t_2435 = heff_dup(heff_rfield(v_c_2434, 3));
      switch (heff_tag_of(v_t_2435)) {
      case TAG_Nil: {
        heff_drop(v_kind_240);
        heff_drop(v_xs_246);
        heff_drop_rec(v_c_2434, 4);
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        heff_take_n(v_t_2435, 0ULL, 2);
        V v_t_2438 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
        V v_t_2439 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2438, MK_INT(1LL))));
        V v_t_2440 = (g_list_2ezipWith_24s919837080x1979082626(v_kind_240, v_c_2434, v_xs_246, v_t_2439));
        return (g_heff_2ecompile_2escalars_2ejustsOf(v_t_2440));
      }
      default: return heff_nomatch(v_t_2435);
      }
    } else {
      heff_drop(v_kind_240);
      heff_drop(v_key_243);
      heff_drop(v_xs_246);
      heff_drop(v_b_247);
      heff_drop_cell(v_ru_24body_242_24ELam, 2);
      heff_drop(v_t_249);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_body_242, 0ULL, 4);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_nf(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    heff_take_n(v_body_242, 0ULL, 3);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EValues: {
    heff_take_n(v_body_242, 0ULL, 1);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_body_242, 0ULL, 2);
    heff_drop(v_kind_240);
    heff_drop(v_key_243);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2eslotsOf(a[0], a[1]);
}
V g_heff_2ecompile_2escalars_2eslotsOf_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_b_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_248; V a_1 = v_b_247; V r_ = (g_heff_2ecompile_2escalars_2esomeApart(a_0, a_1)); heff_drop(v_x_248); heff_drop(v_b_247); r_; });
}
V g_heff_2ecompile_2escalars_2eslotsOf_lam1(V self, V *args) {
  V v_args_2429 = args[0];
  V v_xs_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2429; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2429); r_; });
  V v_y_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2411; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
  V v_ret_24bool = heff_bool(!heff_intEq_c_lent(v_x_2430, v_y_2431, 0));
  heff_drop(v_x_2430);
  heff_drop(v_y_2431);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2escalars_2elabelVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2elabelVar_entry, 3, 0};

V g_heff_2ecompile_2escalars_2elabelVar(V v_l_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_ks_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x3_242, 0);
      V v_vs_246 = heff_field(v_x3_242, 1);
      if (heff_strEq_c_lent(v_k_243, v_l_240, 0)) {
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_ks_244;
        V t_2 = v_vs_246;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2escalars_2elabelVar_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2escalars_2elabelVar(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2escalars_2ematchRw_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_lam1(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_lam2(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_lam3(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_lam4(V self, V *args);
Clo g_heff_2ecompile_2escalars_2ematchRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ematchRw_entry, 4, 0};

V g_heff_2ecompile_2escalars_2ematchRw(V v_go_240, V v_s_241, V v_arms_242, V v_m_243) {
top: ;
  switch (heff_tag_of(v_arms_242)) {
  case TAG_Nil: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_lam0, 1, 1, (V[]){v_go_240}), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242})));
  }
  case TAG_Cons: {
    V v_arms1_245 = heff_dup(heff_field(v_arms_242, 0));
    V v_arms2_246 = heff_dup(heff_field(v_arms_242, 1));
    switch (heff_tag_of(v_arms1_245)) {
    case TAG_MkArm: {
      V v_t_247 = heff_field(v_arms1_245, 0);
      V v_vs_248 = heff_field(v_arms1_245, 1);
      V v_b_249 = heff_field(v_arms1_245, 2);
      V v_ru_24arms1_245_24MkArm = heff_take_reuse_n(v_arms1_245, 7ULL, 3);
      switch (heff_tag_of(v_arms2_246)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_m_243)) {
        case TAG_Nothing: {
          heff_drop(v_t_247);
          heff_drop(v_vs_248);
          heff_drop(v_b_249);
          return (g_heff_2ecompile_2eir_2emapParts_24tok3(v_ru_24arms1_245_24MkArm, heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_lam1, 1, 1, (V[]){v_go_240}), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242})));
        }
        case TAG_Just: {
          V v_sl_2411 = heff_field(v_m_243, 0);
          heff_drop_tag(v_arms_242, 2);
          V v_shape_2412 = heff_dup(heff_rfield(v_sl_2411, 2));
          V v_vars_2413 = heff_dup(heff_rfield(v_sl_2411, 4));
          switch (heff_tag_of(v_shape_2412)) {
          case TAG_ShapeRecord: {
            V v_ru_24shape_2412_24ShapeRecord = heff_take_reuse_n(v_shape_2412, 0ULL, 1);
            heff_drop(v_vars_2413);
            V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24arms1_245_24MkArm, TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_b_249}), NTAG(TAG_Nil)});
            return (g_heff_2ecompile_2eir_2emapParts_24tok1(v_ru_24shape_2412_24ShapeRecord, heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_lam2, 1, 1, (V[]){v_go_240}), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_t_2415})));
          }
          case TAG_ShapeTag: {
            V v_t2_2417 = heff_field(v_shape_2412, 0);
            V v_ru_24shape_2412_24ShapeTag = heff_take_reuse_n(v_shape_2412, 1ULL, 2);
            if (heff_strEq_c_lent(v_t_247, v_t2_2417, 2)) {
              heff_drop(v_s_241);
              heff_drop(v_t_247);
              heff_drop_cell(v_ru_24arms1_245_24MkArm, 3);
              heff_drop_cell(v_ru_24shape_2412_24ShapeTag, 2);
              V v_ps_2419 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_248, v_vars_2413));
              V v_m_2420 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2419; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2419); r_; });
              V v_t_2421 = (g_std_2eordmap_2esize(v_m_2420));
              V v_t_2422;
              if (heff_intEq_c(v_t_2421, MK_INT(0LL))) {
                heff_drop(v_m_2420);
                v_t_2422 = v_b_249;
              } else {
                v_t_2422 = ({ V a_0 = v_m_2420; V a_1 = v_b_249; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2420); r_; });
              }
              return heff_tail(v_go_240, 1, (V[]){v_t_2422});
            } else {
              heff_drop(v_vars_2413);
              V v_t_2423 = heff_tag_at_n(v_ru_24shape_2412_24ShapeTag, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24arms1_245_24MkArm, TAG_MkArm, 3, (V[]){v_t_247, v_vs_248, v_b_249}), NTAG(TAG_Nil)});
              return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_lam3, 1, 1, (V[]){v_go_240}), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_t_2423})));
            }
          }
          default: return heff_nomatch(v_shape_2412);
          }
        }
        default: return heff_nomatch(v_m_243);
        }
      }
      case TAG_Cons: {
        V v_ru_24arms2_246_24Cons = heff_take_reuse_n(v_arms2_246, 0ULL, 2);
        heff_drop(v_t_247);
        heff_drop(v_vs_248);
        heff_drop(v_b_249);
        return (g_heff_2ecompile_2eir_2emapParts_24tok3(v_ru_24arms1_245_24MkArm, heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_lam4, 1, 1, (V[]){v_go_240}), heff_tag_at_n(v_ru_24arms2_246_24Cons, TAG_EMatch, 2, (V[]){v_s_241, v_arms_242})));
      }
      default: return heff_nomatch(v_arms2_246);
      }
    }
    default: return heff_nomatch(v_arms1_245);
    }
  }
  default: return heff_nomatch(v_arms_242);
  }
}
V g_heff_2ecompile_2escalars_2ematchRw_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2escalars_2ematchRw(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2escalars_2ematchRw_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_244);
  return v_go_240;
}
V g_heff_2ecompile_2escalars_2ematchRw_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2410);
  return v_go_240;
}
V g_heff_2ecompile_2escalars_2ematchRw_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2416);
  return v_go_240;
}
V g_heff_2ecompile_2escalars_2ematchRw_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2424);
  return v_go_240;
}
V g_heff_2ecompile_2escalars_2ematchRw_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2427);
  return v_go_240;
}
V g_heff_2ecompile_2escalars_2eargsRw_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2eargsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eargsRw_entry, 4, 0};

V g_heff_2ecompile_2escalars_2eargsRw(V v_go_240, V v_ss_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_args_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_go_246 = heff_dup(v_go_240);
    V v_a_247 = v_a_244;
    HeffT2 v_t_248 = (g_list_2efind_24s1508082563x149957932_24cpr(heff_dup(v_i_242), v_ss_241));
    V v_t_2422;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_s_2411 = v_field_2410;
        switch (heff_tag_of(v_a_247)) {
        case TAG_ERecord: {
          V v_fs_2412 = heff_field(v_a_247, 0);
          V v_ru_24a_247_24ERecord = heff_take_reuse_n(v_a_247, 1ULL, 2);
          heff_drop_rec(v_s_2411, 5);
          v_t_2422 = (g_list_2emap_24tok2(v_ru_24a_247_24ERecord, heff_clo_n(g_heff_2ecompile_2escalars_2eargsRw_lam0, 1, 1, (V[]){v_go_246}), v_fs_2412));
          break;
        }
        case TAG_ETag: {
          V v_args_2419 = heff_field(v_a_247, 1);
          heff_take_n(v_a_247, 2ULL, 3);
          heff_drop_rec(v_s_2411, 5);
          v_t_2422 = (g_list_2emap(v_go_246, v_args_2419));
          break;
        }
        default: {
          heff_drop(v_go_246);
          heff_drop(v_a_247);
          v_t_2422 = (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_2411, 4, 5)));
          break;
        }
        }
      } else {
        heff_drop(v_field_2410);
        V v_t_2421 = heff_tr(heff_call(v_go_246, 1, (V[]){v_a_247}));
        v_t_2422 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
      }
    }
    V v_t_2423 = (g_heff_2ecompile_2escalars_2eargsRw(v_go_240, v_ss_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_args_245));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2422, v_t_2423));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2eargsRw_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2eargsRw(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2escalars_2eargsRw_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_go_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_p_2414, 1);
    heff_take_n(v_p_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  V f_ = v_go_246;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2escalars_2erw_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2erw_entry, 2, 0};

V g_heff_2ecompile_2escalars_2erw(V v_lp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V a_0 = v_x_242; V b_1 = heff_get_n(v_lp_240, 2, 3); HeffT2 r_ = (g_list_2efind_24s1498631415x1735266116_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        V v_s_246 = v_field_245;
        V v_shape_247 = heff_take_field(v_s_246, 2);
        V v_vars_248 = heff_take_field(v_s_246, 4);
        V v_tys_249 = heff_get_n(v_s_246, 3, 5);
        switch (heff_tag_of(v_shape_247)) {
        case TAG_ShapeRecord: {
          V v_ls_2410 = heff_field(v_shape_247, 0);
          heff_take_n(v_shape_247, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_241_24EVar, 1);
          V v_t_2411 = (g_list_2ezipWith_24s1928181476x241816070(v_ls_2410, v_vars_248));
          return heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2411, v_tys_249});
        }
        case TAG_ShapeTag: {
          V v_t_2412 = heff_field(v_shape_247, 0);
          heff_take_n(v_shape_247, 1ULL, 2);
          V v_t_2414 = (g_list_2emap_24s1809017761x1063871171_24tok1(v_ru_24x2_241_24EVar, v_vars_248));
          return heff_tag_n(TAG_ETag, 3, (V[]){v_t_2412, v_t_2414, v_tys_249});
        }
        default: return heff_nomatch(v_shape_247);
        }
      } else {
        heff_drop(v_field_245);
        return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
      }
    }
  }
  case TAG_EProj: {
    V v_e_2415 = heff_field(v_x2_241, 0);
    V v_l_2416 = heff_field(v_x2_241, 1);
    V v_sh_2417 = heff_field(v_x2_241, 2);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_go_2419 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    V v_ss_2420 = heff_get_n(v_lp_240, 2, 3);
    V v_e_2421 = heff_dup(v_e_2415);
    V v_l_2422 = heff_dup(v_l_2416);
    V v_x6_2472;
    switch (heff_tag_of(v_e_2421)) {
    case TAG_EVar: {
      V v_x_2423 = heff_field(v_e_2421, 0);
      heff_take_n(v_e_2421, 1ULL, 1);
      HeffT2 v_t_2424 = ({ V a_0 = v_x_2423; V a_1 = v_ss_2420; HeffT2 r_ = (g_list_2efind_24s1498631415x1735266116_24cpr(a_0, a_1)); heff_drop(v_x_2423); heff_drop(v_ss_2420); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_s_2427 = v_field_2426;
          V v_shape_2428 = heff_take_field(v_s_2427, 2);
          V v_vars_2429 = heff_get_n(v_s_2427, 4, 5);
          V v_t_2433;
          switch (heff_tag_of(v_shape_2428)) {
          case TAG_ShapeRecord: {
            V v_ls_2430 = heff_field(v_shape_2428, 0);
            heff_take_n(v_shape_2428, 1ULL, 1);
            v_t_2433 = v_ls_2430;
            break;
          }
          case TAG_ShapeTag: {
            heff_take_n(v_shape_2428, 0ULL, 2);
            v_t_2433 = NTAG(TAG_Nil);
            break;
          }
          default: heff_nomatch(v_shape_2428);
          }
          v_x6_2472 = ({ V a_0 = v_l_2422; V a_1 = v_t_2433; V a_2 = v_vars_2429; V r_ = (g_heff_2ecompile_2escalars_2elabelVar(a_0, a_1, a_2)); heff_drop(v_l_2422); heff_drop(v_t_2433); heff_drop(v_vars_2429); r_; });
        } else {
          heff_drop(v_l_2422);
          heff_drop(v_field_2426);
          v_x6_2472 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_2421, 0ULL, 3);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_2421, 0ULL, 4);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_2421, 0ULL, 3);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_e_2421, 0ULL, 3);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_e_2421, 0ULL, 1);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_2421, 0ULL, 2);
      heff_drop(v_ss_2420);
      heff_drop(v_l_2422);
      v_x6_2472 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2421);
    }
    switch (heff_tag_of(v_x6_2472)) {
    case TAG_Nothing: {
      V v_t_2473 = heff_tr(heff_call(v_go_2419, 1, (V[]){v_e_2415}));
      return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_2473, v_l_2416, v_sh_2417, v_t_2418});
    }
    case TAG_Just: {
      V v_v_2474 = heff_field(v_x6_2472, 0);
      V v_ru_24x6_2472_24Just = heff_take_reuse_n(v_x6_2472, 1ULL, 1);
      heff_drop(v_e_2415);
      heff_drop(v_l_2416);
      heff_drop(v_sh_2417);
      heff_drop(v_t_2418);
      heff_drop_cell(v_ru_24x2_241_24EProj, 4);
      heff_drop(v_go_2419);
      return heff_tag_at_n(v_ru_24x6_2472_24Just, TAG_EVar, 1, (V[]){v_v_2474});
    }
    default: return heff_nomatch(v_x6_2472);
    }
  }
  case TAG_EMatch: {
    V v_s_2475 = heff_field(v_x2_241, 0);
    V v_arms_2476 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2477 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    V v_t_24117;
    switch (heff_tag_of(v_s_2475)) {
    case TAG_EVar: {
      V v_x_2478 = heff_dup(heff_field(v_s_2475, 0));
      v_t_24117 = ({ V a_0 = v_x_2478; V b_1 = heff_get_n(v_lp_240, 2, 3); V r_ = (g_list_2efind_24s1498631415x1735266116(a_0, b_1)); heff_drop(v_x_2478); heff_drop(b_1); r_; });
      break;
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBool: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ESet: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EValues: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_drop_rec(v_lp_240, 3);
      v_t_24117 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_s_2475);
    }
    return ({ V a_0 = v_ru_24x2_241_24EMatch; V a_1 = v_t_2477; V a_2 = v_s_2475; V a_3 = v_arms_2476; V a_4 = v_t_24117; V r_ = (g_heff_2ecompile_2escalars_2ematchRw_24tok2(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24117); r_; });
  }
  case TAG_ECall: {
    V v_g_24118 = heff_field(v_x2_241, 0);
    V v_args_24119 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_24118), heff_dup(heff_rfield(v_lp_240, 0)))) {
      heff_drop(v_g_24118);
      V v_t_24120 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_24121 = (g_heff_2ecompile_2escalars_2eargsRw(v_t_24120, heff_rfield(v_lp_240, 2), MK_INT(0LL), v_args_24119));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_get_n(v_lp_240, 1, 3), v_t_24121});
    } else {
      V v_t_24122 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_24123 = (g_list_2emap(v_t_24122, v_args_24119));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_24118, v_t_24123});
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2escalars_2erw_lam0, 2, 1, (V[]){v_lp_240}), v_x2_241);
  }
  }
}
V g_heff_2ecompile_2escalars_2erw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2erw(a[0], a[1]);
}
V g_heff_2ecompile_2escalars_2erw_lam0(V self, V *args) {
  V v_x_24124 = args[0];
  V v_p_24125 = args[1];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24124);
  return (g_heff_2ecompile_2escalars_2erw(v_lp_240, v_p_24125));
}
Clo g_heff_2ecompile_2escalars_2eparamsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eparamsRw_entry, 3, 0};

V g_heff_2ecompile_2escalars_2eparamsRw(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s1508082563x149957932_24cpr(heff_dup(v_i_241), v_ss_240));
    V v_t_249;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_248 = v_field_247;
        v_t_249 = heff_get_n(v_s_248, 4, 5);
      } else {
        heff_drop(v_field_247);
        v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    V v_t_2410 = (g_heff_2ecompile_2escalars_2eparamsRw(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_249, v_t_2410));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2eparamsRw_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eparamsRw(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2ewrapArgs_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2ewrapArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ewrapArgs_entry, 3, 0};

V g_heff_2ecompile_2escalars_2ewrapArgs(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s1508082563x149957932_24cpr(heff_dup(v_i_241), v_ss_240));
    V v_t_2422;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_248 = v_field_247;
        V v_sh_249 = heff_dup(heff_rfield(v_s_248, 2));
        V v_s_2410 = v_s_248;
        V v_tys_2411 = heff_take_field(v_s_2410, 3);
        V v_vars_2412 = heff_get_n(v_s_2410, 4, 5);
        V v_y_2413 = v_y_243;
        switch (heff_tag_of(v_sh_249)) {
        case TAG_ShapeRecord: {
          V v_ls_2414 = heff_field(v_sh_249, 0);
          heff_take_n(v_sh_249, 1ULL, 1);
          heff_drop(v_vars_2412);
          V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ls_2414));
          V v_t_2416 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL))));
          v_t_2422 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2escalars_2ewrapArgs_lam0, 2, 3, (V[]){v_tys_2411, v_y_2413, heff_dup(v_ls_2414)}), v_ls_2414, v_t_2416));
          break;
        }
        case TAG_ShapeTag: {
          V v_ru_24sh_249_24ShapeTag = heff_take_reuse_n(v_sh_249, 0ULL, 2);
          heff_drop(v_tys_2411);
          heff_drop(v_y_2413);
          v_t_2422 = (g_list_2emap_24s1809017761x1063871171_24tok2(v_ru_24sh_249_24ShapeTag, v_vars_2412));
          break;
        }
        default: heff_nomatch(v_sh_249);
        }
      } else {
        heff_drop(v_field_247);
        v_t_2422 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), NTAG(TAG_Nil)});
      }
    }
    V v_t_2423 = (g_heff_2ecompile_2escalars_2ewrapArgs(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ys_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2422, v_t_2423));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2ewrapArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2ewrapArgs(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2ewrapArgs_lam0(V self, V *args) {
  V v_l_2417 = args[0];
  V v_i_2418 = args[1];
  V v_tys_2411 = heff_env(self)[0];
  V v_y_2413 = heff_env(self)[1];
  V v_ls_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = ({ V a_0 = v_i_2418; V a_1 = v_tys_2411; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_tys_2411); r_; });
  return heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_2413}), v_l_2417, v_ls_2414, v_t_2419});
}
V g_heff_2ecompile_2escalars_2ewithVars_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2ewithVars_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2ewithVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ewithVars_entry, 1, 0};

V g_heff_2ecompile_2escalars_2ewithVars(V v_s_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_s_240, 2));
  V v_t_246;
  switch (heff_tag_of(v_t_241)) {
  case TAG_ShapeRecord: {
    V v_ls_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    v_t_246 = v_ls_242;
    break;
  }
  case TAG_ShapeTag: {
    V v_ru_24t_241_24ShapeTag = heff_take_reuse_n(v_t_241, 0ULL, 2);
    v_t_246 = (g_list_2emap_24tok2(v_ru_24t_241_24ShapeTag, heff_clo_n(g_heff_2ecompile_2escalars_2ewithVars_lam0, 1, 1, (V[]){heff_dup(v_s_240)}), heff_dup(heff_rfield(v_s_240, 3))));
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  return heff_clo_n(g_heff_2ecompile_2escalars_2ewithVars_lam1, 1, 2, (V[]){v_t_246, v_s_240});
}
V g_heff_2ecompile_2escalars_2ewithVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ewithVars(a[0]);
}
V g_heff_2ecompile_2escalars_2ewithVars_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_245);
  return (g_heff_2ecompile_2eir_2ebaseGo(heff_get_n(v_s_240, 1, 5), MK_INT(0LL)));
}
V g_heff_2ecompile_2escalars_2ewithVars_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_t_246 = heff_env(self)[0];
  V v_s_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_248 = (g_prelude_2etraverse_24s1206798274x929612205_24cpr(v_t_246, v_n_247));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x_2411 = v_field_249;
    V v_n_2412 = v_field_2410;
    V v_t_2413 = ({ V rv_4 = v_x_2411; V rr_ = heff_rec_reuse_nf(v_s_240, 15ULL, 5, shape_at__param__shape__tys__vars, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2413, v_n_2412});
  }
}
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str1, 8, "$scalars");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str2, 6, "$unbox");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str3, 8, "$scalars");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str4, 6, "$unbox");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str5, 8, "$scalars");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str6, 6, "$unbox");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_str7, 0, "");
V g_heff_2ecompile_2escalars_2eloopDefs_lam1(V self, V *args);
V g_heff_2ecompile_2escalars_2eloopDefs_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2eloopDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eloopDefs_entry, 5, 0};

V g_heff_2ecompile_2escalars_2eloopDefs(V v_kind_240, V v_d_241, V v_xs_242, V v_b_243, V v_ss0_244) {
top: ;
  V v_m_245 = (g_prelude_2etraverse_24s1232682027x654714928(heff_dup(v_ss0_244)));
  return heff_clo_n(g_heff_2ecompile_2escalars_2eloopDefs_lam0, 1, 6, (V[]){v_m_245, v_ss0_244, v_xs_242, v_d_241, heff_dup(v_kind_240), v_b_243});
}
V g_heff_2ecompile_2escalars_2eloopDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eloopDefs(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2eloopDefs_lam1(V self, V *args) {
  V v_acc_2434 = args[0];
  V v_x_2435 = args[1];
  V v_ys_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_shape_2436 = heff_take_field(v_x_2435, 2);
  V v_at_2437 = heff_take_field(v_x_2435, 0);
  V v_vars_2438 = heff_get_n(v_x_2435, 4, 5);
  switch (heff_tag_of(v_shape_2436)) {
  case TAG_ShapeRecord: {
    heff_take_n(v_shape_2436, 0ULL, 1);
    heff_drop(v_ys_2427);
    heff_drop(v_at_2437);
    heff_drop(v_vars_2438);
    return v_acc_2434;
  }
  case TAG_ShapeTag: {
    V v_t_2440 = heff_field(v_shape_2436, 0);
    V v_ru_24shape_2436_24ShapeTag = heff_take_reuse_n(v_shape_2436, 1ULL, 2);
    HeffT3 v_t_2442 = ({ V a_0 = v_at_2437; V a_1 = v_ys_2427; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ys_2427); r_; });
    V v_t_2448;
    {
      V v_field_2444 = v_t_2442.f[1];
      V v_field_2445 = v_t_2442.f[2];
      int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
      if ((v_tag_2443 == ((int64_t)0ULL))) {
        V v_x_2446 = v_field_2444;
        V v_x12_2447 = v_field_2445;
        heff_drop(v_x12_2447);
        v_t_2448 = v_x_2446;
      } else {
        heff_drop(v_field_2444);
        heff_drop(v_field_2445);
        v_t_2448 = ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str7);
      }
    }
    V v_t_2449 = heff_tag_at_n(v_ru_24shape_2436_24ShapeTag, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2440, v_vars_2438, v_acc_2434}), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2448}), v_t_2449});
  }
  default: return heff_nomatch(v_shape_2436);
  }
}
V g_heff_2ecompile_2escalars_2eloopDefs_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_ss0_244 = heff_env(self)[1];
  V v_xs_242 = heff_env(self)[2];
  V v_d_241 = heff_env(self)[3];
  V v_kind_240 = heff_env(self)[4];
  V v_b_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_prelude_2etraverse_24s763866529x146151572(v_ss0_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      V v_m_2414 = (g_prelude_2etraverse_24s75890152x1871550235(MK_INT(0LL), ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str0), MK_INT(1LL), heff_dup(v_xs_242)));
      V v_x2_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2413}));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_MkPair: {
        V v_x_2416 = heff_field(v_x2_2415, 0);
        V v_n_2417 = heff_field(v_x2_2415, 1);
        V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
        V v_g_2418 = heff_dup(heff_rfield(v_d_241, 0));
        V v_t_2419 = (g_heff_2ecompile_2escalars_2eparamsRw(v_x_248, MK_INT(0LL), v_xs_242));
        V v_g_2420 = heff_dup(heff_rfield(v_d_241, 0));
        V v_t_2421;
        switch (heff_tag_of(v_kind_240)) {
        case TAG_OfRecords: {
          v_t_2421 = heff_strAppend(v_g_2420, ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str1));
          break;
        }
        case TAG_OfTags: {
          v_t_2421 = heff_strAppend(v_g_2420, ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str2));
          break;
        }
        default: heff_nomatch(v_kind_240);
        }
        V v_t_2422 = heff_rec_n(3, shape_key__worker__slots, (V[]){heff_dup(heff_rfield(v_d_241, 0)), v_t_2421, v_x_248});
        V v_t_2423 = heff_tr(g_heff_2ecompile_2escalars_2erw(v_t_2422, v_b_243));
        V v_body_2424 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_ELam, 2, (V[]){v_t_2419, v_t_2423});
        V v_t_2425;
        switch (heff_tag_of(v_kind_240)) {
        case TAG_OfRecords: {
          v_t_2425 = heff_strAppend(v_g_2418, ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str3));
          break;
        }
        case TAG_OfTags: {
          v_t_2425 = heff_strAppend(v_g_2418, ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str4));
          break;
        }
        default: heff_nomatch(v_kind_240);
        }
        V v_t_2426 = heff_rec_n(3, shape_key__name__body, (V[]){v_t_2425, heff_dup(heff_rfield(v_d_241, 1)), v_body_2424});
        V v_ys_2427 = heff_dup(v_x_2416);
        V v_ss_2428 = heff_dup(v_x_2412);
        V v_g_2429 = heff_dup(heff_rfield(v_d_241, 0));
        V v_t_2430;
        switch (heff_tag_of(v_kind_240)) {
        case TAG_OfRecords: {
          v_t_2430 = heff_strAppend(v_g_2429, ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str5));
          break;
        }
        case TAG_OfTags: {
          v_t_2430 = heff_strAppend(v_g_2429, ((V)&g_heff_2ecompile_2escalars_2eloopDefs_str6));
          break;
        }
        default: heff_nomatch(v_kind_240);
        }
        V v_t_2431 = ({ V a_0 = v_x_2412; V a_1 = MK_INT(0LL); V a_2 = heff_dup(v_x_2416); V r_ = (g_heff_2ecompile_2escalars_2ewrapArgs(a_0, a_1, a_2)); heff_drop(v_x_2412); r_; });
        V v_call_2432 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_ECall, 2, (V[]){v_t_2430, v_t_2431});
        V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ss_2428));
        V v_t_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2escalars_2eloopDefs_lam1, 2, 1, (V[]){v_ys_2427}); V a_1 = v_call_2432; V a_2 = v_t_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2433); r_; });
        V v_body_2451 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2416, v_t_2450});
        V v_t_2452 = ({ V rv_2 = v_body_2451; V rr_ = heff_rec_reuse_nf(v_d_241, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
        V v_x_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2453});
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){v_x_2454, v_n_2417});
      }
      default: return heff_nomatch(v_x2_2415);
      }
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2escalars_2edefWith_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2edefWith_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2edefWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2edefWith_entry, 3, 0};

V g_heff_2ecompile_2escalars_2edefWith(V v_kind_240, V v_d_241, V v_ss_242) {
top: ;
  switch (heff_tag_of(v_ss_242)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ecompile_2escalars_2edefWith_lam0, 1, 1, (V[]){v_d_241});
  }
  case TAG_Cons: {
    V v_t_247 = heff_dup(heff_rfield(v_d_241, 2));
    switch (heff_tag_of(v_t_247)) {
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_t_247, 0);
      V v_b_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      return (g_heff_2ecompile_2escalars_2eloopDefs(v_kind_240, v_d_241, v_xs_248, v_b_249, v_ss_242));
    }
    default: {
      heff_drop_tag(v_ss_242, 2);
      heff_drop(v_t_247);
      return heff_clo_n(g_heff_2ecompile_2escalars_2edefWith_lam1, 1, 1, (V[]){v_d_241});
    }
    }
  }
  default: return heff_nomatch(v_ss_242);
  }
}
V g_heff_2ecompile_2escalars_2edefWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2edefWith(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2edefWith_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_n_243});
}
V g_heff_2ecompile_2escalars_2edefWith_lam1(V self, V *args) {
  V v_n_2410 = args[0];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_241, NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_n_2410});
}
HEFF_LIT(g_heff_2ecompile_2escalars_2ecallersRw_str0, 6, "$unbox");
V g_heff_2ecompile_2escalars_2ecallersRw_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2ecallersRw_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2ecallersRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ecallersRw_entry, 2, 0};

V g_heff_2ecompile_2escalars_2ecallersRw(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_ECall: {
    V v_g_242 = heff_field(v_e_241, 0);
    V v_args_243 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_244 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2ecallersRw_clo), 1, (V[]){heff_dup(v_m_240)}));
    V v_g_245 = heff_dup(v_g_242);
    V v_args_246 = v_args_243;
    HeffT2 v_t_247 = ({ V a_0 = v_m_240; V a_1 = v_g_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_m_240); heff_drop(v_g_242); r_; });
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_ss_2410 = v_field_249;
        V v_t_2465 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2escalars_2ecallersRw_lam0, 1, 1, (V[]){heff_dup(v_args_246)}), v_ss_2410));
        if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
          heff_drop(v_t_2465);
          V v_t_2466 = ({ V a_0 = v_go_244; V a_1 = v_ss_2410; V a_2 = MK_INT(0LL); V a_3 = v_args_246; V r_ = (g_heff_2ecompile_2escalars_2eargsRw(a_0, a_1, a_2, a_3)); heff_drop(v_ss_2410); r_; });
          return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_245, ((V)&g_heff_2ecompile_2escalars_2ecallersRw_str0)), v_t_2466});
        } else {
          heff_drop(v_ss_2410);
          heff_drop(v_t_2465);
          V v_t_2467 = (g_list_2emap(v_go_244, v_args_246));
          return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_245, v_t_2467});
        }
      } else {
        heff_drop(v_field_249);
        V v_t_2468 = (g_list_2emap(v_go_244, v_args_246));
        return heff_tag_at_n(v_ru_24e_241_24ECall, TAG_ECall, 2, (V[]){v_g_245, v_t_2468});
      }
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2escalars_2ecallersRw_lam1, 2, 1, (V[]){v_m_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2escalars_2ecallersRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ecallersRw(a[0], a[1]);
}
V g_heff_2ecompile_2escalars_2ecallersRw_lam0(V self, V *args) {
  V v_s_2411 = args[0];
  V v_args_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_2412 = heff_dup(v_s_2411);
  V v_shape_2413 = heff_take_field(v_s_2412, 2);
  V v_tys_2414 = heff_get_n(v_s_2412, 3, 5);
  HeffT3 v_t_2415 = ({ V a_0 = heff_get_n(v_s_2411, 0, 5); V a_1 = v_args_246; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_args_246); r_; });
  V v_e_2421;
  {
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_x_2419 = v_field_2417;
      V v_x12_2420 = v_field_2418;
      heff_drop(v_x12_2420);
      v_e_2421 = v_x_2419;
    } else {
      heff_drop(v_field_2417);
      heff_drop(v_field_2418);
      v_e_2421 = NTAG(TAG_EAbandon);
    }
  }
  switch (heff_tag_of(v_e_2421)) {
  case TAG_EVar: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_e_2421, 0ULL, 3);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_2421, 0ULL, 4);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_2421, 0);
    V v_fs_2438 = heff_field(v_e_2421, 1);
    heff_take_n(v_e_2421, 3ULL, 3);
    V v_t_2443;
    switch (heff_tag_of(v_shape_2413)) {
    case TAG_ShapeRecord: {
      heff_take_n(v_shape_2413, 0ULL, 1);
      heff_drop(v_t_2437);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ShapeTag: {
      V v_t2_2441 = heff_field(v_shape_2413, 0);
      heff_take_n(v_shape_2413, 1ULL, 2);
      v_t_2443 = heff_bool(heff_strEq_c_lent(v_t_2437, v_t2_2441, 0));
      heff_drop(v_t_2437);
      heff_drop(v_t2_2441);
      break;
    }
    default: heff_nomatch(v_shape_2413);
    }
    V v_ret_24bool = heff_bool(((heff_dup(v_t_2443) == NTAG(TAG_True)) && ({ V v_t_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_fs_2438)); int c_ = ({ V v_t_2472 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_tys_2414)); int c_ = heff_intEq_c_lent(v_t_2471, v_t_2472, 0); heff_drop(v_t_2472); c_; }); heff_drop(v_t_2471); c_; })));
    heff_drop(v_tys_2414);
    heff_drop(v_fs_2438);
    heff_drop(v_t_2443);
    return v_ret_24bool;
  }
  case TAG_EMatch: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    heff_take_n(v_e_2421, 0ULL, 3);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    heff_take_n(v_e_2421, 0ULL, 1);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_2421, 0ULL, 2);
    heff_drop(v_shape_2413);
    heff_drop(v_tys_2414);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_2421);
  }
}
V g_heff_2ecompile_2escalars_2ecallersRw_lam1(V self, V *args) {
  V v_x_2469 = args[0];
  V v_p_2470 = args[1];
  V v_m_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2469);
  return (g_heff_2ecompile_2escalars_2ecallersRw(v_m_240, v_p_2470));
}
Clo g_heff_2ecompile_2escalars_2ecallsLoopW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ecallsLoopW_entry, 2, 0};

V g_heff_2ecompile_2escalars_2ecallsLoopW(V v_m_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_ECall: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_args_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      HeffT2 v_t_246 = ({ V a_0 = v_m_240; V a_1 = v_g_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_g_244); r_; });
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          heff_drop(v_rest_243);
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_args_245);
          V v_x_249 = v_field_248;
          heff_drop(v_x_249);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_field_248);
          V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x2_241_24Cons, v_args_245, v_rest_243));
          V t_0 = v_m_240;
          V t_1 = v_t_2410;
          v_m_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
      }
    }
    default: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2epartsOnto(v_x21_242, v_rest_243));
      V t_0 = v_m_240;
      V t_1 = v_t_2411;
      v_m_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2escalars_2ecallsLoopW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2ecallsLoopW(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2escalars_2esplits_str0, 6, "MkLazy");
Clo g_heff_2ecompile_2escalars_2esplits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2esplits_entry, 2, 0};

V g_heff_2ecompile_2escalars_2esplits(V v_kind_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_kind_240)) {
  case TAG_OfRecords: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      V v_fs_2411 = heff_field(v_e_241, 0);
      switch (heff_tag_of(v_fs_2411)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_fs_2411);
      }
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  case TAG_OfTags: {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_t_2458 = heff_field(v_e_241, 0);
      V v_args_2459 = heff_field(v_e_241, 1);
      V v_t_2463;
      switch (heff_tag_of(v_args_2459)) {
      case TAG_Nil: {
        v_t_2463 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        v_t_2463 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_args_2459);
      }
      V v_ret_24bool = heff_bool(((heff_dup(v_t_2463) == NTAG(TAG_True)) && !heff_strEq_c_lent(v_t_2458, ((V)&g_heff_2ecompile_2escalars_2esplits_str0), 2)));
      heff_drop(v_t_2463);
      return v_ret_24bool;
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e_241);
    }
  }
  default: return heff_nomatch(v_kind_240);
  }
}
V g_heff_2ecompile_2escalars_2esplits_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2esplits(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2epassedW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2epassedW_entry, 4, 0};

V g_heff_2ecompile_2escalars_2epassedW(V v_f_240, V v_x_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_ECall: {
      V v_g_246 = heff_field(v_x41_244, 0);
      V v_args_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_249;
      if (heff_strEq_c_lent(v_g_246, v_f_240, 1)) {
        V v_t_248 = (g_list_2efoldl_24f811568015x381874646(MK_INT(1LL), MK_INT(0LL), v_x_241, v_args_247));
        v_t_249 = heff_intAdd(v_n_242, v_t_248);
      } else {
        v_t_249 = v_n_242;
      }
      V v_t_2410 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x4_243_24Cons, v_args_247, v_rest_245));
      V t_0 = v_f_240;
      V t_1 = v_x_241;
      V t_2 = v_t_249;
      V t_3 = v_t_2410;
      v_f_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2epartsOnto(v_x41_244, v_rest_245));
      V t_0 = v_f_240;
      V t_1 = v_x_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2411;
      v_f_240 = t_0;
      v_x_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2epassedW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2epassedW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2epassedOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2epassedOnly_entry, 3, 0};

V g_heff_2ecompile_2escalars_2epassedOnly(V v_f_240, V v_x_241, V v_b_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
  V v_x1_244 = (g_heff_2ecompile_2eir_2elamW(v_x_241, v_t_243));
  if (!(heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
    V v_t_246 = (g_heff_2ecompile_2eir_2ecountW(v_x_241, MK_INT(0LL), v_t_245));
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ecompile_2escalars_2epassedW(v_f_240, v_x_241, MK_INT(0LL), v_t_247));
    if (heff_intEq_c(v_t_246, v_t_248)) {
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_242, NTAG(TAG_Nil)});
      V v_x_2410 = (g_heff_2ecompile_2escalars_2epassedW(v_f_240, v_x_241, MK_INT(0LL), v_t_249));
      V v_ret_24bool = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2410, 1));
      heff_drop(v_x_2410);
      return v_ret_24bool;
    } else {
      heff_drop(v_b_242);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_b_242);
    heff_drop(v_x1_244);
    return NTAG(TAG_False);
  }
}
V g_heff_2ecompile_2escalars_2epassedOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2epassedOnly(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2ebindsPassedW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ebindsPassedW_entry, 3, 0};

V g_heff_2ecompile_2escalars_2ebindsPassedW(V v_kind_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_ELet: {
      V v_x_245 = heff_field(v_x31_243, 0);
      V v_a_246 = heff_field(v_x31_243, 1);
      V v_b_247 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 7ULL, 3);
      V v_t_248 = (g_heff_2ecompile_2escalars_2esplits(v_kind_240, v_a_246));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = ({ V a_0 = v_f_241; V a_1 = v_x_245; V a_2 = heff_dup(v_b_247); V r_ = (g_heff_2ecompile_2escalars_2epassedOnly(a_0, a_1, a_2)); heff_drop(v_x_245); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_rest_244);
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_a_246);
          heff_drop(v_b_247);
          heff_drop(v_t_249);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_249);
          V v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_246, heff_tag_n(TAG_Cons, 2, (V[]){v_b_247, v_rest_244})});
          V t_0 = v_kind_240;
          V t_1 = v_f_241;
          V t_2 = v_t_2410;
          v_kind_240 = t_0;
          v_f_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_x_245);
        heff_drop(v_t_248);
        V v_t_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_246, heff_tag_n(TAG_Cons, 2, (V[]){v_b_247, v_rest_244})});
        V t_0 = v_kind_240;
        V t_1 = v_f_241;
        V t_2 = v_t_2411;
        v_kind_240 = t_0;
        v_f_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_kind_240;
      V t_1 = v_f_241;
      V t_2 = v_t_2412;
      v_kind_240 = t_0;
      v_f_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2ebindsPassedW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2ebindsPassedW(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2escalars_2esplitIn_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2esplitIn_lam1(V self, V *args);
V g_heff_2ecompile_2escalars_2esplitIn_lam2(V self, V *args);
V g_heff_2ecompile_2escalars_2esplitIn_lam3(V self, V *args);
Clo g_heff_2ecompile_2escalars_2esplitIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2esplitIn_entry, 3, 0};

V g_heff_2ecompile_2escalars_2esplitIn(V v_kind_240, V v_f_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_ELet: {
    V v_x_243 = heff_field(v_e_242, 0);
    V v_a_244 = heff_field(v_e_242, 1);
    V v_b_245 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_246 = (g_heff_2ecompile_2escalars_2esplits(v_kind_240, v_a_244));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ecompile_2escalars_2epassedOnly(v_f_241, v_x_243, heff_dup(v_b_245)));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_2447;
        switch (heff_tag_of(v_a_244)) {
        case TAG_EVar: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EGlobal: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELam: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EApp: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ELet: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ERecord: {
          V v_fs_2417 = heff_dup(heff_field(v_a_244, 0));
          v_t_2447 = (g_list_2emap_24s1173914895x100384474(v_fs_2417));
          break;
        }
        case TAG_EProj: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ETag: {
          V v_args_2424 = heff_dup(heff_field(v_a_244, 1));
          v_t_2447 = v_args_2424;
          break;
        }
        case TAG_EMatch: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPrim: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EPrimCall: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ECall: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EInt: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EStr: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBytes: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFixed: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFloat32: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EAbandon: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EBool: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_ESet: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EValues: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        case TAG_EFix: {
          v_t_2447 = NTAG(TAG_Nil);
          break;
        }
        default: heff_nomatch(v_a_244);
        }
        V v_m_2448 = (g_prelude_2etraverse_24s205209257x1087869143(heff_dup(v_x_243), v_t_2447));
        return heff_clo_n(g_heff_2ecompile_2escalars_2esplitIn_lam0, 1, 6, (V[]){v_m_2448, heff_dup(v_kind_240), heff_dup(v_f_241), v_b_245, v_x_243, v_a_244});
      } else {
        heff_drop(v_t_247);
        V v_m_24111 = (g_heff_2ecompile_2escalars_2esplitIn(v_kind_240, v_f_241, v_a_244));
        return heff_clo_n(g_heff_2ecompile_2escalars_2esplitIn_lam1, 1, 5, (V[]){v_m_24111, heff_dup(v_kind_240), heff_dup(v_f_241), v_b_245, v_x_243});
      }
    } else {
      heff_drop(v_t_246);
      V v_m_24120 = (g_heff_2ecompile_2escalars_2esplitIn(v_kind_240, v_f_241, v_a_244));
      return heff_clo_n(g_heff_2ecompile_2escalars_2esplitIn_lam2, 1, 5, (V[]){v_m_24120, heff_dup(v_kind_240), heff_dup(v_f_241), v_b_245, v_x_243});
    }
  }
  default: {
    return (g_heff_2ecompile_2eir_2etraversePartsM_24s612917181x2034774903(heff_clo_n(g_heff_2ecompile_2escalars_2esplitIn_lam3, 2, 2, (V[]){heff_dup(v_kind_240), heff_dup(v_f_241)}), v_e_242));
  }
  }
}
V g_heff_2ecompile_2escalars_2esplitIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2esplitIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2escalars_2esplitIn_lam0(V self, V *args) {
  V v_n_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_kind_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_n_2452 = heff_field(v_x2_2450, 1);
    V v_ru_24x2_2450_24MkPair = heff_take_reuse_n(v_x2_2450, 3ULL, 2);
    V v_m_2453 = ({ V a_0 = v_kind_240; V a_1 = v_f_241; V a_2 = v_b_245; V r_ = (g_heff_2ecompile_2escalars_2esplitIn(a_0, a_1, a_2)); heff_drop(v_kind_240); heff_drop(v_f_241); r_; });
    V v_x2_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_n_2452}));
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_MkPair: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_n_2456 = heff_field(v_x2_2454, 1);
      V v_ru_24x2_2454_24MkPair = heff_take_reuse_n(v_x2_2454, 3ULL, 2);
      V v_x_2457 = v_x_243;
      V v_a_2458 = v_a_244;
      V v_b_2459 = v_x_2455;
      V v_fds_2460 = v_x_2451;
      V v_e_2461 = v_a_2458;
      V v_fds_2462 = heff_dup(v_fds_2460);
      V v_t_24104;
      switch (heff_tag_of(v_e_2461)) {
      case TAG_EVar: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EGlobal: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_ELam: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EApp: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_ELet: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_ERecord: {
        V v_fs_2472 = heff_field(v_e_2461, 0);
        V v_ts_2473 = heff_field(v_e_2461, 1);
        V v_ru_24e_2461_24ERecord = heff_take_reuse_n(v_e_2461, 3ULL, 2);
        V v_t_2474 = (g_list_2ezipWith_24s634961829x758866838(v_fs_2472, v_fds_2462));
        v_t_24104 = heff_tag_at_n(v_ru_24e_2461_24ERecord, TAG_ERecord, 2, (V[]){v_t_2474, v_ts_2473});
        break;
      }
      case TAG_EProj: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_ETag: {
        V v_t_2479 = heff_field(v_e_2461, 0);
        V v_ts_2481 = heff_field(v_e_2461, 2);
        V v_ru_24e_2461_24ETag = heff_take_reuse_n(v_e_2461, 5ULL, 3);
        V v_t_2482 = (g_list_2emap_24s813634804x1844296865(v_fds_2462));
        v_t_24104 = heff_tag_at_n(v_ru_24e_2461_24ETag, TAG_ETag, 3, (V[]){v_t_2479, v_t_2482, v_ts_2481});
        break;
      }
      case TAG_EMatch: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EPrim: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EPrimCall: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_ECall: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EInt: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EFloat: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EStr: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EBytes: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EFixed: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EFloat32: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EAbandon: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EBool: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_ESet: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EValues: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      case TAG_EFix: {
        heff_drop(v_fds_2462);
        v_t_24104 = v_e_2461;
        break;
      }
      default: heff_nomatch(v_e_2461);
      }
      V v_ps_24105 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_2450_24MkPair, TAG_MkPair, 2, (V[]){v_x_2457, v_t_24104}), NTAG(TAG_Nil)});
      V v_m_24106 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_24105; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop_tag(v_ps_24105, 2); r_; });
      V v_t_24107 = (g_std_2eordmap_2esize(v_m_24106));
      V v_z_24108;
      if (heff_intEq_c(v_t_24107, MK_INT(0LL))) {
        heff_drop(v_m_24106);
        v_z_24108 = v_b_2459;
      } else {
        v_z_24108 = ({ V a_0 = v_m_24106; V a_1 = v_b_2459; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_24106); r_; });
      }
      V v_t_24109 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fds_2460));
      V v_x_24110 = ({ V a_0 = v_z_24108; V a_1 = v_t_24109; V r_ = (g_list_2efoldl_24s2146051398x720013633(a_0, a_1)); heff_drop(v_t_24109); r_; });
      return heff_tag_at_n(v_ru_24x2_2454_24MkPair, TAG_MkPair, 2, (V[]){v_x_24110, v_n_2456});
    }
    default: return heff_nomatch(v_x2_2454);
    }
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2escalars_2esplitIn_lam1(V self, V *args) {
  V v_n_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  V v_kind_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24113 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_n_24112}));
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_MkPair: {
    V v_x_24114 = heff_field(v_x2_24113, 0);
    V v_n_24115 = heff_field(v_x2_24113, 1);
    V v_ru_24x2_24113_24MkPair = heff_take_reuse_n(v_x2_24113, 3ULL, 2);
    V v_m_24116 = ({ V a_0 = v_kind_240; V a_1 = v_f_241; V a_2 = v_b_245; V r_ = (g_heff_2ecompile_2escalars_2esplitIn(a_0, a_1, a_2)); heff_drop(v_kind_240); heff_drop(v_f_241); r_; });
    V v_x2_24117 = heff_tr(heff_call(v_m_24116, 1, (V[]){v_n_24115}));
    switch (heff_tag_of(v_x2_24117)) {
    case TAG_MkPair: {
      V v_x_24118 = heff_field(v_x2_24117, 0);
      V v_n_24119 = heff_field(v_x2_24117, 1);
      heff_take_n(v_x2_24117, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24113_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_243, v_x_24114, v_x_24118}), v_n_24119});
    }
    default: return heff_nomatch(v_x2_24117);
    }
  }
  default: return heff_nomatch(v_x2_24113);
  }
}
V g_heff_2ecompile_2escalars_2esplitIn_lam2(V self, V *args) {
  V v_n_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  V v_kind_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_b_245 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_n_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_MkPair: {
    V v_x_24123 = heff_field(v_x2_24122, 0);
    V v_n_24124 = heff_field(v_x2_24122, 1);
    V v_ru_24x2_24122_24MkPair = heff_take_reuse_n(v_x2_24122, 3ULL, 2);
    V v_m_24125 = ({ V a_0 = v_kind_240; V a_1 = v_f_241; V a_2 = v_b_245; V r_ = (g_heff_2ecompile_2escalars_2esplitIn(a_0, a_1, a_2)); heff_drop(v_kind_240); heff_drop(v_f_241); r_; });
    V v_x2_24126 = heff_tr(heff_call(v_m_24125, 1, (V[]){v_n_24124}));
    switch (heff_tag_of(v_x2_24126)) {
    case TAG_MkPair: {
      V v_x_24127 = heff_field(v_x2_24126, 0);
      V v_n_24128 = heff_field(v_x2_24126, 1);
      heff_take_n(v_x2_24126, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_243, v_x_24123, v_x_24127}), v_n_24128});
    }
    default: return heff_nomatch(v_x2_24126);
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2escalars_2esplitIn_lam3(V self, V *args) {
  V v_x_24129 = args[0];
  V v_p_24130 = args[1];
  V v_kind_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24129);
  return ({ V a_0 = v_kind_240; V a_1 = v_f_241; V a_2 = v_p_24130; V r_ = (g_heff_2ecompile_2escalars_2esplitIn(a_0, a_1, a_2)); heff_drop(v_kind_240); heff_drop(v_f_241); r_; });
}
V g_heff_2ecompile_2escalars_2efoundWith_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2efoundWith_lam1(V self, V *args);
V g_heff_2ecompile_2escalars_2efoundWith_lam2(V self, V *args);
V g_heff_2ecompile_2escalars_2efoundWith_lam3(V self, V *args);
V g_heff_2ecompile_2escalars_2efoundWith_lam4(V self, V *args);
Clo g_heff_2ecompile_2escalars_2efoundWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2efoundWith_entry, 3, 0};

V g_heff_2ecompile_2escalars_2efoundWith(V v_kind_240, V v_d_241, V v_f_242) {
top: ;
  V v_kind_243 = heff_dup(v_kind_240);
  V v_d_244 = heff_dup(v_d_241);
  V v_body_245 = heff_take_field(v_d_244, 2);
  V v_key_246 = heff_get_n(v_d_244, 0, 3);
  V v_t_2450;
  switch (heff_tag_of(v_body_245)) {
  case TAG_EVar: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_body_245, 0);
    V v_b_2410 = heff_field(v_body_245, 1);
    V v_ru_24body_245_24ELam = heff_take_reuse_n(v_body_245, 3ULL, 2);
    switch (heff_tag_of(v_kind_243)) {
    case TAG_OfRecords: {
      heff_drop(v_xs_249);
      V v_t_2411 = heff_tag_at_n(v_ru_24body_245_24ELam, TAG_Cons, 2, (V[]){v_b_2410, NTAG(TAG_Nil)});
      v_t_2450 = ({ V a_0 = v_kind_243; V a_1 = v_key_246; V a_2 = v_t_2411; V r_ = (g_heff_2ecompile_2escalars_2ebindsPassedW(a_0, a_1, a_2)); heff_drop(v_key_246); r_; });
      break;
    }
    case TAG_OfTags: {
      V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2escalars_2efoundWith_lam0, 1, 1, (V[]){heff_dup(v_b_2410)}); V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_t_2414 = heff_tag_at_n(v_ru_24body_245_24ELam, TAG_Cons, 2, (V[]){v_b_2410, NTAG(TAG_Nil)});
        v_t_2450 = ({ V a_0 = v_kind_243; V a_1 = v_key_246; V a_2 = v_t_2414; V r_ = (g_heff_2ecompile_2escalars_2ebindsPassedW(a_0, a_1, a_2)); heff_drop(v_key_246); r_; });
      } else {
        heff_drop(v_key_246);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24body_245_24ELam, 2);
        heff_drop(v_t_2413);
        v_t_2450 = NTAG(TAG_False);
      }
      break;
    }
    default: heff_nomatch(v_kind_243);
    }
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_body_245, 0ULL, 3);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_body_245, 0ULL, 4);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_body_245, 0ULL, 3);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_nf(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EBytes: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_na(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EBool: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_ESet: {
    heff_take_n(v_body_245, 0ULL, 3);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EValues: {
    heff_take_n(v_body_245, 0ULL, 1);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_body_245, 0ULL, 2);
    heff_drop(v_kind_243);
    heff_drop(v_key_246);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_body_245);
  }
  if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
    heff_drop(v_t_2450);
    V v_kind_2451 = heff_dup(v_kind_240);
    V v_d_2452 = v_d_241;
    V v_t_2453 = heff_dup(heff_rfield(v_d_2452, 2));
    V v_m_2463;
    switch (heff_tag_of(v_t_2453)) {
    case TAG_ELam: {
      V v_xs_2454 = heff_field(v_t_2453, 0);
      V v_b_2455 = heff_field(v_t_2453, 1);
      heff_take_n(v_t_2453, 3ULL, 2);
      V v_m_2456 = ({ V a_0 = v_kind_2451; V a_1 = heff_rfield(v_d_2452, 0); V a_2 = v_b_2455; V r_ = (g_heff_2ecompile_2escalars_2esplitIn(a_0, a_1, a_2)); heff_drop(v_kind_2451); r_; });
      v_m_2463 = heff_clo_n(g_heff_2ecompile_2escalars_2efoundWith_lam1, 1, 3, (V[]){v_m_2456, v_d_2452, v_xs_2454});
      break;
    }
    default: {
      heff_drop(v_kind_2451);
      heff_drop(v_t_2453);
      v_m_2463 = heff_clo_n(g_heff_2ecompile_2escalars_2efoundWith_lam2, 1, 1, (V[]){v_d_2452});
      break;
    }
    }
    return heff_clo_n(g_heff_2ecompile_2escalars_2efoundWith_lam3, 1, 3, (V[]){v_m_2463, v_kind_240, v_f_242});
  } else {
    heff_drop(v_kind_240);
    heff_drop(v_d_241);
    heff_drop(v_t_2450);
    return heff_clo_n(g_heff_2ecompile_2escalars_2efoundWith_lam4, 1, 1, (V[]){v_f_242});
  }
}
V g_heff_2ecompile_2escalars_2efoundWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2efoundWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2escalars_2efoundWith_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_b_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2412; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2escalars_2esomeApart(a_0, a_1)); heff_drop(v_x_2412); heff_drop(v_b_2410); r_; });
}
V g_heff_2ecompile_2escalars_2efoundWith_lam1(V self, V *args) {
  V v_n_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_d_2452 = heff_env(self)[1];
  V v_xs_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_n_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_n_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    V v_t_2461 = ({ V rv_2 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2454, v_x_2459}); V rr_ = heff_rec_reuse_nf(v_d_2452, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){v_t_2461, v_n_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2ecompile_2escalars_2efoundWith_lam2(V self, V *args) {
  V v_n_2462 = args[0];
  V v_d_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_2452, v_n_2462});
}
V g_heff_2ecompile_2escalars_2efoundWith_lam3(V self, V *args) {
  V v_n_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_kind_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_n_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_n_2467 = heff_field(v_x2_2465, 1);
    V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
    V v_t_2468 = (g_heff_2ecompile_2escalars_2eslotsOf(v_kind_240, heff_dup(v_x_2466)));
    V v_b_2469 = heff_rec_n(2, shape_def__slots, (V[]){v_x_2466, v_t_2468});
    V v_x_2470 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_b_2469, 1)));
    V v_y_2471 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_f_242, 1)));
    V v_t_2472;
    if (heff_intLt_c(v_y_2471, v_x_2470)) {
      heff_drop_rec(v_f_242, 2);
      v_t_2472 = v_b_2469;
    } else {
      heff_drop_rec(v_b_2469, 2);
      v_t_2472 = v_f_242;
    }
    return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){v_t_2472, v_n_2467});
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2escalars_2efoundWith_lam4(V self, V *args) {
  V v_n_2473 = args[0];
  V v_f_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_242, v_n_2473});
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam1(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam2(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam3(V self, V *args);
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam4(V self, V *args);
Clo g_heff_2ecompile_2escalars_2ematchRw_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ematchRw_24tok2_entry, 5, 0};

V g_heff_2ecompile_2escalars_2ematchRw_24tok2(V v_tok_240, V v_go_241, V v_s_242, V v_arms_243, V v_m_244) {
top: ;
  switch (heff_tag_of(v_arms_243)) {
  case TAG_Nil: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam0, 1, 1, (V[]){v_go_241}), heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_s_242, v_arms_243})));
  }
  case TAG_Cons: {
    V v_arms1_246 = heff_dup(heff_field(v_arms_243, 0));
    V v_arms2_247 = heff_dup(heff_field(v_arms_243, 1));
    switch (heff_tag_of(v_arms1_246)) {
    case TAG_MkArm: {
      V v_t_248 = heff_field(v_arms1_246, 0);
      V v_vs_249 = heff_field(v_arms1_246, 1);
      V v_b_2410 = heff_field(v_arms1_246, 2);
      V v_ru_24arms1_246_24MkArm = heff_take_reuse_n(v_arms1_246, 7ULL, 3);
      switch (heff_tag_of(v_arms2_247)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_m_244)) {
        case TAG_Nothing: {
          heff_drop(v_t_248);
          heff_drop(v_vs_249);
          heff_drop(v_b_2410);
          return (g_heff_2ecompile_2eir_2emapParts_24tok3(v_ru_24arms1_246_24MkArm, heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam1, 1, 1, (V[]){v_go_241}), heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_s_242, v_arms_243})));
        }
        case TAG_Just: {
          V v_sl_2412 = heff_field(v_m_244, 0);
          heff_drop_tag(v_arms_243, 2);
          V v_shape_2413 = heff_dup(heff_rfield(v_sl_2412, 2));
          V v_vars_2414 = heff_dup(heff_rfield(v_sl_2412, 4));
          switch (heff_tag_of(v_shape_2413)) {
          case TAG_ShapeRecord: {
            V v_ru_24shape_2413_24ShapeRecord = heff_take_reuse_n(v_shape_2413, 0ULL, 1);
            heff_drop(v_vars_2414);
            V v_t_2416 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24arms1_246_24MkArm, TAG_MkArm, 3, (V[]){v_t_248, v_vs_249, v_b_2410}), NTAG(TAG_Nil)});
            return (g_heff_2ecompile_2eir_2emapParts_24tok1(v_ru_24shape_2413_24ShapeRecord, heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam2, 1, 1, (V[]){v_go_241}), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_242, v_t_2416})));
          }
          case TAG_ShapeTag: {
            V v_t2_2418 = heff_field(v_shape_2413, 0);
            V v_ru_24shape_2413_24ShapeTag = heff_take_reuse_n(v_shape_2413, 1ULL, 2);
            if (heff_strEq_c_lent(v_t_248, v_t2_2418, 2)) {
              heff_drop_cell(v_tok_240, 2);
              heff_drop(v_s_242);
              heff_drop(v_t_248);
              heff_drop_cell(v_ru_24arms1_246_24MkArm, 3);
              heff_drop_cell(v_ru_24shape_2413_24ShapeTag, 2);
              V v_ps_2420 = (g_list_2ezipWith_24s1928181476x241816070(v_vs_249, v_vars_2414));
              V v_m_2421 = ({ V a_0 = NTAG(TAG_Tip); V a_1 = v_ps_2420; V r_ = (g_list_2efoldl_24s2127176832x914341824(a_0, a_1)); heff_drop(v_ps_2420); r_; });
              V v_t_2422 = (g_std_2eordmap_2esize(v_m_2421));
              V v_t_2423;
              if (heff_intEq_c(v_t_2422, MK_INT(0LL))) {
                heff_drop(v_m_2421);
                v_t_2423 = v_b_2410;
              } else {
                v_t_2423 = ({ V a_0 = v_m_2421; V a_1 = v_b_2410; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2421); r_; });
              }
              return heff_tail(v_go_241, 1, (V[]){v_t_2423});
            } else {
              heff_drop(v_vars_2414);
              V v_t_2424 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24arms1_246_24MkArm, TAG_MkArm, 3, (V[]){v_t_248, v_vs_249, v_b_2410}), NTAG(TAG_Nil)});
              return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam3, 1, 1, (V[]){v_go_241}), heff_tag_at_n(v_ru_24shape_2413_24ShapeTag, TAG_EMatch, 2, (V[]){v_s_242, v_t_2424})));
            }
          }
          default: return heff_nomatch(v_shape_2413);
          }
        }
        default: return heff_nomatch(v_m_244);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_arms2_247, 0ULL, 2);
        heff_drop(v_t_248);
        heff_drop(v_vs_249);
        heff_drop(v_b_2410);
        return (g_heff_2ecompile_2eir_2emapParts_24tok3(v_ru_24arms1_246_24MkArm, heff_clo_n(g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam4, 1, 1, (V[]){v_go_241}), heff_tag_at_n(v_tok_240, TAG_EMatch, 2, (V[]){v_s_242, v_arms_243})));
      }
      default: return heff_nomatch(v_arms2_247);
      }
    }
    default: return heff_nomatch(v_arms1_246);
    }
  }
  default: return heff_nomatch(v_arms_243);
  }
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2escalars_2ematchRw_24tok2(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_245);
  return v_go_241;
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2411);
  return v_go_241;
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2417);
  return v_go_241;
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2425);
  return v_go_241;
}
V g_heff_2ecompile_2escalars_2ematchRw_24tok2_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_go_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2428);
  return v_go_241;
}