// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Mixed 48213
#define TAG_MkArm 55352
#define TAG_NoRecord 51797
#define TAG_PassedOther 52780
#define TAG_PassedRecord 11102
#define TAG_PassedSame 49925
#define TAG_Records 39950
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_at 9882
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_name 9869138
#define LBL_param 307795111
#define LBL_slots 310891087
#define LBL_tys 324872
#define LBL_vars 10107635
static uint32_t shape_at__param__labels__tys__vars[] = {LBL_at, LBL_param, LBL_labels, LBL_tys, LBL_vars};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_key__slots[] = {LBL_key, LBL_slots};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2erepr_2etyIn(V, V);
V g_heff_2ecompile_2erepr_2etyIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2etyIn_clo;
V g_heff_2ecompile_2escalars_2eargsRw(V, V, V, V);
V g_heff_2ecompile_2escalars_2eargsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eargsRw_clo;
V g_heff_2ecompile_2escalars_2ecallsW(V, V, V);
V g_heff_2ecompile_2escalars_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ecallsW_clo;
HeffT2 g_heff_2ecompile_2escalars_2edefWith_24cpr(V, V, V);
V g_heff_2ecompile_2escalars_2eexitsWhole(V, V, V, V);
V g_heff_2ecompile_2escalars_2eexitsWhole_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eexitsWhole_clo;
HeffT2 g_heff_2ecompile_2escalars_2efieldVarOf_24cpr(V, V, V);
V g_heff_2ecompile_2escalars_2ejustsOf(V);
V g_heff_2ecompile_2escalars_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ejustsOf_clo;
V g_heff_2ecompile_2escalars_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2escalars_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ejustsOf_24dps_clo;
HeffT2 g_heff_2ecompile_2escalars_2elabelVar_24cpr(V, V, V);
V g_heff_2ecompile_2escalars_2elamWholeW(V, V, V, V);
V g_heff_2ecompile_2escalars_2elamWholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2elamWholeW_clo;
HeffT2 g_heff_2ecompile_2escalars_2eloopDefs_24cpr(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2emergeTy(V, V);
V g_heff_2ecompile_2escalars_2emergeTy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2emergeTy_clo;
V g_heff_2ecompile_2escalars_2eparamsRw(V, V, V);
V g_heff_2ecompile_2escalars_2eparamsRw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eparamsRw_clo;
V g_heff_2ecompile_2escalars_2epassedOf(V, V);
V g_heff_2ecompile_2escalars_2epassedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2epassedOf_clo;
V g_heff_2ecompile_2escalars_2erw(V, V);
V g_heff_2ecompile_2escalars_2erw_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2erw_clo;
V g_heff_2ecompile_2escalars_2erw_24dps(V, V, V, V);
V g_heff_2ecompile_2escalars_2erw_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2erw_24dps_clo;
V g_heff_2ecompile_2escalars_2esameLabels(V, V);
V g_heff_2ecompile_2escalars_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2esameLabels_clo;
V g_heff_2ecompile_2escalars_2eselfLast(V, V, V);
V g_heff_2ecompile_2escalars_2eselfLast_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eselfLast_clo;
V g_heff_2ecompile_2escalars_2eslotFor(V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotFor_clo;
V g_heff_2ecompile_2escalars_2eslotWith(V, V, V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotWith_clo;
V g_heff_2ecompile_2escalars_2eslotsIn(V, V, V, V);
V g_heff_2ecompile_2escalars_2eslotsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsIn_clo;
V g_heff_2ecompile_2escalars_2eslotsOf(V);
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2eslotsOf_clo;
V g_heff_2ecompile_2escalars_2espread(V, V, V);
V g_heff_2ecompile_2escalars_2espread_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2espread_clo;
V g_heff_2ecompile_2escalars_2ewholeW(V, V, V, V);
V g_heff_2ecompile_2escalars_2ewholeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewholeW_clo;
V g_heff_2ecompile_2escalars_2ewrapArg(V, V);
V g_heff_2ecompile_2escalars_2ewrapArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewrapArg_clo;
V g_heff_2ecompile_2escalars_2ewrapArgs(V, V, V);
V g_heff_2ecompile_2escalars_2ewrapArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2escalars_2ewrapArgs_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1119339522x336883298_24cpr(V, V);
V g_list_2efind_24s882806058x114262163(V, V);
V g_list_2efind_24s882806058x114262163_entry(V self, V *a);
extern Clo g_list_2efind_24s882806058x114262163_clo;
HeffT2 g_list_2efind_24s882806058x114262163_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f2092936166x2062766724(V, V, V);
V g_list_2efoldl_24f2092936166x2062766724_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2092936166x2062766724_clo;
V g_list_2efoldl_24f915973885x1443507785(V, V, V);
V g_list_2efoldl_24f915973885x1443507785_entry(V self, V *a);
extern Clo g_list_2efoldl_24f915973885x1443507785_clo;
V g_list_2efoldl_24s578974906x2018699728(V, V);
V g_list_2efoldl_24s578974906x2018699728_entry(V self, V *a);
extern Clo g_list_2efoldl_24s578974906x2018699728_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1259666496x1713656817(V, V, V, V, V);
V g_list_2ezipWith_24s1259666496x1713656817_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1259666496x1713656817_clo;
V g_list_2ezipWith_24s1928181476x241816070(V, V);
V g_list_2ezipWith_24s1928181476x241816070_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_clo;
HeffT2 g_prelude_2etraverse_24s1266173017x1167058160_24cpr(V, V);
V g_prelude_2etraverse_24s183237039x2129949159(V, V, V, V);
V g_prelude_2etraverse_24s183237039x2129949159_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s183237039x2129949159_clo;
Clo g_heff_2ecompile_2escalars_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2escalars_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2escalars_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2escalars_2eselfLast_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2eselfLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eselfLast_entry, 3, 0};

V g_heff_2ecompile_2escalars_2eselfLast(V v_f_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_take_n(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_ELam: {
    heff_take_n(v_e_242, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EApp: {
    heff_take_n(v_e_242, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 4ULL, 3);
    V t_0 = v_f_240;
    V t_1 = v_acc_241;
    V t_2 = v_b_2411;
    v_f_240 = t_0;
    v_acc_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_242, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EProj: {
    heff_take_n(v_e_242, 0ULL, 4);
    return v_acc_241;
  }
  case TAG_ETag: {
    heff_take_n(v_e_242, 0ULL, 3);
    return v_acc_241;
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2escalars_2eselfLast_lam0, 2, 1, (V[]){heff_dup(v_f_240)}); V a_1 = v_acc_241; V a_2 = v_arms_2422; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2422); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_242, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_ECall: {
    V v_g_2432 = heff_field(v_e_242, 0);
    V v_as_2433 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2432, v_f_240, 1)) {
      return heff_tag_at_n(v_ru_24e_242_24ECall, TAG_Cons, 2, (V[]){v_as_2433, v_acc_241});
    } else {
      heff_drop(v_as_2433);
      heff_drop_cell(v_ru_24e_242_24ECall, 2);
      return v_acc_241;
    }
  }
  case TAG_EInt: {
    heff_take_n(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EFloat: {
    heff_take_na(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EStr: {
    heff_take_n(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_242, 0ULL, 2);
    return v_acc_241;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_242, 0ULL, 1);
    return v_acc_241;
  }
  case TAG_EAbandon: {
    return v_acc_241;
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    return v_acc_241;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2escalars_2eselfLast_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eselfLast(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2eselfLast_lam0(V self, V *args) {
  V v_a_2423 = args[0];
  V v_arm_2424 = args[1];
  V v_f_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_arm_2424)) {
  case TAG_MkArm: {
    V v_b_2427 = heff_field(v_arm_2424, 2);
    heff_take_n(v_arm_2424, 4ULL, 3);
    v_t_2428 = v_b_2427;
    break;
  }
  default: heff_nomatch(v_arm_2424);
  }
  return ({ V a_0 = v_f_240; V a_1 = v_a_2423; V a_2 = v_t_2428; V r_ = (g_heff_2ecompile_2escalars_2eselfLast(a_0, a_1, a_2)); heff_drop(v_f_240); r_; });
}
Clo g_heff_2ecompile_2escalars_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ecallsW_entry, 3, 0};

V g_heff_2ecompile_2escalars_2ecallsW(V v_f_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_g_249 = heff_field(v_x31_243, 0);
      V v_as_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI(v_as_2410, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_g_249, v_t_2411});
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x31_243, 1);
      V v_b_2414 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2415;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2416, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2418;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2419 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2419, v_rest_244});
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2424 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI(v_as_2424, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2426;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2427 = heff_field(v_x31_243, 0);
      V v_arms_2428 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2427, v_t_2429});
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2432 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI(v_as_2432, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2433;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2434 = heff_field(v_x31_243, 0);
      V v_as_2435 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2437;
      if (heff_strEq_c_lent(v_g_2434, v_f_240, 1)) {
        v_t_2437 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        v_t_2437 = v_n_241;
      }
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI(v_as_2435, v_rest_244));
      V t_0 = v_f_240;
      V t_1 = v_t_2437;
      V t_2 = v_t_2438;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_f_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_f_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2ecallsW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2ecallsW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2escalars_2ewholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ewholeW_entry, 4, 0};

V g_heff_2ecompile_2escalars_2ewholeW(V v_p_240, V v_ls_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      V v_y_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_248;
      if (heff_strEq_c_lent(v_y_246, v_p_240, 1)) {
        v_t_248 = heff_intAdd(v_n_242, MK_INT(1LL));
      } else {
        v_t_248 = v_n_242;
      }
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_t_248;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2411 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_2411, v_rest_245});
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2412 = heff_field(v_x41_244, 0);
      V v_as_2413 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI(v_as_2413, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_2412, v_t_2414});
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2416 = heff_field(v_x41_244, 1);
      V v_b_2417 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_2418 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_a_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2417, v_rest_245})});
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2418;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2419 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2421 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2419, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2421;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2422 = heff_field(v_x41_244, 0);
      V v_l_2423 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 4);
      V v_t_2460;
      switch (heff_tag_of(v_e_2422)) {
      case TAG_EVar: {
        V v_y_2426 = heff_dup(heff_field(v_e_2422, 0));
        v_t_2460 = heff_strEq_lent(v_p_240, v_y_2426, 2);
        break;
      }
      case TAG_EGlobal: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EApp: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        v_t_2460 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_2422);
      }
      if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
        heff_drop(v_t_2460);
        V v_t_2461 = ({ V a_0 = v_l_2423; V a_1 = v_ls_241; V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, a_1)); heff_drop(v_l_2423); r_; });
        if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x4_243_24Cons, 2);
          heff_drop(v_e_2422);
          heff_drop(v_t_2461);
          V t_0 = v_p_240;
          V t_1 = v_ls_241;
          V t_2 = v_n_242;
          V t_3 = v_rest_245;
          v_p_240 = t_0;
          v_ls_241 = t_1;
          v_n_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        } else {
          heff_drop(v_t_2461);
          V t_0 = v_p_240;
          V t_1 = v_ls_241;
          V t_2 = v_n_242;
          V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2422, v_rest_245});
          v_p_240 = t_0;
          v_ls_241 = t_1;
          v_n_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      } else {
        heff_drop(v_l_2423);
        heff_drop(v_t_2460);
        V t_0 = v_p_240;
        V t_1 = v_ls_241;
        V t_2 = v_n_242;
        V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2422, v_rest_245});
        v_p_240 = t_0;
        v_ls_241 = t_1;
        v_n_242 = t_2;
        v_x4_243 = t_3;
        goto top;
      }
    }
    case TAG_ETag: {
      V v_as_2463 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2465 = (g_heff_2ecompile_2eir_2eappendI(v_as_2463, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2465;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2466 = heff_field(v_x41_244, 0);
      V v_arms_2467 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2468 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2467, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2466, v_t_2468});
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2471 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2472 = (g_heff_2ecompile_2eir_2eappendI(v_as_2471, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2472;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2474 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2475 = (g_heff_2ecompile_2eir_2eappendI(v_as_2474, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2475;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2ewholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2ewholeW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2elamWholeW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2elamWholeW_entry, 4, 0};

V g_heff_2ecompile_2escalars_2elamWholeW(V v_p_240, V v_ls_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    return v_n_242;
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_EVar: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      V v_t_2410 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_b_249, NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2ecompile_2escalars_2ewholeW(v_p_240, v_ls_241, v_n_242, v_t_2410));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_t_2411;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2412 = heff_field(v_x41_244, 0);
      V v_as_2413 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eir_2eappendI(v_as_2413, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_f_2412, v_t_2414});
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2416 = heff_field(v_x41_244, 1);
      V v_b_2417 = heff_field(v_x41_244, 2);
      heff_take_n(v_x41_244, 6ULL, 3);
      V v_t_2418 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_a_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2417, v_rest_245})});
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2418;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2419 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2421 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2419, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2421;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2422 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 4);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_2422, v_rest_245});
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2427 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 3);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI(v_as_2427, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2429;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2430 = heff_field(v_x41_244, 0);
      V v_arms_2431 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_t_2432 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2431, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_s_2430, v_t_2432});
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_as_2435 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI(v_as_2435, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2436;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_ECall: {
      V v_as_2438 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 2ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2eappendI(v_as_2438, v_rest_245));
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_t_2439;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x41_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x41_244, 0ULL, 2);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      V t_0 = v_p_240;
      V t_1 = v_ls_241;
      V t_2 = v_n_242;
      V t_3 = v_rest_245;
      v_p_240 = t_0;
      v_ls_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2elamWholeW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2elamWholeW(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2escalars_2eexitsWhole_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2eexitsWhole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eexitsWhole_entry, 4, 0};

V g_heff_2ecompile_2escalars_2eexitsWhole(V v_f_240, V v_p_241, V v_ls_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_245);
  }
  case TAG_EGlobal: {
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_247);
  }
  case TAG_ELam: {
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2410);
  }
  case TAG_EApp: {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2413);
  }
  case TAG_ELet: {
    V v_b_2416 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 4ULL, 3);
    V t_0 = v_f_240;
    V t_1 = v_p_241;
    V t_2 = v_ls_242;
    V t_3 = v_b_2416;
    v_f_240 = t_0;
    v_p_241 = t_1;
    v_ls_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2419);
  }
  case TAG_EProj: {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2424);
  }
  case TAG_ETag: {
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2428);
  }
  case TAG_EMatch: {
    V v_arms_2430 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2escalars_2eexitsWhole_lam0, 2, 3, (V[]){heff_dup(v_f_240), heff_dup(v_p_241), heff_dup(v_ls_242)}); V a_1 = MK_INT(0LL); V a_2 = v_arms_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2430); r_; });
  }
  case TAG_EPrim: {
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2439);
  }
  case TAG_EPrimCall: {
    V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2442);
  }
  case TAG_ECall: {
    V v_g_2443 = heff_field(v_e_243, 0);
    V v_as_2444 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    if (heff_strEq_c_lent(v_g_2443, v_f_240, 0)) {
      heff_drop(v_g_2443);
      heff_drop(v_as_2444);
      heff_drop_cell(v_ru_24e_243_24ECall, 2);
      return MK_INT(0LL);
    } else {
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_g_2443, v_as_2444}), NTAG(TAG_Nil)});
      HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2446);
    }
  }
  case TAG_EInt: {
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2448);
  }
  case TAG_EFloat: {
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2450);
  }
  case TAG_EStr: {
    V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2452);
  }
  case TAG_EBytes: {
    V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2454);
  }
  case TAG_EFixed: {
    V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2457);
  }
  case TAG_EFloat32: {
    V v_t_2459 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2459);
  }
  case TAG_EAbandon: {
    V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2460);
  }
  case TAG_EFix: {
    V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, NTAG(TAG_Nil)});
    HEFF_LAST return g_heff_2ecompile_2escalars_2ewholeW(v_p_241, v_ls_242, MK_INT(0LL), v_t_2463);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2escalars_2eexitsWhole_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2escalars_2eexitsWhole(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2escalars_2eexitsWhole_lam0(V self, V *args) {
  V v_n_2431 = args[0];
  V v_arm_2432 = args[1];
  V v_f_240 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_ls_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2436;
  switch (heff_tag_of(v_arm_2432)) {
  case TAG_MkArm: {
    V v_b_2435 = heff_field(v_arm_2432, 2);
    heff_take_n(v_arm_2432, 4ULL, 3);
    v_t_2436 = v_b_2435;
    break;
  }
  default: heff_nomatch(v_arm_2432);
  }
  V v_t_2437 = ({ V a_0 = v_f_240; V a_1 = v_p_241; V a_2 = v_ls_242; V a_3 = v_t_2436; V r_ = (g_heff_2ecompile_2escalars_2eexitsWhole(a_0, a_1, a_2, a_3)); heff_drop(v_f_240); heff_drop(v_p_241); heff_drop(v_ls_242); r_; });
  return heff_intAdd(v_n_2431, v_t_2437);
}
V g_heff_2ecompile_2escalars_2epassedOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2epassedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2epassedOf_entry, 2, 0};

V g_heff_2ecompile_2escalars_2epassedOf(V v_p_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_y_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_y_242, v_p_240, 1)) {
      return NTAG(TAG_PassedSame);
    } else {
      return NTAG(TAG_PassedOther);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_PassedOther);
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_e_241, 0);
    V v_ts_2413 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ERecord = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2412)));
    V v_t_2415 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_fs_2412; V r_ = (g_list_2efoldl_24f2092936166x2062766724(a_0, a_1, a_2)); heff_drop(v_fs_2412); r_; });
    V v_t_2416 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2415, MK_INT(1LL))));
    V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2epassedOf_lam0, 1, 1, (V[]){v_ts_2413}), v_t_2416));
    return heff_tag_at_n(v_ru_24e_241_24ERecord, TAG_PassedRecord, 2, (V[]){v_t_2414, v_t_2418});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    return NTAG(TAG_PassedOther);
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    return NTAG(TAG_PassedOther);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_PassedOther);
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    return NTAG(TAG_PassedOther);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2escalars_2epassedOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2epassedOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2epassedOf_lam0(V self, V *args) {
  V v_i_2417 = args[0];
  V v_ts_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_i_2417; V a_1 = v_ts_2413; V r_ = (g_heff_2ecompile_2erepr_2etyIn(a_0, a_1)); heff_drop(v_ts_2413); r_; });
}
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str0, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str1, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str2, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str3, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str4, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str5, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str6, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str7, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str8, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str9, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str10, 1, "_");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str11, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str12, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str13, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str14, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str15, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str16, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str17, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str18, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str19, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str20, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str21, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str22, 1, "_");
HEFF_LIT(g_heff_2ecompile_2escalars_2emergeTy_str23, 1, "\?");
Clo g_heff_2ecompile_2escalars_2emergeTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2emergeTy_entry, 2, 0};

V g_heff_2ecompile_2escalars_2emergeTy(V v_a_240, V v_b_241) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_a_240)) {
  case TAG_FtFloat: {
    v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str0);
    break;
  }
  case TAG_FtFixed: {
    V v_w_242 = heff_dup(heff_field(v_a_240, 0));
    switch (heff_tag_of(v_w_242)) {
    case TAG_I8: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str1);
      break;
    }
    case TAG_I16: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str2);
      break;
    }
    case TAG_I32: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str3);
      break;
    }
    case TAG_I64: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str4);
      break;
    }
    case TAG_U8: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str5);
      break;
    }
    case TAG_U16: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str6);
      break;
    }
    case TAG_U32: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str7);
      break;
    }
    case TAG_U64: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str8);
      break;
    }
    case TAG_F32: {
      v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str9);
      break;
    }
    default: heff_nomatch(v_w_242);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str10);
    break;
  }
  case TAG_FtAny: {
    v_t_243 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str11);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  V v_t_245;
  switch (heff_tag_of(v_b_241)) {
  case TAG_FtFloat: {
    v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str12);
    break;
  }
  case TAG_FtFixed: {
    V v_w_244 = heff_field(v_b_241, 0);
    switch (heff_tag_of(v_w_244)) {
    case TAG_I8: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str13);
      break;
    }
    case TAG_I16: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str14);
      break;
    }
    case TAG_I32: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str15);
      break;
    }
    case TAG_I64: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str16);
      break;
    }
    case TAG_U8: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str17);
      break;
    }
    case TAG_U16: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str18);
      break;
    }
    case TAG_U32: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str19);
      break;
    }
    case TAG_U64: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str20);
      break;
    }
    case TAG_F32: {
      v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str21);
      break;
    }
    default: heff_nomatch(v_w_244);
    }
    break;
  }
  case TAG_FtOther: {
    v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str22);
    break;
  }
  case TAG_FtAny: {
    v_t_245 = ((V)&g_heff_2ecompile_2escalars_2emergeTy_str23);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  if (heff_strEq_c(v_t_243, v_t_245)) {
    return v_a_240;
  } else {
    heff_drop(v_a_240);
    return NTAG(TAG_FtOther);
  }
}
V g_heff_2ecompile_2escalars_2emergeTy_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2escalars_2emergeTy(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2escalars_2eslotWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eslotWith_entry, 6, 0};

V g_heff_2ecompile_2escalars_2eslotWith(V v_f_240, V v_b_241, V v_i_242, V v_p_243, V v_sames_244, V v_q_245) {
top: ;
  switch (heff_tag_of(v_q_245)) {
  case TAG_NoRecord: {
    heff_drop(v_b_241);
    heff_drop(v_i_242);
    heff_drop(v_p_243);
    heff_drop(v_sames_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Records: {
    V v_ls_246 = heff_field(v_q_245, 0);
    V v_ts_247 = heff_field(v_q_245, 1);
    V v_ru_24q_245_24Records = heff_take_reuse_n(v_q_245, 3ULL, 2);
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ls_246));
    if (heff_intLe_c(v_t_248, MK_INT(8LL))) {
      switch (heff_tag_of(v_ls_246)) {
      case TAG_Nil: {
        heff_drop(v_b_241);
        heff_drop(v_i_242);
        heff_drop(v_p_243);
        heff_drop(v_sames_244);
        heff_drop(v_ts_247);
        heff_drop_cell(v_ru_24q_245_24Records, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_t_2412 = heff_tag_at_n(v_ru_24q_245_24Records, TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
        V v_t_2413 = (g_heff_2ecompile_2escalars_2elamWholeW(v_p_243, v_ls_246, MK_INT(0LL), v_t_2412));
        if (heff_intEq_c(v_t_2413, MK_INT(0LL))) {
          V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
          V v_t_2416 = (g_heff_2ecompile_2escalars_2ewholeW(v_p_243, v_ls_246, MK_INT(0LL), v_t_2415));
          V v_t_2417 = (g_heff_2ecompile_2escalars_2eexitsWhole(v_f_240, v_p_243, v_ls_246, v_b_241));
          if (heff_intEq_c(v_t_2416, heff_intAdd(v_sames_244, v_t_2417))) {
            V v_t_2419 = heff_rec_n(5, shape_at__param__labels__tys__vars, (V[]){v_i_242, v_p_243, v_ls_246, v_ts_247, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2419});
          } else {
            heff_drop(v_i_242);
            heff_drop(v_p_243);
            heff_drop_tag(v_ls_246, 2);
            heff_drop(v_ts_247);
            return NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_b_241);
          heff_drop(v_i_242);
          heff_drop(v_p_243);
          heff_drop(v_sames_244);
          heff_drop_tag(v_ls_246, 2);
          heff_drop(v_ts_247);
          return NTAG(TAG_Nothing);
        }
      }
      default: return heff_nomatch(v_ls_246);
      }
    } else {
      heff_drop(v_b_241);
      heff_drop(v_i_242);
      heff_drop(v_p_243);
      heff_drop(v_sames_244);
      heff_drop(v_ls_246);
      heff_drop(v_ts_247);
      heff_drop_cell(v_ru_24q_245_24Records, 2);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_Mixed: {
    heff_drop(v_b_241);
    heff_drop(v_i_242);
    heff_drop(v_p_243);
    heff_drop(v_sames_244);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_q_245);
  }
}
V g_heff_2ecompile_2escalars_2eslotWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eslotWith(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2eslotFor_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2eslotFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eslotFor_entry, 5, 0};

V g_heff_2ecompile_2escalars_2eslotFor(V v_f_240, V v_b_241, V v_calls_242, V v_p_243, V v_i_244) {
top: ;
  V v_qs_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2eslotFor_lam0, 1, 2, (V[]){heff_dup(v_i_244), heff_dup(v_p_243)}), v_calls_242));
  V v_t_2415 = (g_list_2efoldl_24f915973885x1443507785(MK_INT(1LL), MK_INT(0LL), v_qs_2414));
  V v_t_2416 = (g_list_2efoldl_24s578974906x2018699728(NTAG(TAG_NoRecord), v_qs_2414));
  return (g_heff_2ecompile_2escalars_2eslotWith(v_f_240, v_b_241, v_i_244, v_p_243, v_t_2415, v_t_2416));
}
V g_heff_2ecompile_2escalars_2eslotFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eslotFor(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2escalars_2eslotFor_lam0(V self, V *args) {
  V v_as_245 = args[0];
  V v_i_244 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT3 v_t_246 = ({ V a_0 = v_i_244; V a_1 = v_as_245; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_as_245); r_; });
  V v_t_2413;
  {
    V v_field_248 = v_t_246.f[1];
    V v_field_249 = v_t_246.f[2];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2411 = v_field_248;
      V v_x12_2412 = v_field_249;
      heff_drop(v_x12_2412);
      v_t_2413 = v_x_2411;
    } else {
      heff_drop(v_field_248);
      heff_drop(v_field_249);
      v_t_2413 = NTAG(TAG_EAbandon);
    }
  }
  return ({ V a_0 = v_p_243; V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2escalars_2epassedOf(a_0, a_1)); heff_drop(v_p_243); r_; });
}
Clo g_heff_2ecompile_2escalars_2ejustsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ejustsOf_entry, 1, 0};

V g_heff_2ecompile_2escalars_2ejustsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ms_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_s_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2escalars_2ejustsOf_24dps(v_ms_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2escalars_2ejustsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ejustsOf(a[0]);
}
Clo g_heff_2ecompile_2escalars_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2escalars_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_ms_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_s_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_s_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_ms_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2escalars_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ejustsOf_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2escalars_2eslotsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eslotsIn_entry, 4, 0};

V g_heff_2ecompile_2escalars_2eslotsIn(V v_f_240, V v_xs_241, V v_b_242, V v_calls_243) {
top: ;
  switch (heff_tag_of(v_calls_243)) {
  case TAG_Nil: {
    heff_drop(v_xs_241);
    heff_drop(v_b_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_242), NTAG(TAG_Nil)});
    V v_x_247 = (g_heff_2ecompile_2escalars_2ecallsW(v_f_240, MK_INT(0LL), v_t_246));
    V v_y_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_calls_243));
    if (heff_intEq_c(v_x_247, v_y_248)) {
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_241));
      V v_t_2411 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2410, MK_INT(1LL))));
      V v_t_2412 = (g_list_2ezipWith_24s1259666496x1713656817(v_f_240, v_b_242, v_calls_243, v_xs_241, v_t_2411));
      return (g_heff_2ecompile_2escalars_2ejustsOf(v_t_2412));
    } else {
      heff_drop(v_xs_241);
      heff_drop(v_b_242);
      heff_drop_tag(v_calls_243, 2);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_calls_243);
  }
}
V g_heff_2ecompile_2escalars_2eslotsIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2escalars_2eslotsIn(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2escalars_2eslotsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eslotsOf_entry, 1, 0};

V g_heff_2ecompile_2escalars_2eslotsOf(V v_d_240) {
top: ;
  V v_t_241 = heff_take_field(v_d_240, 2);
  switch (heff_tag_of(v_t_241)) {
  case TAG_EVar: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_t_241, 0);
    V v_b_245 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2escalars_2eselfLast(heff_rfield(v_d_240, 0), NTAG(TAG_Nil), heff_dup(v_b_245)));
    return ({ V b_0 = heff_get_n(v_d_240, 0, 3); V a_1 = v_xs_244; V a_2 = v_b_245; V a_3 = v_t_246; V r_ = (g_heff_2ecompile_2escalars_2eslotsIn(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
  }
  case TAG_EApp: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_t_241, 0ULL, 4);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_d_240, 3);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2escalars_2eslotsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2eslotsOf(a[0]);
}

HeffT2 g_heff_2ecompile_2escalars_2elabelVar_24cpr(V v_l_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x3_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_k_243 = heff_field(v_x2_241, 0);
    V v_ks_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_k_243);
      heff_drop(v_ks_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_v_245 = heff_field(v_x3_242, 0);
      V v_vs_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_243, v_l_240, 1)) {
        heff_drop(v_ks_244);
        heff_drop(v_vs_246);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_v_245}});
      } else {
        heff_drop(v_v_245);
        V t_0 = v_l_240;
        V t_1 = v_ks_244;
        V t_2 = v_vs_246;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ecompile_2escalars_2efieldVarOf_24cpr(V v_ss_240, V v_e_241, V v_l_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_244 = ({ V a_0 = v_x_243; V a_1 = v_ss_240; HeffT2 r_ = (g_list_2efind_24s1119339522x336883298_24cpr(a_0, a_1)); heff_drop(v_x_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_s_248 = v_field_246;
        HEFF_LAST return g_heff_2ecompile_2escalars_2elabelVar_24cpr(v_l_242, heff_dup(heff_rfield(v_s_248, 2)), heff_get_n(v_s_248, 4, 5));
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_ss_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_241)}});
  }
}
V g_heff_2ecompile_2escalars_2espread_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2espread_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2espread_entry, 3, 0};

V g_heff_2ecompile_2escalars_2espread(V v_go_240, V v_s_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EGlobal: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ELam: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EApp: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ELet: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_e_242, 0);
    heff_drop_rec(v_s_241, 5);
    return (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2espread_lam0, 1, 1, (V[]){v_go_240}), heff_dup(v_fs_2412)));
  }
  case TAG_EProj: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ETag: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EMatch: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EPrim: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EPrimCall: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_ECall: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EInt: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFloat: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EStr: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EBytes: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFixed: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFloat32: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EAbandon: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  case TAG_EFix: {
    heff_drop(v_go_240);
    return (g_list_2emap_24s1809017761x1063871171(heff_get_n(v_s_241, 4, 5)));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2escalars_2espread_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2escalars_2espread(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2escalars_2espread_lam0(V self, V *args) {
  V v_p_2414 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_y_2416 = heff_field(v_p_2414, 1);
    heff_take_n(v_p_2414, 2ULL, 2);
    v_t_2417 = v_y_2416;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  V f_ = v_go_240;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2escalars_2eargsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eargsRw_entry, 4, 0};

V g_heff_2ecompile_2escalars_2eargsRw(V v_go_240, V v_ss_241, V v_i_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    heff_drop(v_ss_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_as_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    HeffT2 v_t_246 = (g_list_2efind_24s882806058x114262163_24cpr(heff_dup(v_i_242), heff_dup(v_ss_241)));
    V v_t_2412;
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x4_243_24Cons, 2);
        V v_s_2410 = v_field_248;
        v_t_2412 = ({ V a_0 = heff_dup(v_go_240); V a_1 = v_s_2410; V a_2 = v_a_244; V r_ = (g_heff_2ecompile_2escalars_2espread(a_0, a_1, a_2)); heff_drop(v_a_244); r_; });
      } else {
        heff_drop(v_field_248);
        V v_t_2411 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){v_a_244}));
        v_t_2412 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
      }
    }
    V v_t_2413 = (g_heff_2ecompile_2escalars_2eargsRw(v_go_240, v_ss_241, heff_intAdd(v_i_242, MK_INT(1LL)), v_as_245));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2412, v_t_2413));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2escalars_2eargsRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2eargsRw(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2escalars_2erw_str0, 8, "$scalars");
V g_heff_2ecompile_2escalars_2erw_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2erw_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2erw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2erw_entry, 2, 0};

V g_heff_2ecompile_2escalars_2erw(V v_lp_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EVar = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_list_2efind_24s1119339522x336883298_24cpr(v_x_242, heff_get_n(v_lp_240, 1, 2)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_x_242);
        heff_drop_cell(v_ru_24x2_241_24EVar, 1);
        V v_s_247 = v_field_245;
        V v_t_248 = (g_list_2ezipWith_24s1928181476x241816070(heff_take_field(v_s_247, 2), heff_take_field(v_s_247, 4)));
        return heff_tag_n(TAG_ERecord, 2, (V[]){v_t_248, heff_get_n(v_s_247, 3, 5)});
      } else {
        heff_drop(v_field_245);
        return heff_tag_at_n(v_ru_24x2_241_24EVar, TAG_EVar, 1, (V[]){v_x_242});
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_2410 = heff_field(v_x2_241, 0);
    V v_b_2411 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2410, heff_hole()});
    V v_u_2413 = (g_heff_2ecompile_2escalars_2erw_24dps(v_lp_240, v_b_2411, heff_dup(v_cell_2412), MK_INT(1LL)));
    heff_drop(v_u_2413);
    return v_cell_2412;
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_241, 0);
    V v_as_2415 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2escalars_2erw(heff_dup(v_lp_240), v_f_2414));
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2418 = (g_list_2emap(v_t_2417, v_as_2415));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2416, v_t_2418});
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_x2_241, 0);
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2422 = (g_heff_2ecompile_2escalars_2erw(heff_dup(v_lp_240), v_a_2420));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_t_2422, heff_hole()});
    V v_u_2424 = (g_heff_2ecompile_2escalars_2erw_24dps(v_lp_240, v_b_2421, heff_dup(v_cell_2423), MK_INT(2LL)));
    heff_drop(v_u_2424);
    return v_cell_2423;
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_x2_241, 0);
    V v_ts_2426 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2erw_lam0, 1, 1, (V[]){v_lp_240}), v_fs_2425));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2435, v_ts_2426});
  }
  case TAG_EProj: {
    V v_e_2436 = heff_field(v_x2_241, 0);
    V v_l_2437 = heff_field(v_x2_241, 1);
    V v_sh_2438 = heff_field(v_x2_241, 2);
    V v_t_2439 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_go_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    HeffT2 v_t_2441 = (g_heff_2ecompile_2escalars_2efieldVarOf_24cpr(heff_get_n(v_lp_240, 1, 2), heff_dup(v_e_2436), v_l_2437));
    {
      V v_field_2443 = v_t_2441.f[1];
      int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
      if ((v_tag_2442 == ((int64_t)0ULL))) {
        heff_drop(v_e_2436);
        heff_drop(v_l_2437);
        heff_drop(v_sh_2438);
        heff_drop(v_t_2439);
        heff_drop_cell(v_ru_24x2_241_24EProj, 4);
        heff_drop(v_go_2440);
        V v_v_2445 = v_field_2443;
        return heff_tag_n(TAG_EVar, 1, (V[]){v_v_2445});
      } else {
        heff_drop(v_field_2443);
        V v_t_2446 = heff_tr(heff_call(v_go_2440, 1, (V[]){v_e_2436}));
        return heff_tag_at_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, (V[]){v_t_2446, v_l_2437, v_sh_2438, v_t_2439});
      }
    }
  }
  case TAG_ETag: {
    V v_t_2447 = heff_field(v_x2_241, 0);
    V v_as_2448 = heff_field(v_x2_241, 1);
    V v_ts_2449 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2451 = (g_list_2emap(v_t_2450, v_as_2448));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_2447, v_t_2451, v_ts_2449});
  }
  case TAG_EMatch: {
    V v_s_2452 = heff_field(v_x2_241, 0);
    V v_arms_2453 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2454 = (g_heff_2ecompile_2escalars_2erw(heff_dup(v_lp_240), v_s_2452));
    V v_t_2469 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2erw_lam1, 1, 1, (V[]){v_lp_240}), v_arms_2453));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2454, v_t_2469});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2471 = heff_field(v_x2_241, 0);
    V v_as_2472 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2473 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2474 = (g_list_2emap(v_t_2473, v_as_2472));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2471, v_t_2474});
  }
  case TAG_ECall: {
    V v_g_2475 = heff_field(v_x2_241, 0);
    V v_as_2476 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2475), heff_dup(heff_rfield(v_lp_240, 0)))) {
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_2479 = (g_heff_2ecompile_2escalars_2eargsRw(v_t_2478, heff_get_n(v_lp_240, 1, 2), MK_INT(0LL), v_as_2476));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_2475, ((V)&g_heff_2ecompile_2escalars_2erw_str0)), v_t_2479});
    } else {
      V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_2481 = (g_list_2emap(v_t_2480, v_as_2476));
      return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_2475, v_t_2481});
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  case TAG_EFix: {
    heff_drop_rec(v_lp_240, 2);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2escalars_2erw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2erw(a[0], a[1]);
}
V g_heff_2ecompile_2escalars_2erw_lam0(V self, V *args) {
  V v_p_2427 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_x_2428 = heff_dup(heff_field(v_p_2427, 0));
    v_t_2430 = v_x_2428;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  V v_t_2433;
  switch (heff_tag_of(v_p_2427)) {
  case TAG_MkPair: {
    V v_y_2432 = heff_field(v_p_2427, 1);
    heff_take_n(v_p_2427, 2ULL, 2);
    v_t_2433 = v_y_2432;
    break;
  }
  default: heff_nomatch(v_p_2427);
  }
  V v_t_2434 = (g_heff_2ecompile_2escalars_2erw(v_lp_240, v_t_2433));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_t_2434});
}
V g_heff_2ecompile_2escalars_2erw_lam1(V self, V *args) {
  V v_a_2455 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2459;
  switch (heff_tag_of(v_a_2455)) {
  case TAG_MkArm: {
    V v_t_2456 = heff_dup(heff_field(v_a_2455, 0));
    v_t_2459 = v_t_2456;
    break;
  }
  default: heff_nomatch(v_a_2455);
  }
  V v_t_2463;
  switch (heff_tag_of(v_a_2455)) {
  case TAG_MkArm: {
    V v_vs_2461 = heff_dup(heff_field(v_a_2455, 1));
    v_t_2463 = v_vs_2461;
    break;
  }
  default: heff_nomatch(v_a_2455);
  }
  V v_t_2467;
  switch (heff_tag_of(v_a_2455)) {
  case TAG_MkArm: {
    V v_b_2466 = heff_field(v_a_2455, 2);
    heff_take_n(v_a_2455, 4ULL, 3);
    v_t_2467 = v_b_2466;
    break;
  }
  default: heff_nomatch(v_a_2455);
  }
  V v_t_2468 = (g_heff_2ecompile_2escalars_2erw(v_lp_240, v_t_2467));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2459, v_t_2463, v_t_2468});
}
HEFF_LIT(g_heff_2ecompile_2escalars_2erw_24dps_str0, 8, "$scalars");
V g_heff_2ecompile_2escalars_2erw_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2escalars_2erw_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2escalars_2erw_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2erw_24dps_entry, 4, 0};

V g_heff_2ecompile_2escalars_2erw_24dps(V v_lp_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_245 = (g_list_2efind_24s1119339522x336883298_24cpr(v_x_244, heff_get_n(v_lp_240, 1, 2)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_244);
        V v_s_249 = v_field_247;
        V v_t_2410 = (g_list_2ezipWith_24s1928181476x241816070(heff_take_field(v_s_249, 2), heff_take_field(v_s_249, 4)));
        V v_t_2411 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2410, heff_get_n(v_s_249, 3, 5)});
        return heff_setField(v_d_242, v_i_243, v_t_2411);
      } else {
        heff_drop(v_field_247);
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_x_244}));
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_ELam: {
    V v_xs_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){v_xs_2413, heff_hole()});
    V v_u_2416 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2415));
    heff_drop(v_u_2416);
    V t_0 = v_lp_240;
    V t_1 = v_b_2414;
    V t_2 = v_cell_2415;
    V t_3 = MK_INT(1LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2417 = heff_field(v_x2_241, 0);
    V v_as_2418 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2419 = (g_heff_2ecompile_2escalars_2erw(heff_dup(v_lp_240), v_f_2417));
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2421 = (g_list_2emap(v_t_2420, v_as_2418));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2419, v_t_2421}));
  }
  case TAG_ELet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_a_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2425 = (g_heff_2ecompile_2escalars_2erw(heff_dup(v_lp_240), v_a_2423));
    V v_cell_2426 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){v_x_2422, v_t_2425, heff_hole()});
    V v_u_2427 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2426));
    heff_drop(v_u_2427);
    V t_0 = v_lp_240;
    V t_1 = v_b_2424;
    V t_2 = v_cell_2426;
    V t_3 = MK_INT(2LL);
    v_lp_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2erw_24dps_lam0, 1, 1, (V[]){v_lp_240}), v_fs_2428));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2438, v_ts_2429}));
  }
  case TAG_EProj: {
    V v_e_2439 = heff_field(v_x2_241, 0);
    V v_l_2440 = heff_field(v_x2_241, 1);
    V v_sh_2441 = heff_field(v_x2_241, 2);
    V v_t_2442 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_go_2443 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
    HeffT2 v_t_2444 = (g_heff_2ecompile_2escalars_2efieldVarOf_24cpr(heff_get_n(v_lp_240, 1, 2), heff_dup(v_e_2439), v_l_2440));
    {
      V v_field_2446 = v_t_2444.f[1];
      int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
      if ((v_tag_2445 == ((int64_t)0ULL))) {
        heff_drop(v_e_2439);
        heff_drop(v_l_2440);
        heff_drop(v_sh_2441);
        heff_drop(v_t_2442);
        heff_drop(v_go_2443);
        V v_v_2448 = v_field_2446;
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EVar, 1, (V[]){v_v_2448}));
      } else {
        heff_drop(v_field_2446);
        V v_t_2449 = heff_tr(heff_call(v_go_2443, 1, (V[]){v_e_2439}));
        return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2449, v_l_2440, v_sh_2441, v_t_2442}));
      }
    }
  }
  case TAG_ETag: {
    V v_t_2450 = heff_field(v_x2_241, 0);
    V v_as_2451 = heff_field(v_x2_241, 1);
    V v_ts_2452 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2453 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2454 = (g_list_2emap(v_t_2453, v_as_2451));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2450, v_t_2454, v_ts_2452}));
  }
  case TAG_EMatch: {
    V v_s_2455 = heff_field(v_x2_241, 0);
    V v_arms_2456 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2457 = (g_heff_2ecompile_2escalars_2erw(heff_dup(v_lp_240), v_s_2455));
    V v_t_2472 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2escalars_2erw_24dps_lam1, 1, 1, (V[]){v_lp_240}), v_arms_2456));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2457, v_t_2472}));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EPrimCall: {
    V v_p_2474 = heff_field(v_x2_241, 0);
    V v_as_2475 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
    V v_t_2477 = (g_list_2emap(v_t_2476, v_as_2475));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2474, v_t_2477}));
  }
  case TAG_ECall: {
    V v_g_2478 = heff_field(v_x2_241, 0);
    V v_as_2479 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_g_2478), heff_dup(heff_rfield(v_lp_240, 0)))) {
      V v_t_2481 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){heff_dup(v_lp_240)}));
      V v_t_2482 = (g_heff_2ecompile_2escalars_2eargsRw(v_t_2481, heff_get_n(v_lp_240, 1, 2), MK_INT(0LL), v_as_2479));
      V v_t_2483 = heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){heff_strAppend(v_g_2478, ((V)&g_heff_2ecompile_2escalars_2erw_24dps_str0)), v_t_2482});
      return heff_setField(v_d_242, v_i_243, v_t_2483);
    } else {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      V v_t_2484 = heff_tr(heff_call(((V)&g_heff_2ecompile_2escalars_2erw_clo), 1, (V[]){v_lp_240}));
      V v_t_2485 = (g_list_2emap(v_t_2484, v_as_2479));
      return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2478, v_t_2485}));
    }
  }
  case TAG_EInt: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EStr: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBytes: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFix: {
    heff_drop_rec(v_lp_240, 2);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2escalars_2erw_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2erw_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2escalars_2erw_24dps_lam0(V self, V *args) {
  V v_p_2430 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_dup(heff_field(v_p_2430, 0));
    v_t_2433 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  V v_t_2436;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_field(v_p_2430, 1);
    heff_take_n(v_p_2430, 2ULL, 2);
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  V v_t_2437 = (g_heff_2ecompile_2escalars_2erw(v_lp_240, v_t_2436));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_t_2437});
}
V g_heff_2ecompile_2escalars_2erw_24dps_lam1(V self, V *args) {
  V v_a_2458 = args[0];
  V v_lp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2462;
  switch (heff_tag_of(v_a_2458)) {
  case TAG_MkArm: {
    V v_t_2459 = heff_dup(heff_field(v_a_2458, 0));
    v_t_2462 = v_t_2459;
    break;
  }
  default: heff_nomatch(v_a_2458);
  }
  V v_t_2466;
  switch (heff_tag_of(v_a_2458)) {
  case TAG_MkArm: {
    V v_vs_2464 = heff_dup(heff_field(v_a_2458, 1));
    v_t_2466 = v_vs_2464;
    break;
  }
  default: heff_nomatch(v_a_2458);
  }
  V v_t_2470;
  switch (heff_tag_of(v_a_2458)) {
  case TAG_MkArm: {
    V v_b_2469 = heff_field(v_a_2458, 2);
    heff_take_n(v_a_2458, 4ULL, 3);
    v_t_2470 = v_b_2469;
    break;
  }
  default: heff_nomatch(v_a_2458);
  }
  V v_t_2471 = (g_heff_2ecompile_2escalars_2erw(v_lp_240, v_t_2470));
  return heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2462, v_t_2466, v_t_2471});
}
Clo g_heff_2ecompile_2escalars_2eparamsRw_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2eparamsRw_entry, 3, 0};

V g_heff_2ecompile_2escalars_2eparamsRw(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ss_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_list_2efind_24s882806058x114262163_24cpr(heff_dup(v_i_241), heff_dup(v_ss_240)));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_s_249 = v_field_247;
        v_t_2410 = heff_get_n(v_s_249, 4, 5);
      } else {
        heff_drop(v_field_247);
        v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      }
    }
    V v_t_2411 = (g_heff_2ecompile_2escalars_2eparamsRw(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_2410, v_t_2411));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2eparamsRw_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2eparamsRw(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2escalars_2ewrapArg_lam0(V self, V *args);
Clo g_heff_2ecompile_2escalars_2ewrapArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ewrapArg_entry, 2, 0};

V g_heff_2ecompile_2escalars_2ewrapArg(V v_y_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_240}), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_s_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_243 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_s_242, 2)));
    V v_t_244 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_243, MK_INT(1LL))));
    return (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2escalars_2ewrapArg_lam0, 2, 2, (V[]){heff_dup(v_s_242), v_y_240}), heff_get_n(v_s_242, 2, 5), v_t_244));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2escalars_2ewrapArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2escalars_2ewrapArg(a[0], a[1]);
}
V g_heff_2ecompile_2escalars_2ewrapArg_lam0(V self, V *args) {
  V v_l_245 = args[0];
  V v_i_246 = args[1];
  V v_s_242 = heff_env(self)[0];
  V v_y_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_heff_2ecompile_2erepr_2etyIn(v_i_246, heff_rfield(v_s_242, 3)));
  return heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_240}), v_l_245, heff_get_n(v_s_242, 2, 5), v_t_247});
}
Clo g_heff_2ecompile_2escalars_2ewrapArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2escalars_2ewrapArgs_entry, 3, 0};

V g_heff_2ecompile_2escalars_2ewrapArgs(V v_ss_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ss_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_ys_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_list_2efind_24s882806058x114262163(heff_dup(v_i_241), heff_dup(v_ss_240)));
    V v_t_246 = (g_heff_2ecompile_2escalars_2ewrapArg(heff_dup(v_y_243), v_t_245));
    V v_t_247 = (g_heff_2ecompile_2escalars_2ewrapArgs(v_ss_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_ys_244));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2escalars_2ewrapArgs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2escalars_2ewrapArgs(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_24cpr_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_24cpr_str1, 8, "$scalars");
HEFF_LIT(g_heff_2ecompile_2escalars_2eloopDefs_24cpr_str2, 8, "$scalars");

HeffT2 g_heff_2ecompile_2escalars_2eloopDefs_24cpr(V v_d_240, V v_xs_241, V v_b_242, V v_ss0_243, V v_n_244) {
top: ;
  HeffT2 v_t_245 = (g_prelude_2etraverse_24s1266173017x1167058160_24cpr(v_ss0_243, v_n_244));
  {
    V v_field_246 = v_t_245.f[0];
    V v_field_247 = v_t_245.f[1];
    V v_x_248 = v_field_246;
    V v_n_249 = v_field_247;
    V v_m_2410 = (g_prelude_2etraverse_24s183237039x2129949159(MK_INT(0LL), ((V)&g_heff_2ecompile_2escalars_2eloopDefs_24cpr_str0), MK_INT(1LL), heff_dup(v_xs_241)));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2escalars_2eparamsRw(heff_dup(v_x_248), MK_INT(0LL), v_xs_241));
      V v_t_2415 = heff_rec_n(2, shape_key__slots, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(v_x_248)});
      V v_t_2416 = (g_heff_2ecompile_2escalars_2erw(v_t_2415, v_b_242));
      V v_body_2417 = heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_ELam, 2, (V[]){v_t_2414, v_t_2416});
      V v_t_2418 = heff_strAppend(heff_dup(heff_rfield(v_d_240, 0)), ((V)&g_heff_2ecompile_2escalars_2eloopDefs_24cpr_str1));
      V v_t_2419 = heff_rec_n(3, shape_key__name__body, (V[]){v_t_2418, heff_dup(heff_rfield(v_d_240, 1)), v_body_2417});
      V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_d_240, 0)), ((V)&g_heff_2ecompile_2escalars_2eloopDefs_24cpr_str2));
      V v_t_2421 = (g_heff_2ecompile_2escalars_2ewrapArgs(v_x_248, MK_INT(0LL), v_x_2412));
      V v_body_2422 = heff_tag_n(TAG_ELam, 2, (V[]){v_x_2412, heff_tag_n(TAG_ECall, 2, (V[]){v_t_2420, v_t_2421})});
      V v_t_2423 = ({ V rv_2 = v_body_2422; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
      V v_x_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2424});
      return ((HeffT2){{v_x_2425, v_n_2413}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2411)}});
    }
  }
}

HeffT2 g_heff_2ecompile_2escalars_2edefWith_24cpr(V v_d_240, V v_ss_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_ss_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
    return ((HeffT2){{v_t_243, v_p_242}});
  }
  case TAG_Cons: {
    V v_t_246 = heff_dup(heff_rfield(v_d_240, 2));
    switch (heff_tag_of(v_t_246)) {
    case TAG_EVar: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_248, v_p_242}});
    }
    case TAG_EGlobal: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2410, v_p_242}});
    }
    case TAG_ELam: {
      V v_xs_2411 = heff_field(v_t_246, 0);
      V v_b_2412 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      return (g_heff_2ecompile_2escalars_2eloopDefs_24cpr(v_d_240, v_xs_2411, v_b_2412, v_ss_241, v_p_242));
    }
    case TAG_EApp: {
      V v_ru_24t_246_24EApp = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2415 = heff_tag_at_n(v_ru_24t_246_24EApp, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2415, v_p_242}});
    }
    case TAG_ELet: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2419, v_p_242}});
    }
    case TAG_ERecord: {
      V v_ru_24t_246_24ERecord = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2422 = heff_tag_at_n(v_ru_24t_246_24ERecord, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2422, v_p_242}});
    }
    case TAG_EProj: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2427, v_p_242}});
    }
    case TAG_ETag: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2431, v_p_242}});
    }
    case TAG_EMatch: {
      V v_ru_24t_246_24EMatch = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2434 = heff_tag_at_n(v_ru_24t_246_24EMatch, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2434, v_p_242}});
    }
    case TAG_EPrim: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2436, v_p_242}});
    }
    case TAG_EPrimCall: {
      V v_ru_24t_246_24EPrimCall = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2439 = heff_tag_at_n(v_ru_24t_246_24EPrimCall, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2439, v_p_242}});
    }
    case TAG_ECall: {
      V v_ru_24t_246_24ECall = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2442 = heff_tag_at_n(v_ru_24t_246_24ECall, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2442, v_p_242}});
    }
    case TAG_EInt: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2444, v_p_242}});
    }
    case TAG_EFloat: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2446, v_p_242}});
    }
    case TAG_EStr: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2448, v_p_242}});
    }
    case TAG_EBytes: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2450, v_p_242}});
    }
    case TAG_EFixed: {
      V v_ru_24t_246_24EFixed = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2453 = heff_tag_at_n(v_ru_24t_246_24EFixed, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2453, v_p_242}});
    }
    case TAG_EFloat32: {
      heff_take_na(v_t_246, 0ULL, 1);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2455, v_p_242}});
    }
    case TAG_EAbandon: {
      heff_drop_tag(v_ss_241, 2);
      V v_t_2456 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2456, v_p_242}});
    }
    case TAG_EFix: {
      V v_ru_24t_246_24EFix = heff_take_reuse_n(v_t_246, 0ULL, 2);
      heff_drop_tag(v_ss_241, 2);
      V v_t_2459 = heff_tag_at_n(v_ru_24t_246_24EFix, TAG_Cons, 2, (V[]){v_d_240, NTAG(TAG_Nil)});
      return ((HeffT2){{v_t_2459, v_p_242}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_ss_241)}});
  }
}