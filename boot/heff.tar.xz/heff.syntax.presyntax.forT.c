// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EInvalid 31081
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_EProject 35489
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EndJump 17665
#define TAG_MkAlt 55173
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_head 9693863
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_stmts 311127493
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_names__muts__loop__sp__depth__giving[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241(V);
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eit_241_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246(V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_clo;
V g_heff_2esyntax_2epresyntax_2egivingLoop(V, V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2egivingLoop_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2egivingLoop_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2elocalFun(V, V, V, V);
V g_heff_2esyntax_2epresyntax_2elocalFun_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elocalFun_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_list_2eany_24s1414887908x732433189(V);
V g_list_2eany_24s1414887908x732433189_entry(V self, V *a);
extern Clo g_list_2eany_24s1414887908x732433189_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str0, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str1, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str2, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2eit_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eit_241(V v_sp_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str0)}), heff_dup(v_sp_240)});
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str1), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str2), v_t_242));
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), v_sp_240});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_241, v_t_245));
}
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2eit_241(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str0, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str2, 4, "rest");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(V v_sp_240, V v_cx_241) {
top: ;
  V v_muts_242 = heff_take_field(v_cx_241, 1);
  V v_depth_243 = heff_get_n(v_cx_241, 4, 6);
  V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str1), v_t_244));
  V v_t_246 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), heff_dup(v_sp_240)});
  V v_t_247 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str3), v_t_247));
  V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_248}), v_sp_240});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
  V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_246, v_t_2410));
  return heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_2411, v_muts_242, NTAG(TAG_False), v_depth_243});
}
V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str0, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str2, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str3, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str5, 5, "start");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str6, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str7, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(V v_sp_240, V v_cx_241) {
top: ;
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str1), v_t_242));
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str2)}), heff_dup(v_sp_240)});
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str4), v_t_246));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_245, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str5)}), heff_dup(v_sp_240)});
  V v_t_2412 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str6), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str7), v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2415})));
  V v_t_2417 = (g_list_2emap_24s620499005x2067584111(v_sp_240, heff_get_n(v_cx_241, 1, 6)));
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(v_t_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2417}));
}
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str0, 6, "cursor");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str2, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str3, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str4, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str5, 6, "Cursor");
Clo g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(V v_sp_240, V v_cx_241) {
top: ;
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str1), v_t_242));
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
  V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str2)}), heff_dup(v_sp_240)});
  V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_247 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str3), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str4), v_t_246));
  V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_247}), heff_dup(v_sp_240)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
  V v_t_2410 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_245, v_t_249));
  V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str5)}), heff_dup(v_sp_240)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2410, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_sp_240; V b_1 = NTAG(TAG_False); V a_2 = heff_get_n(v_cx_241, 1, 6); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_t_2413}), v_t_2414});
}
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str0, 4, "next");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str2, 6, "cursor");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str4, 7, "Nothing");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str5, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str6, 7, "Nothing");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str7, 4, "rest");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str8, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str9, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str10, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str11, 4, "Just");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str12, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str13, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str15, 4, "Just");
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246(V v_sp_240, V v_p_241, V v_cx_242, V v_t_243, V v_body_244, V v_endJ_245, V v_inner_246) {
top: ;
  V v_names_247 = heff_take_field(v_inner_246, 0);
  V v_muts_248 = heff_take_field(v_inner_246, 1);
  V v_sp_249 = heff_take_field(v_inner_246, 3);
  V v_depth_2410 = heff_take_field(v_inner_246, 4);
  V v_giving_2411 = heff_get_n(v_inner_246, 5, 6);
  V v_t_2412 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str1), v_t_2412));
  V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2413}), heff_dup(v_sp_240)});
  V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str3), v_t_2415));
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2416}), heff_dup(v_sp_240)});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
  V v_s_2419 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2414, v_t_2418));
  V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str4)}), heff_dup(v_sp_240)});
  V v_x1_2421 = ({ V a_0 = v_t_2420; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2424;
  switch (heff_tag_of(v_x1_2421)) {
  case TAG_At: {
    V v_s_2423 = heff_field(v_x1_2421, 1);
    heff_take_n(v_x1_2421, 2ULL, 2);
    v_t_2424 = v_s_2423;
    break;
  }
  default: heff_nomatch(v_x1_2421);
  }
  V v_t_2425 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2424, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_vars_2426 = heff_dup(heff_rfield(v_endJ_245, 1));
  V v_t_2427 = heff_dup(heff_rfield(v_endJ_245, 2));
  V v_t_2431;
  if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
    heff_drop(v_t_2427);
    switch (heff_tag_of(v_vars_2426)) {
    case TAG_Nil: {
      V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str5)}), heff_dup(v_sp_240)});
      v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2431 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_240), v_vars_2426));
      break;
    }
    default: heff_nomatch(v_vars_2426);
    }
  } else {
    heff_drop(v_t_2427);
    v_t_2431 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_240), v_vars_2426));
  }
  V v_e_2432 = (g_heff_2esyntax_2epresyntax_2eapp(heff_dup(heff_rfield(v_endJ_245, 0)), v_t_2431));
  V v_t_2433 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str6), heff_dup(v_sp_240), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_t_2425)}), heff_dup(v_e_2432)});
  V v_t_2437;
  switch (heff_tag_of(v_e_2432)) {
  case TAG_At: {
    V v_s_2436 = heff_field(v_e_2432, 1);
    heff_take_n(v_e_2432, 2ULL, 2);
    v_t_2437 = v_s_2436;
    break;
  }
  default: heff_nomatch(v_e_2432);
  }
  V v_t_2438 = ({ V rv_1 = heff_get_n(v_t_2437, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2425, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2439 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2440 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str7), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str8), v_t_2439));
  V v_t_2441 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_t_2440}), heff_dup(v_sp_240)});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2441, NTAG(TAG_Nil)});
  V v_ps_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_241), v_t_2442});
  V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str9)}), heff_dup(v_sp_240)});
  V v_x1_2445 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2444, v_ps_2443));
  V v_t_2448;
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_At: {
    V v_s_2447 = heff_field(v_x1_2445, 1);
    heff_take_n(v_x1_2445, 2ULL, 2);
    v_t_2448 = v_s_2447;
    break;
  }
  default: heff_nomatch(v_x1_2445);
  }
  V v_t_2449 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2448, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str10), heff_dup(v_sp_240), v_ps_2443}), v_t_2449});
  V v_ps_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
  V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str11)}), heff_dup(v_sp_240)});
  V v_x1_2453 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2452, v_ps_2451));
  V v_t_2456;
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_At: {
    V v_s_2455 = heff_field(v_x1_2453, 1);
    heff_take_n(v_x1_2453, 2ULL, 2);
    v_t_2456 = v_s_2455;
    break;
  }
  default: heff_nomatch(v_x1_2453);
  }
  V v_t_2457 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2456, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_xs_2458 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_241)));
  HeffT2 v_t_2460 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_lam0, 1, 1, (V[]){heff_dup(v_cx_242)}), v_xs_2458));
  V v_e_2472;
  {
    V v_field_2462 = v_t_2460.f[1];
    int64_t v_tag_2461 = ((int64_t)v_t_2460.f[0]);
    if ((v_tag_2461 == ((int64_t)0ULL))) {
      heff_drop_rec(v_cx_242, 6);
      heff_drop_rec(v_t_243, 1);
      heff_drop(v_body_244);
      heff_drop_rec(v_endJ_245, 4);
      heff_drop(v_names_247);
      heff_drop(v_muts_248);
      heff_drop(v_sp_249);
      heff_drop(v_depth_2410);
      heff_drop(v_giving_2411);
      V v_x_2463 = v_field_2462;
      V v_t_2464 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str12), heff_strAppend(heff_dup(v_x_2463), ((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str13)));
      V v_t_2465 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str14), heff_strAppend(v_x_2463, v_t_2464));
      V v_t_2468;
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_s_2467 = heff_field(v_p_241, 1);
        heff_take_n(v_p_241, 2ULL, 2);
        v_t_2468 = v_s_2467;
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      v_e_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2465}), v_t_2468});
    } else {
      heff_drop(v_p_241);
      heff_drop(v_field_2462);
      V v_cont_2469 = (g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(heff_dup(v_sp_240), heff_dup(v_cx_242)));
      V v_t_2470 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_cont_2469, v_endJ_245})});
      V v_t_2471 = (g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(heff_dup(v_sp_240), v_cx_242));
      v_e_2472 = heff_tr(heff_call(heff_get_n(v_t_243, 0, 1), 3, (V[]){heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){v_names_247, v_muts_248, v_t_2470, v_sp_249, v_depth_2410, v_giving_2411}), v_body_244, heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2471})}));
    }
  }
  V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_str15), heff_dup(v_sp_240), v_ps_2451}), heff_dup(v_t_2457)});
  V v_t_2476;
  switch (heff_tag_of(v_e_2472)) {
  case TAG_At: {
    V v_s_2475 = heff_dup(heff_field(v_e_2472, 1));
    v_t_2476 = v_s_2475;
    break;
  }
  default: heff_nomatch(v_e_2472);
  }
  V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2476, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2457, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2473, v_e_2472}), v_t_2477});
  V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, NTAG(TAG_Nil)});
  V v_alts_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_t_2438}), v_t_2479});
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2419, v_alts_2480}), v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2eturn_246(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_lam0(V self, V *args) {
  V v_x_2459 = args[0];
  V v_cx_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2459; V b_1 = heff_get_n(v_cx_242, 1, 6); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(v_x_2459); heff_drop(b_1); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str0, 5, "after");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str2, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str3, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str4, 5, "after");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str5, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247(V v_sp_240, V v_cx_241, V v_t_242, V v_rest_243, V v_end_244, V v_p_245, V v_body_246) {
top: ;
  V v_t_247 = (g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(heff_dup(v_sp_240), heff_dup(v_cx_241)));
  V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str1), v_t_248));
  V v_t_2410 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = NTAG(TAG_True); V a_2 = heff_dup(heff_rfield(v_cx_241, 1)); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_t_242, 0)), 3, (V[]){heff_dup(v_cx_241), v_rest_243, v_end_244}));
  V v_t_2412 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_249, heff_dup(v_sp_240), v_t_2410, v_t_2411));
  V v_t_2413 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str3), v_t_2413));
  V v_t_2415 = (g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(heff_dup(v_sp_240), heff_dup(v_cx_241)));
  V v_t_2416 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str4), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_str5), v_t_2416));
  V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_2417}), heff_dup(v_sp_240)});
  V v_t_2419 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_2418, heff_dup(heff_rfield(v_cx_241, 1)), NTAG(TAG_True), heff_dup(heff_rfield(v_cx_241, 4))});
  V v_t_2420 = (g_heff_2esyntax_2epresyntax_2eforT_2eturn_246(heff_dup(v_sp_240), v_p_245, heff_dup(v_cx_241), v_t_242, v_body_246, v_t_2419, v_cx_241));
  V v_t_2421 = (g_heff_2esyntax_2epresyntax_2elocalFun(v_t_2414, heff_dup(v_sp_240), v_t_2415, v_t_2420));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
  V v_t_2423 = heff_tag_n(TAG_ELocal, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2422})});
  return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2ejoined_247(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_entry, 7, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249(V v_t_240, V v_cx_241, V v_sp_242, V v_body_243, V v_p_244, V v_rest_245, V v_end_246) {
top: ;
  V v_t_247 = (g_list_2eany_24s1414887908x732433189(v_body_243));
  V v_t_248 = (g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(heff_dup(v_sp_242), heff_dup(v_cx_241)));
  V v_t_249 = (g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(heff_dup(v_sp_242), heff_dup(v_cx_241)));
  return ({ V a_0 = heff_dup(v_t_240); V a_1 = heff_dup(v_cx_241); V a_2 = heff_dup(v_sp_242); V a_3 = v_t_247; V a_4 = v_t_248; V a_5 = v_t_249; V a_6 = heff_clo_n(g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_lam0, 1, 5, (V[]){v_body_243, v_cx_241, v_sp_242, v_p_244, v_t_240}); V a_7 = v_rest_245; V a_8 = v_end_246; V r_ = (g_heff_2esyntax_2epresyntax_2egivingLoop(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_247); r_; });
}
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2egiven_249(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2esyntax_2epresyntax_2eforT_2egiven_249_lam0(V self, V *args) {
  V v_exitJ_2410 = args[0];
  V v_body_243 = heff_env(self)[0];
  V v_cx_241 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_t_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_ret_2411 = (g_list_2eany_24s1414887908x732433189(v_body_243));
  V v_t_2412 = heff_rec_n(6, shape_names__muts__loop__sp__depth__giving, (V[]){heff_dup(heff_rfield(v_cx_241, 0)), heff_dup(heff_rfield(v_cx_241, 1)), heff_dup(heff_rfield(v_cx_241, 2)), heff_dup(heff_rfield(v_cx_241, 3)), heff_dup(heff_rfield(v_cx_241, 4)), heff_tag_n(TAG_Just, 1, (V[]){v_ret_2411})});
  return (g_heff_2esyntax_2epresyntax_2eforT_2eturn_246(v_sp_242, v_p_244, v_cx_241, v_t_240, v_body_243, v_exitJ_2410, v_t_2412));
}