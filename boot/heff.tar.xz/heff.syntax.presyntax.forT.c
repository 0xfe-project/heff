// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EInvalid 31081
#define TAG_EMatch 41631
#define TAG_EProject 35489
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_EndJump 17665
#define TAG_MkAlt 55173
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define LBL_bound 295286168
#define LBL_depth 296830685
#define LBL_end 310101
#define LBL_giving 701566649
#define LBL_head 9693863
#define LBL_loop 9823083
#define LBL_muts 9858798
#define LBL_names 305943394
#define LBL_sp 10436
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit__depth[] = {LBL_head, LBL_vars, LBL_unit, LBL_depth};
static uint32_t shape_names__muts__loop__sp__depth__giving__bound[] = {LBL_names, LBL_muts, LBL_loop, LBL_sp, LBL_depth, LBL_giving, LBL_bound};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(V, V, V, V, V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2epatNames(V);
V g_heff_2esyntax_2epresyntax_2epatNames_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_clo;
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2(V, V);
V g_heff_2esyntax_2epresyntax_2epatNames_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatNames_24tok2_clo;
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(V, V, V);
V g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488_clo;
V g_heff_2esyntax_2epresyntax_2evarParams(V, V, V);
V g_heff_2esyntax_2epresyntax_2evarParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2evarParams_clo;
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str0, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str1, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str2, 5, "start");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str3, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str4, 5, "loop#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(V v_sp_240, V v_cx_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str0)}), heff_dup(v_sp_240)});
  V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_244 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str1), v_t_243)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_246 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_242, v_t_245));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str2)}), heff_dup(v_sp_240)});
  V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str3), v_t_248)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_2411 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410})));
  V v_t_2412 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_240), heff_get_n(v_cx_241, 1, 7)));
  V v_t_2413 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2414 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_str4), v_t_2413)});
  HEFF_LAST return g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_240}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2412}));
}
V g_heff_2esyntax_2epresyntax_2eforT_2efirst_244_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2efirst_244(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str0, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str1, 5, "coll#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str2, 6, "Cursor");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str3, 7, "cursor#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(V v_sp_240, V v_cx_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str0)}), heff_dup(v_sp_240)});
  V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_244 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str1), v_t_243)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_244, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_t_246 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_242, v_t_245));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EProject, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str2)}), heff_dup(v_sp_240)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_246, v_t_248));
  V v_t_2410 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = NTAG(TAG_False); V a_2 = heff_get_n(v_cx_241, 1, 7); V r_ = (g_heff_2esyntax_2epresyntax_2evarParams(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  V v_t_2411 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2412 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_str3), v_t_2411)});
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2412, v_sp_240}), v_t_249});
  return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2410});
}
V g_heff_2esyntax_2epresyntax_2eforT_2eparams_245_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2eparams_245(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str0, 5, "next#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str1, 7, "cursor#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str2, 6, "MkUnit");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str3, 5, "rest#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str4, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str5, 6, "MkPair");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str6, 4, "Just");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str7, 1, "`");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str8, 87, "` is a `let mut` variable here: name what is bound another name (or set the variable, `");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str9, 7, " := e`)");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str10, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str11, 5, "rest#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str12, 5, "loop#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str13, 5, "rest#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str14, 7, "Nothing");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str15, 4, "Just");
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_lam0(V self, V *args);
Clo g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_entry, 6, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(V v_sp_240, V v_p_241, V v_cx_242, V v_body_243, V v_endJ_244, V v_inner_245) {
top: ;
  V v_muts_246 = heff_take_field(v_cx_242, 1);
  V v_depth_247 = heff_get_n(v_cx_242, 4, 7);
  V v_t_248 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str0), v_t_248)});
  V v_t_2410 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2411 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str1), v_t_2410)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2411, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_s_2413 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_240)}), v_t_2412));
  V v_t_2414 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_240, 0)), heff_dup(heff_rfield(v_sp_240, 1))});
  V v_vars_2415 = heff_dup(heff_rfield(v_endJ_244, 1));
  V v_t_2416 = heff_dup(heff_rfield(v_endJ_244, 2));
  V v_t_2420;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    switch (heff_tag_of(v_vars_2415)) {
    case TAG_Nil: {
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str2)}), heff_dup(v_sp_240)});
      v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      break;
    }
    case TAG_Cons: {
      v_t_2420 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_240), v_vars_2415));
      break;
    }
    default: heff_nomatch(v_vars_2415);
    }
  } else {
    heff_drop(v_t_2416);
    v_t_2420 = (g_list_2emap_24s620499005x2067584111(heff_dup(v_sp_240), v_vars_2415));
  }
  V v_e_2421 = (g_heff_2esyntax_2epresyntax_2eapp(heff_dup(heff_rfield(v_endJ_244, 0)), v_t_2420));
  V v_t_2424;
  switch (heff_tag_of(v_e_2421)) {
  case TAG_At: {
    V v_s_2423 = heff_dup(heff_field(v_e_2421, 1));
    v_t_2424 = v_s_2423;
    break;
  }
  default: heff_nomatch(v_e_2421);
  }
  V v_t_2425 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_2426 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str3), v_t_2425)});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2426, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
  V v_ps_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_p_241), v_t_2427});
  V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str4)}), heff_dup(v_sp_240)});
  V v_x1_2430 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2429, v_ps_2428));
  V v_t_2433;
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_At: {
    V v_s_2432 = heff_field(v_x1_2430, 1);
    heff_take_n(v_x1_2430, 2ULL, 2);
    v_t_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_x1_2430);
  }
  V v_t_2434 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2433, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str5), heff_dup(v_sp_240), v_ps_2428}), v_t_2434});
  V v_ps_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
  V v_t_2437 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str6)}), heff_dup(v_sp_240)});
  V v_x1_2438 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2437, v_ps_2436));
  V v_t_2441;
  switch (heff_tag_of(v_x1_2438)) {
  case TAG_At: {
    V v_s_2440 = heff_field(v_x1_2438, 1);
    heff_take_n(v_x1_2438, 2ULL, 2);
    v_t_2441 = v_s_2440;
    break;
  }
  default: heff_nomatch(v_x1_2438);
  }
  V v_t_2442 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2441, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_xs_2443 = (g_heff_2esyntax_2epresyntax_2epatNames(heff_dup(v_p_241)));
  HeffT2 v_t_2445 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_lam0, 1, 1, (V[]){heff_dup(v_muts_246)}); V a_1 = v_xs_2443; HeffT2 r_ = (g_list_2efind_24cpr(a_0, a_1)); heff_drop(v_xs_2443); r_; });
  {
    V v_field_2447 = v_t_2445.f[1];
    int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
    V v_e_2471;
    if ((v_tag_2446 == ((int64_t)0ULL))) {
      heff_drop_rec(v_endJ_244, 4);
      heff_drop_rec(v_inner_245, 7);
      heff_drop(v_muts_246);
      heff_drop(v_depth_247);
      V v_x_2448 = v_field_2447;
      V v_t_2451;
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_s_2450 = heff_field(v_p_241, 1);
        heff_take_n(v_p_241, 2ULL, 2);
        v_t_2451 = v_s_2450;
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      V v_t_2452 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str7), heff_dup(v_x_2448)), ((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str8));
      V v_t_2453 = heff_strAppend(heff_strAppend(v_t_2452, v_x_2448), ((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str9));
      v_e_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){v_t_2453}), v_t_2451});
    } else {
      heff_drop(v_p_241);
      heff_drop(v_field_2447);
      V v_t_2454 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_t_2455 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str10), v_t_2454)});
      V v_t_2456 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_t_2457 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str11), v_t_2456)});
      V v_t_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2457, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
      V v_t_2459 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2455, heff_dup(v_sp_240)}), v_t_2458));
      V v_cont_2460 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_2459, heff_dup(v_muts_246), NTAG(TAG_False), heff_dup(v_depth_247)});
      V v_t_2461 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_t_2462 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str12), v_t_2461)});
      V v_t_2463 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
      V v_t_2464 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str13), v_t_2463)});
      V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, heff_dup(v_sp_240)}), NTAG(TAG_Nil)});
      V v_t_2466 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_2462, heff_dup(v_sp_240)}), v_t_2465));
      V v_t_2467 = heff_rec_n(4, shape_head__vars__unit__depth, (V[]){v_t_2466, v_muts_246, NTAG(TAG_False), v_depth_247});
      V v_end_2468 = heff_tag_n(TAG_EndJump, 1, (V[]){v_t_2467});
      V v_t_2469 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_cont_2460, v_endJ_244})});
      V v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_inner_245, 123ULL, 7, shape_names__muts__loop__sp__depth__giving__bound, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      v_e_2471 = heff_tr(g_heff_2esyntax_2epresyntax_2estmtsF_24s80969983x1240131488(v_t_2470, v_body_243, v_end_2468));
    }
    V v_t_2474;
    switch (heff_tag_of(v_e_2471)) {
    case TAG_At: {
      V v_s_2473 = heff_dup(heff_field(v_e_2471, 1));
      v_t_2474 = v_s_2473;
      break;
    }
    default: heff_nomatch(v_e_2471);
    }
    V v_t_2475 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str14), heff_dup(v_sp_240), NTAG(TAG_Nil)});
    V v_t_2476 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2475, heff_dup(v_t_2414)}), v_e_2421});
    V v_t_2477 = ({ V rv_1 = heff_get_n(v_t_2424, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2414, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_str15), heff_dup(v_sp_240), v_ps_2436}), heff_dup(v_t_2442)});
    V v_t_2479 = ({ V rv_1 = heff_get_n(v_t_2474, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2442, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2480 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2478, v_e_2471}), v_t_2479});
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
    V v_alts_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2476, v_t_2477}), v_t_2481});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2413, v_alts_2482}), v_sp_240});
  }
}
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epresyntax_2eforT_2eturn_246_24s645484059x287871660_lam0(V self, V *args) {
  V v_x_2444 = args[0];
  V v_muts_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_x_2444; V a_1 = v_muts_246; V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, a_1)); heff_drop(v_x_2444); heff_drop(v_muts_246); r_; });
}