// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_EVar 52881
#define LBL_head 9693863
#define LBL_muts 9858798
#define LBL_start 311115900
#define LBL_unit 10090059
#define LBL_vars 10107635
static uint32_t shape_head__vars__unit[] = {LBL_head, LBL_vars, LBL_unit};
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_clo;
HeffT3 g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241(V);
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2eit_241_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_clo;
V g_heff_2esyntax_2epresyntax_2eforT_2evar_240(V, V);
V g_heff_2esyntax_2epresyntax_2eforT_2evar_240_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eforT_2evar_240_clo;
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2evar_240_str0, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2evar_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2evar_240_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2evar_240(V v_sp_240, V v_what_241) {
top: ;
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(v_what_241, heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2evar_240_str0), v_t_242));
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), v_sp_240});
}
V g_heff_2esyntax_2epresyntax_2eforT_2evar_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2evar_240(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str0, 9, "iterateOf");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str1, 4, "coll");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str2, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2eit_241_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry, 1, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eit_241(V v_sp_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str0)}), heff_dup(v_sp_240)});
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str1), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eit_241_str2), v_t_242));
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), v_sp_240});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_241, v_t_245));
}
V g_heff_2esyntax_2epresyntax_2eforT_2eit_241_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2eit_241(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr_str0, 5, "after");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr_str1, 1, "#");

HeffT3 g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr(V v_sp_240, V v_cx_241) {
top: ;
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr_str1), v_t_242));
  V v_f_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), v_sp_240});
  V v_f_245 = heff_get_n(v_cx_241, 1, 4);
  return ((HeffT3){{v_f_244, v_f_245, NTAG(TAG_True)}});
}
Clo g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242(V v_sp_240, V v_cx_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_24cpr(v_sp_240, v_cx_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    return heff_rec_n(3, shape_head__vars__unit, (V[]){v_field_243, v_field_244, v_field_245});
  }
}
V g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2eafterJ_242(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str0, 4, "loop");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str1, 1, "#");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str2, 4, "rest");
HEFF_LIT(g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str3, 1, "#");
Clo g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_entry, 2, 0};

V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(V v_sp_240, V v_cx_241) {
top: ;
  V v_t_242 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str0), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str1), v_t_242));
  V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_243}), heff_dup(v_sp_240)});
  V v_t_245 = heff_intShow(heff_dup(heff_rfield(v_sp_240, 0)));
  V v_t_246 = heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str2), heff_strAppend(((V)&g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_str3), v_t_245));
  V v_t_247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_246}), v_sp_240});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_244, v_t_248));
  return heff_rec_n(3, shape_head__vars__unit, (V[]){v_t_249, heff_get_n(v_cx_241, 1, 4), NTAG(TAG_False)});
}
V g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epresyntax_2eforT_2enextJ_243(a[0], a[1]);
}