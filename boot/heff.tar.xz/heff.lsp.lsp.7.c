// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_PathUri 23459
#define TAG_ProjectFiles 9175
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Throw 56084
#define TAG_UriPath 39251
#define LBL_bind 9519364
#define LBL_binder 558177493
#define LBL_checked 974171621
#define LBL_current 1358797751
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_uses 10094739
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_program__kept[] = {LBL_program, LBL_kept};
static uint32_t shape_root__names__program__current__kept[] = {LBL_root, LBL_names, LBL_program, LBL_current, LBL_kept};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1554102946x910234624(V, V, V);
V g_co_2eop_24s1554102946x910234624_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_clo;
V g_co_2eop_24s1554102946x910234624_24tok1(V, V, V, V);
V g_co_2eop_24s1554102946x910234624_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s1554102946x910234624_24tok1_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2einFile(V, V, V);
V g_heff_2ebuild_2equery_2einFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFile_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506(V, V, V, V);
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739(V, V, V);
V g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739_clo;
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220(V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257(V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_clo;
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(V);
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465(V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465_clo;
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353(V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562(V, V, V);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_clo;
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578(V, V);
V g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949(V, V, V);
V g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140(V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066(V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_clo;
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183(V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_clo;
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989(V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573(V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410(V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2eescapeInto(V, V, V);
V g_json_2eescapeInto_entry(V self, V *a);
extern Clo g_json_2eescapeInto_clo;
V g_json_2erestInto_24s1422122160x502273793(V, V, V, V, V, V, V);
V g_json_2erestInto_24s1422122160x502273793_entry(V self, V *a);
extern Clo g_json_2erestInto_24s1422122160x502273793_clo;
V g_json_2ewriteInto(V, V);
V g_json_2ewriteInto_entry(V self, V *a);
extern Clo g_json_2ewriteInto_clo;
V g_list_2eany_24s1027174601x1571638094(V, V, V, V);
V g_list_2eany_24s1027174601x1571638094_entry(V self, V *a);
extern Clo g_list_2eany_24s1027174601x1571638094_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2eascending_24s1053575971x1138989897(V, V, V);
V g_list_2eascending_24s1053575971x1138989897_entry(V self, V *a);
extern Clo g_list_2eascending_24s1053575971x1138989897_clo;
V g_list_2edescending_24s136597790x1673774577(V, V, V);
V g_list_2edescending_24s136597790x1673774577_entry(V self, V *a);
extern Clo g_list_2edescending_24s136597790x1673774577_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1392650298x1192381411(V, V, V);
V g_list_2emap_24s1392650298x1192381411_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s328130413x305756849(V, V, V, V);
V g_list_2emap_24s328130413x305756849_entry(V self, V *a);
extern Clo g_list_2emap_24s328130413x305756849_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s4199228x1154005405_24tok2(V, V);
V g_list_2emap_24s4199228x1154005405_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24tok2_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s655705766x180835539(V, V);
V g_list_2emergeRuns_24s655705766x180835539_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s655705766x180835539_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoListOnto(V, V);
V g_std_2eordmap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoListOnto_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2espaceEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2espaceEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2espaceEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_l_240, 0)) && ((heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)9ULL))))) {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2espaceEnd(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_str1, 12, "textDocument");
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam0, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam1, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam2, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam3, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam4(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam4, 1, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam5, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam6, 2, 0};
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam7, 2, 0};
Clo g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_entry, 1, 0};

V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(V v_p_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_str1), v_t_241}); V a_1 = v_p_240; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_244;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_JNull: {
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam0_clo);
      }
      case TAG_JBool: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam1_clo);
      }
      case TAG_JInt: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam2_clo);
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam3_clo);
      }
      case TAG_JString: {
        V v_s_2417 = heff_field(v_it1_245, 0);
        V v_ru_24it1_245_24JString = heff_take_reuse_n(v_it1_245, 1ULL, 1);
        V v_t_2419 = heff_tag_at_n(v_ru_24it1_245_24JString, TAG_InR, 1, (V[]){heff_tag_n(TAG_UriPath, 2, (V[]){v_s_2417, ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam4_clo)})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
        V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
        return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
      }
      case TAG_JArray: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam5_clo);
      }
      case TAG_JObject: {
        heff_take_n(v_it1_245, 0ULL, 1);
        return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam6_clo);
      }
      default: return heff_nomatch(v_it1_245);
      }
    } else {
      heff_drop(v_field_244);
      return ((V)&g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam7_clo);
    }
  }
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(a[0]);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam4(V self, V *args) {
  V v_p_2418 = args[0];
  return v_p_2418;
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam5(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409_lam7(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam0, 1, 0};
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam1, 1, 0};
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_entry, 4, 0};

V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506(V v_x1_240, V v_x2_241, V v_z_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_x2_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Just: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nothing: {
      heff_drop(v_z_242);
      heff_drop(v_f_244);
      heff_drop_cell(v_ru_24x1_240_24Just, 1);
      return heff_tail(v_z_243, 1, (V[]){NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_text_245 = heff_field(v_x2_241, 0);
      V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
      V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_f_244));
      V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
      V v_a_249 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_247, ((V)&g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam0_clo)});
      V v_t_2410 = heff_tag_at_n(v_ru_24x1_240_24Just, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_InR, 1, (V[]){v_a_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_c_2422 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam1_clo)));
      return heff_tail(v_c_2422, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam3, 1, 2, (V[]){v_z_243, v_text_245})});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    V v_err_2417 = heff_field(v_x_2416, 0);
    V v_ru_24x_2416_24Left = heff_take_reuse_n(v_x_2416, 1ULL, 1);
    V v_t_2418 = heff_tag_at_n(v_ru_24x_2416_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2417})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2418));
  }
  case TAG_Right: {
    V v_x_2419 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam2, 2, 1, (V[]){v_x_2419});
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_text_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_drop(v_text_245);
    V f_ = v_z_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2425 = heff_field(v_x_2423, 0);
    heff_take_n(v_x_2423, 1ULL, 1);
    V v_t_2426 = heff_bool(heff_strEq_c_lent(v_y_2425, v_text_245, 0));
    heff_drop(v_text_245);
    heff_drop(v_y_2425);
    V f_ = v_z_243;
    args[0] = v_t_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str0, 20, "textDocument/didSave");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str1, 20, "textDocument/didOpen");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str2, 4, "text");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str4, 21, "textDocument/didClose");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str5, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str6, 31, "workspace/didChangeWatchedFiles");
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam0, 2, 0};
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_entry, 3, 0};

V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562(V v_st_240, V v_m_241, V v_p_242) {
top: ;
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str0), 2)) {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_p_242);
    return ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam0_clo);
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str1), 2)) {
      heff_drop_rec(v_st_240, 7);
      V v_c_245 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(heff_dup(v_p_242)));
      return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam1, 2, 2, (V[]){v_c_245, v_p_242});
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str4), 2)) {
        V v_c_2421 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(v_p_242));
        return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam3, 2, 2, (V[]){v_c_2421, v_st_240});
      } else {
        heff_drop_rec(v_st_240, 7);
        heff_drop(v_p_242);
        return heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam5, 2, 1, (V[]){heff_dup(v_m_241)});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str2), NTAG(TAG_Nil)});
  HeffT2 v_t_2410 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str3), v_t_249}); V a_1 = v_p_242; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2420;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_it1_2413 = v_field_2412;
      switch (heff_tag_of(v_it1_2413)) {
      case TAG_JNull: {
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2417 = heff_field(v_it1_2413, 0);
        V v_ru_24it1_2413_24JString = heff_take_reuse_n(v_it1_2413, 1ULL, 1);
        v_t_2420 = heff_tag_at_n(v_ru_24it1_2413_24JString, TAG_Just, 1, (V[]){v_s_2417});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_2413, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_2413);
      }
    } else {
      heff_drop(v_field_2412);
      v_t_2420 = NTAG(TAG_Nothing);
    }
  }
  return (g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506(v_x_248, v_t_2420, v_hd_246, v_k_247));
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam2, 1, 3, (V[]){v_p_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_hd_2422 = heff_env(self)[1];
  V v_k_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430;
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 7);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_f_2425 = heff_dup(heff_field(v_x_2424, 0));
    HeffT2 v_t_2426 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_f_2425; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_f_2425); r_; });
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_d_2429 = v_field_2428;
        v_t_2430 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2429, 1, 2)});
      } else {
        heff_drop(v_field_2428);
        v_t_2430 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2424);
  }
  return (g_heff_2elsp_2elsp_2easOnDisk_24s1439610564x1665067506(v_x_2424, v_t_2430, v_hd_2422, v_k_2423));
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_c_2421 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2421;
  args[0] = heff_dup(v_hd_2422);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam4, 1, 3, (V[]){v_st_240, v_hd_2422, v_k_2423});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V v_t_2433 = heff_bool((heff_strEq_c(heff_strSlice_lent(v_m_241, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str5)) ? 0 : !heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_str6), 2)));
  heff_drop(v_m_241);
  V f_ = v_k_2432;
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(v_p_241));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam0, 2, 2, (V[]){v_c_242, v_st_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2426 = heff_get_n(v_d_2411, 1, 2);
  HeffT2 v_t_2427 = ({ V a_0 = heff_rfield(v_x_2425, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  V v_x_2433;
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    if ((v_tag_2428 == ((int64_t)0ULL))) {
      V v_c_2430 = v_field_2429;
      V v_text_2431 = heff_take_field(v_c_2430, 0);
      V v_program_2432 = heff_get_n(v_c_2430, 1, 2);
      if (heff_strEq_c_lent(v_text_2431, v_text_2426, 1)) {
        v_x_2433 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2425, v_text_2426, v_program_2432});
      } else {
        heff_drop(v_program_2432);
        v_x_2433 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2425, v_text_2426, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2429);
      v_x_2433 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2425, v_text_2426, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_244;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_d_2411 = heff_env(self)[0];
  V v_f_247 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2436 = heff_get_n(v_d_2411, 1, 2);
  HeffT2 v_t_2437 = ({ V a_0 = heff_rfield(v_x_2435, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
  V v_x_2443;
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_c_2440 = v_field_2439;
      V v_text_2441 = heff_take_field(v_c_2440, 0);
      V v_program_2442 = heff_get_n(v_c_2440, 1, 2);
      if (heff_strEq_c_lent(v_text_2441, v_text_2436, 1)) {
        v_x_2443 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2435, v_text_2436, v_program_2442});
      } else {
        heff_drop(v_program_2442);
        v_x_2443 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2435, v_text_2436, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2439);
      v_x_2443 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2435, v_text_2436, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_244;
  args[0] = v_x_2443;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_245)) {
  case TAG_Nothing: {
    heff_drop(v_hd_243);
    V v_t_246 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_str0), NTAG(TAG_Nil)});
    V f_ = v_k_244;
    args[0] = v_t_246;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_247 = heff_field(v_x_245, 0);
    heff_take_n(v_x_245, 1ULL, 1);
    HeffT2 v_t_248 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 0), v_f_247));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_d_2411 = v_field_2410;
        HeffT2 v_t_2412 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_240, 1), v_f_247));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_c_2415 = v_field_2414;
            if (heff_strEq_c(heff_get_n(v_c_2415, 0, 2), heff_dup(heff_rfield(v_d_2411, 1)))) {
              heff_drop(v_hd_243);
              V v_text_2416 = heff_get_n(v_d_2411, 1, 2);
              HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_st_240, 1); V a_1 = v_f_247; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_247); r_; });
              V v_x_2423;
              {
                V v_field_2419 = v_t_2417.f[1];
                int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                if ((v_tag_2418 == ((int64_t)0ULL))) {
                  V v_c_2420 = v_field_2419;
                  V v_text_2421 = heff_take_field(v_c_2420, 0);
                  V v_program_2422 = heff_get_n(v_c_2420, 1, 2);
                  if (heff_strEq_c_lent(v_text_2421, v_text_2416, 1)) {
                    v_x_2423 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2416, v_program_2422});
                  } else {
                    heff_drop(v_program_2422);
                    v_x_2423 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2416, NTAG(TAG_Nil)});
                  }
                } else {
                  heff_drop(v_field_2419);
                  v_x_2423 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, v_text_2416, NTAG(TAG_Nil)});
                }
              }
              V f_ = v_k_244;
              args[0] = v_x_2423;
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              V v_c_2424 = (g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(v_st_240, heff_dup(v_f_247)));
              V f_ = v_c_2424;
              heff_room[0] = v_hd_243;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam2, 1, 3, (V[]){v_d_2411, v_f_247, v_k_244});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop(v_field_2414);
            V v_c_2434 = (g_heff_2elsp_2elsp_2echeck_24s2040744805x1431874270(v_st_240, heff_dup(v_f_247)));
            V f_ = v_c_2434;
            heff_room[0] = v_hd_243;
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam3, 1, 3, (V[]){v_d_2411, v_f_247, v_k_244});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      } else {
        heff_drop(v_hd_243);
        heff_drop(v_f_247);
        heff_drop(v_field_2410);
        V v_t_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_240, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_str1), NTAG(TAG_Nil)});
        V f_ = v_k_244;
        args[0] = v_t_2444;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280_lam1, 1, 3, (V[]){v_st_240, v_k_244, v_hd_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam1, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam7(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam7, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam13(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam13, 1, 0};
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam14(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(V v_st_240, V v_root_241, V v_f_242, V v_names_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam0, 1, 5, (V[]){heff_dup(v_hd_244), heff_dup(v_root_241), heff_dup(v_names_243), heff_dup(v_st_240), v_f_242})})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})}));
  return heff_tail(heff_get_n(v_hd_244, 1, 3), 2, (V[]){v_t_2468, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam14, 1, 4, (V[]){v_st_240, v_root_241, v_names_243, v_k_245})});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam1(V self, V *args) {
  V v_fs_248 = args[0];
  return v_fs_248;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = v_x_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam6(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_d_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2433);
  V v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2432, 1, 2)});
  V f_ = v_k_2434;
  args[0] = v_t_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam7(V self, V *args) {
  V v_r_2438 = args[0];
  return v_r_2438;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam9(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2450);
  V f_ = v_k_2451;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2449});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam8(V self, V *args) {
  V v_x_2446 = args[0];
  switch (heff_tag_of(v_x_2446)) {
  case TAG_Left: {
    V v_err_2447 = heff_field(v_x_2446, 0);
    V v_ru_24x_2446_24Left = heff_take_reuse_n(v_x_2446, 1ULL, 1);
    V v_t_2448 = heff_tag_at_n(v_ru_24x_2446_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2447})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2448));
  }
  case TAG_Right: {
    V v_x_2449 = heff_field(v_x_2446, 0);
    heff_take_n(v_x_2446, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam9, 2, 1, (V[]){v_x_2449});
  }
  default: return heff_nomatch(v_x_2446);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_k_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    heff_take_n(v_x_2455, 0ULL, 1);
    v_t_2458 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2457 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Right = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    v_t_2458 = heff_tag_at_n(v_ru_24x_2455_24Right, TAG_Just, 1, (V[]){v_y_2457});
    break;
  }
  default: heff_nomatch(v_x_2455);
  }
  V f_ = v_k_2454;
  args[0] = v_t_2458;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam10(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  V v_c_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2452;
  args[0] = v_hd_2453;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam11, 1, 1, (V[]){v_k_2454});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam5(V self, V *args) {
  V v_p_2428 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2429 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_2428; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      heff_drop(v_p_2428);
      V v_d_2432 = v_field_2431;
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam6, 2, 1, (V[]){v_d_2432});
    } else {
      heff_drop(v_field_2431);
      V v_path_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_2428));
      V v_t_2437 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2436; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2436); r_; });
      V v_a_2439 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2437, ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam7_clo)});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
      V v_c_2452 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2445}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam8_clo)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam10, 2, 1, (V[]){v_c_2452});
    }
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam12(V self, V *args) {
  V v_s_2459 = args[0];
  V v_names_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_names_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_2459, 8);
    return NTAG(TAG_True);
  }
  case TAG_Just: {
    V v_names_2460 = heff_field(v_names_243, 0);
    heff_take_n(v_names_243, 1ULL, 1);
    return ({ V a_0 = MK_INT(0LL); V b_1 = heff_get_n(v_s_2459, 4, 8); V b_2 = MK_INT(0LL); V a_3 = v_names_2460; V r_ = (g_list_2eany_24s1027174601x1571638094(a_0, b_1, b_2, a_3)); heff_drop(b_1); heff_drop(b_2); heff_drop(v_names_2460); r_; });
  }
  default: return heff_nomatch(v_names_243);
  }
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_names_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_dup(heff_rfield(v_st_240, 3));
  V v_t_2425;
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop(v_root_241);
    v_t_2425 = heff_dup(g_std_2eordmap_2eempty_get());
    break;
  }
  case TAG_Just: {
    V v_pr_2422 = heff_field(v_t_2421, 0);
    heff_take_n(v_t_2421, 1ULL, 1);
    V v_root_2423 = heff_take_field(v_pr_2422, 0);
    V v_kept_2424 = heff_get_n(v_pr_2422, 4, 5);
    if (heff_strEq_c(v_root_2423, v_root_241)) {
      v_t_2425 = v_kept_2424;
    } else {
      heff_drop(v_kept_2424);
      v_t_2425 = heff_dup(g_std_2eordmap_2eempty_get());
    }
    break;
  }
  default: heff_nomatch(v_t_2421);
  }
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_t_2427 = (g_prelude_2e_2b_2b(v_x_2420, v_t_2426));
  return (g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam5, 1, 1, (V[]){heff_dup(v_st_240)}), heff_get_n(v_st_240, 6, 7), heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam12, 1, 1, (V[]){v_names_243}), v_t_2425, v_f_242, v_t_2427, v_hd_244, v_k_247));
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_names_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_root_241 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419;
  switch (heff_tag_of(v_names_243)) {
  case TAG_Nothing: {
    v_c_2419 = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam3, 2, 1, (V[]){v_x_2415});
    break;
  }
  case TAG_Just: {
    V v_names_2418 = heff_dup(heff_field(v_names_243, 0));
    v_c_2419 = ({ V a_0 = heff_dup(v_st_240); V a_1 = v_names_2418; V a_2 = v_x_2415; V r_ = (g_heff_2elsp_2elsp_2ementionedIn_24s1925234474x29656949(a_0, a_1, a_2)); heff_drop(v_names_2418); r_; });
    break;
  }
  default: heff_nomatch(v_names_243);
  }
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam4, 1, 6, (V[]){v_st_240, v_root_241, v_f_242, v_names_243, v_hd_244, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam13(V self, V *args) {
  V v_r_2462 = args[0];
  return v_r_2462;
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam0(V self, V *args) {
  V v_use_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_names_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_f_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_k_247 = heff_dup(heff_rfield(v_hd_244, 0));
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProjectFiles, 2, (V[]){heff_dup(v_root_241), ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam1_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})}));
  V v_t_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam2, 1, 6, (V[]){v_names_243, v_st_240, v_hd_244, v_root_241, v_f_242, v_k_247})}));
  V f_ = v_use_246;
  heff_room[0] = v_t_2461;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam13_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojectAnew_24s1148392565x772836468_lam14(V self, V *args) {
  V v_x_2469 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_root_241 = heff_env(self)[1];
  V v_names_243 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_e_2472;
  switch (heff_tag_of(v_x_2469)) {
  case TAG_Left: {
    heff_take_n(v_x_2469, 0ULL, 1);
    v_e_2472 = heff_rec_n(2, shape_program__kept, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
    break;
  }
  case TAG_Right: {
    V v_e_2471 = heff_field(v_x_2469, 0);
    heff_take_n(v_x_2469, 1ULL, 1);
    v_e_2472 = v_e_2471;
    break;
  }
  default: heff_nomatch(v_x_2469);
  }
  V v_program_2473 = heff_take_field(v_e_2472, 0);
  V v_kept_2474 = heff_get_n(v_e_2472, 1, 2);
  V v_kept_2481;
  switch (heff_tag_of(v_program_2473)) {
  case TAG_Nil: {
    heff_drop(v_kept_2474);
    V v_t_2475 = heff_dup(heff_rfield(v_st_240, 3));
    switch (heff_tag_of(v_t_2475)) {
    case TAG_Nothing: {
      v_kept_2481 = heff_dup(g_std_2eordmap_2eempty_get());
      break;
    }
    case TAG_Just: {
      V v_pr_2476 = heff_field(v_t_2475, 0);
      heff_take_n(v_t_2475, 1ULL, 1);
      V v_root_2477 = heff_take_field(v_pr_2476, 0);
      V v_kept_2478 = heff_get_n(v_pr_2476, 4, 5);
      if (heff_strEq_c_lent(v_root_2477, v_root_241, 1)) {
        v_kept_2481 = v_kept_2478;
      } else {
        heff_drop(v_kept_2478);
        v_kept_2481 = heff_dup(g_std_2eordmap_2eempty_get());
      }
      break;
    }
    default: heff_nomatch(v_t_2475);
    }
    break;
  }
  case TAG_Cons: {
    v_kept_2481 = v_kept_2474;
    break;
  }
  default: heff_nomatch(v_program_2473);
  }
  V v_due_2482 = heff_take_field(v_st_240, 2);
  V v_watch_2483 = heff_take_field(v_st_240, 4);
  V v_shutdown_2484 = heff_take_field(v_st_240, 5);
  V v_lib_2485 = heff_take_field(v_st_240, 6);
  V v_t_2486 = heff_rec_n(5, shape_root__names__program__current__kept, (V[]){v_root_241, v_names_243, heff_dup(v_program_2473), NTAG(TAG_True), v_kept_2481});
  V v_t_2487 = ({ V rv_2 = v_due_2482; V rv_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2486}); V rv_4 = v_watch_2483; V rv_5 = v_shutdown_2484; V rv_6 = v_lib_2485; V rr_ = heff_rec_reuse_nf(v_st_240, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_k_245;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_t_2487, v_program_2473});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str2, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str3, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str5, 8, "location");
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam1, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989(V v_st_240, V v_c_241, V v_y_242) {
top: ;
  V v_name_243 = heff_take_field(v_y_242, 0);
  V v_kind_244 = heff_take_field(v_y_242, 1);
  V v_selection_245 = heff_get_n(v_y_242, 3, 5);
  V v_path_246 = heff_take_field(v_c_241, 1);
  V v_module_247 = heff_take_field(v_c_241, 0);
  V v_source_248 = heff_get_n(v_c_241, 3, 14);
  V v_p_249 = v_path_246;
  HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2422;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      heff_drop(v_p_249);
      V v_d_2413 = v_field_2412;
      v_c_2422 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam0, 2, 1, (V[]){v_d_2413});
    } else {
      heff_drop(v_field_2412);
      V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_249, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam1_clo)})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
      v_c_2422 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam2, 2, 6, (V[]){v_c_2422, v_name_243, v_kind_244, v_module_247, v_source_248, v_selection_245});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam0(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_d_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = heff_get_n(v_d_2413, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam1(V self, V *args) {
  V v_u_2416 = args[0];
  return v_u_2416;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_kind_244 = heff_env(self)[1];
  V v_module_247 = heff_env(self)[2];
  V v_source_248 = heff_env(self)[3];
  V v_selection_245 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_243})});
  V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_244})});
  V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str2), heff_tag_n(TAG_JString, 1, (V[]){v_module_247})});
  V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str3), heff_tag_n(TAG_JString, 1, (V[]){v_x_2425})});
  V v_t_2430 = ({ V a_0 = v_source_248; V a_1 = v_selection_245; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_248); r_; });
  V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str4), v_t_2430}), NTAG(TAG_Nil)});
  V v_t_2432 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_str5), v_t_2432}), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2433})});
  V v_x_2435 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2434})});
  V f_ = v_k_2424;
  args[0] = v_x_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_kind_244 = heff_env(self)[2];
  V v_module_247 = heff_env(self)[3];
  V v_source_248 = heff_env(self)[4];
  V v_selection_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1805454975x2130680989_lam3, 1, 6, (V[]){v_name_243, v_kind_244, v_module_247, v_source_248, v_selection_245, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_entry, 3, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573(V v_st_240, V v_query_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_t_247 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_245)));
    V v_t_2410 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam1, 1, 1, (V[]){heff_dup(v_query_241)}), v_t_247));
    V v_c_2411 = (g_heff_2elsp_2elsp_2eeachSymbol_24s348597425x454335465(heff_dup(v_st_240), heff_dup(v_c_245), v_t_2410));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam2, 2, 4, (V[]){v_c_2411, v_st_240, heff_dup(v_query_241), heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam1(V self, V *args) {
  V v_y_248 = args[0];
  V v_query_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_249 = ({ V b_0 = heff_get_n(v_y_248, 0, 5); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_str0); V r_ = (g_heff_2elsp_2elsp_2elowerGo(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_ret_24bool = heff_bool(heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_query_241, v_s_249, MK_INT(0LL), 4)));
  heff_drop(v_query_241);
  heff_drop(v_s_249);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2417 = (g_prelude_2e_2b_2b(v_x_2414, v_x_2416));
  V f_ = v_k_2413;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_query_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2415 = ({ V a_0 = v_st_240; V a_1 = v_query_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573(a_0, a_1, a_2)); heff_drop(v_query_241); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2415;
  heff_room[0] = v_hd_2412;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam4, 1, 2, (V[]){v_x_2414, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_query_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573_lam3, 1, 5, (V[]){v_st_240, v_query_241, v_rest_246, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_entry, 6, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171(V v_a_240, V v_f_241, V v_off_242, V v_t_243, V v_z_244, V v_z_245) {
top: ;
  V v_target_246 = heff_take_field(v_t_243, 0);
  V v_name_247 = heff_get_n(v_t_243, 1, 2);
  V v_st_248 = heff_take_field(v_a_240, 0);
  V v_program_249 = heff_get_n(v_a_240, 2, 3);
  V v_t_2410 = heff_dup(heff_rfield(v_target_246, 2));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_247), NTAG(TAG_Nil)});
    V v_c_2412 = (g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(v_st_248, heff_dup(v_f_241), heff_tag_n(TAG_Just, 1, (V[]){v_t_2411})));
    return heff_tail(v_c_2412, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_lam0, 1, 6, (V[]){v_name_247, v_program_249, v_target_246, v_f_241, v_z_245, v_off_242})});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop(v_z_244);
    V v_name_2423 = heff_dup(v_name_247);
    V v_occurrences_2424 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_249, heff_dup(v_target_246), v_name_247));
    V v_target_2425 = heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, v_target_246, v_name_2423, v_occurrences_2424})});
    return heff_tail(v_z_245, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_248, v_off_242, v_target_2425})});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_lam0(V self, V *args) {
  V v_x_2413 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_program_249 = heff_env(self)[1];
  V v_target_246 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  V v_off_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_program_2414 = heff_take_field(v_x_2413, 1);
  V v_st_2415 = heff_get_n(v_x_2413, 0, 2);
  V v_name_2416 = heff_dup(v_name_247);
  V v_t_2419;
  switch (heff_tag_of(v_program_2414)) {
  case TAG_Nil: {
    v_t_2419 = v_program_249;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_program_249);
    v_t_2419 = v_program_2414;
    break;
  }
  default: heff_nomatch(v_program_2414);
  }
  V v_occurrences_2420 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2419, heff_dup(v_target_246), v_name_247));
  V v_target_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_241, v_target_246, v_name_2416, v_occurrences_2420})});
  V f_ = v_z_245;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2415, v_off_242, v_target_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_entry, 2, 0};

V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410(V v_st_240, V v_p_241) {
top: ;
  V v_c_242 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam0, 2, 2, (V[]){v_c_242, v_p_241});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_p_241);
    heff_drop(v_hd_243);
    V v_t_248 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_245, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
    V f_ = v_k_244;
    args[0] = v_t_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_249 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    V v_program_2410 = heff_dup(heff_rfield(v_x_245, 2));
    V v_off_2411 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_245, 1), heff_dup(v_p_241)));
    V v_x1_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_2410)));
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nil: {
      heff_drop(v_p_241);
      heff_drop(v_hd_243);
      heff_drop(v_f_249);
      heff_drop_cell(v_ru_24x_247_24Just, 1);
      heff_drop(v_program_2410);
      heff_drop(v_off_2411);
      V v_t_2413 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_245, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
      V f_ = v_k_244;
      args[0] = v_t_2413;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2412, 0);
      heff_take_n(v_x1_2412, 1ULL, 2);
      V v_t_2416 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_2414, 4)));
      V v_t_2417 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2416));
      V v_t_2418 = ({ V a_0 = v_program_2410; V a_1 = v_x_2414; V a_2 = v_t_2417; V a_3 = v_off_2411; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_2410); r_; });
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_drop(v_p_241);
        heff_drop(v_hd_243);
        heff_drop(v_f_249);
        heff_drop_cell(v_ru_24x_247_24Just, 1);
        V v_t_2419 = heff_rec_n(3, shape_st__off__target, (V[]){heff_get_n(v_x_245, 0, 3), MK_INT(0LL), NTAG(TAG_Nothing)});
        V f_ = v_k_244;
        args[0] = v_t_2419;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Just: {
        V v_t_2420 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        V v_t_2421 = (g_heff_2elsp_2elsp_2eoffsetIn(heff_rfield(v_x_245, 1), v_p_241));
        return (g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1(v_ru_24x_247_24Just, v_x_245, v_f_249, v_t_2421, v_t_2420, v_hd_243, v_k_244));
      }
      default: return heff_nomatch(v_t_2418);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_p_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(heff_dup(v_p_241)));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam2, 1, 4, (V[]){v_x_245, v_k_244, v_p_241, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410_lam1, 1, 3, (V[]){v_p_241, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str0, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str4, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str17, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str19, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str20, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str21, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str22, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str23, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str24, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str25, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str26, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str27, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str28, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str29, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str30, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str31, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str32, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str33, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str34, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str35, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str36, 1, "{");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str37, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str38, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str39, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str40, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str41, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str42, 1, "}");
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_entry, 5, 0};

V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183(V v_id_240, V v_new_241, V v_tg_242, V v_z_243, V v_z_244) {
top: ;
  V v_target_245 = heff_take_field(v_tg_242, 2);
  V v_st_246 = heff_get_n(v_tg_242, 0, 3);
  switch (heff_tag_of(v_target_245)) {
  case TAG_Nothing: {
    heff_drop(v_new_241);
    V v_t_247 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str0), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str1), MK_INT(0LL)));
    V v_acc_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str2)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str3));
    V v_t_249 = (g_json_2eescapeInto(heff_strAppend(v_acc_248, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str4)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str5), MK_INT(0LL)));
    V v_acc_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str6));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_acc_2410, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str7)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str8));
    V v_t_2412 = (g_json_2eescapeInto(v_t_2411, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str9), MK_INT(0LL)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str10)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str11));
    V v_acc_2414 = ({ V a_0 = v_t_2413; V a_1 = v_id_240; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_240); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(v_acc_2414, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str12)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str13));
    V v_t_2416 = (g_json_2eescapeInto(v_t_2415, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str14), MK_INT(0LL)));
    V v_acc_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str15)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str16));
    V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str17)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str18));
    V v_a_2419 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s1554102946x910234624(v_a_2419, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam0, 1, 2, (V[]){v_z_244, v_st_246})));
  }
  case TAG_Just: {
    V v_t_2421 = heff_field(v_target_245, 0);
    V v_ru_24target_245_24Just = heff_take_reuse_n(v_target_245, 1ULL, 1);
    HeffT2 v_t_2422 = (g_heff_2ebuild_2equery_2erenameRefused_24cpr(heff_dup(heff_rfield(v_t_2421, 1)), heff_dup(heff_rfield(v_t_2421, 2)), heff_dup(v_new_241)));
    {
      V v_field_2424 = v_t_2422.f[1];
      int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
      if ((v_tag_2423 == ((int64_t)0ULL))) {
        heff_drop(v_new_241);
        heff_drop_rec(v_t_2421, 4);
        V v_why_2425 = v_field_2424;
        V v_c_2426 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(v_ru_24target_245_24Just, v_id_240, MK_INT(-32803LL), v_why_2425));
        return heff_tail(v_c_2426, 2, (V[]){v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam1, 1, 2, (V[]){v_z_244, v_st_246})});
      } else {
        heff_drop_cell(v_ru_24target_245_24Just, 1);
        heff_drop(v_field_2424);
        V v_c_2428 = (g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894(v_st_246, heff_dup(v_t_2421), heff_dup(v_new_241)));
        return heff_tail(v_c_2428, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam2, 1, 5, (V[]){v_t_2421, v_new_241, v_z_243, v_id_240, v_z_244})});
      }
    }
  }
  default: return heff_nomatch(v_target_245);
  }
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam1(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_st_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V f_ = v_z_244;
  args[0] = v_st_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam3(V self, V *args) {
  V v_p_2439 = args[0];
  V v_os_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2440 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2439, v_os_2436));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2439, v_os_2440});
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2464;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_x_2462 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 2);
    v_t_2464 = v_x_2462;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V f_ = v_z_244;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam4(V self, V *args) {
  V v_x_2443 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2444 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str19), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str20), MK_INT(0LL)));
  V v_acc_2445 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str21)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str22));
  V v_t_2446 = (g_json_2eescapeInto(heff_strAppend(v_acc_2445, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str23)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str24), MK_INT(0LL)));
  V v_acc_2447 = heff_strAppend(v_t_2446, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str25));
  V v_t_2448 = heff_strAppend(heff_strAppend(v_acc_2447, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str26)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str27));
  V v_t_2449 = (g_json_2eescapeInto(v_t_2448, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str28), MK_INT(0LL)));
  V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str29)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str30));
  V v_acc_2451 = ({ V a_0 = v_t_2450; V a_1 = v_id_240; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_240); r_; });
  V v_t_2452 = heff_strAppend(heff_strAppend(v_acc_2451, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str31)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str32));
  V v_t_2453 = (g_json_2eescapeInto(v_t_2452, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str33), MK_INT(0LL)));
  V v_acc_2454 = heff_strAppend(heff_strAppend(v_t_2453, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str34)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str35));
  V v_t_2455 = heff_strAppend(heff_strAppend(v_acc_2454, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str36)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str37));
  V v_t_2456 = (g_json_2eescapeInto(v_t_2455, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str38), MK_INT(0LL)));
  V v_t_2457 = heff_strAppend(heff_strAppend(v_t_2456, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str39)), ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str40));
  V v_acc_2458 = ({ V a_0 = v_t_2457; V b_1 = heff_tag_n(TAG_JObject, 1, (V[]){v_x_2443}); V r_ = (g_json_2ewriteInto(a_0, b_1)); heff_drop(b_1); r_; });
  V v_acc_2459 = heff_strAppend(v_acc_2458, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str41));
  V v_a_2460 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2459, ((V)&g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_str42)), NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_2460, v_z_243, heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam5, 1, 2, (V[]){v_x_2429, v_z_244})));
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam6(V self, V *args) {
  V v_x_2467 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2467);
  V v_t_2470;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 2);
    v_t_2470 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V f_ = v_z_244;
  args[0] = v_t_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_t_2421 = heff_env(self)[0];
  V v_new_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_id_240 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_y_2431 = heff_dup(heff_field(v_x_2429, 1));
    v_t_2432 = v_y_2431;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  switch (heff_tag_of(v_t_2432)) {
  case TAG_Nothing: {
    V v_t_2435;
    switch (heff_tag_of(v_x_2429)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_dup(heff_field(v_x_2429, 0));
      v_t_2435 = v_x_2433;
      break;
    }
    default: heff_nomatch(v_x_2429);
    }
    V v_os_2436 = heff_get_n(v_t_2421, 3, 4);
    V v_t_2437 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2436)));
    V v_t_2438 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2437));
    V v_t_2441 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam3, 1, 1, (V[]){v_os_2436}), v_t_2438));
    V v_c_2442 = (g_heff_2elsp_2elsp_2echangesOf_24s1004245210x152107739(v_t_2435, v_new_241, v_t_2441));
    V f_ = v_c_2442;
    heff_room[0] = heff_dup(v_z_243);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam4, 1, 4, (V[]){v_id_240, v_z_243, v_x_2429, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_why_2465 = heff_field(v_t_2432, 0);
    V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 1ULL, 1);
    heff_drop_rec(v_t_2421, 4);
    heff_drop(v_new_241);
    V v_c_2466 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(v_ru_24t_2432_24Just, v_id_240, MK_INT(-32803LL), v_why_2465));
    V f_ = v_c_2466;
    heff_room[0] = v_z_243;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183_lam6, 1, 2, (V[]){v_x_2429, v_z_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2432);
  }
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str0, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str2, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str3, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str4, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str7, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str8, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str9, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str10, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str11, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str12, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str13, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str15, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str16, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str17, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str18, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str19, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str20, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str21, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str22, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str23, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str24, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str25, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str27, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str29, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str31, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str32, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str33, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str34, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str35, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str36, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str37, 1, "[");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str38, 1, "]");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str39, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str40, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str41, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str42, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str43, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str44, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str45, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str46, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str47, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str48, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str49, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str50, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str51, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str52, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str54, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str55, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str56, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str57, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str58, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str59, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str60, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str61, 1, "}");
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_entry, 6, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786(V v_st_240, V v_id_241, V v_d_242, V v_fix_243, V v_z_244, V v_z_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_243, heff_dup(heff_rfield(v_d_242, 1))));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_242, 2);
      V v_x_249 = v_field_248;
      heff_drop(v_x_249);
      V v_t_2410 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str0), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str1), MK_INT(0LL)));
      V v_acc_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str2)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str3));
      V v_t_2412 = (g_json_2eescapeInto(heff_strAppend(v_acc_2411, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str4)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str5), MK_INT(0LL)));
      V v_acc_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str6));
      V v_t_2414 = heff_strAppend(heff_strAppend(v_acc_2413, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str7)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str8));
      V v_t_2415 = (g_json_2eescapeInto(v_t_2414, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str9), MK_INT(0LL)));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str10)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str11));
      V v_acc_2417 = (g_json_2ewriteInto(v_t_2416, v_id_241));
      V v_t_2418 = heff_strAppend(heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str12)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str13));
      V v_t_2419 = (g_json_2eescapeInto(v_t_2418, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str14), MK_INT(0LL)));
      V v_acc_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str15)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str16));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_acc_2420, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str17)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str18));
      V v_a_2422 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2421, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str19)), NTAG(TAG_MkUnit)});
      return (g_co_2eop_24s1554102946x910234624(v_a_2422, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam0, 1, 2, (V[]){v_z_245, v_st_240})));
    } else {
      V v_t_2424 = v_field_248;
      if (heff_strEq_c(heff_dup(v_t_2424), heff_dup(heff_rfield(v_d_242, 1)))) {
        heff_drop_rec(v_d_242, 2);
        heff_drop(v_t_2424);
        V v_t_2425 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str20), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str21), MK_INT(0LL)));
        V v_acc_2426 = heff_strAppend(heff_strAppend(v_t_2425, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str22)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str23));
        V v_t_2427 = (g_json_2eescapeInto(heff_strAppend(v_acc_2426, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str24)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str25), MK_INT(0LL)));
        V v_acc_2428 = heff_strAppend(v_t_2427, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str26));
        V v_t_2429 = heff_strAppend(heff_strAppend(v_acc_2428, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str27)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str28));
        V v_t_2430 = (g_json_2eescapeInto(v_t_2429, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str29), MK_INT(0LL)));
        V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str30)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str31));
        V v_acc_2432 = (g_json_2ewriteInto(v_t_2431, v_id_241));
        V v_t_2433 = heff_strAppend(heff_strAppend(v_acc_2432, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str32)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str33));
        V v_t_2434 = (g_json_2eescapeInto(v_t_2433, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str34), MK_INT(0LL)));
        V v_acc_2435 = heff_strAppend(heff_strAppend(v_t_2434, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str35)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str36));
        V v_t_2436 = heff_strAppend(heff_strAppend(v_acc_2435, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str37)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str38));
        V v_a_2437 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str39)), NTAG(TAG_MkUnit)});
        return (g_co_2eop_24s1554102946x910234624(v_a_2437, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam1, 1, 2, (V[]){v_z_245, v_st_240})));
      } else {
        V v_src_2439 = heff_dup(heff_rfield(v_d_242, 1));
        V v_t_2440 = heff_strLength(heff_get_n(v_d_242, 1, 2));
        V v_t_2441 = (g_heff_2elsp_2elsp_2eposition(v_src_2439, MK_INT(0LL)));
        V v_t_2442;
        if ((((int64_t)0ULL) <= heff_peek_word(v_t_2440))) {
          v_t_2442 = v_t_2440;
        } else {
          heff_drop(v_t_2440);
          v_t_2442 = MK_INT(0LL);
        }
        V v_t_2443 = ({ V a_0 = v_src_2439; V a_1 = v_t_2442; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_2439); r_; });
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str40), v_t_2443}), NTAG(TAG_Nil)});
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str41), v_t_2441}), v_t_2444});
        V v_t_2446 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str42), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2445})});
        V v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str43), heff_tag_n(TAG_JString, 1, (V[]){v_t_2424})});
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
        V v_t_2449 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2448})});
        V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
        V v_result_2451 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2450});
        V v_t_2452 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str44), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str45), MK_INT(0LL)));
        V v_acc_2453 = heff_strAppend(heff_strAppend(v_t_2452, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str46)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str47));
        V v_t_2454 = (g_json_2eescapeInto(heff_strAppend(v_acc_2453, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str48)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str49), MK_INT(0LL)));
        V v_acc_2455 = heff_strAppend(v_t_2454, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str50));
        V v_t_2456 = heff_strAppend(heff_strAppend(v_acc_2455, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str51)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str52));
        V v_t_2457 = (g_json_2eescapeInto(v_t_2456, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str53), MK_INT(0LL)));
        V v_t_2458 = heff_strAppend(heff_strAppend(v_t_2457, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str54)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str55));
        V v_acc_2459 = (g_json_2ewriteInto(v_t_2458, v_id_241));
        V v_t_2460 = heff_strAppend(heff_strAppend(v_acc_2459, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str56)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str57));
        V v_t_2461 = (g_json_2eescapeInto(v_t_2460, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str58), MK_INT(0LL)));
        V v_t_2462 = heff_strAppend(heff_strAppend(v_t_2461, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str59)), ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str60));
        V v_acc_2463 = ({ V a_0 = v_t_2462; V a_1 = v_result_2451; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_result_2451, 1); r_; });
        V v_a_2464 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2463, ((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_str61)), NTAG(TAG_MkUnit)});
        return (g_co_2eop_24s1554102946x910234624(v_a_2464, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam2, 1, 2, (V[]){v_z_245, v_st_240})));
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2423);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam1(V self, V *args) {
  V v_x_2438 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1165636180x967317786_lam2(V self, V *args) {
  V v_x_2465 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2465);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257(V v_a_240, V v_p_241) {
top: ;
  V v_program_242 = heff_take_field(v_a_240, 2);
  V v_text_243 = heff_take_field(v_a_240, 1);
  V v_st_244 = heff_get_n(v_a_240, 0, 3);
  V v_c_245 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(heff_dup(v_p_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_lam0, 2, 5, (V[]){v_c_245, v_program_242, v_p_241, v_text_243, v_st_244});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_program_242 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_text_243 = heff_env(self)[3];
  V v_st_244 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_248)) {
  case TAG_Nothing: {
    heff_drop(v_program_242);
    heff_drop(v_p_241);
    heff_drop(v_text_243);
    heff_drop(v_st_244);
    heff_drop(v_hd_246);
    V f_ = v_k_247;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_249 = heff_field(v_x_248, 0);
    heff_take_n(v_x_248, 1ULL, 1);
    V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_242)));
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Nil: {
      heff_drop(v_program_242);
      heff_drop(v_p_241);
      heff_drop(v_text_243);
      heff_drop(v_st_244);
      heff_drop(v_hd_246);
      heff_drop(v_f_249);
      V f_ = v_k_247;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x1_2410, 0);
      V v_ru_24x1_2410_24Cons = heff_take_reuse_n(v_x1_2410, 1ULL, 2);
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_2410_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str0), NTAG(TAG_Nil)});
      HeffT2 v_t_2414 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str1), v_t_2413}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2424;
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_it1_2417 = v_field_2416;
          switch (heff_tag_of(v_it1_2417)) {
          case TAG_JNull: {
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          case TAG_JArray: {
            V v_xs_2422 = heff_field(v_it1_2417, 0);
            heff_take_n(v_it1_2417, 1ULL, 1);
            v_t_2424 = ({ V a_0 = v_xs_2422; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2422); r_; });
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it1_2417);
          }
        } else {
          heff_drop(v_field_2416);
          v_t_2424 = NTAG(TAG_True);
        }
      }
      if (((heff_dup(v_t_2424) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2411, 3)), heff_dup(v_text_243)))) {
        heff_drop(v_t_2424);
        V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str2), NTAG(TAG_Nil)});
        HeffT2 v_t_2426 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str3), v_t_2425}); V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2436;
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            V v_it1_2429 = v_field_2428;
            switch (heff_tag_of(v_it1_2429)) {
            case TAG_JNull: {
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str4);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2429, 0ULL, 1);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str5);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2429, 0ULL, 1);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str6);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2429, 0ULL, 1);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str7);
              break;
            }
            case TAG_JString: {
              V v_s_2433 = heff_field(v_it1_2429, 0);
              heff_take_n(v_it1_2429, 1ULL, 1);
              v_t_2436 = v_s_2433;
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_it1_2429, 0ULL, 1);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str8);
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2429, 0ULL, 1);
              v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str9);
              break;
            }
            default: heff_nomatch(v_it1_2429);
            }
          } else {
            heff_drop(v_field_2428);
            v_t_2436 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str10);
          }
        }
        V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str11), NTAG(TAG_Nil)});
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str13), v_t_2437})});
        HeffT2 v_t_2439 = ({ V a_0 = v_t_2438; V a_1 = heff_dup(v_p_241); HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2438, 2); r_; });
        V v_t_2463;
        {
          V v_field_2441 = v_t_2439.f[1];
          int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
          V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str14), NTAG(TAG_Nil)});
          V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_str16), v_t_2442})});
          HeffT2 v_t_2444 = ({ V a_0 = v_t_2443; V a_1 = v_p_241; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2443, 2); r_; });
          {
            V v_field_2446 = v_t_2444.f[1];
            int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
            V v_t_2454;
            if ((v_tag_2440 == ((int64_t)0ULL))) {
              V v_it1_2447 = v_field_2441;
              switch (heff_tag_of(v_it1_2447)) {
              case TAG_JNull: {
                v_t_2454 = MK_INT(0LL);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2447, 0ULL, 1);
                v_t_2454 = MK_INT(0LL);
                break;
              }
              case TAG_JInt: {
                V v_i_2449 = heff_field(v_it1_2447, 0);
                heff_take_n(v_it1_2447, 1ULL, 1);
                v_t_2454 = v_i_2449;
                break;
              }
              case TAG_JFloat: {
                double v_x_2450 = heff_tflat_f64(v_it1_2447, 0);
                heff_take_na(v_it1_2447, 0ULL, 1);
                v_t_2454 = heff_floor_f64(v_x_2450);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_it1_2447, 0ULL, 1);
                v_t_2454 = MK_INT(0LL);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2447, 0ULL, 1);
                v_t_2454 = MK_INT(0LL);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2447, 0ULL, 1);
                v_t_2454 = MK_INT(0LL);
                break;
              }
              default: heff_nomatch(v_it1_2447);
              }
            } else {
              heff_drop(v_field_2441);
              v_t_2454 = MK_INT(0LL);
            }
            V v_t_2462;
            if ((v_tag_2445 == ((int64_t)0ULL))) {
              V v_it1_2455 = v_field_2446;
              switch (heff_tag_of(v_it1_2455)) {
              case TAG_JNull: {
                v_t_2462 = MK_INT(0LL);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2455, 0ULL, 1);
                v_t_2462 = MK_INT(0LL);
                break;
              }
              case TAG_JInt: {
                V v_i_2457 = heff_field(v_it1_2455, 0);
                heff_take_n(v_it1_2455, 1ULL, 1);
                v_t_2462 = v_i_2457;
                break;
              }
              case TAG_JFloat: {
                double v_x_2458 = heff_tflat_f64(v_it1_2455, 0);
                heff_take_na(v_it1_2455, 0ULL, 1);
                v_t_2462 = heff_floor_f64(v_x_2458);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_it1_2455, 0ULL, 1);
                v_t_2462 = MK_INT(0LL);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2455, 0ULL, 1);
                v_t_2462 = MK_INT(0LL);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2455, 0ULL, 1);
                v_t_2462 = MK_INT(0LL);
                break;
              }
              default: heff_nomatch(v_it1_2455);
              }
            } else {
              heff_drop(v_field_2446);
              v_t_2462 = MK_INT(0LL);
            }
            v_t_2463 = ({ V a_0 = v_text_243; V a_1 = v_t_2454; V a_2 = v_t_2462; V a_3 = MK_INT(0LL); V a_4 = MK_INT(0LL); V r_ = (g_heff_2elsp_2elsp_2eoffsetGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_243); r_; });
          }
        }
        return (g_heff_2elsp_2elsp_2esplitIn_24s332287586x1560477326(v_st_244, v_f_249, v_t_2436, v_program_242, v_x_2411, v_t_2463, v_hd_246, v_k_247));
      } else {
        heff_drop(v_program_242);
        heff_drop(v_p_241);
        heff_drop(v_text_243);
        heff_drop(v_st_244);
        heff_drop(v_hd_246);
        heff_drop(v_f_249);
        heff_drop_rec(v_x_2411, 14);
        heff_drop(v_t_2424);
        V f_ = v_k_247;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_program_242 = heff_env(self)[1];
  V v_p_241 = heff_env(self)[2];
  V v_text_243 = heff_env(self)[3];
  V v_st_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257_lam1, 1, 6, (V[]){v_k_247, v_program_242, v_p_241, v_text_243, v_st_244, v_hd_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str1, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str2, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str3, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str4, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str5, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str6, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str7, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str8, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str9, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str10, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str11, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str12, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str13, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str14, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str15, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str16, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str17, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str19, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str20, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str21, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str22, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str23, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str24, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str25, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str27, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str28, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str29, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str31, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str32, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str33, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str34, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str35, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str36, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str37, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str39, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str40, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str41, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str42, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str43, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str44, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str45, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str46, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str47, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str48, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str49, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str50, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str51, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str52, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str54, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str55, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str56, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str57, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str58, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str59, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str60, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str61, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str62, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str63, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str64, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str65, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str66, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str67, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str68, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str69, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str70, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str71, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str72, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str73, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str74, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str75, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str76, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str77, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str78, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str79, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str80, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str81, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str82, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str83, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str84, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str85, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str86, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str87, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str88, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str89, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str90, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str91, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str92, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str93, 30, "textDocument/documentHighlight");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str94, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str95, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str96, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str97, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str98, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str99, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str100, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str101, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str102, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str103, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str104, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str105, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str106, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str107, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str108, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str109, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str110, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str111, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str112, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str113, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str114, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str115, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str116, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str117, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str118, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str119, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str120, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str121, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str122, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str123, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str124, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str125, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str126, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str127, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str128, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str129, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str130, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str131, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str132, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str133, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str134, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str135, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str136, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str137, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str138, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str139, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str140, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str141, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str142, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str143, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str144, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str145, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str146, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str147, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str148, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str149, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str150, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str151, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str152, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str153, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str154, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str155, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str156, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str157, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str158, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str159, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str160, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str161, 23, "textDocument/codeAction");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str162, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str163, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str164, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str165, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str166, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str167, 15, "heff/moduleName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str168, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str169, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str170, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str171, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str172, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str173, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam6, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam36(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_entry, 6, 0};

V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223(V v_st_240, V v_m_241, V v_id_242, V v_p_243, V v_z_244, V v_z_245) {
top: ;
  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str0), 2)) {
    heff_drop(v_m_241);
    V v_t_246 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str1), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str2), MK_INT(0LL)));
    V v_acc_247 = heff_strAppend(heff_strAppend(v_t_246, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str3)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str4));
    V v_t_248 = (g_json_2eescapeInto(heff_strAppend(v_acc_247, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str5)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str6), MK_INT(0LL)));
    V v_acc_249 = heff_strAppend(v_t_248, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str7));
    V v_t_2410 = heff_strAppend(heff_strAppend(v_acc_249, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str8)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str9));
    V v_t_2411 = (g_json_2eescapeInto(v_t_2410, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str10), MK_INT(0LL)));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str11)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str12));
    V v_acc_2413 = ({ V a_0 = v_t_2412; V a_1 = v_id_242; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_242); r_; });
    V v_t_2414 = heff_strAppend(heff_strAppend(v_acc_2413, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str13)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str14));
    V v_t_2415 = (g_json_2eescapeInto(v_t_2414, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str15), MK_INT(0LL)));
    V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str16)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str17));
    V v_acc_2417 = ({ V a_0 = v_t_2416; V b_1 = heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get()); V r_ = (g_json_2ewriteInto(a_0, b_1)); heff_drop(b_1); r_; });
    V v_a_2418 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2417, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str18)), NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s1554102946x910234624(v_a_2418, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam0, 1, 3, (V[]){v_p_243, v_st_240, v_z_245})));
  } else {
    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str23), 2)) {
      heff_drop(v_m_241);
      heff_drop(v_p_243);
      V v_t_2463 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str24), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str25), MK_INT(0LL)));
      V v_acc_2464 = heff_strAppend(heff_strAppend(v_t_2463, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str26)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str27));
      V v_t_2465 = (g_json_2eescapeInto(heff_strAppend(v_acc_2464, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str28)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str29), MK_INT(0LL)));
      V v_acc_2466 = heff_strAppend(v_t_2465, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str30));
      V v_t_2467 = heff_strAppend(heff_strAppend(v_acc_2466, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str31)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str32));
      V v_t_2468 = (g_json_2eescapeInto(v_t_2467, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str33), MK_INT(0LL)));
      V v_t_2469 = heff_strAppend(heff_strAppend(v_t_2468, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str34)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str35));
      V v_acc_2470 = ({ V a_0 = v_t_2469; V a_1 = v_id_242; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_242); r_; });
      V v_t_2471 = heff_strAppend(heff_strAppend(v_acc_2470, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str36)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str37));
      V v_t_2472 = (g_json_2eescapeInto(v_t_2471, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str38), MK_INT(0LL)));
      V v_acc_2473 = heff_strAppend(heff_strAppend(v_t_2472, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str39)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str40));
      V v_t_2474 = heff_strAppend(heff_strAppend(v_acc_2473, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str41)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str42));
      V v_a_2475 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2474, NTAG(TAG_MkUnit)});
      return (g_co_2eop_24s1554102946x910234624(v_a_2475, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam1, 1, 2, (V[]){v_st_240, v_z_245})));
    } else {
      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str43), 2)) {
        heff_drop(v_m_241);
        V v_c_2482 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, heff_dup(v_p_243)));
        return heff_tail(v_c_2482, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam2, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
      } else {
        if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str62), 2)) {
          heff_drop(v_m_241);
          V v_c_2499 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, heff_dup(v_p_243)));
          return heff_tail(v_c_2499, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam4, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
        } else {
          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str93), 2)) {
            heff_drop(v_m_241);
            V v_c_24158 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, heff_dup(v_p_243)));
            return heff_tail(v_c_24158, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam10, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
          } else {
            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str110), 2)) {
              heff_drop(v_m_241);
              V v_c_24211 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, heff_dup(v_p_243)));
              return heff_tail(v_c_24211, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam12, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
            } else {
              if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str116), 2)) {
                heff_drop(v_m_241);
                V v_c_24230 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, v_p_243));
                return heff_tail(v_c_24230, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam14, 1, 3, (V[]){v_id_242, v_z_244, v_z_245})});
              } else {
                if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str122), 2)) {
                  heff_drop(v_m_241);
                  V v_t_24249 = (g_std_2eordmap_2etoListOnto(heff_rfield(v_st_240, 0), NTAG(TAG_Nil)));
                  V v_t_24250 = (g_list_2emap_24s1415906091x1371825187(v_t_24249));
                  V v_c_24251 = (g_heff_2elsp_2elsp_2erootsOf_24s200522234x263983081(heff_dup(v_st_240), v_t_24250));
                  return heff_tail(v_c_24251, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam17, 1, 5, (V[]){v_st_240, v_z_244, v_p_243, v_id_242, v_z_245})});
                } else {
                  if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str137), 2)) {
                    heff_drop(v_m_241);
                    V v_c_24282 = (g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410(v_st_240, heff_dup(v_p_243)));
                    return heff_tail(v_c_24282, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam21, 1, 4, (V[]){v_id_242, v_p_243, v_z_244, v_z_245})});
                  } else {
                    if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str150), 2)) {
                      heff_drop(v_m_241);
                      V v_c_24331 = (g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410(v_st_240, v_p_243));
                      return heff_tail(v_c_24331, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam26, 1, 3, (V[]){v_id_242, v_z_244, v_z_245})});
                    } else {
                      if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str151), 2)) {
                        heff_drop(v_m_241);
                        V v_c_24333 = (g_heff_2elsp_2elsp_2ewithTarget_24s2098980032x142067410(v_st_240, heff_dup(v_p_243)));
                        return heff_tail(v_c_24333, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam27, 1, 4, (V[]){v_p_243, v_id_242, v_z_244, v_z_245})});
                      } else {
                        if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str160), 2)) {
                          heff_drop(v_m_241);
                          V v_t_24347 = ({ V a_0 = v_st_240; V a_1 = v_id_242; V a_2 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eformatted_24s1242083030x974732353(a_0, a_1, a_2)); heff_drop(v_id_242); r_; });
                          return heff_tail(v_t_24347, 2, (V[]){v_z_244, v_z_245});
                        } else {
                          if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str161), 2)) {
                            heff_drop(v_m_241);
                            V v_c_24348 = (g_heff_2elsp_2elsp_2ewithProgram_24s104917392x1824478280(v_st_240, heff_dup(v_p_243)));
                            return heff_tail(v_c_24348, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam28, 1, 4, (V[]){v_p_243, v_z_244, v_id_242, v_z_245})});
                          } else {
                            if (heff_strEq_c_lent(v_m_241, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str167), 2)) {
                              heff_drop(v_m_241);
                              V v_c_24363 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s2022578519x1312439409(v_p_243));
                              V v_k_24372 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam32, 1, 4, (V[]){v_id_242, heff_dup(v_z_244), v_z_245, heff_dup(v_st_240)});
                              return heff_tail(v_c_24363, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam34, 1, 3, (V[]){v_k_24372, v_st_240, v_z_244})});
                            } else {
                              heff_drop(v_p_243);
                              V v_c_24379 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(v_id_242, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str173), v_m_241)));
                              return heff_tail(v_c_24379, 2, (V[]){v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam36, 1, 2, (V[]){v_z_245, v_st_240})});
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_w_2457;
  switch (heff_tag_of(v_p_243)) {
  case TAG_JNull: {
    v_w_2457 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2457 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2457 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    heff_take_na(v_p_243, 0ULL, 1);
    v_w_2457 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2457 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    heff_take_n(v_p_243, 0ULL, 1);
    v_w_2457 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_2425 = heff_field(v_p_243, 0);
    heff_take_n(v_p_243, 1ULL, 1);
    HeffT2 v_t_2426 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str19); V a_1 = v_fs_2425; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2425); r_; });
    {
      V v_field_2428 = v_t_2426.f[1];
      int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
      if ((v_tag_2427 == ((int64_t)0ULL))) {
        V v_p_2429 = v_field_2428;
        V v_t_2432;
        switch (heff_tag_of(v_p_2429)) {
        case TAG_MkPair: {
          V v_y_2431 = heff_field(v_p_2429, 1);
          heff_take_n(v_p_2429, 2ULL, 2);
          v_t_2432 = v_y_2431;
          break;
        }
        default: heff_nomatch(v_p_2429);
        }
        switch (heff_tag_of(v_t_2432)) {
        case TAG_JNull: {
          v_w_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2432, 0ULL, 1);
          v_w_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2432, 0ULL, 1);
          v_w_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2432, 0ULL, 1);
          v_w_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2432, 0ULL, 1);
          v_w_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2432, 0ULL, 1);
          v_w_2457 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          V v_fs_2438 = heff_field(v_t_2432, 0);
          heff_take_n(v_t_2432, 1ULL, 1);
          HeffT2 v_t_2439 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str20); V a_1 = v_fs_2438; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2438); r_; });
          {
            V v_field_2441 = v_t_2439.f[1];
            int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
            if ((v_tag_2440 == ((int64_t)0ULL))) {
              V v_p_2442 = v_field_2441;
              V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str21), NTAG(TAG_Nil)});
              V v_t_2446;
              switch (heff_tag_of(v_p_2442)) {
              case TAG_MkPair: {
                V v_y_2445 = heff_field(v_p_2442, 1);
                heff_take_n(v_p_2442, 2ULL, 2);
                v_t_2446 = v_y_2445;
                break;
              }
              default: heff_nomatch(v_p_2442);
              }
              HeffT2 v_t_2447 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str22), v_t_2443}); V a_1 = v_t_2446; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2449 = v_t_2447.f[1];
                int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                if ((v_tag_2448 == ((int64_t)0ULL))) {
                  V v_it1_2450 = v_field_2449;
                  switch (heff_tag_of(v_it1_2450)) {
                  case TAG_JNull: {
                    v_w_2457 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JBool: {
                    V v_b_2451 = heff_field(v_it1_2450, 0);
                    heff_take_n(v_it1_2450, 1ULL, 1);
                    v_w_2457 = v_b_2451;
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2450, 0ULL, 1);
                    v_w_2457 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2450, 0ULL, 1);
                    v_w_2457 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JString: {
                    heff_take_n(v_it1_2450, 0ULL, 1);
                    v_w_2457 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2450, 0ULL, 1);
                    v_w_2457 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2450, 0ULL, 1);
                    v_w_2457 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_it1_2450);
                  }
                } else {
                  heff_drop(v_field_2449);
                  v_w_2457 = NTAG(TAG_False);
                }
              }
            } else {
              heff_drop(v_field_2441);
              v_w_2457 = NTAG(TAG_False);
            }
          }
          break;
        }
        default: heff_nomatch(v_t_2432);
        }
      } else {
        heff_drop(v_field_2428);
        v_w_2457 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_p_243);
  }
  V v_due_2458 = heff_take_field(v_st_240, 2);
  V v_project_2459 = heff_take_field(v_st_240, 3);
  V v_shutdown_2460 = heff_take_field(v_st_240, 5);
  V v_lib_2461 = heff_take_field(v_st_240, 6);
  V v_t_2462 = ({ V rv_2 = v_due_2458; V rv_3 = v_project_2459; V rv_4 = v_w_2457; V rv_5 = v_shutdown_2460; V rv_6 = v_lib_2461; V rr_ = heff_rec_reuse_nf(v_st_240, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_245;
  args[0] = v_t_2462;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam1(V self, V *args) {
  V v_x_2476 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2476);
  V v_due_2477 = heff_take_field(v_st_240, 2);
  V v_project_2478 = heff_take_field(v_st_240, 3);
  V v_watch_2479 = heff_take_field(v_st_240, 4);
  V v_lib_2480 = heff_take_field(v_st_240, 6);
  V v_t_2481 = ({ V rv_2 = v_due_2477; V rv_3 = v_project_2478; V rv_4 = v_watch_2479; V rv_5 = NTAG(TAG_True); V rv_6 = v_lib_2480; V rr_ = heff_rec_reuse_nf(v_st_240, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_245;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam3(V self, V *args) {
  V v_x_2498 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_x_2483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2498);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_x_2483, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam2(V self, V *args) {
  V v_x_2483 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_result_2484 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2483), v_p_243));
  V v_t_2485 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str44), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str45), MK_INT(0LL)));
  V v_acc_2486 = heff_strAppend(heff_strAppend(v_t_2485, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str46)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str47));
  V v_t_2487 = (g_json_2eescapeInto(heff_strAppend(v_acc_2486, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str48)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str49), MK_INT(0LL)));
  V v_acc_2488 = heff_strAppend(v_t_2487, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str50));
  V v_t_2489 = heff_strAppend(heff_strAppend(v_acc_2488, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str51)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str52));
  V v_t_2490 = (g_json_2eescapeInto(v_t_2489, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str53), MK_INT(0LL)));
  V v_t_2491 = heff_strAppend(heff_strAppend(v_t_2490, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str54)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str55));
  V v_acc_2492 = ({ V a_0 = v_t_2491; V a_1 = v_id_242; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_id_242); r_; });
  V v_t_2493 = heff_strAppend(heff_strAppend(v_acc_2492, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str56)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str57));
  V v_t_2494 = (g_json_2eescapeInto(v_t_2493, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str58), MK_INT(0LL)));
  V v_t_2495 = heff_strAppend(heff_strAppend(v_t_2494, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str59)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str60));
  V v_acc_2496 = ({ V a_0 = v_t_2495; V a_1 = v_result_2484; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop(v_result_2484); r_; });
  V v_a_2497 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2496, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str61)), NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_2497, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam3, 1, 2, (V[]){v_z_245, v_x_2483})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam5(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_d_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = heff_get_n(v_d_24127, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam6(V self, V *args) {
  V v_u_24130 = args[0];
  return v_u_24130;
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam8(V self, V *args) {
  V v_x_24139 = args[0];
  V v_source_24121 = heff_env(self)[0];
  V v_span_24122 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_hd_24137 = heff_env(self)[3];
  V v_k_24138 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24140 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str77), heff_tag_n(TAG_JString, 1, (V[]){v_x_24139})});
  V v_t_24141 = ({ V a_0 = v_source_24121; V a_1 = v_span_24122; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_24121); r_; });
  V v_t_24142 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str78), v_t_24141}), NTAG(TAG_Nil)});
  V v_result_24143 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24140, v_t_24142})});
  V v_t_24144 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str79), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str80), MK_INT(0LL)));
  V v_acc_24145 = heff_strAppend(heff_strAppend(v_t_24144, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str81)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str82));
  V v_t_24146 = (g_json_2eescapeInto(heff_strAppend(v_acc_24145, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str83)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str84), MK_INT(0LL)));
  V v_t_24147 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str85), v_result_24143}), NTAG(TAG_Nil)});
  V v_t_24148 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str86), v_id_242}), v_t_24147});
  V v_t_24149 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str87); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str88); V a_3 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str89); V a_4 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str90); V a_5 = heff_strAppend(v_t_24146, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str91)); V a_6 = v_t_24148; V r_ = (g_json_2erestInto_24s1422122160x502273793(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_t_24148, 2); r_; });
  V v_a_24150 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24149, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str92)), NTAG(TAG_MkUnit)});
  V v_t_24151 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24150})});
  V v_t_24152 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24151})});
  V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
  V v_t_24154 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
  V v_t_24155 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24154})});
  return (g_co_2eop_24s615738393x1686646143(v_t_24155, v_hd_24137, v_k_24138));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam7(V self, V *args) {
  V v_hd_24137 = args[0];
  V v_k_24138 = args[1];
  V v_c_24136 = heff_env(self)[0];
  V v_source_24121 = heff_env(self)[1];
  V v_span_24122 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24136;
  args[0] = heff_dup(v_hd_24137);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam8, 1, 5, (V[]){v_source_24121, v_span_24122, v_id_242, v_hd_24137, v_k_24138});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam9(V self, V *args) {
  V v_x_24157 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24103 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24157);
  V f_ = v_z_245;
  args[0] = v_st_24103;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam4(V self, V *args) {
  V v_x_24100 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_program_24101 = heff_take_field(v_x_24100, 2);
  V v_text_24102 = heff_take_field(v_x_24100, 1);
  V v_st_24103 = heff_get_n(v_x_24100, 0, 3);
  V v_t_24104 = ({ V a_0 = v_text_24102; V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24102); r_; });
  V v_t_24105 = (g_heff_2ebuild_2equery_2edefinitionAt(v_program_24101, v_t_24104));
  V v_c_24156;
  switch (heff_tag_of(v_t_24105)) {
  case TAG_Nothing: {
    V v_t_24106 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str63), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str64), MK_INT(0LL)));
    V v_acc_24107 = heff_strAppend(heff_strAppend(v_t_24106, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str65)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str66));
    V v_t_24108 = (g_json_2eescapeInto(heff_strAppend(v_acc_24107, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str67)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str68), MK_INT(0LL)));
    V v_t_24109 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str69), NTAG(TAG_JNull)});
    V v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
    V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str70), v_id_242}), v_t_24110});
    V v_t_24112 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str71); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str72); V a_3 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str73); V a_4 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str74); V a_5 = heff_strAppend(v_t_24108, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str75)); V a_6 = v_t_24111; V r_ = (g_json_2erestInto_24s1422122160x502273793(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_t_24111, 2); r_; });
    V v_a_24113 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24112, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str76)), NTAG(TAG_MkUnit)});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    V v_t_24117 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
    V v_t_24118 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24117})});
    v_c_24156 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_24118}));
    break;
  }
  case TAG_Just: {
    V v_d_24119 = heff_field(v_t_24105, 0);
    V v_ru_24t_24105_24Just = heff_take_reuse_n(v_t_24105, 1ULL, 1);
    V v_path_24120 = heff_take_field(v_d_24119, 0);
    V v_source_24121 = heff_take_field(v_d_24119, 1);
    V v_span_24122 = heff_get_n(v_d_24119, 2, 3);
    V v_p_24123 = v_path_24120;
    HeffT2 v_t_24124 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_24103, 0), v_p_24123));
    V v_c_24136;
    {
      V v_field_24126 = v_t_24124.f[1];
      int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
      if ((v_tag_24125 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24t_24105_24Just, 1);
        heff_drop(v_p_24123);
        V v_d_24127 = v_field_24126;
        v_c_24136 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam5, 2, 1, (V[]){v_d_24127});
      } else {
        heff_drop(v_field_24126);
        V v_t_24131 = heff_tag_at_n(v_ru_24t_24105_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_24123, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam6_clo)})});
        V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
        V v_t_24133 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
        V v_t_24134 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24133})});
        V v_t_24135 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24134})});
        v_c_24136 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24135})}));
      }
    }
    v_c_24156 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam7, 2, 4, (V[]){v_c_24136, v_source_24121, v_span_24122, v_id_242});
    break;
  }
  default: heff_nomatch(v_t_24105);
  }
  V f_ = v_c_24156;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam9, 1, 2, (V[]){v_z_245, v_st_24103});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam11(V self, V *args) {
  V v_x_24210 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24162 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24210);
  V f_ = v_z_245;
  args[0] = v_st_24162;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam10(V self, V *args) {
  V v_x_24159 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_program_24160 = heff_take_field(v_x_24159, 2);
  V v_text_24161 = heff_take_field(v_x_24159, 1);
  V v_st_24162 = heff_get_n(v_x_24159, 0, 3);
  V v_program_24163 = v_program_24160;
  V v_off_24164 = ({ V a_0 = v_text_24161; V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24161); r_; });
  V v_x1_24165 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_24163)));
  V v_t_24200;
  switch (heff_tag_of(v_x1_24165)) {
  case TAG_Nil: {
    heff_drop(v_program_24163);
    heff_drop(v_off_24164);
    v_t_24200 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24166 = heff_field(v_x1_24165, 0);
    V v_ru_24x1_24165_24Cons = heff_take_reuse_n(v_x1_24165, 1ULL, 2);
    V v_x1_24168 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_24163)));
    switch (heff_tag_of(v_x1_24168)) {
    case TAG_Nil: {
      heff_drop(v_program_24163);
      heff_drop(v_off_24164);
      heff_drop(v_x_24166);
      heff_drop_cell(v_ru_24x1_24165_24Cons, 2);
      v_t_24200 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_24169 = heff_field(v_x1_24168, 0);
      V v_ru_24x1_24168_24Cons = heff_take_reuse_n(v_x1_24168, 1ULL, 2);
      V v_t_24171 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_24169, 4)));
      V v_t_24172 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_24171));
      V v_t_24173 = ({ V a_0 = v_program_24163; V a_1 = v_x_24169; V a_2 = v_t_24172; V a_3 = v_off_24164; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_24163); r_; });
      switch (heff_tag_of(v_t_24173)) {
      case TAG_Nothing: {
        heff_drop(v_x_24166);
        heff_drop_cell(v_ru_24x1_24165_24Cons, 2);
        heff_drop_cell(v_ru_24x1_24168_24Cons, 2);
        v_t_24200 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_24174 = heff_field(v_t_24173, 0);
        heff_take_n(v_t_24173, 1ULL, 1);
        V v_target_24175 = heff_take_field(v_t_24174, 0);
        V v_name_24176 = heff_get_n(v_t_24174, 1, 2);
        V v_lit_24177 = v_x_24166;
        V v_t_24178 = v_target_24175;
        V v_name_24179 = v_name_24176;
        V v_t_24180 = heff_dup(heff_rfield(v_t_24178, 2));
        switch (heff_tag_of(v_t_24180)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_24165_24Cons, 2);
          heff_drop_cell(v_ru_24x1_24168_24Cons, 2);
          V v_t_24181 = (g_heff_2ebuild_2equery_2einFile(v_t_24178, v_name_24179, v_lit_24177));
          V v_z_24182 = (g_prelude_2e_2b_2b(v_t_24181, NTAG(TAG_Nil)));
          v_t_24200 = v_z_24182;
          break;
        }
        case TAG_Just: {
          V v_b_24183 = heff_field(v_t_24180, 0);
          heff_take_n(v_t_24180, 1ULL, 1);
          heff_drop(v_name_24179);
          if (heff_strEq_c(heff_dup(heff_rfield(v_lit_24177, 1)), heff_get_n(v_t_24178, 0, 3))) {
            V v_t_24184 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_lit_24177, 4)));
            V v_t_24185 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_24184));
            HeffT2 v_t_24186 = ({ V a_0 = heff_dup(v_b_24183); V b_1 = heff_get_n(v_t_24185, 0, 2); HeffT2 r_ = (g_list_2efind_24s343666469x451168509_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24188 = v_t_24186.f[1];
              int64_t v_tag_24187 = ((int64_t)v_t_24186.f[0]);
              if ((v_tag_24187 == ((int64_t)0ULL))) {
                V v_l_24189 = v_field_24188;
                V v_binder_24190 = heff_take_field(v_l_24189, 1);
                V v_uses_24191 = heff_get_n(v_l_24189, 2, 3);
                V v_x_24192 = v_binder_24190;
                V v_t_24198;
                switch (heff_tag_of(v_uses_24191)) {
                case TAG_Nil: {
                  heff_drop_cell(v_ru_24x1_24168_24Cons, 2);
                  V v_t_24193 = heff_tag_at_n(v_ru_24x1_24165_24Cons, TAG_Cons, 2, (V[]){v_x_24192, NTAG(TAG_Nil)});
                  v_t_24198 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24193, NTAG(TAG_Nil)});
                  break;
                }
                case TAG_Cons: {
                  V v_y_24194 = heff_field(v_uses_24191, 0);
                  V v_ys_24195 = heff_field(v_uses_24191, 1);
                  heff_take_n(v_uses_24191, 3ULL, 2);
                  if (heff_intLe_c(heff_dup(heff_rfield(v_x_24192, 0)), heff_dup(heff_rfield(v_y_24194, 0)))) {
                    V v_t_24196 = heff_tag_at_n(v_ru_24x1_24165_24Cons, TAG_Cons, 2, (V[]){v_x_24192, NTAG(TAG_Nil)});
                    v_t_24198 = (g_list_2eascending_24s1053575971x1138989897(heff_dup(v_y_24194), heff_tag_at_n(v_ru_24x1_24168_24Cons, TAG_Cons, 2, (V[]){v_y_24194, v_t_24196}), v_ys_24195));
                  } else {
                    V v_t_24197 = heff_tag_at_n(v_ru_24x1_24165_24Cons, TAG_Cons, 2, (V[]){v_x_24192, NTAG(TAG_Nil)});
                    v_t_24198 = (g_list_2edescending_24s136597790x1673774577(heff_dup(v_y_24194), heff_tag_at_n(v_ru_24x1_24168_24Cons, TAG_Cons, 2, (V[]){v_y_24194, v_t_24197}), v_ys_24195));
                  }
                  break;
                }
                default: heff_nomatch(v_uses_24191);
                }
                V v_t_24199 = (g_list_2emergeRuns_24s655705766x180835539(NTAG(TAG_Nil), v_t_24198));
                v_t_24200 = (g_list_2emap_24s1392650298x1192381411(v_b_24183, v_lit_24177, v_t_24199));
              } else {
                heff_drop_cell(v_ru_24x1_24165_24Cons, 2);
                heff_drop_cell(v_ru_24x1_24168_24Cons, 2);
                heff_drop_rec(v_lit_24177, 14);
                heff_drop(v_b_24183);
                heff_drop(v_field_24188);
                v_t_24200 = NTAG(TAG_Nil);
              }
            }
          } else {
            heff_drop_cell(v_ru_24x1_24165_24Cons, 2);
            heff_drop_cell(v_ru_24x1_24168_24Cons, 2);
            heff_drop_rec(v_lit_24177, 14);
            heff_drop(v_b_24183);
            v_t_24200 = NTAG(TAG_Nil);
          }
          break;
        }
        default: heff_nomatch(v_t_24180);
        }
        break;
      }
      default: heff_nomatch(v_t_24173);
      }
      break;
    }
    default: heff_nomatch(v_x1_24168);
    }
    break;
  }
  default: heff_nomatch(v_x1_24165);
  }
  V v_t_24201 = (g_list_2emap_24s328130413x305756849(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str94), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str95), MK_INT(1LL), v_t_24200));
  V v_result_24202 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24201});
  V v_t_24203 = (g_json_2eescapeInto(((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str96), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str97), MK_INT(0LL)));
  V v_acc_24204 = heff_strAppend(heff_strAppend(v_t_24203, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str98)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str99));
  V v_t_24205 = (g_json_2eescapeInto(heff_strAppend(v_acc_24204, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str100)), ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str101), MK_INT(0LL)));
  V v_t_24206 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str102), v_result_24202}), NTAG(TAG_Nil)});
  V v_t_24207 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str103), v_id_242}), v_t_24206});
  V v_t_24208 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str104); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str105); V a_3 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str106); V a_4 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str107); V a_5 = heff_strAppend(v_t_24205, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str108)); V a_6 = v_t_24207; V r_ = (g_json_2erestInto_24s1422122160x502273793(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_t_24207, 2); r_; });
  V v_a_24209 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24208, ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str109)), NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_24209, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam11, 1, 2, (V[]){v_z_245, v_st_24162})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam13(V self, V *args) {
  V v_x_24229 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24215 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24229);
  V f_ = v_z_245;
  args[0] = v_st_24215;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam12(V self, V *args) {
  V v_x_24212 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_program_24213 = heff_take_field(v_x_24212, 2);
  V v_text_24214 = heff_take_field(v_x_24212, 1);
  V v_st_24215 = heff_get_n(v_x_24212, 0, 3);
  V v_x1_24216 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24213));
  V v_t_24221;
  switch (heff_tag_of(v_x1_24216)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    heff_drop(v_text_24214);
    v_t_24221 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24217 = heff_field(v_x1_24216, 0);
    V v_ru_24x1_24216_24Cons = heff_take_reuse_n(v_x1_24216, 1ULL, 2);
    V v_t_24219 = ({ V a_0 = v_text_24214; V a_1 = v_p_243; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24214); r_; });
    V v_t_24220 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24217, v_t_24219));
    v_t_24221 = (g_list_2emap_24s4199228x1154005405_24tok2(v_ru_24x1_24216_24Cons, v_t_24220));
    break;
  }
  default: heff_nomatch(v_x1_24216);
  }
  V v_result_24222 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24221});
  V v_t_24223 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str111), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str112)})});
  V v_t_24224 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str113), v_result_24222}), NTAG(TAG_Nil)});
  V v_t_24225 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str114), v_id_242}), v_t_24224});
  V v_t_24226 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24223, v_t_24225})});
  V v_t_24227 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str115); V a_1 = v_t_24226; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24226, 1); r_; });
  V v_a_24228 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24227, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_24228, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam13, 1, 2, (V[]){v_z_245, v_st_24215})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam15(V self, V *args) {
  V v_y_24239 = args[0];
  V v_text_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2edocSymbol(v_text_24233, v_y_24239));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam16(V self, V *args) {
  V v_x_24248 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24234 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24248);
  V f_ = v_z_245;
  args[0] = v_st_24234;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam14(V self, V *args) {
  V v_x_24231 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_program_24232 = heff_take_field(v_x_24231, 2);
  V v_text_24233 = heff_take_field(v_x_24231, 1);
  V v_st_24234 = heff_get_n(v_x_24231, 0, 3);
  V v_x1_24235 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24232));
  V v_t_24240;
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_Nil: {
    heff_drop(v_text_24233);
    v_t_24240 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24236 = heff_field(v_x1_24235, 0);
    V v_ru_24x1_24235_24Cons = heff_take_reuse_n(v_x1_24235, 1ULL, 2);
    V v_t_24238 = (g_heff_2ebuild_2equery_2esymbols(v_x_24236));
    v_t_24240 = (g_list_2emap_24tok2(v_ru_24x1_24235_24Cons, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam15, 1, 1, (V[]){v_text_24233}), v_t_24238));
    break;
  }
  default: heff_nomatch(v_x1_24235);
  }
  V v_result_24241 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24240});
  V v_t_24242 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str117), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str118)})});
  V v_t_24243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str119), v_result_24241}), NTAG(TAG_Nil)});
  V v_t_24244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str120), v_id_242}), v_t_24243});
  V v_t_24245 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24242, v_t_24244})});
  V v_t_24246 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str121); V a_1 = v_t_24245; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24245, 1); r_; });
  V v_a_24247 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24246, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_24247, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam16, 1, 2, (V[]){v_z_245, v_st_24234})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam20(V self, V *args) {
  V v_x_24281 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24256 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24281);
  V f_ = v_z_245;
  args[0] = v_st_24256;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam19(V self, V *args) {
  V v_x_24273 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_24256 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24274 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str132), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str133)})});
  V v_t_24275 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str134), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24273})});
  V v_t_24276 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24275, NTAG(TAG_Nil)});
  V v_t_24277 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str135), v_id_242}), v_t_24276});
  V v_t_24278 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24274, v_t_24277})});
  V v_t_24279 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str136); V a_1 = v_t_24278; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24278, 1); r_; });
  V v_a_24280 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24279, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_24280, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam20, 1, 2, (V[]){v_z_245, v_st_24256})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam18(V self, V *args) {
  V v_x_24255 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_24256 = heff_take_field(v_x_24255, 0);
  V v_program_24257 = heff_get_n(v_x_24255, 1, 2);
  V v_t_24258 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str123), NTAG(TAG_Nil)});
  HeffT2 v_t_24259 = ({ V a_0 = v_t_24258; V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_24258, 2); r_; });
  V v_t_24270;
  {
    V v_field_24261 = v_t_24259.f[1];
    int64_t v_tag_24260 = ((int64_t)v_t_24259.f[0]);
    V v_t_24269;
    if ((v_tag_24260 == ((int64_t)0ULL))) {
      V v_it1_24262 = v_field_24261;
      switch (heff_tag_of(v_it1_24262)) {
      case TAG_JNull: {
        v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str124);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24262, 0ULL, 1);
        v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str125);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24262, 0ULL, 1);
        v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str126);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24262, 0ULL, 1);
        v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str127);
        break;
      }
      case TAG_JString: {
        V v_s_24266 = heff_field(v_it1_24262, 0);
        heff_take_n(v_it1_24262, 1ULL, 1);
        v_t_24269 = v_s_24266;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24262, 0ULL, 1);
        v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str128);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24262, 0ULL, 1);
        v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str129);
        break;
      }
      default: heff_nomatch(v_it1_24262);
      }
    } else {
      heff_drop(v_field_24261);
      v_t_24269 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str130);
    }
    v_t_24270 = ({ V a_0 = v_t_24269; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str131); V r_ = (g_heff_2elsp_2elsp_2elowerGo(a_0, a_1, a_2)); heff_drop(v_t_24269); r_; });
  }
  V v_t_24271 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24257));
  V v_c_24272 = ({ V a_0 = heff_dup(v_st_24256); V a_1 = v_t_24270; V a_2 = v_t_24271; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1931727223x1253276573(a_0, a_1, a_2)); heff_drop(v_t_24270); heff_drop(v_t_24271); r_; });
  V f_ = v_c_24272;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam19, 1, 4, (V[]){v_id_242, v_z_244, v_z_245, v_st_24256});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam17(V self, V *args) {
  V v_x_24252 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24253 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24252));
  V v_c_24254 = ({ V a_0 = v_st_240; V a_1 = v_t_24253; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1835199903x1655648066(a_0, a_1)); heff_drop(v_t_24253); r_; });
  V f_ = v_c_24254;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam18, 1, 4, (V[]){v_p_243, v_z_244, v_id_242, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam22(V self, V *args) {
  V v_o_24299 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24300 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str143), NTAG(TAG_Nil)});
  HeffT2 v_t_24301 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str144), v_t_24300}); V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_24311;
  {
    V v_field_24303 = v_t_24301.f[1];
    int64_t v_tag_24302 = ((int64_t)v_t_24301.f[0]);
    if ((v_tag_24302 == ((int64_t)0ULL))) {
      V v_it1_24304 = v_field_24303;
      switch (heff_tag_of(v_it1_24304)) {
      case TAG_JNull: {
        v_t_24311 = NTAG(TAG_True);
        break;
      }
      case TAG_JBool: {
        V v_b_24305 = heff_field(v_it1_24304, 0);
        heff_take_n(v_it1_24304, 1ULL, 1);
        v_t_24311 = v_b_24305;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24304, 0ULL, 1);
        v_t_24311 = NTAG(TAG_True);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24304, 0ULL, 1);
        v_t_24311 = NTAG(TAG_True);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_24304, 0ULL, 1);
        v_t_24311 = NTAG(TAG_True);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24304, 0ULL, 1);
        v_t_24311 = NTAG(TAG_True);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24304, 0ULL, 1);
        v_t_24311 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it1_24304);
      }
    } else {
      heff_drop(v_field_24303);
      v_t_24311 = NTAG(TAG_True);
    }
  }
  V v_ret_24bool = heff_bool(((heff_dup(v_t_24311) == NTAG(TAG_True)) || !(heff_dup(heff_rfield(v_o_24299, 3)) == NTAG(TAG_True))));
  heff_drop_rec(v_o_24299, 4);
  heff_drop(v_t_24311);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam24(V self, V *args) {
  V v_x_24316 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_hd_24314 = heff_env(self)[1];
  V v_k_24315 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24317 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str145), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str146)})});
  V v_t_24318 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str147), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24316})});
  V v_t_24319 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24318, NTAG(TAG_Nil)});
  V v_t_24320 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str148), v_id_242}), v_t_24319});
  V v_t_24321 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24317, v_t_24320})});
  V v_t_24322 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str149); V a_1 = v_t_24321; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24321, 1); r_; });
  V v_a_24323 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24322, NTAG(TAG_MkUnit)});
  V v_t_24324 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24323})});
  V v_t_24325 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24324})});
  V v_t_24326 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24325})});
  V v_t_24327 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24326})});
  V v_t_24328 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24327})});
  return (g_co_2eop_24s615738393x1686646143(v_t_24328, v_hd_24314, v_k_24315));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam23(V self, V *args) {
  V v_hd_24314 = args[0];
  V v_k_24315 = args[1];
  V v_c_24313 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24313;
  args[0] = heff_dup(v_hd_24314);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam24, 1, 3, (V[]){v_id_242, v_hd_24314, v_k_24315});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam25(V self, V *args) {
  V v_x_24330 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_24285 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24330);
  V f_ = v_z_245;
  args[0] = v_st_24285;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam21(V self, V *args) {
  V v_x_24283 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_target_24284 = heff_take_field(v_x_24283, 2);
  V v_st_24285 = heff_get_n(v_x_24283, 0, 3);
  V v_c_24329;
  switch (heff_tag_of(v_target_24284)) {
  case TAG_Nothing: {
    heff_drop(v_p_243);
    V v_t_24286 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str138), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str139)})});
    V v_t_24287 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str140), NTAG(TAG_JNull)});
    V v_t_24288 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24287, NTAG(TAG_Nil)});
    V v_t_24289 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str141), v_id_242}), v_t_24288});
    V v_t_24290 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24286, v_t_24289})});
    V v_t_24291 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str142); V a_1 = v_t_24290; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24290, 1); r_; });
    V v_a_24292 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24291, NTAG(TAG_MkUnit)});
    V v_t_24293 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24292})});
    V v_t_24294 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24293})});
    V v_t_24295 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24294})});
    V v_t_24296 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24295})});
    V v_t_24297 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24296})});
    v_c_24329 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_24297}));
    break;
  }
  case TAG_Just: {
    V v_t_24298 = heff_field(v_target_24284, 0);
    heff_take_n(v_target_24284, 1ULL, 1);
    V v_t_24312 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam22, 1, 1, (V[]){v_p_243}), heff_get_n(v_t_24298, 3, 4)));
    V v_c_24313 = (g_heff_2elsp_2elsp_2elocations_24s1133385986x1480831578(heff_dup(v_st_24285), v_t_24312));
    v_c_24329 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam23, 2, 2, (V[]){v_c_24313, v_id_242});
    break;
  }
  default: heff_nomatch(v_target_24284);
  }
  V f_ = v_c_24329;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam25, 1, 2, (V[]){v_z_245, v_st_24285});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam26(V self, V *args) {
  V v_x_24332 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eprepared_24s27289376x753327140(v_id_242, v_x_24332, v_z_244, v_z_245));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam27(V self, V *args) {
  V v_x_24334 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24335 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str152), NTAG(TAG_Nil)});
  HeffT2 v_t_24336 = ({ V a_0 = v_t_24335; V a_1 = v_p_243; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_24335, 2); r_; });
  V v_t_24346;
  {
    V v_field_24338 = v_t_24336.f[1];
    int64_t v_tag_24337 = ((int64_t)v_t_24336.f[0]);
    if ((v_tag_24337 == ((int64_t)0ULL))) {
      V v_it1_24339 = v_field_24338;
      switch (heff_tag_of(v_it1_24339)) {
      case TAG_JNull: {
        v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str153);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24339, 0ULL, 1);
        v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str154);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24339, 0ULL, 1);
        v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str155);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24339, 0ULL, 1);
        v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str156);
        break;
      }
      case TAG_JString: {
        V v_s_24343 = heff_field(v_it1_24339, 0);
        heff_take_n(v_it1_24339, 1ULL, 1);
        v_t_24346 = v_s_24343;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24339, 0ULL, 1);
        v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str157);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24339, 0ULL, 1);
        v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str158);
        break;
      }
      default: heff_nomatch(v_it1_24339);
      }
    } else {
      heff_drop(v_field_24338);
      v_t_24346 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str159);
    }
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s1472741403x327815183(v_id_242, v_t_24346, v_x_24334, v_z_244, v_z_245));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam31(V self, V *args) {
  V v_x_24362 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_x_24349 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24362);
  V f_ = v_z_245;
  args[0] = heff_get_n(v_x_24349, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam30(V self, V *args) {
  V v_x_24353 = args[0];
  V v_x_24351 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_x_24349 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24354 = (g_prelude_2e_2b_2b(v_x_24353, v_x_24351));
  V v_result_24355 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24354});
  V v_t_24356 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str162), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str163)})});
  V v_t_24357 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str164), v_result_24355}), NTAG(TAG_Nil)});
  V v_t_24358 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str165), v_id_242}), v_t_24357});
  V v_t_24359 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24356, v_t_24358})});
  V v_t_24360 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str166); V a_1 = v_t_24359; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24359, 1); r_; });
  V v_a_24361 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24360, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_24361, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam31, 1, 2, (V[]){v_z_245, v_x_24349})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam29(V self, V *args) {
  V v_x_24351 = args[0];
  V v_x_24349 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24352 = (g_heff_2elsp_2elsp_2eclaimFixes_24s362301719x643043220(heff_dup(heff_rfield(v_x_24349, 0)), v_p_243));
  V f_ = v_c_24352;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam30, 1, 5, (V[]){v_x_24351, v_id_242, v_z_244, v_z_245, v_x_24349});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam28(V self, V *args) {
  V v_x_24349 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_24350 = (g_heff_2elsp_2elsp_2ecodeActions_24s1681877887x1278159257(heff_dup(v_x_24349), heff_dup(v_p_243)));
  V f_ = v_c_24350;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam29, 1, 5, (V[]){v_x_24349, v_p_243, v_z_244, v_id_242, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam33(V self, V *args) {
  V v_x_24371 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24371);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam32(V self, V *args) {
  V v_x_24364 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24365 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str168), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str169)})});
  V v_t_24366 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str170), v_x_24364}), NTAG(TAG_Nil)});
  V v_t_24367 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str171), v_id_242}), v_t_24366});
  V v_t_24368 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24365, v_t_24367})});
  V v_t_24369 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_str172); V a_1 = v_t_24368; V r_ = (g_json_2ewriteInto(a_0, a_1)); heff_drop_tag(v_t_24368, 1); r_; });
  V v_a_24370 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24369, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s1554102946x910234624(v_a_24370, v_z_244, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam33, 1, 2, (V[]){v_z_245, v_st_240})));
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam35(V self, V *args) {
  V v_x_24376 = args[0];
  V v_k_24372 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24378;
  switch (heff_tag_of(v_x_24376)) {
  case TAG_Nothing: {
    v_t_24378 = NTAG(TAG_JNull);
    break;
  }
  case TAG_Just: {
    V v_n_24377 = heff_field(v_x_24376, 0);
    V v_ru_24x_24376_24Just = heff_take_reuse_n(v_x_24376, 1ULL, 1);
    v_t_24378 = heff_tag_at_n(v_ru_24x_24376_24Just, TAG_JString, 1, (V[]){v_n_24377});
    break;
  }
  default: heff_nomatch(v_x_24376);
  }
  V f_ = v_k_24372;
  args[0] = v_t_24378;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam34(V self, V *args) {
  V v_x_24373 = args[0];
  V v_k_24372 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24373)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 7);
    heff_drop(v_z_244);
    V f_ = v_k_24372;
    args[0] = NTAG(TAG_JNull);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_24374 = heff_field(v_x_24373, 0);
    heff_take_n(v_x_24373, 1ULL, 1);
    V v_c_24375 = (g_heff_2elsp_2elsp_2eclaimOf_24s1668656539x179457260(v_st_240, v_f_24374));
    V f_ = v_c_24375;
    heff_room[0] = v_z_244;
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam35, 1, 1, (V[]){v_k_24372});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24373);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_lam36(V self, V *args) {
  V v_x_24380 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24380);
  V f_ = v_z_245;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_entry, 7, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1(V v_tok_240, V v_a_241, V v_f_242, V v_off_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_target_247 = heff_take_field(v_t_244, 0);
  V v_name_248 = heff_get_n(v_t_244, 1, 2);
  V v_st_249 = heff_take_field(v_a_241, 0);
  V v_program_2410 = heff_get_n(v_a_241, 2, 3);
  V v_t_2411 = heff_dup(heff_rfield(v_target_247, 2));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_248), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(v_st_249, heff_dup(v_f_242), heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){v_t_2412})));
    return heff_tail(v_c_2413, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_lam0, 1, 6, (V[]){v_name_248, v_program_2410, v_target_247, v_f_242, v_z_246, v_off_243})});
  }
  case TAG_Just: {
    heff_take_n(v_t_2411, 0ULL, 1);
    heff_drop(v_z_245);
    V v_name_2424 = heff_dup(v_name_248);
    V v_occurrences_2425 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2410, heff_dup(v_target_247), v_name_248));
    V v_target_2426 = heff_tag_at_n(v_tok_240, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2424, v_occurrences_2425})});
    return heff_tail(v_z_246, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_249, v_off_243, v_target_2426})});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok1_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_name_248 = heff_env(self)[0];
  V v_program_2410 = heff_env(self)[1];
  V v_target_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_off_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_program_2415 = heff_take_field(v_x_2414, 1);
  V v_st_2416 = heff_get_n(v_x_2414, 0, 2);
  V v_name_2417 = heff_dup(v_name_248);
  V v_t_2420;
  switch (heff_tag_of(v_program_2415)) {
  case TAG_Nil: {
    v_t_2420 = v_program_2410;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_program_2410);
    v_t_2420 = v_program_2415;
    break;
  }
  default: heff_nomatch(v_program_2415);
  }
  V v_occurrences_2421 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2420, heff_dup(v_target_247), v_name_248));
  V v_target_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2417, v_occurrences_2421})});
  V f_ = v_z_246;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2416, v_off_243, v_target_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}