// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_errors 652506774
#define LBL_hashes 722717031
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_st 10440
#define LBL_target 1066236092
#define LBL_text 10052084
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(V, V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558(V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180_clo;
V g_heff_2elsp_2elsp_2espaceEnd(V, V);
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2espaceEnd_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;

static V g_heff_2elsp_2elsp_2ejtrue_val;
static HEFF_ONCE g_heff_2elsp_2elsp_2ejtrue_st;
static V g_heff_2elsp_2elsp_2ejtrue_init(void) {
  return heff_tag_n(TAG_JBool, 1, (V[]){NTAG(TAG_True)});
}
V g_heff_2elsp_2elsp_2ejtrue_get(void) {
  if (HEFF_DONE(g_heff_2elsp_2elsp_2ejtrue_st)) return g_heff_2elsp_2elsp_2ejtrue_val;
  return heff_global(&g_heff_2elsp_2elsp_2ejtrue_val, &g_heff_2elsp_2elsp_2ejtrue_st, g_heff_2elsp_2elsp_2ejtrue_init);
}
Clo g_heff_2elsp_2elsp_2espaceEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2espaceEnd_entry, 2, 0};

V g_heff_2elsp_2elsp_2espaceEnd(V v_l_240, V v_i_241) {
top: ;
  if ((heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_l_240, 0)) && ((heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)32ULL)) || (heff_unbox_word(heff_strByteAt_lent(v_l_240, v_i_241, 0)) == ((int64_t)9ULL))))) {
    V t_0 = v_l_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_l_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2elsp_2elsp_2espaceEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2espaceEnd(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam3, 3, 0};
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_entry, 7, 0};

V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(V v_e_240, V v_st_241, V v_f_242, V v_d_243, V v_cut_244, V v_z_245, V v_z_246) {
top: ;
  V v_docs_247 = heff_take_field(v_st_241, 0);
  V v_lib_248 = heff_get_n(v_st_241, 6, 7);
  V v_c_2433 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(heff_dup(v_e_240), heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam0, 1, 5, (V[]){heff_dup(v_f_242), heff_dup(v_d_243), heff_dup(v_cut_244), v_docs_247, heff_dup(v_e_240)}), v_lib_248, v_f_242));
  return heff_tail(v_c_2433, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam6, 1, 4, (V[]){v_e_240, v_z_245, v_d_243, v_z_246})});
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(a[0], a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a4); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_d_243 = heff_env(self)[0];
  V v_cut_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2410);
  V v_t_2412 = heff_strSlice(heff_get_n(v_d_243, 1, 2), MK_INT(0LL), v_cut_244);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_d_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2416, 1, 2)});
  V f_ = v_k_2418;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    v_t_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2431 = heff_field(v_x_2429, 0);
    V v_ru_24x_2429_24Right = heff_take_reuse_n(v_x_2429, 1ULL, 1);
    v_t_2432 = heff_tag_at_n(v_ru_24x_2429_24Right, TAG_Just, 1, (V[]){v_y_2431});
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V f_ = v_k_2428;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam4(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2426;
  args[0] = v_hd_2427;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam5, 1, 1, (V[]){v_k_2428});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_d_243 = heff_env(self)[1];
  V v_cut_244 = heff_env(self)[2];
  V v_docs_247 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c_lent(v_p_249, v_f_242, 2)) {
    heff_drop(v_p_249);
    heff_drop(v_docs_247);
    heff_drop(v_e_240);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam1, 2, 2, (V[]){v_d_243, v_cut_244});
  } else {
    heff_drop_rec(v_d_243, 2);
    heff_drop(v_cut_244);
    HeffT2 v_t_2413 = ({ V a_0 = v_docs_247; V a_1 = v_p_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_247); r_; });
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        heff_drop(v_p_249);
        heff_drop(v_e_240);
        V v_d_2416 = v_field_2415;
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam2, 2, 1, (V[]){v_d_2416});
      } else {
        heff_drop(v_field_2415);
        V v_path_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_249));
        V v_c_2421 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2420; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2420); r_; });
        V v_t_2422 = (g_exception_2eattempted(v_e_240));
        V v_c_2426 = heff_tr(heff_call(v_c_2421, 2, (V[]){v_t_2422, ((V)&g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam3_clo)}));
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam4, 2, 1, (V[]){v_c_2426});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam8(V self, V *args) {
  V v_x_2445 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_243, 1, 2); V a_1 = v_x_2445; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_errors_2437 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2441 = heff_get_n(v_x_2440, 0, 2);
  V v_program_2442 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2441)));
  V v_t_2443 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2441));
  V v_t_2444 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_243, 1)), v_t_2443, v_errors_2437));
  V v_diags_2446 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam8, 1, 1, (V[]){v_d_243}), v_t_2444));
  V f_ = v_z_246;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2442, v_diags_2446});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam6(V self, V *args) {
  V v_x_2434 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_paths_2435 = heff_take_field(v_x_2434, 2);
  V v_sources_2436 = heff_take_field(v_x_2434, 0);
  V v_errors_2437 = heff_get_n(v_x_2434, 1, 5);
  V v_t_2438 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2eordmap_2eempty_get())});
  V v_c_2439 = (g_heff_2ebuild_2esession_2ecachedGo_24s577613724x837579788(v_e_240, v_paths_2435, v_sources_2436, v_t_2438));
  V f_ = v_c_2439;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_lam7, 1, 3, (V[]){v_d_243, v_errors_2437, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_entry, 7, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310(V v_e_240, V v_a_241, V v_f_242, V v_off_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_target_247 = heff_take_field(v_t_244, 0);
  V v_name_248 = heff_get_n(v_t_244, 1, 2);
  V v_st_249 = heff_take_field(v_a_241, 0);
  V v_program_2410 = heff_get_n(v_a_241, 2, 3);
  V v_t_2411 = heff_dup(heff_rfield(v_target_247, 2));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_248), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2elsp_2elsp_2eprojectFor_24s79272836x1052277180(v_e_240, v_st_249, heff_dup(v_f_242), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412})));
    return heff_tail(v_c_2413, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_lam0, 1, 6, (V[]){v_name_248, v_program_2410, v_target_247, v_f_242, v_z_246, v_off_243})});
  }
  case TAG_Just: {
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_z_245);
    V v_name_2424 = heff_dup(v_name_248);
    V v_occurrences_2425 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2410, heff_dup(v_target_247), v_name_248));
    V v_target_2426 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2424, v_occurrences_2425})});
    return heff_tail(v_z_246, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_249, v_off_243, v_target_2426})});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s98778439x949076310_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_name_248 = heff_env(self)[0];
  V v_program_2410 = heff_env(self)[1];
  V v_target_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_off_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_program_2415 = heff_take_field(v_x_2414, 1);
  V v_st_2416 = heff_get_n(v_x_2414, 0, 2);
  V v_name_2417 = heff_dup(v_name_248);
  V v_t_2420;
  switch (heff_tag_of(v_program_2415)) {
  case TAG_Nil: {
    v_t_2420 = v_program_2410;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_program_2410);
    v_t_2420 = v_program_2415;
    break;
  }
  default: heff_nomatch(v_program_2415);
  }
  V v_occurrences_2421 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2420, heff_dup(v_target_247), v_name_248));
  V v_target_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2417, v_occurrences_2421})});
  V f_ = v_z_246;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2416, v_off_243, v_target_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_entry, 3, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558(V v_e_240, V v_a_241, V v_p_242) {
top: ;
  V v_program_243 = heff_take_field(v_a_241, 2);
  V v_text_244 = heff_take_field(v_a_241, 1);
  V v_st_245 = heff_get_n(v_a_241, 0, 3);
  V v_c_246 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_lam0, 2, 6, (V[]){v_c_246, v_program_243, v_p_242, v_text_244, v_e_240, v_st_245});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_st_245 = heff_env(self)[5];
  V v_hd_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_program_243);
    heff_drop(v_p_242);
    heff_drop(v_text_244);
    heff_drop(v_e_240);
    heff_drop(v_st_245);
    heff_drop(v_hd_247);
    V f_ = v_k_248;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_243)));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nil: {
      heff_drop(v_program_243);
      heff_drop(v_p_242);
      heff_drop(v_text_244);
      heff_drop(v_e_240);
      heff_drop(v_st_245);
      heff_drop(v_hd_247);
      heff_drop(v_f_2410);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Cons = heff_take_reuse_n(v_x1_2411, 1ULL, 2);
      V v_t_2414 = heff_tag_at_n(v_ru_24x1_2411_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str0), NTAG(TAG_Nil)});
      HeffT2 v_t_2415 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str1), v_t_2414}); V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2425;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_it1_2418 = v_field_2417;
          switch (heff_tag_of(v_it1_2418)) {
          case TAG_JNull: {
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JArray: {
            V v_xs_2423 = heff_field(v_it1_2418, 0);
            heff_take_n(v_it1_2418, 1ULL, 1);
            v_t_2425 = ({ V a_0 = v_xs_2423; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2423); r_; });
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it1_2418);
          }
        } else {
          heff_drop(v_field_2417);
          v_t_2425 = NTAG(TAG_True);
        }
      }
      if (((heff_dup(v_t_2425) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 3)), heff_dup(v_text_244)))) {
        heff_drop(v_t_2425);
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str2), NTAG(TAG_Nil)});
        HeffT2 v_t_2427 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str3), v_t_2426}); V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2437;
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_it1_2430 = v_field_2429;
            switch (heff_tag_of(v_it1_2430)) {
            case TAG_JNull: {
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str4);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str5);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str6);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str7);
              break;
            }
            case TAG_JString: {
              V v_s_2434 = heff_field(v_it1_2430, 0);
              heff_take_n(v_it1_2430, 1ULL, 1);
              v_t_2437 = v_s_2434;
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str8);
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str9);
              break;
            }
            default: heff_nomatch(v_it1_2430);
            }
          } else {
            heff_drop(v_field_2429);
            v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str10);
          }
        }
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str11), NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str13), v_t_2438})});
        HeffT2 v_t_2440 = ({ V a_0 = v_t_2439; V a_1 = heff_dup(v_p_242); HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2439, 2); r_; });
        V v_t_2464;
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str14), NTAG(TAG_Nil)});
          V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_str16), v_t_2443})});
          HeffT2 v_t_2445 = ({ V a_0 = v_t_2444; V a_1 = v_p_242; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_2444, 2); r_; });
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            V v_t_2455;
            if ((v_tag_2441 == ((int64_t)0ULL))) {
              V v_it1_2448 = v_field_2442;
              switch (heff_tag_of(v_it1_2448)) {
              case TAG_JNull: {
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JInt: {
                V v_i_2450 = heff_field(v_it1_2448, 0);
                heff_take_n(v_it1_2448, 1ULL, 1);
                v_t_2455 = v_i_2450;
                break;
              }
              case TAG_JFloat: {
                double v_x_2451 = heff_tflat_f64(v_it1_2448, 0);
                heff_take_na(v_it1_2448, 0ULL, 1);
                v_t_2455 = heff_floor_f64(v_x_2451);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              default: heff_nomatch(v_it1_2448);
              }
            } else {
              heff_drop(v_field_2442);
              v_t_2455 = MK_INT(0LL);
            }
            V v_t_2463;
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              V v_it1_2456 = v_field_2447;
              switch (heff_tag_of(v_it1_2456)) {
              case TAG_JNull: {
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JInt: {
                V v_i_2458 = heff_field(v_it1_2456, 0);
                heff_take_n(v_it1_2456, 1ULL, 1);
                v_t_2463 = v_i_2458;
                break;
              }
              case TAG_JFloat: {
                double v_x_2459 = heff_tflat_f64(v_it1_2456, 0);
                heff_take_na(v_it1_2456, 0ULL, 1);
                v_t_2463 = heff_floor_f64(v_x_2459);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              default: heff_nomatch(v_it1_2456);
              }
            } else {
              heff_drop(v_field_2447);
              v_t_2463 = MK_INT(0LL);
            }
            v_t_2464 = ({ V a_0 = v_text_244; V a_1 = v_t_2455; V a_2 = v_t_2463; V a_3 = MK_INT(0LL); V a_4 = MK_INT(0LL); V r_ = (g_heff_2elsp_2elsp_2eoffsetGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_244); r_; });
          }
        }
        return (g_heff_2elsp_2elsp_2esplitIn_24s1616987243x2130503862(v_e_240, v_st_245, v_f_2410, v_t_2437, v_program_243, v_x_2412, v_t_2464, v_hd_247, v_k_248));
      } else {
        heff_drop(v_program_243);
        heff_drop(v_p_242);
        heff_drop(v_text_244);
        heff_drop(v_e_240);
        heff_drop(v_st_245);
        heff_drop(v_hd_247);
        heff_drop(v_f_2410);
        heff_drop_rec(v_x_2412, 14);
        heff_drop(v_t_2425);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_st_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_lam1, 1, 7, (V[]){v_k_248, v_program_243, v_p_242, v_text_244, v_e_240, v_st_245, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}