// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EProj 35044
#define TAG_EStr 50587
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HLocal 25864
#define TAG_I32 19220
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkArm 55352
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define TAG_VFixed 12623
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define LBL_aliases 1464806715
#define LBL_body 9524841
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_supply 1056026650
#define LBL_syntax 1059664654
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_vars 10107635
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2eargTysOf(V, V);
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eargTysOf_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V, V, V);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo;
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo;
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo;
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V, V);
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo;
V g_heff_2ecompile_2eerase_2eeraseOne(V, V, V);
V g_heff_2ecompile_2eerase_2eeraseOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseOne_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2eerase_2efieldTyOr(V, V, V, V);
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo;
HeffT2 g_heff_2ecompile_2eerase_2efieldTyOr_24cpr(V, V, V, V);
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eerase_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ekeptOf_clo;
V g_heff_2ecompile_2eerase_2ematchVariants(V);
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ematchVariants_clo;
HeffT2 g_heff_2ecompile_2eerase_2enthLocal_24cpr(V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2eprojWith(V, V, V);
V g_heff_2ecompile_2eerase_2eprojWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojWith_clo;
V g_heff_2ecompile_2eerase_2eshapeWith(V, V, V);
V g_heff_2ecompile_2eerase_2eshapeWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eshapeWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
Clo g_heff_2ecompile_2eerase_2eprojWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojWith_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eprojWith(V v_x1_240, V v_v_241, V v_l_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2evalue_2eproj(v_v_241, v_l_242));
  }
  case TAG_Just: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    heff_drop(v_v_241);
    HeffT2 v_t_244 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_fs_243, 1), v_l_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_i_248 = v_field_246;
        V v_xs_249 = heff_dup(heff_rfield(v_fs_243, 2));
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_248, 1)) {
          if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength_lent(v_xs_249, 0))) {
            V v_v_2412 = heff_arrayIndex(v_xs_249, v_i_248);
            return v_v_2412;
          } else {
            heff_drop(v_i_248);
            heff_drop(v_xs_249);
            return heff_abandon();
          }
        } else {
          heff_drop(v_i_248);
          heff_drop(v_xs_249);
          return heff_abandon();
        }
      } else {
        heff_drop(v_field_246);
        return heff_abandon();
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2eprojWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2eprojWith(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2eerase_2efieldTyOr_24cpr(V v_len_240, V v_t_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_x3_244 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_LikeU: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeFunction: {
      heff_take_n(v_x3_244, 0ULL, 4);
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeRecord: {
      V v_capture_2411 = heff_field(v_x3_244, 1);
      V v_fieldTypes_2412 = heff_field(v_x3_244, 2);
      heff_take_n(v_x3_244, 6ULL, 3);
      HeffT2 v_t_2413 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_fieldTypes_2412, 1), v_k_242));
      V v_t_2418;
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          V v_i_2417 = v_field_2415;
          v_t_2418 = v_i_2417;
        } else {
          heff_drop(v_field_2415);
          v_t_2418 = heff_abandon();
        }
      }
      return (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_len_240, v_capture_2411, v_fieldTypes_2412, v_t_2418, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
    }
    case TAG_LikeSum: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeRune: {
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeArray: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_LikeFixed: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x3_244)}});
    }
  }
  case TAG_Just: {
    V v_ty_2422 = heff_field(v_x4_243, 0);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_ty_2422)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ecompile_2eerase_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ekeptOf_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ekeptOf(V v_len_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_len_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x31_243, 0);
      V v_x312_246 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_246)) {
      case TAG_Nothing: {
        heff_drop(v_len_240);
        heff_drop(v_acc_241);
        heff_drop(v_rest_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_245);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_ty_247 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 1);
        V v_t_248 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(v_len_240), v_ty_247));
        V v_t_249;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_k_245);
          heff_drop(v_t_248);
          v_t_249 = v_acc_241;
        } else {
          heff_drop(v_t_248);
          v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_k_245, v_acc_241});
        }
        V t_0 = v_len_240;
        V t_1 = v_t_249;
        V t_2 = v_rest_244;
        v_len_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eerase_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ekeptOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eshapeWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eshapeWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eshapeWith_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eshapeWith(V v_len_240, V v_t_241, V v_fs_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_241)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_LikeU: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_x1_243, 0ULL, 4);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2411 = heff_field(v_x1_243, 2);
    heff_take_n(v_x1_243, 4ULL, 3);
    v_t_2415 = heff_arrayToList(heff_get_n(v_fieldTypes_2411, 0, 3));
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeInt: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeString: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeRune: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_NoRules: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eerase_2eshapeWith_lam0, 1, 3, (V[]){v_t_241, heff_dup(v_fs_242), heff_dup(v_len_240)}), v_t_2415));
  HEFF_LAST return g_heff_2ecompile_2eerase_2ekeptOf(v_len_240, NTAG(TAG_Nil), v_t_2419);
}
V g_heff_2ecompile_2eerase_2eshapeWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2eshapeWith(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eerase_2eshapeWith_lam0(V self, V *args) {
  V v_k_2416 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_fs_242 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = ({ V a_0 = heff_dup(v_t_241); V a_1 = v_fs_242; V a_2 = v_k_2416; V r_ = (g_heff_2eelab_2evalue_2eprojTyWith(a_0, a_1, a_2)); heff_drop(v_fs_242); r_; });
  V v_t_2418 = ({ V a_0 = v_len_240; V a_1 = v_t_241; V a_2 = v_k_2416; V a_3 = v_t_2417; V r_ = (g_heff_2ecompile_2eerase_2efieldTyOr(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2416, v_t_2418});
}
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str0, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str1, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str2, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str3, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str4, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str5, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str6, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str7, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str8, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str9, 47, "matching on something that is not of a sum type");
V g_heff_2ecompile_2eerase_2ematchVariants_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2ematchVariants_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam10, 1, 0};
Clo g_heff_2ecompile_2eerase_2ematchVariants_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_entry, 1, 0};

V g_heff_2ecompile_2eerase_2ematchVariants(V v_sty_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2evalue_2ebehavior(v_sty_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_LikeU: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_241, 0ULL, 4);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam1_clo);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_241, 0ULL, 3);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam2_clo);
  }
  case TAG_LikeSum: {
    V v_vs_2413 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2eerase_2ematchVariants_lam3, 1, 1, (V[]){v_vs_2413});
  }
  case TAG_LikeInt: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam4_clo);
  }
  case TAG_LikeFloat: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam5_clo);
  }
  case TAG_LikeString: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam6_clo);
  }
  case TAG_LikeRune: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam7_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam8_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam9_clo);
  }
  case TAG_NoRules: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam10_clo);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ematchVariants(a[0]);
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str0)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam1(V self, V *args) {
  V v_n_248 = args[0];
  heff_drop(v_n_248);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str1)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str2)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_vs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_vs_2413, v_n_2414})});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam4(V self, V *args) {
  V v_n_2415 = args[0];
  heff_drop(v_n_2415);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str3)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam5(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str4)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam6(V self, V *args) {
  V v_n_2417 = args[0];
  heff_drop(v_n_2417);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str5)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam7(V self, V *args) {
  V v_n_2418 = args[0];
  heff_drop(v_n_2418);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str6)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam8(V self, V *args) {
  V v_n_2420 = args[0];
  heff_drop(v_n_2420);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str7)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam9(V self, V *args) {
  V v_n_2422 = args[0];
  heff_drop(v_n_2422);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str8)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam10(V self, V *args) {
  V v_n_2423 = args[0];
  heff_drop(v_n_2423);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str9)});
}

HeffT2 g_heff_2ecompile_2eerase_2enthLocal_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_rest_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_l_242}});
    } else {
      heff_drop(v_l_242);
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_entry, 1, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ecatMaybesE(a[0]);
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry, 4, 0};

V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V v_c_240, V v_vs_241, V v_ty_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_tag_244 = heff_field(v_x5_243, 0);
    V v_x52_245 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    switch (heff_tag_of(v_x52_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_x52_245, 0);
      V v_body_247 = heff_field(v_x52_245, 1);
      heff_take_n(v_x52_245, 3ULL, 2);
      V v_t_248 = heff_rec_n(2, shape_c__vars, (V[]){v_c_240, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2ecompile_2eerase_2eargTysOf(v_vs_241, v_tag_244));
      V v_t_2410 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_xs_246), v_t_249));
      V v_m_2411 = (g_heff_2ecompile_2eerase_2earmBindGo(v_t_248, v_t_2410));
      return heff_clo_n(g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0, 1, 4, (V[]){v_m_2411, v_body_247, v_ty_242, v_tag_244});
    }
    default: return heff_nomatch(v_x52_245);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_body_247 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_tag_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Left: {
    V v_e_2414 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Left = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    heff_drop(v_body_247);
    heff_drop(v_ty_242);
    heff_drop(v_tag_244);
    return heff_tag_at_n(v_ru_24x2_2413_24Left, TAG_Left, 1, (V[]){v_e_2414});
  }
  case TAG_Right: {
    V v_x21_2415 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Right = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x21_2415, 0);
      V v_n_2417 = heff_field(v_x21_2415, 1);
      heff_take_n(v_x21_2415, 3ULL, 2);
      V v_m_2418 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_take_field(v_x_2416, 0), v_body_247, v_ty_242));
      V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_n_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Left: {
        V v_e_2420 = heff_field(v_x2_2419, 0);
        V v_ru_24x2_2419_24Left = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
        heff_drop(v_tag_244);
        heff_drop_cell(v_ru_24x2_2413_24Right, 1);
        heff_drop_rec(v_x_2416, 2);
        return heff_tag_at_n(v_ru_24x2_2419_24Left, TAG_Left, 1, (V[]){v_e_2420});
      }
      case TAG_Right: {
        V v_x21_2421 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        switch (heff_tag_of(v_x21_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x21_2421, 0);
          V v_n_2423 = heff_field(v_x21_2421, 1);
          heff_take_n(v_x21_2421, 3ULL, 2);
          V v_t_2424 = heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_244, heff_get_n(v_x_2416, 1, 2), v_x_2422});
          return heff_tag_at_n(v_ru_24x2_2413_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_n_2423})});
        }
        default: return heff_nomatch(v_x21_2421);
        }
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str0, 22, "a type used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str1, 16, "an unbound local");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str2, 9, "the type ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str3, 16, " used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str4, 9, "the type ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str5, 16, " used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str6, 10, "no global ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str7, 10, "no global ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str8, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str9, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str10, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str11, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str12, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str13, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str14, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str15, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str16, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str17, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str18, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str19, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str20, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str21, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str22, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str23, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str24, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str25, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str26, 13, "prelude.Bytes");
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam31(V self, V *args);
Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry, 2, 0};

V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V v_c_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_heff_2ecompile_2eerase_2enthLocal_24cpr(heff_get_n(v_c_240, 0, 4), v_i_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_l_247 = v_field_245;
        V v_t_248 = heff_dup(heff_rfield(v_l_247, 0));
        switch (heff_tag_of(v_t_248)) {
        case TAG_Nothing: {
          heff_drop_rec(v_l_247, 2);
          return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0_clo);
        }
        case TAG_Just: {
          V v_x_2410 = heff_field(v_t_248, 0);
          heff_take_n(v_t_248, 1ULL, 1);
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1, 1, 2, (V[]){v_x_2410, v_l_247});
        }
        default: return heff_nomatch(v_t_248);
        }
      } else {
        heff_drop(v_field_245);
        return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2_clo);
      }
    }
  }
  case TAG_SGlobal: {
    V v_x_2414 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_g_2415 = heff_get_n(v_c_240, 3, 4);
    HeffT2 v_t_2416 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_2415, 1), v_x_2414));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop_rec(v_g_2415, 7);
        V v_e_2420 = v_field_2418;
        V v_t_2421 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2420, 3))));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop_rec(v_e_2420, 4);
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3, 1, 1, (V[]){v_x_2414});
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4, 1, 2, (V[]){v_x_2414, v_e_2420});
        }
      } else {
        heff_drop(v_field_2418);
        HeffT2 v_t_2426 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_2415, 2), v_x_2414));
        {
          V v_field_2428 = v_t_2426.f[1];
          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
          if ((v_tag_2427 == ((int64_t)0ULL))) {
            V v_k2_2430 = v_field_2428;
            HeffT2 v_t_2431 = ({ V b_0 = heff_get_n(v_g_2415, 1, 7); V a_1 = v_k2_2430; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2430); r_; });
            {
              V v_field_2433 = v_t_2431.f[1];
              int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
              if ((v_tag_2432 == ((int64_t)0ULL))) {
                V v_e_2435 = v_field_2433;
                V v_t_2436 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2435, 3))));
                if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
                  heff_drop_rec(v_e_2435, 4);
                  heff_drop(v_t_2436);
                  return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5, 1, 1, (V[]){v_x_2414});
                } else {
                  heff_drop(v_t_2436);
                  return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6, 1, 2, (V[]){v_x_2414, v_e_2435});
                }
              } else {
                heff_drop(v_field_2433);
                return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7, 1, 1, (V[]){v_x_2414});
              }
            }
          } else {
            heff_drop_rec(v_g_2415, 7);
            heff_drop(v_field_2428);
            return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8, 1, 1, (V[]){v_x_2414});
          }
        }
      }
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9_clo);
  }
  case TAG_SApp: {
    V v_f_2445 = heff_field(v_t_241, 0);
    V v_a_2446 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_2447 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_f_2445));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10, 1, 3, (V[]){v_m_2447, v_c_240, v_a_2446});
  }
  case TAG_SLam: {
    V v_ty_24106 = heff_field(v_t_241, 0);
    V v_abs_24107 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SLam = heff_take_reuse_n(v_t_241, 3ULL, 2);
    HeffT2 v_t_24108 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_ty_24106), heff_dup(heff_rfield(v_c_240, 1))));
    {
      V v_field_24110 = v_t_24108.f[1];
      int64_t v_tag_24109 = ((int64_t)v_t_24108.f[0]);
      V v_ty_24116;
      if ((v_tag_24109 == ((int64_t)0ULL))) {
        V v_x_24112 = v_field_24110;
        v_ty_24116 = v_x_24112;
      } else {
        if ((v_tag_24109 == ((int64_t)1ULL))) {
          V v_x11_24114 = v_field_24110;
          heff_drop(v_x11_24114);
          v_ty_24116 = heff_abandon();
        } else {
          V v_x_24115 = v_field_24110;
          v_ty_24116 = v_x_24115;
        }
      }
      V v_m_24117 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_tag_at_n(v_ru_24t_241_24SLam, TAG_SLam, 2, (V[]){heff_dup(v_ty_24106), v_abs_24107}), v_ty_24116));
      return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13, 1, 3, (V[]){v_m_24117, v_c_240, v_ty_24106});
    }
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14_clo);
  }
  case TAG_SProj: {
    V v_e_24136 = heff_field(v_t_241, 0);
    V v_l_24137 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24138 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), heff_dup(v_e_24136)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15, 1, 4, (V[]){v_m_24138, v_c_240, v_e_24136, v_l_24137});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16_clo);
  }
  case TAG_SMatch: {
    V v_scrut_24183 = heff_field(v_t_241, 0);
    V v_cases_24184 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24185 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_scrut_24183));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17, 1, 3, (V[]){v_m_24185, v_cases_24184, v_c_240});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19_clo);
  }
  case TAG_SIs: {
    V v_t2_24224 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24224;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20_clo);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21_clo);
  }
  case TAG_SRec: {
    V v_t2_24227 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24227;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_ty_24228 = heff_field(v_t_241, 0);
    V v_abs_24229 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SFix = heff_take_reuse_n(v_t_241, 3ULL, 2);
    HeffT2 v_t_24230 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_ty_24228), heff_dup(heff_rfield(v_c_240, 1))));
    {
      V v_field_24232 = v_t_24230.f[1];
      int64_t v_tag_24231 = ((int64_t)v_t_24230.f[0]);
      V v_ty_24238;
      if ((v_tag_24231 == ((int64_t)0ULL))) {
        V v_x_24234 = v_field_24232;
        v_ty_24238 = v_x_24234;
      } else {
        if ((v_tag_24231 == ((int64_t)1ULL))) {
          V v_x11_24236 = v_field_24232;
          heff_drop(v_x11_24236);
          v_ty_24238 = heff_abandon();
        } else {
          V v_x_24237 = v_field_24232;
          v_ty_24238 = v_x_24237;
        }
      }
      V v_m_24239 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_tag_at_n(v_ru_24t_241_24SFix, TAG_SFix, 2, (V[]){heff_dup(v_ty_24228), v_abs_24229}), v_ty_24238));
      return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22, 1, 3, (V[]){v_m_24239, v_c_240, v_ty_24228});
    }
  }
  case TAG_SImplicit: {
    V v_t2_24257 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t2_24257;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23_clo);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24_clo);
  }
  case TAG_SLitInt: {
    V v_i_24264 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25, 1, 1, (V[]){v_i_24264});
  }
  case TAG_SLitFloat: {
    V v_x_24267 = heff_tget_v(v_t_241, 0);
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26, 1, 1, (V[]){v_x_24267});
  }
  case TAG_SLitString: {
    V v_s_24270 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27, 1, 1, (V[]){v_s_24270});
  }
  case TAG_SLitBytes: {
    V v_s_24273 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24SLitBytes = heff_take_reuse_n(v_t_241, 1ULL, 1);
    V v_t_24274 = heff_tag_at_n(v_ru_24t_241_24SLitBytes, TAG_SDecode, 1, (V[]){heff_tag_n(TAG_SGlobal, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str26)})});
    HeffT2 v_t_24275 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_t_24274, heff_get_n(v_c_240, 1, 4)));
    V v_t_24283;
    {
      V v_field_24277 = v_t_24275.f[1];
      int64_t v_tag_24276 = ((int64_t)v_t_24275.f[0]);
      if ((v_tag_24276 == ((int64_t)0ULL))) {
        V v_x_24279 = v_field_24277;
        v_t_24283 = v_x_24279;
      } else {
        if ((v_tag_24276 == ((int64_t)1ULL))) {
          V v_x11_24281 = v_field_24277;
          heff_drop(v_x11_24281);
          v_t_24283 = heff_abandon();
        } else {
          V v_x_24282 = v_field_24277;
          v_t_24283 = v_x_24282;
        }
      }
    }
    V v_x_24284 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBytes, 1, (V[]){v_s_24273}), v_t_24283});
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28, 1, 1, (V[]){v_x_24284});
  }
  case TAG_SLitRune: {
    V v_n_24286 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29, 1, 1, (V[]){v_n_24286});
  }
  case TAG_SLitFixed: {
    V v_w_24290 = heff_field(v_t_241, 0);
    V v_n_24291 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30, 1, 2, (V[]){v_w_24290, v_n_24291});
  }
  case TAG_SLitFloat32: {
    V v_x_24294 = heff_tget_v(v_t_241, 0);
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam31, 1, 1, (V[]){v_x_24294});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0(V self, V *args) {
  V v_n_249 = args[0];
  heff_drop(v_n_249);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str0)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_l_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, heff_get_n(v_l_247, 1, 2)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_n_2411})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  heff_drop(v_n_2413);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str1)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3(V self, V *args) {
  V v_n_2422 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2422);
  V v_t_2423 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str2), heff_strAppend(v_x_2414, ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str3)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2423});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2414}), heff_get_n(v_e_2420, 3, 4)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2425, v_n_2424})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5(V self, V *args) {
  V v_n_2437 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2437);
  V v_t_2438 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str4), heff_strAppend(v_x_2414, ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str5)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2438});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6(V self, V *args) {
  V v_n_2439 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2414}), heff_get_n(v_e_2435, 3, 4)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_n_2439})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7(V self, V *args) {
  V v_n_2441 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2441);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str6), v_x_2414)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8(V self, V *args) {
  V v_n_2442 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2442);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str7), v_x_2414)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9(V self, V *args) {
  V v_n_2444 = args[0];
  heff_drop(v_n_2444);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str8)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11(V self, V *args) {
  V v_u_2466 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2466);
  V v_x1_2467 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_take_field(v_c_240, 3), NTAG(TAG_N), v_a_2446, heff_get_n(v_c_240, 1, 4)));
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_Nom: {
    V v_x_2468 = heff_field(v_x1_2467, 0);
    heff_take_n(v_x1_2467, 1ULL, 1);
    return v_x_2468;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2467, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2470 = heff_field(v_x1_2467, 0);
    heff_take_n(v_x1_2467, 1ULL, 1);
    return v_x_2470;
  }
  default: return heff_nomatch(v_x1_2467);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12(V self, V *args) {
  V v_u_2488 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2446 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2488);
  V v_x1_2489 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_take_field(v_c_240, 3), NTAG(TAG_N), v_a_2446, heff_get_n(v_c_240, 1, 4)));
  switch (heff_tag_of(v_x1_2489)) {
  case TAG_Nom: {
    V v_x_2490 = heff_field(v_x1_2489, 0);
    heff_take_n(v_x1_2489, 1ULL, 1);
    return v_x_2490;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2489, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2492 = heff_field(v_x1_2489, 0);
    heff_take_n(v_x1_2489, 1ULL, 1);
    return v_x_2492;
  }
  default: return heff_nomatch(v_x1_2489);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_a_2446 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_Left: {
    V v_e_2450 = heff_field(v_x2_2449, 0);
    V v_ru_24x2_2449_24Left = heff_take_reuse_n(v_x2_2449, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_a_2446);
    return heff_tag_at_n(v_ru_24x2_2449_24Left, TAG_Left, 1, (V[]){v_e_2450});
  }
  case TAG_Right: {
    V v_x21_2451 = heff_field(v_x2_2449, 0);
    V v_ru_24x2_2449_24Right = heff_take_reuse_n(v_x2_2449, 1ULL, 1);
    switch (heff_tag_of(v_x21_2451)) {
    case TAG_MkPair: {
      V v_x_2452 = heff_field(v_x21_2451, 0);
      V v_n_2453 = heff_field(v_x21_2451, 1);
      V v_ru_24x21_2451_24MkPair = heff_take_reuse_n(v_x21_2451, 3ULL, 2);
      switch (heff_tag_of(v_x_2452)) {
      case TAG_MkPair: {
        V v_f_27_2454 = heff_field(v_x_2452, 0);
        V v_fty_2455 = heff_field(v_x_2452, 1);
        V v_ru_24x_2452_24MkPair = heff_take_reuse_n(v_x_2452, 3ULL, 2);
        V v_t_2456 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2455));
        switch (heff_tag_of(v_t_2456)) {
        case TAG_LikeU: {
          V v_ru_24t_2456_24LikeU = heff_take_reuse_n(v_t_2456, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2456_24LikeU, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str9)});
        }
        case TAG_LikeFunction: {
          V v_dom_2459 = heff_field(v_t_2456, 1);
          V v_cod_2460 = heff_field(v_t_2456, 2);
          heff_take_n(v_t_2456, 6ULL, 4);
          V v_t_2462 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_2459)));
          if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
            heff_drop(v_dom_2459);
            heff_drop(v_t_2462);
            V v_x1_2472;
            switch (heff_tag_of(v_cod_2460)) {
            case TAG_MkClo: {
              V v_vs_2464 = heff_field(v_cod_2460, 1);
              V v_body_2465 = heff_field(v_cod_2460, 2);
              heff_take_n(v_cod_2460, 6ULL, 3);
              v_x1_2472 = heff_tr(heff_call(v_body_2465, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2464, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11, 1, 2, (V[]){v_c_240, v_a_2446})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2471 = heff_field(v_cod_2460, 0);
              heff_take_n(v_cod_2460, 1ULL, 1);
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_a_2446);
              v_x1_2472 = v_body_2471;
              break;
            }
            default: heff_nomatch(v_cod_2460);
            }
            V v_t_2476;
            switch (heff_tag_of(v_x1_2472)) {
            case TAG_Nom: {
              V v_x_2473 = heff_field(v_x1_2472, 0);
              heff_take_n(v_x1_2472, 1ULL, 1);
              v_t_2476 = v_x_2473;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2472, 0ULL, 1);
              v_t_2476 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2475 = heff_field(v_x1_2472, 0);
              heff_take_n(v_x1_2472, 1ULL, 1);
              v_t_2476 = v_x_2475;
              break;
            }
            default: heff_nomatch(v_x1_2472);
            }
            V v_x_2477 = heff_tag_at_n(v_ru_24x21_2451_24MkPair, TAG_MkPair, 2, (V[]){v_f_27_2454, v_t_2476});
            return heff_tag_at_n(v_ru_24x2_2449_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2477, v_n_2453})});
          } else {
            heff_drop(v_t_2462);
            V v_m_2478 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_a_2446), v_dom_2459));
            V v_x2_2479 = heff_tr(heff_call(v_m_2478, 1, (V[]){v_n_2453}));
            switch (heff_tag_of(v_x2_2479)) {
            case TAG_Left: {
              V v_e_2480 = heff_field(v_x2_2479, 0);
              V v_ru_24x2_2479_24Left = heff_take_reuse_n(v_x2_2479, 1ULL, 1);
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_a_2446);
              heff_drop_cell(v_ru_24x2_2449_24Right, 1);
              heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
              heff_drop(v_f_27_2454);
              heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
              heff_drop(v_cod_2460);
              return heff_tag_at_n(v_ru_24x2_2479_24Left, TAG_Left, 1, (V[]){v_e_2480});
            }
            case TAG_Right: {
              V v_x21_2481 = heff_field(v_x2_2479, 0);
              heff_take_n(v_x2_2479, 1ULL, 1);
              switch (heff_tag_of(v_x21_2481)) {
              case TAG_MkPair: {
                V v_x_2482 = heff_field(v_x21_2481, 0);
                V v_n_2483 = heff_field(v_x21_2481, 1);
                heff_take_n(v_x21_2481, 3ULL, 2);
                V v_t_2484 = heff_tag_at_n(v_ru_24x_2452_24MkPair, TAG_Cons, 2, (V[]){v_x_2482, NTAG(TAG_Nil)});
                V v_x1_2494;
                switch (heff_tag_of(v_cod_2460)) {
                case TAG_MkClo: {
                  V v_vs_2486 = heff_field(v_cod_2460, 1);
                  V v_body_2487 = heff_field(v_cod_2460, 2);
                  heff_take_n(v_cod_2460, 6ULL, 3);
                  v_x1_2494 = heff_tr(heff_call(v_body_2487, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2486, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12, 1, 2, (V[]){v_c_240, v_a_2446})})}));
                  break;
                }
                case TAG_CloConst: {
                  V v_body_2493 = heff_field(v_cod_2460, 0);
                  heff_take_n(v_cod_2460, 1ULL, 1);
                  heff_drop_rec(v_c_240, 4);
                  heff_drop(v_a_2446);
                  v_x1_2494 = v_body_2493;
                  break;
                }
                default: heff_nomatch(v_cod_2460);
                }
                V v_t_2498;
                switch (heff_tag_of(v_x1_2494)) {
                case TAG_Nom: {
                  V v_x_2495 = heff_field(v_x1_2494, 0);
                  heff_take_n(v_x1_2494, 1ULL, 1);
                  v_t_2498 = v_x_2495;
                  break;
                }
                case TAG_Describe: {
                  heff_take_n(v_x1_2494, 0ULL, 1);
                  v_t_2498 = heff_abandon();
                  break;
                }
                case TAG_Become: {
                  V v_x_2497 = heff_field(v_x1_2494, 0);
                  heff_take_n(v_x1_2494, 1ULL, 1);
                  v_t_2498 = v_x_2497;
                  break;
                }
                default: heff_nomatch(v_x1_2494);
                }
                V v_x_2499 = heff_tag_at_n(v_ru_24x21_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2454, v_t_2484}), v_t_2498});
                return heff_tag_at_n(v_ru_24x2_2449_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2499, v_n_2483})});
              }
              default: return heff_nomatch(v_x21_2481);
              }
            }
            default: return heff_nomatch(v_x2_2479);
            }
          }
        }
        case TAG_LikeRecord: {
          heff_take_n(v_t_2456, 0ULL, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str10)});
        }
        case TAG_LikeSum: {
          V v_ru_24t_2456_24LikeSum = heff_take_reuse_n(v_t_2456, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2456_24LikeSum, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str11)});
        }
        case TAG_LikeInt: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str12)});
        }
        case TAG_LikeFloat: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str13)});
        }
        case TAG_LikeString: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str14)});
        }
        case TAG_LikeRune: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str15)});
        }
        case TAG_LikeArray: {
          V v_ru_24t_2456_24LikeArray = heff_take_reuse_n(v_t_2456, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2456_24LikeArray, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str16)});
        }
        case TAG_LikeFixed: {
          V v_ru_24t_2456_24LikeFixed = heff_take_reuse_n(v_t_2456, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2456_24LikeFixed, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str17)});
        }
        case TAG_NoRules: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2446);
          heff_drop_cell(v_ru_24x2_2449_24Right, 1);
          heff_drop(v_n_2453);
          heff_drop_cell(v_ru_24x21_2451_24MkPair, 2);
          heff_drop(v_f_27_2454);
          heff_drop_cell(v_ru_24x_2452_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str18)});
        }
        default: return heff_nomatch(v_t_2456);
        }
      }
      default: return heff_nomatch(v_x_2452);
      }
    }
    default: return heff_nomatch(v_x21_2451);
    }
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13(V self, V *args) {
  V v_n_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24106 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24119 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_n_24118}));
  switch (heff_tag_of(v_x2_24119)) {
  case TAG_Left: {
    V v_e_24120 = heff_field(v_x2_24119, 0);
    V v_ru_24x2_24119_24Left = heff_take_reuse_n(v_x2_24119, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_24106);
    return heff_tag_at_n(v_ru_24x2_24119_24Left, TAG_Left, 1, (V[]){v_e_24120});
  }
  case TAG_Right: {
    V v_x21_24121 = heff_field(v_x2_24119, 0);
    V v_ru_24x2_24119_24Right = heff_take_reuse_n(v_x2_24119, 1ULL, 1);
    switch (heff_tag_of(v_x21_24121)) {
    case TAG_MkPair: {
      V v_x_24122 = heff_field(v_x21_24121, 0);
      V v_n_24123 = heff_field(v_x21_24121, 1);
      V v_ru_24x21_24121_24MkPair = heff_take_reuse_n(v_x21_24121, 3ULL, 2);
      HeffT2 v_t_24124 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_ty_24106, heff_get_n(v_c_240, 1, 4)));
      V v_t_24132;
      {
        V v_field_24126 = v_t_24124.f[1];
        int64_t v_tag_24125 = ((int64_t)v_t_24124.f[0]);
        if ((v_tag_24125 == ((int64_t)0ULL))) {
          V v_x_24128 = v_field_24126;
          v_t_24132 = v_x_24128;
        } else {
          if ((v_tag_24125 == ((int64_t)1ULL))) {
            V v_x11_24130 = v_field_24126;
            heff_drop(v_x11_24130);
            v_t_24132 = heff_abandon();
          } else {
            V v_x_24131 = v_field_24126;
            v_t_24132 = v_x_24131;
          }
        }
      }
      V v_x_24133 = heff_tag_at_n(v_ru_24x21_24121_24MkPair, TAG_MkPair, 2, (V[]){v_x_24122, v_t_24132});
      return heff_tag_at_n(v_ru_24x2_24119_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24133, v_n_24123})});
    }
    default: return heff_nomatch(v_x21_24121);
    }
  }
  default: return heff_nomatch(v_x2_24119);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14(V self, V *args) {
  V v_n_24135 = args[0];
  heff_drop(v_n_24135);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str19)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15(V self, V *args) {
  V v_n_24139 = args[0];
  V v_m_24138 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_24136 = heff_env(self)[2];
  V v_l_24137 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24140 = heff_tr(heff_call(v_m_24138, 1, (V[]){v_n_24139}));
  switch (heff_tag_of(v_x2_24140)) {
  case TAG_Left: {
    V v_e_24141 = heff_field(v_x2_24140, 0);
    V v_ru_24x2_24140_24Left = heff_take_reuse_n(v_x2_24140, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_e_24136);
    heff_drop(v_l_24137);
    return heff_tag_at_n(v_ru_24x2_24140_24Left, TAG_Left, 1, (V[]){v_e_24141});
  }
  case TAG_Right: {
    V v_x21_24142 = heff_field(v_x2_24140, 0);
    V v_ru_24x2_24140_24Right = heff_take_reuse_n(v_x2_24140, 1ULL, 1);
    switch (heff_tag_of(v_x21_24142)) {
    case TAG_MkPair: {
      V v_x_24143 = heff_field(v_x21_24142, 0);
      V v_n_24144 = heff_field(v_x21_24142, 1);
      V v_ru_24x21_24142_24MkPair = heff_take_reuse_n(v_x21_24142, 3ULL, 2);
      switch (heff_tag_of(v_x_24143)) {
      case TAG_MkPair: {
        V v_e_27_24145 = heff_field(v_x_24143, 0);
        V v_ety_24146 = heff_field(v_x_24143, 1);
        heff_take_n(v_x_24143, 3ULL, 2);
        V v_x1_24147 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_e_24136), heff_dup(heff_rfield(v_c_240, 1))));
        V v_v_24151;
        switch (heff_tag_of(v_x1_24147)) {
        case TAG_Nom: {
          V v_x_24148 = heff_field(v_x1_24147, 0);
          heff_take_n(v_x1_24147, 1ULL, 1);
          v_v_24151 = v_x_24148;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24147, 0ULL, 1);
          v_v_24151 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24150 = heff_field(v_x1_24147, 0);
          heff_take_n(v_x1_24147, 1ULL, 1);
          v_v_24151 = v_x_24150;
          break;
        }
        default: heff_nomatch(v_x1_24147);
        }
        V v_t_24152 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24151));
        V v_m_24153 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 2)); V a_1 = heff_dup(v_ety_24146); V a_2 = v_t_24152; V a_3 = heff_dup(v_l_24137); V r_ = (g_heff_2ecompile_2eerase_2eprojTyInWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_24152); r_; });
        V v_x2_24154 = heff_tr(heff_call(v_m_24153, 1, (V[]){v_n_24144}));
        switch (heff_tag_of(v_x2_24154)) {
        case TAG_Left: {
          V v_e_24155 = heff_field(v_x2_24154, 0);
          V v_ru_24x2_24154_24Left = heff_take_reuse_n(v_x2_24154, 1ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_e_24136);
          heff_drop(v_l_24137);
          heff_drop_cell(v_ru_24x2_24140_24Right, 1);
          heff_drop_cell(v_ru_24x21_24142_24MkPair, 2);
          heff_drop(v_e_27_24145);
          heff_drop(v_ety_24146);
          return heff_tag_at_n(v_ru_24x2_24154_24Left, TAG_Left, 1, (V[]){v_e_24155});
        }
        case TAG_Right: {
          V v_x21_24156 = heff_field(v_x2_24154, 0);
          V v_ru_24x2_24154_24Right = heff_take_reuse_n(v_x2_24154, 1ULL, 1);
          switch (heff_tag_of(v_x21_24156)) {
          case TAG_MkPair: {
            V v_x_24157 = heff_field(v_x21_24156, 0);
            V v_n_24158 = heff_field(v_x21_24156, 1);
            heff_take_n(v_x21_24156, 3ULL, 2);
            V v_x1_24159 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_take_field(v_c_240, 3), NTAG(TAG_N), v_e_24136, heff_take_field(v_c_240, 1)));
            V v_v_24163;
            switch (heff_tag_of(v_x1_24159)) {
            case TAG_Nom: {
              V v_x_24160 = heff_field(v_x1_24159, 0);
              heff_take_n(v_x1_24159, 1ULL, 1);
              v_v_24163 = v_x_24160;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_24159, 0ULL, 1);
              v_v_24163 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_24162 = heff_field(v_x1_24159, 0);
              heff_take_n(v_x1_24159, 1ULL, 1);
              v_v_24163 = v_x_24162;
              break;
            }
            default: heff_nomatch(v_x1_24159);
            }
            V v_t_24164 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24163));
            V v_t_24165 = ({ V a_0 = heff_get_n(v_c_240, 2, 4); V a_1 = v_ety_24146; V a_2 = v_t_24164; V r_ = (g_heff_2ecompile_2eerase_2eshapeWith(a_0, a_1, a_2)); heff_drop(v_t_24164); r_; });
            V v_x1_24166 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_24157)));
            V v_t_24178;
            switch (heff_tag_of(v_x1_24166)) {
            case TAG_LikeU: {
              heff_take_n(v_x1_24166, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFunction: {
              heff_take_n(v_x1_24166, 0ULL, 4);
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRecord: {
              heff_take_n(v_x1_24166, 0ULL, 3);
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeSum: {
              heff_take_n(v_x1_24166, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeInt: {
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFloat: {
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtFloat);
              break;
            }
            case TAG_LikeString: {
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRune: {
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeArray: {
              heff_take_n(v_x1_24166, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFixed: {
              V v_w_24177 = heff_field(v_x1_24166, 0);
              heff_take_n(v_x1_24166, 1ULL, 1);
              v_t_24178 = heff_tag_at_n(v_ru_24x2_24154_24Right, TAG_FtFixed, 1, (V[]){v_w_24177});
              break;
            }
            case TAG_NoRules: {
              heff_drop_cell(v_ru_24x2_24154_24Right, 1);
              v_t_24178 = NTAG(TAG_FtAny);
              break;
            }
            default: heff_nomatch(v_x1_24166);
            }
            V v_x_24179 = heff_tag_at_n(v_ru_24x21_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_27_24145, v_l_24137, v_t_24165, v_t_24178}), v_x_24157});
            return heff_tag_at_n(v_ru_24x2_24140_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24179, v_n_24158})});
          }
          default: return heff_nomatch(v_x21_24156);
          }
        }
        default: return heff_nomatch(v_x2_24154);
        }
      }
      default: return heff_nomatch(v_x_24143);
      }
    }
    default: return heff_nomatch(v_x21_24142);
    }
  }
  default: return heff_nomatch(v_x2_24140);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16(V self, V *args) {
  V v_n_24182 = args[0];
  heff_drop(v_n_24182);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str20)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18(V self, V *args) {
  V v_p_24212 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24198 = heff_env(self)[1];
  V v_x_24207 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_240, v_x_24198, v_x_24207, v_p_24212));
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17(V self, V *args) {
  V v_n_24186 = args[0];
  V v_m_24185 = heff_env(self)[0];
  V v_cases_24184 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24187 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_n_24186}));
  switch (heff_tag_of(v_x2_24187)) {
  case TAG_Left: {
    V v_e_24188 = heff_field(v_x2_24187, 0);
    V v_ru_24x2_24187_24Left = heff_take_reuse_n(v_x2_24187, 1ULL, 1);
    heff_drop_rec(v_cases_24184, 3);
    heff_drop_rec(v_c_240, 4);
    return heff_tag_at_n(v_ru_24x2_24187_24Left, TAG_Left, 1, (V[]){v_e_24188});
  }
  case TAG_Right: {
    V v_x21_24189 = heff_field(v_x2_24187, 0);
    V v_ru_24x2_24187_24Right = heff_take_reuse_n(v_x2_24187, 1ULL, 1);
    switch (heff_tag_of(v_x21_24189)) {
    case TAG_MkPair: {
      V v_x_24190 = heff_field(v_x21_24189, 0);
      V v_n_24191 = heff_field(v_x21_24189, 1);
      V v_ru_24x21_24189_24MkPair = heff_take_reuse_n(v_x21_24189, 3ULL, 2);
      switch (heff_tag_of(v_x_24190)) {
      case TAG_MkPair: {
        V v_s_27_24192 = heff_field(v_x_24190, 0);
        V v_sty_24193 = heff_field(v_x_24190, 1);
        heff_take_n(v_x_24190, 3ULL, 2);
        V v_m_24194 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24193));
        V v_x2_24195 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_n_24191}));
        switch (heff_tag_of(v_x2_24195)) {
        case TAG_Left: {
          V v_e_24196 = heff_field(v_x2_24195, 0);
          V v_ru_24x2_24195_24Left = heff_take_reuse_n(v_x2_24195, 1ULL, 1);
          heff_drop_rec(v_cases_24184, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop_cell(v_ru_24x2_24187_24Right, 1);
          heff_drop_cell(v_ru_24x21_24189_24MkPair, 2);
          heff_drop(v_s_27_24192);
          return heff_tag_at_n(v_ru_24x2_24195_24Left, TAG_Left, 1, (V[]){v_e_24196});
        }
        case TAG_Right: {
          V v_x21_24197 = heff_field(v_x2_24195, 0);
          V v_ru_24x2_24195_24Right = heff_take_reuse_n(v_x2_24195, 1ULL, 1);
          switch (heff_tag_of(v_x21_24197)) {
          case TAG_MkPair: {
            V v_x_24198 = heff_field(v_x21_24197, 0);
            V v_n_24199 = heff_field(v_x21_24197, 1);
            heff_take_n(v_x21_24197, 3ULL, 2);
            V v_t_24200 = heff_arrayToList(heff_dup(heff_rfield(v_cases_24184, 0)));
            V v_t_24201 = heff_arrayToList(heff_dup(heff_rfield(v_cases_24184, 2)));
            V v_t_24202 = (g_heff_2eutil_2edict_2ezipKV(v_t_24200, v_t_24201));
            V v_m_24203 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(heff_dup(v_c_240), heff_dup(v_x_24198), v_t_24202));
            V v_x2_24204 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_n_24199}));
            switch (heff_tag_of(v_x2_24204)) {
            case TAG_Left: {
              V v_e_24205 = heff_field(v_x2_24204, 0);
              heff_take_n(v_x2_24204, 1ULL, 1);
              heff_drop_rec(v_cases_24184, 3);
              heff_drop_rec(v_c_240, 4);
              heff_drop_cell(v_ru_24x2_24187_24Right, 1);
              heff_drop_cell(v_ru_24x21_24189_24MkPair, 2);
              heff_drop(v_s_27_24192);
              heff_drop(v_x_24198);
              return heff_tag_at_n(v_ru_24x2_24195_24Right, TAG_Left, 1, (V[]){v_e_24205});
            }
            case TAG_Right: {
              V v_x21_24206 = heff_field(v_x2_24204, 0);
              heff_take_n(v_x2_24204, 1ULL, 1);
              switch (heff_tag_of(v_x21_24206)) {
              case TAG_MkPair: {
                V v_x_24207 = heff_field(v_x21_24206, 0);
                V v_n_24208 = heff_field(v_x21_24206, 1);
                heff_take_n(v_x21_24206, 3ULL, 2);
                V v_t_24209 = heff_arrayToList(heff_take_field(v_cases_24184, 0));
                V v_t_24210 = heff_arrayToList(heff_get_n(v_cases_24184, 2, 3));
                V v_t_24211 = (g_heff_2eutil_2edict_2ezipKV(v_t_24209, v_t_24210));
                V v_m_24213 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18, 1, 3, (V[]){v_c_240, v_x_24198, heff_dup(v_x_24207)}), v_t_24211));
                V v_x2_24214 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_n_24208}));
                switch (heff_tag_of(v_x2_24214)) {
                case TAG_Left: {
                  V v_e_24215 = heff_field(v_x2_24214, 0);
                  heff_take_n(v_x2_24214, 1ULL, 1);
                  heff_drop_cell(v_ru_24x2_24187_24Right, 1);
                  heff_drop_cell(v_ru_24x21_24189_24MkPair, 2);
                  heff_drop(v_s_27_24192);
                  heff_drop(v_x_24207);
                  return heff_tag_at_n(v_ru_24x2_24195_24Right, TAG_Left, 1, (V[]){v_e_24215});
                }
                case TAG_Right: {
                  V v_x21_24216 = heff_field(v_x2_24214, 0);
                  heff_take_n(v_x2_24214, 1ULL, 1);
                  heff_drop_cell(v_ru_24x2_24195_24Right, 1);
                  switch (heff_tag_of(v_x21_24216)) {
                  case TAG_MkPair: {
                    V v_x_24217 = heff_field(v_x21_24216, 0);
                    V v_n_24218 = heff_field(v_x21_24216, 1);
                    heff_take_n(v_x21_24216, 3ULL, 2);
                    V v_t_24219 = heff_tag_at_n(v_ru_24x21_24189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_24192, v_x_24217}), v_x_24207});
                    return heff_tag_at_n(v_ru_24x2_24187_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24219, v_n_24218})});
                  }
                  default: return heff_nomatch(v_x21_24216);
                  }
                }
                default: return heff_nomatch(v_x2_24214);
                }
              }
              default: return heff_nomatch(v_x21_24206);
              }
            }
            default: return heff_nomatch(v_x2_24204);
            }
          }
          default: return heff_nomatch(v_x21_24197);
          }
        }
        default: return heff_nomatch(v_x2_24195);
        }
      }
      default: return heff_nomatch(v_x_24190);
      }
    }
    default: return heff_nomatch(v_x21_24189);
    }
  }
  default: return heff_nomatch(v_x2_24187);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19(V self, V *args) {
  V v_n_24223 = args[0];
  heff_drop(v_n_24223);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str21)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20(V self, V *args) {
  V v_n_24225 = args[0];
  heff_drop(v_n_24225);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str22)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21(V self, V *args) {
  V v_n_24226 = args[0];
  heff_drop(v_n_24226);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str23)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22(V self, V *args) {
  V v_n_24240 = args[0];
  V v_m_24239 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24228 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24241 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_n_24240}));
  switch (heff_tag_of(v_x2_24241)) {
  case TAG_Left: {
    V v_e_24242 = heff_field(v_x2_24241, 0);
    V v_ru_24x2_24241_24Left = heff_take_reuse_n(v_x2_24241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_24228);
    return heff_tag_at_n(v_ru_24x2_24241_24Left, TAG_Left, 1, (V[]){v_e_24242});
  }
  case TAG_Right: {
    V v_x21_24243 = heff_field(v_x2_24241, 0);
    V v_ru_24x2_24241_24Right = heff_take_reuse_n(v_x2_24241, 1ULL, 1);
    switch (heff_tag_of(v_x21_24243)) {
    case TAG_MkPair: {
      V v_x_24244 = heff_field(v_x21_24243, 0);
      V v_n_24245 = heff_field(v_x21_24243, 1);
      V v_ru_24x21_24243_24MkPair = heff_take_reuse_n(v_x21_24243, 3ULL, 2);
      HeffT2 v_t_24246 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_ty_24228, heff_get_n(v_c_240, 1, 4)));
      V v_t_24254;
      {
        V v_field_24248 = v_t_24246.f[1];
        int64_t v_tag_24247 = ((int64_t)v_t_24246.f[0]);
        if ((v_tag_24247 == ((int64_t)0ULL))) {
          V v_x_24250 = v_field_24248;
          v_t_24254 = v_x_24250;
        } else {
          if ((v_tag_24247 == ((int64_t)1ULL))) {
            V v_x11_24252 = v_field_24248;
            heff_drop(v_x11_24252);
            v_t_24254 = heff_abandon();
          } else {
            V v_x_24253 = v_field_24248;
            v_t_24254 = v_x_24253;
          }
        }
      }
      V v_x_24255 = heff_tag_at_n(v_ru_24x21_24243_24MkPair, TAG_MkPair, 2, (V[]){v_x_24244, v_t_24254});
      return heff_tag_at_n(v_ru_24x2_24241_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24255, v_n_24245})});
    }
    default: return heff_nomatch(v_x21_24243);
    }
  }
  default: return heff_nomatch(v_x2_24241);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23(V self, V *args) {
  V v_n_24259 = args[0];
  heff_drop(v_n_24259);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str24)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24(V self, V *args) {
  V v_n_24263 = args[0];
  heff_drop(v_n_24263);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str25)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25(V self, V *args) {
  V v_n_24265 = args[0];
  V v_i_24264 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24266 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_i_24264}), NTAG(TAG_VPrimInt)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24266, v_n_24265})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26(V self, V *args) {
  V v_n_24268 = args[0];
  V v_x_24267 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24269 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_24267))}), NTAG(TAG_VPrimFloat)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24269, v_n_24268})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27(V self, V *args) {
  V v_n_24271 = args[0];
  V v_s_24270 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24272 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_s_24270}), NTAG(TAG_VPrimString)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24272, v_n_24271})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28(V self, V *args) {
  V v_n_24285 = args[0];
  V v_x_24284 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24284, v_n_24285})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29(V self, V *args) {
  V v_n_24287 = args[0];
  V v_n_24286 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24288 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I32), v_n_24286});
  V v_t_24289 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24288, NTAG(TAG_VPrimRune)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24289, v_n_24287})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30(V self, V *args) {
  V v_n_24292 = args[0];
  V v_w_24290 = heff_env(self)[0];
  V v_n_24291 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24293 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFixed, 2, (V[]){heff_dup(v_w_24290), v_n_24291}), heff_tag_n(TAG_VFixed, 1, (V[]){v_w_24290})});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24293, v_n_24292})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam31(V self, V *args) {
  V v_n_24295 = args[0];
  V v_x_24294 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24296 = heff_tag_n(TAG_VFixed, 1, (V[]){NTAG(TAG_F32)});
  V v_t_24297 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_24294))}), v_t_24296});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24297, v_n_24295})});
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry, 2, 0};

V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V v_c_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_a_242 = heff_field(v_x3_241, 0);
    V v_aty_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_aty_243)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_a_242);
      heff_drop(v_aty_243);
      heff_drop(v_t_244);
      return ((V)&g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0_clo);
    } else {
      heff_drop(v_t_244);
      V v_m_247 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_a_242, heff_dup(v_aty_243)));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam1, 1, 2, (V[]){v_m_247, v_aty_243});
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_245});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_246});
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_aty_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    heff_drop(v_aty_243);
    return heff_tag_at_n(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_x1_2414 = (g_heff_2eelab_2evalue_2ebehavior(v_aty_243));
      V v_t_2426;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_LikeU: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x1_2414, 0ULL, 4);
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_x1_2414, 0ULL, 3);
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeInt: {
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFloat: {
        v_t_2426 = NTAG(TAG_FtFloat);
        break;
      }
      case TAG_LikeString: {
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRune: {
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x1_2414, 0ULL, 1);
        v_t_2426 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFixed: {
        V v_w_2425 = heff_field(v_x1_2414, 0);
        V v_ru_24x1_2414_24LikeFixed = heff_take_reuse_n(v_x1_2414, 1ULL, 1);
        v_t_2426 = heff_tag_at_n(v_ru_24x1_2414_24LikeFixed, TAG_FtFixed, 1, (V[]){v_w_2425});
        break;
      }
      case TAG_NoRules: {
        v_t_2426 = NTAG(TAG_FtAny);
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_x_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){v_x_2412, v_t_2426})});
      return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2427, v_n_2413})});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V v_c_240, V v_ty_241, V v_v_242, V v_fs_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkPair: {
    V v_l_245 = heff_field(v_x6_244, 0);
    V v_fe_246 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2eerase_2eprojTyInWith(heff_dup(heff_rfield(v_c_240, 2)), v_ty_241, v_fs_243, heff_dup(v_l_245)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0, 1, 6, (V[]){v_m_247, v_c_240, heff_dup(v_fs_243), v_v_242, v_l_245, v_fe_246});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fs_243 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_l_245 = heff_env(self)[4];
  V v_fe_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fs_243);
    heff_drop(v_v_242);
    heff_drop(v_l_245);
    heff_drop(v_fe_246);
    return heff_tag_at_n(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_x_2412)));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop_rec(v_c_240, 4);
        heff_drop(v_fs_243);
        heff_drop(v_v_242);
        heff_drop(v_l_245);
        heff_drop(v_fe_246);
        heff_drop(v_x_2412);
        heff_drop(v_t_2414);
        V v_t_2415 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2413});
        return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){v_t_2415});
      } else {
        heff_drop(v_t_2414);
        V v_x1_2416 = ({ V a_0 = v_fs_243; V a_1 = v_v_242; V a_2 = v_l_245; V r_ = (g_heff_2ecompile_2eerase_2eprojWith(a_0, a_1, a_2)); heff_drop(v_fs_243); r_; });
        V v_v_2420;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nom: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2417;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2416, 0ULL, 1);
          v_v_2420 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2419 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_m_2421 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(v_c_240, v_fe_246, heff_dup(v_x_2412), v_v_2420));
        V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2413}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Left: {
          V v_e_2423 = heff_field(v_x2_2422, 0);
          V v_ru_24x2_2422_24Left = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
          heff_drop(v_l_245);
          heff_drop_cell(v_ru_24x2_249_24Right, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x21_2411_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2422_24Left, TAG_Left, 1, (V[]){v_e_2423});
        }
        case TAG_Right: {
          V v_x21_2424 = heff_field(v_x2_2422, 0);
          V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
          switch (heff_tag_of(v_x21_2424)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x21_2424, 0);
            V v_n_2426 = heff_field(v_x21_2424, 1);
            heff_take_n(v_x21_2424, 3ULL, 2);
            V v_x1_2427 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2412));
            V v_t_2439;
            switch (heff_tag_of(v_x1_2427)) {
            case TAG_LikeU: {
              heff_take_n(v_x1_2427, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFunction: {
              heff_take_n(v_x1_2427, 0ULL, 4);
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRecord: {
              heff_take_n(v_x1_2427, 0ULL, 3);
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeSum: {
              heff_take_n(v_x1_2427, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeInt: {
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFloat: {
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtFloat);
              break;
            }
            case TAG_LikeString: {
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRune: {
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeArray: {
              heff_take_n(v_x1_2427, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFixed: {
              V v_w_2438 = heff_field(v_x1_2427, 0);
              heff_take_n(v_x1_2427, 1ULL, 1);
              v_t_2439 = heff_tag_at_n(v_ru_24x2_2422_24Right, TAG_FtFixed, 1, (V[]){v_w_2438});
              break;
            }
            case TAG_NoRules: {
              heff_drop_cell(v_ru_24x2_2422_24Right, 1);
              v_t_2439 = NTAG(TAG_FtAny);
              break;
            }
            default: heff_nomatch(v_x1_2427);
            }
            V v_t_2440 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_x_2425}), v_t_2439});
            V v_x_2441 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2440});
            return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2441, v_n_2426})});
          }
          default: return heff_nomatch(v_x21_2424);
          }
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str2, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str3, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str4, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str5, 1, "$");
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam12(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam11(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry, 4, 0};

V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V v_c_240, V v_t_241, V v_ty_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SCode: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SApp: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLam: {
    V v_abs_2410 = heff_dup(heff_field(v_t_241, 1));
    V v_t_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      V v_dom_2414 = heff_field(v_t_2411, 1);
      V v_cod_2415 = heff_field(v_t_2411, 2);
      heff_take_n(v_t_2411, 6ULL, 4);
      heff_drop_tag(v_t_241, 2);
      heff_drop(v_ty_242);
      V v_t_2422;
      switch (heff_tag_of(v_abs_2410)) {
      case TAG_MkAbs: {
        V v_n_2417 = heff_field(v_abs_2410, 0);
        V v_b_2418 = heff_field(v_abs_2410, 1);
        V v_ru_24abs_2410_24MkAbs = heff_take_reuse_n(v_abs_2410, 3ULL, 2);
        V v_t_2419 = heff_tag_at_n(v_ru_24abs_2410_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2417, NTAG(TAG_True)});
        v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_b_2418});
        break;
      }
      case TAG_AbsConst: {
        V v_b_2420 = heff_field(v_abs_2410, 0);
        heff_take_n(v_abs_2410, 1ULL, 1);
        V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str0), NTAG(TAG_False)});
        v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_b_2420});
        break;
      }
      default: heff_nomatch(v_abs_2410);
      }
      switch (heff_tag_of(v_t_2422)) {
      case TAG_MkPair: {
        V v_it1_2423 = heff_field(v_t_2422, 0);
        V v_body_2424 = heff_field(v_t_2422, 1);
        V v_ru_24t_2422_24MkPair = heff_take_reuse_n(v_t_2422, 3ULL, 2);
        switch (heff_tag_of(v_it1_2423)) {
        case TAG_MkPair: {
          V v_hint_2425 = heff_field(v_it1_2423, 0);
          V v_bound_2426 = heff_field(v_it1_2423, 1);
          V v_ru_24it1_2423_24MkPair = heff_take_reuse_n(v_it1_2423, 3ULL, 2);
          V v_t_2427 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_2414)));
          if ((heff_dup(v_t_2427) == NTAG(TAG_True))) {
            heff_drop(v_hint_2425);
            heff_drop(v_t_2427);
            V v_c_2436;
            if ((heff_dup(v_bound_2426) == NTAG(TAG_True))) {
              heff_drop(v_bound_2426);
              V v_t_2428 = heff_rec_n(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_2414)});
              V v_t_2429 = heff_tag_at_n(v_ru_24t_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2428, heff_dup(heff_rfield(v_c_240, 0))});
              V v_t_2430 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
              V v_v_2432 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2430, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
              V v_t_2434 = heff_tag_at_n(v_ru_24it1_2423_24MkPair, TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1, 1, 1, (V[]){v_v_2432})});
              V v_t_2435 = heff_intAdd(heff_dup(heff_rfield(v_c_240, 2)), MK_INT(1LL));
              v_c_2436 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2429, v_t_2434, v_t_2435, heff_dup(heff_rfield(v_c_240, 3))});
            } else {
              heff_drop_cell(v_ru_24t_2422_24MkPair, 2);
              heff_drop(v_bound_2426);
              heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
              v_c_2436 = heff_dup(v_c_240);
            }
            V v_x1_2444;
            switch (heff_tag_of(v_cod_2415)) {
            case TAG_MkClo: {
              V v_vs_2438 = heff_field(v_cod_2415, 1);
              V v_body_2439 = heff_field(v_cod_2415, 2);
              heff_take_n(v_cod_2415, 6ULL, 3);
              v_x1_2444 = heff_tr(heff_call(v_body_2439, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2438, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2443 = heff_field(v_cod_2415, 0);
              heff_take_n(v_cod_2415, 1ULL, 1);
              v_x1_2444 = v_body_2443;
              break;
            }
            default: heff_nomatch(v_cod_2415);
            }
            V v_ty_2448;
            switch (heff_tag_of(v_x1_2444)) {
            case TAG_Nom: {
              V v_x_2445 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2445;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2444, 0ULL, 1);
              v_ty_2448 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2447 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2447;
              break;
            }
            default: heff_nomatch(v_x1_2444);
            }
            V v_x1_2452 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_v_243, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4, 1, 2, (V[]){v_c_240, v_dom_2414})));
            V v_v_2456;
            switch (heff_tag_of(v_x1_2452)) {
            case TAG_Nom: {
              V v_x_2453 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2453;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              v_v_2456 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2455 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2455;
              break;
            }
            default: heff_nomatch(v_x1_2452);
            }
            V t_0 = v_c_2436;
            V t_1 = v_body_2424;
            V t_2 = v_ty_2448;
            V t_3 = v_v_2456;
            v_c_240 = t_0;
            v_t_241 = t_1;
            v_ty_242 = t_2;
            v_v_243 = t_3;
            goto top;
          } else {
            heff_drop_cell(v_ru_24t_2422_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
            heff_drop(v_t_2427);
            return heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6, 1, 7, (V[]){v_hint_2425, v_bound_2426, v_dom_2414, v_c_240, v_cod_2415, v_v_243, v_body_2424});
          }
        }
        default: return heff_nomatch(v_it1_2423);
        }
      }
      default: return heff_nomatch(v_t_2422);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2411, 0ULL, 3);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRune: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_SCons: {
    V v_d_24106 = heff_dup(heff_field(v_t_241, 0));
    V v_t_24107 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_24107)) {
    case TAG_LikeU: {
      heff_take_n(v_t_24107, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_24107, 0ULL, 4);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_24107, 0ULL, 3);
      heff_drop_tag(v_t_241, 1);
      V v_t_24116 = heff_arrayToList(heff_take_field(v_d_24106, 0));
      V v_t_24117 = heff_arrayToList(heff_get_n(v_d_24106, 2, 3));
      V v_t_24118 = (g_heff_2eutil_2edict_2ezipKV(v_t_24116, v_t_24117));
      V v_t_24119 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_243)));
      return ({ V a_0 = v_c_240; V a_1 = v_ty_242; V a_2 = v_v_243; V a_3 = v_t_24118; V a_4 = v_t_24119; V r_ = (g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_24119); r_; });
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_24107, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRune: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_24107, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_24107, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24106, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_24107);
    }
  }
  case TAG_SProj: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_STag: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMatch: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SSpecialize: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SIs: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SOpaque: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SAbandon: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SRec: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SFix: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SImplicit: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SPrim: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMetaApp: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitInt: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitString: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitBytes: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitRune: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFixed: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat32: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0(V self, V *args) {
  V v_u_2431 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_v_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_v_2432;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3(V self, V *args) {
  V v_u_2442 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2440);
  V v_t_2441 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2441, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2451);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4(V self, V *args) {
  V v_u_2449 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  V v_t_2450 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2450, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7(V self, V *args) {
  V v_u_2466 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2466);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8(V self, V *args) {
  V v_u_2468 = args[0];
  V v_v_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2468);
  return v_v_2467;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10(V self, V *args) {
  V v_u_2477 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2477);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9(V self, V *args) {
  V v_u_2475 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2475);
  V v_t_2476 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2476, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam12(V self, V *args) {
  V v_u_2486 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2486);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam11(V self, V *args) {
  V v_u_2484 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2484);
  V v_t_2485 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2485, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam12, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6(V self, V *args) {
  V v_n_2457 = args[0];
  V v_hint_2425 = heff_env(self)[0];
  V v_bound_2426 = heff_env(self)[1];
  V v_dom_2414 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_2415 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_body_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2460;
  if (heff_strEq_c_lent(v_hint_2425, ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str1), 2)) {
    heff_drop(v_hint_2425);
    v_t_2460 = ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str2);
  } else {
    if (heff_strEq_c_lent(v_hint_2425, ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str3), 2)) {
      heff_drop(v_hint_2425);
      v_t_2460 = ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str4);
    } else {
      v_t_2460 = v_hint_2425;
    }
  }
  V v_t_2461 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str5), heff_intShow(heff_dup(v_n_2457)));
  V v_t_2462 = heff_strAppend(v_t_2460, v_t_2461);
  V v_c_2471;
  if ((heff_dup(v_bound_2426) == NTAG(TAG_True))) {
    heff_drop(v_bound_2426);
    V v_t_2463 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2462)})});
    V v_t_2464 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2463, heff_dup(v_dom_2414)}), heff_dup(heff_rfield(v_c_240, 0))});
    V v_t_2465 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
    V v_v_2467 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2465, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
    V v_t_2469 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8, 1, 1, (V[]){v_v_2467})});
    V v_t_2470 = heff_intAdd(heff_dup(heff_rfield(v_c_240, 2)), MK_INT(1LL));
    v_c_2471 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2464, v_t_2469, v_t_2470, heff_dup(heff_rfield(v_c_240, 3))});
  } else {
    heff_drop(v_bound_2426);
    v_c_2471 = heff_dup(v_c_240);
  }
  V v_x1_2479;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2473 = heff_field(v_cod_2415, 1);
    V v_body_2474 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2479 = heff_tr(heff_call(v_body_2474, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2473, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2478 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    v_x1_2479 = v_body_2478;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_ty_2483;
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_Nom: {
    V v_x_2480 = heff_field(v_x1_2479, 0);
    heff_take_n(v_x1_2479, 1ULL, 1);
    v_ty_2483 = v_x_2480;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2479, 0ULL, 1);
    v_ty_2483 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2482 = heff_field(v_x1_2479, 0);
    heff_take_n(v_x1_2479, 1ULL, 1);
    v_ty_2483 = v_x_2482;
    break;
  }
  default: heff_nomatch(v_x1_2479);
  }
  V v_x1_2487 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_v_243, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam11, 1, 2, (V[]){v_c_240, v_dom_2414})));
  V v_v_2491;
  switch (heff_tag_of(v_x1_2487)) {
  case TAG_Nom: {
    V v_x_2488 = heff_field(v_x1_2487, 0);
    heff_take_n(v_x1_2487, 1ULL, 1);
    v_v_2491 = v_x_2488;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2487, 0ULL, 1);
    v_v_2491 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2490 = heff_field(v_x1_2487, 0);
    heff_take_n(v_x1_2487, 1ULL, 1);
    v_v_2491 = v_x_2490;
    break;
  }
  default: heff_nomatch(v_x1_2487);
  }
  V v_m_2492 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(v_c_2471, v_body_2424, v_ty_2483, v_v_2491));
  V v_x2_2493 = heff_tr(heff_call(v_m_2492, 1, (V[]){heff_intAdd(v_n_2457, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_Left: {
    V v_e_2494 = heff_field(v_x2_2493, 0);
    V v_ru_24x2_2493_24Left = heff_take_reuse_n(v_x2_2493, 1ULL, 1);
    heff_drop(v_t_2462);
    return heff_tag_at_n(v_ru_24x2_2493_24Left, TAG_Left, 1, (V[]){v_e_2494});
  }
  case TAG_Right: {
    V v_x21_2495 = heff_field(v_x2_2493, 0);
    V v_ru_24x2_2493_24Right = heff_take_reuse_n(v_x2_2493, 1ULL, 1);
    switch (heff_tag_of(v_x21_2495)) {
    case TAG_MkPair: {
      V v_x_2496 = heff_field(v_x21_2495, 0);
      V v_n_2497 = heff_field(v_x21_2495, 1);
      V v_ru_24x21_2495_24MkPair = heff_take_reuse_n(v_x21_2495, 3ULL, 2);
      V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      V v_t_2499 = heff_tag_at_n(v_ru_24x21_2495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2498, v_x_2496}), v_n_2497});
      return heff_tag_at_n(v_ru_24x2_2493_24Right, TAG_Right, 1, (V[]){v_t_2499});
    }
    default: return heff_nomatch(v_x21_2495);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eeraseOne_str0, 2, ": ");
V g_heff_2ecompile_2eerase_2eeraseOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eeraseOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eeraseOne_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eeraseOne(V v_g_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_244, 3))));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_g_240);
      heff_drop(v_key_243);
      heff_drop_rec(v_e_244, 4);
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_t_245);
      return v_acc_241;
    } else {
      heff_drop(v_t_245);
      V v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_key_243)})});
      V v_t_247 = heff_rec_n(2, shape_ir__ty, (V[]){v_t_246, heff_dup(heff_rfield(v_e_244, 3))});
      V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2ecompile_2eerase_2eeraseOne_lam0, 1, 1, (V[]){heff_dup(v_e_244)})});
      V v_t_2411 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_248, v_t_2410, MK_INT(1LL), v_g_240}), heff_take_field(v_e_244, 0), heff_take_field(v_e_244, 3), heff_get_n(v_e_244, 2, 4)));
      V v_it_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){heff_dup(heff_rfield(v_acc_241, 2))}));
      switch (heff_tag_of(v_it_2412)) {
      case TAG_Left: {
        V v_err_2413 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        V v_t_2414 = heff_strAppend(v_key_243, heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eeraseOne_str0), v_err_2413));
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_acc_241, 1)});
        return ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_acc_241, 5ULL, 3, shape_defs__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_Right: {
        V v_it1_2416 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        switch (heff_tag_of(v_it1_2416)) {
        case TAG_MkPair: {
          V v_body_2417 = heff_field(v_it1_2416, 0);
          V v_n_2418 = heff_field(v_it1_2416, 1);
          V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24it1_2416_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_243), v_key_243, v_body_2417}), heff_dup(heff_rfield(v_acc_241, 0))});
          return ({ V rv_0 = v_t_2419; V rv_2 = v_n_2418; V rr_ = heff_rec_reuse_nf(v_acc_241, 2ULL, 3, shape_defs__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_it1_2416);
        }
      }
      default: return heff_nomatch(v_it_2412);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eerase_2eeraseOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eeraseOne(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eeraseOne_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return heff_get_n(v_e_244, 2, 4);
}
Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eeraseProgram_entry, 1, 0};

V g_heff_2ecompile_2eerase_2eeraseProgram(V v_g_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(v_g_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    return heff_rec_n(3, shape_defs__errors__supply, (V[]){v_field_242, v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eeraseProgram(a[0]);
}