// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145 14377
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HLocal 25864
#define TAG_I32 19220
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkArm 55352
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VFixed 12623
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define LBL_aliases 1464806715
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_supply 1056026650
#define LBL_syntax 1059664654
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_vars 10107635
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2earmBind(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmBind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBind_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V, V, V);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo;
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo;
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo;
V g_heff_2ecompile_2eerase_2edefinition(V, V, V, V);
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2edefinition_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2eerase_2eextend(V, V, V);
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eextend_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eerase_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ekeptOf_clo;
V g_heff_2ecompile_2eerase_2ematchVariants(V);
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ematchVariants_clo;
HeffT2 g_heff_2ecompile_2eerase_2enthLocal_24cpr(V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
HeffT2 g_heff_2eelab_2evalue_2edecodeEv_24cpr(V);
V g_heff_2eelab_2evalue_2efieldIn(V, V);
V g_heff_2eelab_2evalue_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2efieldIn_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2ecompile_2eerase_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ekeptOf_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ekeptOf(V v_len_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_len_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x31_243, 0);
      V v_x312_246 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_246)) {
      case TAG_Nothing: {
        heff_drop(v_len_240);
        heff_drop(v_acc_241);
        heff_drop(v_rest_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_245);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_ty_247 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 1);
        V v_t_248 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(v_len_240), v_ty_247));
        V v_t_249;
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_k_245);
          heff_drop(v_t_248);
          v_t_249 = v_acc_241;
        } else {
          heff_drop(v_t_248);
          v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_k_245, v_acc_241});
        }
        V t_0 = v_len_240;
        V t_1 = v_t_249;
        V t_2 = v_rest_244;
        v_len_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eerase_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ekeptOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str0, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str1, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str2, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str3, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str4, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str5, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str6, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str7, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str8, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str9, 47, "matching on something that is not of a sum type");
V g_heff_2ecompile_2eerase_2ematchVariants_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2ematchVariants_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam10, 1, 0};
Clo g_heff_2ecompile_2eerase_2ematchVariants_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_entry, 1, 0};

V g_heff_2ecompile_2eerase_2ematchVariants(V v_sty_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2evalue_2ebehavior(v_sty_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_LikeU: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_241, 0ULL, 4);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam1_clo);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_241, 0ULL, 3);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam2_clo);
  }
  case TAG_LikeSum: {
    V v_vs_2413 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2eerase_2ematchVariants_lam3, 1, 1, (V[]){v_vs_2413});
  }
  case TAG_LikeInt: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam4_clo);
  }
  case TAG_LikeFloat: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam5_clo);
  }
  case TAG_LikeString: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam6_clo);
  }
  case TAG_LikeRune: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam7_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam8_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam9_clo);
  }
  case TAG_NoRules: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam10_clo);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ematchVariants(a[0]);
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str0)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam1(V self, V *args) {
  V v_n_248 = args[0];
  heff_drop(v_n_248);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str1)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str2)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_vs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_vs_2413, v_n_2414})});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam4(V self, V *args) {
  V v_n_2415 = args[0];
  heff_drop(v_n_2415);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str3)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam5(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str4)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam6(V self, V *args) {
  V v_n_2417 = args[0];
  heff_drop(v_n_2417);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str5)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam7(V self, V *args) {
  V v_n_2418 = args[0];
  heff_drop(v_n_2418);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str6)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam8(V self, V *args) {
  V v_n_2420 = args[0];
  heff_drop(v_n_2420);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str7)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam9(V self, V *args) {
  V v_n_2422 = args[0];
  heff_drop(v_n_2422);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str8)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam10(V self, V *args) {
  V v_n_2423 = args[0];
  heff_drop(v_n_2423);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str9)});
}
Clo g_heff_2ecompile_2eerase_2earmBind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmBind_entry, 4, 0};

V g_heff_2ecompile_2eerase_2earmBind(V v_c_240, V v_vs_241, V v_tag_242, V v_xs_243) {
top: ;
  V v_byName_244 = heff_take_field(v_vs_241, 1);
  V v_values_245 = heff_get_n(v_vs_241, 2, 3);
  V v_t_246 = heff_rec_n(2, shape_c__vars, (V[]){v_c_240, NTAG(TAG_Nil)});
  HeffT2 v_t_247 = ({ V a_0 = v_byName_244; V a_1 = v_tag_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_244); r_; });
  V v_t_2413;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_i_2410 = v_field_249;
      V v_xs_2411 = v_values_245;
      if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2410, 1) && heff_intLt_c(heff_dup(v_i_2410), heff_arrayLength_lent(v_xs_2411, 0)))) {
        V v_ts_2412 = heff_arrayIndex(v_xs_2411, v_i_2410);
        v_t_2413 = (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_2412)));
      } else {
        heff_drop(v_i_2410);
        heff_drop(v_xs_2411);
        v_t_2413 = NTAG(TAG_Nil);
      }
    } else {
      heff_drop(v_values_245);
      heff_drop(v_field_249);
      v_t_2413 = NTAG(TAG_Nil);
    }
  }
  V v_t_2414 = (g_heff_2ecompile_2eerase_2ezipE(v_xs_243, v_t_2413));
  return (g_heff_2ecompile_2eerase_2earmBindGo(v_t_246, v_t_2414));
}
V g_heff_2ecompile_2eerase_2earmBind_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2earmBind(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}

HeffT2 g_heff_2ecompile_2eerase_2enthLocal_24cpr(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_l_242)}});
    } else {
      if (heff_intLt_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_entry, 1, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ecatMaybesE(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str2, 0, "");
Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(V v_c_240, V v_abs_241, V v_ty_242) {
top: ;
  return (g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145), v_c_240, v_abs_241, v_ty_242, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str0), ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str1), ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str2)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry, 4, 0};

V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V v_c_240, V v_vs_241, V v_ty_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_tag_244 = heff_field(v_x5_243, 0);
    V v_x52_245 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    switch (heff_tag_of(v_x52_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_x52_245, 0);
      V v_body_247 = heff_field(v_x52_245, 1);
      heff_take_n(v_x52_245, 3ULL, 2);
      V v_m_248 = (g_heff_2ecompile_2eerase_2earmBind(v_c_240, v_vs_241, v_tag_244, heff_arrayToList(v_xs_246)));
      return heff_clo_n(g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0, 1, 4, (V[]){v_m_248, v_body_247, v_ty_242, v_tag_244});
    }
    default: return heff_nomatch(v_x52_245);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_body_247 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_tag_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Left: {
    V v_e_2411 = heff_field(v_x2_2410, 0);
    V v_ru_24x2_2410_24Left = heff_take_reuse_n(v_x2_2410, 1ULL, 1);
    heff_drop(v_body_247);
    heff_drop(v_ty_242);
    heff_drop(v_tag_244);
    return heff_tag_at_n(v_ru_24x2_2410_24Left, TAG_Left, 1, (V[]){v_e_2411});
  }
  case TAG_Right: {
    V v_x21_2412 = heff_field(v_x2_2410, 0);
    V v_ru_24x2_2410_24Right = heff_take_reuse_n(v_x2_2410, 1ULL, 1);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x21_2412, 0);
      V v_n_2414 = heff_field(v_x21_2412, 1);
      V v_ru_24x21_2412_24MkPair = heff_take_reuse_n(v_x21_2412, 3ULL, 2);
      V v_c_2415 = heff_take_field(v_x_2413, 0);
      V v_vars_2416 = heff_get_n(v_x_2413, 1, 2);
      V v_m_2417 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_2415, v_body_247, v_ty_242));
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2414}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x2_2418, 0);
        V v_ru_24x2_2418_24Left = heff_take_reuse_n(v_x2_2418, 1ULL, 1);
        heff_drop(v_tag_244);
        heff_drop_cell(v_ru_24x2_2410_24Right, 1);
        heff_drop_cell(v_ru_24x21_2412_24MkPair, 2);
        heff_drop(v_vars_2416);
        return heff_tag_at_n(v_ru_24x2_2418_24Left, TAG_Left, 1, (V[]){v_e_2419});
      }
      case TAG_Right: {
        V v_x21_2420 = heff_field(v_x2_2418, 0);
        heff_take_n(v_x2_2418, 1ULL, 1);
        switch (heff_tag_of(v_x21_2420)) {
        case TAG_MkPair: {
          V v_x_2421 = heff_field(v_x21_2420, 0);
          V v_n_2422 = heff_field(v_x21_2420, 1);
          heff_take_n(v_x21_2420, 3ULL, 2);
          V v_t_2423 = heff_tag_at_n(v_ru_24x21_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_244, v_vars_2416, v_x_2421}), v_n_2422});
          return heff_tag_at_n(v_ru_24x2_2410_24Right, TAG_Right, 1, (V[]){v_t_2423});
        }
        default: return heff_nomatch(v_x21_2420);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x21_2412);
    }
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str0, 22, "a type used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str1, 16, "an unbound local");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str2, 9, "the type ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str3, 16, " used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str4, 9, "the type ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str5, 16, " used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str6, 10, "no global ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str7, 10, "no global ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str8, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str9, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str10, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str11, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str12, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str13, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str14, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str15, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str16, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str17, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str18, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str19, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str20, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str21, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str22, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str23, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str24, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str25, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str26, 13, "prelude.Bytes");
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam31(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam32(V self, V *args);
Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry, 2, 0};

V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V v_c_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_c_240, 0, 4); V a_1 = v_i_242; HeffT2 r_ = (g_heff_2ecompile_2eerase_2enthLocal_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_l_246 = v_field_245;
        V v_ir_247 = heff_take_field(v_l_246, 0);
        V v_ty_248 = heff_get_n(v_l_246, 1, 2);
        switch (heff_tag_of(v_ir_247)) {
        case TAG_Nothing: {
          heff_drop(v_ty_248);
          return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0_clo);
        }
        case TAG_Just: {
          V v_x_2410 = heff_field(v_ir_247, 0);
          heff_take_n(v_ir_247, 1ULL, 1);
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1, 1, 2, (V[]){v_x_2410, v_ty_248});
        }
        default: return heff_nomatch(v_ir_247);
        }
      } else {
        heff_drop(v_field_245);
        return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2_clo);
      }
    }
  }
  case TAG_SGlobal: {
    V v_x_2414 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_g_2415 = heff_get_n(v_c_240, 3, 4);
    V v_entries_2416 = heff_take_field(v_g_2415, 1);
    V v_aliases_2417 = heff_get_n(v_g_2415, 2, 8);
    HeffT2 v_t_2418 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_entries_2416, v_x_2414));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_entries_2416);
        heff_drop(v_aliases_2417);
        V v_e_2421 = v_field_2420;
        V v_t_2422 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2421, 3))));
        if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
          heff_drop_rec(v_e_2421, 4);
          heff_drop(v_t_2422);
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3, 1, 1, (V[]){v_x_2414});
        } else {
          heff_drop(v_t_2422);
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4, 1, 2, (V[]){v_x_2414, v_e_2421});
        }
      } else {
        heff_drop(v_field_2420);
        HeffT2 v_t_2427 = ({ V a_0 = v_aliases_2417; V a_1 = v_x_2414; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_aliases_2417); r_; });
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_k2_2430 = v_field_2429;
            HeffT2 v_t_2431 = ({ V a_0 = v_entries_2416; V a_1 = v_k2_2430; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_entries_2416); heff_drop(v_k2_2430); r_; });
            {
              V v_field_2433 = v_t_2431.f[1];
              int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
              if ((v_tag_2432 == ((int64_t)0ULL))) {
                V v_e_2434 = v_field_2433;
                V v_t_2435 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2434, 3))));
                if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
                  heff_drop_rec(v_e_2434, 4);
                  heff_drop(v_t_2435);
                  return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5, 1, 1, (V[]){v_x_2414});
                } else {
                  heff_drop(v_t_2435);
                  return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6, 1, 2, (V[]){v_x_2414, v_e_2434});
                }
              } else {
                heff_drop(v_field_2433);
                return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7, 1, 1, (V[]){v_x_2414});
              }
            }
          } else {
            heff_drop(v_entries_2416);
            heff_drop(v_field_2429);
            return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8, 1, 1, (V[]){v_x_2414});
          }
        }
      }
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9_clo);
  }
  case TAG_SApp: {
    V v_f_2444 = heff_field(v_t_241, 0);
    V v_a_2445 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_2446 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_f_2444));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10, 1, 3, (V[]){v_m_2446, v_c_240, v_a_2445});
  }
  case TAG_SLam: {
    V v_ty_24105 = heff_field(v_t_241, 0);
    V v_abs_24106 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    HeffT2 v_t_24107 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_ty_24105), heff_dup(heff_rfield(v_c_240, 1))));
    {
      V v_field_24109 = v_t_24107.f[1];
      int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
      V v_ty_24113;
      if ((v_tag_24108 == ((int64_t)0ULL))) {
        V v_x_24110 = v_field_24109;
        v_ty_24113 = v_x_24110;
      } else {
        if ((v_tag_24108 == ((int64_t)1ULL))) {
          V v_x11_24111 = v_field_24109;
          heff_drop(v_x11_24111);
          v_ty_24113 = heff_abandon();
        } else {
          V v_x_24112 = v_field_24109;
          v_ty_24113 = v_x_24112;
        }
      }
      V v_m_24114 = (g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(heff_dup(v_c_240), v_abs_24106, v_ty_24113));
      return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13, 1, 3, (V[]){v_m_24114, v_c_240, v_ty_24105});
    }
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14_clo);
  }
  case TAG_SProj: {
    V v_e_24131 = heff_field(v_t_241, 0);
    V v_l_24132 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24133 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), heff_dup(v_e_24131)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15, 1, 4, (V[]){v_m_24133, v_c_240, v_e_24131, v_l_24132});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17_clo);
  }
  case TAG_SMatch: {
    V v_scrut_24220 = heff_field(v_t_241, 0);
    V v_cases_24221 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_keys_24222 = heff_take_field(v_cases_24221, 0);
    V v_values_24223 = heff_get_n(v_cases_24221, 2, 3);
    V v_m_24224 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_scrut_24220));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18, 1, 4, (V[]){v_m_24224, v_keys_24222, v_values_24223, v_c_240});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20_clo);
  }
  case TAG_SIs: {
    V v_t2_24259 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24259;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21_clo);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22_clo);
  }
  case TAG_SRec: {
    V v_t2_24262 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24262;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_ty_24263 = heff_field(v_t_241, 0);
    V v_abs_24264 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SFix = heff_take_reuse_n(v_t_241, 3ULL, 2);
    HeffT2 v_t_24265 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_ty_24263), heff_dup(heff_rfield(v_c_240, 1))));
    {
      V v_field_24267 = v_t_24265.f[1];
      int64_t v_tag_24266 = ((int64_t)v_t_24265.f[0]);
      V v_ty_24271;
      if ((v_tag_24266 == ((int64_t)0ULL))) {
        V v_x_24268 = v_field_24267;
        v_ty_24271 = v_x_24268;
      } else {
        if ((v_tag_24266 == ((int64_t)1ULL))) {
          V v_x11_24269 = v_field_24267;
          heff_drop(v_x11_24269);
          v_ty_24271 = heff_abandon();
        } else {
          V v_x_24270 = v_field_24267;
          v_ty_24271 = v_x_24270;
        }
      }
      V v_m_24272 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_tag_at_n(v_ru_24t_241_24SFix, TAG_SFix, 2, (V[]){heff_dup(v_ty_24263), v_abs_24264}), v_ty_24271));
      return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23, 1, 3, (V[]){v_m_24272, v_c_240, v_ty_24263});
    }
  }
  case TAG_SImplicit: {
    V v_t2_24288 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t2_24288;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24_clo);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25_clo);
  }
  case TAG_SLitInt: {
    V v_i_24295 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26, 1, 1, (V[]){v_i_24295});
  }
  case TAG_SLitFloat: {
    V v_x_24298 = heff_tget_v(v_t_241, 0);
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27, 1, 1, (V[]){v_x_24298});
  }
  case TAG_SLitString: {
    V v_s_24301 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28, 1, 1, (V[]){v_s_24301});
  }
  case TAG_SLitBytes: {
    V v_s_24304 = heff_field(v_t_241, 0);
    V v_ru_24t_241_24SLitBytes = heff_take_reuse_n(v_t_241, 1ULL, 1);
    V v_t_24305 = heff_get_n(heff_get_n(v_c_240, 3, 4), 1, 8);
    HeffT2 v_t_24306 = ({ V a_0 = v_t_24305; V b_1 = ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str26); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_t_24305); heff_drop(b_1); r_; });
    V v_t_24310;
    {
      V v_field_24308 = v_t_24306.f[1];
      int64_t v_tag_24307 = ((int64_t)v_t_24306.f[0]);
      if ((v_tag_24307 == ((int64_t)0ULL))) {
        V v_e_24309 = v_field_24308;
        v_t_24310 = v_e_24309;
      } else {
        heff_drop(v_field_24308);
        v_t_24310 = heff_abandon();
      }
    }
    V v_t_24311 = heff_tag_at_n(v_ru_24t_241_24SLitBytes, TAG_Nom, 1, (V[]){heff_get_n(v_t_24310, 2, 4)});
    HeffT2 v_t_24312 = ({ V a_0 = v_t_24311; HeffT2 r_ = (g_heff_2eelab_2evalue_2edecodeEv_24cpr(a_0)); heff_drop_tag(v_t_24311, 1); r_; });
    V v_t_24318;
    {
      V v_field_24314 = v_t_24312.f[1];
      int64_t v_tag_24313 = ((int64_t)v_t_24312.f[0]);
      if ((v_tag_24313 == ((int64_t)0ULL))) {
        V v_x_24315 = v_field_24314;
        v_t_24318 = v_x_24315;
      } else {
        if ((v_tag_24313 == ((int64_t)1ULL))) {
          V v_x11_24316 = v_field_24314;
          heff_drop(v_x11_24316);
          v_t_24318 = heff_abandon();
        } else {
          V v_x_24317 = v_field_24314;
          v_t_24318 = v_x_24317;
        }
      }
    }
    V v_x_24319 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EBytes, 1, (V[]){v_s_24304}), v_t_24318});
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29, 1, 1, (V[]){v_x_24319});
  }
  case TAG_SLitRune: {
    V v_n_24321 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30, 1, 1, (V[]){v_n_24321});
  }
  case TAG_SLitFixed: {
    V v_w_24325 = heff_field(v_t_241, 0);
    V v_n_24326 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam31, 1, 2, (V[]){v_w_24325, v_n_24326});
  }
  case TAG_SLitFloat32: {
    V v_x_24329 = heff_tget_v(v_t_241, 0);
    heff_take_na(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam32, 1, 1, (V[]){v_x_24329});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0(V self, V *args) {
  V v_n_249 = args[0];
  heff_drop(v_n_249);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str0)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_ty_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_ty_248}), v_n_2411});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_2412});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2(V self, V *args) {
  V v_n_2413 = args[0];
  heff_drop(v_n_2413);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str1)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3(V self, V *args) {
  V v_n_2423 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2423);
  V v_t_2424 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str2), v_x_2414), ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str3));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2424});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2421 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2414}), heff_get_n(v_e_2421, 3, 4)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2426, v_n_2425})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5(V self, V *args) {
  V v_n_2436 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2436);
  V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str4), v_x_2414), ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str5));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2437});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6(V self, V *args) {
  V v_n_2438 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2414}), heff_get_n(v_e_2434, 3, 4)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_n_2438})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7(V self, V *args) {
  V v_n_2440 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2440);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str6), v_x_2414)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8(V self, V *args) {
  V v_n_2441 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2441);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str7), v_x_2414)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9(V self, V *args) {
  V v_n_2443 = args[0];
  heff_drop(v_n_2443);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str8)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11(V self, V *args) {
  V v_u_2465 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2465);
  V v_x1_2466 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_a_2445, heff_get_n(v_c_240, 1, 4)));
  switch (heff_tag_of(v_x1_2466)) {
  case TAG_Nom: {
    V v_x_2467 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    return v_x_2467;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2466, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2469 = heff_field(v_x1_2466, 0);
    heff_take_n(v_x1_2466, 1ULL, 1);
    return v_x_2469;
  }
  default: return heff_nomatch(v_x1_2466);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12(V self, V *args) {
  V v_u_2487 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2445 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2487);
  V v_x1_2488 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_a_2445, heff_get_n(v_c_240, 1, 4)));
  switch (heff_tag_of(v_x1_2488)) {
  case TAG_Nom: {
    V v_x_2489 = heff_field(v_x1_2488, 0);
    heff_take_n(v_x1_2488, 1ULL, 1);
    return v_x_2489;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2488, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2491 = heff_field(v_x1_2488, 0);
    heff_take_n(v_x1_2488, 1ULL, 1);
    return v_x_2491;
  }
  default: return heff_nomatch(v_x1_2488);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10(V self, V *args) {
  V v_n_2447 = args[0];
  V v_m_2446 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_a_2445 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2448 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2447}));
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_Left: {
    V v_e_2449 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Left = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_a_2445);
    return heff_tag_at_n(v_ru_24x2_2448_24Left, TAG_Left, 1, (V[]){v_e_2449});
  }
  case TAG_Right: {
    V v_x21_2450 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Right = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    switch (heff_tag_of(v_x21_2450)) {
    case TAG_MkPair: {
      V v_x_2451 = heff_field(v_x21_2450, 0);
      V v_n_2452 = heff_field(v_x21_2450, 1);
      V v_ru_24x21_2450_24MkPair = heff_take_reuse_n(v_x21_2450, 3ULL, 2);
      switch (heff_tag_of(v_x_2451)) {
      case TAG_MkPair: {
        V v_f_27_2453 = heff_field(v_x_2451, 0);
        V v_fty_2454 = heff_field(v_x_2451, 1);
        V v_ru_24x_2451_24MkPair = heff_take_reuse_n(v_x_2451, 3ULL, 2);
        V v_t_2455 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2454));
        switch (heff_tag_of(v_t_2455)) {
        case TAG_LikeU: {
          V v_ru_24t_2455_24LikeU = heff_take_reuse_n(v_t_2455, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2455_24LikeU, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str9)});
        }
        case TAG_LikeFunction: {
          V v_dom_2458 = heff_field(v_t_2455, 1);
          V v_cod_2459 = heff_field(v_t_2455, 2);
          heff_take_n(v_t_2455, 6ULL, 4);
          V v_t_2461 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_2458)));
          if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
            heff_drop(v_dom_2458);
            heff_drop(v_t_2461);
            V v_x1_2471;
            switch (heff_tag_of(v_cod_2459)) {
            case TAG_MkClo: {
              V v_vs_2463 = heff_field(v_cod_2459, 1);
              V v_body_2464 = heff_field(v_cod_2459, 2);
              heff_take_n(v_cod_2459, 6ULL, 3);
              v_x1_2471 = heff_tr(heff_call(v_body_2464, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2463, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11, 1, 2, (V[]){v_c_240, v_a_2445})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2470 = heff_field(v_cod_2459, 0);
              heff_take_n(v_cod_2459, 1ULL, 1);
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_a_2445);
              v_x1_2471 = v_body_2470;
              break;
            }
            default: heff_nomatch(v_cod_2459);
            }
            V v_t_2475;
            switch (heff_tag_of(v_x1_2471)) {
            case TAG_Nom: {
              V v_x_2472 = heff_field(v_x1_2471, 0);
              heff_take_n(v_x1_2471, 1ULL, 1);
              v_t_2475 = v_x_2472;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2471, 0ULL, 1);
              v_t_2475 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2474 = heff_field(v_x1_2471, 0);
              heff_take_n(v_x1_2471, 1ULL, 1);
              v_t_2475 = v_x_2474;
              break;
            }
            default: heff_nomatch(v_x1_2471);
            }
            V v_x_2476 = heff_tag_at_n(v_ru_24x21_2450_24MkPair, TAG_MkPair, 2, (V[]){v_f_27_2453, v_t_2475});
            return heff_tag_at_n(v_ru_24x2_2448_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x_2451_24MkPair, TAG_MkPair, 2, (V[]){v_x_2476, v_n_2452})});
          } else {
            heff_drop(v_t_2461);
            V v_m_2477 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_a_2445), v_dom_2458));
            V v_x2_2478 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_n_2452}));
            switch (heff_tag_of(v_x2_2478)) {
            case TAG_Left: {
              V v_e_2479 = heff_field(v_x2_2478, 0);
              V v_ru_24x2_2478_24Left = heff_take_reuse_n(v_x2_2478, 1ULL, 1);
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_a_2445);
              heff_drop_cell(v_ru_24x2_2448_24Right, 1);
              heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
              heff_drop(v_f_27_2453);
              heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
              heff_drop(v_cod_2459);
              return heff_tag_at_n(v_ru_24x2_2478_24Left, TAG_Left, 1, (V[]){v_e_2479});
            }
            case TAG_Right: {
              V v_x21_2480 = heff_field(v_x2_2478, 0);
              heff_take_n(v_x2_2478, 1ULL, 1);
              switch (heff_tag_of(v_x21_2480)) {
              case TAG_MkPair: {
                V v_x_2481 = heff_field(v_x21_2480, 0);
                V v_n_2482 = heff_field(v_x21_2480, 1);
                V v_ru_24x21_2480_24MkPair = heff_take_reuse_n(v_x21_2480, 3ULL, 2);
                V v_t_2483 = heff_tag_at_n(v_ru_24x21_2480_24MkPair, TAG_Cons, 2, (V[]){v_x_2481, NTAG(TAG_Nil)});
                V v_x1_2493;
                switch (heff_tag_of(v_cod_2459)) {
                case TAG_MkClo: {
                  V v_vs_2485 = heff_field(v_cod_2459, 1);
                  V v_body_2486 = heff_field(v_cod_2459, 2);
                  heff_take_n(v_cod_2459, 6ULL, 3);
                  v_x1_2493 = heff_tr(heff_call(v_body_2486, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2485, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12, 1, 2, (V[]){v_c_240, v_a_2445})})}));
                  break;
                }
                case TAG_CloConst: {
                  V v_body_2492 = heff_field(v_cod_2459, 0);
                  heff_take_n(v_cod_2459, 1ULL, 1);
                  heff_drop_rec(v_c_240, 4);
                  heff_drop(v_a_2445);
                  v_x1_2493 = v_body_2492;
                  break;
                }
                default: heff_nomatch(v_cod_2459);
                }
                V v_t_2497;
                switch (heff_tag_of(v_x1_2493)) {
                case TAG_Nom: {
                  V v_x_2494 = heff_field(v_x1_2493, 0);
                  heff_take_n(v_x1_2493, 1ULL, 1);
                  v_t_2497 = v_x_2494;
                  break;
                }
                case TAG_Describe: {
                  heff_take_n(v_x1_2493, 0ULL, 1);
                  v_t_2497 = heff_abandon();
                  break;
                }
                case TAG_Become: {
                  V v_x_2496 = heff_field(v_x1_2493, 0);
                  heff_take_n(v_x1_2493, 1ULL, 1);
                  v_t_2497 = v_x_2496;
                  break;
                }
                default: heff_nomatch(v_x1_2493);
                }
                V v_x_2498 = heff_tag_at_n(v_ru_24x21_2450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2453, v_t_2483}), v_t_2497});
                return heff_tag_at_n(v_ru_24x2_2448_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x_2451_24MkPair, TAG_MkPair, 2, (V[]){v_x_2498, v_n_2482})});
              }
              default: return heff_nomatch(v_x21_2480);
              }
            }
            default: return heff_nomatch(v_x2_2478);
            }
          }
        }
        case TAG_LikeRecord: {
          heff_take_n(v_t_2455, 0ULL, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str10)});
        }
        case TAG_LikeSum: {
          V v_ru_24t_2455_24LikeSum = heff_take_reuse_n(v_t_2455, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2455_24LikeSum, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str11)});
        }
        case TAG_LikeInt: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str12)});
        }
        case TAG_LikeFloat: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str13)});
        }
        case TAG_LikeString: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str14)});
        }
        case TAG_LikeRune: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str15)});
        }
        case TAG_LikeArray: {
          V v_ru_24t_2455_24LikeArray = heff_take_reuse_n(v_t_2455, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2455_24LikeArray, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str16)});
        }
        case TAG_LikeFixed: {
          V v_ru_24t_2455_24LikeFixed = heff_take_reuse_n(v_t_2455, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_2455_24LikeFixed, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str17)});
        }
        case TAG_NoRules: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2445);
          heff_drop_cell(v_ru_24x2_2448_24Right, 1);
          heff_drop(v_n_2452);
          heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
          heff_drop(v_f_27_2453);
          heff_drop_cell(v_ru_24x_2451_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str18)});
        }
        default: return heff_nomatch(v_t_2455);
        }
      }
      default: return heff_nomatch(v_x_2451);
      }
    }
    default: return heff_nomatch(v_x21_2450);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13(V self, V *args) {
  V v_n_24115 = args[0];
  V v_m_24114 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24105 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24116 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_n_24115}));
  switch (heff_tag_of(v_x2_24116)) {
  case TAG_Left: {
    V v_e_24117 = heff_field(v_x2_24116, 0);
    V v_ru_24x2_24116_24Left = heff_take_reuse_n(v_x2_24116, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_24105);
    return heff_tag_at_n(v_ru_24x2_24116_24Left, TAG_Left, 1, (V[]){v_e_24117});
  }
  case TAG_Right: {
    V v_x21_24118 = heff_field(v_x2_24116, 0);
    V v_ru_24x2_24116_24Right = heff_take_reuse_n(v_x2_24116, 1ULL, 1);
    switch (heff_tag_of(v_x21_24118)) {
    case TAG_MkPair: {
      V v_x_24119 = heff_field(v_x21_24118, 0);
      V v_n_24120 = heff_field(v_x21_24118, 1);
      V v_ru_24x21_24118_24MkPair = heff_take_reuse_n(v_x21_24118, 3ULL, 2);
      HeffT2 v_t_24121 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_ty_24105, heff_get_n(v_c_240, 1, 4)));
      V v_t_24127;
      {
        V v_field_24123 = v_t_24121.f[1];
        int64_t v_tag_24122 = ((int64_t)v_t_24121.f[0]);
        if ((v_tag_24122 == ((int64_t)0ULL))) {
          V v_x_24124 = v_field_24123;
          v_t_24127 = v_x_24124;
        } else {
          if ((v_tag_24122 == ((int64_t)1ULL))) {
            V v_x11_24125 = v_field_24123;
            heff_drop(v_x11_24125);
            v_t_24127 = heff_abandon();
          } else {
            V v_x_24126 = v_field_24123;
            v_t_24127 = v_x_24126;
          }
        }
      }
      V v_x_24128 = heff_tag_at_n(v_ru_24x21_24118_24MkPair, TAG_MkPair, 2, (V[]){v_x_24119, v_t_24127});
      return heff_tag_at_n(v_ru_24x2_24116_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24128, v_n_24120})});
    }
    default: return heff_nomatch(v_x21_24118);
    }
  }
  default: return heff_nomatch(v_x2_24116);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14(V self, V *args) {
  V v_n_24130 = args[0];
  heff_drop(v_n_24130);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str19)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16(V self, V *args) {
  V v_k_24175 = args[0];
  V v_len_24159 = heff_env(self)[0];
  V v_t_24160 = heff_env(self)[1];
  V v_fs_24161 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_len_24176 = v_len_24159;
  V v_t_24177 = heff_dup(v_t_24160);
  V v_k_24178 = heff_dup(v_k_24175);
  HeffT2 v_t_24179 = ({ V a_0 = v_t_24160; V a_1 = v_fs_24161; V a_2 = v_k_24175; HeffT2 r_ = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(a_0, a_1, a_2)); heff_drop(v_fs_24161); r_; });
  V v_t_24200;
  {
    V v_field_24181 = v_t_24179.f[1];
    int64_t v_tag_24180 = ((int64_t)v_t_24179.f[0]);
    if ((v_tag_24180 == ((int64_t)0ULL))) {
      heff_drop(v_len_24176);
      heff_drop(v_t_24177);
      heff_drop(v_k_24178);
      V v_ty_24182 = v_field_24181;
      v_t_24200 = heff_tag_n(TAG_Just, 1, (V[]){v_ty_24182});
    } else {
      heff_drop(v_field_24181);
      V v_x3_24183 = (g_heff_2eelab_2evalue_2ebehavior(v_t_24177));
      switch (heff_tag_of(v_x3_24183)) {
      case TAG_LikeU: {
        heff_take_n(v_x3_24183, 0ULL, 1);
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x3_24183, 0ULL, 4);
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeRecord: {
        V v_capture_24190 = heff_field(v_x3_24183, 1);
        V v_fieldTypes_24191 = heff_field(v_x3_24183, 2);
        heff_take_n(v_x3_24183, 6ULL, 3);
        HeffT2 v_t_24192 = ({ V a_0 = heff_rfield(v_fieldTypes_24191, 1); V a_1 = v_k_24178; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_k_24178); r_; });
        V v_t_24196;
        {
          V v_field_24194 = v_t_24192.f[1];
          int64_t v_tag_24193 = ((int64_t)v_t_24192.f[0]);
          if ((v_tag_24193 == ((int64_t)0ULL))) {
            V v_i_24195 = v_field_24194;
            v_t_24196 = v_i_24195;
          } else {
            heff_drop(v_field_24194);
            v_t_24196 = heff_abandon();
          }
        }
        v_t_24200 = (g_heff_2eelab_2erules_2efieldTyAt(v_len_24176, v_capture_24190, v_fieldTypes_24191, v_t_24196, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x3_24183, 0ULL, 1);
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeInt: {
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeFloat: {
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeString: {
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeRune: {
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x3_24183, 0ULL, 1);
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_LikeFixed: {
        heff_take_n(v_x3_24183, 0ULL, 1);
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_NoRules: {
        heff_drop(v_len_24176);
        heff_drop(v_k_24178);
        v_t_24200 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x3_24183);
      }
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_k_24175, v_t_24200});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15(V self, V *args) {
  V v_n_24134 = args[0];
  V v_m_24133 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_24131 = heff_env(self)[2];
  V v_l_24132 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24135 = heff_tr(heff_call(v_m_24133, 1, (V[]){v_n_24134}));
  switch (heff_tag_of(v_x2_24135)) {
  case TAG_Left: {
    V v_e_24136 = heff_field(v_x2_24135, 0);
    V v_ru_24x2_24135_24Left = heff_take_reuse_n(v_x2_24135, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_e_24131);
    heff_drop(v_l_24132);
    return heff_tag_at_n(v_ru_24x2_24135_24Left, TAG_Left, 1, (V[]){v_e_24136});
  }
  case TAG_Right: {
    V v_x21_24137 = heff_field(v_x2_24135, 0);
    V v_ru_24x2_24135_24Right = heff_take_reuse_n(v_x2_24135, 1ULL, 1);
    switch (heff_tag_of(v_x21_24137)) {
    case TAG_MkPair: {
      V v_x_24138 = heff_field(v_x21_24137, 0);
      V v_n_24139 = heff_field(v_x21_24137, 1);
      V v_ru_24x21_24137_24MkPair = heff_take_reuse_n(v_x21_24137, 3ULL, 2);
      switch (heff_tag_of(v_x_24138)) {
      case TAG_MkPair: {
        V v_e_27_24140 = heff_field(v_x_24138, 0);
        V v_ety_24141 = heff_field(v_x_24138, 1);
        V v_ru_24x_24138_24MkPair = heff_take_reuse_n(v_x_24138, 3ULL, 2);
        V v_x1_24142 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_e_24131), heff_dup(heff_rfield(v_c_240, 1))));
        V v_v_24146;
        switch (heff_tag_of(v_x1_24142)) {
        case TAG_Nom: {
          V v_x_24143 = heff_field(v_x1_24142, 0);
          heff_take_n(v_x1_24142, 1ULL, 1);
          v_v_24146 = v_x_24143;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24142, 0ULL, 1);
          v_v_24146 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24145 = heff_field(v_x1_24142, 0);
          heff_take_n(v_x1_24142, 1ULL, 1);
          v_v_24146 = v_x_24145;
          break;
        }
        default: heff_nomatch(v_x1_24142);
        }
        V v_t_24147 = ({ V a_0 = v_v_24146; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop(v_v_24146); r_; });
        V v_m_24148 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 2)); V a_1 = heff_dup(v_ety_24141); V a_2 = v_t_24147; V a_3 = heff_dup(v_l_24132); V r_ = (g_heff_2ecompile_2eerase_2eprojTyInWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_24147); r_; });
        V v_x2_24149 = heff_tr(heff_call(v_m_24148, 1, (V[]){v_n_24139}));
        switch (heff_tag_of(v_x2_24149)) {
        case TAG_Left: {
          V v_e_24150 = heff_field(v_x2_24149, 0);
          V v_ru_24x2_24149_24Left = heff_take_reuse_n(v_x2_24149, 1ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_e_24131);
          heff_drop(v_l_24132);
          heff_drop_cell(v_ru_24x2_24135_24Right, 1);
          heff_drop_cell(v_ru_24x21_24137_24MkPair, 2);
          heff_drop(v_e_27_24140);
          heff_drop(v_ety_24141);
          heff_drop_cell(v_ru_24x_24138_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_24149_24Left, TAG_Left, 1, (V[]){v_e_24150});
        }
        case TAG_Right: {
          V v_x21_24151 = heff_field(v_x2_24149, 0);
          V v_ru_24x2_24149_24Right = heff_take_reuse_n(v_x2_24149, 1ULL, 1);
          switch (heff_tag_of(v_x21_24151)) {
          case TAG_MkPair: {
            V v_x_24152 = heff_field(v_x21_24151, 0);
            V v_n_24153 = heff_field(v_x21_24151, 1);
            V v_ru_24x21_24151_24MkPair = heff_take_reuse_n(v_x21_24151, 3ULL, 2);
            V v_x1_24154 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_e_24131, heff_take_field(v_c_240, 1)));
            V v_v_24158;
            switch (heff_tag_of(v_x1_24154)) {
            case TAG_Nom: {
              V v_x_24155 = heff_field(v_x1_24154, 0);
              heff_take_n(v_x1_24154, 1ULL, 1);
              v_v_24158 = v_x_24155;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_24154, 0ULL, 1);
              v_v_24158 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_24157 = heff_field(v_x1_24154, 0);
              heff_take_n(v_x1_24154, 1ULL, 1);
              v_v_24158 = v_x_24157;
              break;
            }
            default: heff_nomatch(v_x1_24154);
            }
            V v_len_24159 = heff_get_n(v_c_240, 2, 4);
            V v_t_24160 = v_ety_24141;
            V v_fs_24161 = ({ V a_0 = v_v_24158; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop(v_v_24158); r_; });
            V v_x1_24162 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_24160)));
            V v_t_24174;
            switch (heff_tag_of(v_x1_24162)) {
            case TAG_LikeU: {
              heff_take_n(v_x1_24162, 0ULL, 1);
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeFunction: {
              heff_take_n(v_x1_24162, 0ULL, 4);
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeRecord: {
              V v_fieldTypes_24170 = heff_field(v_x1_24162, 2);
              heff_take_n(v_x1_24162, 4ULL, 3);
              v_t_24174 = heff_arrayToList(heff_get_n(v_fieldTypes_24170, 0, 3));
              break;
            }
            case TAG_LikeSum: {
              heff_take_n(v_x1_24162, 0ULL, 1);
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeInt: {
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeFloat: {
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeString: {
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeRune: {
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeArray: {
              heff_take_n(v_x1_24162, 0ULL, 1);
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_LikeFixed: {
              heff_take_n(v_x1_24162, 0ULL, 1);
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            case TAG_NoRules: {
              v_t_24174 = NTAG(TAG_Nil);
              break;
            }
            default: heff_nomatch(v_x1_24162);
            }
            V v_t_24201 = (g_list_2emap_24tok2(v_ru_24x21_24151_24MkPair, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16, 1, 3, (V[]){heff_dup(v_len_24159), v_t_24160, v_fs_24161}), v_t_24174));
            V v_t_24202 = (g_heff_2ecompile_2eerase_2ekeptOf(v_len_24159, NTAG(TAG_Nil), v_t_24201));
            V v_x1_24203 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_24152)));
            V v_t_24215;
            switch (heff_tag_of(v_x1_24203)) {
            case TAG_LikeU: {
              heff_take_n(v_x1_24203, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFunction: {
              heff_take_n(v_x1_24203, 0ULL, 4);
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRecord: {
              heff_take_n(v_x1_24203, 0ULL, 3);
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeSum: {
              heff_take_n(v_x1_24203, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeInt: {
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFloat: {
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtFloat);
              break;
            }
            case TAG_LikeString: {
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRune: {
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeArray: {
              heff_take_n(v_x1_24203, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFixed: {
              V v_w_24214 = heff_field(v_x1_24203, 0);
              heff_take_n(v_x1_24203, 1ULL, 1);
              v_t_24215 = heff_tag_at_n(v_ru_24x2_24149_24Right, TAG_FtFixed, 1, (V[]){v_w_24214});
              break;
            }
            case TAG_NoRules: {
              heff_drop_cell(v_ru_24x2_24149_24Right, 1);
              v_t_24215 = NTAG(TAG_FtAny);
              break;
            }
            default: heff_nomatch(v_x1_24203);
            }
            V v_x_24216 = heff_tag_at_n(v_ru_24x21_24137_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_e_27_24140, v_l_24132, v_t_24202, v_t_24215}), v_x_24152});
            return heff_tag_at_n(v_ru_24x2_24135_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x_24138_24MkPair, TAG_MkPair, 2, (V[]){v_x_24216, v_n_24153})});
          }
          default: return heff_nomatch(v_x21_24151);
          }
        }
        default: return heff_nomatch(v_x2_24149);
        }
      }
      default: return heff_nomatch(v_x_24138);
      }
    }
    default: return heff_nomatch(v_x21_24137);
    }
  }
  default: return heff_nomatch(v_x2_24135);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17(V self, V *args) {
  V v_n_24219 = args[0];
  heff_drop(v_n_24219);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str20)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19(V self, V *args) {
  V v_p_24247 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24237 = heff_env(self)[1];
  V v_x_24244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_240, v_x_24237, v_x_24244, v_p_24247));
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18(V self, V *args) {
  V v_n_24225 = args[0];
  V v_m_24224 = heff_env(self)[0];
  V v_keys_24222 = heff_env(self)[1];
  V v_values_24223 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24226 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_n_24225}));
  switch (heff_tag_of(v_x2_24226)) {
  case TAG_Left: {
    V v_e_24227 = heff_field(v_x2_24226, 0);
    V v_ru_24x2_24226_24Left = heff_take_reuse_n(v_x2_24226, 1ULL, 1);
    heff_drop(v_keys_24222);
    heff_drop(v_values_24223);
    heff_drop_rec(v_c_240, 4);
    return heff_tag_at_n(v_ru_24x2_24226_24Left, TAG_Left, 1, (V[]){v_e_24227});
  }
  case TAG_Right: {
    V v_x21_24228 = heff_field(v_x2_24226, 0);
    V v_ru_24x2_24226_24Right = heff_take_reuse_n(v_x2_24226, 1ULL, 1);
    switch (heff_tag_of(v_x21_24228)) {
    case TAG_MkPair: {
      V v_x_24229 = heff_field(v_x21_24228, 0);
      V v_n_24230 = heff_field(v_x21_24228, 1);
      V v_ru_24x21_24228_24MkPair = heff_take_reuse_n(v_x21_24228, 3ULL, 2);
      switch (heff_tag_of(v_x_24229)) {
      case TAG_MkPair: {
        V v_s_27_24231 = heff_field(v_x_24229, 0);
        V v_sty_24232 = heff_field(v_x_24229, 1);
        V v_ru_24x_24229_24MkPair = heff_take_reuse_n(v_x_24229, 3ULL, 2);
        V v_m_24233 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24232));
        V v_x2_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_n_24230}));
        switch (heff_tag_of(v_x2_24234)) {
        case TAG_Left: {
          V v_e_24235 = heff_field(v_x2_24234, 0);
          V v_ru_24x2_24234_24Left = heff_take_reuse_n(v_x2_24234, 1ULL, 1);
          heff_drop(v_keys_24222);
          heff_drop(v_values_24223);
          heff_drop_rec(v_c_240, 4);
          heff_drop_cell(v_ru_24x2_24226_24Right, 1);
          heff_drop_cell(v_ru_24x21_24228_24MkPair, 2);
          heff_drop(v_s_27_24231);
          heff_drop_cell(v_ru_24x_24229_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_24234_24Left, TAG_Left, 1, (V[]){v_e_24235});
        }
        case TAG_Right: {
          V v_x21_24236 = heff_field(v_x2_24234, 0);
          V v_ru_24x2_24234_24Right = heff_take_reuse_n(v_x2_24234, 1ULL, 1);
          switch (heff_tag_of(v_x21_24236)) {
          case TAG_MkPair: {
            V v_x_24237 = heff_field(v_x21_24236, 0);
            V v_n_24238 = heff_field(v_x21_24236, 1);
            V v_ru_24x21_24236_24MkPair = heff_take_reuse_n(v_x21_24236, 3ULL, 2);
            V v_t_24239 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(heff_dup(v_keys_24222)), heff_arrayToList(heff_dup(v_values_24223))));
            V v_m_24240 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(heff_dup(v_c_240), heff_dup(v_x_24237), v_t_24239));
            V v_x2_24241 = heff_tr(heff_call(v_m_24240, 1, (V[]){v_n_24238}));
            switch (heff_tag_of(v_x2_24241)) {
            case TAG_Left: {
              V v_e_24242 = heff_field(v_x2_24241, 0);
              heff_take_n(v_x2_24241, 1ULL, 1);
              heff_drop(v_keys_24222);
              heff_drop(v_values_24223);
              heff_drop_rec(v_c_240, 4);
              heff_drop_cell(v_ru_24x2_24226_24Right, 1);
              heff_drop_cell(v_ru_24x21_24228_24MkPair, 2);
              heff_drop(v_s_27_24231);
              heff_drop_cell(v_ru_24x_24229_24MkPair, 2);
              heff_drop(v_x_24237);
              heff_drop_cell(v_ru_24x21_24236_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x2_24234_24Right, TAG_Left, 1, (V[]){v_e_24242});
            }
            case TAG_Right: {
              V v_x21_24243 = heff_field(v_x2_24241, 0);
              heff_take_n(v_x2_24241, 1ULL, 1);
              switch (heff_tag_of(v_x21_24243)) {
              case TAG_MkPair: {
                V v_x_24244 = heff_field(v_x21_24243, 0);
                V v_n_24245 = heff_field(v_x21_24243, 1);
                heff_take_n(v_x21_24243, 3ULL, 2);
                V v_t_24246 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_24222), heff_arrayToList(v_values_24223)));
                V v_m_24248 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19, 1, 3, (V[]){v_c_240, v_x_24237, heff_dup(v_x_24244)}), v_t_24246));
                V v_x2_24249 = heff_tr(heff_call(v_m_24248, 1, (V[]){v_n_24245}));
                switch (heff_tag_of(v_x2_24249)) {
                case TAG_Left: {
                  V v_e_24250 = heff_field(v_x2_24249, 0);
                  heff_take_n(v_x2_24249, 1ULL, 1);
                  heff_drop_cell(v_ru_24x2_24226_24Right, 1);
                  heff_drop_cell(v_ru_24x21_24228_24MkPair, 2);
                  heff_drop(v_s_27_24231);
                  heff_drop_cell(v_ru_24x_24229_24MkPair, 2);
                  heff_drop_cell(v_ru_24x21_24236_24MkPair, 2);
                  heff_drop(v_x_24244);
                  return heff_tag_at_n(v_ru_24x2_24234_24Right, TAG_Left, 1, (V[]){v_e_24250});
                }
                case TAG_Right: {
                  V v_x21_24251 = heff_field(v_x2_24249, 0);
                  heff_take_n(v_x2_24249, 1ULL, 1);
                  heff_drop_cell(v_ru_24x2_24234_24Right, 1);
                  switch (heff_tag_of(v_x21_24251)) {
                  case TAG_MkPair: {
                    V v_x_24252 = heff_field(v_x21_24251, 0);
                    V v_n_24253 = heff_field(v_x21_24251, 1);
                    heff_take_n(v_x21_24251, 3ULL, 2);
                    V v_t_24254 = heff_tag_at_n(v_ru_24x21_24228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x21_24236_24MkPair, TAG_EMatch, 2, (V[]){v_s_27_24231, v_x_24252}), v_x_24244});
                    return heff_tag_at_n(v_ru_24x2_24226_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x_24229_24MkPair, TAG_MkPair, 2, (V[]){v_t_24254, v_n_24253})});
                  }
                  default: return heff_nomatch(v_x21_24251);
                  }
                }
                default: return heff_nomatch(v_x2_24249);
                }
              }
              default: return heff_nomatch(v_x21_24243);
              }
            }
            default: return heff_nomatch(v_x2_24241);
            }
          }
          default: return heff_nomatch(v_x21_24236);
          }
        }
        default: return heff_nomatch(v_x2_24234);
        }
      }
      default: return heff_nomatch(v_x_24229);
      }
    }
    default: return heff_nomatch(v_x21_24228);
    }
  }
  default: return heff_nomatch(v_x2_24226);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20(V self, V *args) {
  V v_n_24258 = args[0];
  heff_drop(v_n_24258);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str21)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21(V self, V *args) {
  V v_n_24260 = args[0];
  heff_drop(v_n_24260);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str22)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22(V self, V *args) {
  V v_n_24261 = args[0];
  heff_drop(v_n_24261);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str23)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23(V self, V *args) {
  V v_n_24273 = args[0];
  V v_m_24272 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24263 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24274 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_n_24273}));
  switch (heff_tag_of(v_x2_24274)) {
  case TAG_Left: {
    V v_e_24275 = heff_field(v_x2_24274, 0);
    V v_ru_24x2_24274_24Left = heff_take_reuse_n(v_x2_24274, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_24263);
    return heff_tag_at_n(v_ru_24x2_24274_24Left, TAG_Left, 1, (V[]){v_e_24275});
  }
  case TAG_Right: {
    V v_x21_24276 = heff_field(v_x2_24274, 0);
    V v_ru_24x2_24274_24Right = heff_take_reuse_n(v_x2_24274, 1ULL, 1);
    switch (heff_tag_of(v_x21_24276)) {
    case TAG_MkPair: {
      V v_x_24277 = heff_field(v_x21_24276, 0);
      V v_n_24278 = heff_field(v_x21_24276, 1);
      V v_ru_24x21_24276_24MkPair = heff_take_reuse_n(v_x21_24276, 3ULL, 2);
      HeffT2 v_t_24279 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_ty_24263, heff_get_n(v_c_240, 1, 4)));
      V v_t_24285;
      {
        V v_field_24281 = v_t_24279.f[1];
        int64_t v_tag_24280 = ((int64_t)v_t_24279.f[0]);
        if ((v_tag_24280 == ((int64_t)0ULL))) {
          V v_x_24282 = v_field_24281;
          v_t_24285 = v_x_24282;
        } else {
          if ((v_tag_24280 == ((int64_t)1ULL))) {
            V v_x11_24283 = v_field_24281;
            heff_drop(v_x11_24283);
            v_t_24285 = heff_abandon();
          } else {
            V v_x_24284 = v_field_24281;
            v_t_24285 = v_x_24284;
          }
        }
      }
      V v_x_24286 = heff_tag_at_n(v_ru_24x21_24276_24MkPair, TAG_MkPair, 2, (V[]){v_x_24277, v_t_24285});
      return heff_tag_at_n(v_ru_24x2_24274_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24286, v_n_24278})});
    }
    default: return heff_nomatch(v_x21_24276);
    }
  }
  default: return heff_nomatch(v_x2_24274);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24(V self, V *args) {
  V v_n_24290 = args[0];
  heff_drop(v_n_24290);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str24)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25(V self, V *args) {
  V v_n_24294 = args[0];
  heff_drop(v_n_24294);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str25)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26(V self, V *args) {
  V v_n_24296 = args[0];
  V v_i_24295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24297 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_i_24295}), NTAG(TAG_VPrimInt)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24297, v_n_24296})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27(V self, V *args) {
  V v_n_24299 = args[0];
  V v_x_24298 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24300 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_EFloat, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_24298))}), NTAG(TAG_VPrimFloat)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24300, v_n_24299})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28(V self, V *args) {
  V v_n_24302 = args[0];
  V v_s_24301 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24303 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_s_24301}), NTAG(TAG_VPrimString)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24303, v_n_24302})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29(V self, V *args) {
  V v_n_24320 = args[0];
  V v_x_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24319, v_n_24320})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30(V self, V *args) {
  V v_n_24322 = args[0];
  V v_n_24321 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24323 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I32), v_n_24321});
  V v_t_24324 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24323, NTAG(TAG_VPrimRune)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24324, v_n_24322})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam31(V self, V *args) {
  V v_n_24327 = args[0];
  V v_w_24325 = heff_env(self)[0];
  V v_n_24326 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24328 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFixed, 2, (V[]){heff_dup(v_w_24325), v_n_24326}), heff_tag_n(TAG_VFixed, 1, (V[]){v_w_24325})});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24328, v_n_24327})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam32(V self, V *args) {
  V v_n_24330 = args[0];
  V v_x_24329 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24331 = heff_tag_n(TAG_VFixed, 1, (V[]){NTAG(TAG_F32)});
  V v_t_24332 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_nf(TAG_EFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_24329))}), v_t_24331});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24332, v_n_24330})});
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V v_c_240, V v_ty_241, V v_v_242, V v_fs_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkPair: {
    V v_l_245 = heff_field(v_x6_244, 0);
    V v_fe_246 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2eerase_2eprojTyInWith(heff_dup(heff_rfield(v_c_240, 2)), v_ty_241, v_fs_243, heff_dup(v_l_245)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0, 1, 6, (V[]){v_m_247, v_c_240, v_fs_243, v_v_242, v_l_245, v_fe_246});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fs_243 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_l_245 = heff_env(self)[4];
  V v_fe_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fs_243);
    heff_drop(v_v_242);
    heff_drop(v_l_245);
    heff_drop(v_fe_246);
    return heff_tag_at_n(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_x_2412)));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop_rec(v_c_240, 4);
        heff_drop(v_fs_243);
        heff_drop(v_v_242);
        heff_drop(v_l_245);
        heff_drop(v_fe_246);
        heff_drop(v_x_2412);
        heff_drop(v_t_2414);
        V v_t_2415 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2413});
        return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){v_t_2415});
      } else {
        heff_drop(v_t_2414);
        V v_x1_2416 = v_fs_243;
        V v_v_2417 = v_v_242;
        V v_l_2418 = heff_dup(v_l_245);
        V v_x1_2441;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_v_2417)) {
          case TAG_VNeu: {
            V v_t_2424 = ({ V a_0 = v_v_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2417, 5); r_; });
            v_x1_2441 = ({ V a_0 = v_t_2424; V a_1 = v_l_2418; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_l_2418); r_; });
            break;
          }
          case TAG_VCode: {
            V v_t_2426 = ({ V a_0 = v_v_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2417, 1); r_; });
            v_x1_2441 = ({ V a_0 = v_t_2426; V a_1 = v_l_2418; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_l_2418); r_; });
            break;
          }
          case TAG_VLam: {
            V v_t_2429 = ({ V a_0 = v_v_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2417, 2); r_; });
            v_x1_2441 = ({ V a_0 = v_t_2429; V a_1 = v_l_2418; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_l_2418); r_; });
            break;
          }
          case TAG_VCons: {
            V v_t_2431 = ({ V a_0 = v_v_2417; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop_tag(v_v_2417, 1); r_; });
            v_x1_2441 = ({ V a_0 = v_t_2431; V a_1 = v_l_2418; V r_ = (g_heff_2eelab_2evalue_2efieldIn(a_0, a_1)); heff_drop(v_l_2418); r_; });
            break;
          }
          case TAG_VOpaque: {
            heff_drop(v_l_2418);
            v_x1_2441 = heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
            break;
          }
          default: heff_nomatch(v_v_2417);
          }
          break;
        }
        case TAG_Just: {
          V v_fs_2432 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          heff_drop(v_v_2417);
          V v_byName_2433 = heff_take_field(v_fs_2432, 1);
          V v_values_2434 = heff_get_n(v_fs_2432, 2, 3);
          HeffT2 v_t_2435 = ({ V a_0 = v_byName_2433; V a_1 = v_l_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_2433); heff_drop(v_l_2418); r_; });
          {
            V v_field_2437 = v_t_2435.f[1];
            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
            if ((v_tag_2436 == ((int64_t)0ULL))) {
              V v_i_2438 = v_field_2437;
              V v_xs_2439 = v_values_2434;
              if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2438, 1) && heff_intLt_c(heff_dup(v_i_2438), heff_arrayLength_lent(v_xs_2439, 0)))) {
                V v_v_2440 = heff_arrayIndex(v_xs_2439, v_i_2438);
                v_x1_2441 = v_v_2440;
              } else {
                heff_drop(v_i_2438);
                heff_drop(v_xs_2439);
                v_x1_2441 = heff_abandon();
              }
            } else {
              heff_drop(v_values_2434);
              heff_drop(v_field_2437);
              v_x1_2441 = heff_abandon();
            }
          }
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_v_2445;
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_Nom: {
          V v_x_2442 = heff_field(v_x1_2441, 0);
          heff_take_n(v_x1_2441, 1ULL, 1);
          v_v_2445 = v_x_2442;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2441, 0ULL, 1);
          v_v_2445 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2444 = heff_field(v_x1_2441, 0);
          heff_take_n(v_x1_2441, 1ULL, 1);
          v_v_2445 = v_x_2444;
          break;
        }
        default: heff_nomatch(v_x1_2441);
        }
        V v_m_2446 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(v_c_240, v_fe_246, heff_dup(v_x_2412), v_v_2445));
        V v_x2_2447 = heff_tr(heff_call(v_m_2446, 1, (V[]){v_n_2413}));
        switch (heff_tag_of(v_x2_2447)) {
        case TAG_Left: {
          V v_e_2448 = heff_field(v_x2_2447, 0);
          V v_ru_24x2_2447_24Left = heff_take_reuse_n(v_x2_2447, 1ULL, 1);
          heff_drop(v_l_245);
          heff_drop_cell(v_ru_24x2_249_24Right, 1);
          heff_drop(v_x_2412);
          heff_drop_cell(v_ru_24x21_2411_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2447_24Left, TAG_Left, 1, (V[]){v_e_2448});
        }
        case TAG_Right: {
          V v_x21_2449 = heff_field(v_x2_2447, 0);
          V v_ru_24x2_2447_24Right = heff_take_reuse_n(v_x2_2447, 1ULL, 1);
          switch (heff_tag_of(v_x21_2449)) {
          case TAG_MkPair: {
            V v_x_2450 = heff_field(v_x21_2449, 0);
            V v_n_2451 = heff_field(v_x21_2449, 1);
            V v_ru_24x21_2449_24MkPair = heff_take_reuse_n(v_x21_2449, 3ULL, 2);
            V v_x1_2452 = (g_heff_2eelab_2evalue_2ebehavior(v_x_2412));
            V v_t_2464;
            switch (heff_tag_of(v_x1_2452)) {
            case TAG_LikeU: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFunction: {
              heff_take_n(v_x1_2452, 0ULL, 4);
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRecord: {
              heff_take_n(v_x1_2452, 0ULL, 3);
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeSum: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeInt: {
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFloat: {
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtFloat);
              break;
            }
            case TAG_LikeString: {
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeRune: {
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeArray: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtOther);
              break;
            }
            case TAG_LikeFixed: {
              V v_w_2463 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_t_2464 = heff_tag_at_n(v_ru_24x2_2447_24Right, TAG_FtFixed, 1, (V[]){v_w_2463});
              break;
            }
            case TAG_NoRules: {
              heff_drop_cell(v_ru_24x2_2447_24Right, 1);
              v_t_2464 = NTAG(TAG_FtAny);
              break;
            }
            default: heff_nomatch(v_x1_2452);
            }
            V v_t_2465 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x21_2449_24MkPair, TAG_MkPair, 2, (V[]){v_l_245, v_x_2450}), v_t_2464});
            V v_x_2466 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2465});
            return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2466, v_n_2451})});
          }
          default: return heff_nomatch(v_x21_2449);
          }
        }
        default: return heff_nomatch(v_x2_2447);
        }
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str3, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str4, 1, "$");
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry, 4, 0};

V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V v_c_240, V v_t_241, V v_ty_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLam: {
    V v_abs_245 = heff_dup(heff_field(v_t_241, 1));
    V v_t_246 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_LikeU: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      V v_dom_249 = heff_field(v_t_246, 1);
      V v_cod_2410 = heff_field(v_t_246, 2);
      heff_take_n(v_t_246, 6ULL, 4);
      heff_drop_tag(v_t_241, 2);
      heff_drop(v_ty_242);
      V v_it1_2417;
      V v_body_2418;
      switch (heff_tag_of(v_abs_245)) {
      case TAG_MkAbs: {
        V v_n_2412 = heff_field(v_abs_245, 0);
        V v_b_2413 = heff_field(v_abs_245, 1);
        V v_ru_24abs_245_24MkAbs = heff_take_reuse_n(v_abs_245, 3ULL, 2);
        V v_t_2414 = heff_tag_at_n(v_ru_24abs_245_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2412, NTAG(TAG_True)});
        v_it1_2417 = v_t_2414;
        v_body_2418 = v_b_2413;
        break;
      }
      case TAG_AbsConst: {
        V v_b_2415 = heff_field(v_abs_245, 0);
        heff_take_n(v_abs_245, 1ULL, 1);
        V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str0), NTAG(TAG_False)});
        v_it1_2417 = v_t_2416;
        v_body_2418 = v_b_2415;
        break;
      }
      default: heff_nomatch(v_abs_245);
      }
      switch (heff_tag_of(v_it1_2417)) {
      case TAG_MkPair: {
        V v_hint_2419 = heff_field(v_it1_2417, 0);
        V v_bound_2420 = heff_field(v_it1_2417, 1);
        heff_take_n(v_it1_2417, 3ULL, 2);
        V v_t_2421 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_249)));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_hint_2419);
          heff_drop(v_t_2421);
          V v_c_2422;
          if ((heff_dup(v_bound_2420) == NTAG(TAG_True))) {
            heff_drop(v_bound_2420);
            v_c_2422 = (g_heff_2ecompile_2eerase_2eextend(heff_dup(v_c_240), NTAG(TAG_Nothing), heff_dup(v_dom_249)));
          } else {
            heff_drop(v_bound_2420);
            v_c_2422 = heff_dup(v_c_240);
          }
          V v_x1_2430;
          switch (heff_tag_of(v_cod_2410)) {
          case TAG_MkClo: {
            V v_vs_2424 = heff_field(v_cod_2410, 1);
            V v_body_2425 = heff_field(v_cod_2410, 2);
            heff_take_n(v_cod_2410, 6ULL, 3);
            v_x1_2430 = heff_tr(heff_call(v_body_2425, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2424, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_249)})})}));
            break;
          }
          case TAG_CloConst: {
            V v_body_2429 = heff_field(v_cod_2410, 0);
            heff_take_n(v_cod_2410, 1ULL, 1);
            v_x1_2430 = v_body_2429;
            break;
          }
          default: heff_nomatch(v_cod_2410);
          }
          V v_ty_2434;
          switch (heff_tag_of(v_x1_2430)) {
          case TAG_Nom: {
            V v_x_2431 = heff_field(v_x1_2430, 0);
            heff_take_n(v_x1_2430, 1ULL, 1);
            v_ty_2434 = v_x_2431;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2430, 0ULL, 1);
            v_ty_2434 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2433 = heff_field(v_x1_2430, 0);
            heff_take_n(v_x1_2430, 1ULL, 1);
            v_ty_2434 = v_x_2433;
            break;
          }
          default: heff_nomatch(v_x1_2430);
          }
          V v_x1_2438 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_v_243, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2, 1, 2, (V[]){v_c_240, v_dom_249})));
          V v_v_2442;
          switch (heff_tag_of(v_x1_2438)) {
          case TAG_Nom: {
            V v_x_2439 = heff_field(v_x1_2438, 0);
            heff_take_n(v_x1_2438, 1ULL, 1);
            v_v_2442 = v_x_2439;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2438, 0ULL, 1);
            v_v_2442 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2441 = heff_field(v_x1_2438, 0);
            heff_take_n(v_x1_2438, 1ULL, 1);
            v_v_2442 = v_x_2441;
            break;
          }
          default: heff_nomatch(v_x1_2438);
          }
          V t_0 = v_c_2422;
          V t_1 = v_body_2418;
          V t_2 = v_ty_2434;
          V t_3 = v_v_2442;
          v_c_240 = t_0;
          v_t_241 = t_1;
          v_ty_242 = t_2;
          v_v_243 = t_3;
          goto top;
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4, 1, 7, (V[]){v_hint_2419, v_bound_2420, v_c_240, v_dom_249, v_cod_2410, v_v_243, v_body_2418});
        }
      }
      default: return heff_nomatch(v_it1_2417);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRune: {
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_abs_245);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCons: {
    V v_d_2482 = heff_dup(heff_field(v_t_241, 0));
    V v_keys_2483 = heff_take_field(v_d_2482, 0);
    V v_values_2484 = heff_get_n(v_d_2482, 2, 3);
    V v_t_2485 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_2485)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2485, 0ULL, 4);
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2485, 0ULL, 3);
      heff_drop_tag(v_t_241, 1);
      V v_c_2494 = v_c_240;
      V v_ty_2495 = v_ty_242;
      V v_v_2496 = heff_dup(v_v_243);
      V v_ps_2497 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2483), heff_arrayToList(v_values_2484)));
      V v_fs_2498 = ({ V a_0 = v_v_243; V r_ = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(a_0)); heff_drop(v_v_243); r_; });
      V v_m_24100 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9, 1, 4, (V[]){v_c_2494, v_ty_2495, v_v_2496, v_fs_2498}), v_ps_2497));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10, 1, 1, (V[]){v_m_24100});
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRune: {
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2485, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_keys_2483);
      heff_drop(v_values_2484);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_2485);
    }
  }
  default: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  }
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_dom_249;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0(V self, V *args) {
  V v_u_2426 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2426);
  V v_t_2427 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2427, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3(V self, V *args) {
  V v_u_2437 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2437);
  return v_dom_249;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2(V self, V *args) {
  V v_u_2435 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2435);
  V v_t_2436 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2436, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6(V self, V *args) {
  V v_u_2453 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2453);
  return v_dom_249;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2451);
  V v_t_2452 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2452, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8(V self, V *args) {
  V v_u_2462 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2462);
  return v_dom_249;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7(V self, V *args) {
  V v_u_2460 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2460);
  V v_t_2461 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2461, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4(V self, V *args) {
  V v_n_2443 = args[0];
  V v_hint_2419 = heff_env(self)[0];
  V v_bound_2420 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_dom_249 = heff_env(self)[3];
  V v_cod_2410 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_body_2418 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2444;
  if ((heff_strEq_c_lent(v_hint_2419, ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str1), 2) || heff_strEq_c_lent(v_hint_2419, ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str2), 2))) {
    heff_drop(v_hint_2419);
    v_t_2444 = ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str3);
  } else {
    v_t_2444 = v_hint_2419;
  }
  V v_t_2445 = heff_strAppend(heff_strAppend(v_t_2444, ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str4)), heff_intShow(heff_dup(v_n_2443)));
  V v_c_2447;
  if ((heff_dup(v_bound_2420) == NTAG(TAG_True))) {
    heff_drop(v_bound_2420);
    V v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2445)})});
    v_c_2447 = (g_heff_2ecompile_2eerase_2eextend(heff_dup(v_c_240), v_t_2446, heff_dup(v_dom_249)));
  } else {
    heff_drop(v_bound_2420);
    v_c_2447 = heff_dup(v_c_240);
  }
  V v_x1_2455;
  switch (heff_tag_of(v_cod_2410)) {
  case TAG_MkClo: {
    V v_vs_2449 = heff_field(v_cod_2410, 1);
    V v_body_2450 = heff_field(v_cod_2410, 2);
    heff_take_n(v_cod_2410, 6ULL, 3);
    v_x1_2455 = heff_tr(heff_call(v_body_2450, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2449, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_249)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2454 = heff_field(v_cod_2410, 0);
    heff_take_n(v_cod_2410, 1ULL, 1);
    v_x1_2455 = v_body_2454;
    break;
  }
  default: heff_nomatch(v_cod_2410);
  }
  V v_ty_2459;
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    v_ty_2459 = v_x_2456;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    v_ty_2459 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    v_ty_2459 = v_x_2458;
    break;
  }
  default: heff_nomatch(v_x1_2455);
  }
  V v_x1_2463 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_v_243, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7, 1, 2, (V[]){v_c_240, v_dom_249})));
  V v_v_2467;
  switch (heff_tag_of(v_x1_2463)) {
  case TAG_Nom: {
    V v_x_2464 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_v_2467 = v_x_2464;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2463, 0ULL, 1);
    v_v_2467 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2466 = heff_field(v_x1_2463, 0);
    heff_take_n(v_x1_2463, 1ULL, 1);
    v_v_2467 = v_x_2466;
    break;
  }
  default: heff_nomatch(v_x1_2463);
  }
  V v_m_2468 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(v_c_2447, v_body_2418, v_ty_2459, v_v_2467));
  V v_x2_2469 = heff_tr(heff_call(v_m_2468, 1, (V[]){heff_intAdd(v_n_2443, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_Left: {
    V v_e_2470 = heff_field(v_x2_2469, 0);
    V v_ru_24x2_2469_24Left = heff_take_reuse_n(v_x2_2469, 1ULL, 1);
    heff_drop(v_t_2445);
    return heff_tag_at_n(v_ru_24x2_2469_24Left, TAG_Left, 1, (V[]){v_e_2470});
  }
  case TAG_Right: {
    V v_x21_2471 = heff_field(v_x2_2469, 0);
    V v_ru_24x2_2469_24Right = heff_take_reuse_n(v_x2_2469, 1ULL, 1);
    switch (heff_tag_of(v_x21_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x21_2471, 0);
      V v_n_2473 = heff_field(v_x21_2471, 1);
      V v_ru_24x21_2471_24MkPair = heff_take_reuse_n(v_x21_2471, 3ULL, 2);
      V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
      V v_t_2475 = heff_tag_at_n(v_ru_24x21_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2474, v_x_2472}), v_n_2473});
      return heff_tag_at_n(v_ru_24x2_2469_24Right, TAG_Right, 1, (V[]){v_t_2475});
    }
    default: return heff_nomatch(v_x21_2471);
    }
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9(V self, V *args) {
  V v_p_2499 = args[0];
  V v_c_2494 = heff_env(self)[0];
  V v_ty_2495 = heff_env(self)[1];
  V v_v_2496 = heff_env(self)[2];
  V v_fs_2498 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(v_c_2494, v_ty_2495, v_v_2496, v_fs_2498, v_p_2499));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10(V self, V *args) {
  V v_n_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_n_24101}));
  switch (heff_tag_of(v_x2_24102)) {
  case TAG_Left: {
    V v_e_24103 = heff_field(v_x2_24102, 0);
    V v_ru_24x2_24102_24Left = heff_take_reuse_n(v_x2_24102, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24102_24Left, TAG_Left, 1, (V[]){v_e_24103});
  }
  case TAG_Right: {
    V v_x21_24104 = heff_field(v_x2_24102, 0);
    V v_ru_24x2_24102_24Right = heff_take_reuse_n(v_x2_24102, 1ULL, 1);
    switch (heff_tag_of(v_x21_24104)) {
    case TAG_MkPair: {
      V v_x_24105 = heff_field(v_x21_24104, 0);
      V v_n_24106 = heff_field(v_x21_24104, 1);
      V v_ru_24x21_24104_24MkPair = heff_take_reuse_n(v_x21_24104, 3ULL, 2);
      V v_t_24107 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_24105)));
      V v_t_24108 = (g_list_2emap_24s1937570095x2110149801(v_t_24107));
      V v_t_24109 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_24105));
      V v_t_24110 = (g_list_2emap_24s1173914895x100384474(v_t_24109));
      V v_x_24111 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_24108, v_t_24110});
      return heff_tag_at_n(v_ru_24x2_24102_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x21_24104_24MkPair, TAG_MkPair, 2, (V[]){v_x_24111, v_n_24106})});
    }
    default: return heff_nomatch(v_x21_24104);
    }
  }
  default: return heff_nomatch(v_x2_24102);
  }
}
V g_heff_2ecompile_2eerase_2edefinition_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2edefinition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2edefinition_entry, 4, 0};

V g_heff_2ecompile_2eerase_2edefinition(V v_g_240, V v_key_241, V v_e_242, V v_z_243) {
top: ;
  V v_syntax_244 = heff_take_field(v_e_242, 0);
  V v_type_5f_245 = heff_take_field(v_e_242, 3);
  V v_value_246 = heff_get_n(v_e_242, 2, 4);
  V v_t_247 = v_syntax_244;
  V v_ty_248 = heff_dup(v_type_5f_245);
  V v_v_249 = heff_dup(v_value_246);
  V v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_key_241})});
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2410, v_type_5f_245}), NTAG(TAG_Nil)});
  V v_t_2413 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2ecompile_2eerase_2edefinition_lam0, 1, 1, (V[]){v_value_246})});
  V v_t_2414 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2411, v_t_2413, MK_INT(1LL), v_g_240}), v_t_247, v_ty_248, v_v_249));
  return heff_tail(v_t_2414, 1, (V[]){v_z_243});
}
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2edefinition(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2edefinition_lam0(V self, V *args) {
  V v_u_2412 = args[0];
  V v_value_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_value_246;
}
Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eeraseProgram_entry, 1, 0};

V g_heff_2ecompile_2eerase_2eeraseProgram(V v_g_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(v_g_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    return heff_rec_n(3, shape_defs__errors__supply, (V[]){v_field_242, v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eeraseProgram(a[0]);
}