// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EQ 8989
#define TAG_GT 9054
#define TAG_LT 9209
#define LBL_compare 1182341923
V g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285(V, V, V);
V g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_clo;
V g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036(V, V);
V g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_entry(V self, V *a);
extern Clo g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_clo;
Clo g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_entry, 2, 0};

V g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036(V v_x1_27_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x1_27_240)) {
  case TAG_MkPair: {
    V v_x1_242 = heff_field(v_x1_27_240, 0);
    V v_y1_243 = heff_field(v_x1_27_240, 1);
    switch (heff_tag_of(v_x2_27_241)) {
    case TAG_MkPair: {
      V v_x2_244 = heff_field(v_x2_27_241, 0);
      V v_y2_245 = heff_field(v_x2_27_241, 1);
      V v_it_246;
      if ((heff_dup(v_x1_242) == NTAG(TAG_True))) {
        if ((heff_dup(v_x2_244) == NTAG(TAG_True))) {
          v_it_246 = NTAG(TAG_EQ);
        } else {
          v_it_246 = NTAG(TAG_GT);
        }
      } else {
        if ((heff_dup(v_x2_244) == NTAG(TAG_True))) {
          v_it_246 = NTAG(TAG_LT);
        } else {
          v_it_246 = NTAG(TAG_EQ);
        }
      }
      switch (heff_tag_of(v_it_246)) {
      case TAG_LT: {
        return v_it_246;
      }
      case TAG_EQ: {
        V v_a_247 = heff_strCompare_lent(v_y1_243, v_y2_245, 0);
        if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
          heff_drop(v_a_247);
          return NTAG(TAG_LT);
        } else {
          if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
            return NTAG(TAG_EQ);
          } else {
            return NTAG(TAG_GT);
          }
        }
      }
      case TAG_GT: {
        return v_it_246;
      }
      default: return heff_nomatch(v_it_246);
      }
    }
    default: return heff_nomatch(v_x2_27_241);
    }
  }
  default: return heff_nomatch(v_x1_27_240);
  }
}
V g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_prelude_2einstanceOrderPair_2eordered_240_24s1752757570x34197036(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_clo = {{0x80000000u, K_CLO, 0}, g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_entry, 3, 0};

V g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285(V v_ordB_240, V v_x1_27_241, V v_x2_27_242) {
top: ;
  switch (heff_tag_of(v_x1_27_241)) {
  case TAG_MkPair: {
    V v_x1_243 = heff_field(v_x1_27_241, 0);
    V v_y1_244 = heff_field(v_x1_27_241, 1);
    switch (heff_tag_of(v_x2_27_242)) {
    case TAG_MkPair: {
      V v_x2_245 = heff_field(v_x2_27_242, 0);
      V v_y2_246 = heff_field(v_x2_27_242, 1);
      V v_a_247 = heff_strCompare_lent(v_x1_243, v_x2_245, 0);
      V v_it_248;
      if (heff_intLt_c_lent(v_a_247, MK_INT(0LL), 2)) {
        heff_drop(v_a_247);
        v_it_248 = NTAG(TAG_LT);
      } else {
        if (heff_intEq_c(v_a_247, MK_INT(0LL))) {
          v_it_248 = NTAG(TAG_EQ);
        } else {
          v_it_248 = NTAG(TAG_GT);
        }
      }
      switch (heff_tag_of(v_it_248)) {
      case TAG_LT: {
        heff_drop_rec(v_ordB_240, 4);
        return v_it_248;
      }
      case TAG_EQ: {
        return heff_tail(heff_get_n(v_ordB_240, 1, 4), 2, (V[]){heff_dup(v_y1_244), heff_dup(v_y2_246)});
      }
      case TAG_GT: {
        heff_drop_rec(v_ordB_240, 4);
        return v_it_248;
      }
      default: return heff_nomatch(v_it_248);
      }
    }
    default: return heff_nomatch(v_x2_27_242);
    }
  }
  default: return heff_nomatch(v_x1_27_241);
  }
}
V g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_prelude_2einstanceOrderPair_2eordered_240_24s1372217269x900883285(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}