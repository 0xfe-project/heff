// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Anonymous 24551
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588 6711
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_LNil 57394
#define TAG_Left 13886
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_prim 9944941
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_value 313331083
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_heff_2ecompile_2eprims_2eprims_get(void);
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(V, V, V);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_PatTag: {
        return NTAG(TAG_False);
      }
      case TAG_PatOp: {
        return NTAG(TAG_False);
      }
      case TAG_PatInt: {
        return NTAG(TAG_False);
      }
      case TAG_PatFloat: {
        return NTAG(TAG_False);
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        return NTAG(TAG_False);
      }
      case TAG_PatRune: {
        return NTAG(TAG_False);
      }
      case TAG_PatRecord: {
        return NTAG(TAG_False);
      }
      case TAG_PatWord: {
        return NTAG(TAG_False);
      }
      case TAG_PatAs: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str7, 0, "");
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str1), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str2), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str3), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str4), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str5), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str6), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str7), v_n_240));
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0, 48, "expected a field declaration of the form `x : A`");
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(heff_dup(v_t_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_c_2413)) {
  case TAG_At: {
    V v_s_2419 = heff_field(v_c_2413, 1);
    heff_take_n(v_c_2413, 2ULL, 2);
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_c_2413);
  }
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2417, v_t_2420})});
  V f_ = v_k_2416;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2414, v_hd_2415, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4, 1, 2, (V[]){v_c_2413, v_k_2416})));
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_243, v_x_2410, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2422;
  switch (heff_tag_of(v_d_246)) {
  case TAG_Nothing: {
    v_c_2422 = ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_d_246, 0);
    heff_take_n(v_d_246, 1ULL, 1);
    V v_t_2414 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2413)));
    v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3, 2, 2, (V[]){v_t_2414, v_c_2413});
    break;
  }
  default: heff_nomatch(v_d_246);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2425, 2), 1, (V[]){v_t_2429}));
  V f_ = heff_get_n(v_hd_2425, 1, 3);
  args[0] = v_t_2430;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_n1_241, 0);
      V v_ru_24n1_241_24CInf = heff_take_reuse_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      V v_t_2437;
      switch (heff_tag_of(v_i_243)) {
      case TAG_At: {
        V v_x11_244 = heff_dup(heff_field(v_i_243, 0));
        switch (heff_tag_of(v_x11_244)) {
        case TAG_IVar: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IInt: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IFloat: {
          heff_take_na(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IString: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IBytes: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IPrim: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IRune: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IApp: {
          heff_take_n(v_x11_244, 0ULL, 2);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IAnn: {
          heff_take_n(v_x11_244, 0ULL, 2);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_ISpec: {
          heff_take_n(v_x11_244, 0ULL, 4);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IUpdate: {
          heff_take_n(v_x11_244, 0ULL, 2);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IAnnLam: {
          heff_take_n(v_x11_244, 0ULL, 4);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_IInvalid: {
          heff_take_n(v_x11_244, 0ULL, 3);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_INominal: {
          V v_i_2430 = heff_field(v_x11_244, 0);
          heff_take_n(v_x11_244, 1ULL, 1);
          v_t_2437 = v_i_2430;
          break;
        }
        case TAG_ILitEq: {
          heff_take_n(v_x11_244, 0ULL, 4);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_ILazy: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        case TAG_ITuple: {
          heff_take_n(v_x11_244, 0ULL, 1);
          v_t_2437 = heff_dup(v_i_243);
          break;
        }
        default: heff_nomatch(v_x11_244);
        }
        break;
      }
      default: heff_nomatch(v_i_243);
      }
      V v_t_2471;
      switch (heff_tag_of(v_t_2437)) {
      case TAG_At: {
        V v_x11_2438 = heff_field(v_t_2437, 0);
        heff_take_n(v_t_2437, 1ULL, 2);
        switch (heff_tag_of(v_x11_2438)) {
        case TAG_IVar: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IInt: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IFloat: {
          heff_take_na(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IString: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IBytes: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IPrim: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IRune: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IApp: {
          heff_take_n(v_x11_2438, 0ULL, 2);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IAnn: {
          heff_take_n(v_x11_2438, 0ULL, 2);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ISpec: {
          heff_take_n(v_x11_2438, 0ULL, 4);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IUpdate: {
          heff_take_n(v_x11_2438, 0ULL, 2);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IAnnLam: {
          heff_take_n(v_x11_2438, 0ULL, 4);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_IInvalid: {
          heff_take_n(v_x11_2438, 0ULL, 3);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_INominal: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ILitEq: {
          heff_take_n(v_x11_2438, 0ULL, 4);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_ILazy: {
          V v_c_2469 = heff_field(v_x11_2438, 0);
          heff_take_n(v_x11_2438, 1ULL, 1);
          v_t_2471 = heff_tag_at_n(v_ru_24n1_241_24CInf, TAG_Just, 1, (V[]){v_c_2469});
          break;
        }
        case TAG_ITuple: {
          heff_take_n(v_x11_2438, 0ULL, 1);
          heff_drop_cell(v_ru_24n1_241_24CInf, 1);
          v_t_2471 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x11_2438);
        }
        break;
      }
      default: heff_nomatch(v_t_2437);
      }
      switch (heff_tag_of(v_t_2471)) {
      case TAG_Nothing: {
        V v_t_24105;
        switch (heff_tag_of(v_i_243)) {
        case TAG_At: {
          V v_x11_2472 = heff_dup(heff_field(v_i_243, 0));
          switch (heff_tag_of(v_x11_2472)) {
          case TAG_IVar: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IInt: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IFloat: {
            heff_take_na(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IString: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IRune: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IApp: {
            heff_take_n(v_x11_2472, 0ULL, 2);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_2472, 0ULL, 2);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_2472, 0ULL, 4);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_2472, 0ULL, 2);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_2472, 0ULL, 4);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_2472, 0ULL, 3);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_INominal: {
            V v_i_2498 = heff_field(v_x11_2472, 0);
            heff_take_n(v_x11_2472, 1ULL, 1);
            v_t_24105 = v_i_2498;
            break;
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_2472, 0ULL, 4);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_ILazy: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          case TAG_ITuple: {
            heff_take_n(v_x11_2472, 0ULL, 1);
            v_t_24105 = heff_dup(v_i_243);
            break;
          }
          default: heff_nomatch(v_x11_2472);
          }
          break;
        }
        default: heff_nomatch(v_i_243);
        }
        switch (heff_tag_of(v_t_24105)) {
        case TAG_At: {
          V v_x11_24106 = heff_field(v_t_24105, 0);
          V v_sp_24107 = heff_field(v_t_24105, 1);
          heff_take_n(v_t_24105, 3ULL, 2);
          switch (heff_tag_of(v_x11_24106)) {
          case TAG_IVar: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IInt: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IFloat: {
            heff_take_na(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IString: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IRune: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IApp: {
            heff_take_n(v_x11_24106, 0ULL, 2);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_24106, 0ULL, 2);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_24106, 0ULL, 4);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_24106, 0ULL, 2);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_24106, 0ULL, 4);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_24106, 0ULL, 3);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_INominal: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_24106, 0ULL, 4);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_ILazy: {
            heff_take_n(v_x11_24106, 0ULL, 1);
            heff_drop(v_sp_24107);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
          }
          case TAG_ITuple: {
            V v_cs_24138 = heff_field(v_x11_24106, 0);
            heff_take_n(v_x11_24106, 1ULL, 1);
            V v_t_24172;
            switch (heff_tag_of(v_i_243)) {
            case TAG_At: {
              V v_x11_24139 = heff_field(v_i_243, 0);
              heff_take_n(v_i_243, 1ULL, 2);
              switch (heff_tag_of(v_x11_24139)) {
              case TAG_IVar: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IInt: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IFloat: {
                heff_take_na(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IString: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IBytes: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IPrim: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IRune: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IApp: {
                heff_take_n(v_x11_24139, 0ULL, 2);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IAnn: {
                heff_take_n(v_x11_24139, 0ULL, 2);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_ISpec: {
                heff_take_n(v_x11_24139, 0ULL, 4);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IUpdate: {
                heff_take_n(v_x11_24139, 0ULL, 2);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IAnnLam: {
                heff_take_n(v_x11_24139, 0ULL, 4);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_IInvalid: {
                heff_take_n(v_x11_24139, 0ULL, 3);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_INominal: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_True);
                break;
              }
              case TAG_ILitEq: {
                heff_take_n(v_x11_24139, 0ULL, 4);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_ILazy: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              case TAG_ITuple: {
                heff_take_n(v_x11_24139, 0ULL, 1);
                v_t_24172 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_x11_24139);
              }
              break;
            }
            default: heff_nomatch(v_i_243);
            }
            return ({ V a_0 = v_t_24172; V a_1 = v_sp_24107; V a_2 = v_cs_24138; V r_ = (g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a_0, a_1, a_2)); heff_drop(v_t_24172); r_; });
          }
          default: return heff_nomatch(v_x11_24106);
          }
        }
        default: return heff_nomatch(v_t_24105);
        }
      }
      case TAG_Just: {
        V v_c_24173 = heff_field(v_t_2471, 0);
        heff_take_n(v_t_2471, 1ULL, 1);
        V v_t_24207;
        switch (heff_tag_of(v_i_243)) {
        case TAG_At: {
          V v_x11_24174 = heff_dup(heff_field(v_i_243, 0));
          switch (heff_tag_of(v_x11_24174)) {
          case TAG_IVar: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IInt: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IFloat: {
            heff_take_na(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IString: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IRune: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IApp: {
            heff_take_n(v_x11_24174, 0ULL, 2);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_24174, 0ULL, 2);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_24174, 0ULL, 4);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_24174, 0ULL, 2);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_24174, 0ULL, 4);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_24174, 0ULL, 3);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_INominal: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_True);
            break;
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_24174, 0ULL, 4);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_ILazy: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          case TAG_ITuple: {
            heff_take_n(v_x11_24174, 0ULL, 1);
            v_t_24207 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x11_24174);
          }
          break;
        }
        default: heff_nomatch(v_i_243);
        }
        V v_t_24210;
        switch (heff_tag_of(v_i_243)) {
        case TAG_At: {
          V v_s_24209 = heff_field(v_i_243, 1);
          heff_take_n(v_i_243, 2ULL, 2);
          v_t_24210 = v_s_24209;
          break;
        }
        default: heff_nomatch(v_i_243);
        }
        return ({ V a_0 = v_t_24207; V a_1 = v_t_24210; V a_2 = v_c_24173; V r_ = (g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(a_0, a_1, a_2)); heff_drop(v_t_24207); r_; });
      }
      default: return heff_nomatch(v_t_2471);
      }
    }
    case TAG_CType: {
      V v_t_24211 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return (g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(v_n2_242, v_t_24211));
    }
    case TAG_CLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_24215 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 2, (V[]){v_c_24215, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_24248 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 2, 2, (V[]){v_c_24248, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_n1_241, 0ULL, 4);
      heff_drop(v_n2_242);
      V v_c_24282 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 2, 2, (V[]){v_c_24282, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_24315 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 2, 2, (V[]){v_c_24315, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24346 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 2, (V[]){v_c_24346, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24378 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 2, (V[]){v_c_24378, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24410 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 2, 2, (V[]){v_c_24410, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24442 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 2, 2, (V[]){v_c_24442, v_n_240});
    }
    case TAG_CAbandon: {
      heff_drop(v_n2_242);
      V v_c_24472 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 2, 2, (V[]){v_c_24472, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24503 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 2, 2, (V[]){v_c_24503, v_n_240});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_24218 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24217 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24244;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24219 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24219)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24219, 0ULL, 1);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24219, 0ULL, 1);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24219, 0ULL, 3);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24219, 0ULL, 3);
      v_x_24244 = v_x_24218;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24219, 0ULL, 4);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24219, 0ULL, 3);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24219, 0ULL, 1);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24219, 0ULL, 2);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24219, 0ULL, 2);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24219, 0ULL, 2);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24219, 0ULL, 1);
      v_x_24244 = ({ V a_0 = v_x_24218; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24218); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24219);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24217;
  args[0] = v_x_24244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_24216 = args[0];
  V v_k_24217 = args[1];
  V v_c_24215 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24215;
  args[0] = v_hd_24216;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 2, (V[]){v_n_240, v_k_24217});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_x_24251 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24250 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24277;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24252 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24252)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24252, 0ULL, 1);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24252, 0ULL, 1);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24252, 0ULL, 3);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24252, 0ULL, 3);
      v_x_24277 = v_x_24251;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24252, 0ULL, 4);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24252, 0ULL, 3);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24252, 0ULL, 1);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24252, 0ULL, 2);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24252, 0ULL, 2);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24252, 0ULL, 2);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24252, 0ULL, 1);
      v_x_24277 = ({ V a_0 = v_x_24251; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24251); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24252);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24250;
  args[0] = v_x_24277;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_hd_24249 = args[0];
  V v_k_24250 = args[1];
  V v_c_24248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24248;
  args[0] = v_hd_24249;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 1, 2, (V[]){v_n_240, v_k_24250});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_x_24285 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24284 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24311;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24286 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24286)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24286, 0ULL, 1);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24286, 0ULL, 1);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24286, 0ULL, 3);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24286, 0ULL, 3);
      v_x_24311 = v_x_24285;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24286, 0ULL, 4);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24286, 0ULL, 3);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24286, 0ULL, 1);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24286, 0ULL, 2);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24286, 0ULL, 2);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24286, 0ULL, 2);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24286, 0ULL, 1);
      v_x_24311 = ({ V a_0 = v_x_24285; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24285); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24286);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24284;
  args[0] = v_x_24311;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_hd_24283 = args[0];
  V v_k_24284 = args[1];
  V v_c_24282 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24282;
  args[0] = v_hd_24283;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 1, 2, (V[]){v_n_240, v_k_24284});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_24318 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24317 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24344;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24319 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24319)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24319, 0ULL, 1);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24319, 0ULL, 1);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24319, 0ULL, 3);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24319, 0ULL, 3);
      v_x_24344 = v_x_24318;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24319, 0ULL, 4);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24319, 0ULL, 3);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24319, 0ULL, 1);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24319, 0ULL, 2);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24319, 0ULL, 2);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24319, 0ULL, 2);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24319, 0ULL, 1);
      v_x_24344 = ({ V a_0 = v_x_24318; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24318); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24319);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24317;
  args[0] = v_x_24344;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_hd_24316 = args[0];
  V v_k_24317 = args[1];
  V v_c_24315 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24315;
  args[0] = v_hd_24316;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 2, (V[]){v_n_240, v_k_24317});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_x_24349 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24348 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24375;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24350 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24350)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24350, 0ULL, 1);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24350, 0ULL, 1);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24350, 0ULL, 3);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24350, 0ULL, 3);
      v_x_24375 = v_x_24349;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24350, 0ULL, 4);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24350, 0ULL, 3);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24350, 0ULL, 1);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24350, 0ULL, 2);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24350, 0ULL, 2);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24350, 0ULL, 2);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24350, 0ULL, 1);
      v_x_24375 = ({ V a_0 = v_x_24349; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24349); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24350);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24348;
  args[0] = v_x_24375;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_hd_24347 = args[0];
  V v_k_24348 = args[1];
  V v_c_24346 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24346;
  args[0] = v_hd_24347;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 2, (V[]){v_n_240, v_k_24348});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_x_24381 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24380 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24407;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24382 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24382)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24382, 0ULL, 1);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24382, 0ULL, 1);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24382, 0ULL, 3);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24382, 0ULL, 3);
      v_x_24407 = v_x_24381;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24382, 0ULL, 4);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24382, 0ULL, 3);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24382, 0ULL, 1);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24382, 0ULL, 2);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24382, 0ULL, 2);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24382, 0ULL, 2);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24382, 0ULL, 1);
      v_x_24407 = ({ V a_0 = v_x_24381; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24381); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24382);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24380;
  args[0] = v_x_24407;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24379 = args[0];
  V v_k_24380 = args[1];
  V v_c_24378 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24378;
  args[0] = v_hd_24379;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 1, 2, (V[]){v_n_240, v_k_24380});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_x_24413 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24439;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24414 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24414)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24414, 0ULL, 1);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24414, 0ULL, 1);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24414, 0ULL, 3);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24414, 0ULL, 3);
      v_x_24439 = v_x_24413;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24414, 0ULL, 4);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24414, 0ULL, 3);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24414, 0ULL, 1);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24414, 0ULL, 2);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24414, 0ULL, 2);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24414, 0ULL, 2);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24414, 0ULL, 1);
      v_x_24439 = ({ V a_0 = v_x_24413; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24413); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24414);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24412;
  args[0] = v_x_24439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_hd_24411 = args[0];
  V v_k_24412 = args[1];
  V v_c_24410 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24410;
  args[0] = v_hd_24411;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 1, 2, (V[]){v_n_240, v_k_24412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24445 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24471;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24446 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24446)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24446, 0ULL, 1);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24446, 0ULL, 1);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24446, 0ULL, 3);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24446, 0ULL, 3);
      v_x_24471 = v_x_24445;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24446, 0ULL, 4);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24446, 0ULL, 3);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24446, 0ULL, 1);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24446, 0ULL, 2);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24446, 0ULL, 2);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24446, 0ULL, 2);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24446, 0ULL, 1);
      v_x_24471 = ({ V a_0 = v_x_24445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24445); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24446);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24444;
  args[0] = v_x_24471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_hd_24443 = args[0];
  V v_k_24444 = args[1];
  V v_c_24442 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24442;
  args[0] = v_hd_24443;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 2, (V[]){v_n_240, v_k_24444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_x_24475 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24474 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24501;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24476 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24476)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24476, 0ULL, 1);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24476, 0ULL, 1);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24476, 0ULL, 3);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24476, 0ULL, 3);
      v_x_24501 = v_x_24475;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24476, 0ULL, 4);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24476, 0ULL, 3);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24476, 0ULL, 1);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24476, 0ULL, 2);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24476, 0ULL, 2);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24476, 0ULL, 2);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24476, 0ULL, 1);
      v_x_24501 = ({ V a_0 = v_x_24475; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24475); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24476);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24474;
  args[0] = v_x_24501;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_hd_24473 = args[0];
  V v_k_24474 = args[1];
  V v_c_24472 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24472;
  args[0] = v_hd_24473;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 1, 2, (V[]){v_n_240, v_k_24474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_x_24506 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24505 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24532;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24507 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24507)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24507, 0ULL, 1);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24507, 0ULL, 1);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24507, 0ULL, 3);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24507, 0ULL, 3);
      v_x_24532 = v_x_24506;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24507, 0ULL, 4);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24507, 0ULL, 3);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24507, 0ULL, 1);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24507, 0ULL, 2);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24507, 0ULL, 2);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24507, 0ULL, 2);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24507, 0ULL, 1);
      v_x_24532 = ({ V a_0 = v_x_24506; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24506); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24507);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24505;
  args[0] = v_x_24532;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_hd_24504 = args[0];
  V v_k_24505 = args[1];
  V v_c_24503 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24503;
  args[0] = v_hd_24504;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 1, 2, (V[]){v_n_240, v_k_24505});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2411));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2432 = heff_field(v_x2_240, 2);
    V v_t_2433 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2434 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2433));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2434, v_sp_2432, v_x_2430});
  }
  case TAG_PiAnon: {
    V v_d_2438 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2439 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_d_2438));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2439});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2422;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2428;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    v_c_2428 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_t_2420, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2432, v_x_2430, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2436, v_sp_2432, v_x_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str0, 5, " and ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str1, 14, " are not equal");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str2, 50, "the implicit arguments found do not fit together: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str3, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, "`, it would need ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str5, 11, "found for `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str6, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str7, 24, " does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str8, 35, "cannot infer an implicit argument: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str9, 9, " := ...)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str10, 14, "`: give it, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str11, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str12, 25, ", does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str13, 21, "what is known of it, ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str14, 36, "cannot infer the implicit argument `");
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2), heff_strAppend(heff_dup(v_left_243), v_t_246));
    V v_t_249;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_249 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_248 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_249 = heff_get_n(v_me_248, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2413;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_2410 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2411 = heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), v_right_244));
      V v_t_2412 = heff_strAppend(heff_get_n(v_me_2410, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4), v_t_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5), v_t_2412)});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_247, v_t_249, v_t_2413});
  } else {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7)));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8), heff_strAppend(v_left_243, v_t_2414));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2415, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2416 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_me_2416, 4)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9));
      V v_t_2418 = heff_strAppend(heff_take_field(v_me_2416, 4), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10), v_t_2417));
      V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12)));
      V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13), heff_strAppend(v_left_243, v_t_2419));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14), v_t_2418), heff_get_n(v_me_2416, 5, 6), heff_tag_n(TAG_Just, 1, (V[]){v_t_2420})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 9, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_isInstance_243, V v_tyStx_244, V v_mc_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Left: {
    V v_failed_249 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2410 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2411;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      v_key_2411 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2410);
      v_key_2411 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2412 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2413;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      heff_drop(v_t_2412);
      v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2412);
      v_t_2413 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_entry_2414 = ({ V a_0 = v_g_241; V a_1 = v_t_2413; V a_2 = v_tyStx_244; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2411, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2414, heff_tag_n(TAG_Just, 1, (V[]){v_failed_249})});
    return heff_tail(v_z_248, 1, (V[]){v_t_2415});
  }
  case TAG_Right: {
    V v_t_2416 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2417 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2418;
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      v_key_2418 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2417);
      v_key_2418 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2419 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2420;
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2419);
      v_t_2420 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2421 = heff_dup(heff_rfield(v_d_242, 3));
    V v_k_2422;
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      heff_drop(v_t_2421);
      v_k_2422 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2421);
      v_k_2422 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2423 = (g_heff_2eelab_2eunify_2ezonker(v_mc_245));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_t_2423, 0, 2), 1, (V[]){heff_get_n(v_t_2416, 0, 2)}));
    V v_t_2425 = ({ V a_0 = v_k_2422; V r_ = (g_heff_2eelab_2etoplevel_2eselfWalk(a_0)); heff_drop(v_k_2422); r_; });
    V v_t_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2424}));
    V v_entry_2427 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2420, heff_rfield(v_d_242, 3), v_tyStx_244, v_t_2426));
    V v_t_2428 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2418, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2427, NTAG(TAG_Nothing)});
    return heff_tail(v_z_248, 1, (V[]){v_t_2428});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a7 = a[7]; V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a5, a[6], a7, a[8]); heff_drop(a5); heff_drop(a7); return r;
}

static V g_heff_2eelab_2etoplevel_2eprimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2eprimNames_st;
static V g_heff_2eelab_2etoplevel_2eprimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2eprims_get())));
}
V g_heff_2eelab_2etoplevel_2eprimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2eprimNames_st)) return g_heff_2eelab_2etoplevel_2eprimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2eprimNames_val, &g_heff_2eelab_2etoplevel_2eprimNames_st, g_heff_2eelab_2etoplevel_2eprimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchEntry_str0, 7, "> watch");
Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_call(heff_get_n(v_t_246, 1, 2), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 1, (V[]){heff_get_n(v_t_242, 0, 2)}));
  V v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2eelab_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2419;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      v_t_2419 = v_x_2415;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2413;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2413;
        v_t_2419 = v_x_2418;
      }
    }
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2419});
}
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ewatchEntry(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eisPrimB(a0); heff_drop(a0); return r;
}