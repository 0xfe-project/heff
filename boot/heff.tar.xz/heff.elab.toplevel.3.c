// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Anonymous 24551
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Describe 2650
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Throw 56084
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VOpaque 37311
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_bind 9519364
#define LBL_body 9524841
#define LBL_broken 566525696
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_entries 787768015
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_hidden 729654485
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_malg 9839318
#define LBL_member 869372357
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_watches 1357821955
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__entry[] = {LBL_span, LBL_entry};
static uint32_t shape_span__name__key__member__ty[] = {LBL_span, LBL_name, LBL_key, LBL_member, LBL_ty};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s591410632x427349444(V, V, V);
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a);
extern Clo g_co_2ebind_24s591410632x427349444_clo;
V g_heff_2ecompile_2eprims_2eprims_get(void);
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eenvironment_2ecatchE(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ecatchE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ecatchE_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
V g_heff_2eelab_2eglobals_2eaddOwn(V, V, V);
V g_heff_2eelab_2eglobals_2eaddOwn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddOwn_clo;
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elitBytes(V, V);
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitBytes_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecordUpdate(V, V, V, V);
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordUpdate_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2eanyL(V, V);
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eanyL_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2ebodyEnv(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyEnv_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyEnv_clo;
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edeclJ(V);
V g_heff_2eelab_2etoplevel_2edeclJ_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_clo;
V g_heff_2eelab_2etoplevel_2eelabBody(V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_clo;
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2efailedAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2efailedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efailedAt_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2ekeepSt(V, V);
V g_heff_2eelab_2etoplevel_2ekeepSt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ekeepSt_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2ethawGlobals(V, V);
V g_heff_2eelab_2etoplevel_2ethawGlobals_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawGlobals_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2eelab_2etoplevel_2etopBroken(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopBroken_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopBroken_clo;
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V, V);
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo;
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(V, V);
V g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325_clo;
V g_heff_2eelab_2etoplevel_2etopTake(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopTake_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2eupdatePath(V, V, V);
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2etoplevel_2ewatchTake(V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V, V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewithInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithInstance_clo;
V g_heff_2eelab_2etoplevel_2ewithOne(V, V);
V g_heff_2eelab_2etoplevel_2ewithOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithOne_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2efilter_24s716173495x680820632(V, V);
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_clo;
V g_list_2efoldl_24f106956753x832547985(V, V, V);
V g_list_2efoldl_24f106956753x832547985_entry(V self, V *a);
extern Clo g_list_2efoldl_24f106956753x832547985_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_prelude_2etraverse_24s515579549x140669784(V);
V g_prelude_2etraverse_24s515579549x140669784_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s515579549x140669784_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfWalk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eselfWalk(V v_k_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam0, 2, 1, (V[]){heff_dup(v_k_240)}), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfWalk_lam1, 2, 1, (V[]){heff_dup(v_k_240)})});
}
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eselfWalk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam0(V self, V *args) {
  V v_d_241 = args[0];
  V v_t_242 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_240));
  return ({ V a_0 = v_t_243; V a_1 = v_k_240; V a_2 = v_d_241; V a_3 = v_t_242; V r_ = (g_heff_2eelab_2etoplevel_2eselfTermF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2eselfWalk_lam1(V self, V *args) {
  V v_d_244 = args[0];
  V v_t_245 = args[1];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_240));
  return ({ V a_0 = v_t_246; V a_1 = v_k_240; V a_2 = v_d_244; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eselfTypeF(a_0, a_1, a_2, a_3)); heff_drop(v_k_240); r_; });
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalChk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalChk_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalChk(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam0, 2, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalChk(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam3(V self, V *args) {
  V v_u_2410 = args[0];
  V v_x_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_x1_2411 = heff_tr(heff_call(heff_get_n(v_x_248, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2415});
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){heff_dup(heff_rfield(v_x_248, 0))});
  V f_ = v_k_247;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam3, 1, 1, (V[]){v_x_248})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_245;
  args[0] = v_hd_246;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam2, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalChk_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_a_242 = args[1];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_245;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkChk: {
    V v_f_243 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_244 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_245 = heff_tr(heff_call(v_f_243, 2, (V[]){v_t_244, v_a_242}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalChk_lam1, 2, 1, (V[]){v_c_245});
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_PatTag: {
        return NTAG(TAG_False);
      }
      case TAG_PatOp: {
        return NTAG(TAG_False);
      }
      case TAG_PatInt: {
        return NTAG(TAG_False);
      }
      case TAG_PatFloat: {
        return NTAG(TAG_False);
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        return NTAG(TAG_False);
      }
      case TAG_PatRune: {
        return NTAG(TAG_False);
      }
      case TAG_PatRecord: {
        return NTAG(TAG_False);
      }
      case TAG_PatWord: {
        return NTAG(TAG_False);
      }
      case TAG_PatAs: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eupdatePath_str0, 51, "an update sets a field by its name: `{ r | x = v }`");
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eupdatePath_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eupdatePath_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eupdatePath(V v_sp_240, V v_x2_241, V v_c_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_c_242);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam0, 2, 1, (V[]){v_sp_240});
  }
  case TAG_Cons: {
    V v_x21_249 = heff_field(v_x2_241, 0);
    V v_x22_2410 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_249)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_249, 0);
      V v_xsp_2412 = heff_field(v_x21_249, 1);
      heff_take_n(v_x21_249, 3ULL, 2);
      switch (heff_tag_of(v_x22_2410)) {
      case TAG_Nil: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam1, 2, 4, (V[]){v_x_2411, v_xsp_2412, v_sp_240, v_c_242});
      }
      case TAG_Cons: {
        V v_c_2417 = (g_heff_2eelab_2etoplevel_2eupdatePath(heff_dup(v_sp_240), v_x22_2410, v_c_242));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam2, 2, 4, (V[]){v_c_2417, v_x_2411, v_xsp_2412, v_sp_240});
      }
      default: return heff_nomatch(v_x22_2410);
      }
    }
    default: return heff_nomatch(v_x21_249);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eupdatePath_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eupdatePath(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k2_244 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eupdatePath_str0), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_247}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  args[0] = v_t_248;
  args[1] = v_k2_244;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_x_2411 = heff_env(self)[0];
  V v_xsp_2412 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_UpdateTo, 4, (V[]){v_x_2411, v_xsp_2412, v_sp_240, v_c_242});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_xsp_2412 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2420, NTAG(TAG_Nil)});
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_UpdateIn, 4, (V[]){v_x_2411, v_xsp_2412, v_sp_240, v_t_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eupdatePath_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_xsp_2412 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eupdatePath_lam3, 1, 4, (V[]){v_k_2419, v_x_2411, v_xsp_2412, v_sp_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V v_start_240, V v_s_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_start_240);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0, 2, 1, (V[]){v_s_241});
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x4_242, 0);
    V v_rest_246 = heff_field(v_x4_242, 1);
    V v_c_247 = ({ V a_0 = heff_dup(v_start_240); V a_1 = v_s_241; V a_2 = v_a_245; V r_ = (g_heff_2eelab_2etoplevel_2eelimF_24s5244280x1373327438(a_0, a_1, a_2)); heff_drop(v_s_241); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1, 2, 3, (V[]){v_c_247, v_start_240, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_s_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_s_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_start_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_start_240; V a_1 = v_x_2410; V a_2 = v_rest_246; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_start_240 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_lam2, 1, 4, (V[]){v_start_240, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0, 1, "r");
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam28(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam30(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam29(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_27_241 = heff_dup(heff_field(v_n_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_27_241)) {
    case TAG_IVar: {
      V v_x_243 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0, 2, 2, (V[]){v_sp_242, v_x_243});
    }
    case TAG_IInt: {
      V v_i_247 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1, 2, 2, (V[]){v_sp_242, v_i_247});
    }
    case TAG_IFloat: {
      V v_x_2411 = heff_tget_v(v_n1_27_241, 0);
      heff_take_na(v_n1_27_241, 0ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2, 2, 2, (V[]){v_sp_242, v_x_2411});
    }
    case TAG_IString: {
      V v_s_2415 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3, 2, 1, (V[]){v_s_2415});
    }
    case TAG_IBytes: {
      V v_s_2424 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6, 2, 2, (V[]){v_sp_242, v_s_2424});
    }
    case TAG_IPrim: {
      V v_p_2428 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7, 2, 2, (V[]){v_sp_242, v_p_2428});
    }
    case TAG_IRune: {
      V v_c_2432 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8, 2, 1, (V[]){v_c_2432});
    }
    case TAG_IApp: {
      V v_h_2441 = heff_field(v_n1_27_241, 0);
      V v_args_2442 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2443 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_2441)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11, 2, 3, (V[]){v_c_2443, v_h_2441, v_args_2442});
    }
    case TAG_IAnn: {
      V v_n0_2451 = heff_field(v_n1_27_241, 0);
      V v_n1_2452 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2453 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n0_2451));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13, 2, 2, (V[]){v_c_2453, v_n1_2452});
    }
    case TAG_ISpec: {
      V v_n0_2460 = heff_field(v_n1_27_241, 0);
      V v_x_2461 = heff_field(v_n1_27_241, 1);
      V v_v_2463 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 11ULL, 4);
      heff_drop(v_sp_242);
      V v_c_2464 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_v_2463));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16, 2, 4, (V[]){v_c_2464, v_n0_2460, v_n_240, v_x_2461});
    }
    case TAG_IUpdate: {
      V v_n0_2474 = heff_field(v_n1_27_241, 0);
      V v_fs_2475 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_c_2476 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_2474));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19, 2, 3, (V[]){v_c_2476, v_fs_2475, v_sp_242});
    }
    case TAG_IAnnLam: {
      V v_x_2486 = heff_field(v_n1_27_241, 0);
      V v_tyN_2488 = heff_field(v_n1_27_241, 2);
      V v_body_2489 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 13ULL, 4);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2490 = ({ V a_0 = v_tyN_2488; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2488); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22, 2, 3, (V[]){v_c_2490, v_body_2489, v_x_2486});
    }
    case TAG_IInvalid: {
      V v_code_2497 = heff_field(v_n1_27_241, 0);
      V v_why_2498 = heff_field(v_n1_27_241, 1);
      V v_n1_273_2499 = heff_field(v_n1_27_241, 2);
      heff_take_n(v_n1_27_241, 7ULL, 3);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_n1_273_2499)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam25, 2, 3, (V[]){v_code_2497, v_why_2498, v_sp_242});
      }
      case TAG_Just: {
        V v_note_24106 = heff_field(v_n1_273_2499, 0);
        heff_take_n(v_n1_273_2499, 1ULL, 1);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam26, 2, 4, (V[]){v_code_2497, v_why_2498, v_sp_242, v_note_24106});
      }
      default: return heff_nomatch(v_n1_273_2499);
      }
    }
    case TAG_INominal: {
      V v_i_24113 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_24114 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_24113));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam27, 2, 1, (V[]){v_c_24114});
    }
    case TAG_ILitEq: {
      V v_x_24119 = heff_field(v_n1_27_241, 0);
      V v_xsp_24120 = heff_field(v_n1_27_241, 1);
      V v_eq_24121 = heff_field(v_n1_27_241, 2);
      V v_lit_24122 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 15ULL, 4);
      heff_drop_tag(v_n_240, 2);
      V v_c_24123 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_lit_24122));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam29, 2, 5, (V[]){v_c_24123, v_sp_242, v_x_24119, v_xsp_24120, v_eq_24121});
    }
    default: return heff_nomatch(v_n1_27_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = (g_heff_2eelab_2erules_2efind(v_sp_242, v_x_243));
  V f_ = v_k_245;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_i_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2410 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_IntNum, 1, (V[]){v_i_247})));
  V f_ = v_k_249;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2412);
  V v_t_2414 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_nf(TAG_FracNum, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_2411))})));
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args) {
  V v_u_2421 = args[0];
  heff_drop(v_u_2421);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args) {
  V v_e_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2418);
  heff_drop(v_hd_2419);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_s_2415}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo)});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, NTAG(TAG_VPrimString)});
  V f_ = v_k_2420;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4, 3, 1, (V[]){v_s_2415})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_s_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2425);
  V v_t_2427 = (g_heff_2eelab_2erules_2elitBytes(v_sp_242, v_s_2424));
  V f_ = v_k_2426;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_p_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2429);
  V v_t_2431 = (g_heff_2eelab_2erules_2efindPrim(v_sp_242, v_p_2428));
  V f_ = v_k_2430;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args) {
  V v_u_2438 = args[0];
  heff_drop(v_u_2438);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args) {
  V v_e_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k_2437 = args[2];
  V v_c_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2435);
  heff_drop(v_hd_2436);
  V v_t_2439 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitRune, 1, (V[]){v_c_2432}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10_clo)});
  V v_t_2440 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, NTAG(TAG_VPrimRune)});
  V f_ = v_k_2437;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_c_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9, 3, 1, (V[]){v_c_2432})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args) {
  V v_x_2446 = args[0];
  V v_h_2441 = heff_env(self)[0];
  V v_args_2442 = heff_env(self)[1];
  V v_hd_2444 = heff_env(self)[2];
  V v_k_2445 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449;
  switch (heff_tag_of(v_h_2441)) {
  case TAG_At: {
    V v_s_2448 = heff_field(v_h_2441, 1);
    heff_take_n(v_h_2441, 2ULL, 2);
    v_t_2449 = v_s_2448;
    break;
  }
  default: heff_nomatch(v_h_2441);
  }
  V v_c_2450 = ({ V a_0 = heff_get_n(v_t_2449, 0, 2); V a_1 = v_x_2446; V a_2 = v_args_2442; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_args_2442); r_; });
  V f_ = v_c_2450;
  heff_room[0] = v_hd_2444;
  heff_room[1] = v_k_2445;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_c_2443 = heff_env(self)[0];
  V v_h_2441 = heff_env(self)[1];
  V v_args_2442 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2443;
  args[0] = heff_dup(v_hd_2444);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12, 1, 4, (V[]){v_h_2441, v_args_2442, v_hd_2444, v_k_2445});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args) {
  V v_x_2458 = args[0];
  V v_x_2456 = heff_env(self)[0];
  V v_k_2455 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = ({ V a_0 = v_x_2458; V a_1 = v_x_2456; V r_ = (g_heff_2eelab_2erules_2eannot(a_0, a_1)); heff_drop(v_x_2458); heff_drop(v_x_2456); r_; });
  V f_ = v_k_2455;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n1_2452 = heff_env(self)[0];
  V v_hd_2454 = heff_env(self)[1];
  V v_k_2455 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2457 = ({ V a_0 = v_n1_2452; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n1_2452); r_; });
  V f_ = v_c_2457;
  heff_room[0] = v_hd_2454;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15, 1, 2, (V[]){v_x_2456, v_k_2455});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k_2455 = args[1];
  V v_c_2453 = heff_env(self)[0];
  V v_n1_2452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2453;
  args[0] = heff_dup(v_hd_2454);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14, 1, 3, (V[]){v_n1_2452, v_hd_2454, v_k_2455});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args) {
  V v_x_2469 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2461 = heff_env(self)[1];
  V v_x_2467 = heff_env(self)[2];
  V v_k_2466 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2472;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2471 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2472 = v_s_2471;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_t_2473 = ({ V a_0 = v_t_2472; V a_1 = v_x_2469; V a_2 = v_x_2461; V a_3 = v_x_2467; V r_ = (g_heff_2eelab_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_2469); heff_drop(v_x_2467); r_; });
  V f_ = v_k_2466;
  args[0] = v_t_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args) {
  V v_x_2467 = args[0];
  V v_n0_2460 = heff_env(self)[0];
  V v_hd_2465 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2461 = heff_env(self)[3];
  V v_k_2466 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2468 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_2460));
  V f_ = v_c_2468;
  heff_room[0] = v_hd_2465;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18, 1, 4, (V[]){v_n_240, v_x_2461, v_x_2467, v_k_2466});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  V v_c_2464 = heff_env(self)[0];
  V v_n0_2460 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2461 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2464;
  args[0] = heff_dup(v_hd_2465);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17, 1, 5, (V[]){v_n0_2460, v_hd_2465, v_n_240, v_x_2461, v_k_2466});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args) {
  V v_x_2481 = args[0];
  V v_fs_2475 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2479 = heff_env(self)[2];
  V v_k_2478 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2475));
  V v_t_2483 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2482; V r_ = (g_list_2efoldl_24s1991317015x801331450(a_0, a_1)); heff_drop(v_t_2482); r_; });
  V v_t_2484 = ({ V a_0 = v_t_2483; V a_1 = ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0); V r_ = (g_heff_2eelab_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_2483); r_; });
  V v_x_2485 = ({ V a_0 = v_sp_242; V a_1 = v_x_2479; V a_2 = v_t_2484; V a_3 = v_x_2481; V r_ = (g_heff_2eelab_2erules_2erecordUpdate(a_0, a_1, a_2, a_3)); heff_drop(v_x_2479); r_; });
  V f_ = v_k_2478;
  args[0] = v_x_2485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args) {
  V v_x_2479 = args[0];
  V v_fs_2475 = heff_env(self)[0];
  V v_hd_2477 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_k_2478 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2480 = (g_prelude_2etraverse_24s515579549x140669784(heff_dup(v_fs_2475)));
  V f_ = v_c_2480;
  heff_room[0] = v_hd_2477;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21, 1, 4, (V[]){v_fs_2475, v_sp_242, v_x_2479, v_k_2478});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_c_2476 = heff_env(self)[0];
  V v_fs_2475 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2476;
  args[0] = heff_dup(v_hd_2477);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20, 1, 4, (V[]){v_fs_2475, v_hd_2477, v_sp_242, v_k_2478});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args) {
  V v_x_2495 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_x_2493 = heff_env(self)[1];
  V v_k_2492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2496 = ({ V a_0 = v_x_2486; V a_1 = v_x_2493; V a_2 = v_x_2495; V r_ = (g_heff_2eelab_2erules_2efunctionIntroSyn(a_0, a_1, a_2)); heff_drop(v_x_2493); heff_drop(v_x_2495); r_; });
  V f_ = v_k_2492;
  args[0] = v_t_2496;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args) {
  V v_x_2493 = args[0];
  V v_body_2489 = heff_env(self)[0];
  V v_hd_2491 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  V v_k_2492 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2494 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_body_2489));
  V f_ = v_c_2494;
  heff_room[0] = v_hd_2491;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24, 1, 3, (V[]){v_x_2486, v_x_2493, v_k_2492});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args) {
  V v_hd_2491 = args[0];
  V v_k_2492 = args[1];
  V v_c_2490 = heff_env(self)[0];
  V v_body_2489 = heff_env(self)[1];
  V v_x_2486 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2490;
  args[0] = heff_dup(v_hd_2491);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23, 1, 4, (V[]){v_body_2489, v_hd_2491, v_x_2486, v_k_2492});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam25(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k2_24101 = args[1];
  V v_code_2497 = heff_env(self)[0];
  V v_why_2498 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24102 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_2497), NTAG(TAG_SError), v_why_2498, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24102})});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tr(heff_call(heff_take_field(v_hd_24100, 2), 1, (V[]){v_t_24104}));
  V f_ = heff_get_n(v_hd_24100, 1, 3);
  args[0] = v_t_24105;
  args[1] = v_k2_24101;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam26(V self, V *args) {
  V v_hd_24107 = args[0];
  V v_k2_24108 = args[1];
  V v_code_2497 = heff_env(self)[0];
  V v_why_2498 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_note_24106 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24109 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_2497), NTAG(TAG_SError), v_why_2498, v_sp_242, heff_tag_n(TAG_Just, 1, (V[]){v_note_24106})});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tr(heff_call(heff_take_field(v_hd_24107, 2), 1, (V[]){v_t_24111}));
  V f_ = heff_get_n(v_hd_24107, 1, 3);
  args[0] = v_t_24112;
  args[1] = v_k2_24108;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam28(V self, V *args) {
  V v_x_24117 = args[0];
  V v_k_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24118 = ({ V a_0 = v_x_24117; V r_ = (g_heff_2eelab_2etoplevel_2enominalSyn(a_0)); heff_drop(v_x_24117); r_; });
  V f_ = v_k_24116;
  args[0] = v_t_24118;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam27(V self, V *args) {
  V v_hd_24115 = args[0];
  V v_k_24116 = args[1];
  V v_c_24114 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24114;
  args[0] = v_hd_24115;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam28, 1, 1, (V[]){v_k_24116});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam30(V self, V *args) {
  V v_x_24126 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_24119 = heff_env(self)[1];
  V v_xsp_24120 = heff_env(self)[2];
  V v_eq_24121 = heff_env(self)[3];
  V v_k_24125 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24127 = ({ V a_0 = v_sp_242; V a_1 = v_x_24119; V a_2 = v_xsp_24120; V a_3 = v_eq_24121; V a_4 = v_x_24126; V r_ = (g_heff_2eelab_2erules_2elitEq(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_24126); r_; });
  V f_ = v_k_24125;
  args[0] = v_t_24127;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam29(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_24119 = heff_env(self)[2];
  V v_xsp_24120 = heff_env(self)[3];
  V v_eq_24121 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24123;
  args[0] = v_hd_24124;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam30, 1, 5, (V[]){v_sp_242, v_x_24119, v_xsp_24120, v_eq_24121, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0, 48, "expected a field declaration of the form `x : A`");
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_c_2413)) {
  case TAG_At: {
    V v_s_2419 = heff_field(v_c_2413, 1);
    heff_take_n(v_c_2413, 2ULL, 2);
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_c_2413);
  }
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2417, v_t_2420})});
  V f_ = v_k_2416;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2414, v_hd_2415, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4, 1, 2, (V[]){v_c_2413, v_k_2416})));
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_243, v_x_2410, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2422;
  switch (heff_tag_of(v_d_246)) {
  case TAG_Nothing: {
    v_c_2422 = ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_d_246, 0);
    heff_take_n(v_d_246, 1ULL, 1);
    V v_t_2414 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2413)));
    v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3, 2, 2, (V[]){v_t_2414, v_c_2413});
    break;
  }
  default: heff_nomatch(v_d_246);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2425, 2), 1, (V[]){v_t_2429}));
  V f_ = heff_get_n(v_hd_2425, 1, 3);
  args[0] = v_t_2430;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
    }
    case TAG_CType: {
      V v_t_244 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return ({ V a_0 = v_n2_242; V a_1 = v_t_244; V r_ = (g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
    case TAG_CLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_248 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 2, (V[]){v_c_248, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_2441 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 2, 2, (V[]){v_c_2441, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_n1_241, 0ULL, 4);
      heff_drop(v_n2_242);
      V v_c_2475 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 2, 2, (V[]){v_c_2475, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_24108 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 2, 2, (V[]){v_c_24108, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24139 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 2, (V[]){v_c_24139, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24171 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 2, (V[]){v_c_24171, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24203 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 2, 2, (V[]){v_c_24203, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24235 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 2, 2, (V[]){v_c_24235, v_n_240});
    }
    case TAG_CAbandon: {
      heff_drop(v_n2_242);
      V v_c_24265 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 2, 2, (V[]){v_c_24265, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24296 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 2, 2, (V[]){v_c_24296, v_n_240});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2437;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2412 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_x_2437 = v_x_2411;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2412, 0ULL, 4);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_x_2437 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
      break;
    }
    default: heff_nomatch(v_x11_2412);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_2410;
  args[0] = v_x_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 2, (V[]){v_n_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_x_2444 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2470;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2445 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2445)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2445, 0ULL, 1);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2445, 0ULL, 1);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2445, 0ULL, 3);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2445, 0ULL, 3);
      v_x_2470 = v_x_2444;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2445, 0ULL, 4);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2445, 0ULL, 3);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2445, 0ULL, 1);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2445, 0ULL, 2);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2445, 0ULL, 2);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2445, 0ULL, 2);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2445, 0ULL, 1);
      v_x_2470 = ({ V a_0 = v_x_2444; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2444); r_; });
      break;
    }
    default: heff_nomatch(v_x11_2445);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_2443;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_c_2441 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2441;
  args[0] = v_hd_2442;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 1, 2, (V[]){v_n_240, v_k_2443});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_x_2478 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2477 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24104;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2479 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2479)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2479, 0ULL, 1);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2479, 0ULL, 1);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2479, 0ULL, 3);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2479, 0ULL, 3);
      v_x_24104 = v_x_2478;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2479, 0ULL, 4);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2479, 0ULL, 3);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2479, 0ULL, 1);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2479, 0ULL, 2);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2479, 0ULL, 2);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2479, 0ULL, 2);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2479, 0ULL, 1);
      v_x_24104 = ({ V a_0 = v_x_2478; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2478); r_; });
      break;
    }
    default: heff_nomatch(v_x11_2479);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_2477;
  args[0] = v_x_24104;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_hd_2476 = args[0];
  V v_k_2477 = args[1];
  V v_c_2475 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2475;
  args[0] = v_hd_2476;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 1, 2, (V[]){v_n_240, v_k_2477});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_24111 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24110 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24137;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24112 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24112)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24112, 0ULL, 1);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24112, 0ULL, 1);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24112, 0ULL, 3);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24112, 0ULL, 3);
      v_x_24137 = v_x_24111;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24112, 0ULL, 4);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24112, 0ULL, 3);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24112, 0ULL, 1);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24112, 0ULL, 2);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24112, 0ULL, 2);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24112, 0ULL, 2);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24112, 0ULL, 1);
      v_x_24137 = ({ V a_0 = v_x_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24111); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24112);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24110;
  args[0] = v_x_24137;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_hd_24109 = args[0];
  V v_k_24110 = args[1];
  V v_c_24108 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24108;
  args[0] = v_hd_24109;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 2, (V[]){v_n_240, v_k_24110});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_x_24142 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24141 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24168;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24143 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24143)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24143, 0ULL, 1);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24143, 0ULL, 1);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24143, 0ULL, 3);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24143, 0ULL, 3);
      v_x_24168 = v_x_24142;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24143, 0ULL, 4);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24143, 0ULL, 3);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24143, 0ULL, 1);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24143, 0ULL, 2);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24143, 0ULL, 2);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24143, 0ULL, 2);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24143, 0ULL, 1);
      v_x_24168 = ({ V a_0 = v_x_24142; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24142); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24143);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24141;
  args[0] = v_x_24168;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_hd_24140 = args[0];
  V v_k_24141 = args[1];
  V v_c_24139 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24139;
  args[0] = v_hd_24140;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 2, (V[]){v_n_240, v_k_24141});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_x_24174 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24173 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24200;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24175 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24175)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24175, 0ULL, 1);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24175, 0ULL, 1);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24175, 0ULL, 3);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24175, 0ULL, 3);
      v_x_24200 = v_x_24174;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24175, 0ULL, 4);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24175, 0ULL, 3);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24175, 0ULL, 1);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24175, 0ULL, 2);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24175, 0ULL, 2);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24175, 0ULL, 2);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24175, 0ULL, 1);
      v_x_24200 = ({ V a_0 = v_x_24174; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24174); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24175);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24173;
  args[0] = v_x_24200;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24172 = args[0];
  V v_k_24173 = args[1];
  V v_c_24171 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24171;
  args[0] = v_hd_24172;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 1, 2, (V[]){v_n_240, v_k_24173});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_x_24206 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24205 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24232;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24207 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24207)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24207, 0ULL, 1);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24207, 0ULL, 1);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24207, 0ULL, 3);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24207, 0ULL, 3);
      v_x_24232 = v_x_24206;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24207, 0ULL, 4);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24207, 0ULL, 3);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24207, 0ULL, 1);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24207, 0ULL, 2);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24207, 0ULL, 2);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24207, 0ULL, 2);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24207, 0ULL, 1);
      v_x_24232 = ({ V a_0 = v_x_24206; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24206); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24207);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24205;
  args[0] = v_x_24232;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_hd_24204 = args[0];
  V v_k_24205 = args[1];
  V v_c_24203 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24203;
  args[0] = v_hd_24204;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 1, 2, (V[]){v_n_240, v_k_24205});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24238 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24237 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24264;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24239 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24239)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24239, 0ULL, 1);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24239, 0ULL, 1);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24239, 0ULL, 3);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24239, 0ULL, 3);
      v_x_24264 = v_x_24238;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24239, 0ULL, 4);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24239, 0ULL, 3);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24239, 0ULL, 1);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24239, 0ULL, 2);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24239, 0ULL, 2);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24239, 0ULL, 2);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24239, 0ULL, 1);
      v_x_24264 = ({ V a_0 = v_x_24238; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24238); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24239);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24237;
  args[0] = v_x_24264;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_hd_24236 = args[0];
  V v_k_24237 = args[1];
  V v_c_24235 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24235;
  args[0] = v_hd_24236;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 2, (V[]){v_n_240, v_k_24237});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_x_24268 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24267 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24294;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24269 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24269)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24269, 0ULL, 1);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24269, 0ULL, 1);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24269, 0ULL, 3);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24269, 0ULL, 3);
      v_x_24294 = v_x_24268;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24269, 0ULL, 4);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24269, 0ULL, 3);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24269, 0ULL, 1);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24269, 0ULL, 2);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24269, 0ULL, 2);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24269, 0ULL, 2);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24269, 0ULL, 1);
      v_x_24294 = ({ V a_0 = v_x_24268; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24268); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24269);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24267;
  args[0] = v_x_24294;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_hd_24266 = args[0];
  V v_k_24267 = args[1];
  V v_c_24265 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24265;
  args[0] = v_hd_24266;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 1, 2, (V[]){v_n_240, v_k_24267});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_x_24299 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24298 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24325;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24300 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24300)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24300, 0ULL, 1);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24300, 0ULL, 1);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24300, 0ULL, 3);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24300, 0ULL, 3);
      v_x_24325 = v_x_24299;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24300, 0ULL, 4);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24300, 0ULL, 3);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24300, 0ULL, 1);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24300, 0ULL, 2);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24300, 0ULL, 2);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24300, 0ULL, 2);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24300, 0ULL, 1);
      v_x_24325 = ({ V a_0 = v_x_24299; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24299); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24300);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24298;
  args[0] = v_x_24325;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_hd_24297 = args[0];
  V v_k_24298 = args[1];
  V v_c_24296 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24296;
  args[0] = v_hd_24297;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 1, 2, (V[]){v_n_240, v_k_24298});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = ({ V a_0 = v_t_243; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2411); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2432 = heff_field(v_x2_240, 2);
    V v_t_2433 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2434 = ({ V a_0 = v_t_2433; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2433); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2434, v_sp_2432, v_x_2430});
  }
  case TAG_PiAnon: {
    V v_d_2438 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2439 = ({ V a_0 = v_d_2438; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_d_2438); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2439});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2422;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2428;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    v_c_2428 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_t_2420, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2432, v_x_2430, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2436, v_sp_2432, v_x_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithArgs_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithArgs(V v_x1_240, V v_base_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_base_241;
  }
  case TAG_Cons: {
    V v_ab_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_rest_243, v_base_241));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2ewithOne(heff_dup(v_ab_242), v_t_244);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ewithArgs(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eanyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eanyL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eanyL(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2eanyL_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eanyL(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str0, 5, " and ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str1, 14, " are not equal");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str2, 50, "the implicit arguments found do not fit together: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str3, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, "`, it would need ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str5, 11, "found for `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str6, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str7, 24, " does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str8, 35, "cannot infer an implicit argument: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str9, 9, " := ...)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str10, 14, "`: give it, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str11, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str12, 25, ", does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str13, 21, "what is known of it, ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str14, 36, "cannot infer the implicit argument `");
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2), heff_strAppend(heff_dup(v_left_243), v_t_246));
    V v_t_249;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_249 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_248 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_249 = heff_get_n(v_me_248, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2413;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_2410 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2411 = heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), v_right_244));
      V v_t_2412 = heff_strAppend(heff_get_n(v_me_2410, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4), v_t_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5), v_t_2412)});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_247, v_t_249, v_t_2413});
  } else {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7)));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8), heff_strAppend(v_left_243, v_t_2414));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2415, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2416 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_me_2416, 4)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9));
      V v_t_2418 = heff_strAppend(heff_take_field(v_me_2416, 4), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10), v_t_2417));
      V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12)));
      V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13), heff_strAppend(v_left_243, v_t_2419));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14), v_t_2418), heff_get_n(v_me_2416, 5, 6), heff_tag_n(TAG_Just, 1, (V[]){v_t_2420})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str0, 21, "`; give it as `{...}`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2ebodyPhase_str1, 36, "cannot infer the implicit argument `");
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebodyPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ebodyPhase(V v_dsp_240, V v_d_241, V v_gSelf_242, V v_k_243, V v_aval_244) {
top: ;
  V v_e_245 = (g_heff_2eelab_2etoplevel_2ebodyEnv(heff_dup(v_gSelf_242), v_k_243, heff_take_field(v_d_241, 0), heff_dup(v_aval_244)));
  V v_t_246 = heff_get_n(v_d_241, 2, 4);
  V v_t_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_t_248 = heff_tr(heff_call(v_f_247, 2, (V[]){v_e_245, heff_dup(v_aval_244)}));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam0, 2, 4, (V[]){v_aval_244, v_t_248, v_gSelf_242, v_dsp_240});
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebodyPhase(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam7(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V f_ = v_k_2419;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam6(V self, V *args) {
  V v_unsolved_2417 = args[0];
  V v_hd_2418 = args[1];
  V v_k_2419 = args[2];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_unsolved_2417)) {
  case TAG_Nil: {
    heff_drop_rec(v_hd_2418, 3);
    V f_ = v_k_2419;
    args[0] = v_x_2412;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_u_2420 = heff_field(v_unsolved_2417, 0);
    heff_take_n(v_unsolved_2417, 1ULL, 2);
    V v_t_2422 = heff_strAppend(heff_take_field(v_u_2420, 0), ((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str0));
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2ebodyPhase_str1), v_t_2422), heff_get_n(v_u_2420, 1, 2), NTAG(TAG_Nothing)});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_2418, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_2418, 1, 3);
    args[0] = v_t_2426;
    args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam7, 1, 2, (V[]){v_k_2419, v_x_2412});
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_unsolved_2417);
  }
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2416);
  return (g_co_2ebind_24s591410632x427349444(heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam6, 3, 1, (V[]){v_x_2412}), v_hd_249, v_k_2410));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_dsp_240 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  return ({ V a_0 = v_gSelf_242; V a_1 = v_dsp_240; V a_2 = v_x_2413; V a_3 = heff_dup(v_hd_249); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam5, 1, 3, (V[]){v_x_2412, v_hd_249, v_k_2410}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_2413); r_; });
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_x_2412 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2414);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam4, 1, 6, (V[]){v_gSelf_242, v_dsp_240, v_x_2413, v_hd_249, v_x_2412, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_gSelf_242 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam3, 1, 6, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2413, v_x_2412, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_gSelf_242 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_dsp_240 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_gSelf_242), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam2, 1, 5, (V[]){v_hd_249, v_gSelf_242, v_dsp_240, v_x_2412, v_k_2410})));
}
V g_heff_2eelab_2etoplevel_2ebodyPhase_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_aval_244 = heff_env(self)[0];
  V v_t_248 = heff_env(self)[1];
  V v_gSelf_242 = heff_env(self)[2];
  V v_dsp_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2etoplevel_2efailedAt_clo), 1, (V[]){v_aval_244}));
  return (g_heff_2eelab_2eenvironment_2ecatchE(v_t_248, v_t_2411, heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2etoplevel_2ebodyPhase_lam1, 1, 4, (V[]){v_gSelf_242, v_hd_249, v_dsp_240, v_k_2410})));
}
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 9, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_isInstance_243, V v_tyStx_244, V v_mc_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Left: {
    V v_failed_249 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2410 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2411;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      v_key_2411 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2410);
      v_key_2411 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2412 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2413;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      heff_drop(v_t_2412);
      v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2412);
      v_t_2413 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_entry_2414 = ({ V a_0 = v_g_241; V a_1 = v_t_2413; V a_2 = v_tyStx_244; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2411, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2414, heff_tag_n(TAG_Just, 1, (V[]){v_failed_249})});
    return heff_tail(v_z_248, 1, (V[]){v_t_2415});
  }
  case TAG_Right: {
    V v_t_2416 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2417 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2418;
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      v_key_2418 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2417);
      v_key_2418 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2419 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2420;
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2419);
      v_t_2420 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2421 = heff_dup(heff_rfield(v_d_242, 3));
    V v_k_2422;
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      heff_drop(v_t_2421);
      v_k_2422 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2421);
      v_k_2422 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2423 = (g_heff_2eelab_2eunify_2ezonker(v_mc_245));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_t_2423, 0, 2), 1, (V[]){heff_get_n(v_t_2416, 0, 2)}));
    V v_t_2425 = ({ V a_0 = v_k_2422; V r_ = (g_heff_2eelab_2etoplevel_2eselfWalk(a_0)); heff_drop(v_k_2422); r_; });
    V v_t_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2424}));
    V v_entry_2427 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2420, heff_rfield(v_d_242, 3), v_tyStx_244, v_t_2426));
    V v_t_2428 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2418, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2427, NTAG(TAG_Nothing)});
    return heff_tail(v_z_248, 1, (V[]){v_t_2428});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a7 = a[7]; V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a5, a[6], a7, a[8]); heff_drop(a5); heff_drop(a7); return r;
}

static V g_heff_2eelab_2etoplevel_2eprimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2eprimNames_st;
static V g_heff_2eelab_2etoplevel_2eprimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2eprims_get())));
}
V g_heff_2eelab_2etoplevel_2eprimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2eprimNames_st)) return g_heff_2eelab_2etoplevel_2eprimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2eprimNames_val, &g_heff_2eelab_2etoplevel_2eprimNames_st, g_heff_2eelab_2etoplevel_2eprimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchEntry_str0, 7, "> watch");
Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_call(heff_get_n(v_t_246, 1, 2), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 1, (V[]){heff_get_n(v_t_242, 0, 2)}));
  V v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2eelab_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2419;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2415 = v_field_2413;
      v_t_2419 = v_x_2415;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2417 = v_field_2413;
        heff_drop(v_x11_2417);
        v_t_2419 = heff_abandon();
      } else {
        V v_x_2418 = v_field_2413;
        v_t_2419 = v_x_2418;
      }
    }
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2419});
}
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ewatchEntry(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithBrokenInstance_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewithBrokenInstance(V v_kf_240, V v_n_241, V v_g_242) {
top: ;
  V v_t_2425;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_243 = heff_dup(heff_field(v_n_241, 0));
    switch (heff_tag_of(v_x11_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_f_245});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2410 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 5);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2415 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 4);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 3);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2419});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2422 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 2);
      v_t_2425 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2422});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_243, 0ULL, 1);
      v_t_2425 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_243);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Nothing: {
    heff_drop(v_kf_240);
    heff_drop(v_n_241);
    return v_g_242;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    switch (heff_tag_of(v_n_241)) {
    case TAG_At: {
      V v_x11_2427 = heff_field(v_n_241, 0);
      V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_2427)) {
      case TAG_DeclEquations: {
        V v_x113_2431 = heff_field(v_x11_2427, 2);
        heff_take_n(v_x11_2427, 4ULL, 5);
        switch (heff_tag_of(v_x113_2431)) {
        case TAG_AsDefinition: {
          heff_drop(v_kf_240);
          heff_drop(v_x_2426);
          heff_drop_cell(v_ru_24n_241_24At, 2);
          return v_g_242;
        }
        case TAG_AsInstance: {
          V v_k_2434 = heff_tr(heff_call(heff_dup(v_kf_240), 1, (V[]){heff_dup(v_x_2426)}));
          V v_key_2435 = heff_tr(heff_call(v_kf_240, 1, (V[]){heff_dup(v_x_2426)}));
          V v_t_2438;
          if (heff_strEq_c_lent(v_key_2435, v_x_2426, 0)) {
            heff_drop(v_x_2426);
            heff_drop(v_key_2435);
            v_t_2438 = ((V)&g_heff_2eelab_2etoplevel_2ewithBrokenInstance_str0);
          } else {
            int64_t v_t_2437 = (heff_unbox_word(heff_strLength_lent(v_key_2435, 0)) - heff_unbox_word(heff_strLength(v_x_2426)));
            v_t_2438 = heff_strSlice(v_key_2435, MK_INT(0LL), heff_box_word((v_t_2437 - ((int64_t)1ULL))));
          }
          V v_t_2439 = (g_list_2efilter_24s716173495x680820632(v_k_2434, heff_take_field(v_g_242, 7)));
          V v_t_2440 = heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_k_2434, v_t_2438}), v_t_2439});
          return ({ V rv_7 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_g_242, 127ULL, 8, shape_order__entries__aliases__broken__ambiguous__places__hidden__instances, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
        }
        default: return heff_nomatch(v_x113_2431);
        }
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_2427, 0ULL, 5);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_2427, 0ULL, 4);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_2427, 0ULL, 3);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_2427, 0ULL, 2);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2427, 0ULL, 1);
        heff_drop(v_kf_240);
        heff_drop(v_x_2426);
        heff_drop_cell(v_ru_24n_241_24At, 2);
        return v_g_242;
      }
      default: return heff_nomatch(v_x11_2427);
      }
    }
    default: return heff_nomatch(v_n_241);
    }
  }
  default: return heff_nomatch(v_t_2425);
  }
}
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithBrokenInstance(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2etopTake_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etopTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopTake_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2etopTake(V v_kf_240, V v_acc_241, V v_n_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_Left: {
      V v_d_246 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_243_24MkPair, 2);
      V v_t_247 = (g_heff_2eelab_2etoplevel_2ekeepSt(v_st_245, heff_dup(v_acc_241)));
      V v_t_2411;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_248 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2411 = v_c_248;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2411, 1, 8)));
      V v_t_2413 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2412));
      V v_t_2415;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_246, 0)), MK_INT(-1LL))) {
        heff_drop_rec(v_d_246, 5);
        v_t_2415 = NTAG(TAG_Nil);
      } else {
        v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_246, NTAG(TAG_Nil)});
      }
      V v_t_2416 = (g_list_2efoldl_24f106956753x832547985(heff_get_n(v_acc_241, 1, 9), v_t_2413, v_t_2415));
      HEFF_LAST return g_heff_2eelab_2etoplevel_2etopBroken(v_kf_240, v_t_247, v_n_242, v_t_2416);
    }
    case TAG_Right: {
      V v_r_2417 = heff_field(v_x41_244, 0);
      heff_take_n(v_x41_244, 1ULL, 1);
      heff_drop(v_kf_240);
      V v_g_2418 = heff_take_field(v_acc_241, 0);
      V v_t_2419 = heff_take_field(v_r_2417, 2);
      V v_t_2425;
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        HeffT2 v_t_2420 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_2418, 1), heff_rfield(v_r_2417, 1)));
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_e_2424 = v_field_2422;
            heff_drop(v_e_2424);
            v_t_2425 = v_g_2418;
          } else {
            heff_drop(v_field_2422);
            v_t_2425 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2417, 1)), heff_dup(heff_rfield(v_r_2417, 4)), v_g_2418));
          }
        }
      } else {
        heff_drop(v_t_2419);
        v_t_2425 = (g_heff_2eelab_2eglobals_2eaddEntry(heff_dup(heff_rfield(v_r_2417, 1)), heff_dup(heff_rfield(v_r_2417, 4)), v_g_2418));
      }
      V v_t_2426 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_r_2417, 0)), heff_dup(heff_rfield(v_r_2417, 1)), v_t_2425));
      V v_globals_2427 = (g_heff_2eelab_2etoplevel_2ewithInstance(heff_rfield(v_r_2417, 3), heff_dup(heff_rfield(v_r_2417, 1)), heff_rfield(v_r_2417, 0), v_t_2426));
      V v_t_2431;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2428 = heff_dup(heff_field(v_st_245, 0));
        v_t_2431 = v_c_2428;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2431, 1, 8)));
      V v_t_2433 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2432));
      V v_t_2434 = heff_take_field(v_r_2417, 5);
      V v_t_2437;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_Nothing: {
        v_t_2437 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2435 = heff_field(v_t_2434, 0);
        heff_take_n(v_t_2434, 1ULL, 1);
        if (heff_intEq_c(heff_dup(heff_rfield(v_d_2435, 0)), MK_INT(-1LL))) {
          heff_drop_rec(v_d_2435, 5);
          v_t_2437 = NTAG(TAG_Nil);
        } else {
          v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_d_2435, NTAG(TAG_Nil)});
        }
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      V v_diags_2438 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_241, 1), v_t_2433, v_t_2437));
      V v_t_2442;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2439 = heff_dup(heff_field(v_st_245, 0));
        v_t_2442 = v_c_2439;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_infos_2449 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_241, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_lam0, 1, 1, (V[]){heff_dup(v_st_245)}), heff_get_n(v_t_2442, 0, 8)));
      V v_t_2453;
      switch (heff_tag_of(v_st_245)) {
      case TAG_MkSt: {
        V v_c_2450 = heff_field(v_st_245, 0);
        heff_take_n(v_st_245, 1ULL, 3);
        v_t_2453 = v_c_2450;
        break;
      }
      default: heff_nomatch(v_st_245);
      }
      V v_trace_2454 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2453, 6, 8), heff_take_field(v_acc_241, 8)));
      V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_2417, 1), heff_take_field(v_acc_241, 2)});
      V v_t_2458;
      switch (heff_tag_of(v_n_242)) {
      case TAG_At: {
        V v_s_2457 = heff_field(v_n_242, 1);
        heff_take_n(v_n_242, 2ULL, 2);
        v_t_2458 = v_s_2457;
        break;
      }
      default: heff_nomatch(v_n_242);
      }
      V v_t_2459 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_r_2417, 0, 6), v_t_2458});
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2459, heff_take_field(v_acc_241, 6)});
      return ({ V rv_0 = v_globals_2427; V rv_1 = v_diags_2438; V rv_2 = v_t_2455; V rv_6 = v_t_2460; V rv_7 = v_infos_2449; V rv_8 = v_trace_2454; V rr_ = heff_rec_reuse_nf(v_acc_241, 56ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 4032u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2etopTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etopTake(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam1(V self, V *args) {
  V v_u_2444 = args[0];
  V v_st_245 = heff_env(self)[0];
  V v_n_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2444);
  V v_t_2448;
  switch (heff_tag_of(v_st_245)) {
  case TAG_MkSt: {
    V v_c_2445 = heff_field(v_st_245, 0);
    heff_take_n(v_st_245, 1ULL, 3);
    v_t_2448 = v_c_2445;
    break;
  }
  default: heff_nomatch(v_st_245);
  }
  V f_ = heff_get_n(v_n_2443, 4, 5);
  args[0] = heff_get_n(v_t_2448, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etopTake_lam0(V self, V *args) {
  V v_n_2443 = args[0];
  V v_st_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2etopTake_lam1, 1, 2, (V[]){v_st_245, heff_dup(v_n_2443)}); V rr_ = heff_rec_reuse_nf(v_n_2443, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchTake_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchTake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchTake_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2ewatchTake(V v_acc_240, V v_sp_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_st_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_Left: {
      V v_d_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop(v_sp_241);
      V v_t_249;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_246 = heff_dup(heff_field(v_st_244, 0));
        v_t_249 = v_c_246;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_249, 1, 8)));
      V v_t_2411 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2410));
      V v_t_2413;
      if (heff_intEq_c(heff_dup(heff_rfield(v_d_245, 0)), MK_INT(-1LL))) {
        heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
        heff_drop_rec(v_d_245, 5);
        v_t_2413 = NTAG(TAG_Nil);
      } else {
        v_t_2413 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_d_245, NTAG(TAG_Nil)});
      }
      V v_diags_2414 = (g_list_2efoldl_24f106956753x832547985(heff_take_field(v_acc_240, 1), v_t_2411, v_t_2413));
      V v_t_2418;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2415 = heff_dup(heff_field(v_st_244, 0));
        v_t_2418 = v_c_2415;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2425 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_240, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam0, 1, 1, (V[]){heff_dup(v_st_244)}), heff_get_n(v_t_2418, 0, 8)));
      V v_t_2429;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2426 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2429 = v_c_2426;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2430 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2429, 6, 8), heff_take_field(v_acc_240, 8)));
      return ({ V rv_1 = v_diags_2414; V rv_7 = v_infos_2425; V rv_8 = v_trace_2430; V rr_ = heff_rec_reuse_nf(v_acc_240, 125ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 16371u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    case TAG_Right: {
      V v_entry_2431 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2435;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2432 = heff_dup(heff_field(v_st_244, 0));
        v_t_2435 = v_c_2432;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2435, 1, 8)));
      V v_t_2437 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_t_2436));
      V v_diags_2438 = (g_list_2efoldl_24s1370882877x364361272(heff_take_field(v_acc_240, 1), v_t_2437));
      V v_t_2442;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2439 = heff_dup(heff_field(v_st_244, 0));
        v_t_2442 = v_c_2439;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_infos_2449 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(heff_take_field(v_acc_240, 7), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam2, 1, 1, (V[]){heff_dup(v_st_244)}), heff_get_n(v_t_2442, 0, 8)));
      V v_t_2453;
      switch (heff_tag_of(v_st_244)) {
      case TAG_MkSt: {
        V v_c_2450 = heff_field(v_st_244, 0);
        heff_take_n(v_st_244, 1ULL, 3);
        v_t_2453 = v_c_2450;
        break;
      }
      default: heff_nomatch(v_st_244);
      }
      V v_trace_2454 = (g_heff_2eelab_2etoplevel_2eappendT(heff_get_n(v_t_2453, 6, 8), heff_take_field(v_acc_240, 8)));
      V v_t_2455 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_span__entry, (V[]){v_sp_241, v_entry_2431}), heff_dup(heff_rfield(v_acc_240, 4))});
      return ({ V rv_1 = v_diags_2438; V rv_4 = v_t_2455; V rv_7 = v_infos_2449; V rv_8 = v_trace_2454; V rr_ = heff_rec_reuse_nf(v_acc_240, 109ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 15603u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchTake_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewatchTake(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam1(V self, V *args) {
  V v_u_2420 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_n_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2420);
  V v_t_2424;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_2421 = heff_field(v_st_244, 0);
    heff_take_n(v_st_244, 1ULL, 3);
    v_t_2424 = v_c_2421;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V f_ = heff_get_n(v_n_2419, 4, 5);
  args[0] = heff_get_n(v_t_2424, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam0(V self, V *args) {
  V v_n_2419 = args[0];
  V v_st_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam1, 1, 2, (V[]){v_st_244, heff_dup(v_n_2419)}); V rr_ = heff_rec_reuse_nf(v_n_2419, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam3(V self, V *args) {
  V v_u_2444 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_n_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2444);
  V v_t_2448;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_2445 = heff_field(v_st_244, 0);
    heff_take_n(v_st_244, 1ULL, 3);
    v_t_2448 = v_c_2445;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V f_ = heff_get_n(v_n_2443, 4, 5);
  args[0] = heff_get_n(v_t_2448, 3, 8);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchTake_lam2(V self, V *args) {
  V v_n_2443 = args[0];
  V v_st_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V rv_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchTake_lam3, 1, 2, (V[]){v_st_244, heff_dup(v_n_2443)}); V rr_ = heff_rec_reuse_nf(v_n_2443, 15ULL, 5, shape_span__name__key__member__ty, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10, 2, 0};
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(V v_key_240, V v_g_241, V v_n_242, V v_st_243) {
top: ;
  V v_c_247;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_c_244 = heff_dup(heff_field(v_st_243, 0));
    v_c_247 = v_c_244;
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  V v_c_248 = (g_heff_2eelab_2etoplevel_2edeclJ(v_n_242));
  V v_t_2413;
  switch (heff_tag_of(v_st_243)) {
  case TAG_MkSt: {
    V v_d_2410 = heff_field(v_st_243, 1);
    V v_w_2411 = heff_field(v_st_243, 2);
    V v_ru_24st_243_24MkSt = heff_take_reuse_n(v_st_243, 6ULL, 3);
    V v_t_2412 = ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_247, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    v_t_2413 = heff_tag_at_n(v_ru_24st_243_24MkSt, TAG_MkSt, 3, (V[]){v_t_2412, v_d_2410, v_w_2411});
    break;
  }
  default: heff_nomatch(v_st_243);
  }
  return heff_tail(v_c_248, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0, 1, 3, (V[]){v_g_241, heff_dup(v_n_242), v_key_240}), v_t_2413});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  heff_drop(v_hd_2455);
  V f_ = v_k_2456;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10(V self, V *args) {
  V v_a_2462 = args[0];
  V v_a_2463 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_a_2462}), v_a_2463});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9(V self, V *args) {
  V v_x_2461 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  V v_n_242 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2461);
  return ({ V a_0 = v_key_240; V a_1 = v_g_241; V a_2 = v_n_242; V a_3 = v_x_2414; V a_4 = v_x_2419; V a_5 = heff_dup(g_heff_2eelab_2emeta_2eelabH_get()); V a_6 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam10_clo); V r_ = (g_heff_2eelab_2etoplevel_2eelabBody(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_n_242); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_2421 = args[1];
  V v_n_242 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  V v_g_241 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2420);
  V v_c_2460;
  switch (heff_tag_of(v_n_242)) {
  case TAG_At: {
    V v_x11_2422 = heff_dup(heff_field(v_n_242, 0));
    switch (heff_tag_of(v_x11_2422)) {
    case TAG_DeclEquations: {
      V v_x113_2426 = heff_field(v_x11_2422, 2);
      V v_tyN_2427 = heff_field(v_x11_2422, 3);
      heff_take_n(v_x11_2422, 12ULL, 5);
      switch (heff_tag_of(v_x113_2426)) {
      case TAG_AsDefinition: {
        heff_drop(v_tyN_2427);
        v_c_2460 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam3_clo);
        break;
      }
      case TAG_AsInstance: {
        V v_t_2433;
        switch (heff_tag_of(v_tyN_2427)) {
        case TAG_At: {
          V v_s_2432 = heff_field(v_tyN_2427, 1);
          heff_take_n(v_tyN_2427, 2ULL, 2);
          v_t_2433 = v_s_2432;
          break;
        }
        default: heff_nomatch(v_tyN_2427);
        }
        V v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(heff_dup(heff_rfield(v_x_2419, 0))));
        v_c_2460 = (g_heff_2eelab_2etoplevel_2esearchedInstance(v_t_2433, NTAG(TAG_Nil), MK_INT(0LL), v_t_2434));
        break;
      }
      default: heff_nomatch(v_x113_2426);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2422, 0ULL, 5);
      v_c_2460 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam4_clo);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2422, 0ULL, 4);
      v_c_2460 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam5_clo);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2422, 0ULL, 3);
      v_c_2460 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam6_clo);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2422, 0ULL, 2);
      v_c_2460 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam7_clo);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2422, 0ULL, 1);
      v_c_2460 = ((V)&g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam8_clo);
      break;
    }
    default: heff_nomatch(v_x11_2422);
    }
    break;
  }
  default: heff_nomatch(v_n_242);
  }
  V f_ = v_c_2460;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam9, 1, 5, (V[]){v_key_240, v_g_241, v_n_242, v_x_2414, v_x_2419});
  heff_room[2] = v_z_2421;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1(V self, V *args) {
  V v_x_2419 = args[0];
  V v_n_242 = heff_env(self)[0];
  V v_key_240 = heff_env(self)[1];
  V v_g_241 = heff_env(self)[2];
  V v_x_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam2, 2, 5, (V[]){v_n_242, v_x_2419, v_key_240, v_g_241, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_g_241 = heff_env(self)[0];
  V v_n_242 = heff_env(self)[1];
  V v_key_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_dup(heff_rfield(v_x_2414, 1));
  V v_c_2418;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_MkTyp: {
    V v_f_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    V v_t_2417 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_241), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    v_c_2418 = heff_tr(heff_call(v_f_2416, 1, (V[]){v_t_2417}));
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V f_ = v_c_2418;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabDecl_24s31807341x277521901_lam1, 1, 4, (V[]){v_n_242, v_key_240, v_g_241, v_x_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(V v_acc_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    V v_diags_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_keys_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
    V v_broken_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 3)));
    V v_watches_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 4)));
    V v_tests_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 5)));
    V v_spans_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
    V v_infos_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 7)));
    V v_trace_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 8)));
    return ({ V rv_1 = v_diags_242; V rv_2 = v_keys_243; V rv_3 = v_broken_244; V rv_4 = v_watches_245; V rv_5 = v_tests_246; V rv_6 = v_spans_247; V rv_7 = v_infos_248; V rv_8 = v_trace_249; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2410 = heff_field(v_x3_241, 0);
    V v_rest_2411 = heff_field(v_x3_241, 1);
    V v_t_2412 = (g_heff_2eelab_2etoplevel_2etopOne_24s1425992599x1413077325(v_acc_240, heff_dup(v_n_2410)));
    V t_0 = v_t_2412;
    V t_1 = v_rest_2411;
    v_acc_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2etopGo_24s2086871073x49895751(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eisPrimB(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2ethawOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawOne_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ethawOne(V v_acc_240, V v_d_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2etoplevel_2eisPrimB(heff_rfield(v_d_241, 5)));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 1, 8);
    HeffT2 v_t_244 = ({ V a_0 = v_t_243; V a_1 = heff_rfield(v_d_241, 1); HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_e_248 = v_field_246;
        heff_drop(v_e_248);
        V v_g_249 = (g_heff_2eelab_2eglobals_2eaddOwn(heff_dup(heff_rfield(v_d_241, 0)), heff_dup(heff_rfield(v_d_241, 1)), heff_take_field(v_acc_240, 0)));
        V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
        V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_take_field(v_acc_240, 6)});
        return ({ V rv_0 = v_g_249; V rv_2 = v_t_2410; V rv_6 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
      } else {
        heff_drop(v_field_246);
        V v_g_2413 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
        V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_take_field(v_acc_240, 6)});
        return ({ V rv_0 = v_g_2413; V rv_2 = v_t_2414; V rv_6 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
      }
    }
  } else {
    heff_drop(v_t_242);
    V v_g_2417 = (g_heff_2eelab_2etoplevel_2ethawGlobals(heff_dup(v_acc_240), heff_dup(v_d_241)));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_d_241, 1), heff_take_field(v_acc_240, 2)});
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_d_241, 0), heff_get_n(v_d_241, 3, 6)});
    V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, heff_take_field(v_acc_240, 6)});
    return ({ V rv_0 = v_g_2417; V rv_2 = v_t_2418; V rv_6 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_240, 442ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249804u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
  }
}
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawOne(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V v_ys_240, V v_f_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_setField(v_d_243, MK_INT(1LL), v_ys_240);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_246 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_244}));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_ys_240;
    V t_1 = v_f_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_ys_240 = t_0;
    v_f_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(a[0], a[1], a[2], a[3]);
}