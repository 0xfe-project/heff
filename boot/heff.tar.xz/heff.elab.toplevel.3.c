// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Anonymous 24551
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588 6711
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_LNil 57394
#define TAG_Left 13886
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_prim 9944941
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_value 313331083
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_heff_2ecompile_2eprims_2eprims_get(void);
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(V, V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(V, V, V);
V g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2(V, V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_24tok2_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_PatTag: {
        return NTAG(TAG_False);
      }
      case TAG_PatOp: {
        return NTAG(TAG_False);
      }
      case TAG_PatInt: {
        return NTAG(TAG_False);
      }
      case TAG_PatFloat: {
        return NTAG(TAG_False);
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        return NTAG(TAG_False);
      }
      case TAG_PatRune: {
        return NTAG(TAG_False);
      }
      case TAG_PatRecord: {
        return NTAG(TAG_False);
      }
      case TAG_PatWord: {
        return NTAG(TAG_False);
      }
      case TAG_PatAs: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_x_241));
    if (!(heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str7, 0, "");
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str1), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str2), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str3), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str4), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str5), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str6), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str7), v_n_240));
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0, 48, "expected a field declaration of the form `x : A`");
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(heff_dup(v_t_245)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_c_2413)) {
  case TAG_At: {
    V v_s_2419 = heff_field(v_c_2413, 1);
    heff_take_n(v_c_2413, 2ULL, 2);
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_c_2413);
  }
  V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2417, v_t_2420})});
  V f_ = v_k_2416;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2414, v_hd_2415, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4, 1, 2, (V[]){v_c_2413, v_k_2416})));
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_243, v_x_2410, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2422;
  switch (heff_tag_of(v_d_246)) {
  case TAG_Nothing: {
    v_c_2422 = ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_d_246, 0);
    heff_take_n(v_d_246, 1ULL, 1);
    V v_t_2414 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2413)));
    v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3, 2, 2, (V[]){v_t_2414, v_c_2413});
    break;
  }
  default: heff_nomatch(v_d_246);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2427 = heff_take_field(v_hd_2425, 1);
  V v_malg_2428 = heff_get_n(v_hd_2425, 2, 3);
  V v_t_2429 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tr(heff_call(v_malg_2428, 1, (V[]){v_t_2431}));
  V f_ = v_bind_2427;
  args[0] = v_t_2432;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_n1_241, 0);
      V v_ru_24n1_241_24CInf = heff_take_reuse_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        heff_take_n(v_n_240, 0ULL, 2);
        V v_t_2441;
        switch (heff_tag_of(v_i_243)) {
        case TAG_At: {
          V v_x11_246 = heff_dup(heff_field(v_i_243, 0));
          switch (heff_tag_of(v_x11_246)) {
          case TAG_IVar: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IInt: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IFloat: {
            heff_take_na(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IString: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IRune: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IApp: {
            heff_take_n(v_x11_246, 0ULL, 2);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_246, 0ULL, 2);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_246, 0ULL, 4);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_246, 0ULL, 2);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_246, 0ULL, 4);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_246, 0ULL, 3);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_INominal: {
            V v_i_2432 = heff_field(v_x11_246, 0);
            heff_take_n(v_x11_246, 1ULL, 1);
            switch (heff_tag_of(v_i_243)) {
            case TAG_At: {
              v_t_2441 = v_i_2432;
              break;
            }
            default: heff_nomatch(v_i_243);
            }
            break;
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_246, 0ULL, 4);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_ILazy: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          case TAG_ITuple: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2441 = heff_dup(v_i_243);
            break;
          }
          default: heff_nomatch(v_x11_246);
          }
          break;
        }
        default: heff_nomatch(v_i_243);
        }
        V v_t_2475;
        switch (heff_tag_of(v_t_2441)) {
        case TAG_At: {
          V v_x11_2442 = heff_field(v_t_2441, 0);
          heff_take_n(v_t_2441, 1ULL, 2);
          switch (heff_tag_of(v_x11_2442)) {
          case TAG_IVar: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IInt: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IFloat: {
            heff_take_na(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IString: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IRune: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IApp: {
            heff_take_n(v_x11_2442, 0ULL, 2);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_2442, 0ULL, 2);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_2442, 0ULL, 4);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_2442, 0ULL, 2);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_2442, 0ULL, 4);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_2442, 0ULL, 3);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_INominal: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_2442, 0ULL, 4);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ILazy: {
            V v_c_2473 = heff_field(v_x11_2442, 0);
            heff_take_n(v_x11_2442, 1ULL, 1);
            v_t_2475 = heff_tag_at_n(v_ru_24n1_241_24CInf, TAG_Just, 1, (V[]){v_c_2473});
            break;
          }
          case TAG_ITuple: {
            heff_take_n(v_x11_2442, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2475 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x11_2442);
          }
          break;
        }
        default: heff_nomatch(v_t_2441);
        }
        switch (heff_tag_of(v_t_2475)) {
        case TAG_Nothing: {
          V v_t_24111;
          switch (heff_tag_of(v_i_243)) {
          case TAG_At: {
            V v_x11_2476 = heff_dup(heff_field(v_i_243, 0));
            switch (heff_tag_of(v_x11_2476)) {
            case TAG_IVar: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IInt: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IFloat: {
              heff_take_na(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IString: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IRune: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IApp: {
              heff_take_n(v_x11_2476, 0ULL, 2);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_2476, 0ULL, 2);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_2476, 0ULL, 4);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_2476, 0ULL, 2);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_2476, 0ULL, 4);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_2476, 0ULL, 3);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_INominal: {
              V v_i_24102 = heff_field(v_x11_2476, 0);
              heff_take_n(v_x11_2476, 1ULL, 1);
              switch (heff_tag_of(v_i_243)) {
              case TAG_At: {
                v_t_24111 = v_i_24102;
                break;
              }
              default: heff_nomatch(v_i_243);
              }
              break;
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_2476, 0ULL, 4);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            case TAG_ITuple: {
              heff_take_n(v_x11_2476, 0ULL, 1);
              v_t_24111 = heff_dup(v_i_243);
              break;
            }
            default: heff_nomatch(v_x11_2476);
            }
            break;
          }
          default: heff_nomatch(v_i_243);
          }
          switch (heff_tag_of(v_t_24111)) {
          case TAG_At: {
            V v_x11_24112 = heff_field(v_t_24111, 0);
            V v_sp_24113 = heff_field(v_t_24111, 1);
            heff_take_n(v_t_24111, 3ULL, 2);
            switch (heff_tag_of(v_x11_24112)) {
            case TAG_IVar: {
              V v_ru_24x11_24112_24IVar = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IVar, v_i_243));
            }
            case TAG_IInt: {
              V v_ru_24x11_24112_24IInt = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IInt, v_i_243));
            }
            case TAG_IFloat: {
              V v_ru_24x11_24112_24IFloat = heff_take_reuse_na(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IFloat, v_i_243));
            }
            case TAG_IString: {
              V v_ru_24x11_24112_24IString = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IString, v_i_243));
            }
            case TAG_IBytes: {
              V v_ru_24x11_24112_24IBytes = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IBytes, v_i_243));
            }
            case TAG_IPrim: {
              V v_ru_24x11_24112_24IPrim = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IPrim, v_i_243));
            }
            case TAG_IRune: {
              V v_ru_24x11_24112_24IRune = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24IRune, v_i_243));
            }
            case TAG_IApp: {
              heff_take_n(v_x11_24112, 0ULL, 2);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_24112, 0ULL, 2);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_24112, 0ULL, 4);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_24112, 0ULL, 2);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_24112, 0ULL, 4);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_24112, 0ULL, 3);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_INominal: {
              V v_ru_24x11_24112_24INominal = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24INominal, v_i_243));
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_24112, 0ULL, 4);
              heff_drop(v_sp_24113);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_ILazy: {
              V v_ru_24x11_24112_24ILazy = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
              heff_drop(v_sp_24113);
              return (g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_24tok1(v_ru_24x11_24112_24ILazy, v_i_243));
            }
            case TAG_ITuple: {
              V v_cs_24144 = heff_field(v_x11_24112, 0);
              heff_take_n(v_x11_24112, 1ULL, 1);
              V v_t_24178;
              switch (heff_tag_of(v_i_243)) {
              case TAG_At: {
                V v_x11_24145 = heff_field(v_i_243, 0);
                heff_take_n(v_i_243, 1ULL, 2);
                switch (heff_tag_of(v_x11_24145)) {
                case TAG_IVar: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IInt: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IFloat: {
                  heff_take_na(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IString: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IBytes: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IPrim: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IRune: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IApp: {
                  heff_take_n(v_x11_24145, 0ULL, 2);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IAnn: {
                  heff_take_n(v_x11_24145, 0ULL, 2);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_ISpec: {
                  heff_take_n(v_x11_24145, 0ULL, 4);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IUpdate: {
                  heff_take_n(v_x11_24145, 0ULL, 2);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IAnnLam: {
                  heff_take_n(v_x11_24145, 0ULL, 4);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_IInvalid: {
                  heff_take_n(v_x11_24145, 0ULL, 3);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_INominal: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_True);
                  break;
                }
                case TAG_ILitEq: {
                  heff_take_n(v_x11_24145, 0ULL, 4);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_ILazy: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                case TAG_ITuple: {
                  heff_take_n(v_x11_24145, 0ULL, 1);
                  v_t_24178 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_x11_24145);
                }
                break;
              }
              default: heff_nomatch(v_i_243);
              }
              return ({ V a_0 = v_t_24178; V a_1 = v_sp_24113; V a_2 = v_cs_24144; V r_ = (g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a_0, a_1, a_2)); heff_drop(v_t_24178); r_; });
            }
            default: return heff_nomatch(v_x11_24112);
            }
          }
          default: return heff_nomatch(v_t_24111);
          }
        }
        case TAG_Just: {
          V v_c_24179 = heff_field(v_t_2475, 0);
          heff_take_n(v_t_2475, 1ULL, 1);
          V v_t_24213;
          switch (heff_tag_of(v_i_243)) {
          case TAG_At: {
            V v_x11_24180 = heff_dup(heff_field(v_i_243, 0));
            switch (heff_tag_of(v_x11_24180)) {
            case TAG_IVar: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IInt: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IFloat: {
              heff_take_na(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IString: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IRune: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IApp: {
              heff_take_n(v_x11_24180, 0ULL, 2);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_24180, 0ULL, 2);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_24180, 0ULL, 4);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_24180, 0ULL, 2);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_24180, 0ULL, 4);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_24180, 0ULL, 3);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_INominal: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_True);
              break;
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_24180, 0ULL, 4);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            case TAG_ITuple: {
              heff_take_n(v_x11_24180, 0ULL, 1);
              v_t_24213 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_x11_24180);
            }
            break;
          }
          default: heff_nomatch(v_i_243);
          }
          V v_t_24216;
          switch (heff_tag_of(v_i_243)) {
          case TAG_At: {
            V v_s_24215 = heff_field(v_i_243, 1);
            heff_take_n(v_i_243, 2ULL, 2);
            v_t_24216 = v_s_24215;
            break;
          }
          default: heff_nomatch(v_i_243);
          }
          return ({ V a_0 = v_t_24213; V a_1 = v_t_24216; V a_2 = v_c_24179; V r_ = (g_heff_2eelab_2etoplevel_2elazyChkF_24s825793648x722716036(a_0, a_1, a_2)); heff_drop(v_t_24213); r_; });
        }
        default: return heff_nomatch(v_t_2475);
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CType: {
      V v_t_24217 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_24219 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        return (g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(v_n2_24219, v_t_24217));
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      V v_c_24223 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 2, (V[]){v_c_24223, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      V v_c_24256 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 2, 2, (V[]){v_c_24256, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_n1_241, 0ULL, 4);
      V v_c_24290 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 2, 2, (V[]){v_c_24290, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_n1_241, 0ULL, 3);
      V v_c_24323 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 2, 2, (V[]){v_c_24323, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_n1_241, 0ULL, 1);
      V v_c_24354 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 2, (V[]){v_c_24354, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_n1_241, 0ULL, 2);
      V v_c_24386 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 2, (V[]){v_c_24386, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_n1_241, 0ULL, 2);
      V v_c_24418 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 2, 2, (V[]){v_c_24418, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_n1_241, 0ULL, 2);
      V v_c_24450 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 2, 2, (V[]){v_c_24450, v_n_240});
    }
    case TAG_CAbandon: {
      V v_c_24480 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 2, 2, (V[]){v_c_24480, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_n1_241, 0ULL, 1);
      V v_c_24511 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 2, 2, (V[]){v_c_24511, v_n_240});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_24226 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24225 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24252;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24227 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24227)) {
    case TAG_CInf: {
      V v_ru_24x11_24227_24CInf = heff_take_reuse_n(v_x11_24227, 0ULL, 1);
      v_x_24252 = ({ V a_0 = v_ru_24x11_24227_24CInf; V a_1 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24227_24CType = heff_take_reuse_n(v_x11_24227, 0ULL, 1);
      v_x_24252 = ({ V a_0 = v_ru_24x11_24227_24CType; V a_1 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24227, 0ULL, 3);
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24227, 0ULL, 3);
      v_x_24252 = v_x_24226;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24227, 0ULL, 4);
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24227, 0ULL, 3);
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24227_24CStruct = heff_take_reuse_n(v_x11_24227, 0ULL, 1);
      v_x_24252 = ({ V a_0 = v_ru_24x11_24227_24CStruct; V a_1 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24227, 0ULL, 2);
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24227, 0ULL, 2);
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24227, 0ULL, 2);
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24252 = ({ V a_0 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24226); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24227_24CNominal = heff_take_reuse_n(v_x11_24227, 0ULL, 1);
      v_x_24252 = ({ V a_0 = v_ru_24x11_24227_24CNominal; V a_1 = v_x_24226; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24226); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24227);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24225;
  args[0] = v_x_24252;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_24224 = args[0];
  V v_k_24225 = args[1];
  V v_c_24223 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24223;
  args[0] = v_hd_24224;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 2, (V[]){v_n_240, v_k_24225});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_x_24259 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24258 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24285;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24260 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24260)) {
    case TAG_CInf: {
      V v_ru_24x11_24260_24CInf = heff_take_reuse_n(v_x11_24260, 0ULL, 1);
      v_x_24285 = ({ V a_0 = v_ru_24x11_24260_24CInf; V a_1 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24260_24CType = heff_take_reuse_n(v_x11_24260, 0ULL, 1);
      v_x_24285 = ({ V a_0 = v_ru_24x11_24260_24CType; V a_1 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24260, 0ULL, 3);
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24260, 0ULL, 3);
      v_x_24285 = v_x_24259;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24260, 0ULL, 4);
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24260, 0ULL, 3);
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24260_24CStruct = heff_take_reuse_n(v_x11_24260, 0ULL, 1);
      v_x_24285 = ({ V a_0 = v_ru_24x11_24260_24CStruct; V a_1 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24260, 0ULL, 2);
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24260, 0ULL, 2);
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24260, 0ULL, 2);
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24285 = ({ V a_0 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24259); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24260_24CNominal = heff_take_reuse_n(v_x11_24260, 0ULL, 1);
      v_x_24285 = ({ V a_0 = v_ru_24x11_24260_24CNominal; V a_1 = v_x_24259; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24259); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24260);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24258;
  args[0] = v_x_24285;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_hd_24257 = args[0];
  V v_k_24258 = args[1];
  V v_c_24256 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24256;
  args[0] = v_hd_24257;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 1, 2, (V[]){v_n_240, v_k_24258});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_x_24293 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24292 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24319;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24294 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24294)) {
    case TAG_CInf: {
      V v_ru_24x11_24294_24CInf = heff_take_reuse_n(v_x11_24294, 0ULL, 1);
      v_x_24319 = ({ V a_0 = v_ru_24x11_24294_24CInf; V a_1 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24294_24CType = heff_take_reuse_n(v_x11_24294, 0ULL, 1);
      v_x_24319 = ({ V a_0 = v_ru_24x11_24294_24CType; V a_1 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24294, 0ULL, 3);
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24294, 0ULL, 3);
      v_x_24319 = v_x_24293;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24294, 0ULL, 4);
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24294, 0ULL, 3);
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24294_24CStruct = heff_take_reuse_n(v_x11_24294, 0ULL, 1);
      v_x_24319 = ({ V a_0 = v_ru_24x11_24294_24CStruct; V a_1 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24294, 0ULL, 2);
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24294, 0ULL, 2);
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24294, 0ULL, 2);
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24319 = ({ V a_0 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24293); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24294_24CNominal = heff_take_reuse_n(v_x11_24294, 0ULL, 1);
      v_x_24319 = ({ V a_0 = v_ru_24x11_24294_24CNominal; V a_1 = v_x_24293; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24293); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24294);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24292;
  args[0] = v_x_24319;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_hd_24291 = args[0];
  V v_k_24292 = args[1];
  V v_c_24290 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24290;
  args[0] = v_hd_24291;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 1, 2, (V[]){v_n_240, v_k_24292});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_24326 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24325 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24352;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24327 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24327)) {
    case TAG_CInf: {
      V v_ru_24x11_24327_24CInf = heff_take_reuse_n(v_x11_24327, 0ULL, 1);
      v_x_24352 = ({ V a_0 = v_ru_24x11_24327_24CInf; V a_1 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24327_24CType = heff_take_reuse_n(v_x11_24327, 0ULL, 1);
      v_x_24352 = ({ V a_0 = v_ru_24x11_24327_24CType; V a_1 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24327, 0ULL, 3);
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24327, 0ULL, 3);
      v_x_24352 = v_x_24326;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24327, 0ULL, 4);
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24327, 0ULL, 3);
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24327_24CStruct = heff_take_reuse_n(v_x11_24327, 0ULL, 1);
      v_x_24352 = ({ V a_0 = v_ru_24x11_24327_24CStruct; V a_1 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24327, 0ULL, 2);
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24327, 0ULL, 2);
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24327, 0ULL, 2);
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24352 = ({ V a_0 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24326); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24327_24CNominal = heff_take_reuse_n(v_x11_24327, 0ULL, 1);
      v_x_24352 = ({ V a_0 = v_ru_24x11_24327_24CNominal; V a_1 = v_x_24326; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24326); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24327);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24325;
  args[0] = v_x_24352;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_hd_24324 = args[0];
  V v_k_24325 = args[1];
  V v_c_24323 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24323;
  args[0] = v_hd_24324;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 2, (V[]){v_n_240, v_k_24325});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_x_24357 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24356 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24383;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24358 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24358)) {
    case TAG_CInf: {
      V v_ru_24x11_24358_24CInf = heff_take_reuse_n(v_x11_24358, 0ULL, 1);
      v_x_24383 = ({ V a_0 = v_ru_24x11_24358_24CInf; V a_1 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24358_24CType = heff_take_reuse_n(v_x11_24358, 0ULL, 1);
      v_x_24383 = ({ V a_0 = v_ru_24x11_24358_24CType; V a_1 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24358, 0ULL, 3);
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24358, 0ULL, 3);
      v_x_24383 = v_x_24357;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24358, 0ULL, 4);
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24358, 0ULL, 3);
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24358_24CStruct = heff_take_reuse_n(v_x11_24358, 0ULL, 1);
      v_x_24383 = ({ V a_0 = v_ru_24x11_24358_24CStruct; V a_1 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24358, 0ULL, 2);
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24358, 0ULL, 2);
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24358, 0ULL, 2);
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24383 = ({ V a_0 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24357); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24358_24CNominal = heff_take_reuse_n(v_x11_24358, 0ULL, 1);
      v_x_24383 = ({ V a_0 = v_ru_24x11_24358_24CNominal; V a_1 = v_x_24357; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24357); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24358);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24356;
  args[0] = v_x_24383;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_hd_24355 = args[0];
  V v_k_24356 = args[1];
  V v_c_24354 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24354;
  args[0] = v_hd_24355;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 2, (V[]){v_n_240, v_k_24356});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_x_24389 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24388 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24415;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24390 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24390)) {
    case TAG_CInf: {
      V v_ru_24x11_24390_24CInf = heff_take_reuse_n(v_x11_24390, 0ULL, 1);
      v_x_24415 = ({ V a_0 = v_ru_24x11_24390_24CInf; V a_1 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24390_24CType = heff_take_reuse_n(v_x11_24390, 0ULL, 1);
      v_x_24415 = ({ V a_0 = v_ru_24x11_24390_24CType; V a_1 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24390, 0ULL, 3);
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24390, 0ULL, 3);
      v_x_24415 = v_x_24389;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24390, 0ULL, 4);
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24390, 0ULL, 3);
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24390_24CStruct = heff_take_reuse_n(v_x11_24390, 0ULL, 1);
      v_x_24415 = ({ V a_0 = v_ru_24x11_24390_24CStruct; V a_1 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24390, 0ULL, 2);
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24390, 0ULL, 2);
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24390, 0ULL, 2);
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24415 = ({ V a_0 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24389); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24390_24CNominal = heff_take_reuse_n(v_x11_24390, 0ULL, 1);
      v_x_24415 = ({ V a_0 = v_ru_24x11_24390_24CNominal; V a_1 = v_x_24389; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24389); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24390);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24388;
  args[0] = v_x_24415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24387 = args[0];
  V v_k_24388 = args[1];
  V v_c_24386 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24386;
  args[0] = v_hd_24387;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 1, 2, (V[]){v_n_240, v_k_24388});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_x_24421 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24420 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24447;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24422 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24422)) {
    case TAG_CInf: {
      V v_ru_24x11_24422_24CInf = heff_take_reuse_n(v_x11_24422, 0ULL, 1);
      v_x_24447 = ({ V a_0 = v_ru_24x11_24422_24CInf; V a_1 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24422_24CType = heff_take_reuse_n(v_x11_24422, 0ULL, 1);
      v_x_24447 = ({ V a_0 = v_ru_24x11_24422_24CType; V a_1 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24422, 0ULL, 3);
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24422, 0ULL, 3);
      v_x_24447 = v_x_24421;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24422, 0ULL, 4);
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24422, 0ULL, 3);
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24422_24CStruct = heff_take_reuse_n(v_x11_24422, 0ULL, 1);
      v_x_24447 = ({ V a_0 = v_ru_24x11_24422_24CStruct; V a_1 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24422, 0ULL, 2);
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24422, 0ULL, 2);
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24422, 0ULL, 2);
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24447 = ({ V a_0 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24421); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24422_24CNominal = heff_take_reuse_n(v_x11_24422, 0ULL, 1);
      v_x_24447 = ({ V a_0 = v_ru_24x11_24422_24CNominal; V a_1 = v_x_24421; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24421); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24422);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24420;
  args[0] = v_x_24447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_hd_24419 = args[0];
  V v_k_24420 = args[1];
  V v_c_24418 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24418;
  args[0] = v_hd_24419;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 1, 2, (V[]){v_n_240, v_k_24420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24453 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24452 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24479;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24454 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24454)) {
    case TAG_CInf: {
      V v_ru_24x11_24454_24CInf = heff_take_reuse_n(v_x11_24454, 0ULL, 1);
      v_x_24479 = ({ V a_0 = v_ru_24x11_24454_24CInf; V a_1 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24454_24CType = heff_take_reuse_n(v_x11_24454, 0ULL, 1);
      v_x_24479 = ({ V a_0 = v_ru_24x11_24454_24CType; V a_1 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24454, 0ULL, 3);
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24454, 0ULL, 3);
      v_x_24479 = v_x_24453;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24454, 0ULL, 4);
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24454, 0ULL, 3);
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24454_24CStruct = heff_take_reuse_n(v_x11_24454, 0ULL, 1);
      v_x_24479 = ({ V a_0 = v_ru_24x11_24454_24CStruct; V a_1 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24454, 0ULL, 2);
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24454, 0ULL, 2);
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24454, 0ULL, 2);
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24479 = ({ V a_0 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24453); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24454_24CNominal = heff_take_reuse_n(v_x11_24454, 0ULL, 1);
      v_x_24479 = ({ V a_0 = v_ru_24x11_24454_24CNominal; V a_1 = v_x_24453; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24453); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24454);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24452;
  args[0] = v_x_24479;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_hd_24451 = args[0];
  V v_k_24452 = args[1];
  V v_c_24450 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24450;
  args[0] = v_hd_24451;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 2, (V[]){v_n_240, v_k_24452});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_x_24483 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24482 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24509;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24484 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24484)) {
    case TAG_CInf: {
      V v_ru_24x11_24484_24CInf = heff_take_reuse_n(v_x11_24484, 0ULL, 1);
      v_x_24509 = ({ V a_0 = v_ru_24x11_24484_24CInf; V a_1 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24484_24CType = heff_take_reuse_n(v_x11_24484, 0ULL, 1);
      v_x_24509 = ({ V a_0 = v_ru_24x11_24484_24CType; V a_1 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24484, 0ULL, 3);
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24484, 0ULL, 3);
      v_x_24509 = v_x_24483;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24484, 0ULL, 4);
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24484, 0ULL, 3);
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24484_24CStruct = heff_take_reuse_n(v_x11_24484, 0ULL, 1);
      v_x_24509 = ({ V a_0 = v_ru_24x11_24484_24CStruct; V a_1 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24484, 0ULL, 2);
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24484, 0ULL, 2);
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24484, 0ULL, 2);
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24509 = ({ V a_0 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24483); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24484_24CNominal = heff_take_reuse_n(v_x11_24484, 0ULL, 1);
      v_x_24509 = ({ V a_0 = v_ru_24x11_24484_24CNominal; V a_1 = v_x_24483; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24483); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24484);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24482;
  args[0] = v_x_24509;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_hd_24481 = args[0];
  V v_k_24482 = args[1];
  V v_c_24480 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24480;
  args[0] = v_hd_24481;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 1, 2, (V[]){v_n_240, v_k_24482});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_x_24514 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24513 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24540;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24515 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24515)) {
    case TAG_CInf: {
      V v_ru_24x11_24515_24CInf = heff_take_reuse_n(v_x11_24515, 0ULL, 1);
      v_x_24540 = ({ V a_0 = v_ru_24x11_24515_24CInf; V a_1 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24515_24CType = heff_take_reuse_n(v_x11_24515, 0ULL, 1);
      v_x_24540 = ({ V a_0 = v_ru_24x11_24515_24CType; V a_1 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24515, 0ULL, 3);
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24515, 0ULL, 3);
      v_x_24540 = v_x_24514;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24515, 0ULL, 4);
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24515, 0ULL, 3);
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24515_24CStruct = heff_take_reuse_n(v_x11_24515, 0ULL, 1);
      v_x_24540 = ({ V a_0 = v_ru_24x11_24515_24CStruct; V a_1 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24515, 0ULL, 2);
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24515, 0ULL, 2);
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24515, 0ULL, 2);
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24540 = ({ V a_0 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24514); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24515_24CNominal = heff_take_reuse_n(v_x11_24515, 0ULL, 1);
      v_x_24540 = ({ V a_0 = v_ru_24x11_24515_24CNominal; V a_1 = v_x_24514; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24514); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24515);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24513;
  args[0] = v_x_24540;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_hd_24512 = args[0];
  V v_k_24513 = args[1];
  V v_c_24511 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24511;
  args[0] = v_hd_24512;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 1, 2, (V[]){v_n_240, v_k_24513});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2411));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2432 = heff_field(v_x2_240, 2);
    V v_t_2433 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2434 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2433));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2434, v_sp_2432, v_x_2430});
  }
  case TAG_PiAnon: {
    V v_d_2438 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2439 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_d_2438));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2439});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2422;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2428;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    v_c_2428 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_t_2420, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2432, v_x_2430, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2436, v_sp_2432, v_x_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str0, 5, " and ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str1, 14, " are not equal");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str2, 50, "the implicit arguments found do not fit together: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str3, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, "`, it would need ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str5, 11, "found for `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str6, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str7, 24, " does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str8, 35, "cannot infer an implicit argument: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str9, 14, "`: give it, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str10, 9, " := ...)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str11, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str12, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str13, 25, ", does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str14, 21, "what is known of it, ");
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2), heff_strAppend(heff_dup(v_left_243), v_t_246));
    V v_t_249;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_249 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_248 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_249 = heff_get_n(v_me_248, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2413;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_2410 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2411 = heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), v_right_244));
      V v_t_2412 = heff_strAppend(heff_get_n(v_me_2410, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4), v_t_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5), v_t_2412)});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_247, v_t_249, v_t_2413});
  } else {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7)));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8), heff_strAppend(v_left_243, v_t_2414));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2415, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2416 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_name_2417 = heff_take_field(v_me_2416, 4);
      V v_span_2418 = heff_get_n(v_me_2416, 5, 6);
      V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9), heff_strAppend(heff_dup(v_name_2417), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10)));
      V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11), heff_strAppend(v_name_2417, v_t_2419));
      V v_t_2421 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13)));
      V v_t_2422 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14), heff_strAppend(v_left_243, v_t_2421));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2420, v_span_2418, heff_tag_n(TAG_Just, 1, (V[]){v_t_2422})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 9, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_isInstance_243, V v_tyStx_244, V v_mc_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  V v_prim_249 = heff_take_field(v_d_242, 3);
  V v_name_2410 = heff_get_n(v_d_242, 0, 4);
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Left: {
    V v_failed_2411 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_key_2412;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_key_2412 = heff_dup(v_name_2410);
    } else {
      v_key_2412 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_t_2413;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      v_t_2413 = heff_dup(v_name_2410);
    } else {
      v_t_2413 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_entry_2414 = ({ V a_0 = v_g_241; V a_1 = v_t_2413; V a_2 = v_tyStx_244; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_2410, v_key_2412, v_prim_249, v_isInstance_243, v_entry_2414, heff_tag_n(TAG_Just, 1, (V[]){v_failed_2411})});
    return heff_tail(v_z_248, 1, (V[]){v_t_2415});
  }
  case TAG_Right: {
    V v_t_2416 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_key_2417;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_key_2417 = heff_dup(v_name_2410);
    } else {
      v_key_2417 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_t_2418;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_t_2418 = heff_dup(v_name_2410);
    } else {
      v_t_2418 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_k_2419;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      v_k_2419 = heff_dup(v_name_2410);
    } else {
      v_k_2419 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_t_2420 = (g_heff_2eelab_2eunify_2ezonker(v_mc_245));
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_t_2420, 0, 2), 1, (V[]){heff_get_n(v_t_2416, 0, 2)}));
    V v_t_2422 = ({ V a_0 = v_k_2419; V r_ = (g_heff_2eelab_2etoplevel_2eselfWalk(a_0)); heff_drop(v_k_2419); r_; });
    V v_t_2423 = heff_tr(heff_call(heff_get_n(v_t_2422, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2421}));
    V v_entry_2424 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2418, v_prim_249, v_tyStx_244, v_t_2423));
    V v_t_2425 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_2410, v_key_2417, v_prim_249, v_isInstance_243, v_entry_2424, NTAG(TAG_Nothing)});
    return heff_tail(v_z_248, 1, (V[]){v_t_2425});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a7 = a[7]; V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a5, a[6], a7, a[8]); heff_drop(a5); heff_drop(a7); return r;
}

static V g_heff_2eelab_2etoplevel_2eprimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2eprimNames_st;
static V g_heff_2eelab_2etoplevel_2eprimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2eprims_get())));
}
V g_heff_2eelab_2etoplevel_2eprimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2eprimNames_st)) return g_heff_2eelab_2etoplevel_2eprimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2eprimNames_val, &g_heff_2eelab_2etoplevel_2eprimNames_st, g_heff_2eelab_2etoplevel_2eprimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchEntry_str0, 7, "> watch");
Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_call(heff_get_n(v_t_246, 1, 2), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 1, (V[]){heff_get_n(v_t_242, 0, 2)}));
  V v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2eelab_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2417;
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2417 = v_x_2414;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2415 = v_field_2413;
        heff_drop(v_x11_2415);
        v_t_2417 = heff_abandon();
      } else {
        V v_x_2416 = v_field_2413;
        v_t_2417 = v_x_2416;
      }
    }
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2417});
}
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ewatchEntry(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eisPrimB(a0); heff_drop(a0); return r;
}