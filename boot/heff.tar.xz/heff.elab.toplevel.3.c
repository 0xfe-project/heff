// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Anonymous 24551
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_Describe 2650
#define TAG_FracNum 48168
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_Left 13886
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Throw 56084
#define TAG_VOpaque 37311
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dflt 9576017
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_prim 9944941
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_watches 1357821955
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__typ__dflt[] = {LBL_name, LBL_typ, LBL_dflt};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_heff_2ecompile_2eprims_2eprims_get(void);
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eannot(V, V);
V g_heff_2eelab_2erules_2eannot_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eannot_clo;
V g_heff_2eelab_2erules_2efind(V, V);
V g_heff_2eelab_2erules_2efind_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efind_clo;
V g_heff_2eelab_2erules_2efunctionIntroSyn(V, V, V);
V g_heff_2eelab_2erules_2efunctionIntroSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionIntroSyn_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elitBytes(V, V);
V g_heff_2eelab_2erules_2elitBytes_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitBytes_clo;
V g_heff_2eelab_2erules_2elitEq(V, V, V, V, V);
V g_heff_2eelab_2erules_2elitEq_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elitEq_clo;
V g_heff_2eelab_2erules_2enumLitSyn(V, V);
V g_heff_2eelab_2erules_2enumLitSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitSyn_clo;
V g_heff_2eelab_2erules_2erecordSpec(V, V, V, V);
V g_heff_2eelab_2erules_2erecordSpec_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordSpec_clo;
V g_heff_2eelab_2erules_2erecordUpdate(V, V, V, V);
V g_heff_2eelab_2erules_2erecordUpdate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordUpdate_clo;
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(V, V, V);
V g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eerrEntry(V, V, V);
V g_heff_2eelab_2etoplevel_2eerrEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eerrEntry_clo;
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2enominalSyn(V);
V g_heff_2eelab_2etoplevel_2enominalSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalSyn_clo;
V g_heff_2eelab_2etoplevel_2eprimNames_get(void);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etopGo(V, V, V);
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopGo_clo;
V g_heff_2eelab_2etoplevel_2etopOne(V, V, V);
V g_heff_2eelab_2etoplevel_2etopOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etopOne_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL(V, V);
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1633141968x1211559892(V);
V g_heff_2eelab_2etoplevel_2etraverseEL_24s1633141968x1211559892_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etraverseEL_24s1633141968x1211559892_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(V, V);
V g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1991317015x801331450(V, V);
V g_list_2efoldl_24s1991317015x801331450_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1991317015x801331450_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_heff_2eelab_2etoplevel_2etraverseEL_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2etraverseEL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_lam0, 2, 0};
V g_heff_2eelab_2etoplevel_2etraverseEL_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2etraverseEL_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2etraverseEL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etraverseEL_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2etraverseEL(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2eelab_2etoplevel_2etraverseEL_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam1, 2, 3, (V[]){v_c_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2etraverseEL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etraverseEL(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_xs_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2eelab_2etoplevel_2etraverseEL(v_f_240, v_xs_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam3, 1, 2, (V[]){v_k_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2etraverseEL_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2etraverseEL_lam2, 1, 4, (V[]){v_f_240, v_xs_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2422;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        v_t_2422 = NTAG(TAG_True);
        break;
      }
      case TAG_PatTag: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatOp: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatInt: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatFloat: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatString: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatBytes: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRune: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatRecord: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatWord: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      case TAG_PatAs: {
        v_t_2422 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
      heff_drop(v_t_2422);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2422);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0, 1, "r");
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam27(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam26(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam29(V self, V *args);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam28(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_27_241 = heff_dup(heff_field(v_n_240, 0));
    V v_sp_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_27_241)) {
    case TAG_IVar: {
      V v_x_243 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0, 2, 2, (V[]){v_sp_242, v_x_243});
    }
    case TAG_IInt: {
      V v_i_247 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1, 2, 2, (V[]){v_sp_242, v_i_247});
    }
    case TAG_IFloat: {
      V v_x_2411 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2, 2, 2, (V[]){v_sp_242, v_x_2411});
    }
    case TAG_IString: {
      V v_s_2415 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3, 2, 1, (V[]){v_s_2415});
    }
    case TAG_IBytes: {
      V v_s_2424 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6, 2, 2, (V[]){v_sp_242, v_s_2424});
    }
    case TAG_IRune: {
      V v_c_2428 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7, 2, 1, (V[]){v_c_2428});
    }
    case TAG_IApp: {
      V v_h_2437 = heff_field(v_n1_27_241, 0);
      V v_args_2438 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2439 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_h_2437)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10, 2, 3, (V[]){v_c_2439, v_h_2437, v_args_2438});
    }
    case TAG_IAnn: {
      V v_n0_2447 = heff_field(v_n1_27_241, 0);
      V v_n1_2448 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2449 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n0_2447));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12, 2, 2, (V[]){v_c_2449, v_n1_2448});
    }
    case TAG_ISpec: {
      V v_n0_2456 = heff_field(v_n1_27_241, 0);
      V v_x_2457 = heff_field(v_n1_27_241, 1);
      V v_v_2459 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 11ULL, 4);
      heff_drop(v_sp_242);
      V v_c_2460 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_v_2459));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15, 2, 4, (V[]){v_c_2460, v_n0_2456, v_n_240, v_x_2457});
    }
    case TAG_IUpdate: {
      V v_n0_2470 = heff_field(v_n1_27_241, 0);
      V v_fs_2471 = heff_field(v_n1_27_241, 1);
      heff_take_n(v_n1_27_241, 3ULL, 2);
      heff_drop_tag(v_n_240, 2);
      V v_c_2472 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_2470));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18, 2, 3, (V[]){v_c_2472, v_fs_2471, v_sp_242});
    }
    case TAG_IAnnLam: {
      V v_x_2482 = heff_field(v_n1_27_241, 0);
      V v_tyN_2484 = heff_field(v_n1_27_241, 2);
      V v_body_2485 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 13ULL, 4);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_2486 = ({ V a_0 = v_tyN_2484; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2484); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21, 2, 3, (V[]){v_c_2486, v_body_2485, v_x_2482});
    }
    case TAG_IInvalid: {
      V v_code_2493 = heff_field(v_n1_27_241, 0);
      V v_why_2494 = heff_field(v_n1_27_241, 1);
      V v_n1_273_2495 = heff_field(v_n1_27_241, 2);
      heff_take_n(v_n1_27_241, 7ULL, 3);
      heff_drop_tag(v_n_240, 2);
      switch (heff_tag_of(v_n1_273_2495)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24, 2, 3, (V[]){v_code_2493, v_why_2494, v_sp_242});
      }
      case TAG_Just: {
        V v_note_24102 = heff_field(v_n1_273_2495, 0);
        heff_take_n(v_n1_273_2495, 1ULL, 1);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam25, 2, 4, (V[]){v_code_2493, v_why_2494, v_sp_242, v_note_24102});
      }
      default: return heff_nomatch(v_n1_273_2495);
      }
    }
    case TAG_INominal: {
      V v_i_24109 = heff_field(v_n1_27_241, 0);
      heff_take_n(v_n1_27_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_sp_242);
      V v_c_24110 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_24109));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam26, 2, 1, (V[]){v_c_24110});
    }
    case TAG_ILitEq: {
      V v_x_24115 = heff_field(v_n1_27_241, 0);
      V v_xsp_24116 = heff_field(v_n1_27_241, 1);
      V v_eq_24117 = heff_field(v_n1_27_241, 2);
      V v_lit_24118 = heff_field(v_n1_27_241, 3);
      heff_take_n(v_n1_27_241, 15ULL, 4);
      heff_drop_tag(v_n_240, 2);
      V v_c_24119 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_lit_24118));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam28, 2, 5, (V[]){v_c_24119, v_sp_242, v_x_24115, v_xsp_24116, v_eq_24117});
    }
    default: return heff_nomatch(v_n1_27_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_244);
  V v_t_246 = (g_heff_2eelab_2erules_2efind(v_sp_242, v_x_243));
  V f_ = v_k_245;
  args[0] = v_t_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_i_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2410 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_IntNum, 1, (V[]){v_i_247})));
  V f_ = v_k_249;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2412);
  V v_t_2414 = (g_heff_2eelab_2erules_2enumLitSyn(v_sp_242, heff_tag_n(TAG_FracNum, 1, (V[]){v_x_2411})));
  V f_ = v_k_2413;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5(V self, V *args) {
  V v_u_2421 = args[0];
  heff_drop(v_u_2421);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4(V self, V *args) {
  V v_e_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2418);
  heff_drop(v_hd_2419);
  V v_t_2422 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitString, 1, (V[]){v_s_2415}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam5_clo)});
  V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2422, NTAG(TAG_VPrimString)});
  V f_ = v_k_2420;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam3(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_s_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam4, 3, 1, (V[]){v_s_2415})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_sp_242 = heff_env(self)[0];
  V v_s_2424 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2425);
  V v_t_2427 = (g_heff_2eelab_2erules_2elitBytes(v_sp_242, v_s_2424));
  V f_ = v_k_2426;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9(V self, V *args) {
  V v_u_2434 = args[0];
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8(V self, V *args) {
  V v_e_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2431);
  heff_drop(v_hd_2432);
  V v_t_2435 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SLitRune, 1, (V[]){v_c_2428}), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam9_clo)});
  V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, NTAG(TAG_VPrimRune)});
  V f_ = v_k_2433;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam7(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam8, 3, 1, (V[]){v_c_2428})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_h_2437 = heff_env(self)[0];
  V v_args_2438 = heff_env(self)[1];
  V v_hd_2440 = heff_env(self)[2];
  V v_k_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2445;
  switch (heff_tag_of(v_h_2437)) {
  case TAG_At: {
    V v_s_2444 = heff_field(v_h_2437, 1);
    heff_take_n(v_h_2437, 2ULL, 2);
    v_t_2445 = v_s_2444;
    break;
  }
  default: heff_nomatch(v_h_2437);
  }
  V v_c_2446 = ({ V a_0 = heff_get_n(v_t_2445, 0, 2); V a_1 = v_x_2442; V a_2 = v_args_2438; V r_ = (g_heff_2eelab_2etoplevel_2eelimAll_24s2020260032x361939681(a_0, a_1, a_2)); heff_drop(v_args_2438); r_; });
  V f_ = v_c_2446;
  heff_room[0] = v_hd_2440;
  heff_room[1] = v_k_2441;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  V v_h_2437 = heff_env(self)[1];
  V v_args_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2439;
  args[0] = heff_dup(v_hd_2440);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam11, 1, 4, (V[]){v_h_2437, v_args_2438, v_hd_2440, v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2452 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = ({ V a_0 = v_x_2454; V a_1 = v_x_2452; V r_ = (g_heff_2eelab_2erules_2eannot(a_0, a_1)); heff_drop(v_x_2454); heff_drop(v_x_2452); r_; });
  V f_ = v_k_2451;
  args[0] = v_t_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13(V self, V *args) {
  V v_x_2452 = args[0];
  V v_n1_2448 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2453 = ({ V a_0 = v_n1_2448; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n1_2448); r_; });
  V f_ = v_c_2453;
  heff_room[0] = v_hd_2450;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam14, 1, 2, (V[]){v_x_2452, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam12(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_c_2449 = heff_env(self)[0];
  V v_n1_2448 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2449;
  args[0] = heff_dup(v_hd_2450);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam13, 1, 3, (V[]){v_n1_2448, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17(V self, V *args) {
  V v_x_2465 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_x_2457 = heff_env(self)[1];
  V v_x_2463 = heff_env(self)[2];
  V v_k_2462 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2468;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_s_2467 = heff_field(v_n_240, 1);
    heff_take_n(v_n_240, 2ULL, 2);
    v_t_2468 = v_s_2467;
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2469 = ({ V a_0 = v_t_2468; V a_1 = v_x_2465; V a_2 = v_x_2457; V a_3 = v_x_2463; V r_ = (g_heff_2eelab_2erules_2erecordSpec(a_0, a_1, a_2, a_3)); heff_drop(v_x_2465); heff_drop(v_x_2463); r_; });
  V f_ = v_k_2462;
  args[0] = v_x_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16(V self, V *args) {
  V v_x_2463 = args[0];
  V v_n0_2456 = heff_env(self)[0];
  V v_hd_2461 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2457 = heff_env(self)[3];
  V v_k_2462 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2464 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_n0_2456));
  V f_ = v_c_2464;
  heff_room[0] = v_hd_2461;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam17, 1, 4, (V[]){v_n_240, v_x_2457, v_x_2463, v_k_2462});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam15(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_c_2460 = heff_env(self)[0];
  V v_n0_2456 = heff_env(self)[1];
  V v_n_240 = heff_env(self)[2];
  V v_x_2457 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2460;
  args[0] = heff_dup(v_hd_2461);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam16, 1, 5, (V[]){v_n0_2456, v_hd_2461, v_n_240, v_x_2457, v_k_2462});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20(V self, V *args) {
  V v_x_2477 = args[0];
  V v_fs_2471 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2475 = heff_env(self)[2];
  V v_k_2474 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_fs_2471));
  V v_t_2479 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2478; V r_ = (g_list_2efoldl_24s1991317015x801331450(a_0, a_1)); heff_drop(v_t_2478); r_; });
  V v_t_2480 = ({ V a_0 = v_t_2479; V a_1 = ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0); V r_ = (g_heff_2eelab_2eclauses_2efresh(a_0, a_1)); heff_drop(v_t_2479); r_; });
  V v_x_2481 = ({ V a_0 = v_sp_242; V a_1 = v_x_2475; V a_2 = v_t_2480; V a_3 = v_x_2477; V r_ = (g_heff_2eelab_2erules_2erecordUpdate(a_0, a_1, a_2, a_3)); heff_drop(v_x_2475); r_; });
  V f_ = v_k_2474;
  args[0] = v_x_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19(V self, V *args) {
  V v_x_2475 = args[0];
  V v_fs_2471 = heff_env(self)[0];
  V v_hd_2473 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_k_2474 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2476 = (g_heff_2eelab_2etoplevel_2etraverseEL_24s1633141968x1211559892(heff_dup(v_fs_2471)));
  V f_ = v_c_2476;
  heff_room[0] = v_hd_2473;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam20, 1, 4, (V[]){v_fs_2471, v_sp_242, v_x_2475, v_k_2474});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam18(V self, V *args) {
  V v_hd_2473 = args[0];
  V v_k_2474 = args[1];
  V v_c_2472 = heff_env(self)[0];
  V v_fs_2471 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2472;
  args[0] = heff_dup(v_hd_2473);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam19, 1, 4, (V[]){v_fs_2471, v_hd_2473, v_sp_242, v_k_2474});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23(V self, V *args) {
  V v_x_2491 = args[0];
  V v_x_2482 = heff_env(self)[0];
  V v_x_2489 = heff_env(self)[1];
  V v_k_2488 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2492 = ({ V a_0 = v_x_2482; V a_1 = v_x_2489; V a_2 = v_x_2491; V r_ = (g_heff_2eelab_2erules_2efunctionIntroSyn(a_0, a_1, a_2)); heff_drop(v_x_2489); heff_drop(v_x_2491); r_; });
  V f_ = v_k_2488;
  args[0] = v_t_2492;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22(V self, V *args) {
  V v_x_2489 = args[0];
  V v_body_2485 = heff_env(self)[0];
  V v_hd_2487 = heff_env(self)[1];
  V v_x_2482 = heff_env(self)[2];
  V v_k_2488 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2490 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_body_2485));
  V f_ = v_c_2490;
  heff_room[0] = v_hd_2487;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam23, 1, 3, (V[]){v_x_2482, v_x_2489, v_k_2488});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam21(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_c_2486 = heff_env(self)[0];
  V v_body_2485 = heff_env(self)[1];
  V v_x_2482 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2486;
  args[0] = heff_dup(v_hd_2487);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam22, 1, 4, (V[]){v_body_2485, v_hd_2487, v_x_2482, v_k_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam24(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k2_2497 = args[1];
  V v_code_2493 = heff_env(self)[0];
  V v_why_2494 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2498 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_2493), NTAG(TAG_SError), v_why_2494, v_sp_242, NTAG(TAG_Nothing)});
  V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tr(heff_call(heff_take_field(v_hd_2496, 2), 1, (V[]){v_t_24100}));
  V f_ = heff_get_n(v_hd_2496, 1, 3);
  args[0] = v_t_24101;
  args[1] = v_k2_2497;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam25(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k2_24104 = args[1];
  V v_code_2493 = heff_env(self)[0];
  V v_why_2494 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_note_24102 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24105 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_intAdd(MK_INT(200LL), v_code_2493), NTAG(TAG_SError), v_why_2494, v_sp_242, heff_tag_n(TAG_Just, 1, (V[]){v_note_24102})});
  V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tr(heff_call(heff_take_field(v_hd_24103, 2), 1, (V[]){v_t_24107}));
  V f_ = heff_get_n(v_hd_24103, 1, 3);
  args[0] = v_t_24108;
  args[1] = v_k2_24104;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam27(V self, V *args) {
  V v_x_24113 = args[0];
  V v_k_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24114 = ({ V a_0 = v_x_24113; V r_ = (g_heff_2eelab_2etoplevel_2enominalSyn(a_0)); heff_drop(v_x_24113); r_; });
  V f_ = v_k_24112;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam26(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_c_24110 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24110;
  args[0] = v_hd_24111;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam27, 1, 1, (V[]){v_k_24112});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam29(V self, V *args) {
  V v_x_24122 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_24115 = heff_env(self)[1];
  V v_xsp_24116 = heff_env(self)[2];
  V v_eq_24117 = heff_env(self)[3];
  V v_k_24121 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24123 = ({ V a_0 = v_sp_242; V a_1 = v_x_24115; V a_2 = v_xsp_24116; V a_3 = v_eq_24117; V a_4 = v_x_24122; V r_ = (g_heff_2eelab_2erules_2elitEq(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_24122); r_; });
  V f_ = v_k_24121;
  args[0] = v_t_24123;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam28(V self, V *args) {
  V v_hd_24120 = args[0];
  V v_k_24121 = args[1];
  V v_c_24119 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_24115 = heff_env(self)[2];
  V v_xsp_24116 = heff_env(self)[3];
  V v_eq_24117 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24119;
  args[0] = v_hd_24120;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_lam29, 1, 5, (V[]){v_sp_242, v_x_24115, v_xsp_24116, v_eq_24117, v_k_24121});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0, 48, "expected a field declaration of the form `x : A`");
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2, 2, 0};
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_x22_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclareField: {
      V v_x_243 = heff_field(v_x21_241, 0);
      V v_t_245 = heff_field(v_x21_241, 2);
      V v_d_246 = heff_field(v_x21_241, 3);
      V v_c_247 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_245));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0, 2, 3, (V[]){v_c_247, heff_dup(v_d_246), heff_dup(v_x_243)});
    }
    case TAG_BadFieldDecl: {
      return heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6, 2, 1, (V[]){heff_dup(v_x22_242)});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_c_2413)) {
  case TAG_At: {
    V v_s_2419 = heff_field(v_c_2413, 1);
    heff_take_n(v_c_2413, 2ULL, 2);
    v_t_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_c_2413);
  }
  V v_x_2421 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2417, v_t_2420})});
  V f_ = v_k_2416;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2414, v_hd_2415, heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam4, 1, 2, (V[]){v_c_2413, v_k_2416})));
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_249;
  args[0] = heff_rec_n(3, shape_name__typ__dflt, (V[]){v_x_243, v_x_2410, v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_d_246 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2422;
  switch (heff_tag_of(v_d_246)) {
  case TAG_Nothing: {
    v_c_2422 = ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam2_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2413 = heff_field(v_d_246, 0);
    heff_take_n(v_d_246, 1ULL, 1);
    V v_t_2414 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2413)));
    v_c_2422 = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam3, 2, 2, (V[]){v_t_2414, v_c_2413});
    break;
  }
  default: heff_nomatch(v_d_246);
  }
  V f_ = v_c_2422;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam5, 1, 3, (V[]){v_k_249, v_x_243, v_x_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_d_246 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam1, 1, 4, (V[]){v_d_246, v_hd_248, v_k_249, v_x_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_lam6(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_x22_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(201LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2efieldDeclF_24s208769067x22397212_str0), v_x22_242, NTAG(TAG_Nothing)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_2425, 2), 1, (V[]){v_t_2429}));
  V f_ = heff_get_n(v_hd_2425, 1, 3);
  args[0] = v_t_2430;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    V v_n2_242 = heff_dup(heff_field(v_n_240, 1));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      heff_drop(v_n2_242);
      HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
    }
    case TAG_CType: {
      V v_t_244 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      heff_drop_tag(v_n_240, 2);
      return ({ V a_0 = v_n2_242; V a_1 = v_t_244; V r_ = (g_heff_2eelab_2etoplevel_2etypeChk_24s1903606138x659315865(a_0, a_1)); heff_drop(v_t_244); r_; });
    }
    case TAG_CLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_248 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 2, (V[]){v_c_248, v_n_240});
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_2442 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 2, 2, (V[]){v_c_2442, v_n_240});
    }
    case TAG_CAnnLam: {
      heff_take_n(v_n1_241, 0ULL, 4);
      heff_drop(v_n2_242);
      V v_c_2477 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 2, 2, (V[]){v_c_2477, v_n_240});
    }
    case TAG_CTag: {
      heff_take_n(v_n1_241, 0ULL, 3);
      heff_drop(v_n2_242);
      V v_c_24111 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 2, 2, (V[]){v_c_24111, v_n_240});
    }
    case TAG_CStruct: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24143 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 2, (V[]){v_c_24143, v_n_240});
    }
    case TAG_CMatch: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24176 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 2, (V[]){v_c_24176, v_n_240});
    }
    case TAG_CLetIn: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24209 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 2, 2, (V[]){v_c_24209, v_n_240});
    }
    case TAG_CLocal: {
      heff_take_n(v_n1_241, 0ULL, 2);
      heff_drop(v_n2_242);
      V v_c_24242 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 2, 2, (V[]){v_c_24242, v_n_240});
    }
    case TAG_CAbandon: {
      heff_drop(v_n2_242);
      V v_c_24273 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 2, 2, (V[]){v_c_24273, v_n_240});
    }
    case TAG_CNominal: {
      heff_take_n(v_n1_241, 0ULL, 1);
      heff_drop(v_n2_242);
      V v_c_24305 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 2, 2, (V[]){v_c_24305, v_n_240});
    }
    default: return heff_nomatch(v_n1_241);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2412 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2412, 0ULL, 4);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2412, 0ULL, 3);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2412, 0ULL, 2);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2412, 0ULL, 1);
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2412);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2438;
  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
    heff_drop(v_t_2437);
    v_x_2438 = v_x_2411;
  } else {
    heff_drop(v_t_2437);
    v_x_2438 = ({ V a_0 = v_x_2411; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2411); r_; });
  }
  V f_ = v_k_2410;
  args[0] = v_x_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_248;
  args[0] = v_hd_249;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 2, (V[]){v_n_240, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_x_2445 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2444 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2446 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2446)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2446, 0ULL, 3);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2446, 0ULL, 3);
      v_t_2471 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2446, 0ULL, 4);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2446, 0ULL, 3);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2446, 0ULL, 2);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2446, 0ULL, 2);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2446, 0ULL, 2);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2446, 0ULL, 1);
      v_t_2471 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2446);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_2472;
  if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
    heff_drop(v_t_2471);
    v_x_2472 = v_x_2445;
  } else {
    heff_drop(v_t_2471);
    v_x_2472 = ({ V a_0 = v_x_2445; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2445); r_; });
  }
  V f_ = v_k_2444;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 1, 2, (V[]){v_n_240, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_x_2480 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24106;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_2481 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_2481)) {
    case TAG_CInf: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_2481, 0ULL, 3);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_2481, 0ULL, 3);
      v_t_24106 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_2481, 0ULL, 4);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_2481, 0ULL, 3);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_2481, 0ULL, 2);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_2481, 0ULL, 2);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_2481, 0ULL, 2);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_2481, 0ULL, 1);
      v_t_24106 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2481);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24107;
  if ((heff_dup(v_t_24106) == NTAG(TAG_True))) {
    heff_drop(v_t_24106);
    v_x_24107 = v_x_2480;
  } else {
    heff_drop(v_t_24106);
    v_x_24107 = ({ V a_0 = v_x_2480; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_2480); r_; });
  }
  V f_ = v_k_2479;
  args[0] = v_x_24107;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_c_2477 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2477;
  args[0] = v_hd_2478;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 1, 2, (V[]){v_n_240, v_k_2479});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_24114 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24113 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24140;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24115 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24115)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24115, 0ULL, 3);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24115, 0ULL, 3);
      v_t_24140 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24115, 0ULL, 4);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24115, 0ULL, 3);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24115, 0ULL, 2);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24115, 0ULL, 2);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24115, 0ULL, 2);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24115, 0ULL, 1);
      v_t_24140 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24115);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24141;
  if ((heff_dup(v_t_24140) == NTAG(TAG_True))) {
    heff_drop(v_t_24140);
    v_x_24141 = v_x_24114;
  } else {
    heff_drop(v_t_24140);
    v_x_24141 = ({ V a_0 = v_x_24114; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24114); r_; });
  }
  V f_ = v_k_24113;
  args[0] = v_x_24141;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_hd_24112 = args[0];
  V v_k_24113 = args[1];
  V v_c_24111 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24111;
  args[0] = v_hd_24112;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 2, (V[]){v_n_240, v_k_24113});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_x_24146 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24145 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24172;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24147 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24147)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24147, 0ULL, 3);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24147, 0ULL, 3);
      v_t_24172 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24147, 0ULL, 4);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24147, 0ULL, 3);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24147, 0ULL, 2);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24147, 0ULL, 2);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24147, 0ULL, 2);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24147, 0ULL, 1);
      v_t_24172 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24147);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24173;
  if ((heff_dup(v_t_24172) == NTAG(TAG_True))) {
    heff_drop(v_t_24172);
    v_x_24173 = v_x_24146;
  } else {
    heff_drop(v_t_24172);
    v_x_24173 = ({ V a_0 = v_x_24146; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24146); r_; });
  }
  V f_ = v_k_24145;
  args[0] = v_x_24173;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_c_24143 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24143;
  args[0] = v_hd_24144;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 2, (V[]){v_n_240, v_k_24145});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_x_24179 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24178 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24205;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24180 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24180)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24180, 0ULL, 3);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24180, 0ULL, 3);
      v_t_24205 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24180, 0ULL, 4);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24180, 0ULL, 3);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24180, 0ULL, 2);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24180, 0ULL, 2);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24180, 0ULL, 2);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24180, 0ULL, 1);
      v_t_24205 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24180);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24206;
  if ((heff_dup(v_t_24205) == NTAG(TAG_True))) {
    heff_drop(v_t_24205);
    v_x_24206 = v_x_24179;
  } else {
    heff_drop(v_t_24205);
    v_x_24206 = ({ V a_0 = v_x_24179; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24179); r_; });
  }
  V f_ = v_k_24178;
  args[0] = v_x_24206;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24177 = args[0];
  V v_k_24178 = args[1];
  V v_c_24176 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24176;
  args[0] = v_hd_24177;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 1, 2, (V[]){v_n_240, v_k_24178});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_x_24212 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24211 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24238;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24213 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24213)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24213, 0ULL, 3);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24213, 0ULL, 3);
      v_t_24238 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24213, 0ULL, 4);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24213, 0ULL, 3);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24213, 0ULL, 2);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24213, 0ULL, 2);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24213, 0ULL, 2);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24213, 0ULL, 1);
      v_t_24238 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24213);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24239;
  if ((heff_dup(v_t_24238) == NTAG(TAG_True))) {
    heff_drop(v_t_24238);
    v_x_24239 = v_x_24212;
  } else {
    heff_drop(v_t_24238);
    v_x_24239 = ({ V a_0 = v_x_24212; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24212); r_; });
  }
  V f_ = v_k_24211;
  args[0] = v_x_24239;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_hd_24210 = args[0];
  V v_k_24211 = args[1];
  V v_c_24209 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24209;
  args[0] = v_hd_24210;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 1, 2, (V[]){v_n_240, v_k_24211});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24245 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24271;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24246 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24246)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24246, 0ULL, 3);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24246, 0ULL, 3);
      v_t_24271 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24246, 0ULL, 4);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24246, 0ULL, 3);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24246, 0ULL, 2);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24246, 0ULL, 2);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24246, 0ULL, 2);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24246, 0ULL, 1);
      v_t_24271 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24246);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24272;
  if ((heff_dup(v_t_24271) == NTAG(TAG_True))) {
    heff_drop(v_t_24271);
    v_x_24272 = v_x_24245;
  } else {
    heff_drop(v_t_24271);
    v_x_24272 = ({ V a_0 = v_x_24245; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24245); r_; });
  }
  V f_ = v_k_24244;
  args[0] = v_x_24272;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_hd_24243 = args[0];
  V v_k_24244 = args[1];
  V v_c_24242 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24242;
  args[0] = v_hd_24243;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 2, (V[]){v_n_240, v_k_24244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_x_24276 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24275 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24302;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24277 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24277)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24277, 0ULL, 3);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24277, 0ULL, 3);
      v_t_24302 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24277, 0ULL, 4);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24277, 0ULL, 3);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24277, 0ULL, 2);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24277, 0ULL, 2);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24277, 0ULL, 2);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24277, 0ULL, 1);
      v_t_24302 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24277);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24303;
  if ((heff_dup(v_t_24302) == NTAG(TAG_True))) {
    heff_drop(v_t_24302);
    v_x_24303 = v_x_24276;
  } else {
    heff_drop(v_t_24302);
    v_x_24303 = ({ V a_0 = v_x_24276; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24276); r_; });
  }
  V f_ = v_k_24275;
  args[0] = v_x_24303;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_hd_24274 = args[0];
  V v_k_24275 = args[1];
  V v_c_24273 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24273;
  args[0] = v_hd_24274;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 1, 2, (V[]){v_n_240, v_k_24275});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_x_24308 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24307 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24334;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24309 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24309)) {
    case TAG_CInf: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CType: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24309, 0ULL, 3);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24309, 0ULL, 3);
      v_t_24334 = NTAG(TAG_True);
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24309, 0ULL, 4);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24309, 0ULL, 3);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CStruct: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24309, 0ULL, 2);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24309, 0ULL, 2);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24309, 0ULL, 2);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CAbandon: {
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    case TAG_CNominal: {
      heff_take_n(v_x11_24309, 0ULL, 1);
      v_t_24334 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_24309);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V v_x_24335;
  if ((heff_dup(v_t_24334) == NTAG(TAG_True))) {
    heff_drop(v_t_24334);
    v_x_24335 = v_x_24308;
  } else {
    heff_drop(v_t_24334);
    v_x_24335 = ({ V a_0 = v_x_24308; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24308); r_; });
  }
  V f_ = v_k_24307;
  args[0] = v_x_24335;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_hd_24306 = args[0];
  V v_k_24307 = args[1];
  V v_c_24305 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24305;
  args[0] = v_hd_24306;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 1, 2, (V[]){v_n_240, v_k_24307});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = ({ V a_0 = v_t_243; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_243); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2411); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2430 = heff_field(v_x2_240, 0);
    V v_sp_2432 = heff_field(v_x2_240, 2);
    V v_t_2433 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2434 = ({ V a_0 = v_t_2433; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_t_2433); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2434, v_sp_2432, v_x_2430});
  }
  case TAG_PiAnon: {
    V v_d_2438 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2439 = ({ V a_0 = v_d_2438; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_d_2438); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2439});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2426;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2425 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2426 = v_s_2425;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_x_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2423, v_t_2426})});
  V f_ = v_k_2422;
  args[0] = v_x_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_t_2420 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2428;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2428 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_t_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    v_c_2428 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_t_2420, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  V f_ = v_c_2428;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2436 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2436;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2432, v_x_2430, v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_sp_2432 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2436, v_sp_2432, v_x_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2442 = args[0];
  V v_k_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2442});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2439;
  args[0] = v_hd_2440;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str0, 5, " and ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str1, 14, " are not equal");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str2, 50, "the implicit arguments found do not fit together: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str3, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, "`, it would need ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str5, 11, "found for `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str6, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str7, 24, " does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str8, 35, "cannot infer an implicit argument: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str9, 9, " := ...)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str10, 14, "`: give it, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str11, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str12, 25, ", does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str13, 21, "what is known of it, ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str14, 36, "cannot infer the implicit argument `");
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_strAppend(heff_dup(v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1)));
    V v_t_247 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2), heff_strAppend(heff_dup(v_left_243), v_t_246));
    V v_t_249;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_249 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_248 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_249 = heff_get_n(v_me_248, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2413;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_2410 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2411 = heff_strAppend(v_left_243, heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), v_right_244));
      V v_t_2412 = heff_strAppend(heff_get_n(v_me_2410, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4), v_t_2411));
      v_t_2413 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5), v_t_2412)});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_247, v_t_249, v_t_2413});
  } else {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7)));
      V v_t_2415 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8), heff_strAppend(v_left_243, v_t_2414));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2415, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2416 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_me_2416, 4)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9));
      V v_t_2418 = heff_strAppend(heff_take_field(v_me_2416, 4), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10), v_t_2417));
      V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11), heff_strAppend(v_right_244, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12)));
      V v_t_2420 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13), heff_strAppend(v_left_243, v_t_2419));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14), v_t_2418), heff_get_n(v_me_2416, 5, 6), heff_tag_n(TAG_Just, 1, (V[]){v_t_2420})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 9, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_isInstance_243, V v_tyStx_244, V v_mc_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Left: {
    V v_failed_249 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2410 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2411;
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      v_key_2411 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2410);
      v_key_2411 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2412 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2413;
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      heff_drop(v_t_2412);
      v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2412);
      v_t_2413 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_entry_2414 = ({ V a_0 = v_g_241; V a_1 = v_t_2413; V a_2 = v_tyStx_244; V r_ = (g_heff_2eelab_2etoplevel_2eerrEntry(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2415 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2411, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2414, heff_tag_n(TAG_Just, 1, (V[]){v_failed_249})});
    return heff_tail(v_z_248, 1, (V[]){v_t_2415});
  }
  case TAG_Right: {
    V v_t_2416 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_t_2417 = heff_dup(heff_rfield(v_d_242, 3));
    V v_key_2418;
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      v_key_2418 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2417);
      v_key_2418 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2419 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2420;
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      v_t_2420 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2419);
      v_t_2420 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2421 = heff_dup(heff_rfield(v_d_242, 3));
    V v_k_2422;
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      heff_drop(v_t_2421);
      v_k_2422 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2421);
      v_k_2422 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(heff_rfield(v_d_242, 0))}));
    }
    V v_t_2423 = (g_heff_2eelab_2eunify_2ezonker(v_mc_245));
    V v_t_2424 = heff_tr(heff_call(heff_get_n(v_t_2423, 0, 2), 1, (V[]){heff_get_n(v_t_2416, 0, 2)}));
    V v_t_2425 = (g_heff_2eelab_2etoplevel_2eselfWalk(v_k_2422));
    V v_t_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2424}));
    V v_entry_2427 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2420, heff_rfield(v_d_242, 3), v_tyStx_244, v_t_2426));
    V v_t_2428 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){heff_take_field(v_d_242, 0), v_key_2418, heff_get_n(v_d_242, 3, 4), v_isInstance_243, v_entry_2427, NTAG(TAG_Nothing)});
    return heff_tail(v_z_248, 1, (V[]){v_t_2428});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a7 = a[7]; V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a5, a[6], a7, a[8]); heff_drop(a5); heff_drop(a7); return r;
}

static V g_heff_2eelab_2etoplevel_2eprimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2eprimNames_st;
static V g_heff_2eelab_2etoplevel_2eprimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2eprims_get())));
}
V g_heff_2eelab_2etoplevel_2eprimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2eprimNames_st)) return g_heff_2eelab_2etoplevel_2eprimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2eprimNames_val, &g_heff_2eelab_2etoplevel_2eprimNames_st, g_heff_2eelab_2etoplevel_2eprimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewatchEntry_str0, 7, "> watch");
Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchEntry_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ewatchEntry(V v_g_240, V v_mc_241, V v_t_242, V v_ty_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_241, v_ty_243));
  V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_244));
  V v_t_246 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_tyStx_247 = heff_tr(heff_call(heff_get_n(v_t_246, 1, 2), 1, (V[]){v_t_245}));
  V v_t_248 = (g_heff_2eelab_2eunify_2ezonker(v_mc_241));
  V v_bodyStx_249 = heff_tr(heff_call(heff_get_n(v_t_248, 0, 2), 1, (V[]){heff_get_n(v_t_242, 0, 2)}));
  V v_t_2410 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_240), ((V)&g_heff_2eelab_2etoplevel_2ewatchEntry_str0), heff_dup(v_tyStx_247), heff_dup(v_bodyStx_249)));
  V v_x1_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(v_g_240, NTAG(TAG_N), heff_dup(v_tyStx_247), NTAG(TAG_LNil)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_Nom: {
    V v_x_2412 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2412;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2411, 0ULL, 1);
    v_t_2415 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2414 = heff_field(v_x1_2411, 0);
    heff_take_n(v_x1_2411, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2411);
  }
  return heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_249, v_tyStx_247, v_t_2410, v_t_2415});
}
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2ewatchEntry(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2etopGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etopGo_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etopGo(V v_kf_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_kf_240);
    V v_diags_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 1)));
    V v_keys_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 2)));
    V v_broken_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 3)));
    V v_watches_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 4)));
    V v_tests_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 5)));
    V v_spans_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 6)));
    V v_infos_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 7)));
    V v_trace_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_241, 8)));
    return ({ V rv_1 = v_diags_243; V rv_2 = v_keys_244; V rv_3 = v_broken_245; V rv_4 = v_watches_246; V rv_5 = v_tests_247; V rv_6 = v_spans_248; V rv_7 = v_infos_249; V rv_8 = v_trace_2410; V rr_ = heff_rec_reuse_nf(v_acc_241, 1ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; rr_; });
  }
  case TAG_Cons: {
    V v_n_2411 = heff_field(v_x3_242, 0);
    V v_rest_2412 = heff_field(v_x3_242, 1);
    V v_t_2413 = (g_heff_2eelab_2etoplevel_2etopOne(heff_dup(v_kf_240), v_acc_241, heff_dup(v_n_2411)));
    V t_0 = v_kf_240;
    V t_1 = v_t_2413;
    V t_2 = v_rest_2412;
    v_kf_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2etopGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2etopGo(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eisPrimB(a0); heff_drop(a0); return r;
}