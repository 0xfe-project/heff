// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Anonymous 24551
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588 6711
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_INotationVar 46285
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_LNil 57394
#define TAG_LargeU 29057
#define TAG_Left 13886
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16607
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_TSig 38418
#define TAG_Throw 56084
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_el 9998
#define LBL_end 310101
#define LBL_entry 298026124
#define LBL_failed 665164648
#define LBL_globals 352931696
#define LBL_isInstance 728053194
#define LBL_key 315609
#define LBL_large 304101205
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_prim 9944941
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tm 10464
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_val 326043
#define LBL_value 313331083
static uint32_t shape_chk__span[] = {LBL_chk, LBL_span};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__key__prim__isInstance__entry__failed[] = {LBL_name, LBL_key, LBL_prim, LBL_isInstance, LBL_entry, LBL_failed};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s196996678x1811735276(V, V, V);
V g_co_2ebind_24s196996678x1811735276_entry(V self, V *a);
extern Clo g_co_2ebind_24s196996678x1811735276_clo;
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656(V, V);
V g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656_clo;
V g_heff_2eelab_2eenvironment_2eseeArms(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_clo;
V g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566_clo;
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2eprimitive_2elibraryTable_get(void);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
HeffT1 g_heff_2eelab_2erules_2eapply_24cpr(V, V);
V g_heff_2eelab_2erules_2edelayAt(V, V, V);
V g_heff_2eelab_2erules_2edelayAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayAt_clo;
V g_heff_2eelab_2erules_2eformRecord(V, V);
V g_heff_2eelab_2erules_2eformRecord_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformRecord_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2erules_2elambdaChk(V, V, V, V);
V g_heff_2eelab_2erules_2elambdaChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elambdaChk_clo;
V g_heff_2eelab_2erules_2elazyOther(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elazyOther_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazyOther_clo;
V g_heff_2eelab_2erules_2erecordOf(V, V);
V g_heff_2eelab_2erules_2erecordOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(V, V, V);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_clo;
V g_heff_2eelab_2etoplevel_2eelabOut(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_clo;
V g_heff_2eelab_2etoplevel_2eentryFor(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eentryFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eentryFor_clo;
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338(V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2eisPrimB(V);
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(V);
V g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370_clo;
V g_heff_2eelab_2etoplevel_2eselfTermF_24map0(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTermF_24map0_clo;
V g_heff_2eelab_2etoplevel_2eselfWalk(V);
V g_heff_2eelab_2etoplevel_2eselfWalk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfWalk_clo;
V g_heff_2eelab_2etoplevel_2estuckWith(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckWith_clo;
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(V, V);
V g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2emap_24s2098521682x1221164629(V);
V g_list_2emap_24s2098521682x1221164629_entry(V self, V *a);
extern Clo g_list_2emap_24s2098521682x1221164629_clo;
V g_prelude_2etraverse_24s1778157750x1229378888(V);
V g_prelude_2etraverse_24s1778157750x1229378888_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1778157750x1229378888_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_prelude_2etraverse_24s1963041714x1343204084(V, V, V);
V g_prelude_2etraverse_24s1963041714x1343204084_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1963041714x1343204084_clo;
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2(V, V, V, V);
V g_prelude_2etraverse_24s1963041714x1343204084_24tok2_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1963041714x1343204084_24tok2_clo;
V g_prelude_2etraverse_24s2094958103x549422471(V);
V g_prelude_2etraverse_24s2094958103x549422471_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s2094958103x549422471_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2etoplevel_2eselfTermF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTermF_24map0_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTermF_24map0(V v_r_240, V v_d_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_p_244 = heff_arrayIndexIn_lent(v_a_243, heff_box_word(v_i_242), 2);
      V v_t_249;
      switch (heff_tag_of(v_p_244)) {
      case TAG_MkPair: {
        V v_xs_245 = heff_field(v_p_244, 0);
        V v_b_246 = heff_field(v_p_244, 1);
        V v_ru_24p_244_24MkPair = heff_take_reuse_n(v_p_244, 3ULL, 2);
        V v_t_247 = heff_intAdd(heff_dup(v_d_241), heff_arrayLength_lent(v_xs_245, 0));
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){v_t_247, v_b_246}));
        v_t_249 = heff_tag_at_n(v_ru_24p_244_24MkPair, TAG_MkPair, 2, (V[]){v_xs_245, v_t_248});
        break;
      }
      default: heff_nomatch(v_p_244);
      }
      V t_0 = v_r_240;
      V t_1 = v_d_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_249);
      v_r_240 = t_0;
      v_d_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_d_241);
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_p_244 = heff_arrayIndex_lent(v_a_243, heff_box_word(v_i_242), 2);
    V v_t_249;
    switch (heff_tag_of(v_p_244)) {
    case TAG_MkPair: {
      V v_xs_245 = heff_field(v_p_244, 0);
      V v_b_246 = heff_field(v_p_244, 1);
      V v_ru_24p_244_24MkPair = heff_take_reuse_n(v_p_244, 3ULL, 2);
      V v_t_247 = heff_intAdd(heff_dup(v_d_241), heff_arrayLength_lent(v_xs_245, 0));
      V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){v_t_247, v_b_246}));
      v_t_249 = heff_tag_at_n(v_ru_24p_244_24MkPair, TAG_MkPair, 2, (V[]){v_xs_245, v_t_248});
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V t_0 = v_r_240;
    V t_1 = v_d_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_249);
    v_r_240 = t_0;
    v_d_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_241);
    return v_a_243;
  }
}
V g_heff_2eelab_2etoplevel_2eselfTermF_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eselfTermF_24map0(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_PatVar: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_PatTag: {
        return NTAG(TAG_False);
      }
      case TAG_PatOp: {
        return NTAG(TAG_False);
      }
      case TAG_PatInt: {
        return NTAG(TAG_False);
      }
      case TAG_PatFloat: {
        return NTAG(TAG_False);
      }
      case TAG_PatString: {
        return NTAG(TAG_False);
      }
      case TAG_PatBinary: {
        return NTAG(TAG_False);
      }
      case TAG_PatRune: {
        return NTAG(TAG_False);
      }
      case TAG_PatRecord: {
        return NTAG(TAG_False);
      }
      case TAG_PatWord: {
        return NTAG(TAG_False);
      }
      case TAG_PatAs: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x11_243);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_a_243 = (g_heff_2eelab_2etoplevel_2ehasOpPat(v_x_241));
    if (!(heff_dup(v_a_243) == NTAG(TAG_True))) {
      heff_drop(v_a_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_a_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str7, 0, "");
Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V v_n_240) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str0), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str1), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str2), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str3), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str4), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str5), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str6), ((V)&g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_str7), v_n_240));
}
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str0, 12, "builtin.Lazy");
HEFF_LIT(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str2, 11, "its field `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str3, 113, "` is no run-time data: a record with such a field is a theory -- declare it with `theory X where`, a field a line");
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam24(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam23(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V v_n_240) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_241 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_n1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_n1_241, 0);
      V v_ru_24n1_241_24CInf = heff_take_reuse_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        heff_take_n(v_n_240, 0ULL, 2);
        V v_t_2444;
        switch (heff_tag_of(v_i_243)) {
        case TAG_At: {
          V v_x11_246 = heff_dup(heff_field(v_i_243, 0));
          switch (heff_tag_of(v_x11_246)) {
          case TAG_IVar: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_INotationVar: {
            heff_take_n(v_x11_246, 0ULL, 3);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IInt: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IFloat: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IString: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IRune: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IApp: {
            heff_take_n(v_x11_246, 0ULL, 2);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_246, 0ULL, 2);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_246, 0ULL, 4);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_246, 0ULL, 2);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_246, 0ULL, 4);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_246, 0ULL, 3);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_INominal: {
            V v_i_2435 = heff_field(v_x11_246, 0);
            heff_take_n(v_x11_246, 1ULL, 1);
            switch (heff_tag_of(v_i_243)) {
            case TAG_At: {
              v_t_2444 = v_i_2435;
              break;
            }
            default: heff_nomatch(v_i_243);
            }
            break;
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_246, 0ULL, 4);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_ILazy: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          case TAG_ITuple: {
            heff_take_n(v_x11_246, 0ULL, 1);
            v_t_2444 = heff_dup(v_i_243);
            break;
          }
          default: heff_nomatch(v_x11_246);
          }
          break;
        }
        default: heff_nomatch(v_i_243);
        }
        V v_t_2481;
        switch (heff_tag_of(v_t_2444)) {
        case TAG_At: {
          V v_x11_2445 = heff_field(v_t_2444, 0);
          heff_take_n(v_t_2444, 1ULL, 2);
          switch (heff_tag_of(v_x11_2445)) {
          case TAG_IVar: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_INotationVar: {
            heff_take_n(v_x11_2445, 0ULL, 3);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IInt: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IFloat: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IString: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IBytes: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IPrim: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IRune: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IApp: {
            heff_take_n(v_x11_2445, 0ULL, 2);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IAnn: {
            heff_take_n(v_x11_2445, 0ULL, 2);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ISpec: {
            heff_take_n(v_x11_2445, 0ULL, 4);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IUpdate: {
            heff_take_n(v_x11_2445, 0ULL, 2);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IAnnLam: {
            heff_take_n(v_x11_2445, 0ULL, 4);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_IInvalid: {
            heff_take_n(v_x11_2445, 0ULL, 3);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_INominal: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ILitEq: {
            heff_take_n(v_x11_2445, 0ULL, 4);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_ILazy: {
            V v_c_2479 = heff_field(v_x11_2445, 0);
            heff_take_n(v_x11_2445, 1ULL, 1);
            v_t_2481 = heff_tag_at_n(v_ru_24n1_241_24CInf, TAG_Just, 1, (V[]){v_c_2479});
            break;
          }
          case TAG_ITuple: {
            heff_take_n(v_x11_2445, 0ULL, 1);
            heff_drop_cell(v_ru_24n1_241_24CInf, 1);
            v_t_2481 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x11_2445);
          }
          break;
        }
        default: heff_nomatch(v_t_2444);
        }
        switch (heff_tag_of(v_t_2481)) {
        case TAG_Nothing: {
          V v_t_24120;
          switch (heff_tag_of(v_i_243)) {
          case TAG_At: {
            V v_x11_2482 = heff_dup(heff_field(v_i_243, 0));
            switch (heff_tag_of(v_x11_2482)) {
            case TAG_IVar: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_INotationVar: {
              heff_take_n(v_x11_2482, 0ULL, 3);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IInt: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IFloat: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IString: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IRune: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IApp: {
              heff_take_n(v_x11_2482, 0ULL, 2);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_2482, 0ULL, 2);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_2482, 0ULL, 4);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_2482, 0ULL, 2);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_2482, 0ULL, 4);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_2482, 0ULL, 3);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_INominal: {
              V v_i_24111 = heff_field(v_x11_2482, 0);
              heff_take_n(v_x11_2482, 1ULL, 1);
              switch (heff_tag_of(v_i_243)) {
              case TAG_At: {
                v_t_24120 = v_i_24111;
                break;
              }
              default: heff_nomatch(v_i_243);
              }
              break;
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_2482, 0ULL, 4);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            case TAG_ITuple: {
              heff_take_n(v_x11_2482, 0ULL, 1);
              v_t_24120 = heff_dup(v_i_243);
              break;
            }
            default: heff_nomatch(v_x11_2482);
            }
            break;
          }
          default: heff_nomatch(v_i_243);
          }
          switch (heff_tag_of(v_t_24120)) {
          case TAG_At: {
            V v_x11_24121 = heff_field(v_t_24120, 0);
            V v_sp_24122 = heff_field(v_t_24120, 1);
            heff_take_n(v_t_24120, 3ULL, 2);
            switch (heff_tag_of(v_x11_24121)) {
            case TAG_IVar: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_INotationVar: {
              heff_take_n(v_x11_24121, 0ULL, 3);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IInt: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IFloat: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IString: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IRune: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IApp: {
              heff_take_n(v_x11_24121, 0ULL, 2);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_24121, 0ULL, 2);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_24121, 0ULL, 4);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_24121, 0ULL, 2);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_24121, 0ULL, 4);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_24121, 0ULL, 3);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_INominal: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_24121, 0ULL, 4);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_24121, 0ULL, 1);
              heff_drop(v_sp_24122);
              HEFF_LAST return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(v_i_243);
            }
            case TAG_ITuple: {
              V v_cs_24156 = heff_field(v_x11_24121, 0);
              heff_take_n(v_x11_24121, 1ULL, 1);
              V v_t_24193;
              switch (heff_tag_of(v_i_243)) {
              case TAG_At: {
                V v_x11_24157 = heff_field(v_i_243, 0);
                heff_take_n(v_i_243, 1ULL, 2);
                switch (heff_tag_of(v_x11_24157)) {
                case TAG_IVar: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_INotationVar: {
                  heff_take_n(v_x11_24157, 0ULL, 3);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IInt: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IFloat: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IString: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IBytes: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IPrim: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IRune: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IApp: {
                  heff_take_n(v_x11_24157, 0ULL, 2);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IAnn: {
                  heff_take_n(v_x11_24157, 0ULL, 2);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_ISpec: {
                  heff_take_n(v_x11_24157, 0ULL, 4);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IUpdate: {
                  heff_take_n(v_x11_24157, 0ULL, 2);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IAnnLam: {
                  heff_take_n(v_x11_24157, 0ULL, 4);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_IInvalid: {
                  heff_take_n(v_x11_24157, 0ULL, 3);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_INominal: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_True);
                  break;
                }
                case TAG_ILitEq: {
                  heff_take_n(v_x11_24157, 0ULL, 4);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_ILazy: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                case TAG_ITuple: {
                  heff_take_n(v_x11_24157, 0ULL, 1);
                  v_t_24193 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_x11_24157);
                }
                break;
              }
              default: heff_nomatch(v_i_243);
              }
              return ({ V a_0 = v_t_24193; V a_1 = v_sp_24122; V a_2 = v_cs_24156; V r_ = (g_heff_2eelab_2etoplevel_2etupleChkF_24s1911938197x1899529259(a_0, a_1, a_2)); heff_drop(v_t_24193); r_; });
            }
            default: return heff_nomatch(v_x11_24121);
            }
          }
          default: return heff_nomatch(v_t_24120);
          }
        }
        case TAG_Just: {
          V v_c_24194 = heff_field(v_t_2481, 0);
          heff_take_n(v_t_2481, 1ULL, 1);
          V v_nominal_24231;
          switch (heff_tag_of(v_i_243)) {
          case TAG_At: {
            V v_x11_24195 = heff_dup(heff_field(v_i_243, 0));
            switch (heff_tag_of(v_x11_24195)) {
            case TAG_IVar: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_INotationVar: {
              heff_take_n(v_x11_24195, 0ULL, 3);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IInt: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IFloat: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IString: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IBytes: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IPrim: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IRune: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IApp: {
              heff_take_n(v_x11_24195, 0ULL, 2);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnn: {
              heff_take_n(v_x11_24195, 0ULL, 2);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_ISpec: {
              heff_take_n(v_x11_24195, 0ULL, 4);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IUpdate: {
              heff_take_n(v_x11_24195, 0ULL, 2);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IAnnLam: {
              heff_take_n(v_x11_24195, 0ULL, 4);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_IInvalid: {
              heff_take_n(v_x11_24195, 0ULL, 3);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_INominal: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_True);
              break;
            }
            case TAG_ILitEq: {
              heff_take_n(v_x11_24195, 0ULL, 4);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_ILazy: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            case TAG_ITuple: {
              heff_take_n(v_x11_24195, 0ULL, 1);
              v_nominal_24231 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_x11_24195);
            }
            break;
          }
          default: heff_nomatch(v_i_243);
          }
          V v_sp_24234;
          switch (heff_tag_of(v_i_243)) {
          case TAG_At: {
            V v_s_24233 = heff_field(v_i_243, 1);
            heff_take_n(v_i_243, 2ULL, 2);
            v_sp_24234 = v_s_24233;
            break;
          }
          default: heff_nomatch(v_i_243);
          }
          V v_c_24235 = v_c_24194;
          V v_m_24236 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_24235)));
          return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0, 2, 4, (V[]){v_m_24236, v_sp_24234, v_c_24235, v_nominal_24231});
        }
        default: return heff_nomatch(v_t_2481);
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    case TAG_CType: {
      V v_t_24314 = heff_field(v_n1_241, 0);
      heff_take_n(v_n1_241, 1ULL, 1);
      switch (heff_tag_of(v_n_240)) {
      case TAG_At: {
        V v_n2_24316 = heff_field(v_n_240, 1);
        heff_take_n(v_n_240, 2ULL, 2);
        V v_sp_24317 = v_n2_24316;
        V v_t_24318 = v_t_24314;
        switch (heff_tag_of(v_t_24318)) {
        case TAG_At: {
          V v_t1_24319 = heff_dup(heff_field(v_t_24318, 0));
          switch (heff_tag_of(v_t1_24319)) {
          case TAG_TSig: {
            V v_fields_24321 = heff_field(v_t1_24319, 0);
            heff_take_n(v_t1_24319, 1ULL, 1);
            switch (heff_tag_of(v_t_24318)) {
            case TAG_At: {
              heff_take_n(v_t_24318, 0ULL, 2);
              V v_c_24324 = (g_prelude_2etraverse_24s2094958103x549422471(v_fields_24321));
              return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11, 2, 2, (V[]){v_c_24324, v_sp_24317});
            }
            default: return heff_nomatch(v_t_24318);
            }
          }
          default: {
            heff_drop(v_t1_24319);
            V v_c_24346 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_24318));
            return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17, 2, 2, (V[]){v_c_24346, v_sp_24317});
          }
          }
        }
        default: return heff_nomatch(v_t_24318);
        }
      }
      default: return heff_nomatch(v_n_240);
      }
    }
    default: {
      heff_drop(v_n1_241);
      V v_c_24364 = (g_heff_2eelab_2etoplevel_2erawF_24s95412634x2127120370(heff_dup(v_n_240)));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam23, 2, 2, (V[]){v_c_24364, v_n_240});
    }
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4(V self, V *args) {
  V v_x_24247 = args[0];
  V v_e_24243 = heff_env(self)[0];
  V v_hd_24245 = heff_env(self)[1];
  V v_k_24246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_24247)) {
  case TAG_MkSyn: {
    V v_f_24248 = heff_field(v_x_24247, 0);
    heff_take_n(v_x_24247, 1ULL, 1);
    V f_ = v_f_24248;
    heff_room[0] = v_e_24243;
    heff_room[1] = v_hd_24245;
    heff_room[2] = v_k_24246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_24247);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3(V self, V *args) {
  V v_hd_24245 = args[0];
  V v_k_24246 = args[1];
  V v_c_24244 = heff_env(self)[0];
  V v_e_24243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24244;
  args[0] = heff_dup(v_hd_24245);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam4, 1, 3, (V[]){v_e_24243, v_hd_24245, v_k_24246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2(V self, V *args) {
  V v_e_24243 = args[0];
  V v_sp_24234 = heff_env(self)[0];
  V v_c_24235 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_24244 = (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(v_sp_24234, v_c_24235));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam3, 2, 2, (V[]){v_c_24244, v_e_24243});
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6(V self, V *args) {
  V v_c_24254 = args[0];
  V v_a0_24251 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24254, 3, 9); V a_1 = v_a0_24251; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9(V self, V *args) {
  V v_u_24303 = args[0];
  V v_x_24297 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24303);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_24297});
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10(V self, V *args) {
  V v_hd_24305 = args[0];
  V v_k_24306 = args[1];
  V v_x_24304 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24305);
  V f_ = v_k_24306;
  args[0] = v_x_24304;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8(V self, V *args) {
  V v_e_24299 = args[0];
  V v_a_24300 = args[1];
  V v_x_24297 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_24300);
  V v_t_24301 = heff_get_n(heff_get_n(v_e_24299, 0, 6), 0, 5);
  V v_t_24302 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_t_24301, heff_dup(v_x_24297)));
  V v_x_24304 = heff_rec_n(2, shape_stx__val, (V[]){v_t_24302, heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam9, 1, 1, (V[]){v_x_24297})});
  return heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam10, 2, 1, (V[]){v_x_24304});
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7(V self, V *args) {
  V v_x_24258 = args[0];
  V v_sp_24241 = heff_env(self)[0];
  V v_c_24242 = heff_env(self)[1];
  V v_s_24249 = heff_env(self)[2];
  V v_e_24250 = heff_env(self)[3];
  V v_hd_24252 = heff_env(self)[4];
  V v_k_24253 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_24259 = heff_dup(v_x_24258);
  V v_t_24296;
  switch (heff_tag_of(v_x1_24259)) {
  case TAG_VU: {
    heff_take_n(v_x1_24259, 0ULL, 1);
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    V v_x11_24261 = heff_field(v_x1_24259, 0);
    V v_x12_24262 = heff_field(v_x1_24259, 1);
    heff_take_n(v_x1_24259, 3ULL, 5);
    switch (heff_tag_of(v_x11_24261)) {
    case TAG_HLocal: {
      heff_take_n(v_x11_24261, 0ULL, 1);
      heff_drop(v_x12_24262);
      v_t_24296 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_HGlobal: {
      V v_k_24267 = heff_field(v_x11_24261, 0);
      V v_ru_24x11_24261_24HGlobal = heff_take_reuse_n(v_x11_24261, 1ULL, 1);
      switch (heff_tag_of(v_x12_24262)) {
      case TAG_SpId: {
        heff_drop(v_k_24267);
        heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
        v_t_24296 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SpApp: {
        V v_x121_24268 = heff_field(v_x12_24262, 0);
        V v_x_24269 = heff_field(v_x12_24262, 1);
        heff_take_n(v_x12_24262, 3ULL, 2);
        switch (heff_tag_of(v_x121_24268)) {
        case TAG_SpId: {
          if (heff_strEq_c(v_k_24267, ((V)&g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str0))) {
            v_t_24296 = heff_tag_at_n(v_ru_24x11_24261_24HGlobal, TAG_Just, 1, (V[]){v_x_24269});
          } else {
            heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
            heff_drop(v_x_24269);
            v_t_24296 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_SpApp: {
          heff_take_n(v_x121_24268, 0ULL, 2);
          heff_drop(v_k_24267);
          heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
          heff_drop(v_x_24269);
          v_t_24296 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SpProj: {
          heff_take_n(v_x121_24268, 0ULL, 2);
          heff_drop(v_k_24267);
          heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
          heff_drop(v_x_24269);
          v_t_24296 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_SpSpec: {
          heff_take_n(v_x121_24268, 0ULL, 3);
          heff_drop(v_k_24267);
          heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
          heff_drop(v_x_24269);
          v_t_24296 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x121_24268);
        }
        break;
      }
      case TAG_SpProj: {
        heff_take_n(v_x12_24262, 0ULL, 2);
        heff_drop(v_k_24267);
        heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
        v_t_24296 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SpSpec: {
        heff_take_n(v_x12_24262, 0ULL, 3);
        heff_drop(v_k_24267);
        heff_drop_cell(v_ru_24x11_24261_24HGlobal, 1);
        v_t_24296 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x12_24262);
      }
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_x11_24261, 0ULL, 1);
      heff_drop(v_x12_24262);
      v_t_24296 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_HError: {
      heff_drop(v_x12_24262);
      v_t_24296 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_24261);
    }
    break;
  }
  case TAG_VFunction: {
    heff_take_n(v_x1_24259, 0ULL, 6);
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_x1_24259, 0ULL, 4);
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_x1_24259, 0ULL, 1);
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_x1_24259, 0ULL, 1);
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_x1_24259, 0ULL, 1);
    v_t_24296 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_x1_24259);
  }
  switch (heff_tag_of(v_t_24296)) {
  case TAG_Nothing: {
    return ({ V a_0 = v_sp_24241; V a_1 = v_c_24242; V a_2 = v_s_24249; V a_3 = v_e_24250; V a_4 = v_x_24258; V a_5 = v_hd_24252; V a_6 = v_k_24253; V r_ = (g_heff_2eelab_2erules_2elazyOther(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop_tag(v_s_24249, 1); r_; });
  }
  case TAG_Just: {
    V v_x_24297 = heff_field(v_t_24296, 0);
    V v_ru_24t_24296_24Just = heff_take_reuse_n(v_t_24296, 1ULL, 1);
    heff_drop_tag(v_s_24249, 1);
    V v_t_24298 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(v_sp_24241); V a_2 = ((V)&g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str1); V a_3 = v_c_24242; V r_ = (g_heff_2eelab_2erules_2elambdaChk(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_c_24242); r_; });
    V v_t_24307 = ({ V a_0 = heff_dup(v_sp_24241); V b_1 = heff_tag_at_n(v_ru_24t_24296_24Just, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam8, 2, 1, (V[]){v_x_24297})}); V a_2 = v_t_24298; V r_ = (g_heff_2eelab_2erules_2edelayAt(a_0, b_1, a_2)); heff_drop(b_1); r_; });
    HeffT1 v_t_24308 = ({ V a_0 = v_sp_24241; V a_1 = v_t_24307; HeffT1 r_ = (g_heff_2eelab_2erules_2eapply_24cpr(a_0, a_1)); heff_drop(v_t_24307); r_; });
    {
      V v_field_24309 = v_t_24308.f[0];
      V v_f_24310 = v_field_24309;
      V f_ = v_f_24310;
      heff_room[0] = v_e_24250;
      heff_room[1] = v_x_24258;
      heff_room[2] = v_hd_24252;
      heff_room[3] = v_k_24253;
      if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
    }
  }
  default: return heff_nomatch(v_t_24296);
  }
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5(V self, V *args) {
  V v_e_24250 = args[0];
  V v_a0_24251 = args[1];
  V v_hd_24252 = args[2];
  V v_k_24253 = args[3];
  V v_sp_24241 = heff_env(self)[0];
  V v_c_24242 = heff_env(self)[1];
  V v_s_24249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24255 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam6, 1, 1, (V[]){v_a0_24251})})});
  V v_t_24256 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24255})});
  V v_t_24257 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24252, 2)), 1, (V[]){v_t_24256}));
  V f_ = heff_dup(heff_rfield(v_hd_24252, 1));
  args[0] = v_t_24257;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam7, 1, 6, (V[]){v_sp_24241, v_c_24242, v_s_24249, v_e_24250, v_hd_24252, v_k_24253});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1(V self, V *args) {
  V v_x_24240 = args[0];
  V v_sp_24234 = heff_env(self)[0];
  V v_c_24235 = heff_env(self)[1];
  V v_nominal_24231 = heff_env(self)[2];
  V v_k_24238 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_sp_24241 = heff_dup(v_sp_24234);
  V v_c_24242 = v_x_24240;
  V v_s_24249 = heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam2, 1, 2, (V[]){v_sp_24234, v_c_24235})});
  V v_j_24311 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam5, 4, 3, (V[]){v_sp_24241, v_c_24242, v_s_24249})});
  V v_t_24312;
  if ((heff_dup(v_nominal_24231) == NTAG(TAG_True))) {
    heff_drop(v_nominal_24231);
    v_t_24312 = ({ V a_0 = v_j_24311; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop_tag(v_j_24311, 1); r_; });
  } else {
    heff_drop(v_nominal_24231);
    v_t_24312 = v_j_24311;
  }
  V v_x_24313 = ({ V a_0 = v_t_24312; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_24312); r_; });
  V f_ = v_k_24238;
  args[0] = v_x_24313;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam0(V self, V *args) {
  V v_hd_24237 = args[0];
  V v_k_24238 = args[1];
  V v_m_24236 = heff_env(self)[0];
  V v_sp_24234 = heff_env(self)[1];
  V v_c_24235 = heff_env(self)[2];
  V v_nominal_24231 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24239 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_24236}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_24239, v_hd_24237, heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam1, 1, 4, (V[]){v_sp_24234, v_c_24235, v_nominal_24231, v_k_24238})));
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14(V self, V *args) {
  V v_c_24334 = args[0];
  V v_a0_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24334, 3, 9); V a_1 = v_a0_24331; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16(V self, V *args) {
  V v_x_24340 = args[0];
  V v_e_24330 = heff_env(self)[0];
  V v_sp_24328 = heff_env(self)[1];
  V v_x_24338 = heff_env(self)[2];
  V v_hd_24332 = heff_env(self)[3];
  V v_k_24333 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24341 = heff_dup(heff_rfield(v_x_24340, 3));
  V v_t_24344;
  switch (heff_tag_of(v_t_24341)) {
  case TAG_Nothing: {
    v_t_24344 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_field_24342 = heff_field(v_t_24341, 0);
    V v_ru_24t_24341_24Just = heff_take_reuse_n(v_t_24341, 1ULL, 1);
    V v_t_24343 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str2), v_field_24342), ((V)&g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_str3));
    v_t_24344 = heff_tag_at_n(v_ru_24t_24341_24Just, TAG_Just, 1, (V[]){v_t_24343});
    break;
  }
  default: heff_nomatch(v_t_24341);
  }
  V v_t_24345 = (g_heff_2eelab_2erules_2erecordOf(heff_dup(v_e_24330), v_x_24340));
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_24328, v_t_24344, v_e_24330, v_x_24338, v_t_24345, v_hd_24332, v_k_24333));
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15(V self, V *args) {
  V v_x_24338 = args[0];
  V v_e_24330 = heff_env(self)[0];
  V v_fieldTyps_24329 = heff_env(self)[1];
  V v_hd_24332 = heff_env(self)[2];
  V v_sp_24328 = heff_env(self)[3];
  V v_k_24333 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24339 = (g_heff_2eelab_2erules_2eformRecord(heff_dup(v_e_24330), v_fieldTyps_24329));
  V f_ = v_c_24339;
  heff_room[0] = heff_dup(v_hd_24332);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam16, 1, 5, (V[]){v_e_24330, v_sp_24328, v_x_24338, v_hd_24332, v_k_24333});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13(V self, V *args) {
  V v_e_24330 = args[0];
  V v_a0_24331 = args[1];
  V v_hd_24332 = args[2];
  V v_k_24333 = args[3];
  V v_fieldTyps_24329 = heff_env(self)[0];
  V v_sp_24328 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24335 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam14, 1, 1, (V[]){v_a0_24331})})});
  V v_t_24336 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24335})});
  V v_t_24337 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24332, 2)), 1, (V[]){v_t_24336}));
  V f_ = heff_dup(heff_rfield(v_hd_24332, 1));
  args[0] = v_t_24337;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam15, 1, 5, (V[]){v_e_24330, v_fieldTyps_24329, v_hd_24332, v_sp_24328, v_k_24333});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12(V self, V *args) {
  V v_x_24327 = args[0];
  V v_sp_24317 = heff_env(self)[0];
  V v_k_24326 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_sp_24328 = v_sp_24317;
  V v_fieldTyps_24329 = v_x_24327;
  V f_ = v_k_24326;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam13, 4, 2, (V[]){v_fieldTyps_24329, v_sp_24328})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam11(V self, V *args) {
  V v_hd_24325 = args[0];
  V v_k_24326 = args[1];
  V v_c_24324 = heff_env(self)[0];
  V v_sp_24317 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24324;
  args[0] = v_hd_24325;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam12, 1, 2, (V[]){v_sp_24317, v_k_24326});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam20(V self, V *args) {
  V v_c_24356 = args[0];
  V v_a0_24353 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_24356, 3, 9); V a_1 = v_a0_24353; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam22(V self, V *args) {
  V v_x_24363 = args[0];
  V v_sp_24350 = heff_env(self)[0];
  V v_e_24352 = heff_env(self)[1];
  V v_x_24360 = heff_env(self)[2];
  V v_hd_24354 = heff_env(self)[3];
  V v_k_24355 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_24350, NTAG(TAG_Nothing), v_e_24352, v_x_24360, v_x_24363, v_hd_24354, v_k_24355));
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam21(V self, V *args) {
  V v_x_24360 = args[0];
  V v_typ_24351 = heff_env(self)[0];
  V v_e_24352 = heff_env(self)[1];
  V v_hd_24354 = heff_env(self)[2];
  V v_sp_24350 = heff_env(self)[3];
  V v_k_24355 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24362;
  switch (heff_tag_of(v_typ_24351)) {
  case TAG_MkTyp: {
    V v_f_24361 = heff_field(v_typ_24351, 0);
    heff_take_n(v_typ_24351, 1ULL, 1);
    v_c_24362 = heff_tr(heff_call(v_f_24361, 1, (V[]){heff_dup(v_e_24352)}));
    break;
  }
  default: heff_nomatch(v_typ_24351);
  }
  V f_ = v_c_24362;
  heff_room[0] = heff_dup(v_hd_24354);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam22, 1, 5, (V[]){v_sp_24350, v_e_24352, v_x_24360, v_hd_24354, v_k_24355});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19(V self, V *args) {
  V v_e_24352 = args[0];
  V v_a0_24353 = args[1];
  V v_hd_24354 = args[2];
  V v_k_24355 = args[3];
  V v_typ_24351 = heff_env(self)[0];
  V v_sp_24350 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24357 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam20, 1, 1, (V[]){v_a0_24353})})});
  V v_t_24358 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24357})});
  V v_t_24359 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24354, 2)), 1, (V[]){v_t_24358}));
  V f_ = heff_dup(heff_rfield(v_hd_24354, 1));
  args[0] = v_t_24359;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam21, 1, 5, (V[]){v_typ_24351, v_e_24352, v_hd_24354, v_sp_24350, v_k_24355});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18(V self, V *args) {
  V v_x_24349 = args[0];
  V v_sp_24317 = heff_env(self)[0];
  V v_k_24348 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_sp_24350 = v_sp_24317;
  V v_typ_24351 = v_x_24349;
  V f_ = v_k_24348;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam19, 4, 2, (V[]){v_typ_24351, v_sp_24350})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam17(V self, V *args) {
  V v_hd_24347 = args[0];
  V v_k_24348 = args[1];
  V v_c_24346 = heff_env(self)[0];
  V v_sp_24317 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24346;
  args[0] = v_hd_24347;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam18, 1, 2, (V[]){v_sp_24317, v_k_24348});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam24(V self, V *args) {
  V v_x_24367 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_k_24366 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_24393;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_24368 = heff_field(v_n_240, 0);
    heff_take_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_24368)) {
    case TAG_CInf: {
      V v_ru_24x11_24368_24CInf = heff_take_reuse_n(v_x11_24368, 0ULL, 1);
      v_x_24393 = ({ V a_0 = v_ru_24x11_24368_24CInf; V a_1 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CType: {
      V v_ru_24x11_24368_24CType = heff_take_reuse_n(v_x11_24368, 0ULL, 1);
      v_x_24393 = ({ V a_0 = v_ru_24x11_24368_24CType; V a_1 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CLam: {
      heff_take_n(v_x11_24368, 0ULL, 3);
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CImplicitLam: {
      heff_take_n(v_x11_24368, 0ULL, 3);
      v_x_24393 = v_x_24367;
      break;
    }
    case TAG_CAnnLam: {
      heff_take_n(v_x11_24368, 0ULL, 4);
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CTag: {
      heff_take_n(v_x11_24368, 0ULL, 3);
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CStruct: {
      V v_ru_24x11_24368_24CStruct = heff_take_reuse_n(v_x11_24368, 0ULL, 1);
      v_x_24393 = ({ V a_0 = v_ru_24x11_24368_24CStruct; V a_1 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CMatch: {
      heff_take_n(v_x11_24368, 0ULL, 2);
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CLetIn: {
      heff_take_n(v_x11_24368, 0ULL, 2);
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CLocal: {
      heff_take_n(v_x11_24368, 0ULL, 2);
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CAbandon: {
      v_x_24393 = ({ V a_0 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_x_24367); r_; });
      break;
    }
    case TAG_CNominal: {
      V v_ru_24x11_24368_24CNominal = heff_take_reuse_n(v_x11_24368, 0ULL, 1);
      v_x_24393 = ({ V a_0 = v_ru_24x11_24368_24CNominal; V a_1 = v_x_24367; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_x_24367); r_; });
      break;
    }
    default: heff_nomatch(v_x11_24368);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  V f_ = v_k_24366;
  args[0] = v_x_24393;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam23(V self, V *args) {
  V v_hd_24365 = args[0];
  V v_k_24366 = args[1];
  V v_c_24364 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24364;
  args[0] = v_hd_24365;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_lam24, 1, 2, (V[]){v_n_240, v_k_24366});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4, 2, 0};
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_t_243 = heff_field(v_x2_240, 2);
    heff_take_n(v_x2_240, 5ULL, 3);
    V v_c_244 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_243));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0, 2, 2, (V[]){v_c_244, v_x_241});
  }
  case TAG_PiImplicit: {
    V v_x_248 = heff_field(v_x2_240, 0);
    V v_sp_2410 = heff_field(v_x2_240, 2);
    V v_t_2411 = heff_field(v_x2_240, 3);
    V v_d_2412 = heff_field(v_x2_240, 4);
    heff_take_n(v_x2_240, 29ULL, 5);
    V v_c_2413 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2411));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2, 2, 4, (V[]){v_c_2413, v_d_2412, v_sp_2410, v_x_248});
  }
  case TAG_PiInstance: {
    V v_x_2431 = heff_field(v_x2_240, 0);
    V v_sp_2433 = heff_field(v_x2_240, 2);
    V v_t_2434 = heff_field(v_x2_240, 3);
    heff_take_n(v_x2_240, 13ULL, 4);
    V v_c_2435 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_t_2434));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8, 2, 3, (V[]){v_c_2435, v_sp_2433, v_x_2431});
  }
  case TAG_PiAnon: {
    V v_d_2439 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 1);
    V v_c_2440 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_d_2439));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10, 2, 1, (V[]){v_c_2440});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055(a[0]);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_Named, 2, (V[]){v_x_241, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam1, 1, 2, (V[]){v_k_246, v_x_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_c_2419 = heff_env(self)[0];
  V v_k_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427;
  switch (heff_tag_of(v_c_2419)) {
  case TAG_At: {
    V v_s_2426 = heff_field(v_c_2419, 1);
    heff_take_n(v_c_2419, 2ULL, 2);
    v_t_2427 = v_s_2426;
    break;
  }
  default: heff_nomatch(v_c_2419);
  }
  V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_chk__span, (V[]){v_x_2424, v_t_2427})});
  V f_ = v_k_2422;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_m_2420 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_m_2420}));
  return (g_co_2ebind_24s196996678x1811735276(v_t_2423, v_hd_2421, heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam6, 1, 2, (V[]){v_c_2419, v_k_2422})));
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2415 = heff_env(self)[0];
  V v_sp_2410 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_2415;
  args[0] = heff_tag_n(TAG_NamedImplicit, 4, (V[]){v_sp_2410, v_x_248, v_x_2416, v_x_2430});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_hd_2414 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  V v_sp_2410 = heff_env(self)[3];
  V v_x_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2429;
  switch (heff_tag_of(v_d_2412)) {
  case TAG_Nothing: {
    v_c_2429 = ((V)&g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam4_clo);
    break;
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_d_2412, 0);
    heff_take_n(v_d_2412, 1ULL, 1);
    V v_m_2420 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(heff_dup(v_c_2419)));
    v_c_2429 = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam5, 2, 2, (V[]){v_m_2420, v_c_2419});
    break;
  }
  default: heff_nomatch(v_d_2412);
  }
  V f_ = v_c_2429;
  heff_room[0] = v_hd_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam7, 1, 4, (V[]){v_k_2415, v_sp_2410, v_x_248, v_x_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_d_2412 = heff_env(self)[1];
  V v_sp_2410 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2413;
  args[0] = heff_dup(v_hd_2414);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam3, 1, 5, (V[]){v_d_2412, v_hd_2414, v_k_2415, v_sp_2410, v_x_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_2437 = heff_env(self)[0];
  V v_sp_2433 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2437;
  args[0] = heff_tag_n(TAG_NamedInstance, 3, (V[]){v_sp_2433, v_x_2431, v_x_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam8(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_sp_2433 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = v_hd_2436;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam9, 1, 3, (V[]){v_k_2437, v_sp_2433, v_x_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_2442 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_Anonymous, 1, (V[]){v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam10(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2440;
  args[0] = v_hd_2441;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ebinderF_24s1936032202x1002202055_lam11, 1, 1, (V[]){v_k_2442});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str0, 50, "the implicit arguments found do not fit together: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str2, 14, " are not equal");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str3, 11, "found for `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str4, 17, "`, it would need ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str5, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str6, 35, "cannot infer an implicit argument: ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str7, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str8, 24, " does not say what it is");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str9, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str10, 14, "`: give it, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str11, 9, " := ...)`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str12, 21, "what is known of it, ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str13, 3, " = ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2estuckWith_str14, 25, ", does not say what it is");
Clo g_heff_2eelab_2etoplevel_2estuckWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2estuckWith_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2estuckWith(V v_fallback_240, V v_p_241, V v_about_242, V v_left_243, V v_right_244) {
top: ;
  V v_t_245 = heff_get_n(v_p_241, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_t_245);
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str0), heff_dup(v_left_243)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str1));
    V v_t_247 = heff_strAppend(heff_strAppend(v_t_246, heff_dup(v_right_244)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str2));
    V v_t_249;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      v_t_249 = v_fallback_240;
      break;
    }
    case TAG_Just: {
      V v_me_248 = heff_dup(heff_field(v_about_242, 0));
      heff_drop(v_fallback_240);
      v_t_249 = heff_get_n(v_me_248, 5, 6);
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    V v_t_2414;
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      heff_drop(v_left_243);
      heff_drop(v_right_244);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_me_2410 = heff_field(v_about_242, 0);
      V v_ru_24about_242_24Just = heff_take_reuse_n(v_about_242, 1ULL, 1);
      V v_t_2411 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str3), heff_get_n(v_me_2410, 4, 6));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str4)), v_left_243);
      V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str5)), v_right_244);
      v_t_2414 = heff_tag_at_n(v_ru_24about_242_24Just, TAG_Just, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_about_242);
    }
    return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_247, v_t_249, v_t_2414});
  } else {
    heff_drop(v_t_245);
    switch (heff_tag_of(v_about_242)) {
    case TAG_Nothing: {
      V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str6), v_left_243), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str7));
      V v_t_2416 = heff_strAppend(heff_strAppend(v_t_2415, v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str8));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2416, v_fallback_240, NTAG(TAG_Nothing)});
    }
    case TAG_Just: {
      V v_me_2417 = heff_field(v_about_242, 0);
      heff_take_n(v_about_242, 1ULL, 1);
      heff_drop(v_fallback_240);
      V v_name_2418 = heff_take_field(v_me_2417, 4);
      V v_span_2419 = heff_get_n(v_me_2417, 5, 6);
      V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str9), heff_dup(v_name_2418)), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str10));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, v_name_2418), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str11));
      V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2estuckWith_str12), v_left_243), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str13));
      V v_t_2423 = heff_strAppend(heff_strAppend(v_t_2422, v_right_244), ((V)&g_heff_2eelab_2etoplevel_2estuckWith_str14));
      return heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(327LL), NTAG(TAG_SError), v_t_2421, v_span_2419, heff_tag_n(TAG_Just, 1, (V[]){v_t_2423})});
    }
    default: return heff_nomatch(v_about_242);
    }
  }
}
V g_heff_2eelab_2etoplevel_2estuckWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2estuckWith(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2eelabOut_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabOut_entry, 9, 0};

V g_heff_2eelab_2etoplevel_2eelabOut(V v_key_240, V v_g_241, V v_d_242, V v_isInstance_243, V v_tyStx_244, V v_mc_245, V v_x7_246, V v_z_247, V v_z_248) {
top: ;
  V v_prim_249 = heff_take_field(v_d_242, 3);
  V v_name_2410 = heff_get_n(v_d_242, 0, 4);
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Left: {
    V v_failed_2411 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_key_2412;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_key_2412 = heff_dup(v_name_2410);
    } else {
      v_key_2412 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_g_2413 = v_g_241;
    V v_k_2414;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      v_k_2414 = heff_dup(v_name_2410);
    } else {
      v_k_2414 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(v_name_2410)}));
    }
    heff_drop(v_k_2414);
    V v_tyStx_2415 = v_tyStx_244;
    HeffT2 v_t_2416 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_2413), NTAG(TAG_N), heff_dup(v_tyStx_2415), NTAG(TAG_LNil)));
    V v_t_2424;
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      V v_a_2422;
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_x_2419 = v_field_2418;
        v_a_2422 = v_x_2419;
      } else {
        if ((v_tag_2417 == ((int64_t)1ULL))) {
          V v_x11_2420 = v_field_2418;
          heff_drop(v_x11_2420);
          v_a_2422 = heff_abandon();
        } else {
          V v_x_2421 = v_field_2418;
          v_a_2422 = v_x_2421;
        }
      }
      v_t_2424 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabOut_lam0, 1, 1, (V[]){v_a_2422}), NTAG(TAG_Nothing)));
    }
    HeffT2 v_t_2425 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_2413, NTAG(TAG_N), heff_dup(v_tyStx_2415), NTAG(TAG_LNil)));
    V v_t_2431;
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      if ((v_tag_2426 == ((int64_t)0ULL))) {
        V v_x_2428 = v_field_2427;
        v_t_2431 = v_x_2428;
      } else {
        if ((v_tag_2426 == ((int64_t)1ULL))) {
          V v_x11_2429 = v_field_2427;
          heff_drop(v_x11_2429);
          v_t_2431 = heff_abandon();
        } else {
          V v_x_2430 = v_field_2427;
          v_t_2431 = v_x_2430;
        }
      }
    }
    V v_entry_2432 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SAbandon), v_tyStx_2415, v_t_2424, v_t_2431});
    V v_t_2433 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_2410, v_key_2412, v_prim_249, v_isInstance_243, v_entry_2432, heff_tag_n(TAG_Just, 1, (V[]){v_failed_2411})});
    return heff_tail(v_z_248, 1, (V[]){v_t_2433});
  }
  case TAG_Right: {
    V v_t_2434 = heff_field(v_x7_246, 0);
    heff_take_n(v_x7_246, 1ULL, 1);
    V v_key_2435;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_key_2435 = heff_dup(v_name_2410);
    } else {
      v_key_2435 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_t_2436;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      v_t_2436 = heff_dup(v_name_2410);
    } else {
      v_t_2436 = heff_tr(heff_call(heff_dup(v_key_240), 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_k_2437;
    if ((heff_dup(v_prim_249) == NTAG(TAG_True))) {
      heff_drop(v_key_240);
      v_k_2437 = heff_dup(v_name_2410);
    } else {
      v_k_2437 = heff_tr(heff_call(v_key_240, 1, (V[]){heff_dup(v_name_2410)}));
    }
    V v_t_2438 = (g_heff_2eelab_2eunify_2ezonker(v_mc_245));
    V v_t_2439 = heff_tr(heff_call(heff_get_n(v_t_2438, 0, 2), 1, (V[]){heff_get_n(v_t_2434, 0, 2)}));
    V v_t_2440 = ({ V a_0 = v_k_2437; V r_ = (g_heff_2eelab_2etoplevel_2eselfWalk(a_0)); heff_drop(v_k_2437); r_; });
    V v_t_2441 = heff_tr(heff_call(heff_get_n(v_t_2440, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2439}));
    V v_entry_2442 = (g_heff_2eelab_2etoplevel_2eentryFor(v_g_241, v_t_2436, v_prim_249, v_tyStx_244, v_t_2441));
    V v_t_2443 = heff_rec_n(6, shape_name__key__prim__isInstance__entry__failed, (V[]){v_name_2410, v_key_2435, v_prim_249, v_isInstance_243, v_entry_2442, NTAG(TAG_Nothing)});
    return heff_tail(v_z_248, 1, (V[]){v_t_2443});
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabOut_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a7 = a[7]; V r = g_heff_2eelab_2etoplevel_2eelabOut(a[0], a[1], a[2], a[3], a[4], a5, a[6], a7, a[8]); heff_drop(a5); heff_drop(a7); return r;
}
V g_heff_2eelab_2etoplevel_2eelabOut_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_a_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2423);
  return v_a_2422;
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam16(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_entry, 6, 0};

V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243, V v_p_244, V v_p_245) {
top: ;
  V v_x1_246 = (g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(v_eqs_242));
  if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
    heff_drop(v_x1_246);
    V v_n_249;
    switch (heff_tag_of(v_tyN_241)) {
    case TAG_At: {
      V v_n_247 = heff_field(v_tyN_241, 0);
      V v_sp_248 = heff_field(v_tyN_241, 1);
      v_n_249 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_248), heff_dup(v_n_247)));
      break;
    }
    default: heff_nomatch(v_tyN_241);
    }
    V v_t_2410 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_249));
    return heff_tail(v_t_2410, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam0, 1, 4, (V[]){v_name_240, v_eqs_242, v_sp_243, v_p_244}), v_p_245});
  } else {
    heff_drop(v_x1_246);
    V v_name_2470 = heff_dup(v_name_240);
    V v_args_2471 = NTAG(TAG_Nil);
    V v_eqs_2472 = v_eqs_242;
    V v_sp_2473 = v_sp_243;
    V v_p_2481 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam14, 1, 3, (V[]){heff_dup(v_tyN_241), v_name_240, v_p_244});
    V v_p_2482 = v_p_245;
    V v_t_2483 = (g_heff_2eelab_2etoplevel_2eexplicitNames(v_args_2471));
    HeffT2 v_t_2484 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_name_2470, v_t_2483, heff_dup(v_eqs_2472), v_sp_2473));
    {
      V v_field_2486 = v_t_2484.f[1];
      int64_t v_tag_2485 = ((int64_t)v_t_2484.f[0]);
      if ((v_tag_2485 == ((int64_t)0ULL))) {
        heff_drop(v_eqs_2472);
        heff_drop_clo(v_p_2481, 3);
        V v_err_2487 = v_field_2486;
        V v_msg_2488 = heff_take_field(v_err_2487, 1);
        V v_span_2489 = heff_get_n(v_err_2487, 0, 2);
        V v_t_2490 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), v_msg_2488, v_span_2489, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2490}), v_p_2482});
      } else {
        V v_b_2491 = v_field_2486;
        V v_t_2492 = (g_prelude_2etraverse_24s1778157750x1229378888(heff_dup(v_eqs_2472)));
        V v_t_2493 = ({ V a_0 = v_eqs_2472; V a_1 = v_t_2492; V r_ = (g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656(a_0, a_1)); heff_drop(v_eqs_2472); r_; });
        V v_t_2494 = (g_list_2emap_24s2098521682x1221164629(v_t_2493));
        return (g_heff_2eelab_2eenvironment_2eseeArms_24s2030711793x1858989566(v_t_2494, heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam16, 2, 2, (V[]){v_b_2491, v_p_2481}), v_p_2482));
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam3(V self, V *args) {
  V v_m_2421 = args[0];
  V v_e_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2412, 1, 6), v_m_2421));
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_f_2417 = heff_env(self)[0];
  V v_fsp_2418 = heff_env(self)[1];
  V v_rhs_2420 = heff_env(self)[2];
  V v_sp_2416 = heff_env(self)[3];
  V v_k_2424 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2417, v_fsp_2418, v_x_2425, v_rhs_2420}), v_sp_2416});
  V f_ = v_k_2424;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam4(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_f_2417 = heff_env(self)[1];
  V v_fsp_2418 = heff_env(self)[2];
  V v_rhs_2420 = heff_env(self)[3];
  V v_sp_2416 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam5, 1, 5, (V[]){v_f_2417, v_fsp_2418, v_rhs_2420, v_sp_2416, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam2(V self, V *args) {
  V v_m_2414 = args[0];
  V v_e_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2414)) {
  case TAG_At: {
    V v_x21_2415 = heff_field(v_m_2414, 0);
    V v_sp_2416 = heff_field(v_m_2414, 1);
    heff_take_n(v_m_2414, 3ULL, 2);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_MkEquation: {
      V v_f_2417 = heff_field(v_x21_2415, 0);
      V v_fsp_2418 = heff_field(v_x21_2415, 1);
      V v_ps_2419 = heff_field(v_x21_2415, 2);
      V v_rhs_2420 = heff_field(v_x21_2415, 3);
      heff_take_n(v_x21_2415, 15ULL, 4);
      V v_c_2422 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam3, 1, 1, (V[]){v_e_2412}), v_ps_2419));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam4, 2, 5, (V[]){v_c_2422, v_f_2417, v_fsp_2418, v_rhs_2420, v_sp_2416});
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  default: return heff_nomatch(v_m_2414);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam8(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_msg_2442 = heff_env(self)[0];
  V v_span_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2445 = heff_take_field(v_hd_2443, 1);
  V v_malg_2446 = heff_get_n(v_hd_2443, 2, 3);
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), v_msg_2442, v_span_2441, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(v_malg_2446, 1, (V[]){v_t_2449}));
  V f_ = v_bind_2445;
  args[0] = v_t_2450;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam9(V self, V *args) {
  V v_hd_2452 = args[0];
  V v_k_2453 = args[1];
  V v_b_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2452);
  V f_ = v_k_2453;
  args[0] = v_b_2451;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam12(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2457 = heff_env(self)[0];
  V v_hd_2455 = heff_env(self)[1];
  V v_k_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2461);
  V v_n_2464;
  switch (heff_tag_of(v_x_2457)) {
  case TAG_At: {
    V v_n_2462 = heff_field(v_x_2457, 0);
    V v_sp_2463 = heff_field(v_x_2457, 1);
    heff_take_n(v_x_2457, 3ULL, 2);
    v_n_2464 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2463, v_n_2462));
    break;
  }
  default: heff_nomatch(v_x_2457);
  }
  V v_t_2465 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2464));
  V f_ = v_t_2465;
  heff_room[0] = v_hd_2455;
  heff_room[1] = v_k_2456;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam11(V self, V *args) {
  V v_x_2457 = args[0];
  V v_eqs_2433 = heff_env(self)[0];
  V v_hd_2455 = heff_env(self)[1];
  V v_k_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2458 = (g_prelude_2etraverse_24s1778157750x1229378888(heff_dup(v_eqs_2433)));
  V v_t_2459 = ({ V a_0 = v_eqs_2433; V a_1 = v_t_2458; V r_ = (g_heff_2eelab_2eclauses_2eunreachedAt_24s1178550131x120453656(a_0, a_1)); heff_drop(v_eqs_2433); r_; });
  V v_t_2460 = (g_list_2emap_24s2098521682x1221164629(v_t_2459));
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_2460, heff_dup(v_hd_2455), heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam12, 1, 3, (V[]){v_x_2457, v_hd_2455, v_k_2456})));
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam10(V self, V *args) {
  V v_hd_2455 = args[0];
  V v_k_2456 = args[1];
  V v_c_2454 = heff_env(self)[0];
  V v_eqs_2433 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2454;
  args[0] = heff_dup(v_hd_2455);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam11, 1, 3, (V[]){v_eqs_2433, v_hd_2455, v_k_2456});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam13(V self, V *args) {
  V v_x_2467 = args[0];
  V v_e_2412 = heff_env(self)[0];
  V v_a_2413 = heff_env(self)[1];
  V v_hd_2428 = heff_env(self)[2];
  V v_k_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkChk: {
    V v_f_2468 = heff_field(v_x_2467, 0);
    heff_take_n(v_x_2467, 1ULL, 1);
    V f_ = v_f_2468;
    heff_room[0] = v_e_2412;
    heff_room[1] = v_a_2413;
    heff_room[2] = v_hd_2428;
    heff_room[3] = v_k_2429;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2467);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_hd_2428 = heff_env(self)[2];
  V v_e_2412 = heff_env(self)[3];
  V v_a_2413 = heff_env(self)[4];
  V v_k_2429 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_name_2431 = v_name_240;
  V v_args_2432 = NTAG(TAG_Nil);
  V v_eqs_2433 = v_x_2430;
  V v_sp_2434 = v_sp_243;
  V v_t_2435 = (g_heff_2eelab_2etoplevel_2eexplicitNames(v_args_2432));
  HeffT2 v_t_2436 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_name_2431, v_t_2435, heff_dup(v_eqs_2433), v_sp_2434));
  V v_c_2454;
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      V v_err_2439 = v_field_2438;
      V v_msg_2440 = heff_take_field(v_err_2439, 1);
      V v_span_2441 = heff_get_n(v_err_2439, 0, 2);
      V v_msg_2442 = v_msg_2440;
      v_c_2454 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam8, 2, 2, (V[]){v_msg_2442, v_span_2441});
    } else {
      V v_b_2451 = v_field_2438;
      v_c_2454 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam9, 2, 1, (V[]){v_b_2451});
    }
  }
  V v_c_2466 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam10, 2, 2, (V[]){v_c_2454, v_eqs_2433});
  V f_ = v_c_2466;
  heff_room[0] = heff_dup(v_hd_2428);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam13, 1, 4, (V[]){v_e_2412, v_a_2413, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_e_2412 = heff_env(self)[3];
  V v_a_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam7, 1, 6, (V[]){v_name_240, v_sp_243, v_hd_2428, v_e_2412, v_a_2413, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam1(V self, V *args) {
  V v_e_2412 = args[0];
  V v_a_2413 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2427 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam2, 1, 1, (V[]){heff_dup(v_e_2412)}), v_eqs_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam6, 2, 5, (V[]){v_c_2427, v_name_240, v_sp_243, v_e_2412, v_a_2413});
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_eqs_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2469 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_name_240), v_x_2411, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam1, 2, 3, (V[]){v_eqs_242, v_name_240, v_sp_243})}), NTAG(TAG_False)});
  V f_ = v_p_244;
  args[0] = v_t_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam15(V self, V *args) {
  V v_x_2479 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2480 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_x_2479, v_x_2474, NTAG(TAG_False)});
  V f_ = v_p_244;
  args[0] = v_t_2480;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam14(V self, V *args) {
  V v_x_2474 = args[0];
  V v_tyN_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_n_2477;
  switch (heff_tag_of(v_tyN_241)) {
  case TAG_At: {
    V v_n_2475 = heff_field(v_tyN_241, 0);
    V v_sp_2476 = heff_field(v_tyN_241, 1);
    V v_ru_24tyN_241_24At = heff_take_reuse_n(v_tyN_241, 3ULL, 2);
    v_n_2477 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24tyN_241_24At, v_sp_2476, v_n_2475));
    break;
  }
  default: heff_nomatch(v_tyN_241);
  }
  V v_t_2478 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2477));
  V f_ = v_t_2478;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam15, 1, 3, (V[]){v_name_240, v_x_2474, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338_lam16(V self, V *args) {
  V v_x_2495 = args[0];
  V v_z_2496 = args[1];
  V v_b_2491 = heff_env(self)[0];
  V v_p_2481 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_n_2499;
  switch (heff_tag_of(v_b_2491)) {
  case TAG_At: {
    V v_n_2497 = heff_field(v_b_2491, 0);
    V v_sp_2498 = heff_field(v_b_2491, 1);
    heff_take_n(v_b_2491, 3ULL, 2);
    v_n_2499 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2498, v_n_2497));
    break;
  }
  default: heff_nomatch(v_b_2491);
  }
  V v_t_24100 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2499));
  V f_ = v_t_24100;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = v_p_2481;
  heff_room[2] = v_z_2496;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_str0, 45, "unexpected notation for top-level declaration");
HEFF_LIT(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_str1, 45, "unexpected notation for top-level declaration");
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam5(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam5, 3, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam9(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam9, 1, 0};
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam7(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(V v_d_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_At: {
    V v_d1_243 = heff_dup(heff_field(v_d_240, 0));
    switch (heff_tag_of(v_d1_243)) {
    case TAG_DeclEquations: {
      V v_name_245 = heff_field(v_d1_243, 0);
      V v_tyN_248 = heff_field(v_d1_243, 3);
      V v_eqs_249 = heff_field(v_d1_243, 4);
      heff_take_n(v_d1_243, 25ULL, 5);
      V v_t_2412;
      switch (heff_tag_of(v_tyN_248)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_tyN_248, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_tyN_248);
      }
      V v_t_2415;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_d_240, 1);
        heff_take_n(v_d_240, 2ULL, 2);
        v_t_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_2416 = ({ V rv_1 = heff_get_n(v_t_2415, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2412, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      return ({ V a_0 = v_name_245; V a_1 = v_tyN_248; V a_2 = v_eqs_249; V a_3 = v_t_2416; V a_4 = v_p_241; V a_5 = v_p_242; V r_ = (g_heff_2eelab_2etoplevel_2eequationsD_24s943299625x585026338(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_tyN_248); r_; });
    }
    case TAG_DeclDefine: {
      V v_name_2417 = heff_field(v_d1_243, 0);
      V v_params_2419 = heff_field(v_d1_243, 2);
      V v_tyN_2420 = heff_field(v_d1_243, 3);
      V v_bodyN_2421 = heff_field(v_d1_243, 4);
      heff_take_n(v_d1_243, 29ULL, 5);
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_ru_24d_240_24At = heff_take_reuse_n(v_d_240, 0ULL, 2);
        V v_name_2424 = v_name_2417;
        V v_params_2425 = v_params_2419;
        V v_tyN_2426 = v_tyN_2420;
        V v_bodyN_2427 = v_bodyN_2421;
        V v_p_2428 = v_p_241;
        V v_p_2429 = v_p_242;
        return (g_prelude_2etraverse_24s1963041714x1343204084_24tok2(v_ru_24d_240_24At, v_params_2425, heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam0, 1, 4, (V[]){v_tyN_2426, v_bodyN_2427, v_name_2424, v_p_2428}), v_p_2429));
      }
      default: return heff_nomatch(v_d_240);
      }
    }
    case TAG_DeclTheory: {
      V v_name_2445 = heff_field(v_d1_243, 0);
      V v_params_2447 = heff_field(v_d1_243, 2);
      V v_bodyN_2448 = heff_field(v_d1_243, 3);
      heff_take_n(v_d1_243, 13ULL, 4);
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_ru_24d_240_24At = heff_take_reuse_n(v_d_240, 0ULL, 2);
        V v_name_2451 = v_name_2445;
        V v_params_2452 = v_params_2447;
        V v_bodyN_2453 = v_bodyN_2448;
        V v_p_2454 = v_p_241;
        V v_p_2455 = v_p_242;
        return (g_prelude_2etraverse_24s1963041714x1343204084_24tok2(v_ru_24d_240_24At, v_params_2452, heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam3, 1, 3, (V[]){v_bodyN_2453, v_name_2451, v_p_2454}), v_p_2455));
      }
      default: return heff_nomatch(v_d_240);
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_2473 = heff_field(v_d1_243, 0);
      V v_tyN_2475 = heff_field(v_d1_243, 2);
      heff_take_n(v_d1_243, 5ULL, 3);
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_ru_24d_240_24At = heff_take_reuse_n(v_d_240, 0ULL, 2);
        V v_n_2480;
        switch (heff_tag_of(v_tyN_2475)) {
        case TAG_At: {
          V v_n_2478 = heff_field(v_tyN_2475, 0);
          V v_sp_2479 = heff_field(v_tyN_2475, 1);
          heff_take_n(v_tyN_2475, 3ULL, 2);
          v_n_2480 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24d_240_24At, v_sp_2479, v_n_2478));
          break;
        }
        default: heff_nomatch(v_tyN_2475);
        }
        V v_t_2481 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2480));
        return heff_tail(v_t_2481, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam7, 1, 2, (V[]){v_x_2473, v_p_241}), v_p_242});
      }
      default: return heff_nomatch(v_d_240);
      }
    }
    case TAG_DeclTest: {
      V v_ru_24d1_243_24DeclTest = heff_take_reuse_n(v_d1_243, 0ULL, 2);
      heff_drop(v_p_241);
      V v_t_2499;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_2498 = heff_field(v_d_240, 1);
        heff_take_n(v_d_240, 2ULL, 2);
        v_t_2499 = v_s_2498;
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_24100 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_str0), v_t_2499, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24d1_243_24DeclTest, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24100}), v_p_242});
    }
    case TAG_DeclWatch: {
      V v_ru_24d1_243_24DeclWatch = heff_take_reuse_n(v_d1_243, 0ULL, 1);
      heff_drop(v_p_241);
      V v_t_24104;
      switch (heff_tag_of(v_d_240)) {
      case TAG_At: {
        V v_s_24103 = heff_field(v_d_240, 1);
        heff_take_n(v_d_240, 2ULL, 2);
        v_t_24104 = v_s_24103;
        break;
      }
      default: heff_nomatch(v_d_240);
      }
      V v_t_24105 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_str1), v_t_24104, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24d1_243_24DeclWatch, TAG_Left, 1, (V[]){v_t_24105}), v_p_242});
    }
    default: return heff_nomatch(v_d1_243);
    }
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam2(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_name_2424 = heff_env(self)[2];
  V v_p_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2441 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_x_2430, heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2435, v_x_2440})));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_ty_2442 = heff_field(v_x2_2441, 0);
    V v_tm_2443 = heff_field(v_x2_2441, 1);
    heff_take_n(v_x2_2441, 3ULL, 2);
    V v_t_2444 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_2424, v_ty_2442, v_tm_2443, NTAG(TAG_False)});
    V f_ = v_p_2428;
    args[0] = v_t_2444;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam1(V self, V *args) {
  V v_x_2435 = args[0];
  V v_bodyN_2427 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_name_2424 = heff_env(self)[2];
  V v_p_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2438;
  switch (heff_tag_of(v_bodyN_2427)) {
  case TAG_At: {
    V v_n_2436 = heff_field(v_bodyN_2427, 0);
    V v_sp_2437 = heff_field(v_bodyN_2427, 1);
    heff_take_n(v_bodyN_2427, 3ULL, 2);
    v_n_2438 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2437, v_n_2436));
    break;
  }
  default: heff_nomatch(v_bodyN_2427);
  }
  V v_t_2439 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2438));
  V f_ = v_t_2439;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam2, 1, 4, (V[]){v_x_2430, v_x_2435, v_name_2424, v_p_2428});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam0(V self, V *args) {
  V v_x_2430 = args[0];
  V v_tyN_2426 = heff_env(self)[0];
  V v_bodyN_2427 = heff_env(self)[1];
  V v_name_2424 = heff_env(self)[2];
  V v_p_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2433;
  switch (heff_tag_of(v_tyN_2426)) {
  case TAG_At: {
    V v_n_2431 = heff_field(v_tyN_2426, 0);
    V v_sp_2432 = heff_field(v_tyN_2426, 1);
    V v_ru_24tyN_2426_24At = heff_take_reuse_n(v_tyN_2426, 3ULL, 2);
    v_n_2433 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24tyN_2426_24At, v_sp_2432, v_n_2431));
    break;
  }
  default: heff_nomatch(v_tyN_2426);
  }
  V v_t_2434 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2433));
  V f_ = v_t_2434;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam1, 1, 4, (V[]){v_bodyN_2427, v_x_2430, v_name_2424, v_p_2428});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam6(V self, V *args) {
  V v_u2_2466 = args[0];
  heff_drop(v_u2_2466);
  V v_t_2467 = heff_tag_n(TAG_VU, 1, (V[]){NTAG(TAG_LargeU)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2467});
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam5(V self, V *args) {
  V v_e_2462 = args[0];
  V v_hd_2463 = args[1];
  V v_k_2464 = args[2];
  heff_drop(v_e_2462);
  heff_drop(v_hd_2463);
  V v_t_2465 = heff_tag_n(TAG_SU, 1, (V[]){NTAG(TAG_LargeU)});
  V f_ = v_k_2464;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2465, ((V)&g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam6_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam4(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2456 = heff_env(self)[0];
  V v_name_2451 = heff_env(self)[1];
  V v_p_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2468 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam5_clo)}), v_x_2461});
  V v_x2_2469 = (g_heff_2eelab_2etoplevel_2ewithArgs(v_x_2456, v_t_2468));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_MkPair: {
    V v_ty_2470 = heff_field(v_x2_2469, 0);
    V v_tm_2471 = heff_field(v_x2_2469, 1);
    heff_take_n(v_x2_2469, 3ULL, 2);
    V v_t_2472 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_2451, v_ty_2470, v_tm_2471, NTAG(TAG_False)});
    V f_ = v_p_2454;
    args[0] = v_t_2472;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam3(V self, V *args) {
  V v_x_2456 = args[0];
  V v_bodyN_2453 = heff_env(self)[0];
  V v_name_2451 = heff_env(self)[1];
  V v_p_2454 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_n_2459;
  switch (heff_tag_of(v_bodyN_2453)) {
  case TAG_At: {
    V v_n_2457 = heff_field(v_bodyN_2453, 0);
    V v_sp_2458 = heff_field(v_bodyN_2453, 1);
    heff_take_n(v_bodyN_2453, 3ULL, 2);
    v_n_2459 = (g_heff_2esyntax_2epresyntax_2echkDe_24s1336068923x650570599(v_sp_2458, v_n_2457));
    break;
  }
  default: heff_nomatch(v_bodyN_2453);
  }
  V v_t_2460 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_n_2459));
  V f_ = v_t_2460;
  heff_room[0] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam4, 1, 3, (V[]){v_x_2456, v_name_2451, v_p_2454});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam9(V self, V *args) {
  V v_u_2490 = args[0];
  heff_drop(v_u_2490);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam10(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_x_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2492);
  V f_ = v_k_2493;
  args[0] = v_x_2491;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam8(V self, V *args) {
  V v_e_2483 = args[0];
  V v_a_2484 = args[1];
  V v_x_2473 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e_2483);
  heff_drop(v_a_2484);
  HeffT2 v_t_2485 = ({ V b_0 = heff_dup(g_heff_2eelab_2eprimitive_2elibraryTable_get()); V a_1 = v_x_2473; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_x_2473); r_; });
  V v_t_2489;
  {
    V v_field_2487 = v_t_2485.f[1];
    int64_t v_tag_2486 = ((int64_t)v_t_2485.f[0]);
    if ((v_tag_2486 == ((int64_t)0ULL))) {
      V v_x_2488 = v_field_2487;
      v_t_2489 = heff_tag_n(TAG_SPrim, 1, (V[]){v_x_2488});
    } else {
      heff_drop(v_field_2487);
      v_t_2489 = NTAG(TAG_SOpaque);
    }
  }
  V v_x_2491 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2489, ((V)&g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam9_clo)});
  return heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam10, 2, 1, (V[]){v_x_2491});
}
V g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam7(V self, V *args) {
  V v_x_2482 = args[0];
  V v_x_2473 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2494 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){heff_dup(v_x_2473), v_x_2482, heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2edeclJ_24s533170965x111765980_lam8, 2, 1, (V[]){v_x_2473})}), NTAG(TAG_True)});
  V f_ = v_p_241;
  args[0] = v_t_2494;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2etoplevel_2eisPrimB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eisPrimB_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eisPrimB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return NTAG(TAG_False);
  }
  case TAG_SGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    return NTAG(TAG_False);
  }
  case TAG_SApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLam: {
    return NTAG(TAG_False);
  }
  case TAG_SCons: {
    return NTAG(TAG_False);
  }
  case TAG_SProj: {
    return NTAG(TAG_False);
  }
  case TAG_STag: {
    return NTAG(TAG_False);
  }
  case TAG_SMatch: {
    return NTAG(TAG_False);
  }
  case TAG_SSpecialize: {
    return NTAG(TAG_False);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    return NTAG(TAG_False);
  }
  case TAG_SFix: {
    return NTAG(TAG_False);
  }
  case TAG_SImplicit: {
    return NTAG(TAG_False);
  }
  case TAG_SPrim: {
    return NTAG(TAG_True);
  }
  case TAG_SMetaApp: {
    return NTAG(TAG_False);
  }
  case TAG_SLitInt: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eisPrimB_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eisPrimB(a0); heff_drop(a0); return r;
}