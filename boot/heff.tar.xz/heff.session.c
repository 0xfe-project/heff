// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2esession_2ecacheDir_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 104, 101, 102, 102}};
Clo g_heff_2esession_2ecacheDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecacheDir_entry, 1, 0};

V g_heff_2esession_2ecacheDir(V v_ps_240) {
top: ;
  V v_st_241 = heff_get(heff_dup(v_ps_240), LBL_style);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get(heff_dup(v_ps_240), LBL_root)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2esession_2ecacheDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = ({ V a_0 = heff_get(heff_dup(v_p_244), LBL_absolute); V b_1 = heff_get(heff_dup(v_p_244), LBL_segments); V r_ = (g_std_2epath_2ecollapse(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_246 = heff_rec(3, shape_73_1_293, (V[]){heff_get(heff_dup(v_p_244), LBL_drive), heff_get(v_p_244, LBL_absolute), v_t_245});
  V v_t_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  return (g_heff_2eload_2eunder(v_ps_240, v_t_247, heff_dup(g_heff_2ecache_2eversionDir_get())));
}
V g_heff_2esession_2ecacheDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2esession_2ecacheDir(a[0]);
}
V g_heff_2esession_2ecacheKeep_lam0(V self, V *args);
Clo g_heff_2esession_2ecacheKeep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecacheKeep_entry, 3, 0};

V g_heff_2esession_2ecacheKeep(V v_acc_240, V v_th_241, V v_c_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_c_242), NTAG(TAG_Nil)});
  V v_t_244 = (g_prelude_2econcatList(heff_get(heff_dup(v_acc_240), LBL_done), v_t_243));
  V v_t_2410;
  switch (heff_tag_of(v_th_241)) {
  case TAG_Nothing: {
    V v_t_247 = ({ V a_0 = heff_clo(g_heff_2esession_2ecacheKeep_lam0, 2, 1, (V[]){heff_dup(v_c_242)}); V a_1 = heff_get(v_acc_240, LBL_hashes); V b_2 = heff_get(heff_dup(v_c_242), LBL_own); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    v_t_2410 = (g_heff_2ecache_2ewholeHash(v_t_247, v_c_242));
    break;
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_th_241, 0);
    V v_t_249 = ({ V a_0 = heff_get(v_acc_240, LBL_hashes); V b_1 = heff_get(heff_dup(v_t_248), LBL_hashes); V r_ = (g_prelude_2efoldl_24s786(a_0, b_1)); heff_drop(b_1); r_; });
    v_t_2410 = (g_heff_2ecache_2ewholeHash(v_t_249, v_c_242));
    break;
  }
  default: heff_nomatch(v_th_241);
  }
  return heff_rec(2, shape_71_122, (V[]){v_t_244, v_t_2410});
}
V g_heff_2esession_2ecacheKeep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esession_2ecacheKeep(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2esession_2ecacheKeep_lam0(V self, V *args) {
  V v_m_245 = args[0];
  V v_o_246 = args[1];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecache_2edefHashOne(v_m_245, v_c_242, v_o_246));
}
Clo g_heff_2esession_2ecacheStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecacheStep_entry, 3, 0};

V g_heff_2esession_2ecacheStep(V v_acc_240, V v_s_241, V v_th_242) {
top: ;
  V v_done_243 = heff_get(heff_dup(v_acc_240), LBL_done);
  V v_imps_244 = (g_heff_2edriver_2eimportsOfSource(heff_dup(v_s_241)));
  V v_t_245 = (g_prelude_2emap_24s426(heff_get(heff_dup(v_imps_244), LBL_imports)));
  V v_ms_246 = (g_heff_2edriver_2enubStrD(v_t_245));
  V v_t_247 = (g_heff_2edriver_2eclosureGo(v_done_243, NTAG(TAG_Nil), v_ms_246));
  V v_t_248 = ({ V a_0 = v_done_243; V a_1 = v_s_241; V a_2 = v_imps_244; V a_3 = v_th_242; V a_4 = v_t_247; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
  HEFF_LAST return g_heff_2esession_2ecacheKeep(v_acc_240, v_th_242, v_t_248);
}
V g_heff_2esession_2ecacheStep_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esession_2ecacheStep(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esession_2ecacheStepLean_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecacheStepLean_entry, 3, 0};

V g_heff_2esession_2ecacheStepLean(V v_acc_240, V v_s_241, V v_th_242) {
top: ;
  V v_done_243 = heff_get(heff_dup(v_acc_240), LBL_done);
  V v_imps_244 = (g_heff_2edriver_2eimportsOfSource(heff_dup(v_s_241)));
  V v_t_245 = (g_prelude_2emap_24s426(heff_get(heff_dup(v_imps_244), LBL_imports)));
  V v_ms_246 = (g_heff_2edriver_2enubStrD(v_t_245));
  V v_t_247 = (g_heff_2edriver_2eclosureGo(v_done_243, NTAG(TAG_Nil), v_ms_246));
  V v_t_248 = ({ V a_0 = v_done_243; V a_1 = v_s_241; V a_2 = v_imps_244; V a_3 = v_th_242; V a_4 = v_t_247; V r_ = (g_heff_2edriver_2eelabNeeding(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_247); r_; });
  V v_t_249 = (g_heff_2edriver_2elean(v_t_248));
  HEFF_LAST return g_heff_2esession_2ecacheKeep(v_acc_240, v_th_242, v_t_249);
}
V g_heff_2esession_2ecacheStepLean_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esession_2ecacheStepLean(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2esession_2ezipSC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ezipSC_entry, 2, 0};

V g_heff_2esession_2ezipSC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_ss_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_s_242);
      heff_drop(v_ss_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_c_244 = heff_field(v_x2_241, 0);
      V v_cs_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_s_242, v_c_244}), (g_heff_2esession_2ezipSC(v_ss_243, v_cs_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esession_2ezipSC_entry(V self, V *a) {
  (void)self;
  return g_heff_2esession_2ezipSC(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2esession_2ethawTry_24s890_24s1122_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 99}};
V g_heff_2esession_2ethawTry_24s890_24s1122_lam1(V self, V *args); static Clo g_heff_2esession_2ethawTry_24s890_24s1122_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ethawTry_24s890_24s1122_lam1, 1, 0};
V g_heff_2esession_2ethawTry_24s890_24s1122_lam0(V self, V *args);
V g_heff_2esession_2ethawTry_24s890_24s1122_lam3(V self, V *args);
V g_heff_2esession_2ethawTry_24s890_24s1122_lam2(V self, V *args);
Clo g_heff_2esession_2ethawTry_24s890_24s1122_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ethawTry_24s890_24s1122_entry, 3, 0};

V g_heff_2esession_2ethawTry_24s890_24s1122(V v_ps_240, V v_s_241, V v_acc_242) {
top: ;
  V v_t_243 = (g_heff_2esession_2ecacheDir(heff_dup(v_ps_240)));
  V v_t_244 = heff_strAppend(heff_get(heff_dup(v_s_241), LBL_module), ((V)&g_heff_2esession_2ethawTry_24s890_24s1122_str0));
  V v_path_245 = (g_heff_2eload_2eunder(v_ps_240, v_t_243, v_t_244));
  V v_c_2413 = heff_clo(g_heff_2esession_2ethawTry_24s890_24s1122_lam0, 2, 1, (V[]){v_path_245});
  return heff_clo(g_heff_2esession_2ethawTry_24s890_24s1122_lam2, 2, 3, (V[]){v_c_2413, v_acc_242, v_s_241});
}
V g_heff_2esession_2ethawTry_24s890_24s1122_entry(V self, V *a) {
  (void)self;
  return g_heff_2esession_2ethawTry_24s890_24s1122(a[0], a[1], a[2]);
}
V g_heff_2esession_2ethawTry_24s890_24s1122_lam1(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2esession_2ethawTry_24s890_24s1122_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k2_247 = args[1];
  V v_path_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_ReadFile, 2, (V[]){v_path_245, ((V)&g_heff_2esession_2ethawTry_24s890_24s1122_lam1_clo)})});
  V v_t_2410 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_246), LBL_malg), 1, (V[]){v_t_2411}));
  V f_ = heff_get(v_hd_246, LBL_bind);
  args[0] = v_t_2412;
  args[1] = v_k2_247;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esession_2ethawTry_24s890_24s1122_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x_2418;
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_acc_242);
    heff_drop(v_s_241);
    v_x_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_txt_2417 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    v_x_2418 = ({ V b_0 = heff_get(heff_dup(v_acc_242), LBL_hashes); V b_1 = heff_get(v_acc_242, LBL_done); V a_2 = v_s_241; V a_3 = v_txt_2417; V r_ = (g_heff_2ecache_2emelt(b_0, b_1, a_2, a_3)); heff_drop(b_0); heff_drop(b_1); r_; });
    break;
  }
  default: heff_nomatch(v_x_2416);
  }
  V f_ = v_k_2415;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2ethawTry_24s890_24s1122_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo(g_heff_2esession_2ethawTry_24s890_24s1122_lam3, 1, 3, (V[]){v_acc_242, v_s_241, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam0(V self, V *args);
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam1(V self, V *args);
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam3(V self, V *args);
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam2(V self, V *args);
Clo g_heff_2esession_2ecachedGo_24s889_24s1121_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecachedGo_24s889_24s1121_entry, 3, 0};

V g_heff_2esession_2ecachedGo_24s889_24s1121(V v_ps_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    return heff_clo(g_heff_2esession_2ecachedGo_24s889_24s1121_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x2_241, 0);
    V v_x22_246 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_246)) {
    case TAG_Nil: {
      heff_drop(v_ps_240);
      V v_x_247 = ({ V a_0 = v_acc_242; V a_1 = heff_dup(v_s_245); V b_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2esession_2ecacheStep(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      return heff_clo(g_heff_2esession_2ecachedGo_24s889_24s1121_lam1, 2, 1, (V[]){v_x_247});
    }
    case TAG_Cons: {
      V v_c_2412 = (g_heff_2esession_2ethawTry_24s890_24s1122(heff_dup(v_ps_240), heff_dup(v_s_245), heff_dup(v_acc_242)));
      return heff_clo(g_heff_2esession_2ecachedGo_24s889_24s1121_lam2, 2, 5, (V[]){v_c_2412, v_acc_242, heff_dup(v_s_245), v_ps_240, heff_dup(v_x22_246)});
    }
    default: return heff_nomatch(v_x22_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esession_2ecachedGo_24s889_24s1121_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esession_2ecachedGo_24s889_24s1121(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_x22_246 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = ({ V a_0 = v_acc_242; V a_1 = v_s_245; V a_2 = v_x_2415; V r_ = (g_heff_2esession_2ecacheStepLean(a_0, a_1, a_2)); heff_drop(v_x_2415); r_; });
  V v_t_2417 = ({ V a_0 = v_ps_240; V a_1 = v_x22_246; V a_2 = v_t_2416; V r_ = (g_heff_2esession_2ecachedGo_24s889_24s1121(a_0, a_1, a_2)); heff_drop(v_x22_246); r_; });
  return heff_tail(v_t_2417, 2, (V[]){v_hd_2413, v_k_2414});
}
V g_heff_2esession_2ecachedGo_24s889_24s1121_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_ps_240 = heff_env(self)[3];
  V v_x22_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo(g_heff_2esession_2ecachedGo_24s889_24s1121_lam3, 1, 6, (V[]){v_acc_242, v_s_245, v_ps_240, v_x22_246, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2esession_2efreezeOne_24s892_24s1124_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 104, 99}};
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam0(V self, V *args); static Clo g_heff_2esession_2efreezeOne_24s892_24s1124_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2efreezeOne_24s892_24s1124_lam0, 2, 0};
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam1(V self, V *args); static Clo g_heff_2esession_2efreezeOne_24s892_24s1124_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2efreezeOne_24s892_24s1124_lam1, 2, 0};
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam3(V self, V *args); static Clo g_heff_2esession_2efreezeOne_24s892_24s1124_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2efreezeOne_24s892_24s1124_lam3, 1, 0};
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam2(V self, V *args);
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam5(V self, V *args);
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam4(V self, V *args);
Clo g_heff_2esession_2efreezeOne_24s892_24s1124_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2efreezeOne_24s892_24s1124_entry, 3, 0};

V g_heff_2esession_2efreezeOne_24s892_24s1124(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_s_243 = heff_field(v_x3_242, 0);
    V v_c_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_get(heff_dup(v_c_244), LBL_cached);
    V v_t_2410;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_2410 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_t_246 = heff_get(heff_dup(v_c_244), LBL_diags);
      V v_x1_249;
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nil: {
        v_x1_249 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_246, 0ULL, 2);
        v_x1_249 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_246);
      }
      switch (heff_tag_of(v_x1_249)) {
      case TAG_True: {
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_249);
      }
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_ps_240);
      heff_drop(v_acc_241);
      return ((V)&g_heff_2esession_2efreezeOne_24s892_24s1124_lam0_clo);
    }
    case TAG_False: {
      V v_t_2413 = ({ V b_0 = heff_get(heff_dup(v_acc_241), LBL_hashes); V b_1 = heff_get(v_acc_241, LBL_done); V a_2 = heff_dup(v_s_243); V a_3 = heff_dup(v_c_244); V r_ = (g_heff_2ecache_2efreeze(b_0, b_1, a_2, a_3)); heff_drop(b_0); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop(v_ps_240);
        return ((V)&g_heff_2esession_2efreezeOne_24s892_24s1124_lam1_clo);
      }
      case TAG_Just: {
        V v_out_2416 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2417 = (g_heff_2esession_2ecacheDir(heff_dup(v_ps_240)));
        V v_t_2418 = heff_strAppend(heff_get(heff_dup(v_c_244), LBL_module), ((V)&g_heff_2esession_2efreezeOne_24s892_24s1124_str0));
        V v_path_2419 = (g_heff_2eload_2eunder(v_ps_240, v_t_2417, v_t_2418));
        V v_c_2427 = heff_clo(g_heff_2esession_2efreezeOne_24s892_24s1124_lam2, 2, 2, (V[]){v_path_2419, v_out_2416});
        return heff_clo(g_heff_2esession_2efreezeOne_24s892_24s1124_lam4, 2, 1, (V[]){v_c_2427});
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esession_2efreezeOne_24s892_24s1124(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam1(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  heff_drop(v_hd_2414);
  V f_ = v_k_2415;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam3(V self, V *args) {
  V v_ok_2422 = args[0];
  return v_ok_2422;
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_path_2419 = heff_env(self)[0];
  V v_out_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_WriteFile, 3, (V[]){v_path_2419, v_out_2416, ((V)&g_heff_2esession_2efreezeOne_24s892_24s1124_lam3_clo)})});
  V v_t_2424 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_2420), LBL_malg), 1, (V[]){v_t_2425}));
  V f_ = heff_get(v_hd_2420, LBL_bind);
  args[0] = v_t_2426;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2efreezeOne_24s892_24s1124_lam4(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2427;
  args[0] = v_hd_2428;
  args[1] = heff_clo(g_heff_2esession_2efreezeOne_24s892_24s1124_lam5, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esession_2efreezeAll_24s891_24s1123_lam0(V self, V *args); static Clo g_heff_2esession_2efreezeAll_24s891_24s1123_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2efreezeAll_24s891_24s1123_lam0, 2, 0};
V g_heff_2esession_2efreezeAll_24s891_24s1123_lam2(V self, V *args);
V g_heff_2esession_2efreezeAll_24s891_24s1123_lam1(V self, V *args);
Clo g_heff_2esession_2efreezeAll_24s891_24s1123_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2efreezeAll_24s891_24s1123_entry, 3, 0};

V g_heff_2esession_2efreezeAll_24s891_24s1123(V v_ps_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ps_240);
    heff_drop(v_acc_241);
    return ((V)&g_heff_2esession_2efreezeAll_24s891_24s1123_lam0_clo);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2esession_2efreezeOne_24s892_24s1124(heff_dup(v_ps_240), heff_dup(v_acc_241), v_p_245));
    return heff_clo(g_heff_2esession_2efreezeAll_24s891_24s1123_lam1, 2, 4, (V[]){v_c_247, v_ps_240, v_acc_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esession_2efreezeAll_24s891_24s1123_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2esession_2efreezeAll_24s891_24s1123(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2esession_2efreezeAll_24s891_24s1123_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2efreezeAll_24s891_24s1123_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V a_0 = v_ps_240; V a_1 = v_acc_241; V a_2 = v_rest_246; V r_ = (g_heff_2esession_2efreezeAll_24s891_24s1123(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  return heff_tail(v_t_2411, 2, (V[]){v_hd_248, v_k_249});
}
V g_heff_2esession_2efreezeAll_24s891_24s1123_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo(g_heff_2esession_2efreezeAll_24s891_24s1123_lam2, 1, 5, (V[]){v_ps_240, v_acc_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam3(V self, V *args); static Clo g_heff_2esession_2ecachedProgram_24s888_24s1120_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecachedProgram_24s888_24s1120_lam3, 1, 0};
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam2(V self, V *args);
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam5(V self, V *args);
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam4(V self, V *args);
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam1(V self, V *args);
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam0(V self, V *args);
Clo g_heff_2esession_2ecachedProgram_24s888_24s1120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esession_2ecachedProgram_24s888_24s1120_entry, 1, 0};

V g_heff_2esession_2ecachedProgram_24s888_24s1120(V v_l_240) {
top: ;
  V v_t_241 = heff_rec(2, shape_71_122, (V[]){NTAG(TAG_Nil), heff_dup(g_map_2eempty_get())});
  V v_c_242 = ({ V a_0 = heff_get(heff_dup(v_l_240), LBL_paths); V b_1 = heff_get(heff_dup(v_l_240), LBL_sources); V a_2 = v_t_241; V r_ = (g_heff_2esession_2ecachedGo_24s889_24s1121(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return heff_clo(g_heff_2esession_2ecachedProgram_24s888_24s1120_lam0, 2, 2, (V[]){v_c_242, v_l_240});
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_entry(V self, V *a) {
  (void)self;
  return g_heff_2esession_2ecachedProgram_24s888_24s1120(a[0]);
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam3(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam2(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_path_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_MkDir, 2, (V[]){v_path_246, ((V)&g_heff_2esession_2ecachedProgram_24s888_24s1120_lam3_clo)})});
  V v_t_2411 = heff_tag(TAG_InL, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag(TAG_InR, 1, (V[]){heff_tag(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_apply(heff_get(heff_dup(v_hd_247), LBL_malg), 1, (V[]){v_t_2412}));
  V f_ = heff_get(v_hd_247, LBL_bind);
  args[0] = v_t_2413;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam5(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V f_ = v_k_244;
  args[0] = heff_get(v_x_245, LBL_done);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  V v_t_2416 = (g_heff_2esession_2ezipSC(heff_get(heff_dup(v_l_240), LBL_sources), heff_get(heff_dup(v_x_245), LBL_done)));
  V v_c_2417 = ({ V a_0 = heff_get(v_l_240, LBL_paths); V a_1 = heff_dup(v_x_245); V a_2 = v_t_2416; V r_ = (g_heff_2esession_2efreezeAll_24s891_24s1123(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
  return heff_tail(v_c_2417, 2, (V[]){v_hd_243, heff_clo(g_heff_2esession_2ecachedProgram_24s888_24s1120_lam5, 1, 2, (V[]){v_k_244, v_x_245})});
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_l_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_246 = (g_heff_2esession_2ecacheDir(heff_get(heff_dup(v_l_240), LBL_paths)));
  V v_c_2414 = heff_clo(g_heff_2esession_2ecachedProgram_24s888_24s1120_lam2, 2, 1, (V[]){v_path_246});
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_hd_243), heff_clo(g_heff_2esession_2ecachedProgram_24s888_24s1120_lam4, 1, 4, (V[]){v_l_240, v_x_245, v_hd_243, v_k_244})});
}
V g_heff_2esession_2ecachedProgram_24s888_24s1120_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo(g_heff_2esession_2ecachedProgram_24s888_24s1120_lam1, 1, 3, (V[]){v_l_240, v_hd_243, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}