// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LSnoc 32613
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkFolded 17353
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLocal 28569
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_array_2eempty_get(void);
V g_heff_2eelab_2ereadback_2eappliedOnly(V);
V g_heff_2eelab_2ereadback_2eappliedOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eappliedOnly_clo;
V g_heff_2eelab_2ereadback_2eforcedRb(V);
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eforcedRb_clo;
HeffT2 g_heff_2eelab_2ereadback_2eforcedRb_24cpr(V);
V g_heff_2eelab_2ereadback_2egoRT(V, V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_clo;
V g_heff_2eelab_2ereadback_2egoRT_24dps(V, V, V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24dps_clo;
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665(V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_clo;
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps(V, V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_clo;
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(V, V, V);
V g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591_clo;
HeffT2 g_heff_2eelab_2ereadback_2elocalArgs_24cpr(V);
V g_heff_2eelab_2ereadback_2ereadbBare(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885_clo;
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_clo;
V g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24generate0(V, V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24generate0_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24map0(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24map0_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0(V, V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps_clo;
V g_heff_2eelab_2ereadback_2eshownForcedRb(V);
V g_heff_2eelab_2ereadback_2eshownForcedRb_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownForcedRb_clo;
HeffT2 g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_heff_2eelab_2ereadback_2ereadbTermF_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTermF_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTermF_lam2(V self, V *args); static Clo g_heff_2eelab_2ereadback_2ereadbTermF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_lam2, 1, 0};
Clo g_heff_2eelab_2ereadback_2ereadbTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF(V v_r_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_VNeu: {
    V v_h_243 = heff_field(v_x3_242, 0);
    V v_sp_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 5);
    return (g_heff_2eelab_2ereadback_2ereadbBare(v_r_240, v_n_241, v_h_243, v_sp_244));
  }
  case TAG_VCode: {
    V v_a_248 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VCode = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_248}));
    return heff_tag_at_n(v_ru_24x3_242_24VCode, TAG_SCode, 1, (V[]){v_t_249});
  }
  case TAG_VLam: {
    V v_fty_2410 = heff_field(v_x3_242, 0);
    V v_body_2411 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24VLam = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_2412 = heff_tr(heff_call(heff_dup(v_fty_2410), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_n_241), v_t_2412}));
    V v_r_2414 = v_r_240;
    V v_n_2415 = v_n_241;
    V v_t_2416 = heff_tr(heff_call(v_fty_2410, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2417 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2416)));
    V v_dom_2429;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2417, 0ULL, 1);
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2420 = heff_field(v_t_2417, 1);
      heff_take_n(v_t_2417, 2ULL, 4);
      heff_drop(v_t_2416);
      v_dom_2429 = v_dom_2420;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2417, 0ULL, 3);
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2417, 0ULL, 1);
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeInt: {
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeFloat: {
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeString: {
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeRune: {
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2417, 0ULL, 1);
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2417, 0ULL, 1);
      v_dom_2429 = v_t_2416;
      break;
    }
    case TAG_NoRules: {
      v_dom_2429 = v_t_2416;
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_x4_2430 = v_body_2411;
    V v_t_2450;
    switch (heff_tag_of(v_x4_2430)) {
    case TAG_MkClo: {
      V v_x_2431 = heff_field(v_x4_2430, 0);
      V v_l_2432 = heff_field(v_x4_2430, 1);
      V v_f_2433 = heff_field(v_x4_2430, 2);
      heff_take_n(v_x4_2430, 7ULL, 3);
      V v_n_2434 = heff_intAdd_lent(v_n_2415, MK_INT(1LL), 2);
      V v_v_2436 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_2415}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_lam0, 1, 1, (V[]){v_dom_2429}), NTAG(TAG_Nothing)));
      V v_x3_2438 = heff_tr(heff_call(v_f_2433, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_2432, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_lam1, 1, 1, (V[]){v_v_2436})})}));
      V v_t_2443;
      switch (heff_tag_of(v_x3_2438)) {
      case TAG_Nom: {
        V v_v_2439 = heff_field(v_x3_2438, 0);
        heff_take_n(v_x3_2438, 1ULL, 1);
        v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_2414, 0, 2), 2, (V[]){v_n_2434, v_v_2439}));
        break;
      }
      case TAG_Describe: {
        V v_v_2440 = heff_field(v_x3_2438, 0);
        heff_take_n(v_x3_2438, 1ULL, 1);
        v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_2414, 0, 2), 2, (V[]){v_n_2434, v_v_2440}));
        break;
      }
      case TAG_Become: {
        V v_v_2441 = heff_field(v_x3_2438, 0);
        V v_ru_24x3_2438_24Become = heff_take_reuse_n(v_x3_2438, 1ULL, 1);
        V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_2414, 0, 2), 2, (V[]){v_n_2434, v_v_2441}));
        v_t_2443 = heff_tag_at_n(v_ru_24x3_2438_24Become, TAG_SIs, 1, (V[]){v_t_2442});
        break;
      }
      default: heff_nomatch(v_x3_2438);
      }
      v_t_2450 = heff_tag_at_n(v_ru_24x3_242_24VLam, TAG_MkAbs, 2, (V[]){v_x_2431, v_t_2443});
      break;
    }
    case TAG_CloConst: {
      V v_t_2444 = heff_field(v_x4_2430, 0);
      V v_ru_24x4_2430_24CloConst = heff_take_reuse_n(v_x4_2430, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24VLam, 2);
      heff_drop(v_dom_2429);
      V v_t_2449;
      switch (heff_tag_of(v_t_2444)) {
      case TAG_Nom: {
        V v_v_2445 = heff_field(v_t_2444, 0);
        heff_take_n(v_t_2444, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2430_24CloConst, 1);
        v_t_2449 = heff_tr(heff_call(heff_get_n(v_r_2414, 0, 2), 2, (V[]){v_n_2415, v_v_2445}));
        break;
      }
      case TAG_Describe: {
        V v_v_2446 = heff_field(v_t_2444, 0);
        heff_take_n(v_t_2444, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2430_24CloConst, 1);
        v_t_2449 = heff_tr(heff_call(heff_get_n(v_r_2414, 0, 2), 2, (V[]){v_n_2415, v_v_2446}));
        break;
      }
      case TAG_Become: {
        V v_v_2447 = heff_field(v_t_2444, 0);
        heff_take_n(v_t_2444, 1ULL, 1);
        V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_2414, 0, 2), 2, (V[]){v_n_2415, v_v_2447}));
        v_t_2449 = heff_tag_at_n(v_ru_24x4_2430_24CloConst, TAG_SIs, 1, (V[]){v_t_2448});
        break;
      }
      default: heff_nomatch(v_t_2444);
      }
      v_t_2450 = heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2449});
      break;
    }
    default: heff_nomatch(v_x4_2430);
    }
    return heff_tag_n(TAG_SLam, 2, (V[]){v_t_2413, v_t_2450});
  }
  case TAG_VCons: {
    V v_d_2451 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VCons = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_xs_2452 = heff_take_field(v_d_2451, 2);
    V v_m_2453 = heff_arrayLength_lent(v_xs_2452, 0);
    V v_t_2462;
    if ((heff_peek_word(v_m_2453) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_n_241);
      heff_drop_cell(v_ru_24x3_242_24VCons, 1);
      heff_drop(v_xs_2452);
      v_t_2462 = heff_arrayGenerate(v_m_2453, ((V)&g_heff_2eelab_2ereadback_2ereadbTermF_lam2_clo));
    } else {
      V v_x3_2455 = heff_arrayIndex_lent(v_xs_2452, MK_INT(0LL), 2);
      V v_y_2460;
      switch (heff_tag_of(v_x3_2455)) {
      case TAG_Nom: {
        V v_v_2456 = heff_field(v_x3_2455, 0);
        heff_take_n(v_x3_2455, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24VCons, 1);
        v_y_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_2456}));
        break;
      }
      case TAG_Describe: {
        V v_v_2457 = heff_field(v_x3_2455, 0);
        heff_take_n(v_x3_2455, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24VCons, 1);
        v_y_2460 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_2457}));
        break;
      }
      case TAG_Become: {
        V v_v_2458 = heff_field(v_x3_2455, 0);
        heff_take_n(v_x3_2455, 1ULL, 1);
        V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_2458}));
        v_y_2460 = heff_tag_at_n(v_ru_24x3_242_24VCons, TAG_SIs, 1, (V[]){v_t_2459});
        break;
      }
      default: heff_nomatch(v_x3_2455);
      }
      V v_t_2461 = heff_arrayKeepsAs_lent(v_xs_2452, v_y_2460, 0);
      if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
        heff_drop(v_m_2453);
        heff_drop(v_t_2461);
        v_t_2462 = (g_heff_2eelab_2ereadback_2ereadbTermF_24map0(v_r_240, v_n_241, MK_INT(1LL), heff_arraySet(v_xs_2452, MK_INT(0LL), v_y_2460)));
      } else {
        heff_drop(v_t_2461);
        v_t_2462 = ({ V a_0 = v_xs_2452; V a_1 = v_r_240; V a_2 = v_n_241; V a_3 = MK_INT(1LL); V a_4 = heff_arrayReplicate(v_m_2453, v_y_2460); V r_ = (g_heff_2eelab_2ereadback_2ereadbTermF_24generate0(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_2452); r_; });
      }
    }
    V v_t_2463 = ({ V rv_2 = v_t_2462; V rr_ = heff_rec_reuse_nf(v_d_2451, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SCons, 1, (V[]){v_t_2463});
  }
  case TAG_VOpaque: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbTermF_lam0(V self, V *args) {
  V v_u_2435 = args[0];
  V v_dom_2429 = heff_env(self)[0];
  heff_drop(v_u_2435);
  heff_clo_take(self, 1);
  return v_dom_2429;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_lam1(V self, V *args) {
  V v_u_2437 = args[0];
  V v_v_2436 = heff_env(self)[0];
  heff_drop(v_u_2437);
  heff_clo_take(self, 1);
  return v_v_2436;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_lam2(V self, V *args) {
  V v_u_2454 = args[0];
  heff_drop(v_u_2454);
  return heff_abandon();
}
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24generate0_entry, 5, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24generate0(V v_xs_240, V v_r_241, V v_n_242, V v_box_24i_243, V v_a_244) {
  int64_t v_i_243 = heff_unbox_word(v_box_24i_243);
  v_a_244 = heff_arrayOwn(v_a_244);
  if (((((int64_t)0ULL) <= v_i_243) && (heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
      V v_x3_245 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_243));
      V v_t_2410;
      switch (heff_tag_of(v_x3_245)) {
      case TAG_Nom: {
        V v_v_246 = heff_field(v_x3_245, 0);
        v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){heff_dup(v_n_242), heff_dup(v_v_246)}));
        break;
      }
      case TAG_Describe: {
        V v_v_247 = heff_field(v_x3_245, 0);
        v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){heff_dup(v_n_242), heff_dup(v_v_247)}));
        break;
      }
      case TAG_Become: {
        V v_v_248 = heff_field(v_x3_245, 0);
        V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){heff_dup(v_n_242), heff_dup(v_v_248)}));
        v_t_2410 = heff_tag_n(TAG_SIs, 1, (V[]){v_t_249});
        break;
      }
      default: heff_nomatch(v_x3_245);
      }
      V t_0 = v_xs_240;
      V t_1 = v_r_241;
      V t_2 = v_n_242;
      int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
      V t_4 = heff_arraySetOwnedIn(v_a_244, heff_box_word(v_i_243), v_t_2410);
      v_xs_240 = t_0;
      v_r_241 = t_1;
      v_n_242 = t_2;
      v_i_243 = t_3;
      v_a_244 = t_4;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_241, 2);
      heff_drop(v_n_242);
      return v_a_244;
    }
  } else {
  }
top: ;
  if ((v_i_243 < heff_unbox_word(heff_arrayLength_lent(v_a_244, 0)))) {
    V v_x3_245 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_243));
    V v_t_2410;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nom: {
      V v_v_246 = heff_field(v_x3_245, 0);
      v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){heff_dup(v_n_242), heff_dup(v_v_246)}));
      break;
    }
    case TAG_Describe: {
      V v_v_247 = heff_field(v_x3_245, 0);
      v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){heff_dup(v_n_242), heff_dup(v_v_247)}));
      break;
    }
    case TAG_Become: {
      V v_v_248 = heff_field(v_x3_245, 0);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 2, (V[]){heff_dup(v_n_242), heff_dup(v_v_248)}));
      v_t_2410 = heff_tag_n(TAG_SIs, 1, (V[]){v_t_249});
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    V t_0 = v_xs_240;
    V t_1 = v_r_241;
    V t_2 = v_n_242;
    int64_t t_3 = (v_i_243 + ((int64_t)1ULL));
    V t_4 = heff_arraySetOwned(v_a_244, heff_box_word(v_i_243), v_t_2410);
    v_xs_240 = t_0;
    v_r_241 = t_1;
    v_n_242 = t_2;
    v_i_243 = t_3;
    v_a_244 = t_4;
    goto top;
  } else {
    heff_drop_rec(v_r_241, 2);
    heff_drop(v_n_242);
    return v_a_244;
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2ereadbTermF_24generate0(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24map0_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24map0(V v_r_240, V v_n_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if ((((int64_t)0ULL) <= v_i_242)) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_x3_244 = heff_arrayIndexIn_lent(v_a_243, heff_box_word(v_i_242), 2);
      V v_t_249;
      switch (heff_tag_of(v_x3_244)) {
      case TAG_Nom: {
        V v_v_245 = heff_field(v_x3_244, 0);
        heff_take_n(v_x3_244, 1ULL, 1);
        v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_245}));
        break;
      }
      case TAG_Describe: {
        V v_v_246 = heff_field(v_x3_244, 0);
        heff_take_n(v_x3_244, 1ULL, 1);
        v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_246}));
        break;
      }
      case TAG_Become: {
        V v_v_247 = heff_field(v_x3_244, 0);
        V v_ru_24x3_244_24Become = heff_take_reuse_n(v_x3_244, 1ULL, 1);
        V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_247}));
        v_t_249 = heff_tag_at_n(v_ru_24x3_244_24Become, TAG_SIs, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x3_244);
      }
      V t_0 = v_r_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_249);
      v_r_240 = t_0;
      v_n_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop_rec(v_r_240, 2);
      heff_drop(v_n_241);
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_x3_244 = heff_arrayIndex_lent(v_a_243, heff_box_word(v_i_242), 2);
    V v_t_249;
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nom: {
      V v_v_245 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_245}));
      break;
    }
    case TAG_Describe: {
      V v_v_246 = heff_field(v_x3_244, 0);
      heff_take_n(v_x3_244, 1ULL, 1);
      v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_246}));
      break;
    }
    case TAG_Become: {
      V v_v_247 = heff_field(v_x3_244, 0);
      V v_ru_24x3_244_24Become = heff_take_reuse_n(v_x3_244, 1ULL, 1);
      V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 2, (V[]){heff_dup(v_n_241), v_v_247}));
      v_t_249 = heff_tag_at_n(v_ru_24x3_244_24Become, TAG_SIs, 1, (V[]){v_t_248});
      break;
    }
    default: heff_nomatch(v_x3_244);
    }
    V t_0 = v_r_240;
    V t_1 = v_n_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_249);
    v_r_240 = t_0;
    v_n_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return v_a_243;
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24map0_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF_24map0(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2egoRT_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_entry, 4, 0};

V g_heff_2eelab_2ereadback_2egoRT(V v_r_240, V v_i_241, V v_ls_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_i_241);
    heff_drop(v_ls_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_ls_242)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkField: {
      V v_ty_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24MkField = heff_take_reuse_n(v_t_246, 1ULL, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_i_241), heff_dup(v_ty_247)}));
      V v_v_2411 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_241)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_lam0, 1, 1, (V[]){v_ty_247}), NTAG(TAG_Nothing)));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
      V v_u_2414 = (g_heff_2eelab_2ereadback_2egoRT_24dps(v_r_240, heff_intAdd(v_i_241, MK_INT(1LL)), heff_tag_at_n(v_ru_24t_246_24MkField, TAG_LSnoc, 2, (V[]){v_ls_242, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_lam1, 1, 1, (V[]){v_v_2411})}), v_rest_245, v_cell_2412));
      heff_drop(v_u_2414);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2egoRT(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2ereadback_2egoRT_lam0(V self, V *args) {
  V v_u_2410 = args[0];
  V v_ty_247 = heff_env(self)[0];
  heff_drop(v_u_2410);
  heff_clo_take(self, 1);
  return v_ty_247;
}
V g_heff_2eelab_2ereadback_2egoRT_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  V v_v_2411 = heff_env(self)[0];
  heff_drop(v_u_2413);
  heff_clo_take(self, 1);
  return v_v_2411;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam3(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTypeF_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbTypeF(V v_r_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_VU: {
    V v_u_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VU = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return heff_tag_at_n(v_ru_24x3_242_24VU, TAG_SU, 1, (V[]){v_u_243});
  }
  case TAG_VDecode: {
    V v_h_244 = heff_field(v_x3_242, 0);
    V v_sp_245 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 5);
    V v_t_2414;
    switch (heff_tag_of(v_h_244)) {
    case TAG_HLocal: {
      V v_i_249 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HLocal = heff_take_reuse_n(v_h_244, 1ULL, 1);
      V v_t_2410 = heff_intSub(heff_intSub_lent(v_n_241, v_i_249, 2), MK_INT(1LL));
      v_t_2414 = heff_tag_at_n(v_ru_24h_244_24HLocal, TAG_SLocal, 1, (V[]){v_t_2410});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2411 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HGlobal = heff_take_reuse_n(v_h_244, 1ULL, 1);
      v_t_2414 = heff_tag_at_n(v_ru_24h_244_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2411});
      break;
    }
    case TAG_HMeta: {
      V v_m_2412 = heff_field(v_h_244, 0);
      V v_ru_24h_244_24HMeta = heff_take_reuse_n(v_h_244, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24h_244_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2414 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2412, heff_dup(g_array_2eempty_get()), v_t_2413});
      break;
    }
    case TAG_HError: {
      v_t_2414 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_244);
    }
    V v_t_2415 = (g_heff_2eelab_2ereadback_2ereadbSpine(v_r_240, v_n_241, v_sp_245, v_t_2414));
    return heff_tag_n(TAG_SDecode, 1, (V[]){v_t_2415});
  }
  case TAG_VFunction: {
    V v_level_2416 = heff_field(v_x3_242, 0);
    V v_dom_2417 = heff_field(v_x3_242, 1);
    V v_cod_2418 = heff_field(v_x3_242, 2);
    V v_implicit_2419 = heff_field(v_x3_242, 3);
    V v_dflt_2420 = heff_field(v_x3_242, 4);
    heff_take_n(v_x3_242, 31ULL, 6);
    V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_n_241), heff_dup(v_dom_2417)}));
    V v_r_2423 = v_r_240;
    V v_n_2424 = v_n_241;
    V v_dom_2425 = v_dom_2417;
    V v_x4_2426 = v_cod_2418;
    V v_t_2446;
    switch (heff_tag_of(v_x4_2426)) {
    case TAG_MkClo: {
      V v_x_2427 = heff_field(v_x4_2426, 0);
      V v_l_2428 = heff_field(v_x4_2426, 1);
      V v_f_2429 = heff_field(v_x4_2426, 2);
      heff_take_n(v_x4_2426, 7ULL, 3);
      V v_n_2430 = heff_intAdd_lent(v_n_2424, MK_INT(1LL), 2);
      V v_v_2432 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_2424}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_lam0, 1, 1, (V[]){v_dom_2425}), NTAG(TAG_Nothing)));
      V v_x3_2434 = heff_tr(heff_call(v_f_2429, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_2428, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_lam1, 1, 1, (V[]){v_v_2432})})}));
      V v_t_2439;
      switch (heff_tag_of(v_x3_2434)) {
      case TAG_Nom: {
        V v_a_2435 = heff_field(v_x3_2434, 0);
        heff_take_n(v_x3_2434, 1ULL, 1);
        v_t_2439 = heff_tr(heff_call(heff_get_n(v_r_2423, 1, 2), 2, (V[]){v_n_2430, v_a_2435}));
        break;
      }
      case TAG_Describe: {
        V v_a_2436 = heff_field(v_x3_2434, 0);
        heff_take_n(v_x3_2434, 1ULL, 1);
        v_t_2439 = heff_tr(heff_call(heff_get_n(v_r_2423, 1, 2), 2, (V[]){v_n_2430, v_a_2436}));
        break;
      }
      case TAG_Become: {
        V v_a_2437 = heff_field(v_x3_2434, 0);
        V v_ru_24x3_2434_24Become = heff_take_reuse_n(v_x3_2434, 1ULL, 1);
        V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_2423, 1, 2), 2, (V[]){v_n_2430, v_a_2437}));
        v_t_2439 = heff_tag_at_n(v_ru_24x3_2434_24Become, TAG_SIsTy, 1, (V[]){v_t_2438});
        break;
      }
      default: heff_nomatch(v_x3_2434);
      }
      v_t_2446 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2427, v_t_2439});
      break;
    }
    case TAG_CloConst: {
      V v_t_2440 = heff_field(v_x4_2426, 0);
      V v_ru_24x4_2426_24CloConst = heff_take_reuse_n(v_x4_2426, 1ULL, 1);
      heff_drop(v_dom_2425);
      V v_t_2445;
      switch (heff_tag_of(v_t_2440)) {
      case TAG_Nom: {
        V v_a_2441 = heff_field(v_t_2440, 0);
        heff_take_n(v_t_2440, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2426_24CloConst, 1);
        v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_2423, 1, 2), 2, (V[]){v_n_2424, v_a_2441}));
        break;
      }
      case TAG_Describe: {
        V v_a_2442 = heff_field(v_t_2440, 0);
        heff_take_n(v_t_2440, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2426_24CloConst, 1);
        v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_2423, 1, 2), 2, (V[]){v_n_2424, v_a_2442}));
        break;
      }
      case TAG_Become: {
        V v_a_2443 = heff_field(v_t_2440, 0);
        heff_take_n(v_t_2440, 1ULL, 1);
        V v_t_2444 = heff_tr(heff_call(heff_get_n(v_r_2423, 1, 2), 2, (V[]){v_n_2424, v_a_2443}));
        v_t_2445 = heff_tag_at_n(v_ru_24x4_2426_24CloConst, TAG_SIsTy, 1, (V[]){v_t_2444});
        break;
      }
      default: heff_nomatch(v_t_2440);
      }
      v_t_2446 = heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2445});
      break;
    }
    default: heff_nomatch(v_x4_2426);
    }
    return heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2416, v_t_2422, v_t_2446, v_implicit_2419, v_dflt_2420});
  }
  case TAG_VRecord: {
    V v_level_2447 = heff_field(v_x3_242, 0);
    V v_capture_2448 = heff_field(v_x3_242, 1);
    V v_fieldTypes_2449 = heff_field(v_x3_242, 2);
    V v_defaults_2450 = heff_field(v_x3_242, 3);
    heff_take_n(v_x3_242, 15ULL, 4);
    V v_t_2451 = heff_arrayToList(heff_take_field(v_fieldTypes_2449, 2));
    V v_t_2452 = (g_heff_2eelab_2ereadback_2egoRT(v_r_240, v_n_241, v_capture_2448, v_t_2451));
    V v_t_2453 = ({ V rv_2 = heff_arrayFromList(v_t_2452); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2449, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2447, v_t_2453, v_defaults_2450});
  }
  case TAG_VSum: {
    V v_st_2454 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VSum = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_xs_2455 = heff_take_field(v_st_2454, 2);
    V v_t_2461 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2455, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_lam2, 1, 3, (V[]){v_xs_2455, v_r_240, v_n_241}));
    V v_t_2462 = ({ V rv_2 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_st_2454, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_242_24VSum, TAG_SSum, 1, (V[]){v_t_2462});
  }
  case TAG_VPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return NTAG(TAG_SPrimRune);
  }
  case TAG_VPrimArray: {
    V v_a_2463 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VPrimArray = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_n_241, v_a_2463}));
    return heff_tag_at_n(v_ru_24x3_242_24VPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2464});
  }
  case TAG_VFixed: {
    V v_w_2465 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24VFixed = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_n_241);
    return heff_tag_at_n(v_ru_24x3_242_24VFixed, TAG_SFixed, 1, (V[]){v_w_2465});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTypeF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam0(V self, V *args) {
  V v_u_2431 = args[0];
  V v_dom_2425 = heff_env(self)[0];
  heff_drop(v_u_2431);
  heff_clo_take(self, 1);
  return v_dom_2425;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_v_2432 = heff_env(self)[0];
  heff_drop(v_u_2433);
  heff_clo_take(self, 1);
  return v_v_2432;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam3(V self, V *args) {
  V v_i_2458 = args[0];
  V v_xs_2457 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2459 = heff_arrayIndex(v_xs_2457, v_i_2458);
  V v_t_2460 = heff_tr(heff_call(v_t_2459, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = heff_get_n(v_r_240, 1, 2);
  heff_room[0] = v_n_241;
  heff_room[1] = v_t_2460;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_lam2(V self, V *args) {
  V v_i_2456 = args[0];
  V v_xs_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_n_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_xs_2457 = heff_arrayIndex(v_xs_2455, v_i_2456);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2457, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_lam3, 1, 3, (V[]){v_xs_2457, v_r_240, v_n_241}));
}
Clo g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(V v_n_240, V v_x3_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_SpId: {
    heff_drop(v_n_240);
    return v_t_242;
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x3_241, 0);
    V v_v_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpApp = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(heff_dup(v_n_240), v_sp_243, v_t_242));
    V v_t_246 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_244));
    return heff_tag_at_n(v_ru_24x3_241_24SpApp, TAG_SApp, 2, (V[]){v_t_245, v_t_246});
  }
  case TAG_SpProj: {
    V v_sp_247 = heff_field(v_x3_241, 0);
    V v_x_248 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24SpProj = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_249 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_247, v_t_242));
    return heff_tag_at_n(v_ru_24x3_241_24SpProj, TAG_SProj, 2, (V[]){v_t_249, v_x_248});
  }
  case TAG_SpSpec: {
    V v_sp_2410 = heff_field(v_x3_241, 0);
    V v_x_2411 = heff_field(v_x3_241, 1);
    V v_v_2412 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24SpSpec = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2413 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(heff_dup(v_n_240), v_sp_2410, v_t_242));
    V v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s1630692168x1432232263(v_n_240, v_v_2412));
    return heff_tag_at_n(v_ru_24x3_241_24SpSpec, TAG_SSpecialize, 3, (V[]){v_t_2413, v_x_2411, v_t_2414});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub_lent(v_n_240, v_i_244, 2), MK_INT(1LL));
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_array_2eempty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub_lent(v_n_240, v_i_2411, 2), MK_INT(1LL));
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_array_2eempty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    HeffT2 v_t_2418 = (g_heff_2eelab_2ereadback_2elocalArgs_24cpr(heff_dup(v_sp_242)));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_sp_242);
        V v_idxs_2421 = v_field_2420;
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2421));
        V v_t_2423 = (g_list_2emap_24s1947501783x1475115781(v_n_240, MK_INT(1LL), v_t_2422));
        V v_t_2424 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
      } else {
        heff_drop(v_field_2420);
        V v_t_2425 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_array_2eempty_get()), v_t_2425}));
      }
    }
  }
  case TAG_HError: {
    V v_t_2431;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2426 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2427 = heff_intSub(heff_intSub_lent(v_n_240, v_i_2426, 2), MK_INT(1LL));
      v_t_2431 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2427});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2431 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2428});
      break;
    }
    case TAG_HMeta: {
      V v_m_2429 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2431 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2429, heff_dup(g_array_2eempty_get()), v_t_2430});
      break;
    }
    case TAG_HError: {
      v_t_2431 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2431);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare_24s1737894005x1880474627(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam3(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam2(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry, 2, 0};

V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VU: {
    V v_u_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VU = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at_n(v_ru_24x3_241_24VU, TAG_SU, 1, (V[]){v_u_242});
  }
  case TAG_VDecode: {
    V v_h_243 = heff_field(v_x3_241, 0);
    V v_sp_244 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    V v_t_2413;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      V v_i_248 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HLocal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_249 = heff_intSub(heff_intSub_lent(v_n_240, v_i_248, 2), MK_INT(1LL));
      v_t_2413 = heff_tag_at_n(v_ru_24h_243_24HLocal, TAG_SLocal, 1, (V[]){v_t_249});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2410 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HGlobal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24h_243_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_HMeta: {
      V v_m_2411 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HMeta = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24h_243_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2413 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2411, heff_dup(g_array_2eempty_get()), v_t_2412});
      break;
    }
    case TAG_HError: {
      v_t_2413 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_244, v_t_2413));
    return heff_tag_n(TAG_SDecode, 1, (V[]){v_t_2414});
  }
  case TAG_VFunction: {
    V v_level_2415 = heff_field(v_x3_241, 0);
    V v_dom_2416 = heff_field(v_x3_241, 1);
    V v_cod_2417 = heff_field(v_x3_241, 2);
    V v_implicit_2418 = heff_field(v_x3_241, 3);
    V v_dflt_2419 = heff_field(v_x3_241, 4);
    heff_take_n(v_x3_241, 31ULL, 6);
    V v_t_2421 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_n_240), heff_dup(v_dom_2416)));
    V v_n_2422 = v_n_240;
    V v_dom_2423 = v_dom_2416;
    V v_x4_2424 = v_cod_2417;
    V v_t_2444;
    switch (heff_tag_of(v_x4_2424)) {
    case TAG_MkClo: {
      V v_x_2425 = heff_field(v_x4_2424, 0);
      V v_l_2426 = heff_field(v_x4_2424, 1);
      V v_f_2427 = heff_field(v_x4_2424, 2);
      heff_take_n(v_x4_2424, 7ULL, 3);
      V v_n_2428 = heff_intAdd_lent(v_n_2422, MK_INT(1LL), 2);
      V v_v_2430 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_2422}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam0, 1, 1, (V[]){v_dom_2423}), NTAG(TAG_Nothing)));
      V v_x3_2432 = heff_tr(heff_call(v_f_2427, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_2426, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam1, 1, 1, (V[]){v_v_2430})})}));
      V v_t_2437;
      switch (heff_tag_of(v_x3_2432)) {
      case TAG_Nom: {
        V v_a_2433 = heff_field(v_x3_2432, 0);
        heff_take_n(v_x3_2432, 1ULL, 1);
        v_t_2437 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2428, v_a_2433));
        break;
      }
      case TAG_Describe: {
        V v_a_2434 = heff_field(v_x3_2432, 0);
        heff_take_n(v_x3_2432, 1ULL, 1);
        v_t_2437 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2428, v_a_2434));
        break;
      }
      case TAG_Become: {
        V v_a_2435 = heff_field(v_x3_2432, 0);
        V v_ru_24x3_2432_24Become = heff_take_reuse_n(v_x3_2432, 1ULL, 1);
        V v_t_2436 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2428, v_a_2435));
        v_t_2437 = heff_tag_at_n(v_ru_24x3_2432_24Become, TAG_SIsTy, 1, (V[]){v_t_2436});
        break;
      }
      default: heff_nomatch(v_x3_2432);
      }
      v_t_2444 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2425, v_t_2437});
      break;
    }
    case TAG_CloConst: {
      V v_t_2438 = heff_field(v_x4_2424, 0);
      V v_ru_24x4_2424_24CloConst = heff_take_reuse_n(v_x4_2424, 1ULL, 1);
      heff_drop(v_dom_2423);
      V v_t_2443;
      switch (heff_tag_of(v_t_2438)) {
      case TAG_Nom: {
        V v_a_2439 = heff_field(v_t_2438, 0);
        heff_take_n(v_t_2438, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2424_24CloConst, 1);
        v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2422, v_a_2439));
        break;
      }
      case TAG_Describe: {
        V v_a_2440 = heff_field(v_t_2438, 0);
        heff_take_n(v_t_2438, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2424_24CloConst, 1);
        v_t_2443 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2422, v_a_2440));
        break;
      }
      case TAG_Become: {
        V v_a_2441 = heff_field(v_t_2438, 0);
        heff_take_n(v_t_2438, 1ULL, 1);
        V v_t_2442 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_2422, v_a_2441));
        v_t_2443 = heff_tag_at_n(v_ru_24x4_2424_24CloConst, TAG_SIsTy, 1, (V[]){v_t_2442});
        break;
      }
      default: heff_nomatch(v_t_2438);
      }
      v_t_2444 = heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2443});
      break;
    }
    default: heff_nomatch(v_x4_2424);
    }
    return heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2415, v_t_2421, v_t_2444, v_implicit_2418, v_dflt_2419});
  }
  case TAG_VRecord: {
    V v_level_2445 = heff_field(v_x3_241, 0);
    V v_capture_2446 = heff_field(v_x3_241, 1);
    V v_fieldTypes_2447 = heff_field(v_x3_241, 2);
    V v_defaults_2448 = heff_field(v_x3_241, 3);
    heff_take_n(v_x3_241, 15ULL, 4);
    V v_t_2449 = heff_arrayToList(heff_take_field(v_fieldTypes_2447, 2));
    V v_t_2450 = (g_heff_2eelab_2ereadback_2egoRT_24s738861868x1808236591(v_n_240, v_capture_2446, v_t_2449));
    V v_t_2451 = ({ V rv_2 = heff_arrayFromList(v_t_2450); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2447, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2445, v_t_2451, v_defaults_2448});
  }
  case TAG_VSum: {
    V v_st_2452 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VSum = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2453 = heff_take_field(v_st_2452, 2);
    V v_t_2459 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2453, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam2, 1, 2, (V[]){v_xs_2453, v_n_240}));
    V v_t_2460 = ({ V rv_2 = v_t_2459; V rr_ = heff_rec_reuse_nf(v_st_2452, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_241_24VSum, TAG_SSum, 1, (V[]){v_t_2460});
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimRune);
  }
  case TAG_VPrimArray: {
    V v_a_2461 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VPrimArray = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2462 = heff_tag_at_n(v_ru_24x3_241_24VPrimArray, TAG_SPrimArray, 1, (V[]){heff_hole()});
    V v_u_2463 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_24dps(v_n_240, v_a_2461, v_cell_2462));
    heff_drop(v_u_2463);
    return v_cell_2462;
  }
  case TAG_VFixed: {
    V v_w_2464 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VFixed = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at_n(v_ru_24x3_241_24VFixed, TAG_SFixed, 1, (V[]){v_w_2464});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(a[0], a[1]);
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam0(V self, V *args) {
  V v_u_2429 = args[0];
  V v_dom_2423 = heff_env(self)[0];
  heff_drop(v_u_2429);
  heff_clo_take(self, 1);
  return v_dom_2423;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam1(V self, V *args) {
  V v_u_2431 = args[0];
  V v_v_2430 = heff_env(self)[0];
  heff_drop(v_u_2431);
  heff_clo_take(self, 1);
  return v_v_2430;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam3(V self, V *args) {
  V v_i_2456 = args[0];
  V v_xs_2455 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2457 = heff_arrayIndex(v_xs_2455, v_i_2456);
  V v_t_2458 = heff_tr(heff_call(v_t_2457, 1, (V[]){NTAG(TAG_MkUnit)}));
  return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_n_240, v_t_2458));
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam2(V self, V *args) {
  V v_i_2454 = args[0];
  V v_xs_2453 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2455 = heff_arrayIndex(v_xs_2453, v_i_2454);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2455, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_lam3, 1, 2, (V[]){v_xs_2455, v_n_240}));
}
Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V v_n_240, V v_h_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_h_241)) {
  case TAG_HLocal: {
    V v_t_249;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_244 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_245 = heff_intSub(heff_intSub_lent(v_n_240, v_i_244, 2), MK_INT(1LL));
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_245});
      break;
    }
    case TAG_HGlobal: {
      V v_x_246 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_246});
      break;
    }
    case TAG_HMeta: {
      V v_m_247 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_248 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_249 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_247, heff_dup(g_array_2eempty_get()), v_t_248});
      break;
    }
    case TAG_HError: {
      v_t_249 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_249);
  }
  case TAG_HGlobal: {
    V v_t_2416;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2411 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2412 = heff_intSub(heff_intSub_lent(v_n_240, v_i_2411, 2), MK_INT(1LL));
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2412});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2413 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2416 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2413});
      break;
    }
    case TAG_HMeta: {
      V v_m_2414 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2416 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2414, heff_dup(g_array_2eempty_get()), v_t_2415});
      break;
    }
    case TAG_HError: {
      v_t_2416 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2416);
  }
  case TAG_HMeta: {
    V v_m_2417 = heff_field(v_h_241, 0);
    V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
    HeffT2 v_t_2418 = (g_heff_2eelab_2ereadback_2elocalArgs_24cpr(heff_dup(v_sp_242)));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop(v_sp_242);
        V v_idxs_2421 = v_field_2420;
        V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_idxs_2421));
        V v_t_2423 = (g_list_2emap_24s1947501783x1475115781(v_n_240, MK_INT(1LL), v_t_2422));
        V v_t_2424 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        return heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_arrayFromList(v_t_2423), v_t_2424});
      } else {
        heff_drop(v_field_2420);
        V v_t_2425 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
        HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2417, heff_dup(g_array_2eempty_get()), v_t_2425}));
      }
    }
  }
  case TAG_HError: {
    V v_t_2431;
    switch (heff_tag_of(v_h_241)) {
    case TAG_HLocal: {
      V v_i_2426 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HLocal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2427 = heff_intSub(heff_intSub_lent(v_n_240, v_i_2426, 2), MK_INT(1LL));
      v_t_2431 = heff_tag_at_n(v_ru_24h_241_24HLocal, TAG_SLocal, 1, (V[]){v_t_2427});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2428 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HGlobal = heff_take_reuse_n(v_h_241, 1ULL, 1);
      v_t_2431 = heff_tag_at_n(v_ru_24h_241_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2428});
      break;
    }
    case TAG_HMeta: {
      V v_m_2429 = heff_field(v_h_241, 0);
      V v_ru_24h_241_24HMeta = heff_take_reuse_n(v_h_241, 1ULL, 1);
      V v_t_2430 = heff_tag_at_n(v_ru_24h_241_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2431 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2429, heff_dup(g_array_2eempty_get()), v_t_2430});
      break;
    }
    case TAG_HError: {
      v_t_2431 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_241);
    }
    HEFF_LAST return g_heff_2eelab_2ereadback_2ereadbSpine_24s1912135668x1825423694(v_n_240, v_sp_242, v_t_2431);
  }
  default: return heff_nomatch(v_h_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2eforcedRb_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2eforcedRb_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2ereadback_2eforcedRb_24cpr(V v_mc_240) {
top: ;
  return ((HeffT2){{heff_clo_n(g_heff_2eelab_2ereadback_2eforcedRb_24cpr_lam0, 2, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2ereadback_2eforcedRb_24cpr_lam1, 2, 1, (V[]){heff_dup(v_mc_240)})}});
}
V g_heff_2eelab_2ereadback_2eforcedRb_24cpr_lam0(V self, V *args) {
  V v_n_241 = args[0];
  V v_v_242 = args[1];
  V v_mc_240 = heff_env(self)[0];
  V v_t_243 = (g_heff_2eelab_2ereadback_2eforcedRb(v_mc_240));
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_mc_240; V a_1 = v_v_242; V r_ = (g_heff_2eelab_2evalue_2eforceEl(a_0, a_1)); heff_drop(v_mc_240); r_; });
  return (g_heff_2eelab_2ereadback_2ereadbTermF(v_t_243, v_n_241, v_t_244));
}
V g_heff_2eelab_2ereadback_2eforcedRb_24cpr_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = args[1];
  V v_mc_240 = heff_env(self)[0];
  V v_t_247 = (g_heff_2eelab_2ereadback_2eforcedRb(v_mc_240));
  heff_clo_take(self, 1);
  V v_t_248 = ({ V a_0 = v_mc_240; V a_1 = v_t_246; V r_ = (g_heff_2eelab_2evalue_2eforceTy(a_0, a_1)); heff_drop(v_mc_240); r_; });
  return (g_heff_2eelab_2ereadback_2ereadbTypeF(v_t_247, v_n_245, v_t_248));
}
Clo g_heff_2eelab_2ereadback_2eforcedRb_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2eforcedRb_entry, 1, 0};

V g_heff_2eelab_2ereadback_2eforcedRb(V v_mc_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2ereadback_2eforcedRb_24cpr(v_mc_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_el__ty, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2ereadback_2eforcedRb_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2eforcedRb(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(V v_mc_240) {
top: ;
  return ((HeffT2){{heff_clo_n(g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr_lam0, 2, 1, (V[]){heff_dup(v_mc_240)}), heff_clo_n(g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr_lam1, 2, 1, (V[]){heff_dup(v_mc_240)})}});
}
V g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr_lam0(V self, V *args) {
  V v_n_241 = args[0];
  V v_v_242 = args[1];
  V v_mc_240 = heff_env(self)[0];
  V v_t_243 = (g_heff_2eelab_2ereadback_2eshownForcedRb(v_mc_240));
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_mc_240; V a_1 = v_v_242; V r_ = (g_heff_2eelab_2evalue_2eforceEl(a_0, a_1)); heff_drop(v_mc_240); r_; });
  return (g_heff_2eelab_2ereadback_2ereadbTermF(v_t_243, v_n_241, v_t_244));
}
V g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = args[1];
  V v_mc_240 = heff_env(self)[0];
  V v_t_247 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_t_246));
  heff_clo_take(self, 1);
  V v_r_248 = ({ V a_0 = v_mc_240; V r_ = (g_heff_2eelab_2ereadback_2eshownForcedRb(a_0)); heff_drop(v_mc_240); r_; });
  V v_n_249 = v_n_245;
  V v_t_2410 = heff_dup(v_t_247);
  V v_x4_2430;
  switch (heff_tag_of(v_t_247)) {
  case TAG_VU: {
    heff_take_n(v_t_247, 0ULL, 1);
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    heff_take_n(v_t_247, 0ULL, 5);
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2422 = heff_field(v_t_247, 5);
    heff_take_n(v_t_247, 32ULL, 6);
    v_x4_2430 = v_folded_2422;
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_t_247, 0ULL, 4);
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_t_247, 0ULL, 1);
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_t_247, 0ULL, 1);
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_t_247, 0ULL, 1);
    v_x4_2430 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_x4_2430)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2ereadback_2ereadbTypeF(v_r_248, v_n_249, v_t_2410));
  }
  case TAG_Just: {
    V v_x41_2431 = heff_field(v_x4_2430, 0);
    V v_ru_24x4_2430_24Just = heff_take_reuse_n(v_x4_2430, 1ULL, 1);
    switch (heff_tag_of(v_x41_2431)) {
    case TAG_MkFolded: {
      V v_h_2432 = heff_field(v_x41_2431, 0);
      V v_sp_2433 = heff_field(v_x41_2431, 1);
      heff_take_n(v_x41_2431, 3ULL, 2);
      V v_sp_2434 = heff_tr(heff_call(v_sp_2433, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2435 = (g_heff_2eelab_2ereadback_2eappliedOnly(v_sp_2434));
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        heff_drop(v_t_2435);
        V v_t_2436 = (g_heff_2eelab_2ereadback_2ereadbBare(v_r_248, v_n_249, v_h_2432, v_sp_2434));
        return heff_tag_at_n(v_ru_24x4_2430_24Just, TAG_SDecode, 1, (V[]){v_t_2436});
      } else {
        heff_drop_cell(v_ru_24x4_2430_24Just, 1);
        heff_drop(v_h_2432);
        heff_drop(v_sp_2434);
        heff_drop(v_t_2435);
        return (g_heff_2eelab_2ereadback_2ereadbTypeF(v_r_248, v_n_249, v_t_2410));
      }
    }
    default: return heff_nomatch(v_x41_2431);
    }
  }
  default: return heff_nomatch(v_x4_2430);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam2(V self, V *args); static Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam2, 1, 0};
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_entry, 2, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VNeu: {
    V v_h_242 = heff_field(v_x3_241, 0);
    V v_sp_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    return (g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(v_n_240, v_h_242, v_sp_243));
  }
  case TAG_VCode: {
    V v_a_247 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCode = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_t_2427;
    switch (heff_tag_of(v_a_247)) {
    case TAG_VU: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFunction: {
      V v_folded_2419 = heff_dup(heff_field(v_a_247, 5));
      v_t_2427 = v_folded_2419;
      break;
    }
    case TAG_VRecord: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_2427 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_a_247);
    }
    V v_t_2428 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(v_n_240, v_a_247, v_t_2427));
    return heff_tag_at_n(v_ru_24x3_241_24VCode, TAG_SCode, 1, (V[]){v_t_2428});
  }
  case TAG_VLam: {
    V v_fty_2429 = heff_field(v_x3_241, 0);
    V v_body_2430 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24VLam = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2431 = heff_tr(heff_call(heff_dup(v_fty_2429), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2451;
    switch (heff_tag_of(v_t_2431)) {
    case TAG_VU: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFunction: {
      V v_folded_2443 = heff_dup(heff_field(v_t_2431, 5));
      v_t_2451 = v_folded_2443;
      break;
    }
    case TAG_VRecord: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2431);
    }
    V v_t_2452 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_dup(v_n_240), v_t_2431, v_t_2451));
    V v_n_2453 = v_n_240;
    V v_t_2454 = heff_tr(heff_call(v_fty_2429, 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_2455 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_2454)));
    V v_dom_2467;
    switch (heff_tag_of(v_t_2455)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2455, 0ULL, 1);
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeFunction: {
      V v_dom_2458 = heff_field(v_t_2455, 1);
      heff_take_n(v_t_2455, 2ULL, 4);
      heff_drop(v_t_2454);
      v_dom_2467 = v_dom_2458;
      break;
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2455, 0ULL, 3);
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2455, 0ULL, 1);
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeInt: {
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeFloat: {
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeString: {
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeRune: {
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2455, 0ULL, 1);
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2455, 0ULL, 1);
      v_dom_2467 = v_t_2454;
      break;
    }
    case TAG_NoRules: {
      v_dom_2467 = v_t_2454;
      break;
    }
    default: heff_nomatch(v_t_2455);
    }
    V v_x4_2468 = v_body_2430;
    V v_t_2488;
    switch (heff_tag_of(v_x4_2468)) {
    case TAG_MkClo: {
      V v_x_2469 = heff_field(v_x4_2468, 0);
      V v_l_2470 = heff_field(v_x4_2468, 1);
      V v_f_2471 = heff_field(v_x4_2468, 2);
      heff_take_n(v_x4_2468, 7ULL, 3);
      V v_n_2472 = heff_intAdd_lent(v_n_2453, MK_INT(1LL), 2);
      V v_v_2474 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_2453}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam0, 1, 1, (V[]){v_dom_2467}), NTAG(TAG_Nothing)));
      V v_x3_2476 = heff_tr(heff_call(v_f_2471, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_2470, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam1, 1, 1, (V[]){v_v_2474})})}));
      V v_t_2481;
      switch (heff_tag_of(v_x3_2476)) {
      case TAG_Nom: {
        V v_v_2477 = heff_field(v_x3_2476, 0);
        heff_take_n(v_x3_2476, 1ULL, 1);
        v_t_2481 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_2472, v_v_2477));
        break;
      }
      case TAG_Describe: {
        V v_v_2478 = heff_field(v_x3_2476, 0);
        heff_take_n(v_x3_2476, 1ULL, 1);
        v_t_2481 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_2472, v_v_2478));
        break;
      }
      case TAG_Become: {
        V v_v_2479 = heff_field(v_x3_2476, 0);
        V v_ru_24x3_2476_24Become = heff_take_reuse_n(v_x3_2476, 1ULL, 1);
        V v_t_2480 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_2472, v_v_2479));
        v_t_2481 = heff_tag_at_n(v_ru_24x3_2476_24Become, TAG_SIs, 1, (V[]){v_t_2480});
        break;
      }
      default: heff_nomatch(v_x3_2476);
      }
      v_t_2488 = heff_tag_at_n(v_ru_24x3_241_24VLam, TAG_MkAbs, 2, (V[]){v_x_2469, v_t_2481});
      break;
    }
    case TAG_CloConst: {
      V v_t_2482 = heff_field(v_x4_2468, 0);
      V v_ru_24x4_2468_24CloConst = heff_take_reuse_n(v_x4_2468, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_241_24VLam, 2);
      heff_drop(v_dom_2467);
      V v_t_2487;
      switch (heff_tag_of(v_t_2482)) {
      case TAG_Nom: {
        V v_v_2483 = heff_field(v_t_2482, 0);
        heff_take_n(v_t_2482, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2468_24CloConst, 1);
        v_t_2487 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_2453, v_v_2483));
        break;
      }
      case TAG_Describe: {
        V v_v_2484 = heff_field(v_t_2482, 0);
        heff_take_n(v_t_2482, 1ULL, 1);
        heff_drop_cell(v_ru_24x4_2468_24CloConst, 1);
        v_t_2487 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_2453, v_v_2484));
        break;
      }
      case TAG_Become: {
        V v_v_2485 = heff_field(v_t_2482, 0);
        heff_take_n(v_t_2482, 1ULL, 1);
        V v_t_2486 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(v_n_2453, v_v_2485));
        v_t_2487 = heff_tag_at_n(v_ru_24x4_2468_24CloConst, TAG_SIs, 1, (V[]){v_t_2486});
        break;
      }
      default: heff_nomatch(v_t_2482);
      }
      v_t_2488 = heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2487});
      break;
    }
    default: heff_nomatch(v_x4_2468);
    }
    return heff_tag_n(TAG_SLam, 2, (V[]){v_t_2452, v_t_2488});
  }
  case TAG_VCons: {
    V v_d_2489 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VCons = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2490 = heff_take_field(v_d_2489, 2);
    V v_m_2491 = heff_arrayLength_lent(v_xs_2490, 0);
    V v_t_24100;
    if ((heff_peek_word(v_m_2491) <= ((int64_t)0ULL))) {
      heff_drop(v_n_240);
      heff_drop_cell(v_ru_24x3_241_24VCons, 1);
      heff_drop(v_xs_2490);
      v_t_24100 = heff_arrayGenerate(v_m_2491, ((V)&g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam2_clo));
    } else {
      V v_x3_2493 = heff_arrayIndex_lent(v_xs_2490, MK_INT(0LL), 2);
      V v_y_2498;
      switch (heff_tag_of(v_x3_2493)) {
      case TAG_Nom: {
        V v_v_2494 = heff_field(v_x3_2493, 0);
        heff_take_n(v_x3_2493, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24VCons, 1);
        v_y_2498 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_2494));
        break;
      }
      case TAG_Describe: {
        V v_v_2495 = heff_field(v_x3_2493, 0);
        heff_take_n(v_x3_2493, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_241_24VCons, 1);
        v_y_2498 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_2495));
        break;
      }
      case TAG_Become: {
        V v_v_2496 = heff_field(v_x3_2493, 0);
        heff_take_n(v_x3_2493, 1ULL, 1);
        V v_t_2497 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_240), v_v_2496));
        v_y_2498 = heff_tag_at_n(v_ru_24x3_241_24VCons, TAG_SIs, 1, (V[]){v_t_2497});
        break;
      }
      default: heff_nomatch(v_x3_2493);
      }
      V v_t_2499 = heff_arrayKeepsAs_lent(v_xs_2490, v_y_2498, 0);
      if ((heff_dup(v_t_2499) == NTAG(TAG_True))) {
        heff_drop(v_m_2491);
        heff_drop(v_t_2499);
        v_t_24100 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24map0(v_n_240, MK_INT(1LL), heff_arraySet(v_xs_2490, MK_INT(0LL), v_y_2498)));
      } else {
        heff_drop(v_t_2499);
        v_t_24100 = ({ V a_0 = v_xs_2490; V a_1 = v_n_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2491, v_y_2498); V r_ = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2490); r_; });
      }
    }
    V v_t_24101 = ({ V rv_2 = v_t_24100; V rr_ = heff_rec_reuse_nf(v_d_2489, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SCons, 1, (V[]){v_t_24101});
  }
  case TAG_VOpaque: {
    heff_drop(v_n_240);
    return NTAG(TAG_SOpaque);
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(a[0], a[1]);
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam0(V self, V *args) {
  V v_u_2473 = args[0];
  V v_dom_2467 = heff_env(self)[0];
  heff_drop(v_u_2473);
  heff_clo_take(self, 1);
  return v_dom_2467;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam1(V self, V *args) {
  V v_u_2475 = args[0];
  V v_v_2474 = heff_env(self)[0];
  heff_drop(v_u_2475);
  heff_clo_take(self, 1);
  return v_v_2474;
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_lam2(V self, V *args) {
  V v_u_2492 = args[0];
  heff_drop(v_u_2492);
  return heff_abandon();
}
Clo g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0_entry, 4, 0};

V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0(V v_xs_240, V v_n_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_x3_244 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_242));
      V v_t_249;
      switch (heff_tag_of(v_x3_244)) {
      case TAG_Nom: {
        V v_v_245 = heff_field(v_x3_244, 0);
        v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_241), heff_dup(v_v_245)));
        break;
      }
      case TAG_Describe: {
        V v_v_246 = heff_field(v_x3_244, 0);
        v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_241), heff_dup(v_v_246)));
        break;
      }
      case TAG_Become: {
        V v_v_247 = heff_field(v_x3_244, 0);
        V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_241), heff_dup(v_v_247)));
        v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){v_t_248});
        break;
      }
      default: heff_nomatch(v_x3_244);
      }
      V t_0 = v_xs_240;
      V t_1 = v_n_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_249);
      v_xs_240 = t_0;
      v_n_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      heff_drop(v_n_241);
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_x3_244 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_242));
    V v_t_249;
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nom: {
      V v_v_245 = heff_field(v_x3_244, 0);
      v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_241), heff_dup(v_v_245)));
      break;
    }
    case TAG_Describe: {
      V v_v_246 = heff_field(v_x3_244, 0);
      v_t_249 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_241), heff_dup(v_v_246)));
      break;
    }
    case TAG_Become: {
      V v_v_247 = heff_field(v_x3_244, 0);
      V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397(heff_dup(v_n_241), heff_dup(v_v_247)));
      v_t_249 = heff_tag_n(TAG_SIs, 1, (V[]){v_t_248});
      break;
    }
    default: heff_nomatch(v_x3_244);
    }
    V t_0 = v_xs_240;
    V t_1 = v_n_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_249);
    v_xs_240 = t_0;
    v_n_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    heff_drop(v_n_241);
    return v_a_243;
  }
}
V g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2ereadback_2ereadbTermF_24s898362462x1944657397_24generate0(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_entry, 3, 0};

V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040(V v_n_240, V v_dom_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkClo: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_l_244 = heff_field(v_x4_242, 1);
    V v_f_245 = heff_field(v_x4_242, 2);
    heff_take_n(v_x4_242, 7ULL, 3);
    V v_n_246 = heff_intAdd_lent(v_n_240, MK_INT(1LL), 2);
    V v_v_248 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_lam0, 1, 1, (V[]){v_dom_241}), NTAG(TAG_Nothing)));
    V v_x3_2410 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_244, heff_clo_n(g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_lam1, 1, 1, (V[]){v_v_248})})}));
    V v_t_2475;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nom: {
      V v_a_2411 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Nom = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      V v_t_2431;
      switch (heff_tag_of(v_a_2411)) {
      case TAG_VU: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_2423 = heff_dup(heff_field(v_a_2411, 5));
        v_t_2431 = v_folded_2423;
        break;
      }
      case TAG_VRecord: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_2411);
      }
      v_t_2475 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(v_ru_24x3_2410_24Nom, v_n_246, v_a_2411, v_t_2431));
      break;
    }
    case TAG_Describe: {
      V v_a_2432 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Describe = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_a_2432)) {
      case TAG_VU: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_2444 = heff_dup(heff_field(v_a_2432, 5));
        v_t_2452 = v_folded_2444;
        break;
      }
      case TAG_VRecord: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_2432);
      }
      v_t_2475 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(v_ru_24x3_2410_24Describe, v_n_246, v_a_2432, v_t_2452));
      break;
    }
    case TAG_Become: {
      V v_a_2453 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Become = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      V v_t_2473;
      switch (heff_tag_of(v_a_2453)) {
      case TAG_VU: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_2465 = heff_dup(heff_field(v_a_2453, 5));
        v_t_2473 = v_folded_2465;
        break;
      }
      case TAG_VRecord: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_2473 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_2453);
      }
      V v_t_2474 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(v_n_246, v_a_2453, v_t_2473));
      v_t_2475 = heff_tag_at_n(v_ru_24x3_2410_24Become, TAG_SIsTy, 1, (V[]){v_t_2474});
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    return heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_243, v_t_2475});
  }
  case TAG_CloConst: {
    V v_t_2476 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CloConst = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_dom_241);
    V v_t_24141;
    switch (heff_tag_of(v_t_2476)) {
    case TAG_Nom: {
      V v_a_2477 = heff_field(v_t_2476, 0);
      V v_ru_24t_2476_24Nom = heff_take_reuse_n(v_t_2476, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      V v_t_2497;
      switch (heff_tag_of(v_a_2477)) {
      case TAG_VU: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_2489 = heff_dup(heff_field(v_a_2477, 5));
        v_t_2497 = v_folded_2489;
        break;
      }
      case TAG_VRecord: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_2477);
      }
      v_t_24141 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(v_ru_24t_2476_24Nom, v_n_240, v_a_2477, v_t_2497));
      break;
    }
    case TAG_Describe: {
      V v_a_2498 = heff_field(v_t_2476, 0);
      V v_ru_24t_2476_24Describe = heff_take_reuse_n(v_t_2476, 1ULL, 1);
      heff_drop_cell(v_ru_24x4_242_24CloConst, 1);
      V v_t_24118;
      switch (heff_tag_of(v_a_2498)) {
      case TAG_VU: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_24110 = heff_dup(heff_field(v_a_2498, 5));
        v_t_24118 = v_folded_24110;
        break;
      }
      case TAG_VRecord: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24118 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_2498);
      }
      v_t_24141 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(v_ru_24t_2476_24Describe, v_n_240, v_a_2498, v_t_24118));
      break;
    }
    case TAG_Become: {
      V v_a_24119 = heff_field(v_t_2476, 0);
      V v_ru_24t_2476_24Become = heff_take_reuse_n(v_t_2476, 1ULL, 1);
      V v_t_24139;
      switch (heff_tag_of(v_a_24119)) {
      case TAG_VU: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_24131 = heff_dup(heff_field(v_a_24119, 5));
        v_t_24139 = v_folded_24131;
        break;
      }
      case TAG_VRecord: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_24139 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_a_24119);
      }
      V v_t_24140 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(v_ru_24t_2476_24Become, v_n_240, v_a_24119, v_t_24139));
      v_t_24141 = heff_tag_at_n(v_ru_24x4_242_24CloConst, TAG_SIsTy, 1, (V[]){v_t_24140});
      break;
    }
    default: heff_nomatch(v_t_2476);
    }
    return heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_24141});
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_dom_241 = heff_env(self)[0];
  heff_drop(v_u_247);
  heff_clo_take(self, 1);
  return v_dom_241;
}
V g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_248 = heff_env(self)[0];
  heff_drop(v_u_249);
  heff_clo_take(self, 1);
  return v_v_248;
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_entry, 3, 0};

V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665(V v_i_240, V v_ls_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_f_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkField: {
      V v_ty_246 = heff_field(v_t_245, 0);
      V v_ru_24t_245_24MkField = heff_take_reuse_n(v_t_245, 1ULL, 2);
      V v_t_2427;
      switch (heff_tag_of(v_ty_246)) {
      case TAG_VU: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_2419 = heff_dup(heff_field(v_ty_246, 5));
        v_t_2427 = v_folded_2419;
        break;
      }
      case TAG_VRecord: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_2427 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_ty_246);
      }
      V v_t_2428 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_dup(v_i_240), heff_dup(v_ty_246), v_t_2427));
      V v_v_2430 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_lam0, 1, 1, (V[]){v_ty_246}), NTAG(TAG_Nothing)));
      V v_cell_2431 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2428, heff_hole()});
      V v_u_2433 = (g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), heff_tag_at_n(v_ru_24t_245_24MkField, TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_lam1, 1, 1, (V[]){v_v_2430})}), v_rest_244, v_cell_2431));
      heff_drop(v_u_2433);
      return v_cell_2431;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665(a[0], a[1], a[2]);
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_lam0(V self, V *args) {
  V v_u_2429 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_drop(v_u_2429);
  heff_clo_take(self, 1);
  return v_ty_246;
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_lam1(V self, V *args) {
  V v_u_2432 = args[0];
  V v_v_2430 = heff_env(self)[0];
  heff_drop(v_u_2432);
  heff_clo_take(self, 1);
  return v_v_2430;
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_lam0(V self, V *args);
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_lam1(V self, V *args);
Clo g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_entry, 4, 0};

V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps(V v_i_240, V v_ls_241, V v_x4_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_ls_241);
    return heff_setField(heff_dup(v_d_243), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x4_242, 0);
    V v_rest_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_ls_241)}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkField: {
      V v_ty_247 = heff_field(v_t_246, 0);
      V v_ru_24t_246_24MkField = heff_take_reuse_n(v_t_246, 1ULL, 2);
      V v_t_2428;
      switch (heff_tag_of(v_ty_247)) {
      case TAG_VU: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VDecode: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFunction: {
        V v_folded_2420 = heff_dup(heff_field(v_ty_247, 5));
        v_t_2428 = v_folded_2420;
        break;
      }
      case TAG_VRecord: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VSum: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimInt: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimFloat: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimString: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimRune: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VPrimArray: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_VFixed: {
        v_t_2428 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_ty_247);
      }
      V v_t_2429 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_dup(v_i_240), heff_dup(v_ty_247), v_t_2428));
      V v_v_2431 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_i_240)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_lam0, 1, 1, (V[]){v_ty_247}), NTAG(TAG_Nothing)));
      V v_cell_2432 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2429, heff_hole()});
      V v_u_2433 = heff_setFieldPeek(v_d_243, MK_INT(1LL), v_cell_2432);
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = heff_tag_at_n(v_ru_24t_246_24MkField, TAG_LSnoc, 2, (V[]){v_ls_241, heff_clo_n(g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_lam1, 1, 1, (V[]){v_v_2431})});
      V t_2 = v_rest_245;
      V t_3 = v_u_2433;
      v_i_240 = t_0;
      v_ls_241 = t_1;
      v_x4_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_lam0(V self, V *args) {
  V v_u_2430 = args[0];
  V v_ty_247 = heff_env(self)[0];
  heff_drop(v_u_2430);
  heff_clo_take(self, 1);
  return v_ty_247;
}
V g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665_24dps_lam1(V self, V *args) {
  V v_u_2434 = args[0];
  V v_v_2431 = heff_env(self)[0];
  heff_drop(v_u_2434);
  heff_clo_take(self, 1);
  return v_v_2431;
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_lam1(V self, V *args);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_lam0(V self, V *args);
Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_entry, 2, 0};

V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(V v_n_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_VU: {
    V v_u_242 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VU = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at_n(v_ru_24x3_241_24VU, TAG_SU, 1, (V[]){v_u_242});
  }
  case TAG_VDecode: {
    V v_h_243 = heff_field(v_x3_241, 0);
    V v_sp_244 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 5);
    V v_t_2413;
    switch (heff_tag_of(v_h_243)) {
    case TAG_HLocal: {
      V v_i_248 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HLocal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_249 = heff_intSub(heff_intSub_lent(v_n_240, v_i_248, 2), MK_INT(1LL));
      v_t_2413 = heff_tag_at_n(v_ru_24h_243_24HLocal, TAG_SLocal, 1, (V[]){v_t_249});
      break;
    }
    case TAG_HGlobal: {
      V v_x_2410 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HGlobal = heff_take_reuse_n(v_h_243, 1ULL, 1);
      v_t_2413 = heff_tag_at_n(v_ru_24h_243_24HGlobal, TAG_SGlobal, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_HMeta: {
      V v_m_2411 = heff_field(v_h_243, 0);
      V v_ru_24h_243_24HMeta = heff_take_reuse_n(v_h_243, 1ULL, 1);
      V v_t_2412 = heff_tag_at_n(v_ru_24h_243_24HMeta, TAG_SU, 1, (V[]){NTAG(TAG_SmallU)});
      v_t_2413 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_2411, heff_dup(g_array_2eempty_get()), v_t_2412});
      break;
    }
    case TAG_HError: {
      v_t_2413 = NTAG(TAG_SAbandon);
      break;
    }
    default: heff_nomatch(v_h_243);
    }
    V v_t_2414 = (g_heff_2eelab_2ereadback_2ereadbSpine_24s548322222x1964063001(v_n_240, v_sp_244, v_t_2413));
    return heff_tag_n(TAG_SDecode, 1, (V[]){v_t_2414});
  }
  case TAG_VFunction: {
    V v_level_2415 = heff_field(v_x3_241, 0);
    V v_dom_2416 = heff_field(v_x3_241, 1);
    V v_cod_2417 = heff_field(v_x3_241, 2);
    V v_implicit_2418 = heff_field(v_x3_241, 3);
    V v_dflt_2419 = heff_field(v_x3_241, 4);
    heff_take_n(v_x3_241, 31ULL, 6);
    V v_n_2421 = heff_dup(v_n_240);
    V v_t_2422 = heff_dup(v_dom_2416);
    V v_x4_2442;
    switch (heff_tag_of(v_dom_2416)) {
    case TAG_VU: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFunction: {
      V v_folded_2434 = heff_dup(heff_field(v_dom_2416, 5));
      v_x4_2442 = v_folded_2434;
      break;
    }
    case TAG_VRecord: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      v_x4_2442 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_dom_2416);
    }
    V v_t_2449;
    switch (heff_tag_of(v_x4_2442)) {
    case TAG_Nothing: {
      v_t_2449 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_2421, v_t_2422));
      break;
    }
    case TAG_Just: {
      V v_x41_2443 = heff_field(v_x4_2442, 0);
      V v_ru_24x4_2442_24Just = heff_take_reuse_n(v_x4_2442, 1ULL, 1);
      switch (heff_tag_of(v_x41_2443)) {
      case TAG_MkFolded: {
        V v_h_2444 = heff_field(v_x41_2443, 0);
        V v_sp_2445 = heff_field(v_x41_2443, 1);
        heff_take_n(v_x41_2443, 3ULL, 2);
        V v_sp_2446 = heff_tr(heff_call(v_sp_2445, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_2447 = (g_heff_2eelab_2ereadback_2eappliedOnly(v_sp_2446));
        if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
          heff_drop(v_t_2422);
          heff_drop(v_t_2447);
          V v_t_2448 = (g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(v_n_2421, v_h_2444, v_sp_2446));
          v_t_2449 = heff_tag_at_n(v_ru_24x4_2442_24Just, TAG_SDecode, 1, (V[]){v_t_2448});
        } else {
          heff_drop_cell(v_ru_24x4_2442_24Just, 1);
          heff_drop(v_h_2444);
          heff_drop(v_sp_2446);
          heff_drop(v_t_2447);
          v_t_2449 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_2421, v_t_2422));
        }
        break;
      }
      default: heff_nomatch(v_x41_2443);
      }
      break;
    }
    default: heff_nomatch(v_x4_2442);
    }
    V v_t_2450 = (g_heff_2eelab_2ereadback_2ereadbCloTy_24s788908554x1592793040(v_n_240, v_dom_2416, v_cod_2417));
    return heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2415, v_t_2449, v_t_2450, v_implicit_2418, v_dflt_2419});
  }
  case TAG_VRecord: {
    V v_level_2451 = heff_field(v_x3_241, 0);
    V v_capture_2452 = heff_field(v_x3_241, 1);
    V v_fieldTypes_2453 = heff_field(v_x3_241, 2);
    V v_defaults_2454 = heff_field(v_x3_241, 3);
    heff_take_n(v_x3_241, 15ULL, 4);
    V v_t_2455 = heff_arrayToList(heff_take_field(v_fieldTypes_2453, 2));
    V v_t_2456 = (g_heff_2eelab_2ereadback_2egoRT_24s456868910x1702533665(v_n_240, v_capture_2452, v_t_2455));
    V v_t_2457 = ({ V rv_2 = heff_arrayFromList(v_t_2456); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2453, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2451, v_t_2457, v_defaults_2454});
  }
  case TAG_VSum: {
    V v_st_2458 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VSum = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_xs_2459 = heff_take_field(v_st_2458, 2);
    V v_t_2493 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2459, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_lam0, 1, 2, (V[]){v_xs_2459, v_n_240}));
    V v_t_2494 = ({ V rv_2 = v_t_2493; V rr_ = heff_rec_reuse_nf(v_st_2458, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x3_241_24VSum, TAG_SSum, 1, (V[]){v_t_2494});
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimInt);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimFloat);
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimString);
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return NTAG(TAG_SPrimRune);
  }
  case TAG_VPrimArray: {
    V v_a_2495 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VPrimArray = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_n_2496 = v_n_240;
    V v_t_2497 = heff_dup(v_a_2495);
    V v_x4_24117;
    switch (heff_tag_of(v_a_2495)) {
    case TAG_VU: {
      heff_take_n(v_a_2495, 0ULL, 1);
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VDecode: {
      heff_take_n(v_a_2495, 0ULL, 5);
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFunction: {
      V v_folded_24109 = heff_field(v_a_2495, 5);
      heff_take_n(v_a_2495, 32ULL, 6);
      v_x4_24117 = v_folded_24109;
      break;
    }
    case TAG_VRecord: {
      heff_take_n(v_a_2495, 0ULL, 4);
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VSum: {
      heff_take_n(v_a_2495, 0ULL, 1);
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimInt: {
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimFloat: {
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimString: {
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimRune: {
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VPrimArray: {
      heff_take_n(v_a_2495, 0ULL, 1);
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_VFixed: {
      heff_take_n(v_a_2495, 0ULL, 1);
      v_x4_24117 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_a_2495);
    }
    V v_t_24124;
    switch (heff_tag_of(v_x4_24117)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x3_241_24VPrimArray, 1);
      v_t_24124 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_2496, v_t_2497));
      break;
    }
    case TAG_Just: {
      V v_x41_24118 = heff_field(v_x4_24117, 0);
      heff_take_n(v_x4_24117, 1ULL, 1);
      switch (heff_tag_of(v_x41_24118)) {
      case TAG_MkFolded: {
        V v_h_24119 = heff_field(v_x41_24118, 0);
        V v_sp_24120 = heff_field(v_x41_24118, 1);
        heff_take_n(v_x41_24118, 3ULL, 2);
        V v_sp_24121 = heff_tr(heff_call(v_sp_24120, 1, (V[]){NTAG(TAG_MkUnit)}));
        V v_t_24122 = (g_heff_2eelab_2ereadback_2eappliedOnly(v_sp_24121));
        if ((heff_dup(v_t_24122) == NTAG(TAG_True))) {
          heff_drop(v_t_2497);
          heff_drop(v_t_24122);
          V v_t_24123 = (g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(v_n_2496, v_h_24119, v_sp_24121));
          v_t_24124 = heff_tag_at_n(v_ru_24x3_241_24VPrimArray, TAG_SDecode, 1, (V[]){v_t_24123});
        } else {
          heff_drop_cell(v_ru_24x3_241_24VPrimArray, 1);
          heff_drop(v_h_24119);
          heff_drop(v_sp_24121);
          heff_drop(v_t_24122);
          v_t_24124 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_2496, v_t_2497));
        }
        break;
      }
      default: heff_nomatch(v_x41_24118);
      }
      break;
    }
    default: heff_nomatch(v_x4_24117);
    }
    return heff_tag_n(TAG_SPrimArray, 1, (V[]){v_t_24124});
  }
  case TAG_VFixed: {
    V v_w_24125 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24VFixed = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    heff_drop(v_n_240);
    return heff_tag_at_n(v_ru_24x3_241_24VFixed, TAG_SFixed, 1, (V[]){v_w_24125});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(a[0], a[1]);
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_lam1(V self, V *args) {
  V v_i_2462 = args[0];
  V v_xs_2461 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_arrayIndex(v_xs_2461, v_i_2462);
  V v_t_2464 = heff_tr(heff_call(v_t_2463, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_n_2465 = v_n_240;
  V v_t_2466 = heff_dup(v_t_2464);
  V v_x4_2486;
  switch (heff_tag_of(v_t_2464)) {
  case TAG_VU: {
    heff_take_n(v_t_2464, 0ULL, 1);
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    heff_take_n(v_t_2464, 0ULL, 5);
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2478 = heff_field(v_t_2464, 5);
    heff_take_n(v_t_2464, 32ULL, 6);
    v_x4_2486 = v_folded_2478;
    break;
  }
  case TAG_VRecord: {
    heff_take_n(v_t_2464, 0ULL, 4);
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    heff_take_n(v_t_2464, 0ULL, 1);
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    heff_take_n(v_t_2464, 0ULL, 1);
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    heff_take_n(v_t_2464, 0ULL, 1);
    v_x4_2486 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_2464);
  }
  switch (heff_tag_of(v_x4_2486)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_2465, v_t_2466));
  }
  case TAG_Just: {
    V v_x41_2487 = heff_field(v_x4_2486, 0);
    V v_ru_24x4_2486_24Just = heff_take_reuse_n(v_x4_2486, 1ULL, 1);
    switch (heff_tag_of(v_x41_2487)) {
    case TAG_MkFolded: {
      V v_h_2488 = heff_field(v_x41_2487, 0);
      V v_sp_2489 = heff_field(v_x41_2487, 1);
      heff_take_n(v_x41_2487, 3ULL, 2);
      V v_sp_2490 = heff_tr(heff_call(v_sp_2489, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_2491 = (g_heff_2eelab_2ereadback_2eappliedOnly(v_sp_2490));
      if ((heff_dup(v_t_2491) == NTAG(TAG_True))) {
        heff_drop(v_t_2466);
        heff_drop(v_t_2491);
        V v_t_2492 = (g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(v_n_2465, v_h_2488, v_sp_2490));
        return heff_tag_at_n(v_ru_24x4_2486_24Just, TAG_SDecode, 1, (V[]){v_t_2492});
      } else {
        heff_drop_cell(v_ru_24x4_2486_24Just, 1);
        heff_drop(v_h_2488);
        heff_drop(v_sp_2490);
        heff_drop(v_t_2491);
        return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_2465, v_t_2466));
      }
    }
    default: return heff_nomatch(v_x41_2487);
    }
  }
  default: return heff_nomatch(v_x4_2486);
  }
}
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_lam0(V self, V *args) {
  V v_i_2460 = args[0];
  V v_xs_2459 = heff_env(self)[0];
  V v_n_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2461 = heff_arrayIndex(v_xs_2459, v_i_2460);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2461, 0), heff_clo_n(g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015_lam1, 1, 2, (V[]){v_xs_2461, v_n_240}));
}
Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry, 3, 0};

V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V v_n_240, V v_t_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_240, v_t_241));
  }
  case TAG_Just: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24Just = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_MkFolded: {
      V v_h_244 = heff_field(v_x41_243, 0);
      V v_sp_245 = heff_field(v_x41_243, 1);
      heff_take_n(v_x41_243, 3ULL, 2);
      V v_sp_246 = heff_tr(heff_call(v_sp_245, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_247 = (g_heff_2eelab_2ereadback_2eappliedOnly(v_sp_246));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_241);
        heff_drop(v_t_247);
        V v_t_248 = (g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(v_n_240, v_h_244, v_sp_246));
        return heff_tag_at_n(v_ru_24x4_242_24Just, TAG_SDecode, 1, (V[]){v_t_248});
      } else {
        heff_drop_cell(v_ru_24x4_242_24Just, 1);
        heff_drop(v_h_244);
        heff_drop(v_sp_246);
        heff_drop(v_t_247);
        return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_240, v_t_241));
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry, 4, 0};

V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V v_tok_240, V v_n_241, V v_t_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop_cell(v_tok_240, 1);
    return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_241, v_t_242));
  }
  case TAG_Just: {
    V v_x41_244 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkFolded: {
      V v_h_245 = heff_field(v_x41_244, 0);
      V v_sp_246 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      V v_sp_247 = heff_tr(heff_call(v_sp_246, 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_t_248 = (g_heff_2eelab_2ereadback_2eappliedOnly(v_sp_247));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_242);
        heff_drop(v_t_248);
        V v_t_249 = (g_heff_2eelab_2ereadback_2ereadbBare_24s296181450x587997885(v_n_241, v_h_245, v_sp_247));
        return heff_tag_at_n(v_tok_240, TAG_SDecode, 1, (V[]){v_t_249});
      } else {
        heff_drop_cell(v_tok_240, 1);
        heff_drop(v_h_245);
        heff_drop(v_sp_247);
        heff_drop(v_t_248);
        return (g_heff_2eelab_2ereadback_2ereadbTypeF_24s2082214238x1070847015(v_n_241, v_t_242));
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(a[0], a[1], a[2], a[3]);
}