// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetMut 54984
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Seg 30433
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_blank 295177582
#define LBL_col 308218
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_lead 9813027
#define LBL_raw 322210
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efmt_2elayout_2eblankLine_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V);
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V);
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo;
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V, V);
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitem(V, V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitem_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitem_clo;
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V, V, V);
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo;
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V, V);
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo;
V g_heff_2esyntax_2efmt_2elayout_2enearGo(V, V);
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo;
V g_heff_2esyntax_2efmt_2elayout_2etfDoc(V, V);
V g_heff_2esyntax_2efmt_2elayout_2etfDoc_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2etfDoc_clo;
V g_heff_2esyntax_2efmt_2elex_2edashesEnd(V, V);
V g_heff_2esyntax_2efmt_2elex_2edashesEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2edashesEnd_clo;
V g_heff_2esyntax_2efmt_2elex_2esymChars_get(void);
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2eemptyDoc_get(void);
V g_std_2edoc_2ehardline_get(void);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Atom: {
    return NTAG(TAG_False);
  }
  case TAG_EParen: {
    return NTAG(TAG_False);
  }
  case TAG_Named: {
    return NTAG(TAG_False);
  }
  case TAG_Tup: {
    return NTAG(TAG_False);
  }
  case TAG_Seg: {
    return NTAG(TAG_False);
  }
  case TAG_Braces: {
    return NTAG(TAG_False);
  }
  case TAG_Update: {
    return NTAG(TAG_False);
  }
  case TAG_EUSet: {
    return NTAG(TAG_False);
  }
  case TAG_InstB: {
    return NTAG(TAG_False);
  }
  case TAG_EFSet: {
    return NTAG(TAG_False);
  }
  case TAG_EFDefault: {
    return NTAG(TAG_False);
  }
  case TAG_Sum: {
    return NTAG(TAG_False);
  }
  case TAG_ECon: {
    return NTAG(TAG_False);
  }
  case TAG_EField: {
    return NTAG(TAG_False);
  }
  case TAG_ENeg: {
    return NTAG(TAG_False);
  }
  case TAG_ETilde: {
    return NTAG(TAG_False);
  }
  case TAG_App: {
    return NTAG(TAG_False);
  }
  case TAG_Op: {
    return NTAG(TAG_False);
  }
  case TAG_Ops: {
    return NTAG(TAG_False);
  }
  case TAG_OpRhs: {
    V v_op_2461 = heff_field(v_x1_240, 0);
    V v_e_2462 = heff_field(v_x1_240, 1);
    V v_t_2463 = heff_dup(heff_rfield(v_op_2461, 6));
    if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
      heff_drop(v_t_2463);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2463);
      V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_e_2462));
      return heff_get_n(v_t_2464, 6, 9);
    }
  }
  case TAG_Ann: {
    return NTAG(TAG_False);
  }
  case TAG_BVar: {
    return NTAG(TAG_False);
  }
  case TAG_BImp: {
    return NTAG(TAG_False);
  }
  case TAG_BAnn: {
    return NTAG(TAG_False);
  }
  case TAG_BPat: {
    return NTAG(TAG_False);
  }
  case TAG_Lam: {
    return NTAG(TAG_False);
  }
  case TAG_Case: {
    return NTAG(TAG_False);
  }
  case TAG_EAlt: {
    return NTAG(TAG_False);
  }
  case TAG_If: {
    return NTAG(TAG_False);
  }
  case TAG_Do: {
    return NTAG(TAG_False);
  }
  case TAG_ESBind: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ELetElse: {
    return NTAG(TAG_False);
  }
  case TAG_ELetMut: {
    return NTAG(TAG_False);
  }
  case TAG_EAssign: {
    return NTAG(TAG_False);
  }
  case TAG_EWhile: {
    return NTAG(TAG_False);
  }
  case TAG_EFor: {
    return NTAG(TAG_False);
  }
  case TAG_EJump: {
    return NTAG(TAG_False);
  }
  case TAG_EReturn: {
    return NTAG(TAG_False);
  }
  case TAG_ENest: {
    return NTAG(TAG_False);
  }
  case TAG_EArrow: {
    return NTAG(TAG_False);
  }
  case TAG_IfThen: {
    return NTAG(TAG_False);
  }
  case TAG_ETry: {
    return NTAG(TAG_False);
  }
  case TAG_ECatch: {
    return NTAG(TAG_False);
  }
  case TAG_EWith: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2ebrokenAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2ebrokenAt(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str3, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str5, 0, "");
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args);
Clo g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry, 3, 0};

V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(V v_env_240, V v_i_241, V v_x6_242) {
top: ;
  switch (heff_tag_of(v_x6_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_env_240, 7);
    heff_drop(v_i_241);
    return heff_dup(g_std_2edoc_2eemptyDoc_get());
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x6_242, 0);
    V v_xs_244 = heff_field(v_x6_242, 1);
    V v_t_2422;
    if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
      V v_t_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkTF: {
        V v_xs_245 = heff_field(v_x_243, 0);
        switch (heff_tag_of(v_xs_245)) {
        case TAG_Nil: {
          v_t_2412 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
          break;
        }
        case TAG_Cons: {
          V v_x_2410 = heff_field(v_xs_245, 0);
          v_t_2412 = heff_dup(v_x_2410);
          break;
        }
        default: heff_nomatch(v_xs_245);
        }
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_ix_2413 = heff_take_field(v_t_2412, 7);
      V v_blank_2414 = heff_get_n(v_t_2412, 8, 9);
      HeffT2 v_t_2415 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_env_240, 1), v_ix_2413));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2421;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_x_2418 = v_field_2417;
          switch (heff_tag_of(v_x_2418)) {
          case TAG_Nil: {
            v_t_2421 = v_blank_2414;
            break;
          }
          case TAG_Cons: {
            V v_x_2419 = heff_field(v_x_2418, 0);
            heff_take_n(v_x_2418, 1ULL, 2);
            heff_drop(v_blank_2414);
            v_t_2421 = heff_get_n(v_x_2419, 1, 2);
            break;
          }
          default: heff_nomatch(v_x_2418);
          }
        } else {
          heff_drop(v_field_2417);
          v_t_2421 = v_blank_2414;
        }
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          v_t_2422 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2eblankLine_get());
        } else {
          heff_drop(v_t_2421);
          v_t_2422 = heff_dup(g_std_2edoc_2eemptyDoc_get());
        }
      }
    } else {
      v_t_2422 = heff_dup(g_std_2edoc_2eemptyDoc_get());
    }
    V v_t_2430;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_xs_2423 = heff_field(v_x_243, 0);
      switch (heff_tag_of(v_xs_2423)) {
      case TAG_Nil: {
        v_t_2430 = heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str3), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str4), ((V)&g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_str5), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
        break;
      }
      case TAG_Cons: {
        V v_x_2428 = heff_field(v_xs_2423, 0);
        v_t_2430 = heff_dup(v_x_2428);
        break;
      }
      default: heff_nomatch(v_xs_2423);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2439;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkTF: {
      V v_ty_2434 = heff_field(v_x_243, 3);
      V v_x15_2435 = heff_field(v_x_243, 4);
      switch (heff_tag_of(v_x15_2435)) {
      case TAG_Nothing: {
        v_t_2439 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_ty_2434)));
        break;
      }
      case TAG_Just: {
        V v_x151_2436 = heff_field(v_x15_2435, 0);
        switch (heff_tag_of(v_x151_2436)) {
        case TAG_MkPair: {
          V v_d_2438 = heff_field(v_x151_2436, 1);
          v_t_2439 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_d_2438)));
          break;
        }
        default: heff_nomatch(v_x151_2436);
        }
        break;
      }
      default: heff_nomatch(v_x15_2435);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2441 = (g_heff_2esyntax_2efmt_2elayout_2eitem(heff_dup(v_env_240), v_t_2430, v_t_2439, heff_clo_n(g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0, 1, 1, (V[]){heff_dup(v_x_243)})));
    V v_t_2442 = (g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(v_env_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_xs_244));
    V v_t_2443 = (g_std_2edoc_2e_3c_3e(v_t_2441, v_t_2442));
    V v_t_2444 = (g_std_2edoc_2e_3c_3e(v_t_2422, v_t_2443));
    return (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_2444));
  }
  default: return heff_nomatch(v_x6_242);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2esyntax_2efmt_2elayout_2eitemsGo_24s1613269524x672160886_lam0(V self, V *args) {
  V v_e_2440 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_e_2440; V a_1 = v_x_243; V r_ = (g_heff_2esyntax_2efmt_2elayout_2etfDoc(a_0, a_1)); heff_drop(v_x_243); r_; });
}
Clo g_heff_2esyntax_2efmt_2elayout_2enearGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2enearGo_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2enearGo(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_cs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_c_242, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_cs_243);
      heff_drop(v_t_244);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_cs_243;
      V t_1 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_c_242, v_acc_241});
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2enearGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2efmt_2elayout_2enearGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(V v_s_240, V v_j_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_j_241, 0)) == ((int64_t)45ULL))) {
    V v_t_242 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_s_240, heff_dup(v_j_241)));
    V v_x_243 = heff_intSub(v_t_242, heff_dup(v_j_241));
    if (heff_intLe_c(MK_INT(2LL), v_x_243)) {
      V v_t_244 = (g_heff_2esyntax_2efmt_2elex_2edashesEnd(v_s_240, v_j_241));
      V v_c_245 = heff_strByteAt_lent(v_s_240, v_t_244, 2);
      V v_ret_24bool = heff_bool(((((int64_t)0ULL) <= heff_peek_word(v_c_245)) ? ({ V v_t_246 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_245)))); int c_ = ({ V v_t_247 = heff_strFind(heff_dup(v_t_246), heff_dup(g_heff_2esyntax_2efmt_2elex_2esymChars_get()), MK_INT(0LL)); int c_ = !heff_intLe_c_lent(MK_INT(0LL), v_t_247, 1); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; }) : 1));
      heff_drop(v_c_245);
      return v_ret_24bool;
    } else {
      heff_drop(v_j_241);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_j_241);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2elineCmtAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2elineCmtAt(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str0, 2, "--");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str1, 4, "-- |");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str3, 4, "-- |");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str4, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eexpectLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry, 2, 0};

V g_heff_2esyntax_2efmt_2elayout_2eexpectLine(V v_doc_240, V v_c_241) {
top: ;
  V v_blank_242 = heff_take_field(v_c_241, 1);
  V v_text_243 = heff_get_n(v_c_241, 0, 2);
  if (!(heff_dup(v_blank_242) == NTAG(TAG_True))) {
    heff_drop(v_blank_242);
    if (heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str0))) {
      if ((heff_dup(v_doc_240) == NTAG(TAG_True))) {
        if (heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str1))) {
          V v_s_244 = heff_strSlice(heff_dup(v_text_243), MK_INT(4LL), heff_strLength(v_text_243));
          V v_t_245 = (g_prelude_2eskipSpaces(v_s_244, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
          V v_t_247 = (g_prelude_2eskipSpaces(v_s_244, heff_box_word(v_t_246), MK_INT(-1LL)));
          V v_t_248 = heff_strSlice(v_s_244, v_t_245, heff_intAdd(v_t_247, MK_INT(1LL)));
          V v_x1_249 = heff_bool(heff_strEq_c_lent(v_t_248, ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str2), 2));
          heff_drop(v_t_248);
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
          heff_drop(v_x1_249);
          return v_ret_24bool;
        } else {
          heff_drop(v_text_243);
          return NTAG(TAG_False);
        }
      } else {
        if (!heff_strEq_c(heff_strSlice_lent(v_text_243, MK_INT(0LL), MK_INT(4LL), 6), ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str3))) {
          V v_s_2410 = heff_strSlice(heff_dup(v_text_243), MK_INT(2LL), heff_strLength(v_text_243));
          V v_t_2411 = (g_prelude_2eskipSpaces(v_s_2410, MK_INT(0LL), MK_INT(1LL)));
          int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_s_2410, 0)) - ((int64_t)1ULL));
          V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2410, heff_box_word(v_t_2412), MK_INT(-1LL)));
          V v_t_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
          V v_x1_2415 = heff_bool(heff_strEq_c_lent(v_t_2414, ((V)&g_heff_2esyntax_2efmt_2elayout_2eexpectLine_str4), 2));
          heff_drop(v_t_2414);
          V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2415) == NTAG(TAG_True)));
          heff_drop(v_x1_2415);
          return v_ret_24bool;
        } else {
          heff_drop(v_text_243);
          return NTAG(TAG_False);
        }
      }
    } else {
      heff_drop(v_text_243);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop(v_blank_242);
    heff_drop(v_text_243);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eexpectLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eexpectLine(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2efmt_2elayout_2eeofOf_str2, 0, "");
Clo g_heff_2esyntax_2efmt_2elayout_2eeofOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry, 1, 0};

V g_heff_2esyntax_2efmt_2elayout_2eeofOf(V v_ts_240) {
top: ;
  int64_t v_i_241 = (heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0)) - ((int64_t)1ULL));
  if (((((int64_t)0ULL) <= v_i_241) && (v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_242 = heff_arrayIndex_lent(v_ts_240, heff_box_word(v_i_241), 2);
    return v_t_242;
  } else {
    return heff_rec_n(9, shape_kind__text__raw__start__end__col__first__ix__blank, (V[]){((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str0), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str1), ((V)&g_heff_2esyntax_2efmt_2elayout_2eeofOf_str2), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), MK_INT(-1LL), NTAG(TAG_False)});
  }
}
V g_heff_2esyntax_2efmt_2elayout_2eeofOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2efmt_2elayout_2eeofOf(a0); heff_drop(a0); return r;
}