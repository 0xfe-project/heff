// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SmallU 20221
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_args 9498020
#define LBL_binders 123633223
#define LBL_body 9524841
#define LBL_byName 571997869
#define LBL_ctx 308385
#define LBL_def 308863
#define LBL_head 9693863
#define LBL_hide 9697801
#define LBL_im 10123
#define LBL_indent 762902487
#define LBL_inner 301714032
#define LBL_keys 9783995
#define LBL_large 304101205
#define LBL_n 328
#define LBL_names 305943394
#define LBL_out 319944
#define LBL_params 951713969
#define LBL_rest 9992347
#define LBL_values 1123329101
static uint32_t shape_head__args[] = {LBL_head, LBL_args};
static uint32_t shape_im__indent[] = {LBL_im, LBL_indent};
static uint32_t shape_n__inner[] = {LBL_n, LBL_inner};
static uint32_t shape_names__binders__body[] = {LBL_names, LBL_binders, LBL_body};
static uint32_t shape_names__hide[] = {LBL_names, LBL_hide};
static uint32_t shape_names__out[] = {LBL_names, LBL_out};
static uint32_t shape_names__rest__ctx[] = {LBL_names, LBL_rest, LBL_ctx};
static uint32_t shape_params__names__def__large[] = {LBL_params, LBL_names, LBL_def, LBL_large};
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(V, V, V);
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_clo;
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_clo;
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_clo;
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_clo;
V g_heff_2esyntax_2epsurface_2earrayNone_get(void);
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_clo;
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_clo;
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(V, V, V, V, V, V);
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo;
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo;
V g_heff_2esyntax_2epsurface_2eformerAt(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eformerAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerAt_clo;
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988(V, V, V);
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_clo;
V g_heff_2esyntax_2epsurface_2eformerParam(V, V, V);
V g_heff_2esyntax_2epsurface_2eformerParam_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eformerParam_clo;
V g_heff_2esyntax_2epsurface_2eimplicitGroup(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eimplicitGroup_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eimplicitGroup_clo;
V g_heff_2esyntax_2epsurface_2eimplicitName(V, V, V);
V g_heff_2esyntax_2epsurface_2eimplicitName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eimplicitName_clo;
V g_heff_2esyntax_2epsurface_2eisOperator(V);
V g_heff_2esyntax_2epsurface_2eisOperator_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eisOperator_clo;
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(V, V, V, V);
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_clo;
V g_heff_2esyntax_2epsurface_2elambdas(V, V, V);
V g_heff_2esyntax_2epsurface_2elambdas_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elambdas_clo;
V g_heff_2esyntax_2epsurface_2elistItems(V);
V g_heff_2esyntax_2epsurface_2elistItems_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elistItems_clo;
V g_heff_2esyntax_2epsurface_2elocalName(V, V);
V g_heff_2esyntax_2epsurface_2elocalName_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2elocalName_clo;
V g_heff_2esyntax_2epsurface_2enth(V, V);
V g_heff_2esyntax_2epsurface_2enth_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2enth_clo;
V g_heff_2esyntax_2epsurface_2eopApp(V, V, V);
V g_heff_2esyntax_2epsurface_2eopApp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eopApp_clo;
V g_heff_2esyntax_2epsurface_2eopHead(V);
V g_heff_2esyntax_2epsurface_2eopHead_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eopHead_clo;
V g_heff_2esyntax_2epsurface_2eoperatorGo(V, V, V);
V g_heff_2esyntax_2epsurface_2eoperatorGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eoperatorGo_clo;
V g_heff_2esyntax_2epsurface_2eplainImplicits_get(void);
V g_heff_2esyntax_2epsurface_2eprimitiveOf(V);
V g_heff_2esyntax_2epsurface_2eprimitiveOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eprimitiveOf_clo;
V g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761(V, V, V, V);
V g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_clo;
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(V, V, V, V);
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_clo;
V g_heff_2esyntax_2epsurface_2espineGo(V, V);
V g_heff_2esyntax_2epsurface_2espineGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2espineGo_clo;
V g_heff_2esyntax_2epsurface_2estripIs(V);
V g_heff_2esyntax_2epsurface_2estripIs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2estripIs_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_clo;
V g_heff_2esyntax_2epsurface_2etypeFormer(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etypeFormer_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etypeFormer_clo;
V g_heff_2esyntax_2epsurface_2eunIsTy(V);
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo;
V g_heff_2esyntax_2epsurface_2ewordOf(V);
V g_heff_2esyntax_2epsurface_2ewordOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2ewordOf_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_heff_2eutil_2erune_2equoteGo(V, V, V);
V g_heff_2eutil_2erune_2equoteGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoteGo_clo;
V g_heff_2eutil_2erune_2equoted(V);
V g_heff_2eutil_2erune_2equoted_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2equoted_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2ereplicate(V, V);
V g_list_2ereplicate_entry(V self, V *a);
extern Clo g_list_2ereplicate_clo;
V g_list_2etake(V, V);
V g_list_2etake_entry(V self, V *a);
extern Clo g_list_2etake_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;

static V g_heff_2esyntax_2epsurface_2earrayNone_val;
static HEFF_ONCE g_heff_2esyntax_2epsurface_2earrayNone_st;
static V g_heff_2esyntax_2epsurface_2earrayNone_init(void) {
  return heff_arrayFromList(NTAG(TAG_Nil));
}
V g_heff_2esyntax_2epsurface_2earrayNone_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epsurface_2earrayNone_st)) return g_heff_2esyntax_2epsurface_2earrayNone_val;
  return heff_global(&g_heff_2esyntax_2epsurface_2earrayNone_val, &g_heff_2esyntax_2epsurface_2earrayNone_st, g_heff_2esyntax_2epsurface_2earrayNone_init);
}
V g_heff_2esyntax_2epsurface_2eplainImplicits_lam0(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2eplainImplicits_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eplainImplicits_lam0, 2, 0};

static V g_heff_2esyntax_2epsurface_2eplainImplicits_val;
static HEFF_ONCE g_heff_2esyntax_2epsurface_2eplainImplicits_st;
static V g_heff_2esyntax_2epsurface_2eplainImplicits_init(void) {
  return heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2eplainImplicits_lam0_clo), NTAG(TAG_True)});
}
V g_heff_2esyntax_2epsurface_2eplainImplicits_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2epsurface_2eplainImplicits_st)) return g_heff_2esyntax_2epsurface_2eplainImplicits_val;
  return heff_global(&g_heff_2esyntax_2epsurface_2eplainImplicits_val, &g_heff_2esyntax_2epsurface_2eplainImplicits_st, g_heff_2esyntax_2epsurface_2eplainImplicits_init);
}
V g_heff_2esyntax_2epsurface_2eplainImplicits_lam0(V self, V *args) {
  V v_xs_240 = args[0];
  V v_e_241 = args[1];
  heff_drop(v_xs_240);
  heff_drop(v_e_241);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str0, 4, "plus");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str1, 5, "minus");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str2, 5, "times");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str3, 5, "slash");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str4, 7, "percent");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str5, 2, "eq");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str6, 2, "lt");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str7, 2, "gt");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str8, 3, "amp");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str9, 3, "bar");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str10, 4, "bang");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str11, 5, "caret");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str12, 1, "q");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str13, 2, "at");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str14, 4, "hash");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str15, 6, "dollar");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str16, 5, "tilde");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str17, 5, "colon");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str18, 3, "dot");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ewordOf_str19, 9, "backslash");
Clo g_heff_2esyntax_2epsurface_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2ewordOf_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2ewordOf(V v_c_240) {
top: ;
  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(43LL))) {
    heff_drop(v_c_240);
    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str0)});
  } else {
    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(45LL))) {
      heff_drop(v_c_240);
      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str1)});
    } else {
      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(42LL))) {
        heff_drop(v_c_240);
        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str2)});
      } else {
        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(47LL))) {
          heff_drop(v_c_240);
          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str3)});
        } else {
          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(37LL))) {
            heff_drop(v_c_240);
            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str4)});
          } else {
            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(61LL))) {
              heff_drop(v_c_240);
              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str5)});
            } else {
              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(60LL))) {
                heff_drop(v_c_240);
                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str6)});
              } else {
                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(62LL))) {
                  heff_drop(v_c_240);
                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str7)});
                } else {
                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(38LL))) {
                    heff_drop(v_c_240);
                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str8)});
                  } else {
                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(124LL))) {
                      heff_drop(v_c_240);
                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str9)});
                    } else {
                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(33LL))) {
                        heff_drop(v_c_240);
                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str10)});
                      } else {
                        if (heff_intEq_c(heff_dup(v_c_240), MK_INT(94LL))) {
                          heff_drop(v_c_240);
                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str11)});
                        } else {
                          if (heff_intEq_c(heff_dup(v_c_240), MK_INT(63LL))) {
                            heff_drop(v_c_240);
                            return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str12)});
                          } else {
                            if (heff_intEq_c(heff_dup(v_c_240), MK_INT(64LL))) {
                              heff_drop(v_c_240);
                              return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str13)});
                            } else {
                              if (heff_intEq_c(heff_dup(v_c_240), MK_INT(35LL))) {
                                heff_drop(v_c_240);
                                return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str14)});
                              } else {
                                if (heff_intEq_c(heff_dup(v_c_240), MK_INT(36LL))) {
                                  heff_drop(v_c_240);
                                  return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str15)});
                                } else {
                                  if (heff_intEq_c(heff_dup(v_c_240), MK_INT(126LL))) {
                                    heff_drop(v_c_240);
                                    return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str16)});
                                  } else {
                                    if (heff_intEq_c(heff_dup(v_c_240), MK_INT(58LL))) {
                                      heff_drop(v_c_240);
                                      return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str17)});
                                    } else {
                                      if (heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL))) {
                                        heff_drop(v_c_240);
                                        return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str18)});
                                      } else {
                                        if (heff_intEq_c(v_c_240, MK_INT(92LL))) {
                                          return heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2esyntax_2epsurface_2ewordOf_str19)});
                                        } else {
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2epsurface_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2ewordOf(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eoperatorGo_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241))) {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return heff_tag_n(TAG_Just, 1, (V[]){(g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242))});
  } else {
    V v_t_244 = (g_heff_2esyntax_2epsurface_2ewordOf(heff_strByteAt(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_w_245, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
}
V g_heff_2esyntax_2epsurface_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eoperatorGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eisOperator_str3, 3, "op_");
Clo g_heff_2esyntax_2epsurface_2eisOperator_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eisOperator_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eisOperator(V v_x_240) {
top: ;
  V v_x3_247;
  if (heff_strEq_c(heff_dup(v_x_240), ((V)&g_heff_2esyntax_2epsurface_2eisOperator_str0))) {
    heff_drop(v_x_240);
    v_x3_247 = NTAG(TAG_Nothing);
  } else {
    V v_x1_242 = (g_heff_2esyntax_2epsurface_2eoperatorGo(v_x_240, MK_INT(0LL), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_x1_242)) {
    case TAG_Nothing: {
      v_x3_247 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_ws_243 = heff_field(v_x1_242, 0);
      V v_ru_24x1_242_24Just = heff_take_reuse_n(v_x1_242, 1ULL, 1);
      V v_t_246;
      switch (heff_tag_of(v_ws_243)) {
      case TAG_Nil: {
        v_t_246 = ((V)&g_heff_2esyntax_2epsurface_2eisOperator_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_244 = heff_field(v_ws_243, 0);
        V v_xs_245 = heff_field(v_ws_243, 1);
        heff_take_n(v_ws_243, 3ULL, 2);
        v_t_246 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eisOperator_str2); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
        break;
      }
      default: heff_nomatch(v_ws_243);
      }
      v_x3_247 = heff_tag_at_n(v_ru_24x1_242_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eisOperator_str3), v_t_246)});
      break;
    }
    default: heff_nomatch(v_x1_242);
    }
  }
  switch (heff_tag_of(v_x3_247)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_247, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_247);
  }
}
V g_heff_2esyntax_2epsurface_2eisOperator_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eisOperator(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2enth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2enth_entry, 2, 0};

V g_heff_2esyntax_2epsurface_2enth(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2enth_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epsurface_2enth(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str0, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str1, 1, "'");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elocalName_str3, 0, "");
V g_heff_2esyntax_2epsurface_2elocalName_lam0(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2elocalName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elocalName_entry, 2, 0};

V g_heff_2esyntax_2epsurface_2elocalName(V v_xs_240, V v_i_241) {
top: ;
  V v_t_242 = (g_heff_2esyntax_2epsurface_2enth(v_xs_240, heff_dup(v_i_241)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop(v_xs_240);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elocalName_str0), heff_intShow(v_i_241));
  }
  case TAG_Just: {
    V v_x_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_t_244 = (g_list_2etake(v_i_241, v_xs_240));
    V v_xs_246 = (g_list_2efilter(heff_clo_n(g_heff_2esyntax_2epsurface_2elocalName_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_t_244));
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_246; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    V v_x2_248 = (g_list_2ereplicate(v_t_247, ((V)&g_heff_2esyntax_2epsurface_2elocalName_str1)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2esyntax_2epsurface_2elocalName_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2elocalName_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    return heff_strAppend(v_x_243, v_t_2411);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2epsurface_2elocalName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2elocalName(a[0], a[1]);
}
V g_heff_2esyntax_2epsurface_2elocalName_lam0(V self, V *args) {
  V v_y_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_y_245, v_x_243);
}
Clo g_heff_2esyntax_2epsurface_2espineGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2espineGo_entry, 2, 0};

V g_heff_2esyntax_2epsurface_2espineGo(V v_h_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_h_240)) {
  case TAG_SLocal: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SGlobal: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCode: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_h_240, 0);
    V v_a_246 = heff_field(v_h_240, 1);
    V v_ru_24h_240_24SApp = heff_take_reuse_n(v_h_240, 3ULL, 2);
    V t_0 = v_f_245;
    V t_1 = heff_tag_at_n(v_ru_24h_240_24SApp, TAG_Cons, 2, (V[]){v_a_246, v_acc_241});
    v_h_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  case TAG_SLam: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SCons: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SProj: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_STag: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMatch: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SIs: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SOpaque: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SAbandon: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SRec: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SFix: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SImplicit: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SPrim: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitInt: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitString: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitRune: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(2, shape_head__args, (V[]){v_h_240, v_acc_241});
  }
  default: return heff_nomatch(v_h_240);
  }
}
V g_heff_2esyntax_2epsurface_2espineGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2espineGo(a[0], a[1]);
}
Clo g_heff_2esyntax_2epsurface_2eimplicitName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eimplicitName_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eimplicitName(V v_names_240, V v_i_241, V v_a_242) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_SLocal: {
    V v_x1_244 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Just = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      switch (heff_tag_of(v_m_245)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_244_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_246 = heff_field(v_m_245, 0);
        heff_take_n(v_m_245, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_244_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_246, v_a_242})});
      }
      default: return heff_nomatch(v_m_245);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_SGlobal: {
    V v_x1_248 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Just = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      switch (heff_tag_of(v_m_249)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_248_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2410 = heff_field(v_m_249, 0);
        heff_take_n(v_m_249, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2410, v_a_242})});
      }
      default: return heff_nomatch(v_m_249);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_SCode: {
    V v_x1_2412 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2413 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Just = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      switch (heff_tag_of(v_m_2413)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2412_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2414 = heff_field(v_m_2413, 0);
        heff_take_n(v_m_2413, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2412_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2414, v_a_242})});
      }
      default: return heff_nomatch(v_m_2413);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  case TAG_SApp: {
    V v_x1_2417 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2418 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      switch (heff_tag_of(v_m_2418)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2417_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2419 = heff_field(v_m_2418, 0);
        heff_take_n(v_m_2418, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2417_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2419, v_a_242})});
      }
      default: return heff_nomatch(v_m_2418);
      }
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  case TAG_SLam: {
    V v_x1_2422 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2423 = heff_field(v_x1_2422, 0);
      V v_ru_24x1_2422_24Just = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
      switch (heff_tag_of(v_m_2423)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2422_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2424 = heff_field(v_m_2423, 0);
        heff_take_n(v_m_2423, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2422_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2424, v_a_242})});
      }
      default: return heff_nomatch(v_m_2423);
      }
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  case TAG_SCons: {
    V v_x1_2426 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2426)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2427 = heff_field(v_x1_2426, 0);
      V v_ru_24x1_2426_24Just = heff_take_reuse_n(v_x1_2426, 1ULL, 1);
      switch (heff_tag_of(v_m_2427)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2426_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2428 = heff_field(v_m_2427, 0);
        heff_take_n(v_m_2427, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2426_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2428, v_a_242})});
      }
      default: return heff_nomatch(v_m_2427);
      }
    }
    default: return heff_nomatch(v_x1_2426);
    }
  }
  case TAG_SProj: {
    V v_x1_2431 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2432 = heff_field(v_x1_2431, 0);
      V v_ru_24x1_2431_24Just = heff_take_reuse_n(v_x1_2431, 1ULL, 1);
      switch (heff_tag_of(v_m_2432)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2431_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2433 = heff_field(v_m_2432, 0);
        heff_take_n(v_m_2432, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2431_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2433, v_a_242})});
      }
      default: return heff_nomatch(v_m_2432);
      }
    }
    default: return heff_nomatch(v_x1_2431);
    }
  }
  case TAG_STag: {
    V v_x1_2436 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2436)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2437 = heff_field(v_x1_2436, 0);
      V v_ru_24x1_2436_24Just = heff_take_reuse_n(v_x1_2436, 1ULL, 1);
      switch (heff_tag_of(v_m_2437)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2436_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2438 = heff_field(v_m_2437, 0);
        heff_take_n(v_m_2437, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2436_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2438, v_a_242})});
      }
      default: return heff_nomatch(v_m_2437);
      }
    }
    default: return heff_nomatch(v_x1_2436);
    }
  }
  case TAG_SMatch: {
    V v_x1_2441 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2442 = heff_field(v_x1_2441, 0);
      V v_ru_24x1_2441_24Just = heff_take_reuse_n(v_x1_2441, 1ULL, 1);
      switch (heff_tag_of(v_m_2442)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2441_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2443 = heff_field(v_m_2442, 0);
        heff_take_n(v_m_2442, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2441_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2443, v_a_242})});
      }
      default: return heff_nomatch(v_m_2442);
      }
    }
    default: return heff_nomatch(v_x1_2441);
    }
  }
  case TAG_SSpecialize: {
    V v_x1_2447 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2447)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2448 = heff_field(v_x1_2447, 0);
      V v_ru_24x1_2447_24Just = heff_take_reuse_n(v_x1_2447, 1ULL, 1);
      switch (heff_tag_of(v_m_2448)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 3);
        heff_drop_cell(v_ru_24x1_2447_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2449 = heff_field(v_m_2448, 0);
        heff_take_n(v_m_2448, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2447_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2449, v_a_242})});
      }
      default: return heff_nomatch(v_m_2448);
      }
    }
    default: return heff_nomatch(v_x1_2447);
    }
  }
  case TAG_SIs: {
    V v_x1_2451 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2452 = heff_field(v_x1_2451, 0);
      V v_ru_24x1_2451_24Just = heff_take_reuse_n(v_x1_2451, 1ULL, 1);
      switch (heff_tag_of(v_m_2452)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2451_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2453 = heff_field(v_m_2452, 0);
        heff_take_n(v_m_2452, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2451_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2453, v_a_242})});
      }
      default: return heff_nomatch(v_m_2452);
      }
    }
    default: return heff_nomatch(v_x1_2451);
    }
  }
  case TAG_SOpaque: {
    V v_x1_2454 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2454)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2455 = heff_field(v_x1_2454, 0);
      V v_ru_24x1_2454_24Just = heff_take_reuse_n(v_x1_2454, 1ULL, 1);
      switch (heff_tag_of(v_m_2455)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2454_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2456 = heff_field(v_m_2455, 0);
        heff_take_n(v_m_2455, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2454_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2456, v_a_242})});
      }
      default: return heff_nomatch(v_m_2455);
      }
    }
    default: return heff_nomatch(v_x1_2454);
    }
  }
  case TAG_SAbandon: {
    V v_x1_2457 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2457)) {
    case TAG_Nothing: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2458 = heff_field(v_x1_2457, 0);
      V v_ru_24x1_2457_24Just = heff_take_reuse_n(v_x1_2457, 1ULL, 1);
      switch (heff_tag_of(v_m_2458)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_2457_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2459 = heff_field(v_m_2458, 0);
        heff_take_n(v_m_2458, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2457_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2459, v_a_242})});
      }
      default: return heff_nomatch(v_m_2458);
      }
    }
    default: return heff_nomatch(v_x1_2457);
    }
  }
  case TAG_SRec: {
    V v_x1_2461 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2461)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2462 = heff_field(v_x1_2461, 0);
      V v_ru_24x1_2461_24Just = heff_take_reuse_n(v_x1_2461, 1ULL, 1);
      switch (heff_tag_of(v_m_2462)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2461_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2463 = heff_field(v_m_2462, 0);
        heff_take_n(v_m_2462, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2461_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2463, v_a_242})});
      }
      default: return heff_nomatch(v_m_2462);
      }
    }
    default: return heff_nomatch(v_x1_2461);
    }
  }
  case TAG_SFix: {
    V v_x1_2466 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2467 = heff_field(v_x1_2466, 0);
      V v_ru_24x1_2466_24Just = heff_take_reuse_n(v_x1_2466, 1ULL, 1);
      switch (heff_tag_of(v_m_2467)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2466_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2468 = heff_field(v_m_2467, 0);
        heff_take_n(v_m_2467, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2466_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2468, v_a_242})});
      }
      default: return heff_nomatch(v_m_2467);
      }
    }
    default: return heff_nomatch(v_x1_2466);
    }
  }
  case TAG_SImplicit: {
    V v_n_2469 = heff_field(v_a_242, 0);
    V v_inner_2470 = heff_field(v_a_242, 1);
    heff_take_n(v_a_242, 3ULL, 2);
    heff_drop(v_names_240);
    heff_drop(v_i_241);
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2469, v_inner_2470})});
  }
  case TAG_SPrim: {
    V v_x1_2472 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2472)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2473 = heff_field(v_x1_2472, 0);
      V v_ru_24x1_2472_24Just = heff_take_reuse_n(v_x1_2472, 1ULL, 1);
      switch (heff_tag_of(v_m_2473)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2472_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2474 = heff_field(v_m_2473, 0);
        heff_take_n(v_m_2473, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2472_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2474, v_a_242})});
      }
      default: return heff_nomatch(v_m_2473);
      }
    }
    default: return heff_nomatch(v_x1_2472);
    }
  }
  case TAG_SMetaApp: {
    V v_x1_2478 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2478)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2479 = heff_field(v_x1_2478, 0);
      V v_ru_24x1_2478_24Just = heff_take_reuse_n(v_x1_2478, 1ULL, 1);
      switch (heff_tag_of(v_m_2479)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 3);
        heff_drop_cell(v_ru_24x1_2478_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2480 = heff_field(v_m_2479, 0);
        heff_take_n(v_m_2479, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2478_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2480, v_a_242})});
      }
      default: return heff_nomatch(v_m_2479);
      }
    }
    default: return heff_nomatch(v_x1_2478);
    }
  }
  case TAG_SLitInt: {
    V v_x1_2482 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2483 = heff_field(v_x1_2482, 0);
      V v_ru_24x1_2482_24Just = heff_take_reuse_n(v_x1_2482, 1ULL, 1);
      switch (heff_tag_of(v_m_2483)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2482_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2484 = heff_field(v_m_2483, 0);
        heff_take_n(v_m_2483, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2482_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2484, v_a_242})});
      }
      default: return heff_nomatch(v_m_2483);
      }
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_SLitFloat: {
    V v_x1_2486 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2486)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2487 = heff_field(v_x1_2486, 0);
      V v_ru_24x1_2486_24Just = heff_take_reuse_n(v_x1_2486, 1ULL, 1);
      switch (heff_tag_of(v_m_2487)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2486_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2488 = heff_field(v_m_2487, 0);
        heff_take_n(v_m_2487, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2486_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2488, v_a_242})});
      }
      default: return heff_nomatch(v_m_2487);
      }
    }
    default: return heff_nomatch(v_x1_2486);
    }
  }
  case TAG_SLitString: {
    V v_x1_2490 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2490)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2491 = heff_field(v_x1_2490, 0);
      V v_ru_24x1_2490_24Just = heff_take_reuse_n(v_x1_2490, 1ULL, 1);
      switch (heff_tag_of(v_m_2491)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2490_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2492 = heff_field(v_m_2491, 0);
        heff_take_n(v_m_2491, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2490_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2492, v_a_242})});
      }
      default: return heff_nomatch(v_m_2491);
      }
    }
    default: return heff_nomatch(v_x1_2490);
    }
  }
  case TAG_SLitRune: {
    V v_x1_2494 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2494)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_2495 = heff_field(v_x1_2494, 0);
      V v_ru_24x1_2494_24Just = heff_take_reuse_n(v_x1_2494, 1ULL, 1);
      switch (heff_tag_of(v_m_2495)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_2494_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_2496 = heff_field(v_m_2495, 0);
        heff_take_n(v_m_2495, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2494_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_2496, v_a_242})});
      }
      default: return heff_nomatch(v_m_2495);
      }
    }
    default: return heff_nomatch(v_x1_2494);
    }
  }
  case TAG_SLitFixed: {
    V v_x1_2499 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_2499)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_24100 = heff_field(v_x1_2499, 0);
      V v_ru_24x1_2499_24Just = heff_take_reuse_n(v_x1_2499, 1ULL, 1);
      switch (heff_tag_of(v_m_24100)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 2);
        heff_drop_cell(v_ru_24x1_2499_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_24101 = heff_field(v_m_24100, 0);
        heff_take_n(v_m_24100, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2499_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_24101, v_a_242})});
      }
      default: return heff_nomatch(v_m_24100);
      }
    }
    default: return heff_nomatch(v_x1_2499);
    }
  }
  case TAG_SLitFloat32: {
    V v_x1_24103 = ({ V b_0 = heff_arrayToList(v_names_240); V a_1 = v_i_241; V r_ = (g_heff_2esyntax_2epsurface_2enth(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_x1_24103)) {
    case TAG_Nothing: {
      heff_drop_tag(v_a_242, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_m_24104 = heff_field(v_x1_24103, 0);
      V v_ru_24x1_24103_24Just = heff_take_reuse_n(v_x1_24103, 1ULL, 1);
      switch (heff_tag_of(v_m_24104)) {
      case TAG_Nothing: {
        heff_drop_tag(v_a_242, 1);
        heff_drop_cell(v_ru_24x1_24103_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_n_24105 = heff_field(v_m_24104, 0);
        heff_take_n(v_m_24104, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_24103_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_n__inner, (V[]){v_n_24105, v_a_242})});
      }
      default: return heff_nomatch(v_m_24104);
      }
    }
    default: return heff_nomatch(v_x1_24103);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2esyntax_2epsurface_2eimplicitName_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eimplicitName(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str0, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str1, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str2, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str3, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str4, 1, "}");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str5, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str6, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str7, 1, "}");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str8, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str9, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str10, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str11, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str12, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str13, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str14, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str15, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str16, 1, "_");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elambdas_str17, 1, "_");
Clo g_heff_2esyntax_2epsurface_2elambdas_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elambdas_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2elambdas(V v_ys_240, V v_bs_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_244, v_e_242});
  }
  case TAG_SGlobal: {
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_246, v_e_242});
  }
  case TAG_SCode: {
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_248, v_e_242});
  }
  case TAG_SApp: {
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2411, v_e_242});
  }
  case TAG_SLam: {
    V v_e1_2412 = heff_field(v_e_242, 0);
    V v_e2_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_e1_2412)) {
    case TAG_SU: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2415 = heff_field(v_e2_2413, 0);
        V v_b_2416 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2415, v_bs_241});
        V t_2 = v_b_2416;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str0), v_bs_241});
        V t_2 = v_b_2417;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_e2_2413, 0);
        V v_b_2420 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2419, v_bs_241});
        V t_2 = v_b_2420;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2421 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str1), v_bs_241});
        V t_2 = v_b_2421;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFunction: {
      V v_e14_2425 = heff_field(v_e1_2412, 3);
      heff_take_n(v_e1_2412, 8ULL, 5);
      switch (heff_tag_of(v_e14_2425)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2427 = heff_field(v_e2_2413, 0);
          V v_b_2428 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2427), v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2427, v_bs_241});
          V t_2 = v_b_2428;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2429 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str2), v_bs_241});
          V t_2 = v_b_2429;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Impl: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2430 = heff_field(v_e2_2413, 0);
          V v_b_2431 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elambdas_str3), heff_strAppend(heff_dup(v_x_2430), ((V)&g_heff_2esyntax_2epsurface_2elambdas_str4)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2430, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2432, v_bs_241});
          V t_2 = v_b_2431;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2433 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str5), v_bs_241});
          V t_2 = v_b_2433;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      case TAG_Inst: {
        switch (heff_tag_of(v_e2_2413)) {
        case TAG_MkAbs: {
          V v_x_2434 = heff_field(v_e2_2413, 0);
          V v_b_2435 = heff_field(v_e2_2413, 1);
          V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
          V v_t_2436 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elambdas_str6), heff_strAppend(heff_dup(v_x_2434), ((V)&g_heff_2esyntax_2epsurface_2elambdas_str7)));
          V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){v_x_2434, v_ys_240});
          V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_t_2436, v_bs_241});
          V t_2 = v_b_2435;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        case TAG_AbsConst: {
          V v_b_2437 = heff_field(v_e2_2413, 0);
          heff_take_n(v_e2_2413, 1ULL, 1);
          V t_0 = v_ys_240;
          V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str8), v_bs_241});
          V t_2 = v_b_2437;
          v_ys_240 = t_0;
          v_bs_241 = t_1;
          v_e_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_e2_2413);
        }
      }
      default: return heff_nomatch(v_e14_2425);
      }
    }
    case TAG_SRecord: {
      heff_take_n(v_e1_2412, 0ULL, 3);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2441 = heff_field(v_e2_2413, 0);
        V v_b_2442 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2441), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2441, v_bs_241});
        V t_2 = v_b_2442;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2443 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str9), v_bs_241});
        V t_2 = v_b_2443;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SSum: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2445 = heff_field(v_e2_2413, 0);
        V v_b_2446 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2445), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2445, v_bs_241});
        V t_2 = v_b_2446;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2447 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str10), v_bs_241});
        V t_2 = v_b_2447;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SIsTy: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2449 = heff_field(v_e2_2413, 0);
        V v_b_2450 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2449), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2449, v_bs_241});
        V t_2 = v_b_2450;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2451 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str11), v_bs_241});
        V t_2 = v_b_2451;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimInt: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2452 = heff_field(v_e2_2413, 0);
        V v_b_2453 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2452), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2452, v_bs_241});
        V t_2 = v_b_2453;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2454 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str12), v_bs_241});
        V t_2 = v_b_2454;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimFloat: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2455 = heff_field(v_e2_2413, 0);
        V v_b_2456 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2455), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2455, v_bs_241});
        V t_2 = v_b_2456;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2457 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str13), v_bs_241});
        V t_2 = v_b_2457;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimString: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2458 = heff_field(v_e2_2413, 0);
        V v_b_2459 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2458), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2458, v_bs_241});
        V t_2 = v_b_2459;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2460 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str14), v_bs_241});
        V t_2 = v_b_2460;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimRune: {
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2461 = heff_field(v_e2_2413, 0);
        V v_b_2462 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2461), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2461, v_bs_241});
        V t_2 = v_b_2462;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2463 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str15), v_bs_241});
        V t_2 = v_b_2463;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SPrimArray: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2465 = heff_field(v_e2_2413, 0);
        V v_b_2466 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2465), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2465, v_bs_241});
        V t_2 = v_b_2466;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2467 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str16), v_bs_241});
        V t_2 = v_b_2467;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    case TAG_SFixed: {
      heff_take_n(v_e1_2412, 0ULL, 1);
      switch (heff_tag_of(v_e2_2413)) {
      case TAG_MkAbs: {
        V v_x_2469 = heff_field(v_e2_2413, 0);
        V v_b_2470 = heff_field(v_e2_2413, 1);
        V v_ru_24e2_2413_24MkAbs = heff_take_reuse_n(v_e2_2413, 3ULL, 2);
        V t_0 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){heff_dup(v_x_2469), v_ys_240});
        V t_1 = heff_tag_at_n(v_ru_24e2_2413_24MkAbs, TAG_Cons, 2, (V[]){v_x_2469, v_bs_241});
        V t_2 = v_b_2470;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_b_2471 = heff_field(v_e2_2413, 0);
        heff_take_n(v_e2_2413, 1ULL, 1);
        V t_0 = v_ys_240;
        V t_1 = heff_tag_at_n(v_ru_24e_242_24SLam, TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2epsurface_2elambdas_str17), v_bs_241});
        V t_2 = v_b_2471;
        v_ys_240 = t_0;
        v_bs_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e2_2413);
      }
    }
    default: return heff_nomatch(v_e1_2412);
    }
  }
  case TAG_SCons: {
    V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2473, v_e_242});
  }
  case TAG_SProj: {
    V v_t_2476 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2476, v_e_242});
  }
  case TAG_STag: {
    V v_t_2479 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2479, v_e_242});
  }
  case TAG_SMatch: {
    V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2482, v_e_242});
  }
  case TAG_SSpecialize: {
    V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2486, v_e_242});
  }
  case TAG_SIs: {
    V v_t_2488 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2488, v_e_242});
  }
  case TAG_SOpaque: {
    V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2489, v_e_242});
  }
  case TAG_SAbandon: {
    V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2490, v_e_242});
  }
  case TAG_SRec: {
    V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2492, v_e_242});
  }
  case TAG_SFix: {
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2495, v_e_242});
  }
  case TAG_SImplicit: {
    V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_2498, v_e_242});
  }
  case TAG_SPrim: {
    V v_t_24100 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24100, v_e_242});
  }
  case TAG_SMetaApp: {
    V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24104, v_e_242});
  }
  case TAG_SLitInt: {
    V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24106, v_e_242});
  }
  case TAG_SLitFloat: {
    V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24108, v_e_242});
  }
  case TAG_SLitString: {
    V v_t_24110 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24110, v_e_242});
  }
  case TAG_SLitRune: {
    V v_t_24112 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24112, v_e_242});
  }
  case TAG_SLitFixed: {
    V v_t_24115 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24115, v_e_242});
  }
  case TAG_SLitFloat32: {
    V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_bs_241));
    return heff_rec_n(3, shape_names__binders__body, (V[]){v_ys_240, v_t_24117, v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2esyntax_2epsurface_2elambdas_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2elambdas(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str9, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str15, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str18, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eopHead_str22, 0, "");
Clo g_heff_2esyntax_2epsurface_2eopHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eopHead_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eopHead(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str0);
  }
  case TAG_SGlobal: {
    V v_x_242 = heff_field(v_x1_240, 0);
    return heff_dup(v_x_242);
  }
  case TAG_SCode: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str1);
  }
  case TAG_SApp: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str2);
  }
  case TAG_SLam: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str3);
  }
  case TAG_SCons: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str4);
  }
  case TAG_SProj: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str5);
  }
  case TAG_STag: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str6);
  }
  case TAG_SMatch: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str7);
  }
  case TAG_SSpecialize: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str8);
  }
  case TAG_SIs: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str9);
  }
  case TAG_SOpaque: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str10);
  }
  case TAG_SAbandon: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str11);
  }
  case TAG_SRec: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str12);
  }
  case TAG_SFix: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str13);
  }
  case TAG_SImplicit: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str14);
  }
  case TAG_SPrim: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str15);
  }
  case TAG_SMetaApp: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str16);
  }
  case TAG_SLitInt: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str17);
  }
  case TAG_SLitFloat: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str18);
  }
  case TAG_SLitString: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str19);
  }
  case TAG_SLitRune: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str20);
  }
  case TAG_SLitFixed: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str21);
  }
  case TAG_SLitFloat32: {
    return ((V)&g_heff_2esyntax_2epsurface_2eopHead_str22);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2eopHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2epsurface_2eopHead(a0); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2epsurface_2eopApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eopApp_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eopApp(V v_c_240, V v_xs_241, V v_sp_242) {
top: ;
  V v_t_243 = heff_take_field(v_sp_242, 0);
  switch (heff_tag_of(v_t_243)) {
  case TAG_SLocal: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SGlobal = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_get_n(v_sp_242, 1, 2);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_l_247 = heff_field(v_t_246, 0);
      V v_it2_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      switch (heff_tag_of(v_it2_248)) {
      case TAG_Nil: {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
        heff_drop(v_l_247);
        return NTAG(TAG_Nothing);
      }
      case TAG_Cons: {
        V v_r2_249 = heff_field(v_it2_248, 0);
        V v_it22_2410 = heff_field(v_it2_248, 1);
        heff_take_n(v_it2_248, 3ULL, 2);
        switch (heff_tag_of(v_it22_2410)) {
        case TAG_Nil: {
          V v_t_2411 = (g_heff_2esyntax_2epsurface_2eisOperator(v_x_245));
          switch (heff_tag_of(v_t_2411)) {
          case TAG_True: {
            V v_t_2446;
            switch (heff_tag_of(v_l_247)) {
            case TAG_SLocal: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SGlobal: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SCode: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SApp: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLam: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SCons: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SProj: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_STag: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SMatch: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SSpecialize: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SIs: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SOpaque: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SAbandon: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SRec: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SFix: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SImplicit: {
              v_t_2446 = NTAG(TAG_True);
              break;
            }
            case TAG_SPrim: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SMetaApp: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitInt: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitString: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitRune: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFixed: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            case TAG_SLitFloat32: {
              v_t_2446 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_l_247);
            }
            V v_x1_2481;
            switch (heff_tag_of(v_t_2446)) {
            case TAG_True: {
              v_x1_2481 = NTAG(TAG_True);
              break;
            }
            case TAG_False: {
              switch (heff_tag_of(v_r2_249)) {
              case TAG_SLocal: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SGlobal: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SCode: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SApp: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLam: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SCons: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SProj: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_STag: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SMatch: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SSpecialize: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SIs: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SOpaque: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SAbandon: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SRec: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SFix: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SImplicit: {
                v_x1_2481 = NTAG(TAG_True);
                break;
              }
              case TAG_SPrim: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SMetaApp: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitInt: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFloat: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitString: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitRune: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFixed: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              case TAG_SLitFloat32: {
                v_x1_2481 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_r2_249);
              }
              break;
            }
            default: heff_nomatch(v_t_2446);
            }
            switch (heff_tag_of(v_x1_2481)) {
            case TAG_True: {
              heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
              heff_drop(v_l_247);
              heff_drop(v_r2_249);
              return NTAG(TAG_Nothing);
            }
            case TAG_False: {
              return heff_tag_at_n(v_ru_24t_243_24SGlobal, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_247, v_r2_249})});
            }
            default: return heff_nomatch(v_x1_2481);
            }
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
            heff_drop(v_l_247);
            heff_drop(v_r2_249);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_t_2411);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2410, 0ULL, 2);
          heff_drop(v_x_245);
          heff_drop_cell(v_ru_24t_243_24SGlobal, 1);
          heff_drop(v_l_247);
          heff_drop(v_r2_249);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_it22_2410);
        }
      }
      default: return heff_nomatch(v_it2_248);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_243, 0ULL, 2);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_sp_242, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2epsurface_2eopApp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2epsurface_2eopApp(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2elistItems_str0, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elistItems_str1, 4, "Cons");
Clo g_heff_2esyntax_2epsurface_2elistItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elistItems_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2elistItems(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    V v_x11_2411 = heff_field(v_x1_240, 0);
    V v_ts_2412 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24STag = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x11_2411), ((V)&g_heff_2esyntax_2epsurface_2elistItems_str0))) {
      heff_drop(v_x11_2411);
      heff_drop_cell(v_ru_24x1_240_24STag, 2);
      if (heff_intEq_c(heff_arrayLength(v_ts_2412), MK_INT(0LL))) {
        return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
      } else {
        return NTAG(TAG_Nothing);
      }
    } else {
      if (heff_strEq_c(v_x11_2411, ((V)&g_heff_2esyntax_2epsurface_2elistItems_str1))) {
        if (heff_intEq_c(heff_arrayLength(heff_dup(v_ts_2412)), MK_INT(2LL))) {
          V v_t_2417 = heff_arrayIndex(heff_dup(v_ts_2412), MK_INT(0LL));
          V v_t_2418 = heff_arrayIndex(v_ts_2412, MK_INT(1LL));
          V v_x2_2419 = (g_heff_2esyntax_2epsurface_2elistItems(v_t_2418));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x1_240_24STag, 2);
            heff_drop(v_t_2417);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_ts_2420 = heff_field(v_x2_2419, 0);
            V v_ru_24x2_2419_24Just = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
            return heff_tag_at_n(v_ru_24x2_2419_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24STag, TAG_Cons, 2, (V[]){v_t_2417, v_ts_2420})});
          }
          default: return heff_nomatch(v_x2_2419);
          }
        } else {
          heff_drop(v_ts_2412);
          heff_drop_cell(v_ru_24x1_240_24STag, 2);
          return NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_ts_2412);
        heff_drop_cell(v_ru_24x1_240_24STag, 2);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2elistItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2elistItems(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2eimplicitGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eimplicitGroup_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eimplicitGroup(V v_names_240, V v_u_241, V v_rest_242, V v_ctx_243) {
top: ;
  switch (heff_tag_of(v_rest_242)) {
  case TAG_SU: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SDecode: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFunction: {
    V v_rest2_247 = heff_dup(heff_field(v_rest_242, 1));
    V v_rest3_248 = heff_dup(heff_field(v_rest_242, 2));
    V v_rest4_249 = heff_dup(heff_field(v_rest_242, 3));
    V v_rest5_2410 = heff_dup(heff_field(v_rest_242, 4));
    switch (heff_tag_of(v_rest2_247)) {
    case TAG_SU: {
      V v_u_27_2411 = heff_field(v_rest2_247, 0);
      heff_take_n(v_rest2_247, 1ULL, 1);
      switch (heff_tag_of(v_rest3_248)) {
      case TAG_MkAbs: {
        V v_y_2412 = heff_field(v_rest3_248, 0);
        V v_b_2413 = heff_field(v_rest3_248, 1);
        V v_ru_24rest3_248_24MkAbs = heff_take_reuse_n(v_rest3_248, 3ULL, 2);
        switch (heff_tag_of(v_rest4_249)) {
        case TAG_Expl: {
          heff_drop(v_rest5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
          return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_rest5_2410)) {
          case TAG_Nothing: {
            V v_t_2414;
            switch (heff_tag_of(v_u_241)) {
            case TAG_SmallU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                v_t_2414 = NTAG(TAG_True);
                break;
              }
              case TAG_LargeU: {
                v_t_2414 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_u_27_2411);
              }
              break;
            }
            case TAG_LargeU: {
              switch (heff_tag_of(v_u_27_2411)) {
              case TAG_SmallU: {
                v_t_2414 = NTAG(TAG_False);
                break;
              }
              case TAG_LargeU: {
                v_t_2414 = NTAG(TAG_True);
                break;
              }
              default: heff_nomatch(v_u_27_2411);
              }
              break;
            }
            default: heff_nomatch(v_u_241);
            }
            switch (heff_tag_of(v_t_2414)) {
            case TAG_True: {
              heff_drop_tag(v_rest_242, 5);
              V v_t_2415 = heff_tag_at_n(v_ru_24rest3_248_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_y_2412), NTAG(TAG_Nil)});
              V v_t_2416 = (g_prelude_2e_2b_2b(v_names_240, v_t_2415));
              V t_0 = v_t_2416;
              V t_1 = v_u_241;
              V t_2 = v_b_2413;
              V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_2412, v_ctx_243});
              v_names_240 = t_0;
              v_u_241 = t_1;
              v_rest_242 = t_2;
              v_ctx_243 = t_3;
              goto top;
            }
            case TAG_False: {
              heff_drop(v_y_2412);
              heff_drop(v_b_2413);
              heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
              return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
            }
            default: return heff_nomatch(v_t_2414);
            }
          }
          case TAG_Just: {
            heff_take_n(v_rest5_2410, 0ULL, 1);
            heff_drop(v_u_27_2411);
            heff_drop(v_y_2412);
            heff_drop(v_b_2413);
            heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
            return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
          }
          default: return heff_nomatch(v_rest5_2410);
          }
        }
        case TAG_Inst: {
          heff_drop(v_rest5_2410);
          heff_drop(v_u_27_2411);
          heff_drop(v_y_2412);
          heff_drop(v_b_2413);
          heff_drop_cell(v_ru_24rest3_248_24MkAbs, 2);
          return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
        }
        default: return heff_nomatch(v_rest4_249);
        }
      }
      case TAG_AbsConst: {
        heff_take_n(v_rest3_248, 0ULL, 1);
        heff_drop(v_rest4_249);
        heff_drop(v_rest5_2410);
        heff_drop(v_u_27_2411);
        return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
      }
      default: return heff_nomatch(v_rest3_248);
      }
    }
    case TAG_SDecode: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFunction: {
      heff_take_n(v_rest2_247, 0ULL, 5);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SRecord: {
      heff_take_n(v_rest2_247, 0ULL, 3);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SSum: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SIsTy: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimInt: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimFloat: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimString: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimRune: {
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SPrimArray: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    case TAG_SFixed: {
      heff_take_n(v_rest2_247, 0ULL, 1);
      heff_drop(v_rest3_248);
      heff_drop(v_rest4_249);
      heff_drop(v_rest5_2410);
      return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
    }
    default: return heff_nomatch(v_rest2_247);
    }
  }
  case TAG_SRecord: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SSum: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SIsTy: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimInt: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimFloat: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimString: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimRune: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SPrimArray: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  case TAG_SFixed: {
    return heff_rec_n(3, shape_names__rest__ctx, (V[]){v_names_240, v_rest_242, v_ctx_243});
  }
  default: return heff_nomatch(v_rest_242);
  }
}
V g_heff_2esyntax_2epsurface_2eimplicitGroup_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2epsurface_2eimplicitGroup(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str2, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str3, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str4, 5, "} -> ");
Clo g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(V v_c_240, V v_xs_241, V v_dom_242, V v_r_243) {
top: ;
  V v_t_244 = heff_take_field(v_r_243, 0);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_248 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), v_xs_241, v_dom_242));
  return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str2), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str3), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_str4), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_dup(heff_rfield(v_r_243, 2)); V b_3 = heff_get_n(v_r_243, 1, 3); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; }))))));
}
V g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str2, 5, ") -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str3, 2, "{{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str4, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str5, 6, "}} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str6, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str7, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str8, 6, "{{_ : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str9, 6, "}} -> ");
Clo g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry, 6, 0};

V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(V v_c_240, V v_xs_241, V v_level_242, V v_dom_243, V v_x6_244, V v_implicit_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkAbs: {
    V v_x_246 = heff_field(v_x6_244, 0);
    V v_b_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24MkAbs = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      heff_drop_cell(v_ru_24x6_244_24MkAbs, 2);
      V v_t_248 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str0), heff_strAppend(heff_dup(v_x_246), heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str1), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str2), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; }))))));
    }
    case TAG_Impl: {
      V v_t_2435;
      switch (heff_tag_of(v_dom_243)) {
      case TAG_SU: {
        V v_u_249 = heff_field(v_dom_243, 0);
        V v_t_2410 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = (g_heff_2esyntax_2epsurface_2eimplicitGroup(v_t_2410, v_u_249, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})));
        break;
      }
      case TAG_SDecode: {
        V v_t_2412 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2412, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFunction: {
        V v_t_2418 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2418, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SRecord: {
        V v_t_2422 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2422, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SSum: {
        V v_t_2424 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2424, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SIsTy: {
        V v_t_2426 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2426, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimInt: {
        V v_t_2427 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2427, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimFloat: {
        V v_t_2428 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2428, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimString: {
        V v_t_2429 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2429, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimRune: {
        V v_t_2430 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2430, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SPrimArray: {
        V v_t_2432 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2432, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      case TAG_SFixed: {
        V v_t_2434 = heff_tag_at_n(v_ru_24x6_244_24MkAbs, TAG_Cons, 2, (V[]){heff_dup(v_x_246), NTAG(TAG_Nil)});
        v_t_2435 = heff_rec_n(3, shape_names__rest__ctx, (V[]){v_t_2434, v_b_247, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, heff_dup(v_xs_241)})});
        break;
      }
      default: heff_nomatch(v_dom_243);
      }
      return (g_heff_2esyntax_2epsurface_2earrowGrouped_24s890811436x1724062161(v_c_240, v_xs_241, v_dom_243, v_t_2435));
    }
    case TAG_Inst: {
      heff_drop_cell(v_ru_24x6_244_24MkAbs, 2);
      V v_t_2436 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str3), heff_strAppend(heff_dup(v_x_246), heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str4), heff_strAppend(v_t_2436, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str5), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_xs_241}); V a_3 = v_b_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_247); r_; }))))));
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  case TAG_AbsConst: {
    V v_b_2437 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    switch (heff_tag_of(v_implicit_245)) {
    case TAG_Expl: {
      V v_t_2438 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(v_t_2438, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str6), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2437; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2437); r_; })));
    }
    case TAG_Impl: {
      V v_t_2439 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str7), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2437; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2437); r_; })));
    }
    case TAG_Inst: {
      V v_t_2440 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_243));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str8), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_str9), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_2437; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_2437); r_; }))));
    }
    default: return heff_nomatch(v_implicit_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a5 = a[5]; V r = g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(a[0], a[1], a2, a3, a[4], a5); heff_drop(a2); heff_drop(a3); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str0, 1, "{");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str1, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str2, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str3, 5, "} -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str4, 5, "{_ : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str5, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str6, 5, "} -> ");
Clo g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry, 5, 0};

V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(V v_c_240, V v_xs_241, V v_dom_242, V v_x5_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkAbs: {
    V v_x_245 = heff_field(v_x5_243, 0);
    V v_b_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str0), heff_strAppend(heff_dup(v_x_245), heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str1), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str2), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str3), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_xs_241}); V a_3 = v_b_246; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_246); r_; }))))))));
  }
  case TAG_AbsConst: {
    V v_b_249 = heff_field(v_x5_243, 0);
    heff_take_n(v_x5_243, 1ULL, 1);
    V v_t_2410 = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_dom_242));
    V v_t_2411 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), v_d_244));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str4), heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str5), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_str6), ({ V a_0 = v_c_240; V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V a_3 = v_b_249; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_b_249); r_; }))))));
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str1, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str2, 3, " : ");
Clo g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(V v_c_240, V v_ds_241, V v_acc_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_l_244 = heff_field(v_x5_243, 0);
    V v_t_245 = heff_field(v_x5_243, 1);
    V v_ru_24x5_243_24MkPair = heff_take_reuse_n(v_x5_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x5_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_l_244), heff_dup(heff_rfield(v_acc_242, 0))});
    V v_t_247 = ({ V a_0 = heff_dup(v_c_240); V a_1 = MK_INT(0LL); V a_2 = heff_dup(heff_rfield(v_acc_242, 0)); V a_3 = v_t_245; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
    V v_t_248 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_l_244), heff_rfield(v_ds_241, 1)));
    V v_x4_2414;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_ds_241, 3);
      v_x4_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_i_249 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_xs_2410 = heff_get_n(v_ds_241, 2, 3);
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_249))) {
        if (heff_intLt_c(heff_dup(v_i_249), heff_arrayLength(heff_dup(v_xs_2410)))) {
          V v_t_2413 = heff_arrayIndex(v_xs_2410, v_i_249);
          v_x4_2414 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2413});
        } else {
          heff_drop(v_i_249);
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          heff_drop(v_xs_2410);
          v_x4_2414 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop(v_i_249);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        heff_drop(v_xs_2410);
        v_x4_2414 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2416;
    switch (heff_tag_of(v_x4_2414)) {
    case TAG_Nothing: {
      heff_drop(v_c_240);
      v_t_2416 = ((V)&g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str0);
      break;
    }
    case TAG_Just: {
      V v_d_2415 = heff_field(v_x4_2414, 0);
      heff_take_n(v_x4_2414, 1ULL, 1);
      v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str1), (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_acc_242, 0)), v_d_2415)));
      break;
    }
    default: heff_nomatch(v_x4_2414);
    }
    V v_t_2417 = heff_strAppend(v_l_244, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_str2), heff_strAppend(v_t_247, v_t_2416)));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_t_2419 = (g_prelude_2e_2b_2b(heff_get_n(v_acc_242, 1, 2), v_t_2418));
    return heff_rec_n(2, shape_names__out, (V[]){v_t_246, v_t_2419});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str11, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str12, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str13, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str14, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str17, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str18, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str21, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str22, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str23, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str24, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str25, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str26, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str27, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str28, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str29, 7, "Float32");
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam1(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(V v_c_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x5_243, 0);
    V v_dom_247 = heff_field(v_x5_243, 1);
    V v_cod_248 = heff_field(v_x5_243, 2);
    V v_implicit_249 = heff_field(v_x5_243, 3);
    V v_dflt_2410 = heff_field(v_x5_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(v_c_240, v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(v_c_240, v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str3)));
    } else {
      return v_s_2412;
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_x5_243, 1);
    V v_ds_2416 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 2)));
    V v_fs_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam0, 2, 2, (V[]){v_c_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_t_2424 = heff_get_n(v_acc_2423, 1, 2);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_t_2424, 0);
      V v_xs_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 2)));
    V v_t_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2439 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam1, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2431));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str11); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str12), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2443 = heff_field(v_x5_243, 0);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_t2_2443;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_x5_243 = t_3;
    goto top;
  }
  case TAG_SPrimInt: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str16);
  }
  case TAG_SPrimRune: {
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str17);
  }
  case TAG_SPrimArray: {
    V v_a_2444 = heff_field(v_x5_243, 0);
    V v_s_2445 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str18), (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(v_c_240, MK_INT(2LL), v_xs_242, v_a_2444)));
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str19), heff_strAppend(v_s_2445, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str20)));
    } else {
      return v_s_2445;
    }
  }
  case TAG_SFixed: {
    V v_w_2447 = heff_field(v_x5_243, 0);
    heff_drop(v_c_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2447)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str21);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str22);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str23);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str24);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str25);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str26);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str27);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str28);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str29);
    }
    default: return heff_nomatch(v_w_2447);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_c_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(v_c_240, v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_c_240; V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    V v_ru_24v_2432_24MkPair = heff_take_reuse_n(v_v_2432, 3ULL, 2);
    V v_x2_2436 = heff_tag_at_n(v_ru_24v_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), heff_arrayToList(v_ts_2434)))});
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str8);
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165_str9); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_v_2432);
  }
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str1, 4, " := ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str2, 1, ")");
Clo g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry, 5, 0};

V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(V v_c_240, V v_xs_241, V v_names_242, V v_i_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_xs_241);
    heff_drop(v_names_242);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_245 = heff_field(v_x6_244, 0);
    V v_rest_246 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2epsurface_2eimplicitName(heff_dup(v_names_242), heff_dup(v_i_243), heff_dup(v_a_245)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_241), v_a_245));
      return heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246))});
    }
    case TAG_Just: {
      V v_imp_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      heff_drop(v_a_245);
      V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 1, 2);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x6_244_24Cons, 2);
        heff_drop_rec(v_imp_249, 2);
        V t_0 = v_c_240;
        V t_1 = v_xs_241;
        V t_2 = v_names_242;
        V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
        V t_4 = v_rest_246;
        v_c_240 = t_0;
        v_xs_241 = t_1;
        v_names_242 = t_2;
        v_i_243 = t_3;
        v_x6_244 = t_4;
        goto top;
      }
      case TAG_False: {
        V v_t_2411 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_241), heff_take_field(v_imp_249, 1)));
        V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str0), heff_strAppend(heff_get_n(v_imp_249, 0, 2), heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str1), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_str2)))));
        return heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2412, (g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(v_c_240, v_xs_241, v_names_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rest_246))});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str1, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str2, 1, ")");
Clo g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(V v_c_240, V v_p_241, V v_xs_242, V v_sp_243) {
top: ;
  V v_headArg_244 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))));
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_c_240, 0)), 0, 2);
  V v_t_246 = heff_tr(heff_call(v_t_245, 2, (V[]){heff_dup(v_xs_242), heff_dup(heff_rfield(v_sp_243, 0))}));
  V v_args_247 = (g_heff_2esyntax_2epsurface_2eargStrs_24s18785551x1902706365(heff_dup(v_c_240), heff_dup(v_xs_242), v_t_246, MK_INT(0LL), heff_take_field(v_sp_243, 1)));
  V v_headAlone_248 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, heff_dup(v_p_241), v_xs_242, heff_get_n(v_sp_243, 0, 2)));
  switch (heff_tag_of(v_args_247)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    heff_drop(v_headArg_244);
    return v_headAlone_248;
  }
  case TAG_Cons: {
    heff_drop(v_headAlone_248);
    V v_s_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str0); V a_1 = v_headArg_244; V a_2 = v_args_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_args_247, 2); r_; });
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str1), heff_strAppend(v_s_2411, ((V)&g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_str2)));
    } else {
      return v_s_2411;
    }
  }
  default: return heff_nomatch(v_args_247);
  }
}
V g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str3, 1, ")");
Clo g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(V v_c_240, V v_p_241, V v_xs_242, V v_t_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2epsurface_2espineGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
  V v_it_245 = (g_heff_2esyntax_2epsurface_2eopApp(v_c_240, v_xs_242, v_t_244));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2esyntax_2epsurface_2espineGo(v_t_243, NTAG(TAG_Nil)));
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eappPlain_24s1100565301x1707973146(v_c_240, v_p_241, v_xs_242, v_t_246);
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    heff_take_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_MkPair: {
      V v_l_248 = heff_field(v_it1_247, 0);
      V v_r2_249 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      V v_t_2410 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(1LL), heff_dup(v_xs_242), v_l_248));
      V v_t_2411 = (g_heff_2esyntax_2epsurface_2espineGo(v_t_243, NTAG(TAG_Nil)));
      V v_t_2412 = ({ V b_0 = heff_get_n(v_t_2411, 0, 2); V r_ = (g_heff_2esyntax_2epsurface_2eopHead(b_0)); heff_drop(b_0); r_; });
      V v_s_2413 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str0), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str1), (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(1LL), v_xs_242, v_r2_249))))));
      if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
        return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str2), heff_strAppend(v_s_2413, ((V)&g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_str3)));
      } else {
        return v_s_2413;
      }
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str1, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str2, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str3, 4, " -> ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str4, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str5, 1, ")");
Clo g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(V v_c_240, V v_p_241, V v_xs_242, V v_l_243) {
top: ;
  V v_t_244 = heff_take_field(v_l_243, 1);
  V v_t_247;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_t_244, 0);
    V v_xs_246 = heff_field(v_t_244, 1);
    heff_take_n(v_t_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str1); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_s_248 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str2), heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str3), (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), heff_dup(heff_rfield(v_l_243, 0)), heff_get_n(v_l_243, 2, 3))))));
  if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str4), heff_strAppend(v_s_248, ((V)&g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_str5)));
  } else {
    return v_s_248;
  }
}
V g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str3, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str4, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str5, 4, " -> ");
Clo g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(V v_inner_240, V v_xs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkPair: {
    V v_t_243 = heff_field(v_x4_242, 0);
    V v_x42_244 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x42_244)) {
    case TAG_MkPair: {
      V v_ys_245 = heff_field(v_x42_244, 0);
      V v_body_246 = heff_field(v_x42_244, 1);
      V v_x2_247 = (g_list_2ereplicate(heff_dup(heff_rfield(v_inner_240, 1)), ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str0)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str2); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str3); V a_1 = heff_dup(v_t_243); V b_2 = heff_arrayToList(heff_dup(v_ys_245)); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      V v_xs_2412 = (g_list_2efoldl_24s1370882877x364361272(v_xs_241, heff_arrayToList(heff_dup(v_ys_245))));
      V v_t_2413 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_inner_240, MK_INT(0LL), v_xs_2412, heff_dup(v_body_246)));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str4), heff_strAppend(v_t_2410, heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_str5), v_t_2413))));
    }
    default: return heff_nomatch(v_x42_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str2, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str4, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str5, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str6, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str7, 1, ".");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str18, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str19, 3, " of");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str20, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str22, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str23, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str24, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str26, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str27, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str28, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str29, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str30, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str31, 1, ">");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str32, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str34, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str35, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str36, 1, "'");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str37, 1, "'");
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam1(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam3(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(V v_c_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    return (g_heff_2esyntax_2epsurface_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_246 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_245)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str0), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str1)));
    }
    case TAG_False: {
      return v_x_245;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_a_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(v_c_240, v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_248, v_a_249}));
  }
  case TAG_SLam: {
    V v_t_2410 = heff_field(v_e_243, 0);
    V v_b_2411 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2epsurface_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2410, v_b_2411})));
    return ({ V a_0 = v_c_240; V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2412; V r_ = (g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2414 = heff_arrayToList(heff_take_field(v_d_2413, 0));
    V v_t_2415 = heff_arrayToList(heff_get_n(v_d_2413, 2, 3));
    V v_t_2416 = (g_heff_2eutil_2edict_2ezipKV(v_t_2414, v_t_2415));
    V v_x2_2420 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam0, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2416));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str4); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str5), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str6)));
  }
  case TAG_SProj: {
    V v_e2_2424 = heff_field(v_e_243, 0);
    V v_l_2425 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2426 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(2LL), v_xs_242, v_e2_2424));
    return heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str7), v_l_2425));
  }
  case TAG_STag: {
    V v_x_2427 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2428 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2429 = (g_heff_2esyntax_2epsurface_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      V v_t_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2428)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c(v_t_2430, MK_INT(0LL))) {
        heff_drop_rec(v_c_240, 2);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2428);
        return v_x_2427;
      } else {
        V v_x2_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2427, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam1, 1, 2, (V[]){v_c_240, v_xs_242}), heff_arrayToList(v_ts_2428)))});
        V v_s_2436;
        switch (heff_tag_of(v_x2_2433)) {
        case TAG_Nil: {
          v_s_2436 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2434 = heff_field(v_x2_2433, 0);
          V v_xs_2435 = heff_field(v_x2_2433, 1);
          heff_take_n(v_x2_2433, 3ULL, 2);
          v_s_2436 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str9); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2433);
        }
        if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str10), heff_strAppend(v_s_2436, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str11)));
        } else {
          return v_s_2436;
        }
      }
    }
    case TAG_Just: {
      V v_items_2438 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2427);
      heff_drop(v_ts_2428);
      V v_x2_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam2, 1, 2, (V[]){v_c_240, v_xs_242}), v_items_2438));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str13); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str14), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str15)));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_SMatch: {
    V v_s_2444 = heff_field(v_e_243, 0);
    V v_cases_2445 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2446 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(0LL), heff_dup(v_xs_242), v_s_2444));
    V v_t_2447 = heff_arrayToList(heff_take_field(v_cases_2445, 0));
    V v_t_2448 = heff_arrayToList(heff_get_n(v_cases_2445, 2, 3));
    V v_t_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_x2_2453 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam3, 1, 2, (V[]){v_c_240, v_xs_242}), v_t_2449));
    V v_t_2456;
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_Nil: {
      v_t_2456 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_xs_2455 = heff_field(v_x2_2453, 1);
      heff_take_n(v_x2_2453, 3ULL, 2);
      v_t_2456 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str17); V a_1 = v_x_2454; V a_2 = v_xs_2455; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2455); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2453);
    }
    V v_s_2457 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str18), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str19), v_t_2456)));
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str20), heff_strAppend(v_s_2457, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str21)));
    } else {
      return v_s_2457;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2459 = heff_field(v_e_243, 0);
    V v_x_2460 = heff_field(v_e_243, 1);
    V v_v_2461 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2462 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_dup(v_c_240), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2459));
    V v_t_2463 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), v_xs_242, v_v_2461));
    V v_s_2464 = heff_strAppend(v_t_2462, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str22), heff_strAppend(v_x_2460, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str23), heff_strAppend(v_t_2463, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str24))))));
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str25), heff_strAppend(v_s_2464, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str26)));
    } else {
      return v_s_2464;
    }
  }
  case TAG_SIs: {
    V v_e2_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2466;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str27);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str28);
  }
  case TAG_SRec: {
    V v_e2_2467 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2467;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SFix: {
    V v_e2_27_2469 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2469)) {
    case TAG_MkAbs: {
      V v_x_2470 = heff_field(v_e2_27_2469, 0);
      heff_take_n(v_e2_27_2469, 1ULL, 2);
      return v_x_2470;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2469, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str29);
    }
    default: return heff_nomatch(v_e2_27_2469);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2474 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_p_241;
    V t_2 = v_xs_242;
    V t_3 = v_e2_2474;
    v_c_240 = t_0;
    v_p_241 = t_1;
    v_xs_242 = t_2;
    v_e_243 = t_3;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str30), heff_strAppend(v_x_2475, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str31)));
  }
  case TAG_SMetaApp: {
    V v_m_2476 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str32), heff_intShow(v_m_2476));
  }
  case TAG_SLitInt: {
    V v_i_2479 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2479);
  }
  case TAG_SLitFloat: {
    V v_x_2480 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2480);
  }
  case TAG_SLitString: {
    V v_s_2481 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2482 = (g_heff_2eutil_2erune_2equoteGo(v_s_2481, MK_INT(0LL), ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str34), heff_strAppend(v_t_2482, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str35)));
  }
  case TAG_SLitRune: {
    V v_ch_2483 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2484 = (g_heff_2eutil_2erune_2equoted(v_ch_2483));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str36), heff_strAppend(v_t_2484, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str37)));
  }
  case TAG_SLitFixed: {
    V v_n_2486 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2486);
  }
  case TAG_SLitFloat32: {
    V v_x_2487 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_c_240, 2);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2487);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_f_2417, 0);
    V v_e_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 3ULL, 2);
    return heff_strAppend(v_l_2418, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_str2), (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), v_xs_242, v_e_2419))));
  }
  default: return heff_nomatch(v_f_2417);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(2LL), v_xs_242, v_a_2432));
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(v_c_240, MK_INT(0LL), v_xs_242, v_a_2439));
}
V g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019_lam3(V self, V *args) {
  V v_alt_2450 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_intAdd(heff_take_field(v_c_240, 1), MK_INT(2LL));
  V v_t_2452 = ({ V rv_1 = v_t_2451; V rr_ = heff_rec_reuse_n(v_c_240, 1ULL, 2, shape_im__indent); heff_rfield(rr_, 1) = rv_1; rr_; });
  return ({ V a_0 = v_t_2452; V a_1 = v_xs_242; V a_2 = v_alt_2450; V r_ = (g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(a_0, a_1, a_2)); heff_drop(v_alt_2450); r_; });
}
Clo g_heff_2esyntax_2epsurface_2eprimitiveOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eprimitiveOf_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eprimitiveOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SCons: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SSpecialize: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SIs: {
    V v_e_2418 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V t_0 = v_e_2418;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SImplicit: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrim: {
    V v_x_2424 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SPrim = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24SPrim, TAG_Just, 1, (V[]){v_x_2424});
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLitFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2epsurface_2eprimitiveOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eprimitiveOf(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2estripIs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2estripIs_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2estripIs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_SLocal: {
    return v_e_240;
  }
  case TAG_SGlobal: {
    return v_e_240;
  }
  case TAG_SCode: {
    return v_e_240;
  }
  case TAG_SApp: {
    return v_e_240;
  }
  case TAG_SLam: {
    return v_e_240;
  }
  case TAG_SCons: {
    return v_e_240;
  }
  case TAG_SProj: {
    return v_e_240;
  }
  case TAG_STag: {
    return v_e_240;
  }
  case TAG_SMatch: {
    return v_e_240;
  }
  case TAG_SSpecialize: {
    return v_e_240;
  }
  case TAG_SIs: {
    V v_e1_2418 = heff_field(v_e_240, 0);
    heff_take_n(v_e_240, 1ULL, 1);
    V t_0 = v_e1_2418;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_SOpaque: {
    return v_e_240;
  }
  case TAG_SAbandon: {
    return v_e_240;
  }
  case TAG_SRec: {
    return v_e_240;
  }
  case TAG_SFix: {
    return v_e_240;
  }
  case TAG_SImplicit: {
    return v_e_240;
  }
  case TAG_SPrim: {
    return v_e_240;
  }
  case TAG_SMetaApp: {
    return v_e_240;
  }
  case TAG_SLitInt: {
    return v_e_240;
  }
  case TAG_SLitFloat: {
    return v_e_240;
  }
  case TAG_SLitString: {
    return v_e_240;
  }
  case TAG_SLitRune: {
    return v_e_240;
  }
  case TAG_SLitFixed: {
    return v_e_240;
  }
  case TAG_SLitFloat32: {
    return v_e_240;
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2esyntax_2epsurface_2estripIs_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2estripIs(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2eunIsTy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eunIsTy_entry, 1, 0};

V g_heff_2esyntax_2epsurface_2eunIsTy(V v_d_240) {
top: ;
  switch (heff_tag_of(v_d_240)) {
  case TAG_SU: {
    return v_d_240;
  }
  case TAG_SDecode: {
    return v_d_240;
  }
  case TAG_SFunction: {
    return v_d_240;
  }
  case TAG_SRecord: {
    return v_d_240;
  }
  case TAG_SSum: {
    return v_d_240;
  }
  case TAG_SIsTy: {
    V v_d1_2412 = heff_field(v_d_240, 0);
    heff_take_n(v_d_240, 1ULL, 1);
    V t_0 = v_d1_2412;
    v_d_240 = t_0;
    goto top;
  }
  case TAG_SPrimInt: {
    return v_d_240;
  }
  case TAG_SPrimFloat: {
    return v_d_240;
  }
  case TAG_SPrimString: {
    return v_d_240;
  }
  case TAG_SPrimRune: {
    return v_d_240;
  }
  case TAG_SPrimArray: {
    return v_d_240;
  }
  case TAG_SFixed: {
    return v_d_240;
  }
  default: return heff_nomatch(v_d_240);
  }
}
V g_heff_2esyntax_2epsurface_2eunIsTy_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eunIsTy(a[0]);
}
Clo g_heff_2esyntax_2epsurface_2eformerAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eformerAt_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eformerAt(V v_params_240, V v_ns_241, V v_b_242, V v_large_243) {
top: ;
  switch (heff_tag_of(v_b_242)) {
  case TAG_SLocal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SGlobal: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCode: {
    V v_d_246 = heff_field(v_b_242, 0);
    heff_take_n(v_b_242, 1ULL, 1);
    V v_t_247 = (g_heff_2esyntax_2epsurface_2eunIsTy(v_d_246));
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, v_t_247, v_large_243});
  }
  case TAG_SApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLam: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SCons: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SProj: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_STag: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMatch: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SSpecialize: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SIs: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SOpaque: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SAbandon: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SRec: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SFix: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SImplicit: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SPrim: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SMetaApp: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitInt: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitString: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitRune: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFixed: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  case TAG_SLitFloat32: {
    return heff_rec_n(4, shape_params__names__def__large, (V[]){v_params_240, v_ns_241, heff_tag_n(TAG_SDecode, 1, (V[]){v_b_242}), v_large_243});
  }
  default: return heff_nomatch(v_b_242);
  }
}
V g_heff_2esyntax_2epsurface_2eformerAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eformerAt(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str11, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str12, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str13, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str14, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str17, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str18, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str21, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str22, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str23, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str24, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str25, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str26, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str27, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str28, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str29, 7, "Float32");
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam0(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam0, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam1(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam1, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam2(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam2, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam4(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam4, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam3(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam7(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam7, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam6(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam5(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam8(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam8, 2, 0};
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam9(V self, V *args); static Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam9, 2, 0};
Clo g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    V v_t_248 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam0_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){v_t_248, v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_249 = heff_field(v_x5_243, 0);
    V v_dom_2410 = heff_field(v_x5_243, 1);
    V v_cod_2411 = heff_field(v_x5_243, 2);
    V v_implicit_2412 = heff_field(v_x5_243, 3);
    V v_dflt_2413 = heff_field(v_x5_243, 4);
    V v_s_2421;
    switch (heff_tag_of(v_dflt_2413)) {
    case TAG_Nothing: {
      V v_t_2416 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam1_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(heff_rec_n(2, shape_im__indent, (V[]){v_t_2416, v_lit_240}), v_xs_242, v_level_249, v_dom_2410, heff_dup(v_cod_2411), v_implicit_2412));
      break;
    }
    case TAG_Just: {
      V v_d_2417 = heff_field(v_dflt_2413, 0);
      V v_t_2420 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam2_clo), NTAG(TAG_False)});
      v_s_2421 = (g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(heff_rec_n(2, shape_im__indent, (V[]){v_t_2420, v_lit_240}), v_xs_242, v_dom_2410, heff_dup(v_cod_2411), heff_dup(v_d_2417)));
      break;
    }
    default: heff_nomatch(v_dflt_2413);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str2), heff_strAppend(v_s_2421, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str3)));
    } else {
      return v_s_2421;
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_x5_243, 1);
    V v_ds_2425 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2426 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 0)));
    V v_t_2427 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2424, 2)));
    V v_fs_2428 = (g_heff_2eutil_2edict_2ezipKV(v_t_2426, v_t_2427));
    V v_t_2429 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2435 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam3, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2425)}); V a_1 = v_t_2429; V a_2 = v_fs_2428; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2428); r_; });
    V v_t_2436 = heff_get_n(v_acc_2435, 1, 2);
    V v_t_2439;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_Nil: {
      v_t_2439 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_t_2436, 0);
      V v_xs_2438 = heff_field(v_t_2436, 1);
      heff_take_n(v_t_2436, 3ULL, 2);
      v_t_2439 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str5); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str6), heff_strAppend(v_t_2439, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str7)));
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2441 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 0)));
    V v_t_2442 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2440, 2)));
    V v_t_2443 = (g_heff_2eutil_2edict_2ezipKV(v_t_2441, v_t_2442));
    V v_x2_2454 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam5, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2443));
    V v_t_2457;
    switch (heff_tag_of(v_x2_2454)) {
    case TAG_Nil: {
      v_t_2457 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2455 = heff_field(v_x2_2454, 0);
      V v_xs_2456 = heff_field(v_x2_2454, 1);
      heff_take_n(v_x2_2454, 3ULL, 2);
      v_t_2457 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str11); V a_1 = v_x_2455; V a_2 = v_xs_2456; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2456); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2454);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str12), heff_strAppend(v_t_2457, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2458 = heff_field(v_x5_243, 0);
    V v_t_2461 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam8_clo), NTAG(TAG_False)});
    HEFF_LAST return g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){v_t_2461, v_lit_240}), v_p_241, v_xs_242, v_t2_2458);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str16);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str17);
  }
  case TAG_SPrimArray: {
    V v_a_2462 = heff_field(v_x5_243, 0);
    V v_t_2465 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam9_clo), NTAG(TAG_False)});
    V v_s_2466 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str18), (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){v_t_2465, v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2462)));
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str19), heff_strAppend(v_s_2466, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str20)));
    } else {
      return v_s_2466;
    }
  }
  case TAG_SFixed: {
    V v_w_2468 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2468)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str21);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str22);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str23);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str24);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str25);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str26);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str27);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str28);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str29);
    }
    default: return heff_nomatch(v_w_2468);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam0(V self, V *args) {
  V v_a_246 = args[0];
  V v_a_247 = args[1];
  heff_drop(v_a_246);
  heff_drop(v_a_247);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam1(V self, V *args) {
  V v_a_2414 = args[0];
  V v_a_2415 = args[1];
  heff_drop(v_a_2414);
  heff_drop(v_a_2415);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam2(V self, V *args) {
  V v_a_2418 = args[0];
  V v_a_2419 = args[1];
  heff_drop(v_a_2418);
  heff_drop(v_a_2419);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam4(V self, V *args) {
  V v_a_2432 = args[0];
  V v_a_2433 = args[1];
  heff_drop(v_a_2432);
  heff_drop(v_a_2433);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam3(V self, V *args) {
  V v_acc_2430 = args[0];
  V v_f_2431 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam4_clo), NTAG(TAG_False)});
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(heff_rec_n(2, shape_im__indent, (V[]){v_t_2434, v_lit_240}), v_ds_2425, v_acc_2430, v_f_2431));
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam7(V self, V *args) {
  V v_a_2448 = args[0];
  V v_a_2449 = args[1];
  heff_drop(v_a_2448);
  heff_drop(v_a_2449);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam6(V self, V *args) {
  V v_t2_2447 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2450 = heff_rec_n(2, shape_names__hide, (V[]){((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam7_clo), NTAG(TAG_False)});
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){v_t_2450, v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2447; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2447); r_; });
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam5(V self, V *args) {
  V v_v_2444 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2444)) {
  case TAG_MkPair: {
    V v_t_2445 = heff_field(v_v_2444, 0);
    V v_ts_2446 = heff_field(v_v_2444, 1);
    V v_ru_24v_2444_24MkPair = heff_take_reuse_n(v_v_2444, 3ULL, 2);
    V v_x2_2451 = heff_tag_at_n(v_ru_24v_2444_24MkPair, TAG_Cons, 2, (V[]){v_t_2445, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam6, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2446)))});
    switch (heff_tag_of(v_x2_2451)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str8);
    }
    case TAG_Cons: {
      V v_x_2452 = heff_field(v_x2_2451, 0);
      V v_xs_2453 = heff_field(v_x2_2451, 1);
      heff_take_n(v_x2_2451, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_str9); V a_1 = v_x_2452; V a_2 = v_xs_2453; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2453); r_; });
    }
    default: return heff_nomatch(v_x2_2451);
    }
  }
  default: return heff_nomatch(v_v_2444);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam8(V self, V *args) {
  V v_a_2459 = args[0];
  V v_a_2460 = args[1];
  heff_drop(v_a_2459);
  heff_drop(v_a_2460);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
V g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166_lam9(V self, V *args) {
  V v_a_2463 = args[0];
  V v_a_2464 = args[1];
  heff_drop(v_a_2463);
  heff_drop(v_a_2464);
  return heff_dup(g_heff_2esyntax_2epsurface_2earrayNone_get());
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str1, 8, " : Type)");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str3, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str6, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str7, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str8, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str9, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str12, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str13, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str14, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str15, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str18, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str19, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str20, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str21, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str22, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str23, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str24, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str25, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str26, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str27, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str28, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str29, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str30, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str31, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str32, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str33, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str34, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str35, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str36, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerParam_str37, 1, ")");
Clo g_heff_2esyntax_2epsurface_2eformerParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eformerParam_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eformerParam(V v_ns_240, V v_x_241, V v_dom_242) {
top: ;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_SU: {
    V v_dom1_243 = heff_field(v_dom_242, 0);
    switch (heff_tag_of(v_dom1_243)) {
    case TAG_SmallU: {
      heff_drop(v_ns_240);
      if (heff_intLe_c(MK_INT(65LL), heff_strByteAt(heff_dup(v_x_241), MK_INT(0LL)))) {
        if (heff_intLe_c(heff_strByteAt(heff_dup(v_x_241), MK_INT(0LL)), MK_INT(90LL))) {
          return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str0), heff_strAppend(v_x_241, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str1)));
        } else {
          return v_x_241;
        }
      } else {
        return v_x_241;
      }
    }
    case TAG_LargeU: {
      V v_t_246 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str2), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str3), heff_strAppend(v_t_246, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str4)))));
    }
    default: return heff_nomatch(v_dom1_243);
    }
  }
  case TAG_SDecode: {
    V v_t_248 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str5), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str6), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str7)))));
  }
  case TAG_SFunction: {
    V v_t_2414 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str8), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str9), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str10)))));
  }
  case TAG_SRecord: {
    V v_t_2418 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str11), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str12), heff_strAppend(v_t_2418, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str13)))));
  }
  case TAG_SSum: {
    V v_t_2420 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str14), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str15), heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str16)))));
  }
  case TAG_SIsTy: {
    V v_t_2422 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str17), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str18), heff_strAppend(v_t_2422, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str19)))));
  }
  case TAG_SPrimInt: {
    V v_t_2423 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str20), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str21), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str22)))));
  }
  case TAG_SPrimFloat: {
    V v_t_2424 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str23), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str24), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str25)))));
  }
  case TAG_SPrimString: {
    V v_t_2425 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str26), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str27), heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str28)))));
  }
  case TAG_SPrimRune: {
    V v_t_2426 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str29), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str30), heff_strAppend(v_t_2426, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str31)))));
  }
  case TAG_SPrimArray: {
    V v_t_2428 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str32), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str33), heff_strAppend(v_t_2428, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str34)))));
  }
  case TAG_SFixed: {
    V v_t_2430 = (g_heff_2esyntax_2epsurface_2etyF_24s277684007x293375166(MK_INT(0LL), MK_INT(0LL), v_ns_240, v_dom_242));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str35), heff_strAppend(v_x_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerParam_str36), heff_strAppend(v_t_2430, ((V)&g_heff_2esyntax_2epsurface_2eformerParam_str37)))));
  }
  default: return heff_nomatch(v_dom_242);
  }
}
V g_heff_2esyntax_2epsurface_2eformerParam_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2esyntax_2epsurface_2eformerParam(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2esyntax_2epsurface_2etypeFormer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etypeFormer_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etypeFormer(V v_t_240, V v_body_241, V v_ns_242, V v_params_243) {
top: ;
  switch (heff_tag_of(v_t_240)) {
  case TAG_SU: {
    V v_u_244 = heff_field(v_t_240, 0);
    V v_ru_24t_240_24SU = heff_take_reuse_n(v_t_240, 1ULL, 1);
    V v_t_245 = (g_heff_2esyntax_2epsurface_2estripIs(v_body_241));
    V v_t_246;
    switch (heff_tag_of(v_u_244)) {
    case TAG_SmallU: {
      v_t_246 = NTAG(TAG_False);
      break;
    }
    case TAG_LargeU: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_u_244);
    }
    return heff_tag_at_n(v_ru_24t_240_24SU, TAG_Just, 1, (V[]){(g_heff_2esyntax_2epsurface_2eformerAt(v_params_243, v_ns_242, v_t_245, v_t_246))});
  }
  case TAG_SDecode: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_2425 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_2425;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFunction: {
    V v_dom_2443 = heff_dup(heff_field(v_t_240, 1));
    V v_t3_2444 = heff_dup(heff_field(v_t_240, 2));
    V v_t4_2445 = heff_dup(heff_field(v_t_240, 3));
    switch (heff_tag_of(v_t3_2444)) {
    case TAG_MkAbs: {
      V v_cod_2448 = heff_field(v_t3_2444, 1);
      V v_ru_24t3_2444_24MkAbs = heff_take_reuse_n(v_t3_2444, 2ULL, 2);
      switch (heff_tag_of(v_t4_2445)) {
      case TAG_Expl: {
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          V v_it2_2455 = heff_field(v_body_241, 1);
          V v_ru_24body_241_24SLam = heff_take_reuse_n(v_body_241, 2ULL, 2);
          heff_drop_tag(v_t_240, 5);
          switch (heff_tag_of(v_it2_2455)) {
          case TAG_MkAbs: {
            V v_x_2456 = heff_field(v_it2_2455, 0);
            V v_b_2457 = heff_field(v_it2_2455, 1);
            heff_take_n(v_it2_2455, 3ULL, 2);
            V v_t_2458 = ({ V a_0 = heff_dup(v_ns_242); V a_1 = heff_dup(v_x_2456); V a_2 = v_dom_2443; V r_ = (g_heff_2esyntax_2epsurface_2eformerParam(a_0, a_1, a_2)); heff_drop(v_dom_2443); r_; });
            V v_t_2459 = heff_tag_at_n(v_ru_24t3_2444_24MkAbs, TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
            V v_t_2460 = (g_prelude_2e_2b_2b(v_params_243, v_t_2459));
            V t_0 = v_cod_2448;
            V t_1 = v_b_2457;
            V t_2 = heff_tag_at_n(v_ru_24body_241_24SLam, TAG_Cons, 2, (V[]){v_x_2456, v_ns_242});
            V t_3 = v_t_2460;
            v_t_240 = t_0;
            v_body_241 = t_1;
            v_ns_242 = t_2;
            v_params_243 = t_3;
            goto top;
          }
          case TAG_AbsConst: {
            heff_take_n(v_it2_2455, 0ULL, 1);
            heff_drop(v_ns_242);
            heff_drop(v_params_243);
            heff_drop(v_dom_2443);
            heff_drop(v_cod_2448);
            heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
            heff_drop_cell(v_ru_24body_241_24SLam, 2);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it2_2455);
          }
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_2472 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          V t_0 = v_t_240;
          V t_1 = v_b_2472;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          heff_drop(v_dom_2443);
          heff_drop(v_cod_2448);
          heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Impl: {
        heff_drop(v_dom_2443);
        heff_drop(v_cod_2448);
        heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24106 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24106;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      case TAG_Inst: {
        heff_drop(v_dom_2443);
        heff_drop(v_cod_2448);
        heff_drop_cell(v_ru_24t3_2444_24MkAbs, 2);
        switch (heff_tag_of(v_body_241)) {
        case TAG_SLocal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SGlobal: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCode: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SApp: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLam: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SCons: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SProj: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_STag: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMatch: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SSpecialize: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SIs: {
          V v_b_24140 = heff_field(v_body_241, 0);
          heff_take_n(v_body_241, 1ULL, 1);
          V t_0 = v_t_240;
          V t_1 = v_b_24140;
          V t_2 = v_ns_242;
          V t_3 = v_params_243;
          v_t_240 = t_0;
          v_body_241 = t_1;
          v_ns_242 = t_2;
          v_params_243 = t_3;
          goto top;
        }
        case TAG_SOpaque: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SAbandon: {
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SRec: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SFix: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SImplicit: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SPrim: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SMetaApp: {
          heff_take_n(v_body_241, 0ULL, 3);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitInt: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitString: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitRune: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFixed: {
          heff_take_n(v_body_241, 0ULL, 2);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        case TAG_SLitFloat32: {
          heff_take_n(v_body_241, 0ULL, 1);
          heff_drop_tag(v_t_240, 5);
          heff_drop(v_ns_242);
          heff_drop(v_params_243);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_body_241);
        }
      }
      default: return heff_nomatch(v_t4_2445);
      }
    }
    case TAG_AbsConst: {
      heff_take_n(v_t3_2444, 0ULL, 1);
      heff_drop(v_dom_2443);
      heff_drop(v_t4_2445);
      switch (heff_tag_of(v_body_241)) {
      case TAG_SLocal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCode: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SApp: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SCons: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMatch: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SSpecialize: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SIs: {
        V v_b_24175 = heff_field(v_body_241, 0);
        heff_take_n(v_body_241, 1ULL, 1);
        V t_0 = v_t_240;
        V t_1 = v_b_24175;
        V t_2 = v_ns_242;
        V t_3 = v_params_243;
        v_t_240 = t_0;
        v_body_241 = t_1;
        v_ns_242 = t_2;
        v_params_243 = t_3;
        goto top;
      }
      case TAG_SOpaque: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SAbandon: {
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SRec: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SFix: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SImplicit: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SMetaApp: {
        heff_take_n(v_body_241, 0ULL, 3);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitInt: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitString: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitRune: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFixed: {
        heff_take_n(v_body_241, 0ULL, 2);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      case TAG_SLitFloat32: {
        heff_take_n(v_body_241, 0ULL, 1);
        heff_drop_tag(v_t_240, 5);
        heff_drop(v_ns_242);
        heff_drop(v_params_243);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_body_241);
      }
    }
    default: return heff_nomatch(v_t3_2444);
    }
  }
  case TAG_SRecord: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24212 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24212;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SSum: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24247 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24247;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SIsTy: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24282 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24282;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimInt: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24316 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24316;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimFloat: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24350 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24350;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimString: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24384 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24384;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimRune: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24418 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24418;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SPrimArray: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24453 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24453;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  case TAG_SFixed: {
    switch (heff_tag_of(v_body_241)) {
    case TAG_SLocal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCode: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SApp: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SCons: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMatch: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SSpecialize: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SIs: {
      V v_b_24488 = heff_field(v_body_241, 0);
      heff_take_n(v_body_241, 1ULL, 1);
      V t_0 = v_t_240;
      V t_1 = v_b_24488;
      V t_2 = v_ns_242;
      V t_3 = v_params_243;
      v_t_240 = t_0;
      v_body_241 = t_1;
      v_ns_242 = t_2;
      v_params_243 = t_3;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SAbandon: {
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SFix: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SImplicit: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrim: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SMetaApp: {
      heff_take_n(v_body_241, 0ULL, 3);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitInt: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitString: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitRune: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_body_241, 0ULL, 2);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    case TAG_SLitFloat32: {
      heff_take_n(v_body_241, 0ULL, 1);
      heff_drop_tag(v_t_240, 1);
      heff_drop(v_ns_242);
      heff_drop(v_params_243);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_body_241);
    }
  }
  default: return heff_nomatch(v_t_240);
  }
}
V g_heff_2esyntax_2epsurface_2etypeFormer_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2etypeFormer(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str0, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str2, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str3, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str4, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str5, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str6, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str7, 1, ".");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str10, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str11, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str13, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str14, 1, "[");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str15, 1, "]");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str17, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str18, 5, "case ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str19, 3, " of");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str20, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str21, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str22, 5, " ~ { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str23, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str24, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str26, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str27, 8, "<opaque>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str28, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str29, 7, "<local>");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str30, 11, "<primitive ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str31, 1, ">");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str32, 1, "\?");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str34, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str35, 1, "\"");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str36, 1, "'");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str37, 1, "'");
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam1(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam3(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(V v_lit_240, V v_p_241, V v_xs_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_SLocal: {
    V v_i_244 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return (g_heff_2esyntax_2epsurface_2elocalName(v_xs_242, v_i_244));
  }
  case TAG_SGlobal: {
    V v_x_245 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_246 = (g_heff_2esyntax_2epsurface_2eisOperator(heff_dup(v_x_245)));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str0), heff_strAppend(v_x_245, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str1)));
    }
    case TAG_False: {
      return v_x_245;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_SCode: {
    V v_t_247 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_247; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_243, 0);
    V v_a_249 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eappStr_24s30531101x1531634430(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_tag_at_n(v_ru_24e_243_24SApp, TAG_SApp, 2, (V[]){v_f_248, v_a_249}));
  }
  case TAG_SLam: {
    V v_t_2410 = heff_field(v_e_243, 0);
    V v_b_2411 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24SLam = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2412 = (g_heff_2esyntax_2epsurface_2elambdas(heff_dup(v_xs_242), NTAG(TAG_Nil), heff_tag_at_n(v_ru_24e_243_24SLam, TAG_SLam, 2, (V[]){v_t_2410, v_b_2411})));
    return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = v_p_241; V a_2 = v_xs_242; V a_3 = v_t_2412; V r_ = (g_heff_2esyntax_2epsurface_2elamStr_24s514691199x1669395399(a_0, a_1, a_2, a_3)); heff_drop(v_xs_242); r_; });
  }
  case TAG_SCons: {
    V v_d_2413 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_p_241);
    V v_t_2414 = heff_arrayToList(heff_take_field(v_d_2413, 0));
    V v_t_2415 = heff_arrayToList(heff_get_n(v_d_2413, 2, 3));
    V v_t_2416 = (g_heff_2eutil_2edict_2ezipKV(v_t_2414, v_t_2415));
    V v_x2_2420 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam0, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2416));
    V v_t_2423;
    switch (heff_tag_of(v_x2_2420)) {
    case TAG_Nil: {
      v_t_2423 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2421 = heff_field(v_x2_2420, 0);
      V v_xs_2422 = heff_field(v_x2_2420, 1);
      heff_take_n(v_x2_2420, 3ULL, 2);
      v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str4); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2420);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str5), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str6)));
  }
  case TAG_SProj: {
    V v_e2_2424 = heff_field(v_e_243, 0);
    V v_l_2425 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    heff_drop(v_p_241);
    V v_t_2426 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_e2_2424));
    return heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str7), v_l_2425));
  }
  case TAG_STag: {
    V v_x_2427 = heff_dup(heff_field(v_e_243, 0));
    V v_ts_2428 = heff_dup(heff_field(v_e_243, 1));
    V v_t_2429 = (g_heff_2esyntax_2epsurface_2elistItems(v_e_243));
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      V v_t_2430 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(heff_dup(v_ts_2428)); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (heff_intEq_c(v_t_2430, MK_INT(0LL))) {
        heff_drop(v_lit_240);
        heff_drop(v_p_241);
        heff_drop(v_xs_242);
        heff_drop(v_ts_2428);
        return v_x_2427;
      } else {
        V v_x2_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2427, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2428)))});
        V v_s_2436;
        switch (heff_tag_of(v_x2_2433)) {
        case TAG_Nil: {
          v_s_2436 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str8);
          break;
        }
        case TAG_Cons: {
          V v_x_2434 = heff_field(v_x2_2433, 0);
          V v_xs_2435 = heff_field(v_x2_2433, 1);
          heff_take_n(v_x2_2433, 3ULL, 2);
          v_s_2436 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str9); V a_1 = v_x_2434; V a_2 = v_xs_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2435); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2433);
        }
        if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
          return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str10), heff_strAppend(v_s_2436, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str11)));
        } else {
          return v_s_2436;
        }
      }
    }
    case TAG_Just: {
      V v_items_2438 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      heff_drop(v_p_241);
      heff_drop(v_x_2427);
      heff_drop(v_ts_2428);
      V v_x2_2440 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), v_items_2438));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str13); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str14), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str15)));
    }
    default: return heff_nomatch(v_t_2429);
    }
  }
  case TAG_SMatch: {
    V v_s_2444 = heff_field(v_e_243, 0);
    V v_cases_2445 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2446 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(0LL), heff_dup(v_xs_242), v_s_2444));
    V v_t_2447 = heff_arrayToList(heff_take_field(v_cases_2445, 0));
    V v_t_2448 = heff_arrayToList(heff_get_n(v_cases_2445, 2, 3));
    V v_t_2449 = (g_heff_2eutil_2edict_2ezipKV(v_t_2447, v_t_2448));
    V v_x2_2452 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam3, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2449));
    V v_t_2455;
    switch (heff_tag_of(v_x2_2452)) {
    case TAG_Nil: {
      v_t_2455 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2453 = heff_field(v_x2_2452, 0);
      V v_xs_2454 = heff_field(v_x2_2452, 1);
      heff_take_n(v_x2_2452, 3ULL, 2);
      v_t_2455 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str17); V a_1 = v_x_2453; V a_2 = v_xs_2454; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2454); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2452);
    }
    V v_s_2456 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str18), heff_strAppend(v_t_2446, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str19), v_t_2455)));
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str20), heff_strAppend(v_s_2456, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str21)));
    } else {
      return v_s_2456;
    }
  }
  case TAG_SSpecialize: {
    V v_e2_2458 = heff_field(v_e_243, 0);
    V v_x_2459 = heff_field(v_e_243, 1);
    V v_v_2460 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_t_2461 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), heff_dup(v_lit_240)}), MK_INT(2LL), heff_dup(v_xs_242), v_e2_2458));
    V v_t_2462 = (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_v_2460));
    V v_s_2463 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str22), heff_strAppend(v_x_2459, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str23), heff_strAppend(v_t_2462, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str24))))));
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str25), heff_strAppend(v_s_2463, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str26)));
    } else {
      return v_s_2463;
    }
  }
  case TAG_SIs: {
    V v_e2_2465 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2465);
  }
  case TAG_SOpaque: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str27);
  }
  case TAG_SAbandon: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str28);
  }
  case TAG_SRec: {
    V v_e2_2466 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2466);
  }
  case TAG_SFix: {
    V v_e2_27_2468 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_e2_27_2468)) {
    case TAG_MkAbs: {
      V v_x_2469 = heff_field(v_e2_27_2468, 0);
      heff_take_n(v_e2_27_2468, 1ULL, 2);
      return v_x_2469;
    }
    case TAG_AbsConst: {
      heff_take_n(v_e2_27_2468, 0ULL, 1);
      return ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str29);
    }
    default: return heff_nomatch(v_e2_27_2468);
    }
  }
  case TAG_SImplicit: {
    V v_e2_2473 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_e2_2473);
  }
  case TAG_SPrim: {
    V v_x_2474 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str30), heff_strAppend(v_x_2474, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str31)));
  }
  case TAG_SMetaApp: {
    V v_m_2475 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 3);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str32), heff_intShow(v_m_2475));
  }
  case TAG_SLitInt: {
    V v_i_2478 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_i_2478);
  }
  case TAG_SLitFloat: {
    V v_x_2479 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2479);
  }
  case TAG_SLitString: {
    V v_s_2480 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2481 = (g_heff_2eutil_2erune_2equoteGo(v_s_2480, MK_INT(0LL), ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str33)));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str34), heff_strAppend(v_t_2481, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str35)));
  }
  case TAG_SLitRune: {
    V v_ch_2482 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    V v_t_2483 = (g_heff_2eutil_2erune_2equoted(v_ch_2482));
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str36), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str37)));
  }
  case TAG_SLitFixed: {
    V v_n_2485 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 2ULL, 2);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_intShow(v_n_2485);
  }
  case TAG_SLitFloat32: {
    V v_x_2486 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return heff_floatShow(v_x_2486);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_l_2418 = heff_field(v_f_2417, 0);
    V v_e_2419 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 3ULL, 2);
    return heff_strAppend(v_l_2418, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_str2), (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_e_2419))));
  }
  default: return heff_nomatch(v_f_2417);
  }
}
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam1(V self, V *args) {
  V v_a_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2432));
}
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam2(V self, V *args) {
  V v_a_2439 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(0LL), v_xs_242, v_a_2439));
}
V g_heff_2esyntax_2epsurface_2eelF_24s782373095x2051627714_lam3(V self, V *args) {
  V v_alt_2450 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), heff_intAdd(v_lit_240, MK_INT(2LL))});
  return ({ V a_0 = v_t_2451; V a_1 = v_xs_242; V a_2 = v_alt_2450; V r_ = (g_heff_2esyntax_2epsurface_2ealtLine_24s874977644x690986439(a_0, a_1, a_2)); heff_drop(v_alt_2450); r_; });
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str0, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str1, 6, "Theory");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str2, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str3, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str4, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str5, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str6, 2, "{ ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str7, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str9, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str10, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str11, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str12, 7, "data { ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str13, 2, " }");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str14, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str15, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str16, 6, "String");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str17, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str18, 6, "Array ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str19, 1, "(");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str20, 1, ")");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str21, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str22, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str23, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str24, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str25, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str26, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str27, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str28, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str29, 7, "Float32");
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam1(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(V v_lit_240, V v_p_241, V v_xs_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SU: {
    V v_x51_244 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_x51_244)) {
    case TAG_SmallU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str0);
    }
    case TAG_LargeU: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str1);
    }
    default: return heff_nomatch(v_x51_244);
    }
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2eelF_24s788826615x737511019(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, heff_dup(v_e_245));
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_x5_243, 0);
    V v_dom_247 = heff_field(v_x5_243, 1);
    V v_cod_248 = heff_field(v_x5_243, 2);
    V v_implicit_249 = heff_field(v_x5_243, 3);
    V v_dflt_2410 = heff_field(v_x5_243, 4);
    V v_s_2412;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowStr_24s209749798x1305674526(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_level_246, v_dom_247, heff_dup(v_cod_248), v_implicit_249));
      break;
    }
    case TAG_Just: {
      V v_d_2411 = heff_field(v_dflt_2410, 0);
      v_s_2412 = (g_heff_2esyntax_2epsurface_2earrowDefault_24s13824566x1021468133(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_xs_242, v_dom_247, heff_dup(v_cod_248), heff_dup(v_d_2411)));
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    if (heff_intLe_c(MK_INT(1LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str2), heff_strAppend(v_s_2412, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str3)));
    } else {
      return v_s_2412;
    }
  }
  case TAG_SRecord: {
    V v_fs_2415 = heff_field(v_x5_243, 1);
    V v_ds_2416 = heff_field(v_x5_243, 2);
    heff_drop(v_p_241);
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 0)));
    V v_t_2418 = heff_arrayToList(heff_dup(heff_rfield(v_fs_2415, 2)));
    V v_fs_2419 = (g_heff_2eutil_2edict_2ezipKV(v_t_2417, v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_names__out, (V[]){v_xs_242, NTAG(TAG_Nil)});
    V v_acc_2423 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam0, 2, 2, (V[]){v_lit_240, heff_dup(v_ds_2416)}); V a_1 = v_t_2420; V a_2 = v_fs_2419; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2419); r_; });
    V v_t_2424 = heff_get_n(v_acc_2423, 1, 2);
    V v_t_2427;
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_t_2424, 0);
      V v_xs_2426 = heff_field(v_t_2424, 1);
      heff_take_n(v_t_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str5); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_t_2424);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str6), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str7)));
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_x5_243, 0);
    heff_drop(v_p_241);
    V v_t_2429 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 0)));
    V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2428, 2)));
    V v_t_2431 = (g_heff_2eutil_2edict_2ezipKV(v_t_2429, v_t_2430));
    V v_x2_2439 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam1, 1, 2, (V[]){v_lit_240, v_xs_242}), v_t_2431));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str10);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str11); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str12), heff_strAppend(v_t_2442, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str13)));
  }
  case TAG_SIsTy: {
    V v_t2_2443 = heff_field(v_x5_243, 0);
    HEFF_LAST return g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_p_241, v_xs_242, v_t2_2443);
  }
  case TAG_SPrimInt: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str14);
  }
  case TAG_SPrimFloat: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str15);
  }
  case TAG_SPrimString: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str16);
  }
  case TAG_SPrimRune: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str17);
  }
  case TAG_SPrimArray: {
    V v_a_2444 = heff_field(v_x5_243, 0);
    V v_s_2445 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str18), (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), MK_INT(2LL), v_xs_242, v_a_2444)));
    if (heff_intLe_c(MK_INT(2LL), v_p_241)) {
      return heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str19), heff_strAppend(v_s_2445, ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str20)));
    } else {
      return v_s_2445;
    }
  }
  case TAG_SFixed: {
    V v_w_2447 = heff_field(v_x5_243, 0);
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    heff_drop(v_xs_242);
    switch (heff_tag_of(v_w_2447)) {
    case TAG_I8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str21);
    }
    case TAG_I16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str22);
    }
    case TAG_I32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str23);
    }
    case TAG_I64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str24);
    }
    case TAG_U8: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str25);
    }
    case TAG_U16: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str26);
    }
    case TAG_U32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str27);
    }
    case TAG_U64: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str28);
    }
    case TAG_F32: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str29);
    }
    default: return heff_nomatch(v_w_2447);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam0(V self, V *args) {
  V v_acc_2421 = args[0];
  V v_f_2422 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_ds_2416, v_acc_2421, v_f_2422));
}
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam2(V self, V *args) {
  V v_t2_2435 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = v_xs_242; V a_3 = v_t2_2435; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2435); r_; });
}
V g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam1(V self, V *args) {
  V v_v_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_xs_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2432)) {
  case TAG_MkPair: {
    V v_t_2433 = heff_field(v_v_2432, 0);
    V v_ts_2434 = heff_field(v_v_2432, 1);
    V v_ru_24v_2432_24MkPair = heff_take_reuse_n(v_v_2432, 3ULL, 2);
    V v_x2_2436 = heff_tag_at_n(v_ru_24v_2432_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_lam2, 1, 2, (V[]){v_lit_240, v_xs_242}), heff_arrayToList(v_ts_2434)))});
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str8);
    }
    case TAG_Cons: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_xs_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717_str9); V a_1 = v_x_2437; V a_2 = v_xs_2438; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2438); r_; });
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_v_2432);
  }
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str1, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str2, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str3, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str5, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str6, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str7, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str8, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str9, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str10, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str11, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str13, 2, "  ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str15, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str16, 7, "theory ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str17, 7, " where\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str18, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str19, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str20, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str21, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str22, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str23, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str24, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str25, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str28, 3, " | ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str29, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str30, 5, "data ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str31, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str33, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str34, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str35, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str36, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str37, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str38, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str39, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str40, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str41, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str42, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str43, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str44, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str45, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str46, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str47, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str49, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str50, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str51, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str52, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str53, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str54, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str55, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str56, 1, " ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str57, 5, "type ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str58, 3, " = ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str59, 1, "\012");
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam0(V self, V *args);
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam2(V self, V *args);
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam1(V self, V *args);
Clo g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_entry, 3, 0};

V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988(V v_lit_240, V v_name_241, V v_tf_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_tf_242, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    V v_ru_24t_243_24SU = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_245 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SU, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_246 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str0), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_247 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str1), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str2), heff_strAppend(v_t_247, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str3)))));
      return heff_tag_at_n(v_ru_24t_243_24SU, TAG_Just, 1, (V[]){v_t_248});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_SDecode: {
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2410 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SDecode, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2411 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str4), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2412 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str5), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str6), heff_strAppend(v_t_2412, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str7)))));
      return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_Just, 1, (V[]){v_t_2413});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_SFunction: {
    heff_take_n(v_t_243, 0ULL, 5);
    V v_t_2419 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2420 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str8), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2421 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str9), heff_strAppend(v_t_2420, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str10), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str11)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2422});
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_SRecord: {
    V v_fs_2424 = heff_field(v_t_243, 1);
    V v_ds_2425 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 3);
    V v_t_2426 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      V v_t_2427 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str12), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2428 = heff_arrayToList(heff_take_field(v_fs_2424, 0));
      V v_t_2429 = heff_arrayToList(heff_get_n(v_fs_2424, 2, 3));
      V v_fs_2430 = (g_heff_2eutil_2edict_2ezipKV(v_t_2428, v_t_2429));
      V v_t_2431 = heff_rec_n(2, shape_names__out, (V[]){heff_get_n(v_tf_242, 1, 4), NTAG(TAG_Nil)});
      V v_acc_2434 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam0, 2, 2, (V[]){v_lit_240, v_ds_2425}); V a_1 = v_t_2431; V a_2 = v_fs_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2430); r_; });
      V v_x2_2435 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str13), heff_get_n(v_acc_2434, 1, 2)));
      V v_t_2438;
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str14);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str15); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str16), heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str17), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str18)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2439});
    }
    case TAG_False: {
      heff_drop_rec(v_fs_2424, 3);
      heff_drop(v_ds_2425);
      V v_t_2440 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str19), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2441 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2442 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str20), heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str21), heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str22)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2442});
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  case TAG_SSum: {
    V v_vs_2443 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2444 = heff_dup(heff_rfield(v_tf_242, 3));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_rec(v_vs_2443, 3);
      heff_drop_cell(v_ru_24t_243_24SSum, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2445 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str23), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2446 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2443, 0)));
      V v_t_2447 = heff_arrayToList(heff_dup(heff_rfield(v_vs_2443, 2)));
      V v_x1_2448 = (g_heff_2eutil_2edict_2ezipKV(v_t_2446, v_t_2447));
      V v_t_2451;
      switch (heff_tag_of(v_x1_2448)) {
      case TAG_Nil: {
        v_t_2451 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_x1_2448, 0ULL, 2);
        v_t_2451 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x1_2448);
      }
      V v_t_2466;
      switch (heff_tag_of(v_t_2451)) {
      case TAG_True: {
        heff_drop(v_lit_240);
        heff_drop_rec(v_tf_242, 4);
        heff_drop_rec(v_vs_2443, 3);
        v_t_2466 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str24);
        break;
      }
      case TAG_False: {
        V v_t_2452 = heff_arrayToList(heff_take_field(v_vs_2443, 0));
        V v_t_2453 = heff_arrayToList(heff_get_n(v_vs_2443, 2, 3));
        V v_t_2454 = (g_heff_2eutil_2edict_2ezipKV(v_t_2452, v_t_2453));
        V v_x2_2462 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam1, 1, 2, (V[]){v_lit_240, v_tf_242}), v_t_2454));
        V v_t_2465;
        switch (heff_tag_of(v_x2_2462)) {
        case TAG_Nil: {
          v_t_2465 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str27);
          break;
        }
        case TAG_Cons: {
          V v_x_2463 = heff_field(v_x2_2462, 0);
          V v_xs_2464 = heff_field(v_x2_2462, 1);
          heff_take_n(v_x2_2462, 3ULL, 2);
          v_t_2465 = ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str28); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2462);
        }
        v_t_2466 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str29), v_t_2465);
        break;
      }
      default: heff_nomatch(v_t_2451);
      }
      V v_t_2467 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str30), heff_strAppend(v_t_2445, heff_strAppend(v_t_2466, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str31))));
      return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_Just, 1, (V[]){v_t_2467});
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  case TAG_SIsTy: {
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2469 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2469)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SIsTy, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2470 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str32), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2471 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str33), heff_strAppend(v_t_2470, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str34), heff_strAppend(v_t_2471, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str35)))));
      return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_Just, 1, (V[]){v_t_2472});
    }
    default: return heff_nomatch(v_t_2469);
    }
  }
  case TAG_SPrimInt: {
    V v_t_2473 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2473)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2474 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str36), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2475 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2476 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str37), heff_strAppend(v_t_2474, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str38), heff_strAppend(v_t_2475, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str39)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2476});
    }
    default: return heff_nomatch(v_t_2473);
    }
  }
  case TAG_SPrimFloat: {
    V v_t_2477 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2477)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2478 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str40), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2479 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2480 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str41), heff_strAppend(v_t_2478, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str42), heff_strAppend(v_t_2479, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str43)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2480});
    }
    default: return heff_nomatch(v_t_2477);
    }
  }
  case TAG_SPrimString: {
    V v_t_2481 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2481)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2482 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str44), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2483 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2484 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str45), heff_strAppend(v_t_2482, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str46), heff_strAppend(v_t_2483, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str47)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2484});
    }
    default: return heff_nomatch(v_t_2481);
    }
  }
  case TAG_SPrimRune: {
    V v_t_2485 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2485)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2486 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str48), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2487 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2488 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str49), heff_strAppend(v_t_2486, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str50), heff_strAppend(v_t_2487, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str51)))));
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2488});
    }
    default: return heff_nomatch(v_t_2485);
    }
  }
  case TAG_SPrimArray: {
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2490 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2490)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SPrimArray, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2491 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str52), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2492 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2493 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str53), heff_strAppend(v_t_2491, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str54), heff_strAppend(v_t_2492, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str55)))));
      return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_Just, 1, (V[]){v_t_2493});
    }
    default: return heff_nomatch(v_t_2490);
    }
  }
  case TAG_SFixed: {
    V v_ru_24t_243_24SFixed = heff_take_reuse_n(v_t_243, 0ULL, 1);
    V v_t_2495 = heff_take_field(v_tf_242, 3);
    switch (heff_tag_of(v_t_2495)) {
    case TAG_True: {
      heff_drop(v_lit_240);
      heff_drop(v_name_241);
      heff_drop_rec(v_tf_242, 4);
      heff_drop_cell(v_ru_24t_243_24SFixed, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_False: {
      V v_t_2496 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str56), v_name_241, heff_rfield(v_tf_242, 0)));
      V v_t_2497 = ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(0LL); V a_2 = heff_take_field(v_tf_242, 1); V b_3 = heff_get_n(v_tf_242, 2, 4); V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
      V v_t_2498 = heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str57), heff_strAppend(v_t_2496, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str58), heff_strAppend(v_t_2497, ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str59)))));
      return heff_tag_at_n(v_ru_24t_243_24SFixed, TAG_Just, 1, (V[]){v_t_2498});
    }
    default: return heff_nomatch(v_t_2495);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam0(V self, V *args) {
  V v_acc_2432 = args[0];
  V v_f_2433 = args[1];
  V v_lit_240 = heff_env(self)[0];
  V v_ds_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2epsurface_2erecordField_24s1370722783x13080258(heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}), v_ds_2425, v_acc_2432, v_f_2433));
}
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam2(V self, V *args) {
  V v_t2_2458 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = heff_rec_n(2, shape_im__indent, (V[]){heff_dup(g_heff_2esyntax_2epsurface_2eplainImplicits_get()), v_lit_240}); V a_1 = MK_INT(2LL); V a_2 = heff_get_n(v_tf_242, 1, 4); V a_3 = v_t2_2458; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1050536296x217110165(a_0, a_1, a_2, a_3)); heff_drop(v_t2_2458); r_; });
}
V g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam1(V self, V *args) {
  V v_v_2455 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_tf_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_v_2455)) {
  case TAG_MkPair: {
    V v_t_2456 = heff_field(v_v_2455, 0);
    V v_ts_2457 = heff_field(v_v_2455, 1);
    V v_ru_24v_2455_24MkPair = heff_take_reuse_n(v_v_2455, 3ULL, 2);
    V v_x2_2459 = heff_tag_at_n(v_ru_24v_2455_24MkPair, TAG_Cons, 2, (V[]){v_t_2456, (g_list_2emap(heff_clo_n(g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_lam2, 1, 2, (V[]){v_lit_240, v_tf_242}), heff_arrayToList(v_ts_2457)))});
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_Nil: {
      return ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str25);
    }
    case TAG_Cons: {
      V v_x_2460 = heff_field(v_x2_2459, 0);
      V v_xs_2461 = heff_field(v_x2_2459, 1);
      heff_take_n(v_x2_2459, 3ULL, 2);
      return ({ V a_0 = ((V)&g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988_str26); V a_1 = v_x_2460; V a_2 = v_xs_2461; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2461); r_; });
    }
    default: return heff_nomatch(v_x2_2459);
    }
  }
  default: return heff_nomatch(v_v_2455);
  }
}
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str0, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str2, 3, " : ");
HEFF_LIT(g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str3, 1, "\012");
Clo g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_entry, 4, 0};

V g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761(V v_name_240, V v_shown_241, V v_t_242, V v_body_243) {
top: ;
  V v_t_244 = (g_heff_2esyntax_2epsurface_2eprimitiveOf(heff_dup(v_body_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_242));
    V v_d_246 = heff_strAppend(v_shown_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str0), heff_strAppend(v_t_245, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str1))));
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_name_240), NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2esyntax_2epsurface_2etypeFormer(v_t_242, v_body_243, v_t_247, NTAG(TAG_Nil)));
    V v_x2_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_name_240);
      v_x2_2410 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_tf_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_x2_2410 = (g_heff_2esyntax_2epsurface_2eformerOf_24s1918924696x858537988(MK_INT(0LL), v_name_240, v_tf_249));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nothing: {
      return v_d_246;
    }
    case TAG_Just: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      heff_take_n(v_x2_2410, 1ULL, 1);
      heff_drop(v_d_246);
      return v_x_2411;
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  case TAG_Just: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop(v_name_240);
    heff_drop(v_body_243);
    V v_t_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V a_3 = v_t_242; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s382504448x106840717(a_0, a_1, a_2, a_3)); heff_drop(v_t_242); r_; });
    return heff_strAppend(v_shown_241, heff_strAppend(((V)&g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str2), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_str3))));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2epsurface_2eprintSig_24s900402920x1370327761(a[0], a[1], a[2], a[3]);
}