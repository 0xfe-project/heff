// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Fresh 58834
#define TAG_HS 9084
#define TAG_Inlined 13187
#define TAG_Kept 49931
#define TAG_MkArm 55352
#define TAG_NotInlined 18181
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define LBL_all 306203
#define LBL_applyTo 1586120902
#define LBL_args 9498020
#define LBL_base 9511832
#define LBL_binds 295100400
#define LBL_body 9524841
#define LBL_copies 592412158
#define LBL_count 296209705
#define LBL_defs 9574869
#define LBL_depth 296830685
#define LBL_depths 611816763
#define LBL_done 9584713
#define LBL_e 319
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_holes 300818381
#define LBL_kept 9783717
#define LBL_key 315609
#define LBL_kinds 303412089
#define LBL_kp 10188
#define LBL_made 9839068
#define LBL_madeFresh 950075604
#define LBL_match 305026527
#define LBL_n 328
#define LBL_name 9869138
#define LBL_off 319465
#define LBL_op 10312
#define LBL_plain 308106724
#define LBL_project 2070030684
#define LBL_recipe 1012227257
#define LBL_recipes 1314274025
#define LBL_ren 322325
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_simp 10025792
#define LBL_sp 10436
#define LBL_supply 1056026650
#define LBL_total 311908190
#define LBL_touched 1244526179
#define LBL_underLam 296337946
#define LBL_vars 10107635
#define LBL_ver 326173
#define LBL_vers 10111479
static uint32_t shape_all__kinds__recipes__depths__made__count__off[] = {LBL_all, LBL_kinds, LBL_recipes, LBL_depths, LBL_made, LBL_count, LBL_off};
static uint32_t shape_args__vars__holes[] = {LBL_args, LBL_vars, LBL_holes};
static uint32_t shape_binds__args[] = {LBL_binds, LBL_args};
static uint32_t shape_count__underLam[] = {LBL_count, LBL_underLam};
static uint32_t shape_defs__supply__done__copies[] = {LBL_defs, LBL_supply, LBL_done, LBL_copies};
static uint32_t shape_e__vars__holes__n[] = {LBL_e, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_key__body__safe__touched[] = {LBL_key, LBL_body, LBL_safe, LBL_touched};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_name__ver__recipe__depth__safe__made[] = {LBL_name, LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
static uint32_t shape_ren__vars__holes__n[] = {LBL_ren, LBL_vars, LBL_holes, LBL_n};
static uint32_t shape_safe__total[] = {LBL_safe, LBL_total};
static uint32_t shape_simp__applyTo__project__match[] = {LBL_simp, LBL_applyTo, LBL_project, LBL_match};
static uint32_t shape_supply__fuel__defs__safe__base__total__plain__sp__kp[] = {LBL_supply, LBL_fuel, LBL_defs, LBL_safe, LBL_base, LBL_total, LBL_plain, LBL_sp, LBL_kp};
static uint32_t shape_vers__kept__touched__fresh__madeFresh[] = {LBL_vers, LBL_kept, LBL_touched, LBL_fresh, LBL_madeFresh};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(V, V, V);
V g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2elamW(V, V);
V g_heff_2ecompile_2eir_2elamW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2elamW_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
V g_heff_2ecompile_2eir_2esizeW(V, V);
V g_heff_2ecompile_2eir_2esizeW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeW_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
V g_heff_2ecompile_2eirtext_2ehashW(V, V, V);
V g_heff_2ecompile_2eirtext_2ehashW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2ehashW_clo;
V g_heff_2ecompile_2eprims_2eallPrims_get(void);
V g_heff_2ecompile_2eprims_2eprimArityGo(V, V);
V g_heff_2ecompile_2eprims_2eprimArityGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2eprimArityGo_clo;
V g_heff_2ecompile_2esimplify_2eafresh(V, V);
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eafresh_clo;
V g_heff_2ecompile_2esimplify_2eallAsked(V, V);
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eallAsked_clo;
V g_heff_2ecompile_2esimplify_2eappendL(V, V);
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eappendL_clo;
V g_heff_2ecompile_2esimplify_2eapplyLam(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo;
V g_heff_2ecompile_2esimplify_2eapplyToF(V, V, V);
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo;
V g_heff_2ecompile_2esimplify_2eask(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eask_clo;
V g_heff_2ecompile_2esimplify_2easkKept(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkKept_clo;
V g_heff_2ecompile_2esimplify_2easkedFor(V, V, V, V);
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2easkedFor_clo;
V g_heff_2ecompile_2esimplify_2eattempt(V, V, V);
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eattempt_clo;
V g_heff_2ecompile_2esimplify_2ebackTo(V, V);
V g_heff_2ecompile_2esimplify_2ebackTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebackTo_clo;
V g_heff_2ecompile_2esimplify_2ebinOp(V, V, V);
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ebinOp_clo;
V g_heff_2ecompile_2esimplify_2ebudget_get(void);
V g_heff_2ecompile_2esimplify_2ecallOf(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecallOf_clo;
V g_heff_2ecompile_2esimplify_2ecaseBudget_get(void);
V g_heff_2ecompile_2esimplify_2ecaseOfCase(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo;
V g_heff_2ecompile_2esimplify_2ecatMaybesS(V);
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo;
V g_heff_2ecompile_2esimplify_2echeap(V, V);
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2echeap_clo;
V g_heff_2ecompile_2esimplify_2eclosedKnown(V);
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo;
V g_heff_2ecompile_2esimplify_2eclosedUses_get(void);
V g_heff_2ecompile_2esimplify_2econcatDefs(V);
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo;
V g_heff_2ecompile_2esimplify_2ecopiesDone(V, V);
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo;
V g_heff_2ecompile_2esimplify_2ecopy(V, V);
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopy_clo;
V g_heff_2ecompile_2esimplify_2ecopyVer(V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo;
V g_heff_2ecompile_2esimplify_2ecopyWith(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo;
V g_heff_2ecompile_2esimplify_2edepthOf(V, V, V);
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edepthOf_clo;
V g_heff_2ecompile_2esimplify_2edoneOf(V, V, V, V);
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edoneOf_clo;
V g_heff_2ecompile_2esimplify_2edropL(V, V);
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2edropL_clo;
V g_heff_2ecompile_2esimplify_2eelemStr(V, V);
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eelemStr_clo;
V g_heff_2ecompile_2esimplify_2eeta(V, V);
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eeta_clo;
V g_heff_2ecompile_2esimplify_2eetaHead(V, V, V);
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eetaHead_clo;
V g_heff_2ecompile_2esimplify_2efailing_get(void);
V g_heff_2ecompile_2esimplify_2efewerThan(V, V);
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efewerThan_clo;
V g_heff_2ecompile_2esimplify_2efieldIn(V, V);
V g_heff_2ecompile_2esimplify_2efieldIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efieldIn_clo;
V g_heff_2ecompile_2esimplify_2efindArm(V, V);
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindArm_clo;
V g_heff_2ecompile_2esimplify_2efindField(V, V);
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efindField_clo;
V g_heff_2ecompile_2esimplify_2eflat(V);
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eflat_clo;
V g_heff_2ecompile_2esimplify_2efreshName(V, V);
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshName_clo;
V g_heff_2ecompile_2esimplify_2efreshParams(V, V);
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2efreshParams_clo;
V g_heff_2ecompile_2esimplify_2einlineCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2einlineCall_clo;
V g_heff_2ecompile_2esimplify_2einlineMax_get(void);
V g_heff_2ecompile_2esimplify_2eintOp(V, V, V);
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eintOp_clo;
V g_heff_2ecompile_2esimplify_2eisPure(V, V);
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eisPure_clo;
V g_heff_2ecompile_2esimplify_2ekeepParams(V, V);
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo;
V g_heff_2ecompile_2esimplify_2ekeptAsk(V, V, V);
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo;
V g_heff_2ecompile_2esimplify_2ekeptAt(V, V);
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo;
V g_heff_2ecompile_2esimplify_2eknowing(V, V, V);
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknowing_clo;
V g_heff_2ecompile_2esimplify_2eknown(V, V);
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknown_clo;
V g_heff_2ecompile_2esimplify_2eknownArg(V, V);
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownArg_clo;
V g_heff_2ecompile_2esimplify_2eknownField(V, V, V);
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eknownField_clo;
V g_heff_2ecompile_2esimplify_2elam(V, V);
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elam_clo;
V g_heff_2ecompile_2esimplify_2elamsOut(V, V);
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2elamsOut_clo;
V g_heff_2ecompile_2esimplify_2eletFloat(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletFloat_clo;
V g_heff_2ecompile_2esimplify_2eletIn(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletIn_clo;
V g_heff_2ecompile_2esimplify_2eletPure(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletPure_clo;
V g_heff_2ecompile_2esimplify_2eletSplit(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletSplit_clo;
V g_heff_2ecompile_2esimplify_2eletsOf(V, V);
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eletsOf_clo;
V g_heff_2ecompile_2esimplify_2emadeKept(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeKept_clo;
V g_heff_2ecompile_2esimplify_2emadeOf(V, V, V);
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOf_clo;
V g_heff_2ecompile_2esimplify_2emadeOne(V, V);
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emadeOne_clo;
V g_heff_2ecompile_2esimplify_2emakeEach(V, V);
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeEach_clo;
V g_heff_2ecompile_2esimplify_2emakeFresh(V, V, V);
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo;
V g_heff_2ecompile_2esimplify_2emakeOne(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emakeOne_clo;
V g_heff_2ecompile_2esimplify_2emarkCopySafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo;
V g_heff_2ecompile_2esimplify_2emarkGo(V, V, V, V);
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkGo_clo;
V g_heff_2ecompile_2esimplify_2emarkSafe(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo;
V g_heff_2ecompile_2esimplify_2emarkSafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo;
V g_heff_2ecompile_2esimplify_2emarkedOf(V, V);
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo;
V g_heff_2ecompile_2esimplify_2ematchF(V, V, V);
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ematchF_clo;
V g_heff_2ecompile_2esimplify_2emkApp(V, V);
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2emkApp_clo;
V g_heff_2ecompile_2esimplify_2enoKeep_get(void);
V g_heff_2ecompile_2esimplify_2enthE(V, V);
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2enthE_clo;
V g_heff_2ecompile_2esimplify_2eonceEach(V, V);
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eonceEach_clo;
V g_heff_2ecompile_2esimplify_2eoneDef(V, V);
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneDef_clo;
V g_heff_2ecompile_2esimplify_2eoneItem(V);
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eoneItem_clo;
V g_heff_2ecompile_2esimplify_2eothersPure(V, V);
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eothersPure_clo;
V g_heff_2ecompile_2esimplify_2eownSt(V);
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eownSt_clo;
V g_heff_2ecompile_2esimplify_2eparamsAre(V, V);
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo;
V g_heff_2ecompile_2esimplify_2epartialApp(V, V);
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialApp_clo;
V g_heff_2ecompile_2esimplify_2epartialHead(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialHead_clo;
V g_heff_2ecompile_2esimplify_2epartialOf(V, V, V);
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epartialOf_clo;
V g_heff_2ecompile_2esimplify_2eplainCall(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eplainCall_clo;
V g_heff_2ecompile_2esimplify_2eprimAppN(V, V, V);
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo;
V g_heff_2ecompile_2esimplify_2eprimFails(V);
V g_heff_2ecompile_2esimplify_2eprimFails_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprimFails_clo;
V g_heff_2ecompile_2esimplify_2eprojectF(V, V, V, V);
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eprojectF_clo;
V g_heff_2ecompile_2esimplify_2epureIn(V, V, V);
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epureIn_clo;
V g_heff_2ecompile_2esimplify_2epushArm(V, V, V, V);
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushArm_clo;
V g_heff_2ecompile_2esimplify_2epushBudget_get(void);
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2ecompile_2esimplify_2eraise(V, V);
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eraise_clo;
V g_heff_2ecompile_2esimplify_2erecordAll(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordAll_clo;
V g_heff_2ecompile_2esimplify_2erecordDef(V, V, V);
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2erecordDef_clo;
V g_heff_2ecompile_2esimplify_2eremember(V, V, V);
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eremember_clo;
V g_heff_2ecompile_2esimplify_2ereplayBody(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo;
V g_heff_2ecompile_2esimplify_2ereplayed(V, V, V);
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ereplayed_clo;
V g_heff_2ecompile_2esimplify_2esafeAs(V, V, V);
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esafeAs_clo;
V g_heff_2ecompile_2esimplify_2esetOff(V, V);
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esetOff_clo;
V g_heff_2ecompile_2esimplify_2esgFlat(V, V, V);
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgFlat_clo;
V g_heff_2ecompile_2esimplify_2esgItem(V, V);
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esgItem_clo;
V g_heff_2ecompile_2esimplify_2eshapeOne(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo;
V g_heff_2ecompile_2esimplify_2eshapesOf(V, V, V);
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo;
V g_heff_2ecompile_2esimplify_2esimpF(V, V);
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimpF_clo;
V g_heff_2ecompile_2esimplify_2esimplifyItems(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo;
V g_heff_2ecompile_2esimplify_2esimplifyProgram(V, V);
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo;
V g_heff_2ecompile_2esimplify_2esk_get(void);
V g_heff_2ecompile_2esimplify_2especArgSize_get(void);
V g_heff_2ecompile_2esimplify_2especBody(V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especBody_clo;
V g_heff_2ecompile_2esimplify_2especBodySize_get(void);
V g_heff_2ecompile_2esimplify_2especDepth_get(void);
V g_heff_2ecompile_2esimplify_2especLam(V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especLam_clo;
V g_heff_2ecompile_2esimplify_2especLimit_get(void);
V g_heff_2ecompile_2esimplify_2especMarked(V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especMarked_clo;
V g_heff_2ecompile_2esimplify_2especNamed(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especNamed_clo;
V g_heff_2ecompile_2esimplify_2especShaped(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2especShaped_clo;
V g_heff_2ecompile_2esimplify_2esplitArgs(V, V);
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo;
V g_heff_2ecompile_2esimplify_2estillCall(V, V);
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estillCall_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2esimplify_2esubstCopies(V, V, V);
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo;
V g_heff_2ecompile_2esimplify_2esubstMarked(V, V, V, V);
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo;
V g_heff_2ecompile_2esimplify_2etakeL(V, V);
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakeL_clo;
V g_heff_2ecompile_2esimplify_2etakesMore(V, V, V);
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etakesMore_clo;
V g_heff_2ecompile_2esimplify_2etouch(V, V, V);
V g_heff_2ecompile_2esimplify_2etouch_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etouch_clo;
V g_heff_2ecompile_2esimplify_2etraverseS(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817(V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(V, V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_clo;
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V);
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo;
V g_heff_2ecompile_2esimplify_2etrySpec(V, V, V, V);
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2etrySpec_clo;
V g_heff_2ecompile_2esimplify_2eunOp(V, V);
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eunOp_clo;
V g_heff_2ecompile_2esimplify_2evarsAre(V, V);
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2evarsAre_clo;
V g_heff_2ecompile_2esimplify_2eversAll(V);
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2eversAll_clo;
V g_heff_2ecompile_2esimplify_2ezipL(V, V);
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2ezipL_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eall_24s455618083x1946283732(V, V);
V g_list_2eall_24s455618083x1946283732_entry(V self, V *a);
extern Clo g_list_2eall_24s455618083x1946283732_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1107779796x153132813(V);
V g_list_2eany_24s1107779796x153132813_entry(V self, V *a);
extern Clo g_list_2eany_24s1107779796x153132813_clo;
V g_list_2eany_24s228396297x1310020012(V);
V g_list_2eany_24s228396297x1310020012_entry(V self, V *a);
extern Clo g_list_2eany_24s228396297x1310020012_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1948306825x2028893715(V, V);
V g_list_2efoldl_24s1948306825x2028893715_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1948306825x2028893715_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2efoldl_24s85178867x1278479365(V, V, V, V, V);
V g_list_2efoldl_24s85178867x1278479365_entry(V self, V *a);
extern Clo g_list_2efoldl_24s85178867x1278479365_clo;
V g_list_2efoldl_24s905606722x2129703274(V, V, V);
V g_list_2efoldl_24s905606722x2129703274_entry(V self, V *a);
extern Clo g_list_2efoldl_24s905606722x2129703274_clo;
V g_list_2efoldl_24s91733047x1482905949(V, V);
V g_list_2efoldl_24s91733047x1482905949_entry(V self, V *a);
extern Clo g_list_2efoldl_24s91733047x1482905949_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1123370502x1982532655(V);
V g_list_2emap_24s1123370502x1982532655_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s2067043448x720245267(V);
V g_list_2emap_24s2067043448x720245267_entry(V self, V *a);
extern Clo g_list_2emap_24s2067043448x720245267_clo;
V g_list_2emap_24s379119719x1394241001(V);
V g_list_2emap_24s379119719x1394241001_entry(V self, V *a);
extern Clo g_list_2emap_24s379119719x1394241001_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24s73473062x206541869(V);
V g_list_2emap_24s73473062x206541869_entry(V self, V *a);
extern Clo g_list_2emap_24s73473062x206541869_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s237481877x1031762735(V, V, V);
V g_list_2ezipWith_24s237481877x1031762735_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s237481877x1031762735_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;

static V g_heff_2ecompile_2esimplify_2ebudget_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2ebudget_st;
static V g_heff_2ecompile_2esimplify_2ebudget_init(void) {
  return MK_INT(24LL);
}
V g_heff_2ecompile_2esimplify_2ebudget_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2ebudget_st)) return g_heff_2ecompile_2esimplify_2ebudget_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2ebudget_val, &g_heff_2ecompile_2esimplify_2ebudget_st, g_heff_2ecompile_2esimplify_2ebudget_init);
}

static V g_heff_2ecompile_2esimplify_2enoKeep_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2enoKeep_st;
static V g_heff_2ecompile_2esimplify_2enoKeep_init(void) {
  return heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
}
V g_heff_2ecompile_2esimplify_2enoKeep_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2enoKeep_st)) return g_heff_2ecompile_2esimplify_2enoKeep_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2enoKeep_val, &g_heff_2ecompile_2esimplify_2enoKeep_st, g_heff_2ecompile_2esimplify_2enoKeep_init);
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_242});
}
V g_heff_2ecompile_2esimplify_2etraverseS_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_s_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2esimplify_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_s_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_s_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2esimplify_2eappendL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eappendL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eappendL(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2esimplify_2eappendL(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eappendL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eappendL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eelemStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eelemStr_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eelemStr(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eelemStr_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eelemStr(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ezipL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ezipL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ezipL(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2ecompile_2esimplify_2ezipL(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ezipL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ezipL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2etakeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakeL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etakeL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2esimplify_2etakeL(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2etakeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakeL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2edropL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edropL_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2edropL(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2edropL_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edropL(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletsOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eletsOf(V v_x1_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_body_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      return heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), (g_heff_2ecompile_2esimplify_2eletsOf(v_rest_243, v_body_241))});
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eletsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopy_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopy(V v_e_240, V v_s_241) {
top: ;
  V v_x2_242 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850(heff_dup(g_map_2eempty_get()), heff_take_field(v_s_241, 0), v_e_240));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_e_27_243 = heff_field(v_x2_242, 0);
    V v_n_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24MkPair = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = ({ V rv_0 = v_n_244; V rr_ = heff_rec_reuse_n(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_at_n(v_ru_24x2_242_24MkPair, TAG_MkPair, 2, (V[]){v_e_27_243, v_t_245});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2esimplify_2ecopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecopy(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eknown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknown_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknown(V v_g_240, V v_s_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(v_g_240, heff_rfield(v_s_241, 2)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24Just = heff_take_reuse_n(v_t_242, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_241, 1)))) {
      V v_t_245 = heff_intSub(heff_take_field(v_s_241, 1), MK_INT(1LL));
      V v_t_246 = ({ V rv_1 = v_t_245; V rr_ = heff_rec_reuse_n(v_s_241, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_243, v_t_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_242_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    } else {
      heff_drop(v_b_243);
      heff_drop_cell(v_ru_24t_242_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_241});
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2esimplify_2eknown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknown(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eattempt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eattempt_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eattempt(V v_orig_240, V v_m_241, V v_s_242) {
top: ;
  V v_x2_243 = heff_tr(heff_call(v_m_241, 1, (V[]){heff_dup(v_s_242)}));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_orig_240), NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_lim_248 = heff_intAdd(v_t_247, heff_dup(g_heff_2ecompile_2esimplify_2ebudget_get()));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
    V v_a_2410 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_248), MK_INT(0LL), v_t_249));
    if (heff_intLt_c(v_lim_248, v_a_2410)) {
      heff_drop(v_x_244);
      V v_t_2412 = ({ V rv_2 = heff_take_field(v_s_242, 2); V rv_5 = heff_get_n(v_s_242, 5, 9); V rr_ = heff_rec_reuse_n(v_s_245, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_orig_240, v_t_2412});
    } else {
      heff_drop(v_orig_240);
      heff_drop_rec(v_s_242, 9);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_244, v_s_245});
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2eattempt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eattempt(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str0, 7, "perform");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str1, 8, "arraySet");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str2, 13, "arrayGenerate");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str3, 10, "floatFloor");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str4, 10, "arrayIndex");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str5, 6, "intShl");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str6, 6, "intShr");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str7, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efailing_str8, 6, "intMod");

static V g_heff_2ecompile_2esimplify_2efailing_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2efailing_st;
static V g_heff_2ecompile_2esimplify_2efailing_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str6), v_t_242})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2esimplify_2efailing_str8), v_t_243})});
}
V g_heff_2ecompile_2esimplify_2efailing_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2efailing_st)) return g_heff_2ecompile_2esimplify_2efailing_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2efailing_val, &g_heff_2ecompile_2esimplify_2efailing_st, g_heff_2ecompile_2esimplify_2efailing_init);
}
Clo g_heff_2ecompile_2esimplify_2eprimFails_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimFails_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eprimFails(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = heff_dup(v_p_240); V b_1 = heff_dup(g_heff_2ecompile_2esimplify_2efailing_get()); V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_x3_242 = (g_heff_2eelab_2efixed_2efixedPrimOf(v_p_240));
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      V v_t_244 = heff_get_n(v_x_243, 1, 2);
      switch (heff_tag_of(v_t_244)) {
      case TAG_OpAdd: {
        return NTAG(TAG_False);
      }
      case TAG_OpSub: {
        return NTAG(TAG_False);
      }
      case TAG_OpMul: {
        return NTAG(TAG_False);
      }
      case TAG_OpDiv: {
        return NTAG(TAG_True);
      }
      case TAG_OpRem: {
        return NTAG(TAG_True);
      }
      case TAG_OpEq: {
        return NTAG(TAG_False);
      }
      case TAG_OpLt: {
        return NTAG(TAG_False);
      }
      case TAG_OpLe: {
        return NTAG(TAG_False);
      }
      case TAG_OpAnd: {
        return NTAG(TAG_False);
      }
      case TAG_OpOr: {
        return NTAG(TAG_False);
      }
      case TAG_OpXor: {
        return NTAG(TAG_False);
      }
      case TAG_OpShl: {
        return NTAG(TAG_False);
      }
      case TAG_OpShr: {
        return NTAG(TAG_False);
      }
      case TAG_OpShow: {
        return NTAG(TAG_False);
      }
      case TAG_OpFromInt: {
        return NTAG(TAG_False);
      }
      case TAG_OpToInt: {
        return NTAG(TAG_False);
      }
      case TAG_OpSqrt: {
        return NTAG(TAG_False);
      }
      case TAG_OpFromFloat: {
        return NTAG(TAG_False);
      }
      case TAG_OpToFloat: {
        return NTAG(TAG_False);
      }
      case TAG_OpFloor: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2esimplify_2eprimFails_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimFails(a[0]);
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2epureIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epureIn_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epureIn(V v_safe_240, V v_total_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_e_242, 0);
    V v_x3_245 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_244), v_safe_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    V v_e1_249 = heff_field(v_e_242, 0);
    V v_as_2410 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_e1_249)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_2412 = heff_field(v_e1_249, 0);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2412), v_total_241));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_ar_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2415 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2410));
        if (heff_intLe_c(v_t_2415, v_ar_2414)) {
          V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam0, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2410)));
          return ({ V a_0 = v_t_2418; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2418); r_; });
        } else {
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_e1_249);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2450 = heff_field(v_e_242, 0);
    V v_t_2454 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam1, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_fs_2450)));
    return ({ V a_0 = v_t_2454; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2454); r_; });
  }
  case TAG_EProj: {
    V v_e2_2455 = heff_field(v_e_242, 0);
    V t_0 = v_safe_240;
    V t_1 = v_total_241;
    V t_2 = v_e2_2455;
    v_safe_240 = t_0;
    v_total_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2459 = heff_field(v_e_242, 1);
    V v_t_2461 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam2, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2459)));
    return ({ V a_0 = v_t_2461; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2461); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2465 = heff_field(v_e_242, 0);
    V v_as_2466 = heff_field(v_e_242, 1);
    V v_x1_2467 = (g_heff_2ecompile_2esimplify_2eprimFails(heff_dup(v_p_2465)));
    switch (heff_tag_of(v_x1_2467)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_2469 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam3, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2466)));
      return ({ V a_0 = v_t_2469; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2469); r_; });
    }
    default: return heff_nomatch(v_x1_2467);
    }
  }
  case TAG_ECall: {
    V v_g_2470 = heff_field(v_e_242, 0);
    V v_as_2471 = heff_field(v_e_242, 1);
    V v_t_2472 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_2470), v_total_241));
    switch (heff_tag_of(v_t_2472)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_ar_2473 = heff_field(v_t_2472, 0);
      heff_take_n(v_t_2472, 1ULL, 1);
      V v_t_2474 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2471));
      if (heff_intLe_c(v_t_2474, v_ar_2473)) {
        V v_t_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2epureIn_lam4, 1, 2, (V[]){heff_dup(v_safe_240), heff_dup(v_total_241)}), heff_dup(v_as_2471)));
        return ({ V a_0 = v_t_2477; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2477); r_; });
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_t_2472);
    }
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epureIn(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2epureIn_lam0(V self, V *args) {
  V v_a_2417 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2417; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2417); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam1(V self, V *args) {
  V v_p_2451 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2451)) {
  case TAG_MkPair: {
    V v_e2_2453 = heff_field(v_p_2451, 1);
    heff_take_n(v_p_2451, 2ULL, 2);
    return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_e2_2453; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_e2_2453); r_; });
  }
  default: return heff_nomatch(v_p_2451);
  }
}
V g_heff_2ecompile_2esimplify_2epureIn_lam2(V self, V *args) {
  V v_a_2460 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2460; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2460); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam3(V self, V *args) {
  V v_a_2468 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2468; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2468); r_; });
}
V g_heff_2ecompile_2esimplify_2epureIn_lam4(V self, V *args) {
  V v_a_2476 = args[0];
  V v_safe_240 = heff_env(self)[0];
  V v_total_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_safe_240; V a_1 = v_total_241; V a_2 = v_a_2476; V r_ = (g_heff_2ecompile_2esimplify_2epureIn(a_0, a_1, a_2)); heff_drop(v_safe_240); heff_drop(v_total_241); heff_drop(v_a_2476); r_; });
}
Clo g_heff_2ecompile_2esimplify_2eflat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eflat_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eflat(V v_b_240) {
top: ;
  switch (heff_tag_of(v_b_240)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_b_240, 0);
    V v_b2_244 = heff_field(v_b_240, 1);
    V v_ru_24b_240_24ELam = heff_take_reuse_n(v_b_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2eflat(v_b2_244));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_ys_246 = heff_field(v_x2_245, 0);
      V v_b_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      V v_t_248 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_243, v_ys_246));
      return heff_tag_at_n(v_ru_24b_240_24ELam, TAG_MkPair, 2, (V[]){v_t_248, v_b_247});
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_b_240});
  }
  default: return heff_nomatch(v_b_240);
  }
}
V g_heff_2ecompile_2esimplify_2eflat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eflat(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2esgFlat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgFlat_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esgFlat(V v_acc_240, V v_key_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_xs_243 = heff_field(v_x3_242, 0);
    V v_b_244 = heff_field(v_x3_242, 1);
    V v_a_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
    if (heff_intLt_c(MK_INT(0LL), v_a_245)) {
      V v_t_247 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_249 = (g_heff_2ecompile_2eir_2enubI(v_t_248));
        V v_x1_2410 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_249; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_249); r_; });
        switch (heff_tag_of(v_x1_2410)) {
        case TAG_True: {
          V v_t_2411 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_n(v_acc_240, 2ULL, 2, shape_safe__total); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
        case TAG_False: {
          V v_t_2412 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_241), NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          V v_t_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_243));
          V v_t_2414 = (g_map_2einsert_24s1341440536x470972936(v_key_241, v_t_2413, heff_get_n(v_acc_240, 1, 2)));
          return heff_rec_n(2, shape_safe__total, (V[]){v_t_2412, v_t_2414});
        }
        default: return heff_nomatch(v_x1_2410);
        }
      }
      case TAG_False: {
        V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
        return ({ V rv_0 = v_t_2415; V rr_ = heff_rec_reuse_n(v_acc_240, 2ULL, 2, shape_safe__total); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
      default: return heff_nomatch(v_t_247);
      }
    } else {
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_acc_240, 0), heff_rfield(v_acc_240, 1), v_b_244));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        V v_t_2417 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_244)));
        V v_t_2418 = (g_heff_2ecompile_2eir_2enubI(v_t_2417));
        V v_x1_2419 = ({ V a_0 = heff_dup(v_key_241); V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2418); r_; });
        switch (heff_tag_of(v_x1_2419)) {
        case TAG_True: {
          heff_drop(v_key_241);
          return v_acc_240;
        }
        case TAG_False: {
          V v_t_2420 = (g_map_2einsert_24s1341440536x470972936(v_key_241, NTAG(TAG_MkUnit), heff_take_field(v_acc_240, 0)));
          return ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_n(v_acc_240, 2ULL, 2, shape_safe__total); heff_rfield(rr_, 0) = rv_0; rr_; });
        }
        default: return heff_nomatch(v_x1_2419);
        }
      }
      case TAG_False: {
        heff_drop(v_key_241);
        return v_acc_240;
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2esgFlat_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esgFlat(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialOf(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_x31_243, 0);
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_241));
      V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_246));
      if (heff_intLt_c(v_t_248, v_t_249)) {
        V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epureIn_clo), 2, (V[]){heff_take_field(v_s_240, 3), heff_get_n(v_s_240, 5, 9)}));
        V v_t_2412 = (g_list_2emap(v_t_2411, v_as_241));
        return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
      } else {
        heff_drop_rec(v_s_240, 9);
        heff_drop(v_as_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      heff_drop(v_as_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialOf_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialOf(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2epartialHead(V v_s_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x3_242, 0);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
    V v_t_246 = ({ V a_0 = heff_dup(v_g_244); V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    return ({ V a_0 = v_s_240; V a_1 = v_as_241; V a_2 = v_t_246; V r_ = (g_heff_2ecompile_2esimplify_2epartialOf(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_as_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epartialHead_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2epartialHead(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eisPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eisPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eisPure(V v_e_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_241, 3), heff_rfield(v_s_241, 5), v_e_240));
  V v_t_2433;
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    v_t_2433 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    switch (heff_tag_of(v_e_240)) {
    case TAG_EVar: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      V v_f_247 = heff_field(v_e_240, 0);
      V v_as_248 = heff_field(v_e_240, 1);
      v_t_2433 = (g_heff_2ecompile_2esimplify_2epartialHead(heff_dup(v_s_241), heff_dup(v_as_248), v_f_247));
      break;
    }
    case TAG_ELet: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_240);
    }
    break;
  }
  default: heff_nomatch(v_t_242);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_s_241});
}
V g_heff_2ecompile_2esimplify_2eisPure_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eisPure(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str1, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str2, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str3, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str6, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str7, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str8, 5, "False");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str9, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str10, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eintOp_str11, 5, "False");
Clo g_heff_2ecompile_2esimplify_2eintOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eintOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eintOp(V v_p_240, V v_a_241, V v_b_242) {
top: ;
  if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str0))) {
    heff_drop(v_p_240);
    V v_t_244 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intAdd(v_a_241, v_b_242)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
  } else {
    if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str1))) {
      heff_drop(v_p_240);
      V v_t_246 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intSub(v_a_241, v_b_242)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_246});
    } else {
      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str2))) {
        heff_drop(v_p_240);
        V v_t_248 = heff_tag_n(TAG_EInt, 1, (V[]){heff_intMul(v_a_241, v_b_242)});
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      } else {
        if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str3))) {
          heff_drop(v_p_240);
          V v_t_2411;
          if (heff_intEq_c(v_a_241, v_b_242)) {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str4);
          } else {
            v_t_2411 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str5);
          }
          V v_t_2412 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
        } else {
          if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2eintOp_str6))) {
            heff_drop(v_p_240);
            V v_t_2415;
            if (heff_intLt_c(v_a_241, v_b_242)) {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str7);
            } else {
              v_t_2415 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str8);
            }
            V v_t_2416 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
            return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
          } else {
            if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eintOp_str9))) {
              V v_t_2419;
              if (heff_intLe_c(v_a_241, v_b_242)) {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str10);
              } else {
                v_t_2419 = ((V)&g_heff_2ecompile_2esimplify_2eintOp_str11);
              }
              V v_t_2420 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
              return heff_tag_n(TAG_Just, 1, (V[]){v_t_2420});
            } else {
              heff_drop(v_a_241);
              heff_drop(v_b_242);
              return NTAG(TAG_Nothing);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ecompile_2esimplify_2eintOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eintOp(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str0, 7, "intShow");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eunOp_str1, 9, "strLength");
Clo g_heff_2ecompile_2esimplify_2eunOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eunOp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eunOp(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2424 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EInt = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str0))) {
      V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24EInt, TAG_EStr, 1, (V[]){heff_intShow(v_a_2424)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2426});
    } else {
      heff_drop(v_a_2424);
      heff_drop_cell(v_ru_24x2_241_24EInt, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2428 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2eunOp_str1))) {
      V v_t_2430 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EInt, 1, (V[]){heff_strLength(v_a_2428)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
    } else {
      heff_drop(v_a_2428);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eunOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eunOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str0, 9, "strAppend");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str1, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ebinOp_str3, 5, "False");
Clo g_heff_2ecompile_2esimplify_2ebinOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebinOp_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ebinOp(V v_p_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    V v_a_2425 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      V v_b_2448 = heff_field(v_x3_242, 0);
      heff_take_n(v_x3_242, 1ULL, 1);
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eintOp(v_p_240, v_a_2425, v_b_2448);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2425);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    V v_a_2457 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EStr = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_EVar: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EGlobal: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELam: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EApp: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ELet: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ERecord: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EProj: {
      heff_take_n(v_x3_242, 0ULL, 3);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ETag: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EMatch: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrim: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_ECall: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EInt: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EStr: {
      V v_b_2482 = heff_field(v_x3_242, 0);
      V v_ru_24x3_242_24EStr = heff_take_reuse_n(v_x3_242, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_p_240), ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str0))) {
        heff_drop(v_p_240);
        V v_t_2484 = heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_EStr, 1, (V[]){heff_strAppend(v_a_2457, v_b_2482)});
        return heff_tag_at_n(v_ru_24x3_242_24EStr, TAG_Just, 1, (V[]){v_t_2484});
      } else {
        heff_drop_cell(v_ru_24x3_242_24EStr, 1);
        if (heff_strEq_c(v_p_240, ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str1))) {
          V v_t_2487;
          if (heff_strEq_c(v_a_2457, v_b_2482)) {
            v_t_2487 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str2);
          } else {
            v_t_2487 = ((V)&g_heff_2ecompile_2esimplify_2ebinOp_str3);
          }
          V v_t_2488 = heff_tag_n(TAG_ETag, 2, (V[]){v_t_2487, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x2_241_24EStr, TAG_Just, 1, (V[]){v_t_2488});
        } else {
          heff_drop(v_a_2457);
          heff_drop_cell(v_ru_24x2_241_24EStr, 1);
          heff_drop(v_b_2482);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_EFixed: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFloat32: {
      heff_take_n(v_x3_242, 0ULL, 1);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EAbandon: {
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_EFix: {
      heff_take_n(v_x3_242, 0ULL, 2);
      heff_drop(v_p_240);
      heff_drop(v_a_2457);
      heff_drop_cell(v_ru_24x2_241_24EStr, 1);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_p_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ebinOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebinOp(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eprimAppN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprimAppN_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eprimAppN(V v_p_240, V v_as_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
  }
  case TAG_Just: {
    V v_n_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_241));
    if (heff_intEq_c(v_t_244, heff_dup(v_n_243))) {
      heff_drop(v_n_243);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      V v_x2_2412;
      switch (heff_tag_of(v_as_241)) {
      case TAG_Nil: {
        v_x2_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_a_246 = heff_dup(heff_field(v_as_241, 0));
        V v_x22_247 = heff_dup(heff_field(v_as_241, 1));
        switch (heff_tag_of(v_x22_247)) {
        case TAG_Nil: {
          v_x2_2412 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_246));
          break;
        }
        case TAG_Cons: {
          V v_b_248 = heff_field(v_x22_247, 0);
          V v_x222_249 = heff_field(v_x22_247, 1);
          heff_take_n(v_x22_247, 3ULL, 2);
          switch (heff_tag_of(v_x222_249)) {
          case TAG_Nil: {
            v_x2_2412 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_246, v_b_248));
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x222_249, 0ULL, 2);
            heff_drop(v_a_246);
            heff_drop(v_b_248);
            v_x2_2412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x222_249);
          }
          break;
        }
        default: heff_nomatch(v_x22_247);
        }
        break;
      }
      default: heff_nomatch(v_as_241);
      }
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_Nothing: {
        return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_241});
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        heff_take_n(v_x2_2412, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop(v_as_241);
        return v_x_2413;
      }
      default: return heff_nomatch(v_x2_2412);
      }
    } else {
      V v_a_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_241));
      if (heff_intLt_c(heff_dup(v_n_243), v_a_2414)) {
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        V v_as_2416 = (g_heff_2ecompile_2esimplify_2etakeL(heff_dup(v_n_243), heff_dup(v_as_241)));
        V v_x2_2423;
        switch (heff_tag_of(v_as_2416)) {
        case TAG_Nil: {
          v_x2_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Cons: {
          V v_a_2417 = heff_dup(heff_field(v_as_2416, 0));
          V v_x22_2418 = heff_dup(heff_field(v_as_2416, 1));
          switch (heff_tag_of(v_x22_2418)) {
          case TAG_Nil: {
            v_x2_2423 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_240), v_a_2417));
            break;
          }
          case TAG_Cons: {
            V v_b_2419 = heff_field(v_x22_2418, 0);
            V v_x222_2420 = heff_field(v_x22_2418, 1);
            heff_take_n(v_x22_2418, 3ULL, 2);
            switch (heff_tag_of(v_x222_2420)) {
            case TAG_Nil: {
              v_x2_2423 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_240), v_a_2417, v_b_2419));
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_x222_2420, 0ULL, 2);
              heff_drop(v_a_2417);
              heff_drop(v_b_2419);
              v_x2_2423 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_x222_2420);
            }
            break;
          }
          default: heff_nomatch(v_x22_2418);
          }
          break;
        }
        default: heff_nomatch(v_as_2416);
        }
        V v_t_2425;
        switch (heff_tag_of(v_x2_2423)) {
        case TAG_Nothing: {
          v_t_2425 = heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_240, v_as_2416});
          break;
        }
        case TAG_Just: {
          V v_x_2424 = heff_field(v_x2_2423, 0);
          heff_take_n(v_x2_2423, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop(v_as_2416);
          v_t_2425 = v_x_2424;
          break;
        }
        default: heff_nomatch(v_x2_2423);
        }
        return heff_tag_n(TAG_EApp, 2, (V[]){v_t_2425, (g_heff_2ecompile_2esimplify_2edropL(v_n_243, v_as_241))});
      } else {
        heff_drop(v_n_243);
        return heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24Just, TAG_EPrim, 1, (V[]){v_p_240}), v_as_241});
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eprimAppN_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprimAppN(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emkApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emkApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emkApp(V v_f_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    return v_f_240;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_f_240)) {
    case TAG_EVar: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EGlobal: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ELam: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EApp: {
      V v_g_248 = heff_field(v_f_240, 0);
      V v_bs_249 = heff_field(v_f_240, 1);
      heff_take_n(v_f_240, 3ULL, 2);
      V v_t_2410 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_249, v_as_241));
      V t_0 = v_g_248;
      V t_1 = v_t_2410;
      v_f_240 = t_0;
      v_as_241 = t_1;
      goto top;
    }
    case TAG_ELet: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ERecord: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EProj: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ETag: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EMatch: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EPrim: {
      V v_p_2422 = heff_field(v_f_240, 0);
      heff_take_n(v_f_240, 1ULL, 1);
      V v_t_2423 = ({ V a_0 = heff_dup(v_p_2422); V b_1 = heff_dup(g_heff_2ecompile_2eprims_2eallPrims_get()); V r_ = (g_heff_2ecompile_2eprims_2eprimArityGo(a_0, b_1)); heff_drop(b_1); r_; });
      return (g_heff_2ecompile_2esimplify_2eprimAppN(v_p_2422, v_as_241, v_t_2423));
    }
    case TAG_EPrimCall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_ECall: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EInt: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EStr: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFixed: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFloat32: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EAbandon: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    case TAG_EFix: {
      return heff_tag_n(TAG_EApp, 2, (V[]){v_f_240, v_as_241});
    }
    default: return heff_nomatch(v_f_240);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2ecompile_2esimplify_2emkApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emkApp(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstCopies_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstCopies_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esubstCopies(V v_x_240, V v_a_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_y_243), v_x_240)) {
      heff_drop(v_y_243);
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_a_241});
    } else {
      heff_drop(v_a_241);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam0, 1, 1, (V[]){v_y_243});
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam1, 1, 1, (V[]){v_e_242});
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_e_242, 0);
    V v_b_249 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2410 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_249));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam2, 1, 2, (V[]){v_m_2410, v_xs_248});
  }
  case TAG_EApp: {
    V v_f_2415 = heff_field(v_e_242, 0);
    V v_as_2416 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2417 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_f_2415));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam3, 1, 4, (V[]){v_m_2417, v_x_240, v_a_241, v_as_2416});
  }
  case TAG_ELet: {
    V v_y_2428 = heff_field(v_e_242, 0);
    V v_e2_2429 = heff_field(v_e_242, 1);
    V v_b_2430 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2431 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_e2_2429));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam5, 1, 5, (V[]){v_m_2431, v_x_240, v_a_241, v_b_2430, v_y_2428});
  }
  case TAG_ERecord: {
    V v_fs_2440 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_m_2449 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam6, 1, 2, (V[]){v_x_240, v_a_241}), v_fs_2440));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam8, 1, 1, (V[]){v_m_2449});
  }
  case TAG_EProj: {
    V v_e2_2454 = heff_field(v_e_242, 0);
    V v_l_2455 = heff_field(v_e_242, 1);
    V v_sh_2456 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2457 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e2_2454));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam9, 1, 3, (V[]){v_m_2457, v_l_2455, v_sh_2456});
  }
  case TAG_ETag: {
    V v_t_2462 = heff_field(v_e_242, 0);
    V v_as_2463 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2465 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam10, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2463));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam11, 1, 2, (V[]){v_m_2465, v_t_2462});
  }
  case TAG_EMatch: {
    V v_s_2470 = heff_field(v_e_242, 0);
    V v_arms_2471 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2472 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(heff_dup(v_x_240), heff_dup(v_a_241), v_s_2470));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam12, 1, 4, (V[]){v_m_2472, v_x_240, v_a_241, v_arms_2471});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam15, 1, 1, (V[]){v_e_242});
  }
  case TAG_EPrimCall: {
    V v_p_2492 = heff_field(v_e_242, 0);
    V v_as_2493 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2495 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam16, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2493));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam17, 1, 2, (V[]){v_m_2495, v_p_2492});
  }
  case TAG_ECall: {
    V v_g_24100 = heff_field(v_e_242, 0);
    V v_as_24101 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_24103 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam18, 1, 2, (V[]){v_x_240, v_a_241}), v_as_24101));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam19, 1, 2, (V[]){v_m_24103, v_g_24100});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam20, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam21, 1, 1, (V[]){v_e_242});
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam22, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam23, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam24, 1, 1, (V[]){v_e_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam25, 1, 1, (V[]){v_e_242});
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    heff_drop(v_a_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam26, 1, 1, (V[]){v_e_242});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esubstCopies(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_y_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_y_243}), v_s_245});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_xs_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_s_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_248, v_x_2413}), v_s_2414});
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam4(V self, V *args) {
  V v_q_2422 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2422));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_as_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    V v_m_2423 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam4, 1, 2, (V[]){v_x_240, v_a_241}), v_as_2416));
    V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2421}));
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_MkPair: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_s_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      V v_x_2427 = (g_heff_2ecompile_2esimplify_2emkApp(v_x_2420, v_x_2425));
      return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2426});
    }
    default: return heff_nomatch(v_x2_2424);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_b_2430 = heff_env(self)[3];
  V v_y_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2430));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2428, v_x_2434, v_x_2438}), v_s_2439});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam7(V self, V *args) {
  V v_s_2445 = args[0];
  V v_m_2444 = heff_env(self)[0];
  V v_l_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2446 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_s_2445}));
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkPair: {
    V v_x_2447 = heff_field(v_x2_2446, 0);
    V v_s_2448 = heff_field(v_x2_2446, 1);
    V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2442, v_x_2447}), v_s_2448});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam6(V self, V *args) {
  V v_p_2441 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2441)) {
  case TAG_MkPair: {
    V v_l_2442 = heff_field(v_p_2441, 0);
    V v_e_2443 = heff_field(v_p_2441, 1);
    heff_take_n(v_p_2441, 3ULL, 2);
    V v_m_2444 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_e_2443));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam7, 1, 2, (V[]){v_m_2444, v_l_2442});
  }
  default: return heff_nomatch(v_p_2441);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam8(V self, V *args) {
  V v_s_2450 = args[0];
  V v_m_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2451 = heff_tr(heff_call(v_m_2449, 1, (V[]){v_s_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_s_2453 = heff_field(v_x2_2451, 1);
    V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 1, (V[]){v_x_2452}), v_s_2453});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam9(V self, V *args) {
  V v_s_2458 = args[0];
  V v_m_2457 = heff_env(self)[0];
  V v_l_2455 = heff_env(self)[1];
  V v_sh_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2459 = heff_tr(heff_call(v_m_2457, 1, (V[]){v_s_2458}));
  switch (heff_tag_of(v_x2_2459)) {
  case TAG_MkPair: {
    V v_x_2460 = heff_field(v_x2_2459, 0);
    V v_s_2461 = heff_field(v_x2_2459, 1);
    V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_x_2460, v_l_2455, v_sh_2456}), v_s_2461});
  }
  default: return heff_nomatch(v_x2_2459);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam10(V self, V *args) {
  V v_q_2464 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2464));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_t_2462 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_s_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_s_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2462, v_x_2468}), v_s_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam14(V self, V *args) {
  V v_s_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_t_2478 = heff_env(self)[1];
  V v_vs_2479 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_s_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_s_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2478, v_vs_2479, v_x_2484}), v_s_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam13(V self, V *args) {
  V v_a_2477 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_2477)) {
  case TAG_MkArm: {
    V v_t_2478 = heff_field(v_a_2477, 0);
    V v_vs_2479 = heff_field(v_a_2477, 1);
    V v_b_2480 = heff_field(v_a_2477, 2);
    heff_take_n(v_a_2477, 7ULL, 3);
    V v_m_2481 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_b_2480));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam14, 1, 3, (V[]){v_m_2481, v_t_2478, v_vs_2479});
  }
  default: return heff_nomatch(v_a_2477);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam12(V self, V *args) {
  V v_s_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_arms_2471 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2474 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_s_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_s_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    V v_m_2486 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esubstCopies_lam13, 1, 2, (V[]){v_x_240, v_a_241}), v_arms_2471));
    V v_x2_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_s_2476}));
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_s_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2475, v_x_2488}), v_s_2489});
    }
    default: return heff_nomatch(v_x2_2487);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam15(V self, V *args) {
  V v_s_2491 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_2491});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam16(V self, V *args) {
  V v_q_2494 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_2494));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam17(V self, V *args) {
  V v_s_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_p_2492 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_s_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_s_2499 = heff_field(v_x2_2497, 1);
    V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2492, v_x_2498}), v_s_2499});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam18(V self, V *args) {
  V v_q_24102 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2esimplify_2esubstCopies(v_x_240, v_a_241, v_q_24102));
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam19(V self, V *args) {
  V v_s_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_g_24100 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_s_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_s_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24100, v_x_24106}), v_s_24107});
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam20(V self, V *args) {
  V v_s_24109 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24109});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam21(V self, V *args) {
  V v_s_24111 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24111});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam22(V self, V *args) {
  V v_s_24113 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam23(V self, V *args) {
  V v_s_24116 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24116});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam24(V self, V *args) {
  V v_s_24118 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24118});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam25(V self, V *args) {
  V v_s_24119 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24119});
}
V g_heff_2ecompile_2esimplify_2esubstCopies_lam26(V self, V *args) {
  V v_s_24122 = args[0];
  V v_e_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_242, v_s_24122});
}
Clo g_heff_2ecompile_2esimplify_2elam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elam_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elam(V v_xs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_240, v_ys_244));
    return heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_246, v_b_245});
  }
  case TAG_EApp: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ELet: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ERecord: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EProj: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ETag: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EMatch: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EPrimCall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_ECall: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EInt: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EStr: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_ELam, 2, (V[]){v_xs_240, v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2elam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2elam(a[0], a[1]);
}

static V g_heff_2ecompile_2esimplify_2especArgSize_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especArgSize_st;
static V g_heff_2ecompile_2esimplify_2especArgSize_init(void) {
  return MK_INT(60LL);
}
V g_heff_2ecompile_2esimplify_2especArgSize_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especArgSize_st)) return g_heff_2ecompile_2esimplify_2especArgSize_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especArgSize_val, &g_heff_2ecompile_2esimplify_2especArgSize_st, g_heff_2ecompile_2esimplify_2especArgSize_init);
}
Clo g_heff_2ecompile_2esimplify_2eclosedKnown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eclosedKnown_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eclosedKnown(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_x1_240, 0);
    V v_b_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){heff_dup(v_xs_243), heff_dup(v_b_244)}), NTAG(TAG_Nil)});
    V v_a_246 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_245));
    if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), v_a_246)) {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ELam, 2, (V[]){v_xs_243, v_b_244}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 1, (V[]){heff_dup(v_fs_2413)}), NTAG(TAG_Nil)});
    V v_a_2415 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), MK_INT(0LL), v_t_2414));
    if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especArgSize_get()), v_a_2415)) {
      heff_drop(v_fs_2413);
      return NTAG(TAG_False);
    } else {
      return ({ V a_0 = NTAG(TAG_Nil); V b_1 = heff_tag_n(TAG_ERecord, 1, (V[]){v_fs_2413}); V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, b_1)); heff_drop(b_1); r_; });
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eclosedKnown_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eclosedKnown(a[0]);
}

static V g_heff_2ecompile_2esimplify_2eclosedUses_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2eclosedUses_st;
static V g_heff_2ecompile_2esimplify_2eclosedUses_init(void) {
  return MK_INT(4LL);
}
V g_heff_2ecompile_2esimplify_2eclosedUses_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2eclosedUses_st)) return g_heff_2ecompile_2esimplify_2eclosedUses_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2eclosedUses_val, &g_heff_2ecompile_2esimplify_2eclosedUses_st, g_heff_2ecompile_2esimplify_2eclosedUses_init);
}
V g_heff_2ecompile_2esimplify_2eletPure_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eletPure_lam4(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletPure_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletPure(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_o_244) {
top: ;
  if (heff_intEq_c(heff_dup(v_o_244), MK_INT(0LL))) {
    heff_drop(v_x_241);
    heff_drop(v_a_242);
    heff_drop(v_o_244);
    return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243});
  } else {
    V v_t_2436;
    switch (heff_tag_of(v_a_242)) {
    case TAG_EVar: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_a_242);
    }
    V v_t_2437;
    switch (heff_tag_of(v_t_2436)) {
    case TAG_True: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      v_t_2437 = heff_intEq(heff_dup(v_o_244), MK_INT(1LL));
      break;
    }
    default: heff_nomatch(v_t_2436);
    }
    switch (heff_tag_of(v_t_2437)) {
    case TAG_True: {
      heff_drop(v_o_244);
      V v_m_2438 = (g_map_2einsert_24s1341440536x470972936(v_x_241, v_a_242, heff_dup(g_map_2eempty_get())));
      V v_t_2439 = (g_map_2esize(v_m_2438));
      V v_t_2441;
      if (heff_intEq_c(v_t_2439, MK_INT(0LL))) {
        heff_drop(v_m_2438);
        v_t_2441 = v_b_243;
      } else {
        v_t_2441 = ({ V a_0 = v_m_2438; V a_1 = v_b_243; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2438); r_; });
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2441});
    }
    case TAG_False: {
      V v_t_2442 = (g_heff_2ecompile_2eir_2eisValue(v_a_242));
      switch (heff_tag_of(v_t_2442)) {
      case TAG_True: {
        V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_242), NTAG(TAG_Nil)});
        V v_a_2444 = (g_heff_2ecompile_2eir_2esizeB(MK_INT(12LL), MK_INT(0LL), v_t_2443));
        if (heff_intLt_c(MK_INT(12LL), v_a_2444)) {
          if (heff_intLe_c(v_o_244, heff_dup(g_heff_2ecompile_2esimplify_2eclosedUses_get()))) {
            V v_t_2447 = (g_heff_2ecompile_2esimplify_2eclosedKnown(heff_dup(v_a_242)));
            switch (heff_tag_of(v_t_2447)) {
            case TAG_True: {
              V v_m_2448 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
              return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam0, 1, 2, (V[]){v_m_2448, v_r_240});
            }
            case TAG_False: {
              V v_m_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
              return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam1, 1, 3, (V[]){v_m_2453, v_x_241, v_a_242});
            }
            default: return heff_nomatch(v_t_2447);
            }
          } else {
            V v_m_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam2, 1, 3, (V[]){v_m_2458, v_x_241, v_a_242});
          }
        } else {
          heff_drop(v_o_244);
          V v_m_2463 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_241, v_a_242, v_b_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam3, 1, 2, (V[]){v_m_2463, v_r_240});
        }
      }
      case TAG_False: {
        heff_drop(v_o_244);
        V v_m_2468 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eletPure_lam4, 1, 3, (V[]){v_m_2468, v_x_241, v_a_242});
      }
      default: return heff_nomatch(v_t_2442);
      }
    }
    default: return heff_nomatch(v_t_2437);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletPure(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2eletPure_lam0(V self, V *args) {
  V v_s_2449 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2450 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2449}));
  switch (heff_tag_of(v_x2_2450)) {
  case TAG_MkPair: {
    V v_x_2451 = heff_field(v_x2_2450, 0);
    V v_s_2452 = heff_field(v_x2_2450, 1);
    heff_take_n(v_x2_2450, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_x_2451;
    heff_room[1] = v_s_2452;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2450);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam1(V self, V *args) {
  V v_s_2454 = args[0];
  V v_m_2453 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2455 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_s_2454}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x2_2455, 0);
    V v_s_2457 = heff_field(v_x2_2455, 1);
    V v_ru_24x2_2455_24MkPair = heff_take_reuse_n(v_x2_2455, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2456}), v_s_2457});
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam2(V self, V *args) {
  V v_s_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_s_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_s_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2461}), v_s_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam3(V self, V *args) {
  V v_s_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_s_2464}));
  switch (heff_tag_of(v_x2_2465)) {
  case TAG_MkPair: {
    V v_x_2466 = heff_field(v_x2_2465, 0);
    V v_s_2467 = heff_field(v_x2_2465, 1);
    heff_take_n(v_x2_2465, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_x_2466;
    heff_room[1] = v_s_2467;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2465);
  }
}
V g_heff_2ecompile_2esimplify_2eletPure_lam4(V self, V *args) {
  V v_s_2469 = args[0];
  V v_m_2468 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_a_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2470 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_s_2469}));
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkPair: {
    V v_x_2471 = heff_field(v_x2_2470, 0);
    V v_s_2472 = heff_field(v_x2_2470, 1);
    V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2471}), v_s_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshName_str0, 1, "$");
Clo g_heff_2ecompile_2esimplify_2efreshName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshName_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efreshName(V v_base_240, V v_s_241) {
top: ;
  V v_n_242 = heff_take_field(v_s_241, 0);
  V v_t_243 = heff_strAppend(v_base_240, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2efreshName_str0), heff_intShow(heff_dup(v_n_242))));
  V v_t_244 = ({ V rv_0 = heff_intAdd(v_n_242, MK_INT(1LL)); V rr_ = heff_rec_reuse_n(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_t_244});
}
V g_heff_2ecompile_2esimplify_2efreshName_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshName(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2esplitArgs_str0, 1, "t");
Clo g_heff_2ecompile_2esimplify_2esplitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esplitArgs_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esplitArgs(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_242 = heff_rec_n(2, shape_binds__args, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_242, v_p_241});
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x1_240, 0);
    V v_as_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2eisPure(v_a_243, v_p_241));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_x2_2414;
      switch (heff_tag_of(v_x_246)) {
      case TAG_True: {
        V v_t_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_a_243});
        v_x2_2414 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_s_247});
        break;
      }
      case TAG_False: {
        V v_x2_249 = (g_heff_2ecompile_2esimplify_2efreshName(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_str0), v_s_247));
        switch (heff_tag_of(v_x2_249)) {
        case TAG_MkPair: {
          V v_x_2410 = heff_field(v_x2_249, 0);
          V v_s_2411 = heff_field(v_x2_249, 1);
          V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
          V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_x_2410), v_a_243})});
          V v_t_2413 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2412, heff_tag_n(TAG_EVar, 1, (V[]){v_x_2410})});
          v_x2_2414 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_s_2411});
          break;
        }
        default: heff_nomatch(v_x2_249);
        }
        break;
      }
      default: heff_nomatch(v_x_246);
      }
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
        V v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2esplitArgs_clo), 1, (V[]){v_as_244}));
        V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2416}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkPair: {
          V v_x_2419 = heff_field(v_x2_2418, 0);
          V v_s_2420 = heff_field(v_x2_2418, 1);
          V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
          V v_x1_2423;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_dup(heff_field(v_x_2415, 0));
            v_x1_2423 = v_x_2421;
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          V v_a_2426;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_MkPair: {
            V v_y_2425 = heff_field(v_x_2415, 1);
            heff_take_n(v_x_2415, 2ULL, 2);
            v_a_2426 = v_y_2425;
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          V v_x_2431;
          switch (heff_tag_of(v_x1_2423)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
            V v_t_2427 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_a_2426, heff_dup(heff_rfield(v_x_2419, 1))});
            v_x_2431 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_n(v_x_2419, 1ULL, 2, shape_binds__args); heff_rfield(rr_, 1) = rv_1; rr_; });
            break;
          }
          case TAG_Just: {
            V v_bd_2428 = heff_field(v_x1_2423, 0);
            heff_take_n(v_x1_2423, 1ULL, 1);
            V v_t_2429 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_Cons, 2, (V[]){v_bd_2428, heff_dup(heff_rfield(v_x_2419, 0))});
            V v_t_2430 = heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_Cons, 2, (V[]){v_a_2426, heff_get_n(v_x_2419, 1, 2)});
            v_x_2431 = heff_rec_n(2, shape_binds__args, (V[]){v_t_2429, v_t_2430});
            break;
          }
          default: heff_nomatch(v_x1_2423);
          }
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2431, v_s_2420});
        }
        default: return heff_nomatch(v_x2_2418);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esplitArgs_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esplitArgs(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2efewerThan_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efewerThan_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efewerThan(V v_as_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_245 = heff_field(v_x21_242, 0);
      V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_240));
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
      return heff_intLt(v_t_247, v_t_248);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efewerThan_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efewerThan(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2epartialApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epartialApp_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2epartialApp(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    V v_as_247 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_field(v_x21_246, 0);
      V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 7, 9), 0, 7);
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2410); r_; });
      return ({ V a_0 = v_as_247; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2esimplify_2efewerThan(a_0, a_1)); heff_drop(v_t_2411); r_; });
    }
    case TAG_ELam: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop_rec(v_s_240, 9);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop_rec(v_s_240, 9);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2epartialApp_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2epartialApp(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eletSplit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletSplit_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletSplit(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    V v_m_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_247 = heff_tr(heff_call(v_m_246, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x2_247, 0);
      V v_s_249 = heff_field(v_x2_247, 1);
      V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_248}), v_s_249});
    }
    default: return heff_nomatch(v_x2_247);
    }
  }
  case TAG_EGlobal: {
    V v_m_2411 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2413}), v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  case TAG_ELam: {
    V v_m_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_s_2420 = heff_field(v_x2_2418, 1);
      V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2419}), v_s_2420});
    }
    default: return heff_nomatch(v_x2_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2421 = heff_field(v_a_242, 0);
    V v_as_2422 = heff_field(v_a_242, 1);
    V v_ru_24a_242_24EApp = heff_take_reuse_n(v_a_242, 3ULL, 2);
    V v_x2_2423 = (g_heff_2ecompile_2esimplify_2esplitArgs(v_as_2422, v_z_244));
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_MkPair: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_s_2425 = heff_field(v_x2_2423, 1);
      V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
      V v_t_2426 = heff_tag_at_n(v_ru_24a_242_24EApp, TAG_EApp, 2, (V[]){v_f_2421, heff_dup(heff_rfield(v_x_2424, 1))});
      V v_t_2427 = heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2428 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_2427));
      V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2430 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2429));
      V v_t_2431 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_2428, v_t_2430}), 0, 2);
      V v_m_2432 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_t_2426, v_b_243, v_t_2431));
      V v_x2_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2425}));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_s_2435 = heff_field(v_x2_2433, 1);
        V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
        V v_x_2436 = ({ V b_0 = heff_get_n(v_x_2424, 0, 2); V a_1 = v_x_2434; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(b_0, a_1)); heff_drop(b_0); r_; });
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
    default: return heff_nomatch(v_x2_2423);
    }
  }
  case TAG_ELet: {
    V v_m_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_x_2442 = heff_field(v_x2_2441, 0);
      V v_s_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2442}), v_s_2443});
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_ERecord: {
    V v_m_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2446 = heff_tr(heff_call(v_m_2445, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_MkPair: {
      V v_x_2447 = heff_field(v_x2_2446, 0);
      V v_s_2448 = heff_field(v_x2_2446, 1);
      V v_ru_24x2_2446_24MkPair = heff_take_reuse_n(v_x2_2446, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2447}), v_s_2448});
    }
    default: return heff_nomatch(v_x2_2446);
    }
  }
  case TAG_EProj: {
    V v_m_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_MkPair: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_s_2455 = heff_field(v_x2_2453, 1);
      V v_ru_24x2_2453_24MkPair = heff_take_reuse_n(v_x2_2453, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2454}), v_s_2455});
    }
    default: return heff_nomatch(v_x2_2453);
    }
  }
  case TAG_ETag: {
    V v_m_2458 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2459 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2459)) {
    case TAG_MkPair: {
      V v_x_2460 = heff_field(v_x2_2459, 0);
      V v_s_2461 = heff_field(v_x2_2459, 1);
      V v_ru_24x2_2459_24MkPair = heff_take_reuse_n(v_x2_2459, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2459_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2460}), v_s_2461});
    }
    default: return heff_nomatch(v_x2_2459);
    }
  }
  case TAG_EMatch: {
    V v_m_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2465 = heff_tr(heff_call(v_m_2464, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x2_2465, 0);
      V v_s_2467 = heff_field(v_x2_2465, 1);
      V v_ru_24x2_2465_24MkPair = heff_take_reuse_n(v_x2_2465, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2466}), v_s_2467});
    }
    default: return heff_nomatch(v_x2_2465);
    }
  }
  case TAG_EPrim: {
    V v_m_2469 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2470 = heff_tr(heff_call(v_m_2469, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2470)) {
    case TAG_MkPair: {
      V v_x_2471 = heff_field(v_x2_2470, 0);
      V v_s_2472 = heff_field(v_x2_2470, 1);
      V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2471}), v_s_2472});
    }
    default: return heff_nomatch(v_x2_2470);
    }
  }
  case TAG_EPrimCall: {
    V v_m_2475 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2476 = heff_tr(heff_call(v_m_2475, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x2_2476, 0);
      V v_s_2478 = heff_field(v_x2_2476, 1);
      V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2477}), v_s_2478});
    }
    default: return heff_nomatch(v_x2_2476);
    }
  }
  case TAG_ECall: {
    V v_m_2481 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2482)) {
    case TAG_MkPair: {
      V v_x_2483 = heff_field(v_x2_2482, 0);
      V v_s_2484 = heff_field(v_x2_2482, 1);
      V v_ru_24x2_2482_24MkPair = heff_take_reuse_n(v_x2_2482, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2483}), v_s_2484});
    }
    default: return heff_nomatch(v_x2_2482);
    }
  }
  case TAG_EInt: {
    V v_m_2486 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_s_2489 = heff_field(v_x2_2487, 1);
      V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2488}), v_s_2489});
    }
    default: return heff_nomatch(v_x2_2487);
    }
  }
  case TAG_EFloat: {
    V v_m_2491 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2492 = heff_tr(heff_call(v_m_2491, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2492)) {
    case TAG_MkPair: {
      V v_x_2493 = heff_field(v_x2_2492, 0);
      V v_s_2494 = heff_field(v_x2_2492, 1);
      V v_ru_24x2_2492_24MkPair = heff_take_reuse_n(v_x2_2492, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2493}), v_s_2494});
    }
    default: return heff_nomatch(v_x2_2492);
    }
  }
  case TAG_EStr: {
    V v_m_2496 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_2497 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_MkPair: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_s_2499 = heff_field(v_x2_2497, 1);
      V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2498}), v_s_2499});
    }
    default: return heff_nomatch(v_x2_2497);
    }
  }
  case TAG_EFixed: {
    V v_m_24102 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24103 = heff_tr(heff_call(v_m_24102, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24103)) {
    case TAG_MkPair: {
      V v_x_24104 = heff_field(v_x2_24103, 0);
      V v_s_24105 = heff_field(v_x2_24103, 1);
      V v_ru_24x2_24103_24MkPair = heff_take_reuse_n(v_x2_24103, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24104}), v_s_24105});
    }
    default: return heff_nomatch(v_x2_24103);
    }
  }
  case TAG_EFloat32: {
    V v_m_24107 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_s_24110 = heff_field(v_x2_24108, 1);
      V v_ru_24x2_24108_24MkPair = heff_take_reuse_n(v_x2_24108, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24108_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24109}), v_s_24110});
    }
    default: return heff_nomatch(v_x2_24108);
    }
  }
  case TAG_EAbandon: {
    V v_m_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24112 = heff_tr(heff_call(v_m_24111, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24112)) {
    case TAG_MkPair: {
      V v_x_24113 = heff_field(v_x2_24112, 0);
      V v_s_24114 = heff_field(v_x2_24112, 1);
      V v_ru_24x2_24112_24MkPair = heff_take_reuse_n(v_x2_24112, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24113}), v_s_24114});
    }
    default: return heff_nomatch(v_x2_24112);
    }
  }
  case TAG_EFix: {
    V v_m_24117 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
    V v_x2_24118 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_z_244}));
    switch (heff_tag_of(v_x2_24118)) {
    case TAG_MkPair: {
      V v_x_24119 = heff_field(v_x2_24118, 0);
      V v_s_24120 = heff_field(v_x2_24118, 1);
      V v_ru_24x2_24118_24MkPair = heff_take_reuse_n(v_x2_24118, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_24118_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_24119}), v_s_24120});
    }
    default: return heff_nomatch(v_x2_24118);
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletSplit_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletSplit(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2eletIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletIn_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eletIn(V v_r_240, V v_x_241, V v_a_242, V v_b_243, V v_s_244) {
top: ;
  V v_x2_245 = (g_heff_2ecompile_2esimplify_2eisPure(v_a_242, v_s_244));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_s_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    switch (heff_tag_of(v_x_246)) {
    case TAG_True: {
      V v_t_248 = heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_241), MK_INT(0LL), v_t_248));
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_243), NTAG(TAG_Nil)});
      V v_t_2411 = (g_heff_2ecompile_2eir_2elamW(heff_dup(v_x_241), v_t_2410));
      V v_t_2412 = heff_get_n(heff_rec_n(2, shape_count__underLam, (V[]){v_t_249, v_t_2411}), 0, 2);
      V v_t_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletPure(v_r_240, v_x_241, v_a_242, v_b_243, v_t_2412));
      return heff_tail(v_t_2413, 1, (V[]){v_s_247});
    }
    case TAG_False: {
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2epartialApp(heff_dup(v_s_247), v_a_242));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x2_245_24MkPair, 2);
        HEFF_LAST return g_heff_2ecompile_2esimplify_2eletSplit(v_r_240, v_x_241, v_a_242, v_b_243, v_s_247);
      }
      case TAG_False: {
        V v_m_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_243}));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_247}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          heff_take_n(v_x2_2416, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_241, v_a_242, v_x_2417}), v_s_2418});
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x_246);
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2esimplify_2eletIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletIn(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2etakesMore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etakesMore_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etakesMore(V v_s_240, V v_g_241, V v_n_242) {
top: ;
  V v_it_243 = ({ V a_0 = v_g_241; V b_1 = heff_get_n(v_s_240, 2, 9); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_n_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_it1_244 = heff_field(v_it_243, 0);
    heff_take_n(v_it_243, 1ULL, 1);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_EVar: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      V v_xs_247 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 2);
      V v_a_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_247; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      return heff_intLt(v_n_242, v_a_249);
    }
    case TAG_EApp: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_take_n(v_it1_244, 0ULL, 3);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_take_n(v_it1_244, 0ULL, 2);
      heff_drop(v_n_242);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2ecompile_2esimplify_2etakesMore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etakesMore(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eparamsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eparamsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eparamsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_y_248))) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eparamsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2eparamsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eetaHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eetaHead_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eetaHead(V v_kinds_240, V v_xs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_field(v_x3_242, 0);
    V v_x1_244 = (g_heff_2ecompile_2esimplify_2eelemStr(heff_dup(v_y_243), v_xs_241));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_field(v_x3_242, 0);
    V v_x3_246 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_g_245), v_kinds_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_246);
    }
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2eetaHead_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2eetaHead(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2eeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eeta_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eeta(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_e_241;
  }
  case TAG_EGlobal: {
    return v_e_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_dup(heff_field(v_e_241, 0));
    V v_e2_245 = heff_dup(heff_field(v_e_241, 1));
    switch (heff_tag_of(v_e2_245)) {
    case TAG_EVar: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ELam: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_e2_245, 0);
      V v_as_2411 = heff_field(v_e2_245, 1);
      V v_ru_24e2_245_24EApp = heff_take_reuse_n(v_e2_245, 3ULL, 2);
      heff_drop_tag(v_e_241, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eparamsAre(v_xs_244, v_as_2411));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        V v_t_2413 = (g_heff_2ecompile_2esimplify_2eetaHead(v_kinds_240, v_xs_244, v_f_2410));
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          heff_drop(v_xs_244);
          heff_drop(v_as_2411);
          heff_drop_cell(v_ru_24e2_245_24EApp, 2);
          return v_f_2410;
        }
        case TAG_False: {
          return heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag_n(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      case TAG_False: {
        return heff_tag_at_n(v_ru_24e2_245_24EApp, TAG_ELam, 2, (V[]){v_xs_244, heff_tag_n(TAG_EApp, 2, (V[]){v_f_2410, v_as_2411})});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_ELet: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ERecord: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EProj: {
      heff_take_n(v_e2_245, 0ULL, 3);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ETag: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EMatch: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrim: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_ECall: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EInt: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EStr: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFixed: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFloat32: {
      heff_take_n(v_e2_245, 0ULL, 1);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EAbandon: {
      heff_drop(v_xs_244);
      return v_e_241;
    }
    case TAG_EFix: {
      heff_take_n(v_e2_245, 0ULL, 2);
      heff_drop(v_xs_244);
      return v_e_241;
    }
    default: return heff_nomatch(v_e2_245);
    }
  }
  case TAG_EApp: {
    return v_e_241;
  }
  case TAG_ELet: {
    return v_e_241;
  }
  case TAG_ERecord: {
    return v_e_241;
  }
  case TAG_EProj: {
    return v_e_241;
  }
  case TAG_ETag: {
    return v_e_241;
  }
  case TAG_EMatch: {
    return v_e_241;
  }
  case TAG_EPrim: {
    return v_e_241;
  }
  case TAG_EPrimCall: {
    return v_e_241;
  }
  case TAG_ECall: {
    return v_e_241;
  }
  case TAG_EInt: {
    return v_e_241;
  }
  case TAG_EFloat: {
    return v_e_241;
  }
  case TAG_EStr: {
    return v_e_241;
  }
  case TAG_EFixed: {
    return v_e_241;
  }
  case TAG_EFloat32: {
    return v_e_241;
  }
  case TAG_EAbandon: {
    return v_e_241;
  }
  case TAG_EFix: {
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eeta_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eeta(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eletFloat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eletFloat_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eletFloat(V v_r_240, V v_x_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_EVar: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EGlobal: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELam: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EApp: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ELet: {
    V v_y_2410 = heff_field(v_a_242, 0);
    V v_a1_2411 = heff_field(v_a_242, 1);
    V v_a2_2412 = heff_field(v_a_242, 2);
    heff_take_n(v_a_242, 7ULL, 3);
    V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_241, v_a2_2412, v_b_243));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eletFloat_lam0, 1, 3, (V[]){v_m_2413, v_y_2410, v_a1_2411});
  }
  case TAG_ERecord: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EProj: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ETag: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EMatch: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrim: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EPrimCall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_ECall: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EInt: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EStr: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFixed: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFloat32: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EAbandon: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  case TAG_EFix: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eletIn_clo), 4, (V[]){v_r_240, v_x_241, v_a_242, v_b_243});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2ecompile_2esimplify_2eletFloat_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eletFloat(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eletFloat_lam0(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_y_2410 = heff_env(self)[1];
  V v_a1_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_y_2410, v_a1_2411, v_x_2416}), v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args);
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esimpF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimpF_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimpF(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam0, 1, 1, (V[]){v_e_241});
  }
  case TAG_EGlobal: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam1, 1, 1, (V[]){v_e_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_e1_2416 = heff_field(v_e_241, 0);
    V v_as_2417 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e1_2416)) {
    case TAG_EVar: {
      V v_m_2419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam3, 1, 3, (V[]){v_m_2419, v_r_240, v_as_2417});
    }
    case TAG_EGlobal: {
      V v_m_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam5, 1, 3, (V[]){v_m_2430, v_r_240, v_as_2417});
    }
    case TAG_ELam: {
      V v_m_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam7, 1, 3, (V[]){v_m_2442, v_r_240, v_as_2417});
    }
    case TAG_EApp: {
      V v_e11_2452 = heff_dup(heff_field(v_e1_2416, 0));
      V v_bs_2453 = heff_dup(heff_field(v_e1_2416, 1));
      switch (heff_tag_of(v_e11_2452)) {
      case TAG_EVar: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam9, 1, 3, (V[]){v_m_2455, v_r_240, v_as_2417});
      }
      case TAG_EGlobal: {
        V v_g_2465 = heff_field(v_e11_2452, 0);
        heff_take_n(v_e11_2452, 1ULL, 1);
        heff_drop_tag(v_e1_2416, 2);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam11, 1, 4, (V[]){v_bs_2453, v_g_2465, v_as_2417, v_r_240});
      }
      case TAG_ELam: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2482 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam13, 1, 3, (V[]){v_m_2482, v_r_240, v_as_2417});
      }
      case TAG_EApp: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_2494 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam15, 1, 3, (V[]){v_m_2494, v_r_240, v_as_2417});
      }
      case TAG_ELet: {
        heff_take_n(v_e11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24107 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam17, 1, 3, (V[]){v_m_24107, v_r_240, v_as_2417});
      }
      case TAG_ERecord: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24118 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam19, 1, 3, (V[]){v_m_24118, v_r_240, v_as_2417});
      }
      case TAG_EProj: {
        heff_take_n(v_e11_2452, 0ULL, 3);
        heff_drop(v_bs_2453);
        V v_m_24131 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam21, 1, 3, (V[]){v_m_24131, v_r_240, v_as_2417});
      }
      case TAG_ETag: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24143 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam23, 1, 3, (V[]){v_m_24143, v_r_240, v_as_2417});
      }
      case TAG_EMatch: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24155 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam25, 1, 3, (V[]){v_m_24155, v_r_240, v_as_2417});
      }
      case TAG_EPrim: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24166 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam27, 1, 3, (V[]){v_m_24166, v_r_240, v_as_2417});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24178 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam29, 1, 3, (V[]){v_m_24178, v_r_240, v_as_2417});
      }
      case TAG_ECall: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24190 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam31, 1, 3, (V[]){v_m_24190, v_r_240, v_as_2417});
      }
      case TAG_EInt: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24201 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam33, 1, 3, (V[]){v_m_24201, v_r_240, v_as_2417});
      }
      case TAG_EFloat: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24212 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam35, 1, 3, (V[]){v_m_24212, v_r_240, v_as_2417});
      }
      case TAG_EStr: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24223 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam37, 1, 3, (V[]){v_m_24223, v_r_240, v_as_2417});
      }
      case TAG_EFixed: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24235 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam39, 1, 3, (V[]){v_m_24235, v_r_240, v_as_2417});
      }
      case TAG_EFloat32: {
        heff_take_n(v_e11_2452, 0ULL, 1);
        heff_drop(v_bs_2453);
        V v_m_24246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam41, 1, 3, (V[]){v_m_24246, v_r_240, v_as_2417});
      }
      case TAG_EAbandon: {
        heff_drop(v_bs_2453);
        V v_m_24256 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam43, 1, 3, (V[]){v_m_24256, v_r_240, v_as_2417});
      }
      case TAG_EFix: {
        heff_take_n(v_e11_2452, 0ULL, 2);
        heff_drop(v_bs_2453);
        V v_m_24268 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam45, 1, 3, (V[]){v_m_24268, v_r_240, v_as_2417});
      }
      default: return heff_nomatch(v_e11_2452);
      }
    }
    case TAG_ELet: {
      V v_m_24281 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam47, 1, 3, (V[]){v_m_24281, v_r_240, v_as_2417});
    }
    case TAG_ERecord: {
      V v_m_24292 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam49, 1, 3, (V[]){v_m_24292, v_r_240, v_as_2417});
    }
    case TAG_EProj: {
      V v_m_24305 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam51, 1, 3, (V[]){v_m_24305, v_r_240, v_as_2417});
    }
    case TAG_ETag: {
      V v_m_24317 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam53, 1, 3, (V[]){v_m_24317, v_r_240, v_as_2417});
    }
    case TAG_EMatch: {
      V v_m_24329 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam55, 1, 3, (V[]){v_m_24329, v_r_240, v_as_2417});
    }
    case TAG_EPrim: {
      V v_m_24340 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam57, 1, 3, (V[]){v_m_24340, v_r_240, v_as_2417});
    }
    case TAG_EPrimCall: {
      V v_m_24352 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam59, 1, 3, (V[]){v_m_24352, v_r_240, v_as_2417});
    }
    case TAG_ECall: {
      V v_m_24364 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam61, 1, 3, (V[]){v_m_24364, v_r_240, v_as_2417});
    }
    case TAG_EInt: {
      V v_m_24375 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam63, 1, 3, (V[]){v_m_24375, v_r_240, v_as_2417});
    }
    case TAG_EFloat: {
      V v_m_24386 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam65, 1, 3, (V[]){v_m_24386, v_r_240, v_as_2417});
    }
    case TAG_EStr: {
      V v_m_24397 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam67, 1, 3, (V[]){v_m_24397, v_r_240, v_as_2417});
    }
    case TAG_EFixed: {
      V v_m_24409 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam69, 1, 3, (V[]){v_m_24409, v_r_240, v_as_2417});
    }
    case TAG_EFloat32: {
      V v_m_24420 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam71, 1, 3, (V[]){v_m_24420, v_r_240, v_as_2417});
    }
    case TAG_EAbandon: {
      V v_m_24430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam73, 1, 3, (V[]){v_m_24430, v_r_240, v_as_2417});
    }
    case TAG_EFix: {
      V v_m_24442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e1_2416}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam75, 1, 3, (V[]){v_m_24442, v_r_240, v_as_2417});
    }
    default: return heff_nomatch(v_e1_2416);
    }
  }
  case TAG_ELet: {
    V v_x_24452 = heff_field(v_e_241, 0);
    V v_a_24453 = heff_field(v_e_241, 1);
    V v_b_24454 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24455 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24453}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam77, 1, 4, (V[]){v_m_24455, v_r_240, v_x_24452, v_b_24454});
  }
  case TAG_ERecord: {
    V v_fs_24461 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_m_24470 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam78, 1, 1, (V[]){v_r_240}), v_fs_24461));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam80, 1, 1, (V[]){v_m_24470});
  }
  case TAG_EProj: {
    V v_e2_24475 = heff_field(v_e_241, 0);
    V v_l_24476 = heff_field(v_e_241, 1);
    V v_sh_24477 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_m_24478 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e2_24475}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam81, 1, 4, (V[]){v_m_24478, v_r_240, v_l_24476, v_sh_24477});
  }
  case TAG_ETag: {
    V v_t_24483 = heff_field(v_e_241, 0);
    V v_as_24484 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24486 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam82, 1, 1, (V[]){v_r_240}), v_as_24484));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam83, 1, 2, (V[]){v_m_24486, v_t_24483});
  }
  case TAG_EMatch: {
    V v_s_24491 = heff_field(v_e_241, 0);
    V v_arms_24492 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24493 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_s_24491}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam84, 1, 3, (V[]){v_m_24493, v_r_240, v_arms_24492});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam87, 1, 1, (V[]){v_e_241});
  }
  case TAG_EPrimCall: {
    V v_p_24513 = heff_field(v_e_241, 0);
    V v_as_24514 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_m_24516 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam88, 1, 1, (V[]){v_r_240}), v_as_24514));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam89, 1, 2, (V[]){v_m_24516, v_p_24513});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam90, 1, 1, (V[]){v_e_241});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam91, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam92, 1, 1, (V[]){v_e_241});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam93, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam94, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam95, 1, 1, (V[]){v_e_241});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam96, 1, 1, (V[]){v_e_241});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam97, 1, 1, (V[]){v_e_241});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimpF(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam0(V self, V *args) {
  V v_s_243 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_243});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_s_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_s_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_s_2412, 7)), 1, 7);
    V v_t_2414 = (g_heff_2ecompile_2esimplify_2elam(v_xs_246, v_x_2411));
    V v_x_2415 = ({ V a_0 = v_t_2413; V a_1 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2eeta(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam4(V self, V *args) {
  V v_a_2424 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam3(V self, V *args) {
  V v_s_2420 = args[0];
  V v_m_2419 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2421 = heff_tr(heff_call(v_m_2419, 1, (V[]){v_s_2420}));
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_s_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    V v_m_2425 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_s_2423}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_s_2428 = heff_field(v_x2_2426, 1);
      heff_take_n(v_x2_2426, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2422;
      heff_room[1] = v_x_2427;
      heff_room[2] = v_s_2428;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2426);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam6(V self, V *args) {
  V v_a_2435 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam5(V self, V *args) {
  V v_s_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_s_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_s_2434 = heff_field(v_x2_2432, 1);
    heff_take_n(v_x2_2432, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam6, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2434}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2433;
      heff_room[1] = v_x_2438;
      heff_room[2] = v_s_2439;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam8(V self, V *args) {
  V v_a_2447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam7(V self, V *args) {
  V v_s_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_s_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_s_2446 = heff_field(v_x2_2444, 1);
    heff_take_n(v_x2_2444, 3ULL, 2);
    V v_m_2448 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam8, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2449 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_s_2446}));
    switch (heff_tag_of(v_x2_2449)) {
    case TAG_MkPair: {
      V v_x_2450 = heff_field(v_x2_2449, 0);
      V v_s_2451 = heff_field(v_x2_2449, 1);
      heff_take_n(v_x2_2449, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2445;
      heff_room[1] = v_x_2450;
      heff_room[2] = v_s_2451;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2449);
    }
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam10(V self, V *args) {
  V v_a_2460 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam9(V self, V *args) {
  V v_s_2456 = args[0];
  V v_m_2455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2457 = heff_tr(heff_call(v_m_2455, 1, (V[]){v_s_2456}));
  switch (heff_tag_of(v_x2_2457)) {
  case TAG_MkPair: {
    V v_x_2458 = heff_field(v_x2_2457, 0);
    V v_s_2459 = heff_field(v_x2_2457, 1);
    heff_take_n(v_x2_2457, 3ULL, 2);
    V v_m_2461 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_s_2459}));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_s_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2458;
      heff_room[1] = v_x_2463;
      heff_room[2] = v_s_2464;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  default: return heff_nomatch(v_x2_2457);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam12(V self, V *args) {
  V v_a_2475 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam11(V self, V *args) {
  V v_s_2466 = args[0];
  V v_bs_2453 = heff_env(self)[0];
  V v_g_2465 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2467 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_bs_2453));
  V v_t_2468 = (g_heff_2ecompile_2esimplify_2etakesMore(heff_dup(v_s_2466), heff_dup(v_g_2465), v_t_2467));
  switch (heff_tag_of(v_t_2468)) {
  case TAG_True: {
    V v_t_2469 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2465}), (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2453, v_as_2417))});
    V f_ = heff_get_n(v_r_240, 0, 4);
    heff_room[0] = v_t_2469;
    heff_room[1] = v_s_2466;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_False: {
    V v_t_2470 = heff_tag_n(TAG_EApp, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_2465}), v_bs_2453});
    V v_m_2471 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2470}));
    V v_x2_2472 = heff_tr(heff_call(v_m_2471, 1, (V[]){v_s_2466}));
    switch (heff_tag_of(v_x2_2472)) {
    case TAG_MkPair: {
      V v_x_2473 = heff_field(v_x2_2472, 0);
      V v_s_2474 = heff_field(v_x2_2472, 1);
      heff_take_n(v_x2_2472, 3ULL, 2);
      V v_m_2476 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam12, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
      V v_x2_2477 = heff_tr(heff_call(v_m_2476, 1, (V[]){v_s_2474}));
      switch (heff_tag_of(v_x2_2477)) {
      case TAG_MkPair: {
        V v_x_2478 = heff_field(v_x2_2477, 0);
        V v_s_2479 = heff_field(v_x2_2477, 1);
        heff_take_n(v_x2_2477, 3ULL, 2);
        V f_ = heff_get_n(v_r_240, 1, 4);
        heff_room[0] = v_x_2473;
        heff_room[1] = v_x_2478;
        heff_room[2] = v_s_2479;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      default: return heff_nomatch(v_x2_2477);
      }
    }
    default: return heff_nomatch(v_x2_2472);
    }
  }
  default: return heff_nomatch(v_t_2468);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam14(V self, V *args) {
  V v_a_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2487;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam13(V self, V *args) {
  V v_s_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_s_2483}));
  switch (heff_tag_of(v_x2_2484)) {
  case TAG_MkPair: {
    V v_x_2485 = heff_field(v_x2_2484, 0);
    V v_s_2486 = heff_field(v_x2_2484, 1);
    heff_take_n(v_x2_2484, 3ULL, 2);
    V v_m_2488 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam14, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2486}));
    switch (heff_tag_of(v_x2_2489)) {
    case TAG_MkPair: {
      V v_x_2490 = heff_field(v_x2_2489, 0);
      V v_s_2491 = heff_field(v_x2_2489, 1);
      heff_take_n(v_x2_2489, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2485;
      heff_room[1] = v_x_2490;
      heff_room[2] = v_s_2491;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_2489);
    }
  }
  default: return heff_nomatch(v_x2_2484);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam16(V self, V *args) {
  V v_a_2499 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_2499;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam15(V self, V *args) {
  V v_s_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_s_2495}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_MkPair: {
    V v_x_2497 = heff_field(v_x2_2496, 0);
    V v_s_2498 = heff_field(v_x2_2496, 1);
    heff_take_n(v_x2_2496, 3ULL, 2);
    V v_m_24100 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam16, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24101 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_s_2498}));
    switch (heff_tag_of(v_x2_24101)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x2_24101, 0);
      V v_s_24103 = heff_field(v_x2_24101, 1);
      heff_take_n(v_x2_24101, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_2497;
      heff_room[1] = v_x_24102;
      heff_room[2] = v_s_24103;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24101);
    }
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam18(V self, V *args) {
  V v_a_24112 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24112;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam17(V self, V *args) {
  V v_s_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_s_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_MkPair: {
    V v_x_24110 = heff_field(v_x2_24109, 0);
    V v_s_24111 = heff_field(v_x2_24109, 1);
    heff_take_n(v_x2_24109, 3ULL, 2);
    V v_m_24113 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam18, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24114 = heff_tr(heff_call(v_m_24113, 1, (V[]){v_s_24111}));
    switch (heff_tag_of(v_x2_24114)) {
    case TAG_MkPair: {
      V v_x_24115 = heff_field(v_x2_24114, 0);
      V v_s_24116 = heff_field(v_x2_24114, 1);
      heff_take_n(v_x2_24114, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24110;
      heff_room[1] = v_x_24115;
      heff_room[2] = v_s_24116;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24114);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam20(V self, V *args) {
  V v_a_24123 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24123;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam19(V self, V *args) {
  V v_s_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24120 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_s_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_MkPair: {
    V v_x_24121 = heff_field(v_x2_24120, 0);
    V v_s_24122 = heff_field(v_x2_24120, 1);
    heff_take_n(v_x2_24120, 3ULL, 2);
    V v_m_24124 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam20, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_s_24122}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_s_24127 = heff_field(v_x2_24125, 1);
      heff_take_n(v_x2_24125, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24121;
      heff_room[1] = v_x_24126;
      heff_room[2] = v_s_24127;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24125);
    }
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam22(V self, V *args) {
  V v_a_24136 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24136;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam21(V self, V *args) {
  V v_s_24132 = args[0];
  V v_m_24131 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24133 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_s_24132}));
  switch (heff_tag_of(v_x2_24133)) {
  case TAG_MkPair: {
    V v_x_24134 = heff_field(v_x2_24133, 0);
    V v_s_24135 = heff_field(v_x2_24133, 1);
    heff_take_n(v_x2_24133, 3ULL, 2);
    V v_m_24137 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam22, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24138 = heff_tr(heff_call(v_m_24137, 1, (V[]){v_s_24135}));
    switch (heff_tag_of(v_x2_24138)) {
    case TAG_MkPair: {
      V v_x_24139 = heff_field(v_x2_24138, 0);
      V v_s_24140 = heff_field(v_x2_24138, 1);
      heff_take_n(v_x2_24138, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24134;
      heff_room[1] = v_x_24139;
      heff_room[2] = v_s_24140;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24138);
    }
  }
  default: return heff_nomatch(v_x2_24133);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam24(V self, V *args) {
  V v_a_24148 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24148;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam23(V self, V *args) {
  V v_s_24144 = args[0];
  V v_m_24143 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24145 = heff_tr(heff_call(v_m_24143, 1, (V[]){v_s_24144}));
  switch (heff_tag_of(v_x2_24145)) {
  case TAG_MkPair: {
    V v_x_24146 = heff_field(v_x2_24145, 0);
    V v_s_24147 = heff_field(v_x2_24145, 1);
    heff_take_n(v_x2_24145, 3ULL, 2);
    V v_m_24149 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam24, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24150 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_s_24147}));
    switch (heff_tag_of(v_x2_24150)) {
    case TAG_MkPair: {
      V v_x_24151 = heff_field(v_x2_24150, 0);
      V v_s_24152 = heff_field(v_x2_24150, 1);
      heff_take_n(v_x2_24150, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24146;
      heff_room[1] = v_x_24151;
      heff_room[2] = v_s_24152;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24150);
    }
  }
  default: return heff_nomatch(v_x2_24145);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam26(V self, V *args) {
  V v_a_24160 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24160;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam25(V self, V *args) {
  V v_s_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_s_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_MkPair: {
    V v_x_24158 = heff_field(v_x2_24157, 0);
    V v_s_24159 = heff_field(v_x2_24157, 1);
    heff_take_n(v_x2_24157, 3ULL, 2);
    V v_m_24161 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24162 = heff_tr(heff_call(v_m_24161, 1, (V[]){v_s_24159}));
    switch (heff_tag_of(v_x2_24162)) {
    case TAG_MkPair: {
      V v_x_24163 = heff_field(v_x2_24162, 0);
      V v_s_24164 = heff_field(v_x2_24162, 1);
      heff_take_n(v_x2_24162, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24158;
      heff_room[1] = v_x_24163;
      heff_room[2] = v_s_24164;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24162);
    }
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam28(V self, V *args) {
  V v_a_24171 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24171;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam27(V self, V *args) {
  V v_s_24167 = args[0];
  V v_m_24166 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24168 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_s_24167}));
  switch (heff_tag_of(v_x2_24168)) {
  case TAG_MkPair: {
    V v_x_24169 = heff_field(v_x2_24168, 0);
    V v_s_24170 = heff_field(v_x2_24168, 1);
    heff_take_n(v_x2_24168, 3ULL, 2);
    V v_m_24172 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam28, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24173 = heff_tr(heff_call(v_m_24172, 1, (V[]){v_s_24170}));
    switch (heff_tag_of(v_x2_24173)) {
    case TAG_MkPair: {
      V v_x_24174 = heff_field(v_x2_24173, 0);
      V v_s_24175 = heff_field(v_x2_24173, 1);
      heff_take_n(v_x2_24173, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24169;
      heff_room[1] = v_x_24174;
      heff_room[2] = v_s_24175;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24173);
    }
  }
  default: return heff_nomatch(v_x2_24168);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam30(V self, V *args) {
  V v_a_24183 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24183;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam29(V self, V *args) {
  V v_s_24179 = args[0];
  V v_m_24178 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24180 = heff_tr(heff_call(v_m_24178, 1, (V[]){v_s_24179}));
  switch (heff_tag_of(v_x2_24180)) {
  case TAG_MkPair: {
    V v_x_24181 = heff_field(v_x2_24180, 0);
    V v_s_24182 = heff_field(v_x2_24180, 1);
    heff_take_n(v_x2_24180, 3ULL, 2);
    V v_m_24184 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam30, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24185 = heff_tr(heff_call(v_m_24184, 1, (V[]){v_s_24182}));
    switch (heff_tag_of(v_x2_24185)) {
    case TAG_MkPair: {
      V v_x_24186 = heff_field(v_x2_24185, 0);
      V v_s_24187 = heff_field(v_x2_24185, 1);
      heff_take_n(v_x2_24185, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24181;
      heff_room[1] = v_x_24186;
      heff_room[2] = v_s_24187;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24185);
    }
  }
  default: return heff_nomatch(v_x2_24180);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam32(V self, V *args) {
  V v_a_24195 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24195;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam31(V self, V *args) {
  V v_s_24191 = args[0];
  V v_m_24190 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24192 = heff_tr(heff_call(v_m_24190, 1, (V[]){v_s_24191}));
  switch (heff_tag_of(v_x2_24192)) {
  case TAG_MkPair: {
    V v_x_24193 = heff_field(v_x2_24192, 0);
    V v_s_24194 = heff_field(v_x2_24192, 1);
    heff_take_n(v_x2_24192, 3ULL, 2);
    V v_m_24196 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam32, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24197 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_s_24194}));
    switch (heff_tag_of(v_x2_24197)) {
    case TAG_MkPair: {
      V v_x_24198 = heff_field(v_x2_24197, 0);
      V v_s_24199 = heff_field(v_x2_24197, 1);
      heff_take_n(v_x2_24197, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24193;
      heff_room[1] = v_x_24198;
      heff_room[2] = v_s_24199;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24197);
    }
  }
  default: return heff_nomatch(v_x2_24192);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam34(V self, V *args) {
  V v_a_24206 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24206;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam33(V self, V *args) {
  V v_s_24202 = args[0];
  V v_m_24201 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24203 = heff_tr(heff_call(v_m_24201, 1, (V[]){v_s_24202}));
  switch (heff_tag_of(v_x2_24203)) {
  case TAG_MkPair: {
    V v_x_24204 = heff_field(v_x2_24203, 0);
    V v_s_24205 = heff_field(v_x2_24203, 1);
    heff_take_n(v_x2_24203, 3ULL, 2);
    V v_m_24207 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam34, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24208 = heff_tr(heff_call(v_m_24207, 1, (V[]){v_s_24205}));
    switch (heff_tag_of(v_x2_24208)) {
    case TAG_MkPair: {
      V v_x_24209 = heff_field(v_x2_24208, 0);
      V v_s_24210 = heff_field(v_x2_24208, 1);
      heff_take_n(v_x2_24208, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24204;
      heff_room[1] = v_x_24209;
      heff_room[2] = v_s_24210;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24208);
    }
  }
  default: return heff_nomatch(v_x2_24203);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam36(V self, V *args) {
  V v_a_24217 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24217;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam35(V self, V *args) {
  V v_s_24213 = args[0];
  V v_m_24212 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24214 = heff_tr(heff_call(v_m_24212, 1, (V[]){v_s_24213}));
  switch (heff_tag_of(v_x2_24214)) {
  case TAG_MkPair: {
    V v_x_24215 = heff_field(v_x2_24214, 0);
    V v_s_24216 = heff_field(v_x2_24214, 1);
    heff_take_n(v_x2_24214, 3ULL, 2);
    V v_m_24218 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam36, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24219 = heff_tr(heff_call(v_m_24218, 1, (V[]){v_s_24216}));
    switch (heff_tag_of(v_x2_24219)) {
    case TAG_MkPair: {
      V v_x_24220 = heff_field(v_x2_24219, 0);
      V v_s_24221 = heff_field(v_x2_24219, 1);
      heff_take_n(v_x2_24219, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24215;
      heff_room[1] = v_x_24220;
      heff_room[2] = v_s_24221;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24219);
    }
  }
  default: return heff_nomatch(v_x2_24214);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam38(V self, V *args) {
  V v_a_24228 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24228;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam37(V self, V *args) {
  V v_s_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24225 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_s_24224}));
  switch (heff_tag_of(v_x2_24225)) {
  case TAG_MkPair: {
    V v_x_24226 = heff_field(v_x2_24225, 0);
    V v_s_24227 = heff_field(v_x2_24225, 1);
    heff_take_n(v_x2_24225, 3ULL, 2);
    V v_m_24229 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam38, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24230 = heff_tr(heff_call(v_m_24229, 1, (V[]){v_s_24227}));
    switch (heff_tag_of(v_x2_24230)) {
    case TAG_MkPair: {
      V v_x_24231 = heff_field(v_x2_24230, 0);
      V v_s_24232 = heff_field(v_x2_24230, 1);
      heff_take_n(v_x2_24230, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24226;
      heff_room[1] = v_x_24231;
      heff_room[2] = v_s_24232;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24230);
    }
  }
  default: return heff_nomatch(v_x2_24225);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam40(V self, V *args) {
  V v_a_24240 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam39(V self, V *args) {
  V v_s_24236 = args[0];
  V v_m_24235 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24237 = heff_tr(heff_call(v_m_24235, 1, (V[]){v_s_24236}));
  switch (heff_tag_of(v_x2_24237)) {
  case TAG_MkPair: {
    V v_x_24238 = heff_field(v_x2_24237, 0);
    V v_s_24239 = heff_field(v_x2_24237, 1);
    heff_take_n(v_x2_24237, 3ULL, 2);
    V v_m_24241 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam40, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24242 = heff_tr(heff_call(v_m_24241, 1, (V[]){v_s_24239}));
    switch (heff_tag_of(v_x2_24242)) {
    case TAG_MkPair: {
      V v_x_24243 = heff_field(v_x2_24242, 0);
      V v_s_24244 = heff_field(v_x2_24242, 1);
      heff_take_n(v_x2_24242, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24238;
      heff_room[1] = v_x_24243;
      heff_room[2] = v_s_24244;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24242);
    }
  }
  default: return heff_nomatch(v_x2_24237);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam42(V self, V *args) {
  V v_a_24251 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24251;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam41(V self, V *args) {
  V v_s_24247 = args[0];
  V v_m_24246 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24248 = heff_tr(heff_call(v_m_24246, 1, (V[]){v_s_24247}));
  switch (heff_tag_of(v_x2_24248)) {
  case TAG_MkPair: {
    V v_x_24249 = heff_field(v_x2_24248, 0);
    V v_s_24250 = heff_field(v_x2_24248, 1);
    heff_take_n(v_x2_24248, 3ULL, 2);
    V v_m_24252 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24253 = heff_tr(heff_call(v_m_24252, 1, (V[]){v_s_24250}));
    switch (heff_tag_of(v_x2_24253)) {
    case TAG_MkPair: {
      V v_x_24254 = heff_field(v_x2_24253, 0);
      V v_s_24255 = heff_field(v_x2_24253, 1);
      heff_take_n(v_x2_24253, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24249;
      heff_room[1] = v_x_24254;
      heff_room[2] = v_s_24255;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24253);
    }
  }
  default: return heff_nomatch(v_x2_24248);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam44(V self, V *args) {
  V v_a_24261 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24261;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam43(V self, V *args) {
  V v_s_24257 = args[0];
  V v_m_24256 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24258 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_s_24257}));
  switch (heff_tag_of(v_x2_24258)) {
  case TAG_MkPair: {
    V v_x_24259 = heff_field(v_x2_24258, 0);
    V v_s_24260 = heff_field(v_x2_24258, 1);
    heff_take_n(v_x2_24258, 3ULL, 2);
    V v_m_24262 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam44, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24263 = heff_tr(heff_call(v_m_24262, 1, (V[]){v_s_24260}));
    switch (heff_tag_of(v_x2_24263)) {
    case TAG_MkPair: {
      V v_x_24264 = heff_field(v_x2_24263, 0);
      V v_s_24265 = heff_field(v_x2_24263, 1);
      heff_take_n(v_x2_24263, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24259;
      heff_room[1] = v_x_24264;
      heff_room[2] = v_s_24265;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24263);
    }
  }
  default: return heff_nomatch(v_x2_24258);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam46(V self, V *args) {
  V v_a_24273 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24273;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam45(V self, V *args) {
  V v_s_24269 = args[0];
  V v_m_24268 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24270 = heff_tr(heff_call(v_m_24268, 1, (V[]){v_s_24269}));
  switch (heff_tag_of(v_x2_24270)) {
  case TAG_MkPair: {
    V v_x_24271 = heff_field(v_x2_24270, 0);
    V v_s_24272 = heff_field(v_x2_24270, 1);
    heff_take_n(v_x2_24270, 3ULL, 2);
    V v_m_24274 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam46, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24275 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_s_24272}));
    switch (heff_tag_of(v_x2_24275)) {
    case TAG_MkPair: {
      V v_x_24276 = heff_field(v_x2_24275, 0);
      V v_s_24277 = heff_field(v_x2_24275, 1);
      heff_take_n(v_x2_24275, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24271;
      heff_room[1] = v_x_24276;
      heff_room[2] = v_s_24277;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24275);
    }
  }
  default: return heff_nomatch(v_x2_24270);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam48(V self, V *args) {
  V v_a_24286 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24286;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam47(V self, V *args) {
  V v_s_24282 = args[0];
  V v_m_24281 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24283 = heff_tr(heff_call(v_m_24281, 1, (V[]){v_s_24282}));
  switch (heff_tag_of(v_x2_24283)) {
  case TAG_MkPair: {
    V v_x_24284 = heff_field(v_x2_24283, 0);
    V v_s_24285 = heff_field(v_x2_24283, 1);
    heff_take_n(v_x2_24283, 3ULL, 2);
    V v_m_24287 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam48, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24288 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_s_24285}));
    switch (heff_tag_of(v_x2_24288)) {
    case TAG_MkPair: {
      V v_x_24289 = heff_field(v_x2_24288, 0);
      V v_s_24290 = heff_field(v_x2_24288, 1);
      heff_take_n(v_x2_24288, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24284;
      heff_room[1] = v_x_24289;
      heff_room[2] = v_s_24290;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24288);
    }
  }
  default: return heff_nomatch(v_x2_24283);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam50(V self, V *args) {
  V v_a_24297 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24297;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam49(V self, V *args) {
  V v_s_24293 = args[0];
  V v_m_24292 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24294 = heff_tr(heff_call(v_m_24292, 1, (V[]){v_s_24293}));
  switch (heff_tag_of(v_x2_24294)) {
  case TAG_MkPair: {
    V v_x_24295 = heff_field(v_x2_24294, 0);
    V v_s_24296 = heff_field(v_x2_24294, 1);
    heff_take_n(v_x2_24294, 3ULL, 2);
    V v_m_24298 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam50, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24299 = heff_tr(heff_call(v_m_24298, 1, (V[]){v_s_24296}));
    switch (heff_tag_of(v_x2_24299)) {
    case TAG_MkPair: {
      V v_x_24300 = heff_field(v_x2_24299, 0);
      V v_s_24301 = heff_field(v_x2_24299, 1);
      heff_take_n(v_x2_24299, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24295;
      heff_room[1] = v_x_24300;
      heff_room[2] = v_s_24301;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24299);
    }
  }
  default: return heff_nomatch(v_x2_24294);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam52(V self, V *args) {
  V v_a_24310 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24310;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam51(V self, V *args) {
  V v_s_24306 = args[0];
  V v_m_24305 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24307 = heff_tr(heff_call(v_m_24305, 1, (V[]){v_s_24306}));
  switch (heff_tag_of(v_x2_24307)) {
  case TAG_MkPair: {
    V v_x_24308 = heff_field(v_x2_24307, 0);
    V v_s_24309 = heff_field(v_x2_24307, 1);
    heff_take_n(v_x2_24307, 3ULL, 2);
    V v_m_24311 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam52, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24312 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_s_24309}));
    switch (heff_tag_of(v_x2_24312)) {
    case TAG_MkPair: {
      V v_x_24313 = heff_field(v_x2_24312, 0);
      V v_s_24314 = heff_field(v_x2_24312, 1);
      heff_take_n(v_x2_24312, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24308;
      heff_room[1] = v_x_24313;
      heff_room[2] = v_s_24314;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24312);
    }
  }
  default: return heff_nomatch(v_x2_24307);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam54(V self, V *args) {
  V v_a_24322 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24322;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam53(V self, V *args) {
  V v_s_24318 = args[0];
  V v_m_24317 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24319 = heff_tr(heff_call(v_m_24317, 1, (V[]){v_s_24318}));
  switch (heff_tag_of(v_x2_24319)) {
  case TAG_MkPair: {
    V v_x_24320 = heff_field(v_x2_24319, 0);
    V v_s_24321 = heff_field(v_x2_24319, 1);
    heff_take_n(v_x2_24319, 3ULL, 2);
    V v_m_24323 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam54, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24324 = heff_tr(heff_call(v_m_24323, 1, (V[]){v_s_24321}));
    switch (heff_tag_of(v_x2_24324)) {
    case TAG_MkPair: {
      V v_x_24325 = heff_field(v_x2_24324, 0);
      V v_s_24326 = heff_field(v_x2_24324, 1);
      heff_take_n(v_x2_24324, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24320;
      heff_room[1] = v_x_24325;
      heff_room[2] = v_s_24326;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24324);
    }
  }
  default: return heff_nomatch(v_x2_24319);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam56(V self, V *args) {
  V v_a_24334 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24334;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam55(V self, V *args) {
  V v_s_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_s_24330}));
  switch (heff_tag_of(v_x2_24331)) {
  case TAG_MkPair: {
    V v_x_24332 = heff_field(v_x2_24331, 0);
    V v_s_24333 = heff_field(v_x2_24331, 1);
    heff_take_n(v_x2_24331, 3ULL, 2);
    V v_m_24335 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam56, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24336 = heff_tr(heff_call(v_m_24335, 1, (V[]){v_s_24333}));
    switch (heff_tag_of(v_x2_24336)) {
    case TAG_MkPair: {
      V v_x_24337 = heff_field(v_x2_24336, 0);
      V v_s_24338 = heff_field(v_x2_24336, 1);
      heff_take_n(v_x2_24336, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24332;
      heff_room[1] = v_x_24337;
      heff_room[2] = v_s_24338;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24336);
    }
  }
  default: return heff_nomatch(v_x2_24331);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam58(V self, V *args) {
  V v_a_24345 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24345;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam57(V self, V *args) {
  V v_s_24341 = args[0];
  V v_m_24340 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24342 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_s_24341}));
  switch (heff_tag_of(v_x2_24342)) {
  case TAG_MkPair: {
    V v_x_24343 = heff_field(v_x2_24342, 0);
    V v_s_24344 = heff_field(v_x2_24342, 1);
    heff_take_n(v_x2_24342, 3ULL, 2);
    V v_m_24346 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam58, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24347 = heff_tr(heff_call(v_m_24346, 1, (V[]){v_s_24344}));
    switch (heff_tag_of(v_x2_24347)) {
    case TAG_MkPair: {
      V v_x_24348 = heff_field(v_x2_24347, 0);
      V v_s_24349 = heff_field(v_x2_24347, 1);
      heff_take_n(v_x2_24347, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24343;
      heff_room[1] = v_x_24348;
      heff_room[2] = v_s_24349;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24347);
    }
  }
  default: return heff_nomatch(v_x2_24342);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam60(V self, V *args) {
  V v_a_24357 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24357;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam59(V self, V *args) {
  V v_s_24353 = args[0];
  V v_m_24352 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24354 = heff_tr(heff_call(v_m_24352, 1, (V[]){v_s_24353}));
  switch (heff_tag_of(v_x2_24354)) {
  case TAG_MkPair: {
    V v_x_24355 = heff_field(v_x2_24354, 0);
    V v_s_24356 = heff_field(v_x2_24354, 1);
    heff_take_n(v_x2_24354, 3ULL, 2);
    V v_m_24358 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam60, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24359 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_s_24356}));
    switch (heff_tag_of(v_x2_24359)) {
    case TAG_MkPair: {
      V v_x_24360 = heff_field(v_x2_24359, 0);
      V v_s_24361 = heff_field(v_x2_24359, 1);
      heff_take_n(v_x2_24359, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24355;
      heff_room[1] = v_x_24360;
      heff_room[2] = v_s_24361;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24359);
    }
  }
  default: return heff_nomatch(v_x2_24354);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam62(V self, V *args) {
  V v_a_24369 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24369;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam61(V self, V *args) {
  V v_s_24365 = args[0];
  V v_m_24364 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24366 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_s_24365}));
  switch (heff_tag_of(v_x2_24366)) {
  case TAG_MkPair: {
    V v_x_24367 = heff_field(v_x2_24366, 0);
    V v_s_24368 = heff_field(v_x2_24366, 1);
    heff_take_n(v_x2_24366, 3ULL, 2);
    V v_m_24370 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam62, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24371 = heff_tr(heff_call(v_m_24370, 1, (V[]){v_s_24368}));
    switch (heff_tag_of(v_x2_24371)) {
    case TAG_MkPair: {
      V v_x_24372 = heff_field(v_x2_24371, 0);
      V v_s_24373 = heff_field(v_x2_24371, 1);
      heff_take_n(v_x2_24371, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24367;
      heff_room[1] = v_x_24372;
      heff_room[2] = v_s_24373;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24371);
    }
  }
  default: return heff_nomatch(v_x2_24366);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam64(V self, V *args) {
  V v_a_24380 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24380;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam63(V self, V *args) {
  V v_s_24376 = args[0];
  V v_m_24375 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24377 = heff_tr(heff_call(v_m_24375, 1, (V[]){v_s_24376}));
  switch (heff_tag_of(v_x2_24377)) {
  case TAG_MkPair: {
    V v_x_24378 = heff_field(v_x2_24377, 0);
    V v_s_24379 = heff_field(v_x2_24377, 1);
    heff_take_n(v_x2_24377, 3ULL, 2);
    V v_m_24381 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam64, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24382 = heff_tr(heff_call(v_m_24381, 1, (V[]){v_s_24379}));
    switch (heff_tag_of(v_x2_24382)) {
    case TAG_MkPair: {
      V v_x_24383 = heff_field(v_x2_24382, 0);
      V v_s_24384 = heff_field(v_x2_24382, 1);
      heff_take_n(v_x2_24382, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24378;
      heff_room[1] = v_x_24383;
      heff_room[2] = v_s_24384;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24382);
    }
  }
  default: return heff_nomatch(v_x2_24377);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam66(V self, V *args) {
  V v_a_24391 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24391;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam65(V self, V *args) {
  V v_s_24387 = args[0];
  V v_m_24386 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24388 = heff_tr(heff_call(v_m_24386, 1, (V[]){v_s_24387}));
  switch (heff_tag_of(v_x2_24388)) {
  case TAG_MkPair: {
    V v_x_24389 = heff_field(v_x2_24388, 0);
    V v_s_24390 = heff_field(v_x2_24388, 1);
    heff_take_n(v_x2_24388, 3ULL, 2);
    V v_m_24392 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam66, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24393 = heff_tr(heff_call(v_m_24392, 1, (V[]){v_s_24390}));
    switch (heff_tag_of(v_x2_24393)) {
    case TAG_MkPair: {
      V v_x_24394 = heff_field(v_x2_24393, 0);
      V v_s_24395 = heff_field(v_x2_24393, 1);
      heff_take_n(v_x2_24393, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24389;
      heff_room[1] = v_x_24394;
      heff_room[2] = v_s_24395;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24393);
    }
  }
  default: return heff_nomatch(v_x2_24388);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam68(V self, V *args) {
  V v_a_24402 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24402;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam67(V self, V *args) {
  V v_s_24398 = args[0];
  V v_m_24397 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24399 = heff_tr(heff_call(v_m_24397, 1, (V[]){v_s_24398}));
  switch (heff_tag_of(v_x2_24399)) {
  case TAG_MkPair: {
    V v_x_24400 = heff_field(v_x2_24399, 0);
    V v_s_24401 = heff_field(v_x2_24399, 1);
    heff_take_n(v_x2_24399, 3ULL, 2);
    V v_m_24403 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam68, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24404 = heff_tr(heff_call(v_m_24403, 1, (V[]){v_s_24401}));
    switch (heff_tag_of(v_x2_24404)) {
    case TAG_MkPair: {
      V v_x_24405 = heff_field(v_x2_24404, 0);
      V v_s_24406 = heff_field(v_x2_24404, 1);
      heff_take_n(v_x2_24404, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24400;
      heff_room[1] = v_x_24405;
      heff_room[2] = v_s_24406;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24404);
    }
  }
  default: return heff_nomatch(v_x2_24399);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam70(V self, V *args) {
  V v_a_24414 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam69(V self, V *args) {
  V v_s_24410 = args[0];
  V v_m_24409 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24411 = heff_tr(heff_call(v_m_24409, 1, (V[]){v_s_24410}));
  switch (heff_tag_of(v_x2_24411)) {
  case TAG_MkPair: {
    V v_x_24412 = heff_field(v_x2_24411, 0);
    V v_s_24413 = heff_field(v_x2_24411, 1);
    heff_take_n(v_x2_24411, 3ULL, 2);
    V v_m_24415 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam70, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24416 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_s_24413}));
    switch (heff_tag_of(v_x2_24416)) {
    case TAG_MkPair: {
      V v_x_24417 = heff_field(v_x2_24416, 0);
      V v_s_24418 = heff_field(v_x2_24416, 1);
      heff_take_n(v_x2_24416, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24412;
      heff_room[1] = v_x_24417;
      heff_room[2] = v_s_24418;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24416);
    }
  }
  default: return heff_nomatch(v_x2_24411);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam72(V self, V *args) {
  V v_a_24425 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam71(V self, V *args) {
  V v_s_24421 = args[0];
  V v_m_24420 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24422 = heff_tr(heff_call(v_m_24420, 1, (V[]){v_s_24421}));
  switch (heff_tag_of(v_x2_24422)) {
  case TAG_MkPair: {
    V v_x_24423 = heff_field(v_x2_24422, 0);
    V v_s_24424 = heff_field(v_x2_24422, 1);
    heff_take_n(v_x2_24422, 3ULL, 2);
    V v_m_24426 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam72, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24427 = heff_tr(heff_call(v_m_24426, 1, (V[]){v_s_24424}));
    switch (heff_tag_of(v_x2_24427)) {
    case TAG_MkPair: {
      V v_x_24428 = heff_field(v_x2_24427, 0);
      V v_s_24429 = heff_field(v_x2_24427, 1);
      heff_take_n(v_x2_24427, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24423;
      heff_room[1] = v_x_24428;
      heff_room[2] = v_s_24429;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24427);
    }
  }
  default: return heff_nomatch(v_x2_24422);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam74(V self, V *args) {
  V v_a_24435 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24435;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam73(V self, V *args) {
  V v_s_24431 = args[0];
  V v_m_24430 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24432 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_s_24431}));
  switch (heff_tag_of(v_x2_24432)) {
  case TAG_MkPair: {
    V v_x_24433 = heff_field(v_x2_24432, 0);
    V v_s_24434 = heff_field(v_x2_24432, 1);
    heff_take_n(v_x2_24432, 3ULL, 2);
    V v_m_24436 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam74, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24437 = heff_tr(heff_call(v_m_24436, 1, (V[]){v_s_24434}));
    switch (heff_tag_of(v_x2_24437)) {
    case TAG_MkPair: {
      V v_x_24438 = heff_field(v_x2_24437, 0);
      V v_s_24439 = heff_field(v_x2_24437, 1);
      heff_take_n(v_x2_24437, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24433;
      heff_room[1] = v_x_24438;
      heff_room[2] = v_s_24439;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24437);
    }
  }
  default: return heff_nomatch(v_x2_24432);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam76(V self, V *args) {
  V v_a_24447 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam75(V self, V *args) {
  V v_s_24443 = args[0];
  V v_m_24442 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24444 = heff_tr(heff_call(v_m_24442, 1, (V[]){v_s_24443}));
  switch (heff_tag_of(v_x2_24444)) {
  case TAG_MkPair: {
    V v_x_24445 = heff_field(v_x2_24444, 0);
    V v_s_24446 = heff_field(v_x2_24444, 1);
    heff_take_n(v_x2_24444, 3ULL, 2);
    V v_m_24448 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam76, 1, 1, (V[]){heff_dup(v_r_240)}), v_as_2417));
    V v_x2_24449 = heff_tr(heff_call(v_m_24448, 1, (V[]){v_s_24446}));
    switch (heff_tag_of(v_x2_24449)) {
    case TAG_MkPair: {
      V v_x_24450 = heff_field(v_x2_24449, 0);
      V v_s_24451 = heff_field(v_x2_24449, 1);
      heff_take_n(v_x2_24449, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      heff_room[0] = v_x_24445;
      heff_room[1] = v_x_24450;
      heff_room[2] = v_s_24451;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24449);
    }
  }
  default: return heff_nomatch(v_x2_24444);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam77(V self, V *args) {
  V v_s_24456 = args[0];
  V v_m_24455 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_x_24452 = heff_env(self)[2];
  V v_b_24454 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24457 = heff_tr(heff_call(v_m_24455, 1, (V[]){v_s_24456}));
  switch (heff_tag_of(v_x2_24457)) {
  case TAG_MkPair: {
    V v_x_24458 = heff_field(v_x2_24457, 0);
    V v_s_24459 = heff_field(v_x2_24457, 1);
    heff_take_n(v_x2_24457, 3ULL, 2);
    V v_t_24460 = heff_tr(g_heff_2ecompile_2esimplify_2eletFloat(v_r_240, v_x_24452, v_x_24458, v_b_24454));
    V f_ = v_t_24460;
    args[0] = v_s_24459;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_24457);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam79(V self, V *args) {
  V v_s_24466 = args[0];
  V v_m_24465 = heff_env(self)[0];
  V v_l_24463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24467 = heff_tr(heff_call(v_m_24465, 1, (V[]){v_s_24466}));
  switch (heff_tag_of(v_x2_24467)) {
  case TAG_MkPair: {
    V v_x_24468 = heff_field(v_x2_24467, 0);
    V v_s_24469 = heff_field(v_x2_24467, 1);
    V v_ru_24x2_24467_24MkPair = heff_take_reuse_n(v_x2_24467, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_24463, v_x_24468}), v_s_24469});
  }
  default: return heff_nomatch(v_x2_24467);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam78(V self, V *args) {
  V v_p_24462 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_24462)) {
  case TAG_MkPair: {
    V v_l_24463 = heff_field(v_p_24462, 0);
    V v_e_24464 = heff_field(v_p_24462, 1);
    heff_take_n(v_p_24462, 3ULL, 2);
    V v_m_24465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_e_24464}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam79, 1, 2, (V[]){v_m_24465, v_l_24463});
  }
  default: return heff_nomatch(v_p_24462);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam80(V self, V *args) {
  V v_s_24471 = args[0];
  V v_m_24470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24472 = heff_tr(heff_call(v_m_24470, 1, (V[]){v_s_24471}));
  switch (heff_tag_of(v_x2_24472)) {
  case TAG_MkPair: {
    V v_x_24473 = heff_field(v_x2_24472, 0);
    V v_s_24474 = heff_field(v_x2_24472, 1);
    V v_ru_24x2_24472_24MkPair = heff_take_reuse_n(v_x2_24472, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 1, (V[]){v_x_24473}), v_s_24474});
  }
  default: return heff_nomatch(v_x2_24472);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam81(V self, V *args) {
  V v_s_24479 = args[0];
  V v_m_24478 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_l_24476 = heff_env(self)[2];
  V v_sh_24477 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24480 = heff_tr(heff_call(v_m_24478, 1, (V[]){v_s_24479}));
  switch (heff_tag_of(v_x2_24480)) {
  case TAG_MkPair: {
    V v_x_24481 = heff_field(v_x2_24480, 0);
    V v_s_24482 = heff_field(v_x2_24480, 1);
    heff_take_n(v_x2_24480, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 2, 4);
    heff_room[0] = v_l_24476;
    heff_room[1] = v_sh_24477;
    heff_room[2] = v_x_24481;
    heff_room[3] = v_s_24482;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x2_24480);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam82(V self, V *args) {
  V v_a_24485 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24485;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam83(V self, V *args) {
  V v_s_24487 = args[0];
  V v_m_24486 = heff_env(self)[0];
  V v_t_24483 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24488 = heff_tr(heff_call(v_m_24486, 1, (V[]){v_s_24487}));
  switch (heff_tag_of(v_x2_24488)) {
  case TAG_MkPair: {
    V v_x_24489 = heff_field(v_x2_24488, 0);
    V v_s_24490 = heff_field(v_x2_24488, 1);
    V v_ru_24x2_24488_24MkPair = heff_take_reuse_n(v_x2_24488, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24488_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_24483, v_x_24489}), v_s_24490});
  }
  default: return heff_nomatch(v_x2_24488);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam86(V self, V *args) {
  V v_s_24503 = args[0];
  V v_m_24502 = heff_env(self)[0];
  V v_t_24499 = heff_env(self)[1];
  V v_vs_24500 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24504 = heff_tr(heff_call(v_m_24502, 1, (V[]){v_s_24503}));
  switch (heff_tag_of(v_x2_24504)) {
  case TAG_MkPair: {
    V v_x_24505 = heff_field(v_x2_24504, 0);
    V v_s_24506 = heff_field(v_x2_24504, 1);
    V v_ru_24x2_24504_24MkPair = heff_take_reuse_n(v_x2_24504, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24504_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24499, v_vs_24500, v_x_24505}), v_s_24506});
  }
  default: return heff_nomatch(v_x2_24504);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam85(V self, V *args) {
  V v_a_24498 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_24498)) {
  case TAG_MkArm: {
    V v_t_24499 = heff_field(v_a_24498, 0);
    V v_vs_24500 = heff_field(v_a_24498, 1);
    V v_b_24501 = heff_field(v_a_24498, 2);
    heff_take_n(v_a_24498, 7ULL, 3);
    V v_m_24502 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_b_24501}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam86, 1, 3, (V[]){v_m_24502, v_t_24499, v_vs_24500});
  }
  default: return heff_nomatch(v_a_24498);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam84(V self, V *args) {
  V v_s_24494 = args[0];
  V v_m_24493 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_arms_24492 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24495 = heff_tr(heff_call(v_m_24493, 1, (V[]){v_s_24494}));
  switch (heff_tag_of(v_x2_24495)) {
  case TAG_MkPair: {
    V v_x_24496 = heff_field(v_x2_24495, 0);
    V v_s_24497 = heff_field(v_x2_24495, 1);
    heff_take_n(v_x2_24495, 3ULL, 2);
    V v_m_24507 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2esimpF_lam85, 1, 1, (V[]){heff_dup(v_r_240)}), v_arms_24492));
    V v_x2_24508 = heff_tr(heff_call(v_m_24507, 1, (V[]){v_s_24497}));
    switch (heff_tag_of(v_x2_24508)) {
    case TAG_MkPair: {
      V v_x_24509 = heff_field(v_x2_24508, 0);
      V v_s_24510 = heff_field(v_x2_24508, 1);
      heff_take_n(v_x2_24508, 3ULL, 2);
      V f_ = heff_get_n(v_r_240, 3, 4);
      heff_room[0] = v_x_24496;
      heff_room[1] = v_x_24509;
      heff_room[2] = v_s_24510;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
    default: return heff_nomatch(v_x2_24508);
    }
  }
  default: return heff_nomatch(v_x2_24495);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam87(V self, V *args) {
  V v_s_24512 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24512});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam88(V self, V *args) {
  V v_a_24515 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_r_240, 0, 4);
  args[0] = v_a_24515;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ecompile_2esimplify_2esimpF_lam89(V self, V *args) {
  V v_s_24517 = args[0];
  V v_m_24516 = heff_env(self)[0];
  V v_p_24513 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24518 = heff_tr(heff_call(v_m_24516, 1, (V[]){v_s_24517}));
  switch (heff_tag_of(v_x2_24518)) {
  case TAG_MkPair: {
    V v_x_24519 = heff_field(v_x2_24518, 0);
    V v_s_24520 = heff_field(v_x2_24518, 1);
    V v_ru_24x2_24518_24MkPair = heff_take_reuse_n(v_x2_24518, 3ULL, 2);
    V v_x2_24527;
    switch (heff_tag_of(v_x_24519)) {
    case TAG_Nil: {
      v_x2_24527 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_a_24521 = heff_dup(heff_field(v_x_24519, 0));
      V v_x22_24522 = heff_dup(heff_field(v_x_24519, 1));
      switch (heff_tag_of(v_x22_24522)) {
      case TAG_Nil: {
        v_x2_24527 = (g_heff_2ecompile_2esimplify_2eunOp(heff_dup(v_p_24513), v_a_24521));
        break;
      }
      case TAG_Cons: {
        V v_b_24523 = heff_field(v_x22_24522, 0);
        V v_x222_24524 = heff_field(v_x22_24522, 1);
        heff_take_n(v_x22_24522, 3ULL, 2);
        switch (heff_tag_of(v_x222_24524)) {
        case TAG_Nil: {
          v_x2_24527 = (g_heff_2ecompile_2esimplify_2ebinOp(heff_dup(v_p_24513), v_a_24521, v_b_24523));
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_x222_24524, 0ULL, 2);
          heff_drop(v_a_24521);
          heff_drop(v_b_24523);
          v_x2_24527 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x222_24524);
        }
        break;
      }
      default: heff_nomatch(v_x22_24522);
      }
      break;
    }
    default: heff_nomatch(v_x_24519);
    }
    V v_x_24529;
    switch (heff_tag_of(v_x2_24527)) {
    case TAG_Nothing: {
      v_x_24529 = heff_tag_at_n(v_ru_24x2_24518_24MkPair, TAG_EPrimCall, 2, (V[]){v_p_24513, v_x_24519});
      break;
    }
    case TAG_Just: {
      V v_x_24528 = heff_field(v_x2_24527, 0);
      heff_take_n(v_x2_24527, 1ULL, 1);
      heff_drop(v_p_24513);
      heff_drop(v_x_24519);
      heff_drop_cell(v_ru_24x2_24518_24MkPair, 2);
      v_x_24529 = v_x_24528;
      break;
    }
    default: heff_nomatch(v_x2_24527);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24529, v_s_24520});
  }
  default: return heff_nomatch(v_x2_24518);
  }
}
V g_heff_2ecompile_2esimplify_2esimpF_lam90(V self, V *args) {
  V v_s_24532 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24532});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam91(V self, V *args) {
  V v_s_24534 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24534});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam92(V self, V *args) {
  V v_s_24536 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24536});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam93(V self, V *args) {
  V v_s_24538 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24538});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam94(V self, V *args) {
  V v_s_24541 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24541});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam95(V self, V *args) {
  V v_s_24543 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24543});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam96(V self, V *args) {
  V v_s_24544 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24544});
}
V g_heff_2ecompile_2esimplify_2esimpF_lam97(V self, V *args) {
  V v_s_24547 = args[0];
  V v_e_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_241, v_s_24547});
}

static V g_heff_2ecompile_2esimplify_2einlineMax_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2einlineMax_st;
static V g_heff_2ecompile_2esimplify_2einlineMax_init(void) {
  return MK_INT(50LL);
}
V g_heff_2ecompile_2esimplify_2einlineMax_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2einlineMax_st)) return g_heff_2ecompile_2esimplify_2einlineMax_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2einlineMax_val, &g_heff_2ecompile_2esimplify_2einlineMax_st, g_heff_2ecompile_2esimplify_2einlineMax_init);
}
Clo g_heff_2ecompile_2esimplify_2einlineCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2einlineCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2einlineCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_242), heff_rfield(v_s_244, 2)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2eknown(v_g_242, v_s_244));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
      switch (heff_tag_of(v_x_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 4);
        V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_249, v_s_248});
      }
      case TAG_Just: {
        V v_b_2410 = heff_field(v_x_247, 0);
        heff_take_n(v_x_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
        V v_t_2411 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2410, v_as_243}));
        return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2411, v_t_2412, v_s_248));
      }
      default: return heff_nomatch(v_x_247);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  case TAG_Just: {
    V v_b_2413 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_2413, NTAG(TAG_Nil)});
    V v_a_2415 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2einlineMax_get()), MK_INT(0LL), v_t_2414));
    if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2einlineMax_get()), v_a_2415)) {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_g_242);
      V v_x_2417 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_244});
    } else {
      V v_x2_2418 = (g_heff_2ecompile_2esimplify_2eknown(v_g_242, v_s_244));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_s_2420 = heff_field(v_x2_2418, 1);
        V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
        switch (heff_tag_of(v_x_2419)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2421 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2420});
        }
        case TAG_Just: {
          V v_b_2422 = heff_field(v_x_2419, 0);
          heff_take_n(v_x_2419, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2418_24MkPair, 2);
          V v_t_2423 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_243)));
          V v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2422, v_as_243}));
          return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2423, v_t_2424, v_s_2420));
        }
        default: return heff_nomatch(v_x_2419);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2esimplify_2einlineCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2einlineCall(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_str0, 1, "p");
HEFF_LIT(g_heff_2ecompile_2esimplify_2efreshParams_str1, 1, "$");
Clo g_heff_2ecompile_2esimplify_2efreshParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efreshParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efreshParams(V v_k_240, V v_s_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_take_field(v_s_241, 0)});
  V v_t_243 = (g_list_2erange(MK_INT(1LL), v_k_240));
  V v_t_244 = (g_list_2efoldl_24s85178867x1278479365(((V)&g_heff_2ecompile_2esimplify_2efreshParams_str0), ((V)&g_heff_2ecompile_2esimplify_2efreshParams_str1), MK_INT(1LL), v_t_242, v_t_243));
  switch (heff_tag_of(v_t_244)) {
  case TAG_MkPair: {
    V v_xs_245 = heff_field(v_t_244, 0);
    V v_n_246 = heff_field(v_t_244, 1);
    V v_ru_24t_244_24MkPair = heff_take_reuse_n(v_t_244, 3ULL, 2);
    V v_t_247 = ({ V rv_0 = v_n_246; V rr_ = heff_rec_reuse_n(v_s_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_at_n(v_ru_24t_244_24MkPair, TAG_MkPair, 2, (V[]){v_xs_245, v_t_247});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2esimplify_2efreshParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2efreshParams(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2eremember_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eremember_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eremember(V v_k_240, V v_p_241, V v_s_242) {
top: ;
  V v_t_245;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_k_240, v_p_241, heff_take_field(v_s_242, 6)));
    v_t_245 = ({ V rv_6 = v_t_244; V rr_ = heff_rec_reuse_n(v_s_242, 447ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 6) = rv_6; rr_; });
  } else {
    heff_drop(v_k_240);
    heff_drop(v_p_241);
    v_t_245 = v_s_242;
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
}
V g_heff_2ecompile_2esimplify_2eremember_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eremember(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str0, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str1, 1, "/");
HEFF_LIT(g_heff_2ecompile_2esimplify_2eplainCall_str2, 1, "/");
Clo g_heff_2ecompile_2esimplify_2eplainCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eplainCall_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2eplainCall(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_s_244) {
top: ;
  V v_t_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_246 = heff_strAppend(heff_dup(v_g_242), heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str0), heff_intShow(v_t_245)));
  V v_it_247 = (g_map_2elookup_24s1546226666x2146984184(v_t_246, heff_rfield(v_s_244, 6)));
  switch (heff_tag_of(v_it_247)) {
  case TAG_Nothing: {
    V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_x2_249 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_248, heff_dup(v_s_244)));
    switch (heff_tag_of(v_x2_249)) {
    case TAG_MkPair: {
      V v_x_2410 = heff_field(v_x2_249, 0);
      V v_s_2411 = heff_field(v_x2_249, 1);
      V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
      V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eknown(heff_dup(v_g_242), v_s_2411));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
        switch (heff_tag_of(v_x_2413)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          heff_drop(v_g_242);
          heff_drop_rec(v_s_244, 9);
          heff_drop(v_x_2410);
          heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
          V v_x_2415 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
          return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2415, v_s_2414});
        }
        case TAG_Just: {
          V v_b_2416 = heff_field(v_x_2413, 0);
          heff_take_n(v_x_2413, 1ULL, 1);
          V v_t_2417 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_x_2410)));
          V v_m_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2416, v_t_2417}));
          V v_x2_2419 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_s_2414}));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_s_2421 = heff_field(v_x2_2419, 1);
            V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
            V v_e_2422 = (g_heff_2ecompile_2esimplify_2emkApp(heff_dup(v_f_241), heff_dup(v_as_243)));
            V v_t_2423 = heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_Cons, 2, (V[]){v_e_2422, NTAG(TAG_Nil)});
            V v_t_2424 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_2423));
            V v_lim_2425 = heff_intAdd(v_t_2424, heff_dup(g_heff_2ecompile_2esimplify_2ebudget_get()));
            V v_t_2426 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2420), NTAG(TAG_Nil)});
            V v_a_2427 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(v_lim_2425), MK_INT(0LL), v_t_2426));
            V v_t_2429;
            if (heff_intLt_c(v_lim_2425, v_a_2427)) {
              v_t_2429 = NTAG(TAG_False);
            } else {
              v_t_2429 = NTAG(TAG_True);
            }
            switch (heff_tag_of(v_t_2429)) {
            case TAG_True: {
              heff_drop(v_f_241);
              heff_drop_rec(v_s_244, 9);
              V v_t_2430 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2431 = heff_strAppend(v_g_242, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str1), heff_intShow(v_t_2430)));
              V v_x2_2432 = (g_heff_2ecompile_2esimplify_2eremember(v_t_2431, heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_Inlined, 2, (V[]){heff_dup(v_x_2410), heff_dup(v_x_2420)}), v_s_2421));
              switch (heff_tag_of(v_x2_2432)) {
              case TAG_MkPair: {
                V v_s_2434 = heff_field(v_x2_2432, 1);
                V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 2ULL, 2);
                V v_t_2435 = (g_heff_2ecompile_2esimplify_2ezipL(v_x_2410, v_as_243));
                V v_m_2436 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2435; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_2435); r_; });
                V v_t_2437 = (g_map_2esize(v_m_2436));
                V v_x_2439;
                if (heff_intEq_c(v_t_2437, MK_INT(0LL))) {
                  heff_drop(v_m_2436);
                  v_x_2439 = v_x_2420;
                } else {
                  v_x_2439 = ({ V a_0 = v_m_2436; V a_1 = v_x_2420; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2436); r_; });
                }
                return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){v_x_2439, v_s_2434});
              }
              default: return heff_nomatch(v_x2_2432);
              }
            }
            case TAG_False: {
              heff_drop(v_x_2410);
              heff_drop(v_x_2420);
              V v_t_2440 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
              V v_t_2441 = heff_strAppend(v_g_242, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2eplainCall_str2), heff_intShow(v_t_2440)));
              V v_t_2442 = ({ V rv_2 = heff_take_field(v_s_244, 2); V rv_5 = heff_get_n(v_s_244, 5, 9); V rr_ = heff_rec_reuse_n(v_s_2421, 475ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 5) = rv_5; rr_; });
              V v_x2_2443 = (g_heff_2ecompile_2esimplify_2eremember(v_t_2441, NTAG(TAG_NotInlined), v_t_2442));
              switch (heff_tag_of(v_x2_2443)) {
              case TAG_MkPair: {
                V v_s_2445 = heff_field(v_x2_2443, 1);
                heff_take_n(v_x2_2443, 2ULL, 2);
                V v_x_2446 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
                return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2446, v_s_2445});
              }
              default: return heff_nomatch(v_x2_2443);
              }
            }
            default: return heff_nomatch(v_t_2429);
            }
          }
          default: return heff_nomatch(v_x2_2419);
          }
        }
        default: return heff_nomatch(v_x_2413);
        }
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    default: return heff_nomatch(v_x2_249);
    }
  }
  case TAG_Just: {
    V v_it1_2447 = heff_field(v_it_247, 0);
    heff_take_n(v_it_247, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_g_242);
    switch (heff_tag_of(v_it1_2447)) {
    case TAG_Inlined: {
      V v_ps_2448 = heff_field(v_it1_2447, 0);
      V v_e_2449 = heff_field(v_it1_2447, 1);
      V v_ru_24it1_2447_24Inlined = heff_take_reuse_n(v_it1_2447, 3ULL, 2);
      if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_244, 1)))) {
        heff_drop(v_f_241);
        V v_t_2451 = heff_intSub(heff_take_field(v_s_244, 1), MK_INT(1LL));
        V v_t_2452 = ({ V rv_1 = v_t_2451; V rr_ = heff_rec_reuse_n(v_s_244, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_x2_2453 = (g_heff_2ecompile_2esimplify_2ecopy(v_e_2449, v_t_2452));
        switch (heff_tag_of(v_x2_2453)) {
        case TAG_MkPair: {
          V v_x_2454 = heff_field(v_x2_2453, 0);
          V v_s_2455 = heff_field(v_x2_2453, 1);
          heff_take_n(v_x2_2453, 3ULL, 2);
          V v_t_2456 = (g_heff_2ecompile_2esimplify_2ezipL(v_ps_2448, v_as_243));
          V v_m_2457 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2456; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_2456); r_; });
          V v_t_2458 = (g_map_2esize(v_m_2457));
          V v_x_2460;
          if (heff_intEq_c(v_t_2458, MK_INT(0LL))) {
            heff_drop(v_m_2457);
            v_x_2460 = v_x_2454;
          } else {
            v_x_2460 = ({ V a_0 = v_m_2457; V a_1 = v_x_2454; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_2457); r_; });
          }
          return heff_tag_at_n(v_ru_24it1_2447_24Inlined, TAG_MkPair, 2, (V[]){v_x_2460, v_s_2455});
        }
        default: return heff_nomatch(v_x2_2453);
        }
      } else {
        heff_drop(v_ps_2448);
        heff_drop(v_e_2449);
        V v_x_2461 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
        return heff_tag_at_n(v_ru_24it1_2447_24Inlined, TAG_MkPair, 2, (V[]){v_x_2461, v_s_244});
      }
    }
    case TAG_NotInlined: {
      V v_x_2462 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2462, v_s_244});
    }
    default: return heff_nomatch(v_it1_2447);
    }
  }
  default: return heff_nomatch(v_it_247);
  }
}
V g_heff_2ecompile_2esimplify_2eplainCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eplainCall(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ecompile_2esimplify_2ecallOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecallOf_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecallOf(V v_r_240, V v_f_241, V v_g_242, V v_as_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
  }
  case TAG_Just: {
    V v_x51_245 = heff_field(v_x5_244, 0);
    switch (heff_tag_of(v_x51_245)) {
    case TAG_EVar: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EGlobal: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELam: {
      V v_xs_248 = heff_field(v_x51_245, 0);
      V v_t_2410 = (g_list_2emap_24s379119719x1394241001(heff_dup(v_as_243)));
      V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_t_2412 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_248));
        V v_t_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
        if (heff_intEq_c(v_t_2412, v_t_2413)) {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eplainCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        } else {
          return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
        }
      }
      case TAG_False: {
        return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_EApp: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ELet: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ERecord: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EProj: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ETag: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EMatch: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrim: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EPrimCall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_ECall: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EInt: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EStr: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFixed: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFloat32: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EAbandon: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    case TAG_EFix: {
      return heff_tail(((V)&g_heff_2ecompile_2esimplify_2einlineCall_clo), 4, (V[]){v_r_240, v_f_241, v_g_242, v_as_243});
    }
    default: return heff_nomatch(v_x51_245);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2esimplify_2ecallOf_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2esimplify_2ecallOf(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyLam_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eapplyLam(V v_r_240, V v_xs_241, V v_b_242, V v_as_243) {
top: ;
  V v_a_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_245 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_247;
  if (heff_intLe_c(heff_dup(v_a_244), heff_dup(v_b_245))) {
    heff_drop(v_b_245);
    v_t_247 = v_a_244;
  } else {
    heff_drop(v_a_244);
    v_t_247 = v_b_245;
  }
  V v_t_248 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_247, heff_dup(v_xs_241)));
  V v_a_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_t_2412;
  if (heff_intLe_c(heff_dup(v_a_249), heff_dup(v_b_2410))) {
    heff_drop(v_b_2410);
    v_t_2412 = v_a_249;
  } else {
    heff_drop(v_a_249);
    v_t_2412 = v_b_2410;
  }
  V v_t_2413 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2412, heff_dup(v_as_243)));
  V v_t_2414 = (g_heff_2ecompile_2esimplify_2ezipL(v_t_248, v_t_2413));
  V v_a_2415 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_a_2416 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
  V v_b_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
  V v_b_2419;
  if (heff_intLe_c(heff_dup(v_a_2416), heff_dup(v_b_2417))) {
    heff_drop(v_b_2417);
    v_b_2419 = v_a_2416;
  } else {
    heff_drop(v_a_2416);
    v_b_2419 = v_b_2417;
  }
  V v_t_2426;
  if (heff_intLt_c(v_b_2419, v_a_2415)) {
    V v_a_2421 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_241));
    V v_b_2422 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2424;
    if (heff_intLe_c(heff_dup(v_a_2421), heff_dup(v_b_2422))) {
      heff_drop(v_b_2422);
      v_t_2424 = v_a_2421;
    } else {
      heff_drop(v_a_2421);
      v_t_2424 = v_b_2422;
    }
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2424, heff_dup(v_xs_241)));
    v_t_2426 = heff_tag_n(TAG_ELam, 2, (V[]){v_t_2425, v_b_242});
  } else {
    v_t_2426 = v_b_242;
  }
  V v_t_2427 = ({ V a_0 = v_t_2414; V a_1 = v_t_2426; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_m_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_2427}));
  return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyLam_lam0, 1, 4, (V[]){v_m_2428, v_xs_241, v_as_243, v_r_240});
}
V g_heff_2ecompile_2esimplify_2eapplyLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyLam(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eapplyLam_lam0(V self, V *args) {
  V v_s_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_xs_241 = heff_env(self)[1];
  V v_as_243 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_s_2432 = heff_field(v_x2_2430, 1);
    heff_take_n(v_x2_2430, 3ULL, 2);
    V v_a_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
    V v_b_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_243));
    V v_t_2436;
    if (heff_intLe_c(heff_dup(v_a_2433), heff_dup(v_b_2434))) {
      heff_drop(v_b_2434);
      v_t_2436 = v_a_2433;
    } else {
      heff_drop(v_a_2433);
      v_t_2436 = v_b_2434;
    }
    V v_t_2437 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2436, v_as_243));
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_2431;
    heff_room[1] = v_t_2437;
    heff_room[2] = v_s_2432;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
Clo g_heff_2ecompile_2esimplify_2evarsAre_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2evarsAre_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2evarsAre(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_x21_246 = heff_field(v_x2_241, 0);
      V v_es_247 = heff_field(v_x2_241, 1);
      switch (heff_tag_of(v_x21_246)) {
      case TAG_EVar: {
        V v_y_248 = heff_field(v_x21_246, 0);
        if (heff_strEq_c(heff_dup(v_x_244), heff_dup(v_y_248))) {
          V t_0 = v_xs_245;
          V t_1 = v_es_247;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          return NTAG(TAG_False);
        }
      }
      case TAG_EGlobal: {
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_246);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2evarsAre_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2evarsAre(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2esimplify_2especBodySize_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especBodySize_st;
static V g_heff_2ecompile_2esimplify_2especBodySize_init(void) {
  return MK_INT(1200LL);
}
V g_heff_2ecompile_2esimplify_2especBodySize_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especBodySize_st)) return g_heff_2ecompile_2esimplify_2especBodySize_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especBodySize_val, &g_heff_2ecompile_2esimplify_2especBodySize_st, g_heff_2ecompile_2esimplify_2especBodySize_init);
}

static V g_heff_2ecompile_2esimplify_2especLimit_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especLimit_st;
static V g_heff_2ecompile_2esimplify_2especLimit_init(void) {
  return MK_INT(50000LL);
}
V g_heff_2ecompile_2esimplify_2especLimit_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especLimit_st)) return g_heff_2ecompile_2esimplify_2especLimit_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especLimit_val, &g_heff_2ecompile_2esimplify_2especLimit_st, g_heff_2ecompile_2esimplify_2especLimit_init);
}

static V g_heff_2ecompile_2esimplify_2especDepth_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2especDepth_st;
static V g_heff_2ecompile_2esimplify_2especDepth_init(void) {
  return MK_INT(16LL);
}
V g_heff_2ecompile_2esimplify_2especDepth_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2especDepth_st)) return g_heff_2ecompile_2esimplify_2especDepth_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2especDepth_val, &g_heff_2ecompile_2esimplify_2especDepth_st, g_heff_2ecompile_2esimplify_2especDepth_init);
}
Clo g_heff_2ecompile_2esimplify_2eknownArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownArg_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eknownArg(V v_kinds_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(v_g_243, v_kinds_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EApp: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ELet: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ERecord: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EProj: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ETag: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EMatch: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EPrim: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EPrimCall: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_ECall: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EInt: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFloat: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EStr: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFixed: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFloat32: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EAbandon: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  case TAG_EFix: {
    return (g_heff_2ecompile_2esimplify_2eclosedKnown(v_e_241));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2eknownArg_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eknownArg(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2enthE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2enthE_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2enthE(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2enthE_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2enthE(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkGo_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emarkGo(V v_all_240, V v_as_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_st_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_st_244)) {
    case TAG_True: {
      V v_x3_246 = (g_heff_2ecompile_2esimplify_2enthE(heff_dup(v_i_243), v_as_241));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        v_t_248 = (g_heff_2ecompile_2esimplify_2eknownArg(v_all_240, v_x_247));
        break;
      }
      default: heff_nomatch(v_x3_246);
      }
      break;
    }
    case TAG_False: {
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_st_244);
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, (g_heff_2ecompile_2esimplify_2emarkGo(v_all_240, v_as_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2emarkGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeepParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeepParams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeepParams(V v_x1_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_xs_241;
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_xs_241, 0);
      V v_xs2_245 = heff_field(v_xs_241, 1);
      heff_take_n(v_xs_241, 3ULL, 2);
      switch (heff_tag_of(v_m_242)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_244);
        V t_0 = v_ms_243;
        V t_1 = v_xs2_245;
        v_x1_240 = t_0;
        v_xs_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, (g_heff_2ecompile_2esimplify_2ekeepParams(v_ms_243, v_xs2_245))});
      }
      default: return heff_nomatch(v_m_242);
      }
    }
    default: return heff_nomatch(v_xs_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ekeepParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeepParams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2esubstMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esubstMarked_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2esubstMarked(V v_x1_240, V v_x2_241, V v_x3_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam0, 1, 1, (V[]){v_e_243});
  }
  case TAG_Cons: {
    V v_m_245 = heff_field(v_x1_240, 0);
    V v_ms_246 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_245);
      heff_drop(v_ms_246);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam1, 1, 1, (V[]){v_e_243});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x2_241, 0);
      V v_xs_249 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_x3_242)) {
      case TAG_Nil: {
        heff_drop(v_m_245);
        heff_drop(v_ms_246);
        heff_drop(v_x_248);
        heff_drop(v_xs_249);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam2, 1, 1, (V[]){v_e_243});
      }
      case TAG_Cons: {
        V v_a_2411 = heff_field(v_x3_242, 0);
        V v_as_2412 = heff_field(v_x3_242, 1);
        switch (heff_tag_of(v_m_245)) {
        case TAG_True: {
          V v_m_2413 = heff_tr(g_heff_2ecompile_2esimplify_2esubstCopies(v_x_248, heff_dup(v_a_2411), v_e_243));
          return heff_clo_n(g_heff_2ecompile_2esimplify_2esubstMarked_lam3, 1, 4, (V[]){v_m_2413, v_ms_246, v_xs_249, heff_dup(v_as_2412)});
        }
        case TAG_False: {
          heff_drop(v_x_248);
          V t_0 = v_ms_246;
          V t_1 = v_xs_249;
          V t_2 = v_as_2412;
          V t_3 = v_e_243;
          v_x1_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          v_e_243 = t_3;
          goto top;
        }
        default: return heff_nomatch(v_m_245);
        }
      }
      default: return heff_nomatch(v_x3_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esubstMarked_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2esubstMarked(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_244});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_247});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_e_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_243, v_s_2410});
}
V g_heff_2ecompile_2esimplify_2esubstMarked_lam3(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_ms_246 = heff_env(self)[1];
  V v_xs_249 = heff_env(self)[2];
  V v_as_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = ({ V a_0 = v_ms_246; V a_1 = v_xs_249; V a_2 = v_as_2412; V a_3 = v_x_2416; V r_ = (g_heff_2ecompile_2esimplify_2esubstMarked(a_0, a_1, a_2, a_3)); heff_drop(v_as_2412); r_; });
    V f_ = v_t_2418;
    args[0] = v_s_2417;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
Clo g_heff_2ecompile_2esimplify_2eshapeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapeOne_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapeOne(V v_m_240, V v_a_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_m_240)) {
  case TAG_True: {
    V v_t_243 = heff_rec_n(4, shape_ren__vars__holes__n, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_s_242, 0)});
    V v_x1_244 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_241, v_t_243));
    V v_x_249;
    switch (heff_tag_of(v_x1_244)) {
    case TAG_MkPair: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_st_246 = heff_field(v_x1_244, 1);
      heff_take_n(v_x1_244, 3ULL, 2);
      V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 1)));
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_st_246, 2)));
      v_x_249 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_e_245, v_t_247, v_t_248, heff_get_n(v_st_246, 3, 4)});
      break;
    }
    default: heff_nomatch(v_x1_244);
    }
    V v_t_2410 = ({ V rv_0 = heff_dup(heff_rfield(v_x_249, 3)); V rr_ = heff_rec_reuse_n(v_s_242, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2410});
  }
  case TAG_False: {
    V v_t_2411 = heff_rec_n(4, shape_e__vars__holes__n, (V[]){v_a_241, NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(heff_rfield(v_s_242, 0))});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_s_242});
  }
  default: return heff_nomatch(v_m_240);
  }
}
V g_heff_2ecompile_2esimplify_2eshapeOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2eshapeOne(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2eshapesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eshapesOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eshapesOf(V v_x1_240, V v_as_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_p_242});
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x1_240, 0);
    V v_ms_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_m_244);
      heff_drop(v_ms_245);
      V v_t_246 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_as_241, NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_t_246, v_p_242});
    }
    case TAG_Cons: {
      V v_a_247 = heff_field(v_as_241, 0);
      V v_as2_248 = heff_field(v_as_241, 1);
      V v_ru_24as_241_24Cons = heff_take_reuse_n(v_as_241, 3ULL, 2);
      V v_x2_249 = ({ V a_0 = v_m_244; V a_1 = v_a_247; V a_2 = v_p_242; V r_ = (g_heff_2ecompile_2esimplify_2eshapeOne(a_0, a_1, a_2)); heff_drop(v_m_244); r_; });
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_x_2410 = heff_field(v_x2_249, 0);
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        V v_m_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2eshapesOf_clo), 2, (V[]){v_ms_245, v_as2_248}));
        V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
        switch (heff_tag_of(v_x2_2413)) {
        case TAG_MkPair: {
          V v_x_2414 = heff_field(v_x2_2413, 0);
          V v_s_2415 = heff_field(v_x2_2413, 1);
          heff_take_n(v_x2_2413, 3ULL, 2);
          V v_t_2416 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_2410, 0)), heff_dup(heff_rfield(v_x_2414, 0))});
          V v_t_2417 = (g_heff_2ecompile_2esimplify_2eappendL(heff_take_field(v_x_2410, 1), heff_take_field(v_x_2414, 1)));
          V v_t_2418 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_x_2410, 2, 4), heff_get_n(v_x_2414, 2, 3)));
          V v_x_2419 = heff_rec_n(3, shape_args__vars__holes, (V[]){v_t_2416, v_t_2417, v_t_2418});
          return heff_tag_at_n(v_ru_24as_241_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2415});
        }
        default: return heff_nomatch(v_x2_2413);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eshapesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eshapesOf(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emarkSafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkSafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkSafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_247;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V v_t_244 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_242, 3)));
    v_t_247 = ({ V rv_3 = v_t_244; V rr_ = heff_rec_reuse_n(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 3) = rv_3; rr_; });
    break;
  }
  case TAG_False: {
    V v_t_245 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 3), heff_rfield(v_s_242, 5), v_b_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      V v_t_246 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_242, 3)));
      v_t_247 = ({ V rv_3 = v_t_246; V rr_ = heff_rec_reuse_n(v_s_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 3) = rv_3; rr_; });
      break;
    }
    case TAG_False: {
      heff_drop(v_h_240);
      v_t_247 = v_s_242;
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2esimplify_2emarkSafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkSafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2emarkCopySafe_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkCopySafe_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkCopySafe(V v_h_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eisValue(v_b_241));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_244 = (g_heff_2ecompile_2esimplify_2epureIn(heff_rfield(v_s_242, 4), heff_rfield(v_s_242, 5), v_b_241));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_248;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), heff_take_field(v_s_242, 4)));
    V v_s_246 = ({ V rv_4 = v_t_245; V rr_ = heff_rec_reuse_n(v_s_242, 495ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), heff_take_field(v_s_246, 3)));
    v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_n(v_s_246, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 3) = rv_3; rr_; });
    break;
  }
  case TAG_False: {
    heff_drop(v_h_240);
    v_t_248 = v_s_242;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2emarkCopySafe_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emarkCopySafe(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2easkedFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkedFor_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkedFor(V v_h_240, V v_b0_241, V v_d_242, V v_s_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b0_241), NTAG(TAG_Nil)});
  V v_a_245 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_244));
  V v_t_248;
  if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), v_a_245)) {
    v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  } else {
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
    v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), heff_dup(v_b0_241), v_t_247));
  }
  V v_t_2439;
  switch (heff_tag_of(v_b0_241)) {
  case TAG_EVar: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    v_t_2439 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2439 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2439 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b0_241);
  }
  V v_t_2441;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_True: {
    V v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    v_t_2441 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), NTAG(TAG_MkUnit), v_t_2440));
    break;
  }
  case TAG_False: {
    v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 1, 7);
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 2, 7);
  V v_t_2443 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_b0_241, v_t_2442));
  V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 3, 7);
  V v_t_2445 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_d_242, v_t_2444));
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 4, 7);
  V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 5, 7);
  V v_t_2448 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 6, 7);
  V v_p_2449 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_248, v_t_2441, v_t_2443, v_t_2445, v_t_2446, heff_intAdd(v_t_2447, MK_INT(1LL)), v_t_2448});
  V v_t_2450 = ({ V rv_7 = v_p_2449; V rr_ = heff_rec_reuse_n(v_s_243, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2450});
}
V g_heff_2ecompile_2esimplify_2easkedFor_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2easkedFor(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especBody_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2especBody(V v_g_240, V v_h_241, V v_marks_242, V v_sh_243, V v_lam1_244) {
top: ;
  switch (heff_tag_of(v_lam1_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam0, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam1, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELam: {
    V v_xs1_249 = heff_field(v_lam1_244, 0);
    V v_b1_2410 = heff_field(v_lam1_244, 1);
    heff_take_n(v_lam1_244, 3ULL, 2);
    V v_t_2411 = (g_list_2emap_24s1809017761x1063871171(heff_dup(heff_rfield(v_sh_243, 1))));
    V v_t_2412 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_t_2411, heff_dup(v_marks_242), v_b1_2410));
    V v_m_2413 = (g_heff_2ecompile_2esimplify_2esubstMarked(heff_dup(v_marks_242), heff_dup(v_xs1_249), heff_rfield(v_sh_243, 0), v_t_2412));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam2, 1, 4, (V[]){v_m_2413, v_marks_242, v_xs1_249, v_sh_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam3, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam4, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam5, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam6, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam7, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam8, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam9, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam10, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam11, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam12, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam13, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam14, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam15, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam16, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam17, 1, 1, (V[]){v_lam1_244});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_marks_242);
    heff_drop_rec(v_sh_243, 3);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2especBody_lam18, 1, 1, (V[]){v_lam1_244});
  }
  default: return heff_nomatch(v_lam1_244);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especBody(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2esimplify_2especBody_lam0(V self, V *args) {
  V v_s_246 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_246});
}
V g_heff_2ecompile_2esimplify_2especBody_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_248});
}
V g_heff_2ecompile_2esimplify_2especBody_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_marks_242 = heff_env(self)[1];
  V v_xs1_249 = heff_env(self)[2];
  V v_sh_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_s_2417 = heff_field(v_x2_2415, 1);
    V v_ru_24x2_2415_24MkPair = heff_take_reuse_n(v_x2_2415, 3ULL, 2);
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_242), heff_dup(v_xs1_249)));
    V v_x1_2419 = (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(heff_rfield(v_sh_243, 1)), v_t_2418));
    V v_x_2424;
    switch (heff_tag_of(v_x1_2419)) {
    case TAG_Nil: {
      heff_drop(v_marks_242);
      heff_drop(v_xs1_249);
      heff_drop_rec(v_sh_243, 3);
      heff_drop_cell(v_ru_24x2_2415_24MkPair, 2);
      v_x_2424 = v_x_2416;
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2419, 0ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2ekeepParams(v_marks_242, v_xs1_249));
      V v_t_2423 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_243, 1, 3), v_t_2422));
      v_x_2424 = heff_tag_at_n(v_ru_24x2_2415_24MkPair, TAG_ELam, 2, (V[]){v_t_2423, v_x_2416});
      break;
    }
    default: heff_nomatch(v_x1_2419);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2424, v_s_2417});
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2esimplify_2especBody_lam3(V self, V *args) {
  V v_s_2427 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2427});
}
V g_heff_2ecompile_2esimplify_2especBody_lam4(V self, V *args) {
  V v_s_2431 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2431});
}
V g_heff_2ecompile_2esimplify_2especBody_lam5(V self, V *args) {
  V v_s_2433 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2433});
}
V g_heff_2ecompile_2esimplify_2especBody_lam6(V self, V *args) {
  V v_s_2437 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2437});
}
V g_heff_2ecompile_2esimplify_2especBody_lam7(V self, V *args) {
  V v_s_2440 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2440});
}
V g_heff_2ecompile_2esimplify_2especBody_lam8(V self, V *args) {
  V v_s_2443 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2443});
}
V g_heff_2ecompile_2esimplify_2especBody_lam9(V self, V *args) {
  V v_s_2445 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2445});
}
V g_heff_2ecompile_2esimplify_2especBody_lam10(V self, V *args) {
  V v_s_2448 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2448});
}
V g_heff_2ecompile_2esimplify_2especBody_lam11(V self, V *args) {
  V v_s_2451 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2451});
}
V g_heff_2ecompile_2esimplify_2especBody_lam12(V self, V *args) {
  V v_s_2453 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2453});
}
V g_heff_2ecompile_2esimplify_2especBody_lam13(V self, V *args) {
  V v_s_2455 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2455});
}
V g_heff_2ecompile_2esimplify_2especBody_lam14(V self, V *args) {
  V v_s_2457 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2457});
}
V g_heff_2ecompile_2esimplify_2especBody_lam15(V self, V *args) {
  V v_s_2460 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2460});
}
V g_heff_2ecompile_2esimplify_2especBody_lam16(V self, V *args) {
  V v_s_2462 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2462});
}
V g_heff_2ecompile_2esimplify_2especBody_lam17(V self, V *args) {
  V v_s_2463 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2463});
}
V g_heff_2ecompile_2esimplify_2especBody_lam18(V self, V *args) {
  V v_s_2466 = args[0];
  V v_lam1_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_lam1_244, v_s_2466});
}
Clo g_heff_2ecompile_2esimplify_2echeap_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2echeap_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2echeap(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    V v_g_243 = heff_field(v_x2_241, 0);
    V v_x3_244 = ({ V a_0 = heff_dup(v_g_243); V a_1 = v_safe_240; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_safe_240); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_ELam: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), v_a_2411));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V t_0 = v_safe_240;
      V t_1 = v_b_2412;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_ERecord: {
    V v_fs_2414 = heff_field(v_x2_241, 0);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2416 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2414)));
    V v_t_2417 = (g_list_2emap(v_t_2415, v_t_2416));
    return ({ V a_0 = v_t_2417; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    V t_0 = v_safe_240;
    V t_1 = v_e_2418;
    v_safe_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2422 = heff_field(v_x2_241, 1);
    V v_t_2423 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
    V v_t_2424 = (g_list_2emap(v_t_2423, heff_dup(v_as_2422)));
    return ({ V a_0 = v_t_2424; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2424); r_; });
  }
  case TAG_EMatch: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_p_2428 = heff_field(v_x2_241, 0);
    V v_as_2429 = heff_field(v_x2_241, 1);
    V v_x1_2430 = (g_heff_2ecompile_2esimplify_2eprimFails(heff_dup(v_p_2428)));
    switch (heff_tag_of(v_x1_2430)) {
    case TAG_True: {
      heff_drop(v_safe_240);
      return NTAG(TAG_False);
    }
    case TAG_False: {
      V v_t_2431 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2echeap_clo), 1, (V[]){v_safe_240}));
      V v_t_2432 = (g_list_2emap(v_t_2431, heff_dup(v_as_2429)));
      return ({ V a_0 = v_t_2432; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2432); r_; });
    }
    default: return heff_nomatch(v_x1_2430);
    }
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2echeap_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2echeap(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2elamsOut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2elamsOut_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2elamsOut(V v_safe_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EGlobal: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_x2_241, 0);
    heff_drop(v_safe_240);
    return (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_244));
  }
  case TAG_EApp: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ELet: {
    V v_a_249 = heff_field(v_x2_241, 1);
    V v_b_2410 = heff_field(v_x2_241, 2);
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), v_a_249));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      V t_0 = v_safe_240;
      V t_1 = v_b_2410;
      v_safe_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_ERecord: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EProj: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ETag: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EMatch: {
    V v_sc_2418 = heff_field(v_x2_241, 0);
    V v_arms_2419 = heff_field(v_x2_241, 1);
    V v_t_2420 = (g_heff_2ecompile_2esimplify_2echeap(heff_dup(v_safe_240), v_sc_2418));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      V v_x1_2423;
      switch (heff_tag_of(v_arms_2419)) {
      case TAG_Nil: {
        v_x1_2423 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_2423 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_arms_2419);
      }
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_True: {
        heff_drop(v_safe_240);
        return MK_INT(0LL);
      }
      case TAG_False: {
        V v_t_2424 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2elamsOut_clo), 1, (V[]){v_safe_240}));
        V v_t_2425 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2419)));
        V v_x1_2426 = (g_list_2emap(v_t_2424, v_t_2425));
        switch (heff_tag_of(v_x1_2426)) {
        case TAG_Nil: {
          return MK_INT(0LL);
        }
        case TAG_Cons: {
          V v_x_2427 = heff_field(v_x1_2426, 0);
          V v_xs_2428 = heff_field(v_x1_2426, 1);
          heff_take_n(v_x1_2426, 3ULL, 2);
          return ({ V a_0 = v_x_2427; V a_1 = v_xs_2428; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_xs_2428); r_; });
        }
        default: return heff_nomatch(v_x1_2426);
        }
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    case TAG_False: {
      heff_drop(v_safe_240);
      return MK_INT(0LL);
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EPrimCall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_ECall: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EInt: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EStr: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFixed: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFloat32: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EAbandon: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  case TAG_EFix: {
    heff_drop(v_safe_240);
    return MK_INT(0LL);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2elamsOut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2elamsOut(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2estripLams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estripLams_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estripLams(V v_zs_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELam: {
    V v_ys_244 = heff_field(v_e_241, 0);
    V v_b_245 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_as_246 = (g_list_2emap_24s1809017761x1063871171(heff_dup(v_zs_240)));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2ezipL(heff_dup(v_ys_244), v_as_246));
    V v_m_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_a_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ys_244));
    V v_b_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_zs_240));
    V v_e_2414;
    if (heff_intLt_c(v_b_2410, v_a_249)) {
      V v_t_2412 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_zs_240; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_zs_240); r_; });
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2edropL(v_t_2412, v_ys_244));
      v_e_2414 = heff_tag_at_n(v_ru_24e_241_24ELam, TAG_ELam, 2, (V[]){v_t_2413, v_b_245});
    } else {
      heff_drop(v_zs_240);
      heff_drop(v_ys_244);
      heff_drop_cell(v_ru_24e_241_24ELam, 2);
      v_e_2414 = v_b_245;
    }
    V v_t_2415 = (g_map_2esize(v_m_248));
    if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
      heff_drop(v_m_248);
      return v_e_2414;
    } else {
      return ({ V a_0 = v_m_248; V a_1 = v_e_2414; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_248); r_; });
    }
  }
  case TAG_EApp: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_241, 0);
    V v_a_2420 = heff_field(v_e_241, 1);
    V v_b_2421 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    return heff_tag_at_n(v_ru_24e_241_24ELet, TAG_ELet, 3, (V[]){v_x_2419, v_a_2420, (g_heff_2ecompile_2esimplify_2estripLams(v_zs_240, v_b_2421))});
  }
  case TAG_ERecord: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EProj: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ETag: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EMatch: {
    V v_sc_2428 = heff_field(v_e_241, 0);
    V v_arms_2429 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2estripLams_clo), 1, (V[]){v_zs_240}));
    return heff_tag_at_n(v_ru_24e_241_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2428, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2estripLams_lam0, 1, 1, (V[]){v_go_2430}), v_arms_2429))});
  }
  case TAG_EPrim: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EPrimCall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_ECall: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EInt: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EStr: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFixed: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  case TAG_EFix: {
    heff_drop(v_zs_240);
    return v_e_241;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2estripLams(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2estripLams_lam0(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkArm: {
    V v_t_2432 = heff_field(v_x2_2431, 0);
    V v_vs_2433 = heff_field(v_x2_2431, 1);
    V v_b_2434 = heff_field(v_x2_2431, 2);
    V v_ru_24x2_2431_24MkArm = heff_take_reuse_n(v_x2_2431, 7ULL, 3);
    V v_t_2435 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_b_2434}));
    return heff_tag_at_n(v_ru_24x2_2431_24MkArm, TAG_MkArm, 3, (V[]){v_t_2432, v_vs_2433, v_t_2435});
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
Clo g_heff_2ecompile_2esimplify_2eraise_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eraise_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eraise(V v_e_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_t_243 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_245 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_245, v_p_241));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
        V v_x_249 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_247), (g_heff_2ecompile_2esimplify_2estripLams(v_x_247, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_248});
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
  }
  case TAG_EGlobal: {
    V v_t_2411 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2411, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2413 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2414 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2413, v_p_241));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_MkPair: {
        V v_x_2415 = heff_field(v_x2_2414, 0);
        V v_s_2416 = heff_field(v_x2_2414, 1);
        V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
        V v_x_2417 = heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2415), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2415, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_s_2416});
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
  }
  case TAG_ELam: {
    V v_xs_2418 = heff_field(v_e_240, 0);
    V v_b_2419 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2420 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_b_2419));
    if (heff_intEq_c(v_t_2420, MK_INT(0LL))) {
      return heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_2418, v_b_2419}), v_p_241});
    } else {
      V v_t_2422 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_b_2419));
      V v_x2_2423 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2422, v_p_241));
      switch (heff_tag_of(v_x2_2423)) {
      case TAG_MkPair: {
        V v_x_2424 = heff_field(v_x2_2423, 0);
        V v_s_2425 = heff_field(v_x2_2423, 1);
        V v_ru_24x2_2423_24MkPair = heff_take_reuse_n(v_x2_2423, 3ULL, 2);
        V v_t_2426 = (g_heff_2ecompile_2esimplify_2eappendL(v_xs_2418, heff_dup(v_x_2424)));
        V v_x_2427 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2426, (g_heff_2ecompile_2esimplify_2estripLams(v_x_2424, v_b_2419))});
        return heff_tag_at_n(v_ru_24x2_2423_24MkPair, TAG_MkPair, 2, (V[]){v_x_2427, v_s_2425});
      }
      default: return heff_nomatch(v_x2_2423);
      }
    }
  }
  case TAG_EApp: {
    V v_t_2430 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2430, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2432 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2433 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2432, v_p_241));
      switch (heff_tag_of(v_x2_2433)) {
      case TAG_MkPair: {
        V v_x_2434 = heff_field(v_x2_2433, 0);
        V v_s_2435 = heff_field(v_x2_2433, 1);
        V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
        V v_x_2436 = heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2434), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2434, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2436, v_s_2435});
      }
      default: return heff_nomatch(v_x2_2433);
      }
    }
  }
  case TAG_ELet: {
    V v_t_2440 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2440, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2442 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2443 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2442, v_p_241));
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_MkPair: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_s_2445 = heff_field(v_x2_2443, 1);
        V v_ru_24x2_2443_24MkPair = heff_take_reuse_n(v_x2_2443, 3ULL, 2);
        V v_x_2446 = heff_tag_at_n(v_ru_24x2_2443_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2444), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2444, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2446, v_s_2445});
      }
      default: return heff_nomatch(v_x2_2443);
      }
    }
  }
  case TAG_ERecord: {
    V v_t_2448 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2448, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2450 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2451 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2450, v_p_241));
      switch (heff_tag_of(v_x2_2451)) {
      case TAG_MkPair: {
        V v_x_2452 = heff_field(v_x2_2451, 0);
        V v_s_2453 = heff_field(v_x2_2451, 1);
        V v_ru_24x2_2451_24MkPair = heff_take_reuse_n(v_x2_2451, 3ULL, 2);
        V v_x_2454 = heff_tag_at_n(v_ru_24x2_2451_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2452), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2452, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2454, v_s_2453});
      }
      default: return heff_nomatch(v_x2_2451);
      }
    }
  }
  case TAG_EProj: {
    V v_t_2458 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2458, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2460 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2461 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2460, v_p_241));
      switch (heff_tag_of(v_x2_2461)) {
      case TAG_MkPair: {
        V v_x_2462 = heff_field(v_x2_2461, 0);
        V v_s_2463 = heff_field(v_x2_2461, 1);
        V v_ru_24x2_2461_24MkPair = heff_take_reuse_n(v_x2_2461, 3ULL, 2);
        V v_x_2464 = heff_tag_at_n(v_ru_24x2_2461_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2462), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2462, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2464, v_s_2463});
      }
      default: return heff_nomatch(v_x2_2461);
      }
    }
  }
  case TAG_ETag: {
    V v_t_2467 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2467, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2469 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2470 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2469, v_p_241));
      switch (heff_tag_of(v_x2_2470)) {
      case TAG_MkPair: {
        V v_x_2471 = heff_field(v_x2_2470, 0);
        V v_s_2472 = heff_field(v_x2_2470, 1);
        V v_ru_24x2_2470_24MkPair = heff_take_reuse_n(v_x2_2470, 3ULL, 2);
        V v_x_2473 = heff_tag_at_n(v_ru_24x2_2470_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2471), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2471, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2473, v_s_2472});
      }
      default: return heff_nomatch(v_x2_2470);
      }
    }
  }
  case TAG_EMatch: {
    V v_t_2476 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2476, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2478 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2479 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2478, v_p_241));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_MkPair: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_s_2481 = heff_field(v_x2_2479, 1);
        V v_ru_24x2_2479_24MkPair = heff_take_reuse_n(v_x2_2479, 3ULL, 2);
        V v_x_2482 = heff_tag_at_n(v_ru_24x2_2479_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2480), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2480, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2482, v_s_2481});
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
  }
  case TAG_EPrim: {
    V v_t_2484 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2484, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2486 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2487 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2486, v_p_241));
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_MkPair: {
        V v_x_2488 = heff_field(v_x2_2487, 0);
        V v_s_2489 = heff_field(v_x2_2487, 1);
        V v_ru_24x2_2487_24MkPair = heff_take_reuse_n(v_x2_2487, 3ULL, 2);
        V v_x_2490 = heff_tag_at_n(v_ru_24x2_2487_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2488), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2488, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2490, v_s_2489});
      }
      default: return heff_nomatch(v_x2_2487);
      }
    }
  }
  case TAG_EPrimCall: {
    V v_t_2493 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_2493, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_2495 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_2496 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_2495, v_p_241));
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_MkPair: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_s_2498 = heff_field(v_x2_2496, 1);
        V v_ru_24x2_2496_24MkPair = heff_take_reuse_n(v_x2_2496, 3ULL, 2);
        V v_x_2499 = heff_tag_at_n(v_ru_24x2_2496_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_2497), (g_heff_2ecompile_2esimplify_2estripLams(v_x_2497, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2499, v_s_2498});
      }
      default: return heff_nomatch(v_x2_2496);
      }
    }
  }
  case TAG_ECall: {
    V v_t_24102 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24102, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24104 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24105 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24104, v_p_241));
      switch (heff_tag_of(v_x2_24105)) {
      case TAG_MkPair: {
        V v_x_24106 = heff_field(v_x2_24105, 0);
        V v_s_24107 = heff_field(v_x2_24105, 1);
        V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
        V v_x_24108 = heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24106), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24106, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24108, v_s_24107});
      }
      default: return heff_nomatch(v_x2_24105);
      }
    }
  }
  case TAG_EInt: {
    V v_t_24110 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24110, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24112 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24113 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24112, v_p_241));
      switch (heff_tag_of(v_x2_24113)) {
      case TAG_MkPair: {
        V v_x_24114 = heff_field(v_x2_24113, 0);
        V v_s_24115 = heff_field(v_x2_24113, 1);
        V v_ru_24x2_24113_24MkPair = heff_take_reuse_n(v_x2_24113, 3ULL, 2);
        V v_x_24116 = heff_tag_at_n(v_ru_24x2_24113_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24114), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24114, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24116, v_s_24115});
      }
      default: return heff_nomatch(v_x2_24113);
      }
    }
  }
  case TAG_EFloat: {
    V v_t_24118 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24118, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24120 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24121 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24120, v_p_241));
      switch (heff_tag_of(v_x2_24121)) {
      case TAG_MkPair: {
        V v_x_24122 = heff_field(v_x2_24121, 0);
        V v_s_24123 = heff_field(v_x2_24121, 1);
        V v_ru_24x2_24121_24MkPair = heff_take_reuse_n(v_x2_24121, 3ULL, 2);
        V v_x_24124 = heff_tag_at_n(v_ru_24x2_24121_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24122), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24122, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24124, v_s_24123});
      }
      default: return heff_nomatch(v_x2_24121);
      }
    }
  }
  case TAG_EStr: {
    V v_t_24126 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24126, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24128 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24129 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24128, v_p_241));
      switch (heff_tag_of(v_x2_24129)) {
      case TAG_MkPair: {
        V v_x_24130 = heff_field(v_x2_24129, 0);
        V v_s_24131 = heff_field(v_x2_24129, 1);
        V v_ru_24x2_24129_24MkPair = heff_take_reuse_n(v_x2_24129, 3ULL, 2);
        V v_x_24132 = heff_tag_at_n(v_ru_24x2_24129_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24130), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24130, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24132, v_s_24131});
      }
      default: return heff_nomatch(v_x2_24129);
      }
    }
  }
  case TAG_EFixed: {
    V v_t_24135 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24135, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24137 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24138 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24137, v_p_241));
      switch (heff_tag_of(v_x2_24138)) {
      case TAG_MkPair: {
        V v_x_24139 = heff_field(v_x2_24138, 0);
        V v_s_24140 = heff_field(v_x2_24138, 1);
        V v_ru_24x2_24138_24MkPair = heff_take_reuse_n(v_x2_24138, 3ULL, 2);
        V v_x_24141 = heff_tag_at_n(v_ru_24x2_24138_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24139), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24139, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24141, v_s_24140});
      }
      default: return heff_nomatch(v_x2_24138);
      }
    }
  }
  case TAG_EFloat32: {
    V v_t_24143 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24143, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24145 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24146 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24145, v_p_241));
      switch (heff_tag_of(v_x2_24146)) {
      case TAG_MkPair: {
        V v_x_24147 = heff_field(v_x2_24146, 0);
        V v_s_24148 = heff_field(v_x2_24146, 1);
        V v_ru_24x2_24146_24MkPair = heff_take_reuse_n(v_x2_24146, 3ULL, 2);
        V v_x_24149 = heff_tag_at_n(v_ru_24x2_24146_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24147), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24147, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24149, v_s_24148});
      }
      default: return heff_nomatch(v_x2_24146);
      }
    }
  }
  case TAG_EAbandon: {
    V v_t_24150 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24150, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24152 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24153 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24152, v_p_241));
      switch (heff_tag_of(v_x2_24153)) {
      case TAG_MkPair: {
        V v_x_24154 = heff_field(v_x2_24153, 0);
        V v_s_24155 = heff_field(v_x2_24153, 1);
        V v_ru_24x2_24153_24MkPair = heff_take_reuse_n(v_x2_24153, 3ULL, 2);
        V v_x_24156 = heff_tag_at_n(v_ru_24x2_24153_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24154), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24154, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24156, v_s_24155});
      }
      default: return heff_nomatch(v_x2_24153);
      }
    }
  }
  case TAG_EFix: {
    V v_t_24159 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
    if (heff_intEq_c(v_t_24159, MK_INT(0LL))) {
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_p_241});
    } else {
      V v_t_24161 = (g_heff_2ecompile_2esimplify_2elamsOut(heff_dup(heff_rfield(v_p_241, 3)), v_e_240));
      V v_x2_24162 = (g_heff_2ecompile_2esimplify_2efreshParams(v_t_24161, v_p_241));
      switch (heff_tag_of(v_x2_24162)) {
      case TAG_MkPair: {
        V v_x_24163 = heff_field(v_x2_24162, 0);
        V v_s_24164 = heff_field(v_x2_24162, 1);
        V v_ru_24x2_24162_24MkPair = heff_take_reuse_n(v_x2_24162, 3ULL, 2);
        V v_x_24165 = heff_tag_at_n(v_ru_24x2_24162_24MkPair, TAG_ELam, 2, (V[]){heff_dup(v_x_24163), (g_heff_2ecompile_2esimplify_2estripLams(v_x_24163, v_e_240))});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24165, v_s_24164});
      }
      default: return heff_nomatch(v_x2_24162);
      }
    }
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2esimplify_2eraise_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eraise(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emarkedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkedOf_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emarkedOf(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_242 = heff_field(v_x1_240, 0);
    V v_ms_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_m_242);
      heff_drop(v_ms_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_as_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      switch (heff_tag_of(v_m_242)) {
      case TAG_True: {
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, (g_heff_2ecompile_2esimplify_2emarkedOf(v_ms_243, v_as_245))});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ms_243;
        V t_1 = v_as_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_m_242);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkedOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emarkedOf(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edepthOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edepthOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2edepthOf(V v_ds_240, V v_g_241, V v_args_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_242));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_241, ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_243; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_243); r_; })});
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2esimplify_2edepthOf_lam0, 2, 1, (V[]){heff_dup(v_ds_240)}); V a_1 = MK_INT(0LL); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop_tag(v_t_244, 2); r_; });
  return heff_intAdd(MK_INT(1LL), v_t_2411);
}
V g_heff_2ecompile_2esimplify_2edepthOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2edepthOf(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2edepthOf_lam0(V self, V *args) {
  V v_d_245 = args[0];
  V v_n_246 = args[1];
  V v_ds_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_247 = ({ V a_0 = v_n_246; V a_1 = v_ds_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_ds_240); r_; });
  V v_b_249;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nothing: {
    v_b_249 = MK_INT(0LL);
    break;
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x2_247, 0);
    heff_take_n(v_x2_247, 1ULL, 1);
    v_b_249 = v_x_248;
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  if (heff_intLe_c(heff_dup(v_b_249), heff_dup(v_d_245))) {
    heff_drop(v_b_249);
    return v_d_245;
  } else {
    heff_drop(v_d_245);
    return v_b_249;
  }
}
Clo g_heff_2ecompile_2esimplify_2eownSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eownSt_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eownSt(V v_s_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 0, 7);
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 1, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 2, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 3, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 4, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_240, 7)), 6, 7);
  V v_t_247 = ({ V rv_1 = MK_INT(4000LL); V rv_6 = heff_dup(g_map_2eempty_get()); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_241, v_t_242, v_t_243, v_t_244, v_t_245, MK_INT(0LL), v_t_246}); V rr_ = heff_rec_reuse_n(v_s_240, 317ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
}
V g_heff_2ecompile_2esimplify_2eownSt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eownSt(a[0]);
}
Clo g_heff_2ecompile_2esimplify_2esetOff_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esetOff_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esetOff(V v_o_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_248 = ({ V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_o_240}); V rr_ = heff_rec_reuse_n(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2esetOff_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esetOff(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2ebackTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ebackTo_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ebackTo(V v_saved_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_saved_240, 7)), 5, 7);
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_saved_240, 7)), 6, 7);
  V v_t_249 = ({ V rv_1 = heff_take_field(v_saved_240, 1); V rv_6 = heff_get_n(v_saved_240, 6, 9); V rv_7 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248}); V rr_ = heff_rec_reuse_n(v_s_241, 317ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_249});
}
V g_heff_2ecompile_2esimplify_2ebackTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ebackTo(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2etouch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etouch_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2etouch(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_k_243 = heff_take_field(v_s_242, 8);
  V v_t_244 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_v_241, heff_take_field(v_k_243, 0)));
  V v_k_245 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_t_244, heff_take_field(v_k_243, 1), heff_dup(heff_rfield(v_k_243, 2)), heff_take_field(v_k_243, 3), heff_take_field(v_k_243, 4)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_h_240, heff_get_n(v_k_243, 2, 5)});
  V v_t_247 = ({ V rv_2 = v_t_246; V rr_ = heff_rec_reuse_n(v_k_245, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_248 = ({ V rv_8 = v_t_247; V rr_ = heff_rec_reuse_n(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 8) = rv_8; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_248});
}
V g_heff_2ecompile_2esimplify_2etouch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etouch(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2eversAll_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2eversAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eversAll_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eversAll(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_v_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_v_243), ((V)&g_heff_2ecompile_2esimplify_2eversAll_str0))) {
        heff_drop(v_rest_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_v_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      } else {
        V v_x2_245 = (g_heff_2ecompile_2esimplify_2eversAll(v_rest_242));
        switch (heff_tag_of(v_x2_245)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_241_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_vs_246 = heff_field(v_x2_245, 0);
          heff_take_n(v_x2_245, 1ULL, 1);
          return heff_tag_at_n(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_v_243, v_vs_246})});
        }
        default: return heff_nomatch(v_x2_245);
        }
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eversAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eversAll(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyVer_str1, 1, "-");
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopyVer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyVer_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecopyVer(V v_vers_240, V v_h_241, V v_g_242, V v_args_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_243));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_242, ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1347985788x1836008258(a_0, a_1)); heff_drop(v_t_244); r_; })});
  V v_t_247 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopyVer_lam0, 1, 1, (V[]){heff_dup(v_vers_240)}), v_t_245));
  V v_x2_248 = (g_heff_2ecompile_2esimplify_2eversAll(v_t_247));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    heff_drop(v_h_241);
    return ((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str0);
  }
  case TAG_Just: {
    V v_vs_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Just = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    V v_items_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_248_24Just, TAG_HS, 1, (V[]){v_h_241}), (g_list_2emap_24s1123370502x1982532655(v_vs_249))});
    V v_t_2411 = (g_heff_2ecompile_2eirtext_2ehashW(MK_INT(5381LL), MK_INT(7919LL), v_items_2410));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_MkPair: {
      V v_a_2412 = heff_field(v_t_2411, 0);
      V v_b_2413 = heff_field(v_t_2411, 1);
      heff_take_n(v_t_2411, 3ULL, 2);
      return heff_strAppend(heff_intShow(v_a_2412), heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2ecopyVer_str1), heff_intShow(v_b_2413)));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2ecopyVer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2ecopyVer(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2esimplify_2ecopyVer_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_vers_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_k_246; V a_1 = v_vers_240; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_vers_240); r_; });
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ekeptAt_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ekeptAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeptAt_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ekeptAt(V v_s_240, V v_h_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_240, 8)), 0, 5);
  V v_t_243 = ({ V a_0 = heff_dup(v_h_241); V a_1 = v_t_242; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_242); r_; });
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_s_240, 9);
    heff_drop(v_h_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_245 = heff_get_n(heff_get_n(v_s_240, 8, 9), 1, 5);
    V v_x2_246 = ({ V a_0 = v_h_241; V a_1 = v_t_245; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_245); r_; });
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nothing: {
      heff_drop(v_v_244);
      heff_drop_cell(v_ru_24t_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_kc_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_kc_247, 0)), heff_dup(v_v_244))) {
        if (heff_strEq_c(v_v_244, ((V)&g_heff_2ecompile_2esimplify_2ekeptAt_str0))) {
          heff_drop_cell(v_ru_24t_243_24Just, 1);
          heff_drop_rec(v_kc_247, 5);
          return NTAG(TAG_Nothing);
        } else {
          return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_kc_247});
        }
      } else {
        heff_drop(v_v_244);
        heff_drop_cell(v_ru_24t_243_24Just, 1);
        heff_drop_rec(v_kc_247, 5);
        return NTAG(TAG_Nothing);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2esimplify_2ekeptAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeptAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emarkSafeAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emarkSafeAs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emarkSafeAs(V v_x1_240, V v_h_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_True: {
    V v_t_243 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_241), NTAG(TAG_MkUnit), heff_take_field(v_p_242, 4)));
    V v_s_244 = ({ V rv_4 = v_t_243; V rr_ = heff_rec_reuse_n(v_p_242, 495ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 4) = rv_4; rr_; });
    V v_t_245 = (g_map_2einsert_24s1341440536x470972936(v_h_241, NTAG(TAG_MkUnit), heff_take_field(v_s_244, 3)));
    V v_t_246 = ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_n(v_s_244, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_246});
  }
  case TAG_False: {
    heff_drop(v_h_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emarkSafeAs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2emarkSafeAs(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2easkKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2easkKept_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2easkKept(V v_h_240, V v_kc_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_h_240);
    heff_drop_rec(v_kc_241, 5);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_p_243});
  }
  case TAG_Just: {
    V v_b_244 = heff_field(v_x3_242, 0);
    V v_x2_245 = (g_heff_2ecompile_2esimplify_2ecopy(heff_dup(v_b_244), v_p_243));
    switch (heff_tag_of(v_x2_245)) {
    case TAG_MkPair: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_s_247 = heff_field(v_x2_245, 1);
      V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_240), v_x_246, heff_take_field(v_kc_241, 2), v_s_247));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_s_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 2ULL, 2);
        V v_x2_2411 = ({ V b_0 = heff_get_n(v_kc_241, 3, 5); V a_1 = v_h_240; V a_2 = v_s_2410; V r_ = (g_heff_2ecompile_2esimplify_2emarkSafeAs(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_MkPair: {
          V v_s_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 2ULL, 2);
          return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_2413});
        }
        default: return heff_nomatch(v_x2_2411);
        }
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_x2_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2easkKept_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2esimplify_2easkKept(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2esimplify_2ekeptAsk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ekeptAsk_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ekeptAsk(V v_h_240, V v_v_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_x3_244 = ({ V a_0 = heff_dup(v_h_240); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_h_240);
    heff_drop(v_v_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
  }
  case TAG_False: {
    V v_k_247 = heff_take_field(v_s_242, 8);
    V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_240), v_v_241, heff_take_field(v_k_247, 0)));
    V v_k_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_n(v_k_247, 30ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2410 = ({ V rv_8 = v_k_249; V rr_ = heff_rec_reuse_n(v_s_242, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_x2_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2410});
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_s_2413 = heff_field(v_x2_2411, 1);
      V v_ru_24x2_2411_24MkPair = heff_take_reuse_n(v_x2_2411, 2ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_2413), heff_dup(v_h_240)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop(v_h_240);
        return heff_tag_at_n(v_ru_24x2_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2413});
      }
      case TAG_Just: {
        V v_kc_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2411_24MkPair, 2);
        V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2415, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        return ({ V a_0 = v_h_240; V a_1 = v_kc_2415; V a_2 = v_t_2416; V a_3 = v_s_2413; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2416); r_; });
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2ecompile_2esimplify_2ekeptAsk_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ekeptAsk(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eallAsked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eallAsked_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eallAsked(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_p_241});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_h_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      V v_x2_246 = (g_heff_2ecompile_2esimplify_2ekeptAsk(v_h_244, v_v_245, v_p_241));
      switch (heff_tag_of(v_x2_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x2_246, 0);
        V v_s_248 = heff_field(v_x2_246, 1);
        heff_take_n(v_x2_246, 3ULL, 2);
        switch (heff_tag_of(v_x_247)) {
        case TAG_True: {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          V t_0 = v_rest_243;
          V t_1 = v_s_248;
          v_x1_240 = t_0;
          v_p_241 = t_1;
          goto top;
        }
        case TAG_False: {
          heff_drop(v_rest_243);
          return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_248});
        }
        default: return heff_nomatch(v_x_247);
        }
      }
      default: return heff_nomatch(v_x2_246);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eallAsked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eallAsked(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emadeKept_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeKept_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeKept(V v_km_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_km_240, 2);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eallAsked(heff_get_n(v_km_240, 1, 2), v_p_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x_245)) {
      case TAG_True: {
        V v_x2_247 = (g_heff_2ecompile_2esimplify_2ecopy(v_b_243, v_s_246));
        switch (heff_tag_of(v_x2_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_s_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
        }
        default: return heff_nomatch(v_x2_247);
        }
      }
      case TAG_False: {
        heff_drop(v_b_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      }
      default: return heff_nomatch(v_x_245);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2emadeKept_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeKept(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eknowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknowing_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknowing(V v_r_240, V v_b0_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2esimplify_2eownSt(heff_dup(v_s_242)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_MkPair: {
    V v_s_245 = heff_field(v_t_243, 1);
    V v_ru_24t_243_24MkPair = heff_take_reuse_n(v_t_243, 2ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2esetOff(NTAG(TAG_True), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 2ULL, 2);
      V v_m_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_b0_241}));
      V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_MkPair: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_s_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_x_2411}));
        V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_s_2412}));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2415, v_s_2416));
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_MkPair: {
            V v_x_2418 = heff_field(v_x2_2417, 0);
            V v_s_2419 = heff_field(v_x2_2417, 1);
            heff_take_n(v_x2_2417, 3ULL, 2);
            V v_t_2420 = (g_heff_2ecompile_2esimplify_2ebackTo(v_s_242, v_s_2419));
            switch (heff_tag_of(v_t_2420)) {
            case TAG_MkPair: {
              V v_s_2422 = heff_field(v_t_2420, 1);
              heff_take_n(v_t_2420, 2ULL, 2);
              return heff_tag_at_n(v_ru_24t_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_2418, v_s_2422});
            }
            default: return heff_nomatch(v_t_2420);
            }
          }
          default: return heff_nomatch(v_x2_2417);
          }
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_2410);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2esimplify_2eknowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknowing(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eask_entry, 9, 0};

V g_heff_2ecompile_2esimplify_2eask(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_marks_244, V v_sh_245, V v_h_246, V v_d_247, V v_s_248) {
top: ;
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_248, 8)), 0, 5);
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_244), heff_dup(heff_rfield(v_sh_245, 0))));
  V v_t_2411 = ({ V a_0 = v_t_249; V a_1 = heff_dup(v_h_246); V a_2 = heff_dup(v_g_241); V a_3 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2ecopyVer(a_0, a_1, a_2, a_3)); heff_drop(v_t_249); r_; });
  V v_x2_2412 = (g_heff_2ecompile_2esimplify_2etouch(heff_dup(v_h_246), v_t_2411, heff_dup(v_s_248)));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_MkPair: {
    V v_s_2414 = heff_field(v_x2_2412, 1);
    V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 2ULL, 2);
    V v_t_2415 = heff_get_n(heff_get_n(v_s_248, 7, 9), 2, 7);
    V v_x3_2416 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x3_2416)) {
    case TAG_Nothing: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2416, 0ULL, 1);
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2416);
    }
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      heff_drop(v_r_240);
      heff_drop(v_g_241);
      heff_drop(v_xs_242);
      heff_drop(v_b_243);
      heff_drop(v_marks_244);
      heff_drop_rec(v_sh_245, 3);
      heff_drop(v_h_246);
      heff_drop(v_d_247);
      return heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2414});
    }
    case TAG_False: {
      V v_t_2419 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_2414), heff_dup(v_h_246)));
      V v_x2_2422;
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        v_x2_2422 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2414});
        break;
      }
      case TAG_Just: {
        V v_kc_2420 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_2412_24MkPair, 2);
        V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_kc_2420, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_x2_2422 = ({ V a_0 = heff_dup(v_h_246); V a_1 = v_kc_2420; V a_2 = v_t_2421; V a_3 = v_s_2414; V r_ = (g_heff_2ecompile_2esimplify_2easkKept(a_0, a_1, a_2, a_3)); heff_drop(v_t_2421); r_; });
        break;
      }
      default: heff_nomatch(v_t_2419);
      }
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
        switch (heff_tag_of(v_x_2423)) {
        case TAG_True: {
          heff_drop(v_r_240);
          heff_drop(v_g_241);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_244);
          heff_drop_rec(v_sh_245, 3);
          heff_drop(v_h_246);
          heff_drop(v_d_247);
          return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_s_2424});
        }
        case TAG_False: {
          V v_x2_2425 = (g_heff_2ecompile_2esimplify_2ecopy(heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_ELam, 2, (V[]){v_xs_242, v_b_243}), v_s_2424));
          switch (heff_tag_of(v_x2_2425)) {
          case TAG_MkPair: {
            V v_x_2426 = heff_field(v_x2_2425, 0);
            V v_s_2427 = heff_field(v_x2_2425, 1);
            V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
            V v_m_2428 = (g_heff_2ecompile_2esimplify_2especBody(v_g_241, heff_dup(v_h_246), v_marks_244, v_sh_245, v_x_2426));
            V v_x2_2429 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_s_2427}));
            switch (heff_tag_of(v_x2_2429)) {
            case TAG_MkPair: {
              V v_x_2430 = heff_field(v_x2_2429, 0);
              V v_s_2431 = heff_field(v_x2_2429, 1);
              heff_take_n(v_x2_2429, 3ULL, 2);
              V v_x2_2432 = (g_heff_2ecompile_2esimplify_2eknowing(v_r_240, v_x_2430, v_s_2431));
              switch (heff_tag_of(v_x2_2432)) {
              case TAG_MkPair: {
                V v_x_2433 = heff_field(v_x2_2432, 0);
                V v_s_2434 = heff_field(v_x2_2432, 1);
                heff_take_n(v_x2_2432, 3ULL, 2);
                V v_x2_2435 = (g_heff_2ecompile_2esimplify_2easkedFor(heff_dup(v_h_246), heff_dup(v_x_2433), v_d_247, v_s_2434));
                switch (heff_tag_of(v_x2_2435)) {
                case TAG_MkPair: {
                  V v_s_2437 = heff_field(v_x2_2435, 1);
                  heff_take_n(v_x2_2435, 2ULL, 2);
                  V v_k_2438 = heff_take_field(v_s_2437, 8);
                  V v_t_2439 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_h_246), NTAG(TAG_MkUnit), heff_take_field(v_k_2438, 3)));
                  V v_k_2440 = ({ V rv_3 = v_t_2439; V rr_ = heff_rec_reuse_n(v_k_2438, 23ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 3) = rv_3; rr_; });
                  V v_t_2441 = ({ V rv_8 = v_k_2440; V rr_ = heff_rec_reuse_n(v_s_2437, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 8) = rv_8; rr_; });
                  V v_x2_2442 = heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2441});
                  switch (heff_tag_of(v_x2_2442)) {
                  case TAG_MkPair: {
                    V v_s_2444 = heff_field(v_x2_2442, 1);
                    heff_take_n(v_x2_2442, 2ULL, 2);
                    return ({ V a_0 = v_h_246; V a_1 = v_x_2433; V a_2 = v_s_2444; V r_ = (g_heff_2ecompile_2esimplify_2emarkCopySafe(a_0, a_1, a_2)); heff_drop(v_x_2433); r_; });
                  }
                  default: return heff_nomatch(v_x2_2442);
                  }
                }
                default: return heff_nomatch(v_x2_2435);
                }
              }
              default: return heff_nomatch(v_x2_2432);
              }
            }
            default: return heff_nomatch(v_x2_2429);
            }
          }
          default: return heff_nomatch(v_x2_2425);
          }
        }
        default: return heff_nomatch(v_x_2423);
        }
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2esimplify_2eask_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eask(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_heff_2ecompile_2esimplify_2especNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especNamed_entry, 10, 0};

V g_heff_2ecompile_2esimplify_2especNamed(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_h_247, V v_d_248, V v_z_249) {
top: ;
  if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especDepth_get()), heff_dup(v_d_248))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    heff_drop(v_h_247);
    heff_drop(v_d_248);
    V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_z_249});
  } else {
    V v_x2_2412 = (g_heff_2ecompile_2esimplify_2eask(heff_dup(v_r_240), v_g_241, v_xs_242, v_b_243, heff_dup(v_marks_245), heff_dup(v_sh_246), heff_dup(v_h_247), v_d_248, v_z_249));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 2ULL, 2);
      V v_t_2415 = (g_heff_2ecompile_2espec_2edropAt(v_marks_245, v_as_244));
      V v_t_2416 = (g_heff_2ecompile_2esimplify_2eappendL(heff_get_n(v_sh_246, 2, 3), v_t_2415));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 3, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_h_247}), v_t_2416, v_s_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
}
V g_heff_2ecompile_2esimplify_2especNamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especNamed(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str5, 2, "$s");
HEFF_LIT(g_heff_2ecompile_2esimplify_2especShaped_str6, 2, "$s");
Clo g_heff_2ecompile_2esimplify_2especShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especShaped_entry, 8, 0};

V g_heff_2ecompile_2esimplify_2especShaped(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_sh_246, V v_s_247) {
top: ;
  V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nil: {
    V v_t_249 = heff_dup(heff_rfield(v_sh_246, 1));
    V v_x1_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_x1_2412 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_t_249, 0ULL, 2);
      v_x1_2412 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_True: {
      v_t_2415 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2415 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2412);
    }
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_248, 0ULL, 2);
    v_t_2415 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    heff_drop_rec(v_sh_246, 3);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_s_247});
  }
  case TAG_False: {
    V v_t_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_marks_245));
    V v_t_2418 = (g_heff_2ecompile_2esimplify_2etakeL(v_t_2417, heff_dup(heff_rfield(v_sh_246, 0))));
    V v_x2_2419 = (g_list_2ezipWith_24s237481877x1031762735(((V)&g_heff_2ecompile_2esimplify_2especShaped_str0), heff_dup(v_marks_245), v_t_2418));
    V v_t_2422;
    switch (heff_tag_of(v_x2_2419)) {
    case TAG_Nil: {
      v_t_2422 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_2420 = heff_field(v_x2_2419, 0);
      V v_xs_2421 = heff_field(v_x2_2419, 1);
      heff_take_n(v_x2_2419, 3ULL, 2);
      v_t_2422 = ({ V a_0 = ((V)&g_heff_2ecompile_2esimplify_2especShaped_str2); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2419);
    }
    V v_k_2423 = heff_strAppend(heff_dup(v_g_241), heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str3), heff_strAppend(v_t_2422, ((V)&g_heff_2ecompile_2esimplify_2especShaped_str4))));
    V v_x2_2424 = (g_prelude_2eindexFrom(((V)&g_heff_2ecompile_2esimplify_2especShaped_str5), heff_dup(v_g_241), MK_INT(0LL)));
    V v_t_2426;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      v_t_2426 = heff_dup(v_g_241);
      break;
    }
    case TAG_Just: {
      V v_i_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_t_2426 = heff_strSlice(heff_dup(v_g_241), MK_INT(0LL), v_i_2425);
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ecompile_2esimplify_2especShaped_str6), (g_heff_2ecompile_2espec_2ehashGo(v_k_2423, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)))));
    V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_s_247, 7)), 3, 7);
    V v_t_2429 = (g_heff_2ecompile_2esimplify_2emarkedOf(heff_dup(v_marks_245), heff_dup(heff_rfield(v_sh_246, 0))));
    V v_t_2430 = ({ V a_0 = v_t_2428; V a_1 = heff_dup(v_g_241); V a_2 = v_t_2429; V r_ = (g_heff_2ecompile_2esimplify_2edepthOf(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
    return (g_heff_2ecompile_2esimplify_2especNamed(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_sh_246, v_t_2427, v_t_2430, v_s_247));
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2ecompile_2esimplify_2especShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especShaped(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2esimplify_2especMarked_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especMarked_entry, 7, 0};

V g_heff_2ecompile_2esimplify_2especMarked(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_marks_245, V v_z_246) {
top: ;
  V v_x1_247 = (g_list_2eany_24s228396297x1310020012(v_marks_245));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_True: {
    V v_x1_248 = (g_heff_2ecompile_2esimplify_2ekeepParams(heff_dup(v_marks_245), heff_dup(v_xs_242)));
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Nil: {
      V v_t_249 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
      V v_t_2410 = (g_heff_2ecompile_2eir_2enubI(v_t_249));
      V v_t_2411 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        V v_x1_2412 = (g_heff_2ecompile_2eir_2eisValue(v_b_243));
        switch (heff_tag_of(v_x1_2412)) {
        case TAG_True: {
          V v_x2_2413 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
          switch (heff_tag_of(v_x2_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x2_2413, 0);
            V v_s_2415 = heff_field(v_x2_2413, 1);
            heff_take_n(v_x2_2413, 3ULL, 2);
            return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2414, v_s_2415));
          }
          default: return heff_nomatch(v_x2_2413);
          }
        }
        case TAG_False: {
          heff_drop(v_r_240);
          heff_drop(v_xs_242);
          heff_drop(v_b_243);
          heff_drop(v_marks_245);
          V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2416, v_z_246});
        }
        default: return heff_nomatch(v_x1_2412);
        }
      }
      case TAG_False: {
        V v_x2_2417 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2418, v_s_2419));
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_x1_248, 0ULL, 2);
      V v_x2_2422 = (g_heff_2ecompile_2esimplify_2eshapesOf(heff_dup(v_marks_245), heff_dup(v_as_244), v_z_246));
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_s_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        return (g_heff_2ecompile_2esimplify_2especShaped(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_marks_245, v_x_2423, v_s_2424));
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  case TAG_False: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    heff_drop(v_marks_245);
    V v_x_2425 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2425, v_z_246});
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2ecompile_2esimplify_2especMarked_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especMarked(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2esimplify_2especLam_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2especLam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2especLam_entry, 6, 0};

V g_heff_2ecompile_2esimplify_2especLam(V v_r_240, V v_g_241, V v_xs_242, V v_b_243, V v_as_244, V v_s_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 6, 7);
  V v_t_2412;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_2412 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 5, 7);
    if (heff_intLe_c(heff_dup(g_heff_2ecompile_2esimplify_2especLimit_get()), v_t_247)) {
      v_t_2412 = NTAG(TAG_True);
    } else {
      V v_x1_2411 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2esimplify_2especLam_lam0, 1, 1, (V[]){heff_dup(v_s_245)}), v_as_244));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_True: {
        v_t_2412 = NTAG(TAG_False);
        break;
      }
      case TAG_False: {
        v_t_2412 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x1_2411);
      }
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_2412)) {
  case TAG_True: {
    heff_drop(v_r_240);
    heff_drop(v_xs_242);
    heff_drop(v_b_243);
    V v_x_2413 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_244));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2413, v_s_245});
  }
  case TAG_False: {
    V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_s_245, 7)), 1, 7);
    V v_t_2415 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_243)));
    V v_t_2416 = (g_heff_2ecompile_2eir_2enubI(v_t_2415));
    V v_t_2417 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_2416); r_; });
    V v_t_2419;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_241), heff_dup(v_b_243)));
      v_t_2419 = ({ V a_0 = v_t_2418; V a_1 = heff_dup(v_xs_242); V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2estaticGo(a_0, a_1, a_2)); heff_drop(v_t_2418); r_; });
      break;
    }
    case TAG_False: {
      v_t_2419 = (g_list_2emap_24s73473062x206541869(heff_dup(v_xs_242)));
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2420 = ({ V a_0 = v_t_2414; V a_1 = v_as_244; V a_2 = v_t_2419; V a_3 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2esimplify_2emarkGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
    return (g_heff_2ecompile_2esimplify_2especMarked(v_r_240, v_g_241, v_xs_242, v_b_243, v_as_244, v_t_2420, v_s_245));
  }
  default: return heff_nomatch(v_t_2412);
  }
}
V g_heff_2ecompile_2esimplify_2especLam_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2especLam(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ecompile_2esimplify_2especLam_lam0(V self, V *args) {
  V v_a_249 = args[0];
  V v_s_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get_n(heff_get_n(v_s_245, 7, 9), 1, 7);
  return ({ V a_0 = v_t_2410; V a_1 = v_a_249; V r_ = (g_heff_2ecompile_2esimplify_2eknownArg(a_0, a_1)); heff_drop(v_t_2410); r_; });
}
Clo g_heff_2ecompile_2esimplify_2etrySpec_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etrySpec_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2etrySpec(V v_r_240, V v_g_241, V v_as_242, V v_s_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_243, 7)), 0, 7);
  V v_it_245 = ({ V a_0 = heff_dup(v_g_241); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_244); r_; });
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_r_240);
    V v_x_246 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_n(TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_s_243});
  }
  case TAG_Just: {
    V v_it1_247 = heff_field(v_it_245, 0);
    V v_ru_24it_245_24Just = heff_take_reuse_n(v_it_245, 1ULL, 1);
    switch (heff_tag_of(v_it1_247)) {
    case TAG_EVar: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_249 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_s_243});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2411 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2411, v_s_243});
    }
    case TAG_ELam: {
      V v_xs_2412 = heff_field(v_it1_247, 0);
      V v_b_2413 = heff_field(v_it1_247, 1);
      heff_take_n(v_it1_247, 3ULL, 2);
      heff_drop_cell(v_ru_24it_245_24Just, 1);
      return (g_heff_2ecompile_2esimplify_2especLam(v_r_240, v_g_241, v_xs_2412, v_b_2413, v_as_242, v_s_243));
    }
    case TAG_EApp: {
      V v_ru_24it1_247_24EApp = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2416 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EApp, TAG_MkPair, 2, (V[]){v_x_2416, v_s_243});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2420 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2420, v_s_243});
    }
    case TAG_ERecord: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2422 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2422, v_s_243});
    }
    case TAG_EProj: {
      heff_take_n(v_it1_247, 0ULL, 3);
      heff_drop(v_r_240);
      V v_x_2426 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2426, v_s_243});
    }
    case TAG_ETag: {
      V v_ru_24it1_247_24ETag = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2429 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ETag, TAG_MkPair, 2, (V[]){v_x_2429, v_s_243});
    }
    case TAG_EMatch: {
      V v_ru_24it1_247_24EMatch = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2432 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EMatch, TAG_MkPair, 2, (V[]){v_x_2432, v_s_243});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2434 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_s_243});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_247_24EPrimCall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2437 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EPrimCall, TAG_MkPair, 2, (V[]){v_x_2437, v_s_243});
    }
    case TAG_ECall: {
      V v_ru_24it1_247_24ECall = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2440 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24ECall, TAG_MkPair, 2, (V[]){v_x_2440, v_s_243});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2442 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2442, v_s_243});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2444 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_s_243});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2446 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2446, v_s_243});
    }
    case TAG_EFixed: {
      V v_ru_24it1_247_24EFixed = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2449 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFixed, TAG_MkPair, 2, (V[]){v_x_2449, v_s_243});
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_247, 0ULL, 1);
      heff_drop(v_r_240);
      V v_x_2451 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_s_243});
    }
    case TAG_EAbandon: {
      heff_drop(v_r_240);
      V v_x_2452 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2452, v_s_243});
    }
    case TAG_EFix: {
      V v_ru_24it1_247_24EFix = heff_take_reuse_n(v_it1_247, 0ULL, 2);
      heff_drop(v_r_240);
      V v_x_2455 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24it_245_24Just, TAG_EGlobal, 1, (V[]){v_g_241}), v_as_242));
      return heff_tag_at_n(v_ru_24it1_247_24EFix, TAG_MkPair, 2, (V[]){v_x_2455, v_s_243});
    }
    default: return heff_nomatch(v_it1_247);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2ecompile_2esimplify_2etrySpec_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etrySpec(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2esimplify_2estillCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2estillCall_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2estillCall(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    V v_x21_246 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_EVar: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x21_246, 0);
      return heff_strEq(v_g_240, heff_dup(v_h_249));
    }
    case TAG_ELam: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_g_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2estillCall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2estillCall(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2efieldIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efieldIn_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efieldIn(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_l_240))) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efieldIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efieldIn(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2eknownField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eknownField_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eknownField(V v_g_240, V v_l_241, V v_s_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  V v_it_244 = ({ V a_0 = v_g_240; V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_l_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
  }
  case TAG_Just: {
    V v_it1_245 = heff_field(v_it_244, 0);
    V v_ru_24it_244_24Just = heff_take_reuse_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_245)) {
    case TAG_EVar: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EGlobal: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELam: {
      V v_ru_24it1_245_24ELam = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EApp: {
      V v_ru_24it1_245_24EApp = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EApp, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ELet: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ERecord: {
      V v_fs_2415 = heff_field(v_it1_245, 0);
      heff_take_n(v_it1_245, 1ULL, 1);
      V v_t_2416 = ({ V a_0 = v_l_241; V a_1 = v_fs_2415; V r_ = (g_heff_2ecompile_2esimplify_2efieldIn(a_0, a_1)); heff_drop(v_fs_2415); r_; });
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24it_244_24Just, 1);
        return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
      }
      case TAG_Just: {
        V v_v_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        V v_t_2418 = (g_heff_2ecompile_2eir_2eisValue(v_v_2417));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_s_242, 1)))) {
            V v_t_2420 = heff_intSub(heff_take_field(v_s_242, 1), MK_INT(1LL));
            V v_t_2421 = ({ V rv_1 = v_t_2420; V rr_ = heff_rec_reuse_n(v_s_242, 509ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_x2_2422 = (g_heff_2ecompile_2esimplify_2ecopy(v_v_2417, v_t_2421));
            switch (heff_tag_of(v_x2_2422)) {
            case TAG_MkPair: {
              V v_x_2423 = heff_field(v_x2_2422, 0);
              V v_s_2424 = heff_field(v_x2_2422, 1);
              V v_ru_24x2_2422_24MkPair = heff_take_reuse_n(v_x2_2422, 3ULL, 2);
              return heff_tag_at_n(v_ru_24x2_2422_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it_244_24Just, TAG_Just, 1, (V[]){v_x_2423}), v_s_2424});
            }
            default: return heff_nomatch(v_x2_2422);
            }
          } else {
            heff_drop_cell(v_ru_24it_244_24Just, 1);
            heff_drop(v_v_2417);
            return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
          }
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24it_244_24Just, 1);
          heff_drop(v_v_2417);
          return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    case TAG_EProj: {
      heff_take_n(v_it1_245, 0ULL, 3);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ETag: {
      V v_ru_24it1_245_24ETag = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ETag, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EMatch: {
      V v_ru_24it1_245_24EMatch = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EMatch, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrim: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EPrimCall: {
      V v_ru_24it1_245_24EPrimCall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EPrimCall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_ECall: {
      V v_ru_24it1_245_24ECall = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24ECall, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EStr: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFixed: {
      V v_ru_24it1_245_24EFixed = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EFixed, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFloat32: {
      heff_take_n(v_it1_245, 0ULL, 1);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EAbandon: {
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    case TAG_EFix: {
      V v_ru_24it1_245_24EFix = heff_take_reuse_n(v_it1_245, 0ULL, 2);
      heff_drop(v_l_241);
      heff_drop_cell(v_ru_24it_244_24Just, 1);
      return heff_tag_at_n(v_ru_24it1_245_24EFix, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_242});
    }
    default: return heff_nomatch(v_it1_245);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2ecompile_2esimplify_2eknownField_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eknownField(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2epushable_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushable_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2epushable(V v_a_240) {
top: ;
  V v_t_2431;
  switch (heff_tag_of(v_a_240)) {
  case TAG_EVar: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EGlobal: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_ELam: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EApp: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EProj: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EPrimCall: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EStr: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EFixed: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EFloat32: {
    v_t_2431 = NTAG(TAG_True);
    break;
  }
  case TAG_EAbandon: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    v_t_2431 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_a_240);
  }
  switch (heff_tag_of(v_t_2431)) {
  case TAG_True: {
    heff_drop(v_a_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_2432 = (g_heff_2ecompile_2eir_2eisValue(v_a_240));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eclosedKnown(v_a_240);
    }
    case TAG_False: {
      heff_drop(v_a_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_t_2431);
  }
}
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushable(a[0]);
}

static V g_heff_2ecompile_2esimplify_2epushBudget_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2epushBudget_st;
static V g_heff_2ecompile_2esimplify_2epushBudget_init(void) {
  return MK_INT(120LL);
}
V g_heff_2ecompile_2esimplify_2epushBudget_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2epushBudget_st)) return g_heff_2ecompile_2esimplify_2epushBudget_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2epushBudget_val, &g_heff_2ecompile_2esimplify_2epushBudget_st, g_heff_2ecompile_2esimplify_2epushBudget_init);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_2434;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      v_t_2434 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2434 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_m_2436;
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      v_m_2436 = heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam1, 1, 1, (V[]){v_x_242});
      break;
    }
    case TAG_False: {
      v_m_2436 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2ecopy_clo), 1, (V[]){v_x_242}));
      break;
    }
    default: heff_nomatch(v_t_2434);
    }
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam2, 1, 2, (V[]){v_m_2436, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817(a[0]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam1(V self, V *args) {
  V v_a_2435 = args[0];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_a_2435});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817_lam2(V self, V *args) {
  V v_s_2437 = args[0];
  V v_m_2436 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2438 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2437}));
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_x_2439 = heff_field(v_x2_2438, 0);
    V v_s_2440 = heff_field(v_x2_2438, 1);
    V v_ru_24x2_2438_24MkPair = heff_take_reuse_n(v_x2_2438, 3ULL, 2);
    V v_m_2441 = (g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817(v_xs_243));
    V v_x2_2442 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_s_2440}));
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_MkPair: {
      V v_x_2443 = heff_field(v_x2_2442, 0);
      V v_s_2444 = heff_field(v_x2_2442, 1);
      heff_take_n(v_x2_2442, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2439, v_x_2443}), v_s_2444});
    }
    default: return heff_nomatch(v_x2_2442);
    }
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args);
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eapplyToF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eapplyToF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2eapplyToF(V v_r_240, V v_f_241, V v_as_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
  if (heff_intEq_c(v_t_243, MK_INT(0LL))) {
    heff_drop_rec(v_r_240, 4);
    heff_drop(v_as_242);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam0, 1, 1, (V[]){v_f_241});
  } else {
    switch (heff_tag_of(v_f_241)) {
    case TAG_EVar: {
      heff_drop_rec(v_r_240, 4);
      V v_x_247 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam1, 1, 1, (V[]){v_x_247});
    }
    case TAG_EGlobal: {
      V v_g_249 = heff_dup(heff_field(v_f_241, 0));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam2, 1, 4, (V[]){v_g_249, v_r_240, v_f_241, v_as_242});
    }
    case TAG_ELam: {
      V v_xs_2417 = heff_field(v_f_241, 0);
      V v_it2_2418 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24ELam = heff_take_reuse_n(v_f_241, 3ULL, 2);
      switch (heff_tag_of(v_it2_2418)) {
      case TAG_EVar: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EGlobal: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELam: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EApp: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ELet: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ERecord: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EProj: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ETag: {
        V v_t_2432 = heff_field(v_it2_2418, 0);
        V v_es_2433 = heff_field(v_it2_2418, 1);
        heff_take_n(v_it2_2418, 3ULL, 2);
        V v_t_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
        V v_t_2435 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
        if (heff_intEq_c(v_t_2434, v_t_2435)) {
          V v_t_2437 = (g_heff_2ecompile_2esimplify_2evarsAre(v_xs_2417, v_es_2433));
          switch (heff_tag_of(v_t_2437)) {
          case TAG_True: {
            heff_drop_rec(v_r_240, 4);
            heff_drop(v_xs_2417);
            heff_drop_cell(v_ru_24f_241_24ELam, 2);
            heff_drop(v_es_2433);
            return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam3, 1, 2, (V[]){v_t_2432, v_as_242});
          }
          case TAG_False: {
            return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at_n(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2432, v_es_2433}), v_as_242));
          }
          default: return heff_nomatch(v_t_2437);
          }
        } else {
          return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, heff_tag_at_n(v_ru_24f_241_24ELam, TAG_ETag, 2, (V[]){v_t_2432, v_es_2433}), v_as_242));
        }
      }
      case TAG_EMatch: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrim: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EPrimCall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_ECall: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EInt: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EStr: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFixed: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFloat32: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      case TAG_EFix: {
        heff_drop_cell(v_ru_24f_241_24ELam, 2);
        return (g_heff_2ecompile_2esimplify_2eapplyLam(v_r_240, v_xs_2417, v_it2_2418, v_as_242));
      }
      default: return heff_nomatch(v_it2_2418);
      }
    }
    case TAG_EApp: {
      V v_g_2454 = heff_field(v_f_241, 0);
      V v_bs_2455 = heff_field(v_f_241, 1);
      heff_take_n(v_f_241, 3ULL, 2);
      V v_t_2456 = (g_heff_2ecompile_2esimplify_2eappendL(v_bs_2455, v_as_242));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_g_2454, v_t_2456});
    }
    case TAG_ELet: {
      V v_x_2457 = heff_field(v_f_241, 0);
      V v_a_2458 = heff_field(v_f_241, 1);
      V v_b_2459 = heff_field(v_f_241, 2);
      heff_take_n(v_f_241, 7ULL, 3);
      V v_m_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2459, v_as_242}));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam4, 1, 3, (V[]){v_m_2460, v_x_2457, v_a_2458});
    }
    case TAG_ERecord: {
      heff_drop_rec(v_r_240, 4);
      V v_x_2466 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam5, 1, 1, (V[]){v_x_2466});
    }
    case TAG_EProj: {
      V v_it1_2468 = heff_dup(heff_field(v_f_241, 0));
      V v_l_2469 = heff_dup(heff_field(v_f_241, 1));
      V v_sh_2470 = heff_dup(heff_field(v_f_241, 2));
      switch (heff_tag_of(v_it1_2468)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_2472 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam6, 1, 1, (V[]){v_x_2472});
      }
      case TAG_EGlobal: {
        V v_g_2474 = heff_field(v_it1_2468, 0);
        heff_take_n(v_it1_2468, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam7, 1, 6, (V[]){v_g_2474, v_l_2469, v_f_241, v_as_242, v_r_240, v_sh_2470});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_2495 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam9, 1, 1, (V[]){v_x_2495});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_2499 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam10, 1, 1, (V[]){v_x_2499});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2468, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24104 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam11, 1, 1, (V[]){v_x_24104});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24107 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam12, 1, 1, (V[]){v_x_24107});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2468, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24112 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam13, 1, 1, (V[]){v_x_24112});
      }
      case TAG_ETag: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24116 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam14, 1, 1, (V[]){v_x_24116});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24120 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam15, 1, 1, (V[]){v_x_24120});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24123 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam16, 1, 1, (V[]){v_x_24123});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24127 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam17, 1, 1, (V[]){v_x_24127});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24131 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam18, 1, 1, (V[]){v_x_24131});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24134 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam19, 1, 1, (V[]){v_x_24134});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24137 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam20, 1, 1, (V[]){v_x_24137});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24140 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam21, 1, 1, (V[]){v_x_24140});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24144 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam22, 1, 1, (V[]){v_x_24144});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it1_2468, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24147 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam23, 1, 1, (V[]){v_x_24147});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24149 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam24, 1, 1, (V[]){v_x_24149});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2468, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        heff_drop(v_l_2469);
        heff_drop(v_sh_2470);
        V v_x_24153 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam25, 1, 1, (V[]){v_x_24153});
      }
      default: return heff_nomatch(v_it1_2468);
      }
    }
    case TAG_ETag: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24157 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam26, 1, 1, (V[]){v_x_24157});
    }
    case TAG_EMatch: {
      V v_s_24159 = heff_field(v_f_241, 0);
      V v_arms_24160 = heff_field(v_f_241, 1);
      V v_ru_24f_241_24EMatch = heff_take_reuse_n(v_f_241, 3ULL, 2);
      V v_t_24161 = (g_list_2emap_24s2067043448x720245267(heff_dup(v_as_242)));
      V v_t_24162 = ({ V a_0 = v_t_24161; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_24161); r_; });
      V v_t_24166;
      switch (heff_tag_of(v_t_24162)) {
      case TAG_True: {
        V v_t_24163 = (g_list_2efoldl_24s905606722x2129703274(MK_INT(0LL), MK_INT(0LL), heff_dup(v_as_242)));
        V v_t_24164 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms_24160));
        V v_t_24165 = heff_intMul(v_t_24163, heff_intSub(v_t_24164, MK_INT(1LL)));
        v_t_24166 = heff_intLe(v_t_24165, heff_dup(g_heff_2ecompile_2esimplify_2epushBudget_get()));
        break;
      }
      case TAG_False: {
        v_t_24166 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_24162);
      }
      switch (heff_tag_of(v_t_24166)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24f_241_24EMatch, 2);
        V v_m_24179 = (g_heff_2ecompile_2esimplify_2etraverseS(heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam27, 1, 2, (V[]){v_as_242, v_r_240}), v_arms_24160));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam29, 1, 2, (V[]){v_m_24179, v_s_24159});
      }
      case TAG_False: {
        heff_drop_rec(v_r_240, 4);
        V v_x_24184 = (g_heff_2ecompile_2esimplify_2emkApp(heff_tag_at_n(v_ru_24f_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_24159, v_arms_24160}), v_as_242));
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam30, 1, 1, (V[]){v_x_24184});
      }
      default: return heff_nomatch(v_t_24166);
      }
    }
    case TAG_EPrim: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24187 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam31, 1, 1, (V[]){v_x_24187});
    }
    case TAG_EPrimCall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24191 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam32, 1, 1, (V[]){v_x_24191});
    }
    case TAG_ECall: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24195 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam33, 1, 1, (V[]){v_x_24195});
    }
    case TAG_EInt: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24198 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam34, 1, 1, (V[]){v_x_24198});
    }
    case TAG_EFloat: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24201 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam35, 1, 1, (V[]){v_x_24201});
    }
    case TAG_EStr: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24204 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam36, 1, 1, (V[]){v_x_24204});
    }
    case TAG_EFixed: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24208 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam37, 1, 1, (V[]){v_x_24208});
    }
    case TAG_EFloat32: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24211 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam38, 1, 1, (V[]){v_x_24211});
    }
    case TAG_EAbandon: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24213 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam39, 1, 1, (V[]){v_x_24213});
    }
    case TAG_EFix: {
      heff_drop_rec(v_r_240, 4);
      V v_x_24217 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam40, 1, 1, (V[]){v_x_24217});
    }
    default: return heff_nomatch(v_f_241);
    }
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eapplyToF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_f_241, v_s_245});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_s_248});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam2(V self, V *args) {
  V v_s_2410 = args[0];
  V v_g_249 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_249), heff_rfield(v_s_2410, 2)));
  V v_m_2412 = ({ V a_0 = heff_dup(v_r_240); V a_1 = v_f_241; V a_2 = heff_dup(v_g_249); V a_3 = heff_dup(v_as_242); V a_4 = v_t_2411; V r_ = heff_tr(g_heff_2ecompile_2esimplify_2ecallOf(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2411); r_; });
  V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2410}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    V v_s_2415 = heff_field(v_x2_2413, 1);
    V v_ru_24x2_2413_24MkPair = heff_take_reuse_n(v_x2_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2esimplify_2estillCall(heff_dup(v_g_249), v_x_2414));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_True: {
      heff_drop(v_x_2414);
      heff_drop_cell(v_ru_24x2_2413_24MkPair, 2);
      return (g_heff_2ecompile_2esimplify_2etrySpec(v_r_240, v_g_249, v_as_242, v_s_2415));
    }
    case TAG_False: {
      heff_drop(v_g_249);
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_as_242);
      return heff_tag_at_n(v_ru_24x2_2413_24MkPair, TAG_MkPair, 2, (V[]){v_x_2414, v_s_2415});
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam3(V self, V *args) {
  V v_s_2438 = args[0];
  V v_t_2432 = heff_env(self)[0];
  V v_as_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2432, v_as_242}), v_s_2438});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam4(V self, V *args) {
  V v_s_2461 = args[0];
  V v_m_2460 = heff_env(self)[0];
  V v_x_2457 = heff_env(self)[1];
  V v_a_2458 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2462 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_s_2461}));
  switch (heff_tag_of(v_x2_2462)) {
  case TAG_MkPair: {
    V v_x_2463 = heff_field(v_x2_2462, 0);
    V v_s_2464 = heff_field(v_x2_2462, 1);
    V v_ru_24x2_2462_24MkPair = heff_take_reuse_n(v_x2_2462, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2457, v_a_2458, v_x_2463}), v_s_2464});
  }
  default: return heff_nomatch(v_x2_2462);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam5(V self, V *args) {
  V v_s_2467 = args[0];
  V v_x_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2466, v_s_2467});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam6(V self, V *args) {
  V v_s_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2472, v_s_2473});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam8(V self, V *args) {
  V v_s_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_as_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_s_2489}));
  switch (heff_tag_of(v_x2_2490)) {
  case TAG_MkPair: {
    V v_x_2491 = heff_field(v_x2_2490, 0);
    V v_s_2492 = heff_field(v_x2_2490, 1);
    heff_take_n(v_x2_2490, 3ULL, 2);
    V f_ = heff_get_n(v_r_240, 1, 4);
    heff_room[0] = v_x_2491;
    heff_room[1] = v_as_242;
    heff_room[2] = v_s_2492;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x2_2490);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam7(V self, V *args) {
  V v_s_2475 = args[0];
  V v_g_2474 = heff_env(self)[0];
  V v_l_2469 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_as_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  V v_sh_2470 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_2476 = (g_heff_2ecompile_2esimplify_2eknown(heff_dup(v_g_2474), v_s_2475));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_s_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    switch (heff_tag_of(v_x_2477)) {
    case TAG_Nothing: {
      heff_drop(v_sh_2470);
      V v_x2_2479 = (g_heff_2ecompile_2esimplify_2eknownField(v_g_2474, v_l_2469, v_s_2478));
      switch (heff_tag_of(v_x2_2479)) {
      case TAG_MkPair: {
        V v_x_2480 = heff_field(v_x2_2479, 0);
        V v_s_2481 = heff_field(v_x2_2479, 1);
        heff_take_n(v_x2_2479, 3ULL, 2);
        switch (heff_tag_of(v_x_2480)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_240, 4);
          V v_x_2482 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, v_as_242));
          return heff_tag_at_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, (V[]){v_x_2482, v_s_2481});
        }
        case TAG_Just: {
          V v_v_2483 = heff_field(v_x_2480, 0);
          heff_take_n(v_x_2480, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_2476_24MkPair, 2);
          V v_t_2484 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
          V v_t_2485 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_v_2483, v_as_242}));
          return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2484, v_t_2485, v_s_2481));
        }
        default: return heff_nomatch(v_x_2480);
        }
      }
      default: return heff_nomatch(v_x2_2479);
      }
    }
    case TAG_Just: {
      V v_b_2486 = heff_field(v_x_2477, 0);
      heff_take_n(v_x_2477, 1ULL, 1);
      heff_drop(v_g_2474);
      heff_drop_cell(v_ru_24x2_2476_24MkPair, 2);
      V v_t_2487 = (g_heff_2ecompile_2esimplify_2emkApp(v_f_241, heff_dup(v_as_242)));
      V v_m_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 3, (V[]){v_l_2469, v_sh_2470, v_b_2486}));
      return (g_heff_2ecompile_2esimplify_2eattempt(v_t_2487, heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam8, 1, 3, (V[]){v_m_2488, v_r_240, v_as_242}), v_s_2478));
    }
    default: return heff_nomatch(v_x_2477);
    }
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam9(V self, V *args) {
  V v_s_2496 = args[0];
  V v_x_2495 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2495, v_s_2496});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam10(V self, V *args) {
  V v_s_24100 = args[0];
  V v_x_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2499, v_s_24100});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam11(V self, V *args) {
  V v_s_24105 = args[0];
  V v_x_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24104, v_s_24105});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam12(V self, V *args) {
  V v_s_24108 = args[0];
  V v_x_24107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24107, v_s_24108});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam13(V self, V *args) {
  V v_s_24113 = args[0];
  V v_x_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24112, v_s_24113});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam14(V self, V *args) {
  V v_s_24117 = args[0];
  V v_x_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24116, v_s_24117});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam15(V self, V *args) {
  V v_s_24121 = args[0];
  V v_x_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24120, v_s_24121});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam16(V self, V *args) {
  V v_s_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24123, v_s_24124});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam17(V self, V *args) {
  V v_s_24128 = args[0];
  V v_x_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24127, v_s_24128});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam18(V self, V *args) {
  V v_s_24132 = args[0];
  V v_x_24131 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24131, v_s_24132});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam19(V self, V *args) {
  V v_s_24135 = args[0];
  V v_x_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24134, v_s_24135});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam20(V self, V *args) {
  V v_s_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24137, v_s_24138});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam21(V self, V *args) {
  V v_s_24141 = args[0];
  V v_x_24140 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24140, v_s_24141});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam22(V self, V *args) {
  V v_s_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24144, v_s_24145});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam23(V self, V *args) {
  V v_s_24148 = args[0];
  V v_x_24147 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24147, v_s_24148});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam24(V self, V *args) {
  V v_s_24150 = args[0];
  V v_x_24149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24149, v_s_24150});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam25(V self, V *args) {
  V v_s_24154 = args[0];
  V v_x_24153 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24153, v_s_24154});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam26(V self, V *args) {
  V v_s_24158 = args[0];
  V v_x_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24157, v_s_24158});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam28(V self, V *args) {
  V v_s_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_b_24170 = heff_env(self)[2];
  V v_t_24168 = heff_env(self)[3];
  V v_vs_24169 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_s_24172}));
  V v_x2_24176;
  switch (heff_tag_of(v_x2_24173)) {
  case TAG_MkPair: {
    V v_x_24174 = heff_field(v_x2_24173, 0);
    V v_s_24175 = heff_field(v_x2_24173, 1);
    heff_take_n(v_x2_24173, 3ULL, 2);
    v_x2_24176 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 3, (V[]){v_b_24170, v_x_24174, v_s_24175}));
    break;
  }
  default: heff_nomatch(v_x2_24173);
  }
  switch (heff_tag_of(v_x2_24176)) {
  case TAG_MkPair: {
    V v_x_24177 = heff_field(v_x2_24176, 0);
    V v_s_24178 = heff_field(v_x2_24176, 1);
    V v_ru_24x2_24176_24MkPair = heff_take_reuse_n(v_x2_24176, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_24168, v_vs_24169, v_x_24177}), v_s_24178});
  }
  default: return heff_nomatch(v_x2_24176);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam27(V self, V *args) {
  V v_a_24167 = args[0];
  V v_as_242 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_a_24167)) {
  case TAG_MkArm: {
    V v_t_24168 = heff_field(v_a_24167, 0);
    V v_vs_24169 = heff_field(v_a_24167, 1);
    V v_b_24170 = heff_field(v_a_24167, 2);
    heff_take_n(v_a_24167, 7ULL, 3);
    V v_m_24171 = (g_heff_2ecompile_2esimplify_2etraverseS_24s1810870444x426948817(v_as_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eapplyToF_lam28, 1, 5, (V[]){v_m_24171, v_r_240, v_b_24170, v_t_24168, v_vs_24169});
  }
  default: return heff_nomatch(v_a_24167);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam29(V self, V *args) {
  V v_s_24180 = args[0];
  V v_m_24179 = heff_env(self)[0];
  V v_s_24159 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24181 = heff_tr(heff_call(v_m_24179, 1, (V[]){v_s_24180}));
  switch (heff_tag_of(v_x2_24181)) {
  case TAG_MkPair: {
    V v_x_24182 = heff_field(v_x2_24181, 0);
    V v_s_24183 = heff_field(v_x2_24181, 1);
    V v_ru_24x2_24181_24MkPair = heff_take_reuse_n(v_x2_24181, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24181_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_24159, v_x_24182}), v_s_24183});
  }
  default: return heff_nomatch(v_x2_24181);
  }
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam30(V self, V *args) {
  V v_s_24185 = args[0];
  V v_x_24184 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24184, v_s_24185});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam31(V self, V *args) {
  V v_s_24188 = args[0];
  V v_x_24187 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24187, v_s_24188});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam32(V self, V *args) {
  V v_s_24192 = args[0];
  V v_x_24191 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24191, v_s_24192});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam33(V self, V *args) {
  V v_s_24196 = args[0];
  V v_x_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24195, v_s_24196});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam34(V self, V *args) {
  V v_s_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24198, v_s_24199});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam35(V self, V *args) {
  V v_s_24202 = args[0];
  V v_x_24201 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24201, v_s_24202});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam36(V self, V *args) {
  V v_s_24205 = args[0];
  V v_x_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24204, v_s_24205});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam37(V self, V *args) {
  V v_s_24209 = args[0];
  V v_x_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24208, v_s_24209});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam38(V self, V *args) {
  V v_s_24212 = args[0];
  V v_x_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24211, v_s_24212});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam39(V self, V *args) {
  V v_s_24214 = args[0];
  V v_x_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24213, v_s_24214});
}
V g_heff_2ecompile_2esimplify_2eapplyToF_lam40(V self, V *args) {
  V v_s_24218 = args[0];
  V v_x_24217 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24217, v_s_24218});
}
Clo g_heff_2ecompile_2esimplify_2efindField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindField_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindField(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_k_244 = heff_field(v_x21_242, 0);
      V v_v_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_k_244), heff_dup(v_l_240))) {
        heff_drop(v_l_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_l_240;
        V t_1 = v_rest_243;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindField(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eothersPure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eothersPure_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eothersPure(V v_l_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_l_240);
    return ((V)&g_heff_2ecompile_2esimplify_2eothersPure_lam0_clo);
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x21_243, 0);
      V v_f_246 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      if (heff_strEq_c(v_k_245, heff_dup(v_l_240))) {
        heff_drop(v_f_246);
        V t_0 = v_l_240;
        V t_1 = v_rest_244;
        v_l_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_clo_n(g_heff_2ecompile_2esimplify_2eothersPure_lam1, 1, 3, (V[]){v_f_246, v_l_240, v_rest_244});
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eothersPure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eothersPure(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_s_242});
}
V g_heff_2ecompile_2esimplify_2eothersPure_lam1(V self, V *args) {
  V v_s_248 = args[0];
  V v_f_246 = heff_env(self)[0];
  V v_l_240 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_249 = ({ V a_0 = v_f_246; V a_1 = v_s_248; V r_ = (g_heff_2ecompile_2esimplify_2eisPure(a_0, a_1)); heff_drop(v_f_246); r_; });
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    switch (heff_tag_of(v_x_2410)) {
    case TAG_True: {
      heff_drop_cell(v_ru_24x2_249_24MkPair, 2);
      V v_t_2412 = (g_heff_2ecompile_2esimplify_2eothersPure(v_l_240, v_rest_244));
      V f_ = v_t_2412;
      args[0] = v_s_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_False: {
      heff_drop(v_l_240);
      heff_drop(v_rest_244);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_s_2411});
    }
    default: return heff_nomatch(v_x_2410);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args);
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eprojectF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eprojectF_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2eprojectF(V v_r_240, V v_l_241, V v_sh_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam0, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EGlobal: {
    V v_g_246 = heff_dup(heff_field(v_e_243, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam1, 1, 5, (V[]){v_g_246, v_e_243, v_l_241, v_sh_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam2, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam3, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_e_243, 0);
    V v_a_2420 = heff_field(v_e_243, 1);
    V v_b_2421 = heff_field(v_e_243, 2);
    heff_take_n(v_e_243, 7ULL, 3);
    V v_m_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 3, (V[]){v_l_241, v_sh_242, v_b_2421}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam4, 1, 3, (V[]){v_m_2422, v_x_2419, v_a_2420});
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_e_243, 0);
    heff_take_n(v_e_243, 1ULL, 1);
    heff_drop_rec(v_r_240, 4);
    V v_t_2428 = (g_heff_2ecompile_2esimplify_2efindField(heff_dup(v_l_241), v_fs_2427));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam5, 1, 3, (V[]){v_fs_2427, v_l_241, v_sh_242});
    }
    case TAG_Just: {
      V v_v_2431 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      V v_m_2432 = (g_heff_2ecompile_2esimplify_2eothersPure(heff_dup(v_l_241), heff_dup(v_fs_2427)));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam6, 1, 5, (V[]){v_m_2432, v_v_2431, v_fs_2427, v_l_241, v_sh_242});
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam7, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_ETag: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam8, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EMatch: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam9, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam10, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam11, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam12, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam13, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam14, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam15, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam16, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam17, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam18, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eprojectF_lam19, 1, 3, (V[]){v_e_243, v_l_241, v_sh_242});
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eprojectF(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam0(V self, V *args) {
  V v_s_245 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_245});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam1(V self, V *args) {
  V v_s_247 = args[0];
  V v_g_246 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_l_241 = heff_env(self)[2];
  V v_sh_242 = heff_env(self)[3];
  V v_r_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_248 = (g_heff_2ecompile_2esimplify_2eknown(v_g_246, v_s_247));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_s_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2410});
    }
    case TAG_Just: {
      V v_b_2411 = heff_field(v_x_249, 0);
      heff_take_n(v_x_249, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_248_24MkPair, 2);
      V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 3, (V[]){heff_dup(v_l_241), heff_dup(v_sh_242), v_b_2411}));
      return (g_heff_2ecompile_2esimplify_2eattempt(heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_t_2412, v_s_2410));
    }
    default: return heff_nomatch(v_x_249);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam2(V self, V *args) {
  V v_s_2415 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2415});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2418});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam4(V self, V *args) {
  V v_s_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  V v_x_2419 = heff_env(self)[1];
  V v_a_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_s_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_s_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2419, v_a_2420, v_x_2425}), v_s_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam5(V self, V *args) {
  V v_s_2429 = args[0];
  V v_fs_2427 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tag_n(TAG_EProj, 3, (V[]){heff_tag_n(TAG_ERecord, 1, (V[]){v_fs_2427}), v_l_241, v_sh_242});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_s_2429});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam6(V self, V *args) {
  V v_s_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_v_2431 = heff_env(self)[1];
  V v_fs_2427 = heff_env(self)[2];
  V v_l_241 = heff_env(self)[3];
  V v_sh_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_s_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_s_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    V v_x_2437;
    switch (heff_tag_of(v_x_2435)) {
    case TAG_True: {
      heff_drop(v_fs_2427);
      heff_drop(v_l_241);
      heff_drop(v_sh_242);
      v_x_2437 = v_v_2431;
      break;
    }
    case TAG_False: {
      heff_drop(v_v_2431);
      v_x_2437 = heff_tag_n(TAG_EProj, 3, (V[]){heff_tag_n(TAG_ERecord, 1, (V[]){v_fs_2427}), v_l_241, v_sh_242});
      break;
    }
    default: heff_nomatch(v_x_2435);
    }
    return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_x_2437, v_s_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam7(V self, V *args) {
  V v_s_2441 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2441});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam8(V self, V *args) {
  V v_s_2444 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2444});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam9(V self, V *args) {
  V v_s_2447 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2447});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam10(V self, V *args) {
  V v_s_2449 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2449});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam11(V self, V *args) {
  V v_s_2452 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2452});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam12(V self, V *args) {
  V v_s_2455 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2455});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam13(V self, V *args) {
  V v_s_2457 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2457});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam14(V self, V *args) {
  V v_s_2459 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2459});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam15(V self, V *args) {
  V v_s_2461 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2461});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam16(V self, V *args) {
  V v_s_2464 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2464});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam17(V self, V *args) {
  V v_s_2466 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2466});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam18(V self, V *args) {
  V v_s_2467 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2467});
}
V g_heff_2ecompile_2esimplify_2eprojectF_lam19(V self, V *args) {
  V v_s_2470 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_sh_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_243, v_l_241, v_sh_242}), v_s_2470});
}
Clo g_heff_2ecompile_2esimplify_2efindArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2efindArm_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2efindArm(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      if (heff_strEq_c(heff_dup(v_t2_244), heff_dup(v_t_240))) {
        heff_drop(v_t_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){heff_dup(v_t2_244), heff_dup(v_vs_245), heff_dup(v_b_246)})});
      } else {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2efindArm_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2efindArm(a[0], a1); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2esimplify_2ecaseBudget_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2ecaseBudget_st;
static V g_heff_2ecompile_2esimplify_2ecaseBudget_init(void) {
  return MK_INT(40LL);
}
V g_heff_2ecompile_2esimplify_2ecaseBudget_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2ecaseBudget_st)) return g_heff_2ecompile_2esimplify_2ecaseBudget_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2ecaseBudget_val, &g_heff_2ecompile_2esimplify_2ecaseBudget_st, g_heff_2ecompile_2esimplify_2ecaseBudget_init);
}
Clo g_heff_2ecompile_2esimplify_2epushArm_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2epushArm_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2epushArm(V v_r_240, V v_arms_241, V v_x3_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkArm: {
    V v_t_244 = heff_field(v_x3_242, 0);
    V v_vs_245 = heff_field(v_x3_242, 1);
    V v_b_246 = heff_field(v_x3_242, 2);
    V v_ru_24x3_242_24MkArm = heff_take_reuse_n(v_x3_242, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), v_arms_241});
    V v_x2_248 = (g_heff_2ecompile_2esimplify_2ecopy(v_t_247, v_p_243));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
      V v_t_2441;
      switch (heff_tag_of(v_x_249)) {
      case TAG_EVar: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x_249, 0ULL, 3);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EMatch: {
        V v_arms_2427 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2441 = v_arms_2427;
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFloat32: {
        heff_take_n(v_x_249, 0ULL, 1);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EAbandon: {
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x_249, 0ULL, 2);
        v_t_2441 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_m_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_246, v_t_2441}));
      V v_x2_2443 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2443)) {
      case TAG_MkPair: {
        V v_x_2444 = heff_field(v_x2_2443, 0);
        V v_s_2445 = heff_field(v_x2_2443, 1);
        heff_take_n(v_x2_2443, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24MkArm, TAG_MkArm, 3, (V[]){v_t_244, v_vs_245, v_x_2444}), v_s_2445});
      }
      default: return heff_nomatch(v_x2_2443);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2esimplify_2epushArm_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2epushArm(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecaseOfCase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecaseOfCase_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2ecaseOfCase(V v_r_240, V v_s2_241, V v_arms2_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_list_2eany_24s1107779796x153132813(v_arms2_242));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_tag_n(TAG_EMatch, 2, (V[]){NTAG(TAG_EAbandon), heff_dup(v_arms_243)});
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
    V v_t_247 = (g_heff_2ecompile_2eir_2esizeW(MK_INT(0LL), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_arms2_242));
    V v_t_249 = heff_intMul(v_t_247, heff_intSub(v_t_248, MK_INT(1LL)));
    if (heff_intLe_c(v_t_249, heff_dup(g_heff_2ecompile_2esimplify_2ecaseBudget_get()))) {
      V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2epushArm_clo), 2, (V[]){v_r_240, v_arms_243}));
      V v_m_2412 = (g_heff_2ecompile_2esimplify_2etraverseS(v_t_2411, v_arms2_242));
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0, 1, 2, (V[]){v_m_2412, v_s2_241});
    } else {
      heff_drop(v_r_240);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
    }
  }
  case TAG_False: {
    heff_drop(v_r_240);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2, 1, 3, (V[]){v_s2_241, v_arms2_242, v_arms_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecaseOfCase(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_s2_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_s_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_x_2415}), v_s_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam1(V self, V *args) {
  V v_s_2417 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_s_2417});
}
V g_heff_2ecompile_2esimplify_2ecaseOfCase_lam2(V self, V *args) {
  V v_s_2419 = args[0];
  V v_s2_241 = heff_env(self)[0];
  V v_arms2_242 = heff_env(self)[1];
  V v_arms_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2420 = heff_tag_n(TAG_EMatch, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s2_241, v_arms2_242}), v_arms_243});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_s_2419});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args);
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ematchF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ematchF_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ematchF(V v_r_240, V v_s_241, V v_arms_242) {
top: ;
  switch (heff_tag_of(v_s_241)) {
  case TAG_EVar: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam0, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EGlobal: {
    V v_g_245 = heff_dup(heff_field(v_s_241, 0));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam1, 1, 4, (V[]){v_g_245, v_s_241, v_arms_242, v_r_240});
  }
  case TAG_ELam: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam2, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EApp: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam3, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ELet: {
    V v_x_2447 = heff_field(v_s_241, 0);
    V v_a_2448 = heff_field(v_s_241, 1);
    V v_b_2449 = heff_field(v_s_241, 2);
    heff_take_n(v_s_241, 7ULL, 3);
    V v_m_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 4), 2, (V[]){v_b_2449, v_arms_242}));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam4, 1, 3, (V[]){v_m_2450, v_x_2447, v_a_2448});
  }
  case TAG_ERecord: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam5, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EProj: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam6, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ETag: {
    V v_t_2461 = heff_dup(heff_field(v_s_241, 0));
    V v_as_2462 = heff_dup(heff_field(v_s_241, 1));
    V v_it_2463 = (g_heff_2ecompile_2esimplify_2efindArm(v_t_2461, v_arms_242));
    switch (heff_tag_of(v_it_2463)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      heff_drop(v_as_2462);
      return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam7, 1, 2, (V[]){v_s_241, v_arms_242});
    }
    case TAG_Just: {
      V v_it1_2465 = heff_field(v_it_2463, 0);
      heff_take_n(v_it_2463, 1ULL, 1);
      heff_drop_tag(v_s_241, 2);
      heff_drop(v_arms_242);
      switch (heff_tag_of(v_it1_2465)) {
      case TAG_MkArm: {
        V v_vs_2467 = heff_field(v_it1_2465, 1);
        V v_b_2468 = heff_field(v_it1_2465, 2);
        heff_take_n(v_it1_2465, 6ULL, 3);
        V v_t_2469 = (g_heff_2ecompile_2esimplify_2ezipL(v_vs_2467, v_as_2462));
        V v_t_2470 = ({ V a_0 = v_t_2469; V a_1 = v_b_2468; V r_ = (g_heff_2ecompile_2esimplify_2eletsOf(a_0, a_1)); heff_drop(v_t_2469); r_; });
        return heff_tail(heff_get_n(v_r_240, 0, 4), 1, (V[]){v_t_2470});
      }
      default: return heff_nomatch(v_it1_2465);
      }
    }
    default: return heff_nomatch(v_it_2463);
    }
  }
  case TAG_EMatch: {
    V v_s2_2471 = heff_field(v_s_241, 0);
    V v_arms2_2472 = heff_field(v_s_241, 1);
    heff_take_n(v_s_241, 3ULL, 2);
    return (g_heff_2ecompile_2esimplify_2ecaseOfCase(v_r_240, v_s2_2471, v_arms2_2472, v_arms_242));
  }
  case TAG_EPrim: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam8, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EPrimCall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam9, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_ECall: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam10, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EInt: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam11, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam12, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EStr: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam13, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFixed: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam14, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFloat32: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam15, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam16, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  case TAG_EFix: {
    heff_drop_rec(v_r_240, 4);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2ematchF_lam17, 1, 2, (V[]){v_s_241, v_arms_242});
  }
  default: return heff_nomatch(v_s_241);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ematchF(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2ematchF_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_244});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_arms_242 = heff_env(self)[2];
  V v_r_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_247 = (g_heff_2ecompile_2esimplify_2eknown(v_g_245, v_s_246));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_s_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
    }
    case TAG_Just: {
      V v_it1_2410 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_EVar: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EGlobal: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELam: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EApp: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ELet: {
        heff_take_n(v_it1_2410, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ERecord: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EProj: {
        heff_take_n(v_it1_2410, 0ULL, 3);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ETag: {
        V v_t2_2424 = heff_field(v_it1_2410, 0);
        V v_as2_2425 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        heff_drop_tag(v_s_241, 1);
        heff_drop_cell(v_ru_24x2_247_24MkPair, 2);
        V f_ = heff_get_n(v_r_240, 3, 4);
        heff_room[0] = heff_tag_n(TAG_ETag, 2, (V[]){v_t2_2424, v_as2_2425});
        heff_room[1] = v_arms_242;
        heff_room[2] = v_s_249;
        if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
      }
      case TAG_EMatch: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrim: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EPrimCall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_ECall: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EInt: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EStr: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFixed: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFloat32: {
        heff_take_n(v_it1_2410, 0ULL, 1);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EAbandon: {
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      case TAG_EFix: {
        heff_take_n(v_it1_2410, 0ULL, 2);
        heff_drop_rec(v_r_240, 4);
        return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_249});
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
    default: return heff_nomatch(v_x_248);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam2(V self, V *args) {
  V v_s_2443 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2443});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam3(V self, V *args) {
  V v_s_2446 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2446});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam4(V self, V *args) {
  V v_s_2451 = args[0];
  V v_m_2450 = heff_env(self)[0];
  V v_x_2447 = heff_env(self)[1];
  V v_a_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2452 = heff_tr(heff_call(v_m_2450, 1, (V[]){v_s_2451}));
  switch (heff_tag_of(v_x2_2452)) {
  case TAG_MkPair: {
    V v_x_2453 = heff_field(v_x2_2452, 0);
    V v_s_2454 = heff_field(v_x2_2452, 1);
    V v_ru_24x2_2452_24MkPair = heff_take_reuse_n(v_x2_2452, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2447, v_a_2448, v_x_2453}), v_s_2454});
  }
  default: return heff_nomatch(v_x2_2452);
  }
}
V g_heff_2ecompile_2esimplify_2ematchF_lam5(V self, V *args) {
  V v_s_2456 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2456});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam6(V self, V *args) {
  V v_s_2460 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2460});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam7(V self, V *args) {
  V v_s_2464 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2464});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam8(V self, V *args) {
  V v_s_2474 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2474});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam9(V self, V *args) {
  V v_s_2477 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2477});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam10(V self, V *args) {
  V v_s_2480 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2480});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam11(V self, V *args) {
  V v_s_2482 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2482});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam12(V self, V *args) {
  V v_s_2484 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2484});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam13(V self, V *args) {
  V v_s_2486 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2486});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam14(V self, V *args) {
  V v_s_2489 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2489});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam15(V self, V *args) {
  V v_s_2491 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2491});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam16(V self, V *args) {
  V v_s_2492 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2492});
}
V g_heff_2ecompile_2esimplify_2ematchF_lam17(V self, V *args) {
  V v_s_2495 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_arms_242}), v_s_2495});
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam1, 2, 0};
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam2, 3, 0};
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2esk_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esk_lam3, 2, 0};

static V g_heff_2ecompile_2esimplify_2esk_val;
static HEFF_ONCE g_heff_2ecompile_2esimplify_2esk_st;
static V g_heff_2ecompile_2esimplify_2esk_init(void) {
  return heff_rec_n(4, shape_simp__applyTo__project__match, (V[]){((V)&g_heff_2ecompile_2esimplify_2esk_lam0_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam1_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam2_clo), ((V)&g_heff_2ecompile_2esimplify_2esk_lam3_clo)});
}
V g_heff_2ecompile_2esimplify_2esk_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2esimplify_2esk_st)) return g_heff_2ecompile_2esimplify_2esk_val;
  return heff_global(&g_heff_2ecompile_2esimplify_2esk_val, &g_heff_2ecompile_2esimplify_2esk_st, g_heff_2ecompile_2esimplify_2esk_init);
}
V g_heff_2ecompile_2esimplify_2esk_lam0(V self, V *args) {
  V v_e_240 = args[0];
  return (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_e_240));
}
V g_heff_2ecompile_2esimplify_2esk_lam1(V self, V *args) {
  V v_f_241 = args[0];
  V v_as_242 = args[1];
  return (g_heff_2ecompile_2esimplify_2eapplyToF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_f_241, v_as_242));
}
V g_heff_2ecompile_2esimplify_2esk_lam2(V self, V *args) {
  V v_l_243 = args[0];
  V v_sh_244 = args[1];
  V v_e_245 = args[2];
  return (g_heff_2ecompile_2esimplify_2eprojectF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_l_243, v_sh_244, v_e_245));
}
V g_heff_2ecompile_2esimplify_2esk_lam3(V self, V *args) {
  V v_s_246 = args[0];
  V v_arms_247 = args[1];
  return (g_heff_2ecompile_2esimplify_2ematchF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_s_246, v_arms_247));
}
Clo g_heff_2ecompile_2esimplify_2erecordAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordAll_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordAll(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_241), NTAG(TAG_Nil)});
  V v_a_244 = (g_heff_2ecompile_2eir_2esizeB(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), MK_INT(0LL), v_t_243));
  V v_t_247;
  if (heff_intLt_c(heff_dup(g_heff_2ecompile_2esimplify_2especBodySize_get()), v_a_244)) {
    v_t_247 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 0, 7);
    v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), v_t_246));
  }
  V v_t_2438;
  switch (heff_tag_of(v_b_241)) {
  case TAG_EVar: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ELam: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_True);
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_True);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_b_241, 0ULL, 3);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFixed: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFloat32: {
    heff_take_n(v_b_241, 0ULL, 1);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EAbandon: {
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_b_241, 0ULL, 2);
    v_t_2438 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_t_2440;
  switch (heff_tag_of(v_t_2438)) {
  case TAG_True: {
    V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
    v_t_2440 = (g_map_2einsert_24s1341440536x470972936(v_key_240, NTAG(TAG_MkUnit), v_t_2439));
    break;
  }
  case TAG_False: {
    heff_drop(v_key_240);
    v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 1, 7);
    break;
  }
  default: heff_nomatch(v_t_2438);
  }
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 2, 7);
  V v_t_2442 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 3, 7);
  V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 4, 7);
  V v_t_2444 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 5, 7);
  V v_t_2445 = heff_get_n(heff_dup(heff_rfield(v_s_242, 7)), 6, 7);
  V v_p_2446 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_247, v_t_2440, v_t_2441, v_t_2442, v_t_2443, v_t_2444, v_t_2445});
  return ({ V rv_7 = v_p_2446; V rr_ = heff_rec_reuse_n(v_s_242, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2ecompile_2esimplify_2erecordAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordAll(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2erecordDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2erecordDef_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2erecordDef(V v_key_240, V v_b_241, V v_s_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_b_241)));
  V v_t_244 = (g_heff_2ecompile_2eir_2enubI(v_t_243));
  V v_t_245 = ({ V a_0 = heff_dup(v_key_240); V a_1 = v_t_244; V r_ = (g_heff_2ecompile_2esimplify_2eelemStr(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_247 = v_s_242;
    break;
  }
  case TAG_False: {
    V v_d_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_key_240), heff_dup(v_b_241), heff_take_field(v_s_242, 2)));
    v_t_247 = ({ V rv_2 = v_d_246; V rr_ = heff_rec_reuse_n(v_s_242, 507ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), (g_heff_2ecompile_2esimplify_2erecordAll(v_key_240, v_b_241, v_t_247))});
}
V g_heff_2ecompile_2esimplify_2erecordDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2erecordDef(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2emadeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOne_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emadeOne(V v_h_240, V v_s_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 0, 7);
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 1, 7);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 2, 7);
  V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 3, 7);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 4, 7);
  V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_h_240, NTAG(TAG_MkUnit), v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 5, 7);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_s_241, 7)), 6, 7);
  V v_p_2410 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_247, v_t_248, v_t_249});
  V v_t_2411 = ({ V rv_7 = v_p_2410; V rr_ = heff_rec_reuse_n(v_s_241, 383ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 7) = rv_7; rr_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2411});
}
V g_heff_2ecompile_2esimplify_2emadeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emadeOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2emakeFresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeFresh_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emakeFresh(V v_h_240, V v_b0_241, V v_s_242) {
top: ;
  V v_k_243 = heff_dup(heff_rfield(v_s_242, 8));
  V v_t_244 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_k_243, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_245 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){heff_take_field(v_s_242, 0), heff_take_field(v_s_242, 1), heff_take_field(v_s_242, 2), heff_take_field(v_s_242, 3), heff_take_field(v_s_242, 4), heff_take_field(v_s_242, 5), heff_take_field(v_s_242, 6), heff_take_field(v_s_242, 7), v_t_244});
  V v_x2_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_245});
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2esimplify_2eownSt(v_s_248));
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_s_2411 = heff_field(v_t_249, 1);
      V v_ru_24t_249_24MkPair = heff_take_reuse_n(v_t_249, 2ULL, 2);
      V v_m_2412 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_b0_241));
      V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_MkPair: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_s_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        V v_m_2416 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2414));
        V v_x2_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_s_2415}));
        switch (heff_tag_of(v_x2_2417)) {
        case TAG_MkPair: {
          V v_x_2418 = heff_field(v_x2_2417, 0);
          V v_s_2419 = heff_field(v_x2_2417, 1);
          heff_take_n(v_x2_2417, 3ULL, 2);
          V v_x2_2420 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2418, v_s_2419));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_x_2421 = heff_field(v_x2_2420, 0);
            V v_s_2422 = heff_field(v_x2_2420, 1);
            heff_take_n(v_x2_2420, 3ULL, 2);
            V v_k_2423 = heff_dup(heff_rfield(v_s_2422, 8));
            V v_t_2424 = heff_get_n(heff_get_n(v_s_242, 8, 9), 2, 5);
            V v_k_2425 = ({ V rv_2 = v_t_2424; V rr_ = heff_rec_reuse_n(v_k_2423, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 2) = rv_2; rr_; });
            V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_s_2422, 8)), 2, 5);
            V v_t_2427 = (g_map_2einsert_24s1341440536x470972936(v_h_240, v_t_2426, heff_take_field(v_k_2425, 4)));
            V v_k_2428 = ({ V rv_4 = v_t_2427; V rr_ = heff_rec_reuse_n(v_k_2425, 15ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 4) = rv_4; rr_; });
            V v_t_2429 = ({ V rv_8 = v_k_2428; V rr_ = heff_rec_reuse_n(v_s_2422, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 8) = rv_8; rr_; });
            V v_x2_2430 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_2429});
            switch (heff_tag_of(v_x2_2430)) {
            case TAG_MkPair: {
              V v_s_2432 = heff_field(v_x2_2430, 1);
              heff_take_n(v_x2_2430, 2ULL, 2);
              return heff_tag_at_n(v_ru_24t_249_24MkPair, TAG_MkPair, 2, (V[]){v_x_2421, v_s_2432});
            }
            default: return heff_nomatch(v_x2_2430);
            }
          }
          default: return heff_nomatch(v_x2_2420);
          }
        }
        default: return heff_nomatch(v_x2_2417);
        }
      }
      default: return heff_nomatch(v_x2_2413);
      }
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2esimplify_2emakeFresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeFresh(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeOne_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2emakeOne(V v_more_240, V v_h_241, V v_b0_242, V v_s_243) {
top: ;
  V v_x2_244 = (g_heff_2ecompile_2esimplify_2emadeOne(heff_dup(v_h_241), v_s_243));
  switch (heff_tag_of(v_x2_244)) {
  case TAG_MkPair: {
    V v_s_246 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 2ULL, 2);
    V v_x1_247 = (g_heff_2ecompile_2esimplify_2ekeptAt(heff_dup(v_s_246), heff_dup(v_h_241)));
    V v_x2_2412;
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nothing: {
      v_x2_2412 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      break;
    }
    case TAG_Just: {
      V v_kc_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 1);
      V v_t_249 = heff_get_n(v_kc_248, 4, 5);
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        v_x2_2412 = heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
        break;
      }
      case TAG_Just: {
        V v_km_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_244_24MkPair, 2);
        V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_km_2410, 0)), 1, (V[]){NTAG(TAG_MkUnit)}));
        v_x2_2412 = (g_heff_2ecompile_2esimplify_2emadeKept(v_km_2410, v_t_2411, v_s_246));
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_x1_247);
    }
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
      V v_m_2417;
      switch (heff_tag_of(v_x_2413)) {
      case TAG_Nothing: {
        v_m_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeFresh_clo), 2, (V[]){heff_dup(v_h_241), v_b0_242}));
        break;
      }
      case TAG_Just: {
        V v_b_2415 = heff_field(v_x_2413, 0);
        heff_take_n(v_x_2413, 1ULL, 1);
        heff_drop(v_b0_242);
        v_m_2417 = heff_clo_n(g_heff_2ecompile_2esimplify_2emakeOne_lam0, 1, 1, (V[]){v_b_2415});
        break;
      }
      default: heff_nomatch(v_x_2413);
      }
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_MkPair: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_s_2420 = heff_field(v_x2_2418, 1);
        V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
        V v_t_2421 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_2419)));
        V v_t_2422 = (g_heff_2ecompile_2eir_2enubI(v_t_2421));
        V v_m_2423 = heff_tr(heff_call(v_more_240, 1, (V[]){v_t_2422}));
        V v_x2_2424 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2420}));
        switch (heff_tag_of(v_x2_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x2_2424, 0);
          V v_s_2426 = heff_field(v_x2_2424, 1);
          heff_take_n(v_x2_2424, 3ULL, 2);
          V v_t_2427 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_h_241), v_h_241, v_x_2419}), NTAG(TAG_Nil)});
          V v_x_2428 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2425, v_t_2427));
          return heff_tag_at_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, (V[]){v_x_2428, v_s_2426});
        }
        default: return heff_nomatch(v_x2_2424);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_heff_2ecompile_2esimplify_2emakeOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2emakeOne_lam0(V self, V *args) {
  V v_s_2416 = args[0];
  V v_b_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2415, v_s_2416});
}
V g_heff_2ecompile_2esimplify_2emakeEach_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2emakeEach_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_lam0, 1, 0};
Clo g_heff_2ecompile_2esimplify_2emakeEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emakeEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2emakeEach(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_h_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 4, 7);
    V v_x3_245 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_244; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_t_244); r_; });
    V v_x3_248;
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_p_241, 7)), 2, 7);
      v_x3_248 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      v_x3_248 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x3_245);
    }
    V v_m_2411;
    switch (heff_tag_of(v_x3_248)) {
    case TAG_Nothing: {
      heff_drop(v_h_242);
      v_m_2411 = ((V)&g_heff_2ecompile_2esimplify_2emakeEach_lam0_clo);
      break;
    }
    case TAG_Just: {
      V v_b0_2410 = heff_field(v_x3_248, 0);
      heff_take_n(v_x3_248, 1ULL, 1);
      v_m_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeOne_clo), 3, (V[]){((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), v_h_242, v_b0_2410}));
      break;
    }
    default: heff_nomatch(v_x3_248);
    }
    V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_p_241}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_s_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      V v_m_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2esimplify_2emakeEach_clo), 1, (V[]){v_rest_243}));
      V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2414}));
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_MkPair: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_s_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        V v_x_2419 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2413, v_x_2417));
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2418});
      }
      default: return heff_nomatch(v_x2_2416);
      }
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2emakeEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2emakeEach(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2emakeEach_lam0(V self, V *args) {
  V v_s_249 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_249});
}
Clo g_heff_2ecompile_2esimplify_2eonceEach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eonceEach_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eonceEach(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), v_seen_240));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_x_242), NTAG(TAG_MkUnit), v_seen_240));
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2esimplify_2eonceEach(v_t_245, v_xs_243))});
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2eonceEach_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eonceEach(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2edoneOf_str0, 0, "");
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2edoneOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2edoneOf_entry, 4, 0};

V g_heff_2ecompile_2esimplify_2edoneOf(V v_s_240, V v_d_241, V v_b_242, V v_t_243) {
top: ;
  V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(heff_rfield(v_d_241, 0)), heff_rfield(v_s_240, 3)));
  V v_t_246;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    v_t_246 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  V v_t_248 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_247));
  V v_t_2414 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2edoneOf_lam0, 1, 1, (V[]){v_s_240}), v_t_248));
  return heff_rec_n(4, shape_key__body__safe__touched, (V[]){heff_get_n(v_d_241, 0, 3), v_b_242, v_t_246, v_t_2414});
}
V g_heff_2ecompile_2esimplify_2edoneOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2edoneOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2esimplify_2edoneOf_lam0(V self, V *args) {
  V v_h_249 = args[0];
  V v_s_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = heff_get_n(heff_get_n(v_s_240, 8, 9), 0, 5);
  V v_x2_2411 = ({ V a_0 = heff_dup(v_h_249); V a_1 = v_t_2410; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2413;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nothing: {
    v_t_2413 = ((V)&g_heff_2ecompile_2esimplify_2edoneOf_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    heff_take_n(v_x2_2411, 1ULL, 1);
    v_t_2413 = v_x_2412;
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_249, v_t_2413});
}
Clo g_heff_2ecompile_2esimplify_2eoneDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneDef_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eoneDef(V v_d_240, V v_s_241) {
top: ;
  V v_t_242 = (g_heff_2ecompile_2esimplify_2eownSt(v_s_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_MkPair: {
    V v_s_244 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24MkPair = heff_take_reuse_n(v_t_242, 2ULL, 2);
    V v_k_245 = heff_take_field(v_s_244, 8);
    V v_t_246 = ({ V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_n(v_k_245, 27ULL, 5, shape_vers__kept__touched__fresh__madeFresh); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_247 = ({ V rv_8 = v_t_246; V rr_ = heff_rec_reuse_n(v_s_244, 255ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 8) = rv_8; rr_; });
    V v_x2_248 = heff_tag_at_n(v_ru_24t_242_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_247});
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_s_2410 = heff_field(v_x2_248, 1);
      V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 2ULL, 2);
      V v_m_2411 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), heff_dup(heff_rfield(v_d_240, 2))));
      V v_x2_2412 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_s_2410}));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_x_2413 = heff_field(v_x2_2412, 0);
        V v_s_2414 = heff_field(v_x2_2412, 1);
        V v_ru_24x2_2412_24MkPair = heff_take_reuse_n(v_x2_2412, 3ULL, 2);
        V v_m_2415 = (g_heff_2ecompile_2esimplify_2esimpF(heff_dup(g_heff_2ecompile_2esimplify_2esk_get()), v_x_2413));
        V v_x2_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_s_2414}));
        switch (heff_tag_of(v_x2_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x2_2416, 0);
          V v_s_2418 = heff_field(v_x2_2416, 1);
          V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
          V v_x2_2419 = (g_heff_2ecompile_2esimplify_2eraise(v_x_2417, v_s_2418));
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_MkPair: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_s_2421 = heff_field(v_x2_2419, 1);
            V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
            V v_x2_2422 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(heff_rfield(v_d_240, 0)), heff_dup(v_x_2420), heff_dup(v_s_2421)));
            switch (heff_tag_of(v_x2_2422)) {
            case TAG_MkPair: {
              V v_s_2424 = heff_field(v_x2_2422, 1);
              heff_take_n(v_x2_2422, 2ULL, 2);
              V v_x2_2425 = (g_heff_2ecompile_2esimplify_2emarkSafe(heff_dup(heff_rfield(v_d_240, 0)), v_x_2420, v_s_2424));
              switch (heff_tag_of(v_x2_2425)) {
              case TAG_MkPair: {
                V v_s_2427 = heff_field(v_x2_2425, 1);
                heff_take_n(v_x2_2425, 2ULL, 2);
                V v_t_2428 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_2420)));
                V v_t_2429 = (g_heff_2ecompile_2eir_2enubI(v_t_2428));
                V v_x2_2430 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2429, heff_dup(v_s_2427)));
                switch (heff_tag_of(v_x2_2430)) {
                case TAG_MkPair: {
                  V v_x_2431 = heff_field(v_x2_2430, 0);
                  V v_s_2432 = heff_field(v_x2_2430, 1);
                  heff_take_n(v_x2_2430, 3ULL, 2);
                  V v_t_2433 = heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(heff_rfield(v_d_240, 0)), heff_dup(heff_rfield(v_d_240, 1)), heff_dup(v_x_2420)});
                  V v_t_2434 = heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
                  V v_t_2435 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2431, v_t_2434));
                  V v_t_2436 = heff_get_n(heff_get_n(v_s_2421, 8, 9), 2, 5);
                  V v_t_2437 = (g_heff_2ecompile_2esimplify_2edoneOf(v_s_2427, v_d_240, v_x_2420, v_t_2436));
                  V v_t_2438 = heff_tag_at_n(v_ru_24x2_2412_24MkPair, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
                  V v_x_2439 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2435, v_t_2438});
                  return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){v_x_2439, v_s_2432});
                }
                default: return heff_nomatch(v_x2_2430);
                }
              }
              default: return heff_nomatch(v_x2_2425);
              }
            }
            default: return heff_nomatch(v_x2_2422);
            }
          }
          default: return heff_nomatch(v_x2_2419);
          }
        }
        default: return heff_nomatch(v_x2_2416);
        }
      }
      default: return heff_nomatch(v_x2_2412);
      }
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2esimplify_2eoneDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneDef(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esafeAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esafeAs_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2esafeAs(V v_x1_240, V v_k_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_True: {
    V v_t_243 = (g_map_2einsert_24s1341440536x470972936(v_k_241, NTAG(TAG_MkUnit), heff_take_field(v_p_242, 3)));
    V v_t_244 = ({ V rv_3 = v_t_243; V rr_ = heff_rec_reuse_n(v_p_242, 503ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_t_244});
  }
  case TAG_False: {
    heff_drop(v_k_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2esafeAs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2esafeAs(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2esimplify_2ereplayBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayBody_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayBody(V v_k_240, V v_b0_241, V v_s_242) {
top: ;
  V v_x2_243 = (g_heff_2ecompile_2esimplify_2ecopy(v_b0_241, v_s_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_s_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24MkPair = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_x2_246 = (g_heff_2ecompile_2esimplify_2erecordDef(heff_dup(heff_rfield(v_k_240, 0)), heff_dup(v_x_244), v_s_245));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_s_248 = heff_field(v_x2_246, 1);
      V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 2ULL, 2);
      V v_x2_249 = (g_heff_2ecompile_2esimplify_2esafeAs(heff_rfield(v_k_240, 3), heff_dup(heff_rfield(v_k_240, 0)), v_s_248));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_s_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 2ULL, 2);
        V v_t_2412 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_244)));
        V v_t_2413 = (g_heff_2ecompile_2eir_2enubI(v_t_2412));
        V v_x2_2414 = (g_heff_2ecompile_2esimplify_2emakeEach(v_t_2413, v_s_2411));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x2_2414, 0);
          V v_s_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_t_2417 = heff_rec_n(3, shape_key__name__body, (V[]){heff_take_field(v_k_240, 0), heff_get_n(v_k_240, 1, 7), v_x_244});
          V v_t_2418 = heff_tag_at_n(v_ru_24x2_243_24MkPair, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
          V v_x_2419 = (g_heff_2ecompile_2esimplify_2eappendL(v_x_2415, v_t_2418));
          return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_2419, v_s_2416});
        }
        default: return heff_nomatch(v_x2_2414);
        }
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayBody_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayBody(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2ereplayed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ereplayed_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2ereplayed(V v_k_240, V v_x2_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_k_240, 7);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_p_242});
  }
  case TAG_Just: {
    V v_b0_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eallAsked(heff_dup(heff_rfield(v_k_240, 4)), v_p_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      V v_ru_24x2_244_24MkPair = heff_take_reuse_n(v_x2_244, 3ULL, 2);
      switch (heff_tag_of(v_x_245)) {
      case TAG_True: {
        V v_x2_247 = (g_heff_2ecompile_2esimplify_2ereplayBody(v_k_240, v_b0_243, v_s_246));
        switch (heff_tag_of(v_x2_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x2_247, 0);
          V v_s_249 = heff_field(v_x2_247, 1);
          heff_take_n(v_x2_247, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_248}), v_s_249});
        }
        default: return heff_nomatch(v_x2_247);
        }
      }
      case TAG_False: {
        heff_drop_rec(v_k_240, 7);
        heff_drop(v_b0_243);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return heff_tag_at_n(v_ru_24x2_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_s_246});
      }
      default: return heff_nomatch(v_x_245);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2ereplayed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ereplayed(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2esimplify_2eafresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eafresh_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2eafresh(V v_x1_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_n_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop(v_n_243);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_p_241});
    }
    case TAG_Just: {
      V v_d_245 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24MkPair, 2);
      V v_t_246 = ({ V rv_0 = v_n_243; V rr_ = heff_rec_reuse_n(v_p_241, 510ULL, 9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp); heff_rfield(rr_, 0) = rv_0; rr_; });
      HEFF_LAST return g_heff_2ecompile_2esimplify_2eoneDef(v_d_245, v_t_246);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eafresh_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eafresh(a[0], a[1]);
}
V g_heff_2ecompile_2esimplify_2eoneItem_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2eoneItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2eoneItem_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2eoneItem(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Fresh: {
    V v_d_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tail(((V)&g_heff_2ecompile_2esimplify_2eoneDef_clo), 1, (V[]){v_d_241});
  }
  case TAG_Kept: {
    V v_k_242 = heff_field(v_x1_240, 0);
    V v_redo_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_clo_n(g_heff_2ecompile_2esimplify_2eoneItem_lam0, 1, 2, (V[]){v_k_242, v_redo_243});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2eoneItem_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2eoneItem(a[0]);
}
V g_heff_2ecompile_2esimplify_2eoneItem_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_redo_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_242, 2)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x2_246 = (g_heff_2ecompile_2esimplify_2ereplayed(v_k_242, v_t_245, heff_dup(v_s_244)));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    switch (heff_tag_of(v_x_247)) {
    case TAG_Nothing: {
      heff_drop(v_s_248);
      heff_drop_cell(v_ru_24x2_246_24MkPair, 2);
      V v_t_249 = heff_tr(heff_call(v_redo_243, 1, (V[]){heff_dup(heff_rfield(v_s_244, 0))}));
      return (g_heff_2ecompile_2esimplify_2eafresh(v_t_249, v_s_244));
    }
    case TAG_Just: {
      V v_ds_2410 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 1);
      heff_drop_rec(v_s_244, 9);
      heff_drop(v_redo_243);
      V v_t_2411 = heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){v_ds_2410, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_s_248});
    }
    default: return heff_nomatch(v_x_247);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
Clo g_heff_2ecompile_2esimplify_2econcatDefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2econcatDefs_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2econcatDefs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ds_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2econcatDefs(v_rest_242));
    return (g_heff_2ecompile_2esimplify_2eappendL(heff_dup(v_ds_241), v_t_243));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2econcatDefs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2esimplify_2econcatDefs(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2esimplify_2emadeOf_str1, 0, "");
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2emadeOf_entry, 3, 0};

V g_heff_2ecompile_2esimplify_2emadeOf(V v_st_240, V v_bodies_241, V v_h_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_244 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_243; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_243); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_t_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
    V v_t_247 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_246));
    V v_tv_2413 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2emadeOf_lam0, 1, 1, (V[]){v_st_240}), v_t_247));
    V v_x2_2414 = (g_map_2elookup_24s1546226666x2146984184(v_h_242, v_bodies_241));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      heff_drop(v_tv_2413);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_b_2415 = heff_field(v_x2_2414, 0);
      heff_take_n(v_x2_2414, 1ULL, 1);
      V v_t_2416 = (g_list_2eall_24s455618083x1946283732(((V)&g_heff_2ecompile_2esimplify_2emadeOf_str1), v_tv_2413));
      switch (heff_tag_of(v_t_2416)) {
      case TAG_True: {
        return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2415, v_tv_2413})});
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        heff_drop(v_tv_2413);
        heff_drop(v_b_2415);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_t_2416);
      }
    }
    default: return heff_nomatch(v_x2_2414);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2esimplify_2emadeOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2emadeOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2emadeOf_lam0(V self, V *args) {
  V v_h_248 = args[0];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_get_n(heff_get_n(v_st_240, 8, 9), 0, 5);
  V v_x2_2410 = ({ V a_0 = heff_dup(v_h_248); V a_1 = v_t_249; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2412;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nothing: {
    v_t_2412 = ((V)&g_heff_2ecompile_2esimplify_2emadeOf_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    heff_take_n(v_x2_2410, 1ULL, 1);
    v_t_2412 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_h_248, v_t_2412});
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopyWith_str0, 0, "");
Clo g_heff_2ecompile_2esimplify_2ecopyWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopyWith_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2ecopyWith(V v_st_240, V v_bodies_241, V v_h_242, V v_v_243, V v_r_244) {
top: ;
  if (heff_strEq_c(heff_dup(v_v_243), ((V)&g_heff_2ecompile_2esimplify_2ecopyWith_str0))) {
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_h_242);
    heff_drop(v_v_243);
    heff_drop(v_r_244);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 3, 7);
    V v_x2_247 = ({ V a_0 = heff_dup(v_h_242); V a_1 = v_t_246; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_249;
    switch (heff_tag_of(v_x2_247)) {
    case TAG_Nothing: {
      v_t_249 = MK_INT(0LL);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_x2_247, 0);
      heff_take_n(v_x2_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_x2_247);
    }
    V v_x3_2410 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_h_242), heff_rfield(v_st_240, 4)));
    V v_t_2412;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_2410, 0ULL, 1);
      v_t_2412 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x3_2410);
    }
    V v_t_2413 = (g_heff_2ecompile_2esimplify_2emadeOf(v_st_240, v_bodies_241, heff_dup(v_h_242)));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(6, shape_name__ver__recipe__depth__safe__made, (V[]){v_h_242, v_v_243, v_r_244, v_t_249, v_t_2412, v_t_2413})});
  }
}
V g_heff_2ecompile_2esimplify_2ecopyWith_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopyWith(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2esimplify_2ecatMaybesS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecatMaybesS_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2ecatMaybesS(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_rest_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2esimplify_2ecatMaybesS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2ecatMaybesS(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2esimplify_2ecopiesDone_str0, 0, "");
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2ecopiesDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2ecopiesDone_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2ecopiesDone(V v_st_240, V v_defs_241) {
top: ;
  V v_bodies_242 = (g_list_2efoldl_24s91733047x1482905949(heff_dup(g_map_2eempty_get()), v_defs_241));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 3, 5);
  V v_t_244 = ({ V a_0 = v_t_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_243); r_; });
  V v_t_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 4, 5);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_list_2emap_24s1937570095x2110149801(v_t_247));
  V v_t_249 = (g_prelude_2e_2b_2b(v_t_245, v_t_248));
  V v_t_2410 = (g_heff_2ecompile_2esimplify_2eonceEach(heff_dup(g_map_2eempty_get()), v_t_249));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2esimplify_2ecopiesDone_lam0, 1, 2, (V[]){v_st_240, v_bodies_242}), v_t_2410));
  return (g_heff_2ecompile_2esimplify_2ecatMaybesS(v_t_2419));
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2ecopiesDone(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2ecopiesDone_lam0(V self, V *args) {
  V v_h_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bodies_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_st_240, 7)), 2, 7);
  V v_t_2413 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2412; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_h_2411);
    heff_drop_rec(v_st_240, 9);
    heff_drop(v_bodies_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_r_2414 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2415 = heff_get_n(heff_dup(heff_rfield(v_st_240, 8)), 0, 5);
    V v_x2_2416 = ({ V a_0 = heff_dup(v_h_2411); V a_1 = v_t_2415; V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, a_1)); heff_drop(v_t_2415); r_; });
    V v_t_2418;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nothing: {
      v_t_2418 = ((V)&g_heff_2ecompile_2esimplify_2ecopiesDone_str0);
      break;
    }
    case TAG_Just: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return ({ V a_0 = v_st_240; V a_1 = v_bodies_242; V a_2 = v_h_2411; V a_3 = v_t_2418; V a_4 = v_r_2414; V r_ = (g_heff_2ecompile_2esimplify_2ecopyWith(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bodies_242); r_; });
  }
  default: return heff_nomatch(v_t_2413);
  }
}
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_p_241});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2ecompile_2esimplify_2eoneDef(v_x_242, v_p_241));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_s_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      V v_x2_247 = (g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(v_xs_243, v_s_246));
      switch (heff_tag_of(v_x2_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_s_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_x_248}), v_s_249});
      }
      default: return heff_nomatch(v_x2_247);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esimplifyProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyProgram_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esimplifyProgram(V v_n0_240, V v_defs_241) {
top: ;
  V v_sg_242 = (g_list_2efoldl_24s1948306825x2028893715(heff_rec_n(2, shape_safe__total, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())}), v_defs_241));
  V v_t_243 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_244 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_sg_242, 0)), heff_dup(heff_rfield(v_sg_242, 0)), heff_get_n(v_sg_242, 1, 2), heff_dup(g_map_2eempty_get()), v_t_243, heff_dup(g_heff_2ecompile_2esimplify_2enoKeep_get())});
  V v_x1_245 = (g_heff_2ecompile_2esimplify_2etraverseS_24s212709335x1942172582(v_defs_241, v_t_244));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_out_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    V v_t_248 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_246)));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_248); r_; });
    V v_t_2410 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_246)));
    V v_t_2411 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2410); r_; });
    V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(v_out_246));
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = ({ V a_0 = heff_dup(v_st_247); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2413); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_249, heff_get_n(v_st_247, 0, 9), v_t_2411, v_t_2414});
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyProgram(a[0], a[1]);
}
Clo g_heff_2ecompile_2esimplify_2esgItem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esgItem_entry, 2, 0};

V g_heff_2ecompile_2esimplify_2esgItem(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Fresh: {
    V v_d_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_heff_2ecompile_2esimplify_2eflat(heff_dup(heff_rfield(v_d_242, 2))));
    return ({ V a_0 = v_acc_240; V a_1 = heff_dup(heff_rfield(v_d_242, 0)); V a_2 = v_t_243; V r_ = (g_heff_2ecompile_2esimplify_2esgFlat(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  }
  case TAG_Kept: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_t_246 = heff_dup(heff_rfield(v_k_244, 5));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_k_244, 0)), NTAG(TAG_MkUnit), heff_dup(heff_rfield(v_acc_240, 0))));
      break;
    }
    case TAG_False: {
      v_t_247 = heff_dup(heff_rfield(v_acc_240, 0));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_249;
    if (heff_intLe_c(MK_INT(0LL), heff_dup(heff_rfield(v_k_244, 6)))) {
      v_t_249 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_k_244, 0)), heff_dup(heff_rfield(v_k_244, 6)), heff_get_n(v_acc_240, 1, 2)));
    } else {
      v_t_249 = heff_get_n(v_acc_240, 1, 2);
    }
    return heff_rec_n(2, shape_safe__total, (V[]){v_t_247, v_t_249});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2esimplify_2esgItem_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2esimplify_2esgItem(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0(V self, V *args); static Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0, 1, 0};
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam1(V self, V *args);
Clo g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry, 1, 0};

V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = heff_tr(g_heff_2ecompile_2esimplify_2eoneItem(v_x_242));
    return heff_clo_n(g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(a[0]);
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam0(V self, V *args) {
  V v_s_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_s_241});
}
V g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636_lam1(V self, V *args) {
  V v_s_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_s_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_s_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_s_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_s_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_s_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
Clo g_heff_2ecompile_2esimplify_2esimplifyItems_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2esimplify_2esimplifyItems_entry, 5, 0};

V g_heff_2ecompile_2esimplify_2esimplifyItems(V v_n0_240, V v_sg_241, V v_vers_242, V v_kept_243, V v_items_244) {
top: ;
  V v_t_245 = (g_heff_2ecompile_2esimplify_2etraverseS_24s600508957x1347989636(v_items_244));
  V v_t_246 = heff_rec_n(7, shape_all__kinds__recipes__depths__made__count__off, (V[]){heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), MK_INT(0LL), NTAG(TAG_False)});
  V v_t_247 = heff_rec_n(5, shape_vers__kept__touched__fresh__madeFresh, (V[]){v_vers_242, v_kept_243, NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get())});
  V v_t_248 = heff_rec_n(9, shape_supply__fuel__defs__safe__base__total__plain__sp__kp, (V[]){v_n0_240, MK_INT(0LL), heff_dup(g_map_2eempty_get()), heff_dup(heff_rfield(v_sg_241, 0)), heff_dup(heff_rfield(v_sg_241, 0)), heff_get_n(v_sg_241, 1, 2), heff_dup(g_map_2eempty_get()), v_t_246, v_t_247});
  V v_x1_249 = heff_tr(heff_call(v_t_245, 1, (V[]){v_t_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_out_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    heff_take_n(v_x1_249, 3ULL, 2);
    V v_t_2412 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_out_2410)));
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2412); r_; });
    V v_t_2414 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_out_2410)));
    V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2414); r_; });
    V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(v_out_2410));
    V v_t_2417 = ({ V a_0 = v_t_2416; V r_ = (g_heff_2ecompile_2esimplify_2econcatDefs(a_0)); heff_drop(v_t_2416); r_; });
    V v_t_2418 = ({ V a_0 = heff_dup(v_st_2411); V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2esimplify_2ecopiesDone(a_0, a_1)); heff_drop(v_t_2417); r_; });
    return heff_rec_n(4, shape_defs__supply__done__copies, (V[]){v_t_2413, heff_get_n(v_st_2411, 0, 9), v_t_2415, v_t_2418});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2ecompile_2esimplify_2esimplifyItems_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2esimplify_2esimplifyItems(a[0], a[1], a[2], a[3], a[4]);
}