// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2efmt_2etoks_2ecountNl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2ecountNl_entry, 3, 0};

V g_heff_2efmt_2etoks_2ecountNl(V v_s_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_intLe(heff_dup(v_b_242), heff_dup(v_a_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_a_241);
    heff_drop(v_b_242);
    heff_drop(v_t_243);
    return MK_INT(0LL);
  }
  case TAG_False: {
    heff_drop(v_t_243);
    V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_a_241)), MK_INT(10LL));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_t_244);
      v_t_245 = MK_INT(1LL);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_244);
      v_t_245 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V v_t_246 = (g_heff_2efmt_2etoks_2ecountNl(v_s_240, heff_intAdd(v_a_241, MK_INT(1LL)), v_b_242));
    return heff_intAdd(v_t_245, v_t_246);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2efmt_2etoks_2ecountNl_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2ecountNl(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2efmt_2etoks_2einlineAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 45}};
Clo g_heff_2efmt_2etoks_2einlineAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2einlineAt_entry, 3, 0};

V g_heff_2efmt_2etoks_2einlineAt(V v_elems_240, V v_k_241, V v_e_242) {
top: ;
  V v_t_243 = heff_strSlice(heff_get(heff_dup(v_e_242), LBL_text), MK_INT(0LL), MK_INT(2LL));
  V v_t_244 = heff_strEq(v_t_243, ((V)&g_heff_2efmt_2etoks_2einlineAt_str0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_t_244);
    V v_t_245 = heff_intLt(heff_intAdd(heff_dup(v_k_241), MK_INT(1LL)), heff_arrayLength(heff_dup(v_elems_240)));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_n_246 = heff_arrayIndex(v_elems_240, heff_intAdd(v_k_241, MK_INT(1LL)));
      V v_t_247 = heff_get(heff_dup(v_n_246), LBL_tok);
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop(v_e_242);
        heff_drop(v_n_246);
        heff_drop(v_t_247);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        heff_take(v_t_247, 0ULL);
        return heff_intEq(heff_get(v_n_246, LBL_startLine), heff_get(v_e_242, LBL_endLine));
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_False: {
      heff_drop(v_elems_240);
      heff_drop(v_k_241);
      heff_drop(v_e_242);
      heff_drop(v_t_245);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_False: {
    heff_drop(v_elems_240);
    heff_drop(v_k_241);
    heff_drop(v_e_242);
    heff_drop(v_t_244);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2efmt_2etoks_2einlineAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2einlineAt(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2efmt_2etoks_2estepTok_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
Clo g_heff_2efmt_2etoks_2estepTok_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2estepTok_entry, 5, 0};

V g_heff_2efmt_2etoks_2estepTok(V v_src_240, V v_st_241, V v_e_242, V v_blank_243, V v_t_244) {
top: ;
  V v_t_245 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_n), MK_INT(1LL));
  V v_t_246 = heff_strEq(heff_get(heff_dup(v_t_244), LBL_kind), ((V)&g_heff_2efmt_2etoks_2estepTok_str0));
  V v_t_2411;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_t_246);
    V v_s_247 = heff_strSlice(v_src_240, heff_get(heff_dup(v_t_244), LBL_start), heff_get(heff_dup(v_t_244), LBL_end));
    V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), MK_INT(0LL), MK_INT(1LL)));
    V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_s_247)), MK_INT(1LL));
    V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), v_t_249, MK_INT(-1LL)));
    v_t_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
    break;
  }
  case TAG_False: {
    heff_drop(v_t_246);
    v_t_2411 = heff_strSlice(v_src_240, heff_get(heff_dup(v_t_244), LBL_start), heff_get(heff_dup(v_t_244), LBL_end));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2412 = heff_rec(9, shape_147_321_254_305_78_45_96_142_24, (V[]){heff_get(heff_dup(v_t_244), LBL_kind), heff_get(heff_dup(v_t_244), LBL_text), v_t_2411, heff_get(heff_dup(v_t_244), LBL_start), heff_get(heff_dup(v_t_244), LBL_end), heff_get(heff_dup(v_t_244), LBL_col), heff_get(v_t_244, LBL_first), heff_get(heff_dup(v_st_241), LBL_n), v_blank_243});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, heff_get(heff_dup(v_st_241), LBL_toks)});
  V v_t_2414 = heff_get(heff_dup(v_st_241), LBL_pending);
  V v_t_2418;
  switch (heff_tag_of(v_t_2414)) {
  case TAG_Nil: {
    heff_drop(v_t_2414);
    v_t_2418 = heff_get(heff_dup(v_st_241), LBL_lead);
    break;
  }
  case TAG_Cons: {
    heff_take(v_t_2414, 0ULL);
    V v_t_2417 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_st_241), LBL_pending)));
    v_t_2418 = (g_map_2einsert_24s214(heff_get(heff_dup(v_st_241), LBL_n), v_t_2417, heff_get(heff_dup(v_st_241), LBL_lead)));
    break;
  }
  default: heff_nomatch(v_t_2414);
  }
  V v_t_2419 = heff_get(heff_dup(v_st_241), LBL_inl);
  V v_t_2423;
  switch (heff_tag_of(v_t_2419)) {
  case TAG_Nil: {
    heff_drop(v_t_2419);
    v_t_2423 = heff_get(heff_dup(v_st_241), LBL_inline);
    break;
  }
  case TAG_Cons: {
    heff_take(v_t_2419, 0ULL);
    V v_t_2422 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_st_241), LBL_inl)));
    v_t_2423 = (g_map_2einsert_24s214(heff_get(heff_dup(v_st_241), LBL_n), v_t_2422, heff_get(heff_dup(v_st_241), LBL_inline)));
    break;
  }
  default: heff_nomatch(v_t_2419);
  }
  V v_t_2424 = heff_rec(2, shape_142_167, (V[]){heff_get(heff_dup(v_st_241), LBL_n), heff_get(heff_dup(v_e_242), LBL_endLine)});
  V v_t_2425 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_k), MK_INT(1LL));
  return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_242, LBL_endLine), v_t_245, v_t_2413, NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_2418, v_t_2423, heff_get(v_st_241, LBL_trail), heff_tag(TAG_Just, 1, (V[]){v_t_2424}), v_t_2425});
}
V g_heff_2efmt_2etoks_2estepTok_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2estepTok(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2efmt_2etoks_2estepTrail_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2efmt_2etoks_2estepTrail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2estepTrail_entry, 3, 0};

V g_heff_2efmt_2etoks_2estepTrail(V v_st_240, V v_e_241, V v_lt_242) {
top: ;
  V v_m_243 = heff_get(heff_dup(v_st_240), LBL_trail);
  V v_ix_244 = heff_get(heff_dup(v_lt_242), LBL_ix);
  V v_text_245 = heff_get(heff_dup(v_e_241), LBL_text);
  V v_t_246 = (g_map_2elookup_24s12(heff_dup(v_ix_244), v_m_243));
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    heff_drop(v_t_246);
    v_t_249 = (g_map_2einsert_24s214(v_ix_244, v_text_245, v_m_243));
    break;
  }
  case TAG_Just: {
    V v_old_247 = heff_field(v_t_246, 0);
    heff_take(v_t_246, 1ULL);
    V v_t_248 = heff_strAppend(v_old_247, heff_strAppend(((V)&g_heff_2efmt_2etoks_2estepTrail_str0), v_text_245));
    v_t_249 = (g_map_2einsert_24s214(v_ix_244, v_t_248, v_m_243));
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_t_2410 = heff_rec(2, shape_142_167, (V[]){heff_get(v_lt_242, LBL_ix), heff_get(heff_dup(v_e_241), LBL_endLine)});
  V v_t_2411 = heff_intAdd(heff_get(heff_dup(v_st_240), LBL_k), MK_INT(1LL));
  return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_241, LBL_endLine), heff_get(heff_dup(v_st_240), LBL_n), heff_get(heff_dup(v_st_240), LBL_toks), heff_get(heff_dup(v_st_240), LBL_pending), heff_get(heff_dup(v_st_240), LBL_inl), heff_get(heff_dup(v_st_240), LBL_lead), heff_get(v_st_240, LBL_inline), v_t_249, heff_tag(TAG_Just, 1, (V[]){v_t_2410}), v_t_2411});
}
V g_heff_2efmt_2etoks_2estepTrail_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2estepTrail(a[0], a[1], a[2]);
}
Clo g_heff_2efmt_2etoks_2estepCmt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2estepCmt_entry, 4, 0};

V g_heff_2efmt_2etoks_2estepCmt(V v_elems_240, V v_st_241, V v_e_242, V v_blank_243) {
top: ;
  V v_t_244 = (g_heff_2efmt_2etoks_2einlineAt(v_elems_240, heff_get(heff_dup(v_st_241), LBL_k), heff_dup(v_e_242)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_blank_243);
    heff_drop(v_t_244);
    V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_get(heff_dup(v_e_242), LBL_text), heff_get(heff_dup(v_st_241), LBL_inl)});
    V v_t_246 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_k), MK_INT(1LL));
    return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_242, LBL_endLine), heff_get(heff_dup(v_st_241), LBL_n), heff_get(heff_dup(v_st_241), LBL_toks), heff_get(heff_dup(v_st_241), LBL_pending), v_t_245, heff_get(heff_dup(v_st_241), LBL_lead), heff_get(heff_dup(v_st_241), LBL_inline), heff_get(heff_dup(v_st_241), LBL_trail), heff_get(v_st_241, LBL_lastTok), v_t_246});
  }
  case TAG_False: {
    heff_drop(v_t_244);
    V v_t_247 = heff_get(heff_dup(v_st_241), LBL_lastTok);
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop(v_t_247);
      V v_t_248 = heff_rec(2, shape_321_24, (V[]){heff_get(heff_dup(v_e_242), LBL_text), v_blank_243});
      V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_t_248, heff_get(heff_dup(v_st_241), LBL_pending)});
      V v_t_2410 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_k), MK_INT(1LL));
      return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_242, LBL_endLine), heff_get(heff_dup(v_st_241), LBL_n), heff_get(heff_dup(v_st_241), LBL_toks), v_t_249, heff_get(heff_dup(v_st_241), LBL_inl), heff_get(heff_dup(v_st_241), LBL_lead), heff_get(heff_dup(v_st_241), LBL_inline), heff_get(heff_dup(v_st_241), LBL_trail), heff_get(v_st_241, LBL_lastTok), v_t_2410});
    }
    case TAG_Just: {
      V v_lt_2411 = heff_field(v_t_247, 0);
      heff_take(v_t_247, 1ULL);
      V v_t_2412 = heff_intEq(heff_get(heff_dup(v_lt_2411), LBL_line), heff_get(heff_dup(v_e_242), LBL_startLine));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_True: {
        heff_drop(v_t_2412);
        V v_t_2413 = heff_get(heff_dup(v_st_241), LBL_pending);
        switch (heff_tag_of(v_t_2413)) {
        case TAG_Nil: {
          heff_drop(v_t_2413);
          V v_t_2414 = heff_get(heff_dup(v_st_241), LBL_inl);
          switch (heff_tag_of(v_t_2414)) {
          case TAG_Nil: {
            heff_drop(v_blank_243);
            heff_drop(v_t_2414);
            return (g_heff_2efmt_2etoks_2estepTrail(v_st_241, v_e_242, v_lt_2411));
          }
          case TAG_Cons: {
            V v_ru_24t_2414_24Cons = heff_take_reuse(v_t_2414, 0ULL);
            heff_drop(v_lt_2411);
            V v_t_2417 = heff_rec(2, shape_321_24, (V[]){heff_get(heff_dup(v_e_242), LBL_text), v_blank_243});
            V v_t_2418 = heff_tag_at(v_ru_24t_2414_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_get(heff_dup(v_st_241), LBL_pending)});
            V v_t_2419 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_k), MK_INT(1LL));
            return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_242, LBL_endLine), heff_get(heff_dup(v_st_241), LBL_n), heff_get(heff_dup(v_st_241), LBL_toks), v_t_2418, heff_get(heff_dup(v_st_241), LBL_inl), heff_get(heff_dup(v_st_241), LBL_lead), heff_get(heff_dup(v_st_241), LBL_inline), heff_get(heff_dup(v_st_241), LBL_trail), heff_get(v_st_241, LBL_lastTok), v_t_2419});
          }
          default: return heff_nomatch(v_t_2414);
          }
        }
        case TAG_Cons: {
          V v_ru_24t_2413_24Cons = heff_take_reuse(v_t_2413, 0ULL);
          heff_drop(v_lt_2411);
          V v_t_2422 = heff_rec(2, shape_321_24, (V[]){heff_get(heff_dup(v_e_242), LBL_text), v_blank_243});
          V v_t_2423 = heff_tag_at(v_ru_24t_2413_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_get(heff_dup(v_st_241), LBL_pending)});
          V v_t_2424 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_k), MK_INT(1LL));
          return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_242, LBL_endLine), heff_get(heff_dup(v_st_241), LBL_n), heff_get(heff_dup(v_st_241), LBL_toks), v_t_2423, heff_get(heff_dup(v_st_241), LBL_inl), heff_get(heff_dup(v_st_241), LBL_lead), heff_get(heff_dup(v_st_241), LBL_inline), heff_get(heff_dup(v_st_241), LBL_trail), heff_get(v_st_241, LBL_lastTok), v_t_2424});
        }
        default: return heff_nomatch(v_t_2413);
        }
      }
      case TAG_False: {
        heff_drop(v_lt_2411);
        heff_drop(v_t_2412);
        V v_t_2425 = heff_rec(2, shape_321_24, (V[]){heff_get(heff_dup(v_e_242), LBL_text), v_blank_243});
        V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2425, heff_get(heff_dup(v_st_241), LBL_pending)});
        V v_t_2427 = heff_intAdd(heff_get(heff_dup(v_st_241), LBL_k), MK_INT(1LL));
        return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){heff_get(v_e_242, LBL_endLine), heff_get(heff_dup(v_st_241), LBL_n), heff_get(heff_dup(v_st_241), LBL_toks), v_t_2426, heff_get(heff_dup(v_st_241), LBL_inl), heff_get(heff_dup(v_st_241), LBL_lead), heff_get(heff_dup(v_st_241), LBL_inline), heff_get(heff_dup(v_st_241), LBL_trail), heff_get(v_st_241, LBL_lastTok), v_t_2427});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2efmt_2etoks_2estepCmt_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2estepCmt(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2efmt_2etoks_2estep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2estep_entry, 4, 0};

V g_heff_2efmt_2etoks_2estep(V v_src_240, V v_elems_241, V v_st_242, V v_e_243) {
top: ;
  V v_t_244 = heff_get(heff_dup(v_e_243), LBL_tok);
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_src_240);
    heff_drop(v_t_244);
    V v_t_245 = heff_intLe(MK_INT(0LL), heff_get(heff_dup(v_st_242), LBL_prevEnd));
    V v_t_247;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_t_245);
      V v_t_246 = heff_intSub(heff_get(heff_dup(v_e_243), LBL_startLine), heff_get(heff_dup(v_st_242), LBL_prevEnd));
      v_t_247 = heff_intLe(MK_INT(2LL), v_t_246);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      v_t_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    return (g_heff_2efmt_2etoks_2estepCmt(v_elems_241, v_st_242, v_e_243, v_t_247));
  }
  case TAG_Just: {
    V v_t_248 = heff_field(v_t_244, 0);
    heff_take(v_t_244, 1ULL);
    heff_drop(v_elems_241);
    V v_t_249 = heff_intLe(MK_INT(0LL), heff_get(heff_dup(v_st_242), LBL_prevEnd));
    V v_t_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_t_249);
      V v_t_2410 = heff_intSub(heff_get(heff_dup(v_e_243), LBL_startLine), heff_get(heff_dup(v_st_242), LBL_prevEnd));
      v_t_2411 = heff_intLe(MK_INT(2LL), v_t_2410);
      break;
    }
    case TAG_False: {
      heff_drop(v_t_249);
      v_t_2411 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    return (g_heff_2efmt_2etoks_2estepTok(v_src_240, v_st_242, v_e_243, v_t_2411, v_t_248));
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2efmt_2etoks_2estep_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2estep(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2efmt_2etoks_2elineElem_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2elineElem_entry, 3, 0};

V g_heff_2efmt_2etoks_2elineElem(V v_src_240, V v_acc_241, V v_e_242) {
top: ;
  V v_t_243 = (g_heff_2efmt_2etoks_2ecountNl(heff_dup(v_src_240), heff_get(heff_dup(v_acc_241), LBL_offset), heff_get(heff_dup(v_e_242), LBL_start)));
  V v_t_244 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_line), v_t_243);
  V v_t_245 = (g_heff_2efmt_2etoks_2ecountNl(heff_dup(v_src_240), heff_get(heff_dup(v_e_242), LBL_start), heff_get(heff_dup(v_e_242), LBL_end)));
  V v_t_246 = (g_heff_2efmt_2etoks_2ecountNl(heff_dup(v_src_240), heff_get(heff_dup(v_acc_241), LBL_offset), heff_get(heff_dup(v_e_242), LBL_start)));
  V v_t_247 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_line), v_t_246);
  V v_t_248 = (g_heff_2efmt_2etoks_2ecountNl(heff_dup(v_src_240), heff_get(heff_dup(v_acc_241), LBL_offset), heff_get(heff_dup(v_e_242), LBL_start)));
  V v_t_249 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_line), v_t_248);
  V v_t_2410 = (g_heff_2efmt_2etoks_2ecountNl(v_src_240, heff_get(heff_dup(v_e_242), LBL_start), heff_get(heff_dup(v_e_242), LBL_end)));
  V v_t_2411 = heff_rec(6, shape_305_78_325_321_306_79, (V[]){heff_get(heff_dup(v_e_242), LBL_start), heff_get(heff_dup(v_e_242), LBL_end), heff_get(heff_dup(v_e_242), LBL_tok), heff_get(heff_dup(v_e_242), LBL_text), v_t_247, heff_intAdd(v_t_249, v_t_2410)});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, heff_get(v_acc_241, LBL_out)});
  return heff_rec(3, shape_167_202_214, (V[]){heff_intAdd(v_t_244, v_t_245), heff_get(v_e_242, LBL_end), v_t_2412});
}
V g_heff_2efmt_2etoks_2elineElem_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2elineElem(a[0], a[1], a[2]);
}

static V g_heff_2efmt_2etoks_2eemptyStA_val;
static int g_heff_2efmt_2etoks_2eemptyStA_st;
static V g_heff_2efmt_2etoks_2eemptyStA_init(void) {
  return heff_rec(10, shape_243_189_327_232_135_158_136_332_155_144, (V[]){MK_INT(-1LL), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nothing), MK_INT(0LL)});
}
V g_heff_2efmt_2etoks_2eemptyStA_get(void) {
  if (g_heff_2efmt_2etoks_2eemptyStA_st == 2) return g_heff_2efmt_2etoks_2eemptyStA_val;
  if (g_heff_2efmt_2etoks_2eemptyStA_st == 1) heff_fail("defined by itself");
  g_heff_2efmt_2etoks_2eemptyStA_st = 1;
  g_heff_2efmt_2etoks_2eemptyStA_val = heff_tr(g_heff_2efmt_2etoks_2eemptyStA_init());
  g_heff_2efmt_2etoks_2eemptyStA_st = 2;
  return g_heff_2efmt_2etoks_2eemptyStA_val;
}
Clo g_heff_2efmt_2etoks_2eattach_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2eattach_entry, 3, 0};

V g_heff_2efmt_2etoks_2eattach(V v_src_240, V v_toks_241, V v_comments_242) {
top: ;
  V v_t_243 = (g_prelude_2emap_24s217(v_toks_241));
  V v_t_244 = (g_prelude_2emap_24s218(v_comments_242));
  V v_t_245 = (g_prelude_2econcatList(v_t_243, v_t_244));
  V v_es_246 = (g_prelude_2esortBy_24s215(v_t_245));
  V v_t_247 = heff_tr(heff_apply(((V)&g_heff_2efmt_2etoks_2elineElem_clo), 1, (V[]){heff_dup(v_src_240)}));
  V v_t_248 = heff_rec(3, shape_167_202_214, (V[]){MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)});
  V v_l_249 = ({ V a_0 = v_t_247; V a_1 = v_t_248; V a_2 = v_es_246; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_246); r_; });
  V v_xs_2410 = heff_get(v_l_249, LBL_out);
  V v_t_2411 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2410));
  V v_elems_2412 = heff_arrayFromList(v_t_2411);
  V v_t_2413 = heff_tr(heff_apply(((V)&g_heff_2efmt_2etoks_2estep_clo), 2, (V[]){heff_dup(v_src_240), heff_dup(v_elems_2412)}));
  V v_r_2414 = (g_array_2efoldlFrom(v_t_2413, MK_INT(0LL), heff_dup(g_heff_2efmt_2etoks_2eemptyStA_get()), v_elems_2412));
  V v_t_2415 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_get(heff_dup(v_r_2414), LBL_toks)));
  V v_t_2416 = heff_rec(7, shape_302_158_136_332_195_196_97, (V[]){v_src_240, heff_get(heff_dup(v_r_2414), LBL_lead), heff_get(heff_dup(v_r_2414), LBL_inline), heff_get(v_r_2414, LBL_trail), MK_INT(-1LL), MK_INT(-1LL), heff_dup(g_heff_2efixity_2eemptyFixities_get())});
  return heff_rec(2, shape_327_82, (V[]){heff_arrayFromList(v_t_2415), v_t_2416});
}
V g_heff_2efmt_2etoks_2eattach_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2eattach(a[0], a[1], a[2]);
}
Clo g_heff_2efmt_2etoks_2eplainGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2efmt_2etoks_2eplainGo_entry, 3, 0};

V g_heff_2efmt_2etoks_2eplainGo(V v_n_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_x3_242);
    return (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_Cons: {
    V v_t_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse(v_x3_242, 3ULL);
    V v_t_245 = heff_rec(9, shape_147_321_254_305_78_45_96_142_24, (V[]){heff_get(heff_dup(v_t_243), LBL_kind), heff_get(heff_dup(v_t_243), LBL_text), heff_get(heff_dup(v_t_243), LBL_text), heff_get(heff_dup(v_t_243), LBL_start), heff_get(heff_dup(v_t_243), LBL_end), heff_get(heff_dup(v_t_243), LBL_col), heff_get(v_t_243, LBL_first), heff_dup(v_n_240), NTAG(TAG_False)});
    V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
    V t_1 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_acc_241});
    V t_2 = v_rest_244;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2efmt_2etoks_2eplainGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2efmt_2etoks_2eplainGo(a[0], a[1], a[2]);
}