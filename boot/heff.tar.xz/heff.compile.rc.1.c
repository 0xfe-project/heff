// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_DefFun 38319
#define TAG_DefVal 53073
#define TAG_ICond 62625
#define TAG_IOp 20150
#define TAG_ISts 38700
#define TAG_ITl 20301
#define TAG_IVal 40987
#define TAG_KnownTag 34380
#define TAG_MkArm 55352
#define TAG_MkBlock 5679
#define TAG_MkDef 57825
#define TAG_OAbandon 25311
#define TAG_OApply 26324
#define TAG_OBool 4289
#define TAG_OCall 20533
#define TAG_OPrim 30905
#define TAG_OSimple 59809
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RBox 28228
#define TAG_RBytes 24984
#define TAG_RClo 29087
#define TAG_RDup 30328
#define TAG_RF32 30142
#define TAG_RFixed 35467
#define TAG_RFloat 50557
#define TAG_RGet 32719
#define TAG_RGetRaw 14078
#define TAG_RInt 34920
#define TAG_RLocal 34280
#define TAG_RNTag 26236
#define TAG_RPrim 49376
#define TAG_RPrimFn 2224
#define TAG_RRec 43273
#define TAG_RRecIn 34674
#define TAG_RStr 44714
#define TAG_RTag 45075
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SCase 45371
#define TAG_SDecl 12991
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SIf 29564
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SLet 1789
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSet 8516
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_after 294093302
#define LBL_arity 294440695
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_fixed 298804110
#define LBL_funs 9650075
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lent 9813446
#define LBL_op 10312
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_takes 311482598
#define LBL_workers 1757018875
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_ret};
V g_heff_2ecompile_2erc_2eagrees(V, V, V);
V g_heff_2ecompile_2erc_2eagrees_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eagrees_clo;
V g_heff_2ecompile_2erc_2echangedOf(V, V, V);
V g_heff_2ecompile_2erc_2echangedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2echangedOf_clo;
V g_heff_2ecompile_2erc_2ecoerce(V, V, V);
V g_heff_2ecompile_2erc_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecoerce_clo;
V g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(V, V, V, V);
V g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_clo;
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483(V, V, V, V, V);
V g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483_clo;
V g_heff_2ecompile_2erc_2eelemS(V, V);
V g_heff_2ecompile_2erc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemS_clo;
V g_heff_2ecompile_2erc_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erc_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efreeGo_clo;
V g_heff_2ecompile_2erc_2efreeOf(V, V);
V g_heff_2ecompile_2erc_2efreeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efreeOf_clo;
V g_heff_2ecompile_2erc_2efunRc(V, V, V, V);
V g_heff_2ecompile_2erc_2efunRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efunRc_clo;
V g_heff_2ecompile_2erc_2efvSts(V);
V g_heff_2ecompile_2erc_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvSts_clo;
V g_heff_2ecompile_2erc_2efvTl(V);
V g_heff_2ecompile_2erc_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvTl_clo;
V g_heff_2ecompile_2erc_2efvVal(V);
V g_heff_2ecompile_2erc_2efvVal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvVal_clo;
V g_heff_2ecompile_2erc_2efvW(V, V, V);
V g_heff_2ecompile_2erc_2efvW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvW_clo;
V g_heff_2ecompile_2erc_2eindexIn(V, V, V);
V g_heff_2ecompile_2erc_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eindexIn_clo;
V g_heff_2ecompile_2erc_2ejustsOf(V);
V g_heff_2ecompile_2erc_2ejustsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ejustsOf_clo;
V g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237(V, V);
V g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_clo;
V g_heff_2ecompile_2erc_2ekeptFrom(V, V);
V g_heff_2ecompile_2erc_2ekeptFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ekeptFrom_clo;
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780(V, V, V, V, V);
V g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780_clo;
V g_heff_2ecompile_2erc_2enaturalOf(V, V);
V g_heff_2ecompile_2erc_2enaturalOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2enaturalOf_clo;
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_clo;
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(V, V, V);
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_clo;
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps(V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps_clo;
V g_heff_2ecompile_2erc_2eoperandsOf(V);
V g_heff_2ecompile_2erc_2eoperandsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsOf_clo;
V g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_clo;
V g_heff_2ecompile_2erc_2ercDef(V, V, V);
V g_heff_2ecompile_2erc_2ercDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ercDef_clo;
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834(V, V, V, V, V);
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_clo;
V g_heff_2ecompile_2erc_2ereuseArgs(V, V);
V g_heff_2ecompile_2erc_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseArgs_clo;
V g_heff_2ecompile_2erc_2ereuseOp(V, V, V);
V g_heff_2ecompile_2erc_2ereuseOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseOp_clo;
V g_heff_2ecompile_2erc_2ereusePrim_get(void);
V g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(V, V, V);
V g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_clo;
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(V, V, V);
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_clo;
V g_heff_2ecompile_2erc_2ereuseV(V, V, V);
V g_heff_2ecompile_2erc_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseV_clo;
V g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416(V, V, V);
V g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416_clo;
V g_heff_2ecompile_2erc_2ereusedOf(V);
V g_heff_2ecompile_2erc_2ereusedOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereusedOf_clo;
V g_heff_2ecompile_2erc_2ereusing(V, V, V, V);
V g_heff_2ecompile_2erc_2ereusing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereusing_clo;
V g_heff_2ecompile_2erc_2esameAs(V, V, V);
V g_heff_2ecompile_2erc_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esameAs_clo;
V g_heff_2ecompile_2erc_2esameS(V, V);
V g_heff_2ecompile_2erc_2esameS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esameS_clo;
V g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178(V, V);
V g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_clo;
V g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_clo;
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_clo;
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_clo;
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702(V, V, V);
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_clo;
V g_heff_2ecompile_2erc_2etakeOne(V, V, V);
V g_heff_2ecompile_2erc_2etakeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakeOne_clo;
V g_heff_2ecompile_2erc_2etakeVar(V, V, V, V, V);
V g_heff_2ecompile_2erc_2etakeVar_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakeVar_clo;
V g_heff_2ecompile_2erc_2etakenFv(V, V, V, V);
V g_heff_2ecompile_2erc_2etakenFv_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakenFv_clo;
V g_heff_2ecompile_2erc_2etakesAt(V, V, V, V);
V g_heff_2ecompile_2erc_2etakesAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakesAt_clo;
V g_heff_2ecompile_2erc_2etyAt(V, V);
V g_heff_2ecompile_2erc_2etyAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etyAt_clo;
V g_heff_2ecompile_2erc_2eunboxOf(V, V);
V g_heff_2ecompile_2erc_2eunboxOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eunboxOf_clo;
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_clo;
V g_heff_2ecompile_2erc_2eupdatedIn(V, V, V, V);
V g_heff_2ecompile_2erc_2eupdatedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eupdatedIn_clo;
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(V, V, V, V);
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_clo;
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(V, V, V);
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_clo;
V g_heff_2ecompile_2erc_2evalRc(V, V, V);
V g_heff_2ecompile_2erc_2evalRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalRc_clo;
V g_heff_2ecompile_2erepr_2efloatShape(V);
V g_heff_2ecompile_2erepr_2efloatShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efloatShape_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2eopShape(V, V);
V g_heff_2ecompile_2erepr_2eopShape_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eopShape_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2eslotRepr(V, V);
V g_heff_2ecompile_2erepr_2eslotRepr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eslotRepr_clo;
V g_heff_2eelab_2efixed_2efixedPrimOf(V);
V g_heff_2eelab_2efixed_2efixedPrimOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimOf_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24s1104809983x118204267(V, V);
V g_list_2efoldl_24s1104809983x118204267_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1104809983x118204267_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1203202837x1639358108(V, V);
V g_list_2efoldl_24s1203202837x1639358108_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1203202837x1639358108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2efoldl_24s1790904629x1122008408(V, V);
V g_list_2efoldl_24s1790904629x1122008408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1790904629x1122008408_clo;
V g_list_2efoldl_24s2127637016x52413280(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s2127637016x52413280_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2127637016x52413280_clo;
V g_list_2efoldl_24s421921225x565177679(V, V);
V g_list_2efoldl_24s421921225x565177679_entry(V self, V *a);
extern Clo g_list_2efoldl_24s421921225x565177679_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s895442511x653187280(V, V, V);
V g_list_2efoldl_24s895442511x653187280_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895442511x653187280_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s212505720x1447378304(V, V);
V g_list_2ezipWith_24s212505720x1447378304_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s212505720x1447378304_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f489629841x1061860251(V, V, V);
V g_prelude_2e_2b_2b_24f489629841x1061860251_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f489629841x1061860251_clo;
Clo g_heff_2ecompile_2erc_2efvW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efvW_entry, 3, 0};

V g_heff_2ecompile_2erc_2efvW(V v_bs_240, V v_ms_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_bs_240, v_ms_241});
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_IVal: {
      V v_x311_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_245)) {
      case TAG_SVar: {
        V v_x_246 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 1);
        V t_0 = v_bs_240;
        V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_ms_241});
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SGlobal: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SInt: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SStr: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SBytes: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFixed: {
        heff_take_n(v_x311_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SFloat32: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_x311_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SLam: {
        V v_xs_2416 = heff_field(v_x311_245, 0);
        V v_x3112_2417 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 3ULL, 2);
        switch (heff_tag_of(v_x3112_2417)) {
        case TAG_MkBlock: {
          V v_t_2418 = heff_field(v_x3112_2417, 0);
          heff_take_n(v_x3112_2417, 1ULL, 1);
          V v_t_2419 = (g_prelude_2e_2b_2b(v_xs_2416, v_bs_240));
          V v_t_2420 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_2418}), v_rest_244});
          V t_0 = v_t_2419;
          V t_1 = v_ms_241;
          V t_2 = v_t_2420;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3112_2417);
        }
      }
      case TAG_STag: {
        V v_as_2422 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2422));
        V v_t_2424 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2423));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2424;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SRec: {
        V v_fs_2425 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2427 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2425));
        V v_t_2428 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2427));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2428;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SProj: {
        V v_v_2429 = heff_field(v_x311_245, 0);
        heff_take_n(v_x311_245, 1ULL, 4);
        V v_t_2433 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2429}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2433;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_SPrim: {
        V v_as_2435 = heff_field(v_x311_245, 1);
        heff_take_n(v_x311_245, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2436 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2435));
        V v_t_2437 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2436));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2437;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_245);
      }
    }
    case TAG_IOp: {
      V v_x311_2438 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2438)) {
      case TAG_OSimple: {
        V v_v_2439 = heff_field(v_x311_2438, 0);
        heff_take_n(v_x311_2438, 1ULL, 1);
        V v_t_2440 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2439}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2440;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OCall: {
        V v_as_2442 = heff_field(v_x311_2438, 1);
        heff_take_n(v_x311_2438, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2442));
        V v_t_2444 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2443));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2444;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OApply: {
        V v_f_2445 = heff_field(v_x311_2438, 0);
        V v_as_2446 = heff_field(v_x311_2438, 1);
        heff_take_n(v_x311_2438, 3ULL, 2);
        V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2445, v_as_2446})));
        V v_t_2448 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2447));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2448;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OPrim: {
        V v_as_2450 = heff_field(v_x311_2438, 1);
        heff_take_n(v_x311_2438, 2ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2450));
        V v_t_2452 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_2451));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2452;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_OBool: {
        V v_c_2453 = heff_field(v_x311_2438, 0);
        heff_take_n(v_x311_2438, 1ULL, 1);
        V v_t_2454 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2453}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2454;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2438);
      }
    }
    case TAG_ICond: {
      V v_x311_2455 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ICond = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2455)) {
      case TAG_PTrue: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PFalse: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PRel: {
        V v_a_2457 = heff_field(v_x311_2455, 1);
        V v_b_2458 = heff_field(v_x311_2455, 2);
        heff_take_n(v_x311_2455, 6ULL, 3);
        V v_t_2459 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_b_2458}), v_rest_244});
        V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_IVal, 1, (V[]){v_a_2457}), v_t_2459});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2460;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PBool: {
        V v_v_2461 = heff_field(v_x311_2455, 0);
        heff_take_n(v_x311_2455, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2462 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_2461}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2462;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PNot: {
        V v_c_2463 = heff_field(v_x311_2455, 0);
        heff_take_n(v_x311_2455, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ICond, 1);
        V v_t_2464 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2463}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2464;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PIf: {
        V v_a_2465 = heff_field(v_x311_2455, 0);
        V v_b_2466 = heff_field(v_x311_2455, 1);
        V v_c_2467 = heff_field(v_x311_2455, 2);
        heff_take_n(v_x311_2455, 7ULL, 3);
        V v_t_2468 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2467}), v_rest_244});
        V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_ICond, 1, (V[]){v_b_2466}), v_t_2468});
        V v_t_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_a_2465}), v_t_2469});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_2470;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_PLet: {
        V v_x_2471 = heff_field(v_x311_2455, 0);
        V v_o_2472 = heff_field(v_x311_2455, 1);
        V v_c_2473 = heff_field(v_x311_2455, 2);
        heff_take_n(v_x311_2455, 7ULL, 3);
        V v_t_2474 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2473}), v_rest_244});
        V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ICond, TAG_IOp, 1, (V[]){v_o_2472}), v_t_2474});
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2471, v_bs_240});
        V t_1 = v_ms_241;
        V t_2 = v_t_2475;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_2455);
      }
    }
    case TAG_ISts: {
      V v_x311_2476 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ISts = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_2476)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ISts, 1);
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_rest_244;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Cons: {
        V v_x3111_2477 = heff_field(v_x311_2476, 0);
        V v_ss_2478 = heff_field(v_x311_2476, 1);
        V v_ru_24x311_2476_24Cons = heff_take_reuse_n(v_x311_2476, 3ULL, 2);
        switch (heff_tag_of(v_x3111_2477)) {
        case TAG_SLet: {
          V v_x_2479 = heff_field(v_x3111_2477, 0);
          V v_o_2480 = heff_field(v_x3111_2477, 1);
          V v_ru_24x3111_2477_24SLet = heff_take_reuse_n(v_x3111_2477, 3ULL, 2);
          V v_t_2481 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2478}), v_rest_244});
          V v_t_2482 = heff_tag_at_n(v_ru_24x311_2476_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_IOp, 1, (V[]){v_o_2480}), v_t_2481});
          V t_0 = heff_tag_at_n(v_ru_24x3111_2477_24SLet, TAG_Cons, 2, (V[]){v_x_2479, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2482;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SDecl: {
          V v_x_2483 = heff_field(v_x3111_2477, 0);
          heff_take_n(v_x3111_2477, 1ULL, 1);
          heff_drop_cell(v_ru_24x31_243_24ISts, 1);
          V v_t_2484 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2478}), v_rest_244});
          V t_0 = heff_tag_at_n(v_ru_24x311_2476_24Cons, TAG_Cons, 2, (V[]){v_x_2483, v_bs_240});
          V t_1 = v_ms_241;
          V t_2 = v_t_2484;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SSet: {
          V v_o_2486 = heff_field(v_x3111_2477, 1);
          heff_take_n(v_x3111_2477, 2ULL, 2);
          V v_t_2487 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2478}), v_rest_244});
          V v_t_2488 = heff_tag_at_n(v_ru_24x311_2476_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_IOp, 1, (V[]){v_o_2486}), v_t_2487});
          V t_0 = v_bs_240;
          V t_1 = v_ms_241;
          V t_2 = v_t_2488;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SIf: {
          V v_c_2489 = heff_field(v_x3111_2477, 0);
          V v_ts_2490 = heff_field(v_x3111_2477, 1);
          V v_fs_2491 = heff_field(v_x3111_2477, 2);
          heff_take_n(v_x3111_2477, 7ULL, 3);
          V v_t_2492 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2478}), v_rest_244});
          V v_t_2493 = heff_tag_at_n(v_ru_24x311_2476_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_ISts, 1, (V[]){v_fs_2491}), v_t_2492});
          V v_t_2494 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ts_2490}), v_t_2493});
          V v_t_2495 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_2489}), v_t_2494});
          V t_0 = v_bs_240;
          V t_1 = v_ms_241;
          V t_2 = v_t_2495;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_SCase: {
          V v_v_2496 = heff_field(v_x3111_2477, 0);
          V v_arms_2497 = heff_field(v_x3111_2477, 1);
          heff_take_n(v_x3111_2477, 3ULL, 2);
          V v_t_2498 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_2497)));
          V v_t_2499 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2498; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_2498); r_; });
          V v_t_24100 = (g_prelude_2e_2b_2b(v_t_2499, v_bs_240));
          V v_t_24101 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ISts, 1, (V[]){v_ss_2478}), v_rest_244});
          V v_t_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_2497));
          V v_t_24103 = (g_list_2efoldl_24s1104809983x118204267(v_t_24101, v_t_24102));
          V v_t_24104 = heff_tag_at_n(v_ru_24x311_2476_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ISts, TAG_IVal, 1, (V[]){v_v_2496}), v_t_24103});
          V t_0 = v_t_24100;
          V t_1 = v_ms_241;
          V t_2 = v_t_24104;
          v_bs_240 = t_0;
          v_ms_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        default: return heff_nomatch(v_x3111_2477);
        }
      }
      default: return heff_nomatch(v_x311_2476);
      }
    }
    case TAG_ITl: {
      V v_x311_24105 = heff_field(v_x31_243, 0);
      V v_ru_24x31_243_24ITl = heff_take_reuse_n(v_x31_243, 1ULL, 1);
      switch (heff_tag_of(v_x311_24105)) {
      case TAG_TSeq: {
        V v_ss_24106 = heff_field(v_x311_24105, 0);
        V v_t_24107 = heff_field(v_x311_24105, 1);
        V v_ru_24x311_24105_24TSeq = heff_take_reuse_n(v_x311_24105, 3ULL, 2);
        V v_t_24108 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_24107}), v_rest_244});
        V v_t_24109 = heff_tag_at_n(v_ru_24x311_24105_24TSeq, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ISts, 1, (V[]){v_ss_24106}), v_t_24108});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24109;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TReturn: {
        V v_o_24110 = heff_field(v_x311_24105, 0);
        heff_take_n(v_x311_24105, 1ULL, 1);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24111 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_24110}), v_rest_244});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24111;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TLoop: {
        V v_vs_24112 = heff_field(v_x311_24105, 0);
        heff_take_n(v_x311_24105, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24113 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_24112));
        V v_t_24114 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_244, v_t_24113));
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24114;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TIf: {
        V v_c_24115 = heff_field(v_x311_24105, 0);
        V v_t_24116 = heff_field(v_x311_24105, 1);
        V v_e_24117 = heff_field(v_x311_24105, 2);
        heff_take_n(v_x311_24105, 7ULL, 3);
        V v_t_24118 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_e_24117}), v_rest_244});
        V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x31_243_24ITl, TAG_ITl, 1, (V[]){v_t_24116}), v_t_24118});
        V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){v_c_24115}), v_t_24119});
        V t_0 = v_bs_240;
        V t_1 = v_ms_241;
        V t_2 = v_t_24120;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_TCase: {
        V v_v_24121 = heff_field(v_x311_24105, 0);
        V v_arms_24122 = heff_field(v_x311_24105, 1);
        heff_take_n(v_x311_24105, 3ULL, 2);
        heff_drop_cell(v_ru_24x31_243_24ITl, 1);
        V v_t_24123 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_24122)));
        V v_t_24124 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24123; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_24123); r_; });
        V v_t_24125 = (g_prelude_2e_2b_2b(v_t_24124, v_bs_240));
        V v_t_24126 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_arms_24122));
        V v_t_24127 = (g_list_2efoldl_24s421921225x565177679(v_rest_244, v_t_24126));
        V v_t_24128 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_24121}), v_t_24127});
        V t_0 = v_t_24125;
        V t_1 = v_ms_241;
        V t_2 = v_t_24128;
        v_bs_240 = t_0;
        v_ms_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x311_24105);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2efvW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efvW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2efreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efreeOf_entry, 2, 0};

V g_heff_2ecompile_2erc_2efreeOf(V v_xs_240, V v_t_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ITl, 1, (V[]){v_t_241}), NTAG(TAG_Nil)});
  V v_x2_243 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_242));
  switch (heff_tag_of(v_x2_243)) {
  case TAG_MkPair: {
    V v_bs_244 = heff_field(v_x2_243, 0);
    V v_ms_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    V v_bs_246 = (g_prelude_2e_2b_2b(v_xs_240, v_bs_244));
    V v_ms_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_245));
    V v_t_248 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_246; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_246); r_; });
    return ({ V a_0 = v_t_248; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_247; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ecompile_2erc_2efreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efreeOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2efvVal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efvVal_entry, 1, 0};

V g_heff_2ecompile_2erc_2efvVal(V v_v_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_v_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erc_2efvVal_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efvVal(a[0]);
}
Clo g_heff_2ecompile_2erc_2ekeptFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ekeptFrom_entry, 2, 0};

V g_heff_2ecompile_2erc_2ekeptFrom(V v_ls_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_l_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_SVar: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SGlobal: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SInt: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SStr: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SBytes: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SFixed: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SFloat32: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SPrimFn: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SLam: {
      return NTAG(TAG_Nothing);
    }
    case TAG_STag: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SRec: {
      return NTAG(TAG_Nothing);
    }
    case TAG_SProj: {
      V v_e_2420 = heff_field(v_x22_243, 0);
      V v_l2_2421 = heff_field(v_x22_243, 1);
      V v_sh_2422 = heff_field(v_x22_243, 2);
      if (heff_strEq_c(heff_dup(v_l_242), heff_dup(v_l2_2421))) {
        V v_t_2425 = (g_heff_2ecompile_2erc_2esameS(v_ls_240, v_sh_2422));
        if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
          heff_drop(v_t_2425);
          switch (heff_tag_of(v_e_2420)) {
          case TAG_SVar: {
            V v_x_2426 = heff_field(v_e_2420, 0);
            return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2426)});
          }
          case TAG_SGlobal: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SInt: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SFloat: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SStr: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SBytes: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SFixed: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SFloat32: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SPrimFn: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SLam: {
            return NTAG(TAG_Nothing);
          }
          case TAG_STag: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SRec: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SProj: {
            return NTAG(TAG_Nothing);
          }
          case TAG_SPrim: {
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_e_2420);
          }
        } else {
          heff_drop(v_t_2425);
          return NTAG(TAG_Nothing);
        }
      } else {
        return NTAG(TAG_Nothing);
      }
    }
    case TAG_SPrim: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2ekeptFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erc_2ekeptFrom(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2eupdatedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2eupdatedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eupdatedIn_entry, 4, 0};

V g_heff_2ecompile_2erc_2eupdatedIn(V v_ce_240, V v_live_241, V v_ls_242, V v_fs_243) {
top: ;
  V v_x_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_243));
  if (heff_intLt_c(MK_INT(62LL), v_x_244)) {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_ls_242);
    heff_drop(v_fs_243);
    return NTAG(TAG_Nothing);
  } else {
    V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ecompile_2erc_2ekeptFrom_clo), 1, (V[]){v_ls_242}));
    V v_t_247 = (g_list_2emap(v_t_246, v_fs_243));
    V v_t_248 = (g_heff_2ecompile_2erc_2ejustsOf(v_t_247));
    V v_x1_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2eupdatedIn_lam0, 1, 2, (V[]){v_ce_240, heff_dup(v_live_241)}), v_t_248));
    switch (heff_tag_of(v_x1_2413)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x1_2413, 0);
      heff_take_n(v_x1_2413, 1ULL, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
    }
    default: return heff_nomatch(v_x1_2413);
    }
  }
}
V g_heff_2ecompile_2erc_2eupdatedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2eupdatedIn(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2eupdatedIn_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_ce_240 = heff_env(self)[0];
  V v_live_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_249), heff_rfield(v_ce_240, 4)));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2410) == NTAG(TAG_True)) && ({ V v_x1_2411 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_249), v_live_241)); int c_ = ((heff_dup(v_x1_2411) == NTAG(TAG_True)) ? 0 : ({ V v_x1_2412 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_249), heff_rfield(v_ce_240, 6))); int c_ = !(heff_dup(v_x1_2412) == NTAG(TAG_True)); heff_drop(v_x1_2412); c_; })); heff_drop(v_x1_2411); c_; })));
  heff_drop(v_x_249);
  heff_drop_rec(v_ce_240, 13);
  heff_drop(v_live_241);
  heff_drop(v_t_2410);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erc_2ecoerce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ecoerce_entry, 3, 0};

V g_heff_2ecompile_2erc_2ecoerce(V v_from_240, V v_to_241, V v_v_242) {
top: ;
  V v_t_243 = (g_heff_2ecompile_2erepr_2ereprEq(v_from_240, v_to_241));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_from_240);
    heff_drop(v_to_241);
    heff_drop(v_t_243);
    return v_v_242;
  } else {
    heff_drop(v_t_243);
    V v_t_245;
    switch (heff_tag_of(v_to_241)) {
    case TAG_RepV: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    case TAG_RepF64: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_to_241);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_to_241);
      heff_drop(v_t_245);
      return heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242});
    } else {
      heff_drop(v_t_245);
      switch (heff_tag_of(v_from_240)) {
      case TAG_RepV: {
        return (g_heff_2ecompile_2erc_2eunboxOf(v_to_241, v_v_242));
      }
      case TAG_RepFix: {
        return (g_heff_2ecompile_2erc_2eunboxOf(v_to_241, heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242})));
      }
      case TAG_RepF64: {
        return (g_heff_2ecompile_2erc_2eunboxOf(v_to_241, heff_tag_n(TAG_RBox, 2, (V[]){v_from_240, v_v_242})));
      }
      default: return heff_nomatch(v_from_240);
      }
    }
  }
}
V g_heff_2ecompile_2erc_2ecoerce_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ecoerce(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2enaturalOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2enaturalOf_entry, 2, 0};

V g_heff_2ecompile_2erc_2enaturalOf(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_x2_243 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      return NTAG(TAG_RepV);
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      return v_x_244;
    }
    default: return heff_nomatch(v_x2_243);
    }
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SInt: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SFloat: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SStr: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SBytes: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SFixed: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SFloat32: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SPrimFn: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SLam: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_STag: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SRec: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SProj: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_RepV);
  }
  case TAG_SPrim: {
    V v_p_2424 = heff_field(v_v_241, 0);
    heff_drop_rec(v_ce_240, 13);
    V v_x2_2426 = (g_heff_2eelab_2efixed_2efixedPrimOf(heff_dup(v_p_2424)));
    V v_x1_2429;
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_Nothing: {
      v_x1_2429 = (g_heff_2ecompile_2erepr_2efloatShape(heff_dup(v_p_2424)));
      break;
    }
    case TAG_Just: {
      V v_fp_2427 = heff_field(v_x2_2426, 0);
      V v_ru_24x2_2426_24Just = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
      V v_t_2428 = heff_tag_at_n(v_ru_24x2_2426_24Just, TAG_RepFix, 1, (V[]){heff_dup(heff_rfield(v_fp_2427, 0))});
      v_x1_2429 = ({ V a_0 = v_t_2428; V b_1 = heff_get_n(v_fp_2427, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2eopShape(a_0, b_1)); heff_drop(b_1); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2426);
    }
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_Nothing: {
      return NTAG(TAG_RepV);
    }
    case TAG_Just: {
      V v_s_2430 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 1);
      return heff_get_n(v_s_2430, 1, 2);
    }
    default: return heff_nomatch(v_x1_2429);
    }
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erc_2enaturalOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2enaturalOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2erc_2eagrees_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eagrees_entry, 3, 0};

V g_heff_2ecompile_2erc_2eagrees(V v_ce_240, V v_g_241, V v_as_242) {
top: ;
  V v_m_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_g_241), heff_rfield(v_ce_240, 0)));
  V v_n_244 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_242));
  V v_t_245 = heff_dup(heff_rfield(v_ce_240, 2));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_g_241);
    heff_drop(v_m_243);
    heff_drop(v_n_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_s_246, 1, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    if (heff_intEq_c(v_t_247, heff_dup(v_n_244))) {
      switch (heff_tag_of(v_m_243)) {
      case TAG_Nothing: {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_g_241);
        heff_drop(v_n_244);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_m_249 = heff_field(v_m_243, 0);
        heff_take_n(v_m_243, 1ULL, 1);
        if (heff_intEq_c(v_n_244, v_m_249)) {
          return ({ V a_0 = heff_dup(v_ce_240); V b_1 = heff_get_n(v_ce_240, 2, 13); V a_2 = v_g_241; V r_ = (g_heff_2ecompile_2erc_2esameAs(a_0, b_1, a_2)); heff_drop(b_1); r_; });
        } else {
          heff_drop_rec(v_ce_240, 13);
          heff_drop(v_g_241);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_m_243);
      }
    } else {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_g_241);
      heff_drop(v_m_243);
      heff_drop(v_n_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ecompile_2erc_2eagrees_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2eagrees(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2etakenFv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etakenFv_entry, 4, 0};

V g_heff_2ecompile_2erc_2etakenFv(V v_ce_240, V v_x2_241, V v_vs_242, V v_fb_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x1_247;
    switch (heff_tag_of(v_vs_242)) {
    case TAG_Nil: {
      v_x1_247 = NTAG(TAG_True);
      break;
    }
    case TAG_Cons: {
      v_x1_247 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_vs_242);
    }
    if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      heff_drop(v_x1_247);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_x1_247);
      V v_t_248 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
      if (heff_intLe_c(v_t_248, MK_INT(60LL))) {
        V v_x1_2410 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_244), v_fb_243));
        if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 13);
          heff_drop(v_x_244);
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          heff_drop(v_x1_2410);
          return NTAG(TAG_Nothing);
        } else {
          heff_drop(v_x1_2410);
          V v_x1_2411 = ({ V a_0 = heff_dup(v_x_244); V b_1 = heff_get_n(v_ce_240, 5, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
          if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            heff_drop(v_x1_2411);
            return NTAG(TAG_Nothing);
          } else {
            heff_drop(v_x1_2411);
            return heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_x_244});
          }
        }
      } else {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2etakenFv_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erc_2etakenFv(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erc_2ereuseArgs_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2ereuseArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereuseArgs_entry, 2, 0};

V g_heff_2ecompile_2erc_2ereuseArgs(V v_go_240, V v_vs_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2erc_2ereuseArgs_lam0, 2, 1, (V[]){v_go_240}), v_t_242, v_vs_241));
}
V g_heff_2ecompile_2erc_2ereuseArgs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2ereuseArgs(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2ereuseArgs_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_v_244 = args[1];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247;
  switch (heff_tag_of(v_acc_243)) {
  case TAG_MkPair: {
    V v_x_245 = heff_dup(heff_field(v_acc_243, 0));
    v_t_247 = v_x_245;
    break;
  }
  default: heff_nomatch(v_acc_243);
  }
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_go_240);
    heff_drop(v_t_247);
    V v_t_2410;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_249 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_t_2410 = v_y_249;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2411));
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), v_t_2412});
  } else {
    heff_drop(v_t_247);
    V v_done_2415;
    switch (heff_tag_of(v_acc_243)) {
    case TAG_MkPair: {
      V v_y_2414 = heff_field(v_acc_243, 1);
      heff_take_n(v_acc_243, 2ULL, 2);
      v_done_2415 = v_y_2414;
      break;
    }
    default: heff_nomatch(v_acc_243);
    }
    V v_x2_2416 = heff_tr(heff_call(v_go_240, 1, (V[]){v_v_244}));
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_MkPair: {
      V v_b_2417 = heff_field(v_x2_2416, 0);
      V v_e_2418 = heff_field(v_x2_2416, 1);
      V v_ru_24x2_2416_24MkPair = heff_take_reuse_n(v_x2_2416, 3ULL, 2);
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_2416_24MkPair, TAG_Cons, 2, (V[]){v_e_2418, NTAG(TAG_Nil)});
      V v_t_2420 = (g_prelude_2e_2b_2b(v_done_2415, v_t_2419));
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_b_2417, v_t_2420});
    }
    default: return heff_nomatch(v_x2_2416);
    }
  }
}
V g_heff_2ecompile_2erc_2ereuseV_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2ereuseV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereuseV_entry, 3, 0};

V g_heff_2ecompile_2erc_2ereuseV(V v_ru_240, V v_n_241, V v_v_242) {
top: ;
  switch (heff_tag_of(v_v_242)) {
  case TAG_SVar: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SGlobal: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SInt: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SFloat: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SStr: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SBytes: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SFixed: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SFloat32: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SPrimFn: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SLam: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_STag: {
    V v_t_2415 = heff_field(v_v_242, 0);
    V v_as_2416 = heff_field(v_v_242, 1);
    V v_ru_24v_242_24STag = heff_take_reuse_n(v_v_242, 3ULL, 2);
    V v_t_2417 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2416));
    if (heff_intEq_c(v_t_2417, heff_dup(v_n_241))) {
      heff_drop(v_n_241);
      V v_t_2419 = heff_tag_at_n(v_ru_24v_242_24STag, TAG_Cons, 2, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_t_2415, v_as_2416}), NTAG(TAG_Nil)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_SVar, 1, (V[]){v_ru_240}), v_t_2419});
      return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_SPrim, 2, (V[]){heff_dup(g_heff_2ecompile_2erc_2ereusePrim_get()), v_t_2420})});
    } else {
      V v_x2_2422 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erc_2ereuseV_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_as_2416; V r_ = (g_heff_2ecompile_2erc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_2416); r_; });
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_MkPair: {
        V v_b_2423 = heff_field(v_x2_2422, 0);
        V v_as_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        return heff_tag_at_n(v_ru_24v_242_24STag, TAG_MkPair, 2, (V[]){v_b_2423, heff_tag_n(TAG_STag, 2, (V[]){v_t_2415, v_as_2424})});
      }
      default: return heff_nomatch(v_x2_2422);
      }
    }
  }
  case TAG_SRec: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SProj: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  case TAG_SPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_v_242});
  }
  default: return heff_nomatch(v_v_242);
  }
}
V g_heff_2ecompile_2erc_2ereuseV_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ereuseV(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2ereuseV_lam0(V self, V *args) {
  V v_v_2421 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erc_2ereuseV(v_ru_240, v_n_241, v_v_2421));
}
V g_heff_2ecompile_2erc_2ereuseOp_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2ereuseOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereuseOp_entry, 3, 0};

V g_heff_2ecompile_2erc_2ereuseOp(V v_ru_240, V v_n_241, V v_o_242) {
top: ;
  switch (heff_tag_of(v_o_242)) {
  case TAG_OSimple: {
    V v_v_243 = heff_field(v_o_242, 0);
    V v_ru_24o_242_24OSimple = heff_take_reuse_n(v_o_242, 1ULL, 1);
    V v_t_244 = (g_heff_2ecompile_2erc_2ereuseV(v_ru_240, v_n_241, v_v_243));
    switch (heff_tag_of(v_t_244)) {
    case TAG_MkPair: {
      V v_b_245 = heff_field(v_t_244, 0);
      V v_v2_246 = heff_field(v_t_244, 1);
      V v_ru_24t_244_24MkPair = heff_take_reuse_n(v_t_244, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_244_24MkPair, TAG_MkPair, 2, (V[]){v_b_245, heff_tag_at_n(v_ru_24o_242_24OSimple, TAG_OSimple, 1, (V[]){v_v2_246})});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_OCall: {
    V v_g_247 = heff_field(v_o_242, 0);
    V v_as_248 = heff_field(v_o_242, 1);
    V v_ru_24o_242_24OCall = heff_take_reuse_n(v_o_242, 3ULL, 2);
    V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erc_2ereuseOp_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_as_248; V r_ = (g_heff_2ecompile_2erc_2ereuseArgs(a_0, a_1)); heff_drop(v_as_248); r_; });
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_b_2411 = heff_field(v_t_2410, 0);
      V v_as2_2412 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24o_242_24OCall, TAG_MkPair, 2, (V[]){v_b_2411, heff_tag_n(TAG_OCall, 2, (V[]){v_g_247, v_as2_2412})});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_OApply: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  case TAG_OPrim: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  case TAG_OAbandon: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  case TAG_OBool: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), v_o_242});
  }
  default: return heff_nomatch(v_o_242);
  }
}
V g_heff_2ecompile_2erc_2ereuseOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ereuseOp(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2ereuseOp_lam0(V self, V *args) {
  V v_v_249 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erc_2ereuseV(v_ru_240, v_n_241, v_v_249));
}
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_entry, 3, 0};

V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702(V v_ru_240, V v_n_241, V v_arms_242) {
top: ;
  V v_t_2410 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_lam0, 1, 2, (V[]){heff_dup(v_ru_240), heff_dup(v_n_241)}), v_arms_242));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_lam1, 1, 2, (V[]){v_ru_240, v_n_241}), v_arms_242));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_t_2419});
}
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_lam0(V self, V *args) {
  V v_arm_243 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_243)) {
  case TAG_MkArm: {
    V v_ss_246 = heff_field(v_arm_243, 2);
    heff_take_n(v_arm_243, 4ULL, 3);
    V v_x1_247 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_ss_246));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      return v_x_248;
    }
    default: return heff_nomatch(v_x1_247);
    }
  }
  default: return heff_nomatch(v_arm_243);
  }
}
V g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702_lam1(V self, V *args) {
  V v_arm_2411 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_arm_2411)) {
  case TAG_MkArm: {
    V v_t_2412 = heff_field(v_arm_2411, 0);
    V v_vs_2413 = heff_field(v_arm_2411, 1);
    V v_ss_2414 = heff_field(v_arm_2411, 2);
    V v_ru_24arm_2411_24MkArm = heff_take_reuse_n(v_arm_2411, 7ULL, 3);
    V v_x1_2415 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_ss_2414));
    V v_t_2418;
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_y_2417 = heff_field(v_x1_2415, 1);
      heff_take_n(v_x1_2415, 2ULL, 2);
      v_t_2418 = v_y_2417;
      break;
    }
    default: heff_nomatch(v_x1_2415);
    }
    return heff_tag_at_n(v_ru_24arm_2411_24MkArm, TAG_MkArm, 3, (V[]){v_t_2412, v_vs_2413, v_t_2418});
  }
  default: return heff_nomatch(v_arm_2411);
  }
}
Clo g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_entry, 3, 0};

V g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ru_240);
    heff_drop(v_n_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_False), NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x41_243 = heff_field(v_x4_242, 0);
    V v_rest_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_243)) {
    case TAG_SLet: {
      V v_x_245 = heff_field(v_x41_243, 0);
      V v_o_246 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SLet = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_247 = (g_heff_2ecompile_2erc_2ereuseOp(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_246));
      V v_x5_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_b_248 = heff_field(v_t_247, 0);
        V v_o2_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        v_x5_2410 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){v_b_248, heff_tag_n(TAG_SLet, 2, (V[]){v_x_245, v_o2_249})});
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      switch (heff_tag_of(v_x5_2410)) {
      case TAG_MkPair: {
        V v_x51_2411 = heff_field(v_x5_2410, 0);
        V v_st_2412 = heff_field(v_x5_2410, 1);
        heff_take_n(v_x5_2410, 3ULL, 2);
        if ((heff_dup(v_x51_2411) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2411);
          return heff_tag_at_n(v_ru_24x41_243_24SLet, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_Cons, 2, (V[]){v_st_2412, v_rest_244})});
        } else {
          heff_drop(v_x51_2411);
          V v_x2_2413 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2413)) {
          case TAG_MkPair: {
            V v_b_2414 = heff_field(v_x2_2413, 0);
            V v_ss_2415 = heff_field(v_x2_2413, 1);
            heff_take_n(v_x2_2413, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x41_243_24SLet, TAG_MkPair, 2, (V[]){v_b_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_st_2412, v_ss_2415})});
          }
          default: return heff_nomatch(v_x2_2413);
          }
        }
      }
      default: return heff_nomatch(v_x5_2410);
      }
    }
    case TAG_SDecl: {
      V v_x2_2417 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_rest_244));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_b_2418 = heff_field(v_x2_2417, 0);
        V v_ss_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){v_b_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_x41_243, v_ss_2419})});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    case TAG_SSet: {
      V v_x_2420 = heff_field(v_x41_243, 0);
      V v_o_2421 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SSet = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_2422 = (g_heff_2ecompile_2erc_2ereuseOp(heff_dup(v_ru_240), heff_dup(v_n_241), v_o_2421));
      V v_x5_2425;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_MkPair: {
        V v_b_2423 = heff_field(v_t_2422, 0);
        V v_o2_2424 = heff_field(v_t_2422, 1);
        heff_take_n(v_t_2422, 3ULL, 2);
        v_x5_2425 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){v_b_2423, heff_tag_n(TAG_SSet, 2, (V[]){v_x_2420, v_o2_2424})});
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      switch (heff_tag_of(v_x5_2425)) {
      case TAG_MkPair: {
        V v_x51_2426 = heff_field(v_x5_2425, 0);
        V v_st_2427 = heff_field(v_x5_2425, 1);
        heff_take_n(v_x5_2425, 3ULL, 2);
        if ((heff_dup(v_x51_2426) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2426);
          return heff_tag_at_n(v_ru_24x41_243_24SSet, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_Cons, 2, (V[]){v_st_2427, v_rest_244})});
        } else {
          heff_drop(v_x51_2426);
          V v_x2_2428 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2428)) {
          case TAG_MkPair: {
            V v_b_2429 = heff_field(v_x2_2428, 0);
            V v_ss_2430 = heff_field(v_x2_2428, 1);
            heff_take_n(v_x2_2428, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x41_243_24SSet, TAG_MkPair, 2, (V[]){v_b_2429, heff_tag_n(TAG_Cons, 2, (V[]){v_st_2427, v_ss_2430})});
          }
          default: return heff_nomatch(v_x2_2428);
          }
        }
      }
      default: return heff_nomatch(v_x5_2425);
      }
    }
    case TAG_SIf: {
      V v_c_2431 = heff_field(v_x41_243, 0);
      V v_ts_2432 = heff_field(v_x41_243, 1);
      V v_fs_2433 = heff_field(v_x41_243, 2);
      heff_take_n(v_x41_243, 7ULL, 3);
      V v_t_2434 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(heff_dup(v_ru_240), heff_dup(v_n_241), v_ts_2432));
      V v_x5_2441;
      switch (heff_tag_of(v_t_2434)) {
      case TAG_MkPair: {
        V v_bt_2435 = heff_field(v_t_2434, 0);
        V v_ts2_2436 = heff_field(v_t_2434, 1);
        heff_take_n(v_t_2434, 3ULL, 2);
        V v_t_2437 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(heff_dup(v_ru_240), heff_dup(v_n_241), v_fs_2433));
        switch (heff_tag_of(v_t_2437)) {
        case TAG_MkPair: {
          V v_bf_2438 = heff_field(v_t_2437, 0);
          V v_fs2_2439 = heff_field(v_t_2437, 1);
          heff_take_n(v_t_2437, 3ULL, 2);
          V v_t_2440;
          if ((heff_dup(v_bt_2435) == NTAG(TAG_True))) {
            heff_drop(v_bt_2435);
            heff_drop(v_bf_2438);
            v_t_2440 = NTAG(TAG_True);
          } else {
            heff_drop(v_bt_2435);
            v_t_2440 = v_bf_2438;
          }
          v_x5_2441 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){v_t_2440, heff_tag_n(TAG_SIf, 3, (V[]){v_c_2431, v_ts2_2436, v_fs2_2439})});
          break;
        }
        default: heff_nomatch(v_t_2437);
        }
        break;
      }
      default: heff_nomatch(v_t_2434);
      }
      switch (heff_tag_of(v_x5_2441)) {
      case TAG_MkPair: {
        V v_x51_2442 = heff_field(v_x5_2441, 0);
        V v_st_2443 = heff_field(v_x5_2441, 1);
        V v_ru_24x5_2441_24MkPair = heff_take_reuse_n(v_x5_2441, 3ULL, 2);
        if ((heff_dup(v_x51_2442) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2442);
          return heff_tag_at_n(v_ru_24x5_2441_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_Cons, 2, (V[]){v_st_2443, v_rest_244})});
        } else {
          heff_drop(v_x51_2442);
          V v_x2_2444 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2444)) {
          case TAG_MkPair: {
            V v_b_2445 = heff_field(v_x2_2444, 0);
            V v_ss_2446 = heff_field(v_x2_2444, 1);
            heff_take_n(v_x2_2444, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x5_2441_24MkPair, TAG_MkPair, 2, (V[]){v_b_2445, heff_tag_n(TAG_Cons, 2, (V[]){v_st_2443, v_ss_2446})});
          }
          default: return heff_nomatch(v_x2_2444);
          }
        }
      }
      default: return heff_nomatch(v_x5_2441);
      }
    }
    case TAG_SCase: {
      V v_v_2447 = heff_field(v_x41_243, 0);
      V v_arms_2448 = heff_field(v_x41_243, 1);
      V v_ru_24x41_243_24SCase = heff_take_reuse_n(v_x41_243, 3ULL, 2);
      V v_t_2449 = (g_heff_2ecompile_2erc_2estArms_24s802720625x1605697702(heff_dup(v_ru_240), heff_dup(v_n_241), v_arms_2448));
      V v_x5_2452;
      switch (heff_tag_of(v_t_2449)) {
      case TAG_MkPair: {
        V v_b_2450 = heff_field(v_t_2449, 0);
        V v_as2_2451 = heff_field(v_t_2449, 1);
        heff_take_n(v_t_2449, 3ULL, 2);
        v_x5_2452 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){v_b_2450, heff_tag_n(TAG_SCase, 2, (V[]){v_v_2447, v_as2_2451})});
        break;
      }
      default: heff_nomatch(v_t_2449);
      }
      switch (heff_tag_of(v_x5_2452)) {
      case TAG_MkPair: {
        V v_x51_2453 = heff_field(v_x5_2452, 0);
        V v_st_2454 = heff_field(v_x5_2452, 1);
        heff_take_n(v_x5_2452, 3ULL, 2);
        if ((heff_dup(v_x51_2453) == NTAG(TAG_True))) {
          heff_drop(v_ru_240);
          heff_drop(v_n_241);
          heff_drop(v_x51_2453);
          return heff_tag_at_n(v_ru_24x41_243_24SCase, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_Cons, 2, (V[]){v_st_2454, v_rest_244})});
        } else {
          heff_drop(v_x51_2453);
          V v_x2_2455 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_240, v_n_241, v_rest_244));
          switch (heff_tag_of(v_x2_2455)) {
          case TAG_MkPair: {
            V v_b_2456 = heff_field(v_x2_2455, 0);
            V v_ss_2457 = heff_field(v_x2_2455, 1);
            heff_take_n(v_x2_2455, 3ULL, 2);
            return heff_tag_at_n(v_ru_24x41_243_24SCase, TAG_MkPair, 2, (V[]){v_b_2456, heff_tag_n(TAG_Cons, 2, (V[]){v_st_2454, v_ss_2457})});
          }
          default: return heff_nomatch(v_x2_2455);
          }
        }
      }
      default: return heff_nomatch(v_x5_2452);
      }
    }
    default: return heff_nomatch(v_x41_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2erc_2ereusing_str0, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erc_2ereusing_str1, 3, "ru$");
HEFF_LIT(g_heff_2ecompile_2erc_2ereusing_str2, 1, "$");
HEFF_LIT(g_heff_2ecompile_2erc_2ereusing_str3, 3, "ru$");
Clo g_heff_2ecompile_2erc_2ereusing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereusing_entry, 4, 0};

V g_heff_2ecompile_2erc_2ereusing(V v_x1_240, V v_t_241, V v_vs_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Just = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_245 = heff_strAppend(heff_dup(v_x_244), heff_strAppend(((V)&g_heff_2ecompile_2erc_2ereusing_str0), heff_dup(v_t_241)));
    V v_ru_246 = heff_strAppend(((V)&g_heff_2ecompile_2erc_2ereusing_str1), v_t_245);
    V v_n_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_242));
    V v_it_2416;
    switch (heff_tag_of(v_b_243)) {
    case TAG_ATail: {
      V v_t_248 = heff_dup(heff_field(v_b_243, 0));
      V v_t_249 = (g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(v_ru_246, v_n_247, v_t_248));
      switch (heff_tag_of(v_t_249)) {
      case TAG_MkPair: {
        V v_b_2410 = heff_field(v_t_249, 0);
        V v_t2_2411 = heff_field(v_t_249, 1);
        V v_ru_24t_249_24MkPair = heff_take_reuse_n(v_t_249, 3ULL, 2);
        v_it_2416 = heff_tag_at_n(v_ru_24t_249_24MkPair, TAG_MkPair, 2, (V[]){v_b_2410, heff_tag_at_n(v_ru_24x1_240_24Just, TAG_ATail, 1, (V[]){v_t2_2411})});
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    case TAG_ASts: {
      V v_ss_2412 = heff_dup(heff_field(v_b_243, 0));
      V v_t_2413 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(v_ru_246, v_n_247, v_ss_2412));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_MkPair: {
        V v_b_2414 = heff_field(v_t_2413, 0);
        V v_ss2_2415 = heff_field(v_t_2413, 1);
        V v_ru_24t_2413_24MkPair = heff_take_reuse_n(v_t_2413, 3ULL, 2);
        v_it_2416 = heff_tag_at_n(v_ru_24t_2413_24MkPair, TAG_MkPair, 2, (V[]){v_b_2414, heff_tag_at_n(v_ru_24x1_240_24Just, TAG_ASts, 1, (V[]){v_ss2_2415})});
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    switch (heff_tag_of(v_it_2416)) {
    case TAG_MkPair: {
      V v_it1_2417 = heff_field(v_it_2416, 0);
      V v_b2_2418 = heff_field(v_it_2416, 1);
      V v_ru_24it_2416_24MkPair = heff_take_reuse_n(v_it_2416, 3ULL, 2);
      if ((heff_dup(v_it1_2417) == NTAG(TAG_True))) {
        heff_drop(v_b_243);
        heff_drop(v_it1_2417);
        V v_t_2419 = heff_strAppend(v_x_244, heff_strAppend(((V)&g_heff_2ecompile_2erc_2ereusing_str2), v_t_241));
        V v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erc_2ereusing_str3), v_t_2419)});
        return heff_tag_at_n(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2420, v_b2_2418});
      } else {
        heff_drop(v_t_241);
        heff_drop(v_x_244);
        heff_drop(v_it1_2417);
        heff_drop(v_b2_2418);
        return heff_tag_at_n(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_b_243});
      }
    }
    default: return heff_nomatch(v_it_2416);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2ereusing_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2ereusing(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2ereusedOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereusedOf_entry, 1, 0};

V g_heff_2ecompile_2erc_2ereusedOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x121_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x121_243)) {
      case TAG_SVar: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SGlobal: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SInt: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SFloat: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SStr: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SBytes: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SFixed: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SFloat32: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrimFn: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SLam: {
        return NTAG(TAG_Nothing);
      }
      case TAG_STag: {
        V v_as_2418 = heff_field(v_x121_243, 1);
        switch (heff_tag_of(v_x122_244)) {
        case TAG_Nil: {
          V v_t_2419 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_as_2418));
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_KnownTag, 1, (V[]){v_t_2419})});
        }
        case TAG_Cons: {
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_x122_244);
        }
      }
      case TAG_SRec: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SProj: {
        return NTAG(TAG_Nothing);
      }
      case TAG_SPrim: {
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x121_243);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2ereusedOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2erc_2ereusedOf(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2erc_2eoperandsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eoperandsOf_entry, 1, 0};

V g_heff_2ecompile_2erc_2eoperandsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_OSimple: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_SVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SGlobal: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SStr: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SFixed: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_SFloat32: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimFn: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLam: {
      heff_take_n(v_x11_241, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_STag: {
      V v_as_2415 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      return v_as_2415;
    }
    case TAG_SRec: {
      V v_fs_2416 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 2);
      HEFF_LAST return g_list_2emap_24s1173914895x100384474(v_fs_2416);
    }
    case TAG_SProj: {
      V v_e_2418 = heff_field(v_x11_241, 0);
      V v_l_2419 = heff_field(v_x11_241, 1);
      V v_sh_2420 = heff_field(v_x11_241, 2);
      V v_t_2421 = heff_field(v_x11_241, 3);
      V v_ru_24x11_241_24SProj = heff_take_reuse_n(v_x11_241, 15ULL, 4);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24SProj, TAG_SProj, 4, (V[]){v_e_2418, v_l_2419, v_sh_2420, v_t_2421}), NTAG(TAG_Nil)});
    }
    case TAG_SPrim: {
      V v_as_2423 = heff_field(v_x11_241, 1);
      heff_take_n(v_x11_241, 2ULL, 2);
      return v_as_2423;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  case TAG_OCall: {
    V v_as_2425 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_as_2425;
  }
  case TAG_OApply: {
    V v_f_2426 = heff_field(v_x1_240, 0);
    V v_as_2427 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24OApply = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24OApply, TAG_Cons, 2, (V[]){v_f_2426, v_as_2427});
  }
  case TAG_OPrim: {
    V v_as_2429 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 2);
    return v_as_2429;
  }
  case TAG_OAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_OBool: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2eoperandsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eoperandsOf(a[0]);
}
Clo g_heff_2ecompile_2erc_2etakeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etakeOne_entry, 3, 0};

V g_heff_2ecompile_2erc_2etakeOne(V v_ce_240, V v_rest_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SVar: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SGlobal: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SInt: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFloat: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SStr: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SBytes: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFixed: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SFloat32: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SPrimFn: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SLam: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_STag: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SRec: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  case TAG_SProj: {
    V v_e1_2419 = heff_field(v_e_242, 0);
    V v_l_2420 = heff_field(v_e_242, 1);
    V v_sh_2421 = heff_field(v_e_242, 2);
    V v_t_2422 = heff_field(v_e_242, 3);
    V v_t_2423 = (g_heff_2ecompile_2erepr_2emayBeFlat(heff_dup(v_t_2422)));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_ce_240);
      heff_drop(v_rest_241);
      heff_drop(v_t_2423);
      return NTAG(TAG_Nil);
    } else {
      heff_drop(v_t_2423);
      V v_t_2446;
      switch (heff_tag_of(v_e1_2419)) {
      case TAG_SVar: {
        V v_x_2424 = heff_field(v_e1_2419, 0);
        v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2424)});
        break;
      }
      case TAG_SGlobal: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e1_2419);
      }
      return ({ V a_0 = v_ce_240; V a_1 = v_rest_241; V a_2 = v_t_2446; V a_3 = heff_dup(v_l_2420); V a_4 = v_sh_2421; V r_ = (g_heff_2ecompile_2erc_2etakeVar(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2446); r_; });
    }
  }
  case TAG_SPrim: {
    heff_drop(v_ce_240);
    heff_drop(v_rest_241);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2erc_2etakeOne_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2etakeOne(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2etakesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etakesAt_entry, 4, 0};

V g_heff_2ecompile_2erc_2etakesAt(V v_ce_240, V v_before_241, V v_after_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_before_241);
    heff_drop(v_after_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_244 = heff_field(v_x4_243, 0);
    V v_es_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_245)));
    V v_rest_247 = (g_list_2efoldl_24s1203202837x1639358108(heff_dup(v_after_242), v_t_246));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_before_241)));
    V v_t_249 = (g_list_2efoldl_24s1203202837x1639358108(v_rest_247, v_t_248));
    V v_t_2410 = (g_heff_2ecompile_2erc_2etakeOne(heff_dup(v_ce_240), v_t_249, v_e_244));
    V v_t_2411 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_e_244, NTAG(TAG_Nil)});
    V v_t_2412 = (g_prelude_2e_2b_2b(v_before_241, v_t_2411));
    V v_t_2413 = (g_heff_2ecompile_2erc_2etakesAt(v_ce_240, v_t_2412, v_after_242, v_es_245));
    return (g_prelude_2e_2b_2b(v_t_2410, v_t_2413));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2erc_2etakesAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2etakesAt(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_entry, 3, 0};

V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x4_242, 0);
    V v_es_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_244)));
    V v_t_246 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_245; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_245); r_; });
    V v_live_247 = (g_prelude_2e_2b_2b(v_t_246, heff_dup(v_live_241)));
    V v_t_248 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(heff_dup(v_ce_240), v_live_247, NTAG(TAG_RepV), v_e_243));
    V v_cell_249 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_24dps(v_ce_240, v_live_241, v_es_244, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam3(V self, V *args);
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam4(V self, V *args);
Clo g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_entry, 6, 0};

V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099(V v_ce_240, V v_live_241, V v_fs_242, V v_ts_243, V v_x_244, V v_changed_245) {
top: ;
  V v_ls_246 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
  V v_t_2410 = (g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237(heff_clo_n(g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam0, 1, 2, (V[]){v_ls_246, heff_dup(v_x_244)}), v_fs_242));
  V v_t_2411 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_2412 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2411, MK_INT(1LL))));
  V v_is_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam1, 1, 1, (V[]){heff_dup(v_changed_245)}), v_t_2412));
  V v_t_2420 = ({ V a_0 = MK_INT(3LL); V a_1 = MK_INT(0LL); V a_2 = v_is_2419; V r_ = (g_list_2efoldl_24s895442511x653187280(a_0, a_1, a_2)); heff_drop(v_is_2419); r_; });
  V v_ps_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam3, 1, 1, (V[]){heff_dup(v_ts_243)}), heff_dup(v_changed_245)));
  V v_t_2431 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = v_ps_2430; V r_ = (g_list_2efoldl_24s2127637016x52413280(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_ps_2430); r_; });
  V v_t_2432 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
  V v_t_2433 = (g_list_2emap_24s1937570095x2110149801(v_fs_242));
  V v_rps_2439 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam4, 1, 1, (V[]){heff_dup(v_ts_243)}), heff_dup(v_changed_245)));
  V v_vs_2440 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_changed_245)));
  V v_t_2441 = (g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(v_ce_240, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), v_live_241}), heff_dup(v_rps_2439), v_vs_2440));
  V v_t_2442 = (g_list_2ezipWith_24s212505720x1447378304(v_rps_2439, v_t_2441));
  V v_t_2443 = (g_list_2ezipWith_24s1029292936x211450510(v_changed_245, v_t_2442));
  return heff_tag_n(TAG_RRecIn, 7, (V[]){v_x_244, v_t_2410, v_t_2420, v_t_2431, v_t_2432, v_t_2433, v_t_2443});
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam0(V self, V *args) {
  V v_f_247 = args[0];
  V v_ls_246 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_248 = ({ V a_0 = v_ls_246; V a_1 = v_f_247; V r_ = (g_heff_2ecompile_2erc_2ekeptFrom(a_0, a_1)); heff_drop(v_ls_246); heff_drop(v_f_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    heff_drop(v_x_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_y_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    return heff_strEq(v_x_244, v_y_249);
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam2(V self, V *args) {
  V v_p_2414 = args[0];
  V v_i_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417;
  switch (heff_tag_of(v_p_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_p_2414, 0);
    heff_take_n(v_p_2414, 1ULL, 2);
    v_t_2417 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_p_2414);
  }
  return heff_intEq(v_t_2417, v_i_2413);
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam1(V self, V *args) {
  V v_i_2413 = args[0];
  V v_changed_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2418 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam2, 1, 1, (V[]){v_i_2413}); V a_1 = v_changed_245; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_changed_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2418) == NTAG(TAG_True)));
  heff_drop(v_x1_2418);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam3(V self, V *args) {
  V v_p_2421 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2424;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_dup(heff_field(v_p_2421, 0));
    v_t_2424 = v_x_2422;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_i_2427;
  switch (heff_tag_of(v_p_2421)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_p_2421, 0);
    heff_take_n(v_p_2421, 1ULL, 2);
    v_i_2427 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_p_2421);
  }
  V v_t_2428 = ({ V a_0 = heff_dup(v_i_2427); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erc_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  V v_t_2429 = (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2427, v_t_2428));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_t_2429});
}
V g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099_lam4(V self, V *args) {
  V v_p_2434 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_i_2437;
  switch (heff_tag_of(v_p_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_p_2434, 0);
    heff_take_n(v_p_2434, 1ULL, 2);
    v_i_2437 = v_x_2435;
    break;
  }
  default: heff_nomatch(v_p_2434);
  }
  V v_t_2438 = ({ V a_0 = heff_dup(v_i_2437); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erc_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2437, v_t_2438));
}
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_entry, 5, 0};

V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834(V v_ce_240, V v_live_241, V v_fs_242, V v_ts_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
    V v_t_246 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
    V v_t_247 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_246, MK_INT(1LL))));
    V v_ps_2411 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_lam0, 1, 1, (V[]){heff_dup(v_ts_243)}), v_t_247));
    V v_t_2412 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = MK_INT(2LL); V a_5 = MK_INT(0LL); V a_6 = MK_INT(0LL); V a_7 = MK_INT(0LL); V a_8 = MK_INT(3LL); V a_9 = MK_INT(0LL); V a_10 = MK_INT(1LL); V a_11 = MK_INT(0LL); V a_12 = v_ps_2411; V r_ = (g_list_2efoldl_24s2127637016x52413280(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_ps_2411); r_; });
    V v_t_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_fs_242));
    V v_t_2414 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2413, MK_INT(1LL))));
    V v_rps_2417 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_lam1, 1, 1, (V[]){heff_dup(v_ts_243)}), v_t_2414));
    V v_vs_2418 = (g_list_2emap_24s1173914895x100384474(v_fs_242));
    V v_t_2419 = (g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(v_ce_240, v_live_241, heff_dup(v_rps_2417), v_vs_2418));
    V v_t_2420 = (g_list_2ezipWith_24s212505720x1447378304(v_rps_2417, v_t_2419));
    return heff_tag_n(TAG_RRec, 3, (V[]){v_t_245, v_t_2412, v_t_2420});
  }
  case TAG_Just: {
    V v_x_2421 = heff_field(v_x6_244, 0);
    V v_t_2422 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_242)));
    V v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_x_2421); V a_2 = heff_dup(v_fs_242); V r_ = (g_heff_2ecompile_2erc_2echangedOf(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
    return (g_heff_2ecompile_2erc_2eupdateVal_24s1776020739x694311099(v_ce_240, v_live_241, v_fs_242, v_ts_243, heff_dup(v_x_2421), v_t_2423));
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834(a[0], a[1], a[2], a3, a4); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_lam0(V self, V *args) {
  V v_i_248 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = ({ V a_0 = heff_dup(v_i_248); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erc_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  V v_t_2410 = (g_heff_2ecompile_2erepr_2eslotRepr(heff_dup(v_i_248), v_t_249));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_i_248, v_t_2410});
}
V g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834_lam1(V self, V *args) {
  V v_i_2415 = args[0];
  V v_ts_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = ({ V a_0 = heff_dup(v_i_2415); V a_1 = v_ts_243; V r_ = (g_heff_2ecompile_2erc_2etyAt(a_0, a_1)); heff_drop(v_ts_243); r_; });
  return (g_heff_2ecompile_2erepr_2eslotRepr(v_i_2415, v_t_2416));
}
Clo g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_entry, 3, 0};

V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(V v_ce_240, V v_live_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_SVar: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SVar = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_x3_244 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_243), heff_rfield(v_ce_240, 10)));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      V v_t_245 = ({ V a_0 = heff_dup(v_x_243); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_t_245);
        return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
      } else {
        heff_drop(v_t_245);
        V v_t_246 = ({ V a_0 = heff_dup(v_x_243); V b_1 = heff_get_n(v_ce_240, 6, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RDup, 1, (V[]){v_x_243});
        } else {
          heff_drop(v_t_246);
          return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
        }
      }
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      return heff_tag_at_n(v_ru_24x4_242_24SVar, TAG_RLocal, 1, (V[]){v_x_243});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_SGlobal: {
    V v_g_248 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SGlobal = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop(v_live_241);
    V v_x3_249 = ({ V a_0 = heff_dup(v_g_248); V b_1 = heff_get_n(v_ce_240, 0, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RGet, 1, (V[]){v_g_248});
    }
    case TAG_Just: {
      heff_take_n(v_x3_249, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x4_242_24SGlobal, TAG_RClo, 1, (V[]){v_g_248});
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  case TAG_SInt: {
    V v_n_2411 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SInt = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SInt, TAG_RInt, 1, (V[]){v_n_2411});
  }
  case TAG_SFloat: {
    V v_x_2412 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFloat, TAG_RFloat, 1, (V[]){v_x_2412});
  }
  case TAG_SStr: {
    V v_s_2413 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SStr = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SStr, TAG_RStr, 1, (V[]){v_s_2413});
  }
  case TAG_SBytes: {
    V v_s_2414 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SBytes = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SBytes, TAG_RBytes, 1, (V[]){v_s_2414});
  }
  case TAG_SFixed: {
    V v_w_2415 = heff_field(v_x4_242, 0);
    V v_n_2416 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SFixed = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFixed, TAG_RFixed, 2, (V[]){v_w_2415, v_n_2416});
  }
  case TAG_SFloat32: {
    V v_x_2417 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SFloat32 = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SFloat32, TAG_RF32, 1, (V[]){v_x_2417});
  }
  case TAG_SPrimFn: {
    V v_p_2418 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24SPrimFn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_live_241);
    return heff_tag_at_n(v_ru_24x4_242_24SPrimFn, TAG_RPrimFn, 1, (V[]){v_p_2418});
  }
  case TAG_SLam: {
    V v_xs_2419 = heff_field(v_x4_242, 0);
    V v_x42_2420 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x42_2420)) {
    case TAG_MkBlock: {
      V v_t_2421 = heff_field(v_x42_2420, 0);
      heff_take_n(v_x42_2420, 1ULL, 1);
      V v_t_2422 = (g_heff_2ecompile_2erc_2efreeOf(heff_dup(v_xs_2419), heff_dup(v_t_2421)));
      return (g_heff_2ecompile_2erc_2elamWith_24s522251335x630617780(v_ce_240, v_live_241, v_xs_2419, v_t_2421, v_t_2422));
    }
    default: return heff_nomatch(v_x42_2420);
    }
  }
  case TAG_STag: {
    V v_t_2423 = heff_field(v_x4_242, 0);
    V v_as_2424 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24STag = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_as_2424)) {
    case TAG_Nil: {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      heff_drop_cell(v_ru_24x4_242_24STag, 2);
      return heff_tag_n(TAG_RNTag, 1, (V[]){v_t_2423});
    }
    case TAG_Cons: {
      V v_t_2427 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(v_ce_240, v_live_241, v_as_2424));
      return heff_tag_at_n(v_ru_24x4_242_24STag, TAG_RTag, 2, (V[]){v_t_2423, v_t_2427});
    }
    default: return heff_nomatch(v_as_2424);
    }
  }
  case TAG_SRec: {
    V v_fs_2428 = heff_field(v_x4_242, 0);
    V v_ts_2429 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    V v_t_2430 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2428)));
    V v_t_2431 = (g_heff_2ecompile_2erc_2eupdatedIn(heff_dup(v_ce_240), v_live_241, v_t_2430, heff_dup(v_fs_2428)));
    return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_fs_2428; V a_3 = v_ts_2429; V a_4 = v_t_2431; V r_ = (g_heff_2ecompile_2erc_2erecordVal_24s1169650949x940510834(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_ts_2429); heff_drop(v_t_2431); r_; });
  }
  case TAG_SProj: {
    V v_e_2432 = heff_field(v_x4_242, 0);
    V v_l_2433 = heff_field(v_x4_242, 1);
    V v_sh_2434 = heff_field(v_x4_242, 2);
    V v_t_2435 = heff_field(v_x4_242, 3);
    heff_take_n(v_x4_242, 15ULL, 4);
    V v_t_2436 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_sh_2434));
    V v_t_2437 = ({ V a_0 = heff_dup(v_l_2433); V a_1 = MK_INT(0LL); V a_2 = v_sh_2434; V r_ = (g_heff_2ecompile_2erc_2eindexIn(a_0, a_1, a_2)); heff_drop(v_sh_2434); r_; });
    return (g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636(v_ce_240, v_live_241, v_e_2432, v_l_2433, v_t_2435, v_t_2436, v_t_2437));
  }
  case TAG_SPrim: {
    V v_p_2438 = heff_field(v_x4_242, 0);
    V v_as_2439 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24SPrim = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_p_2438), heff_dup(g_heff_2ecompile_2erc_2ereusePrim_get()))) {
      heff_drop(v_p_2438);
      heff_drop_cell(v_ru_24x4_242_24SPrim, 2);
      HEFF_LAST return g_heff_2ecompile_2erc_2ereuseVal_24s814420424x606195416(v_ce_240, v_live_241, v_as_2439);
    } else {
      V v_t_2441 = (g_heff_2ecompile_2erc_2eoperandsF_24s1094207497x1210215551(v_ce_240, v_live_241, v_as_2439));
      return heff_tag_at_n(v_ru_24x4_242_24SPrim, TAG_RPrim, 2, (V[]){v_p_2438, v_t_2441});
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_entry, 6, 0};

V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    heff_drop(v_x7_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_246 = heff_field(v_x6_244, 0);
    V v_rps_247 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x7_245)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_i_243);
      heff_drop(v_rp_246);
      heff_drop(v_rps_247);
      heff_drop_cell(v_ru_24x6_244_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_248 = heff_field(v_x7_245, 0);
      V v_es_249 = heff_field(v_x7_245, 1);
      heff_take_n(v_x7_245, 3ULL, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_249)));
      V v_t_2411 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2410; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2410); r_; });
      V v_t_2412 = (g_prelude_2e_2b_2b(v_t_2411, heff_dup(v_live_241)));
      V v_t_2413 = (g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766(heff_dup(v_ce_240), v_live_241, v_t_2412, v_bi_242, heff_dup(v_i_243), v_rp_246, v_e_248));
      V v_cell_2414 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = (g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps(v_ce_240, v_live_241, v_bi_242, heff_intAdd(v_i_243, MK_INT(1LL)), v_rps_247, v_es_249, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_x7_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_entry, 4, 0};

V g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(V v_ce_240, V v_c_241, V v_yes_242, V v_no_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_ICond, 1, (V[]){heff_dup(v_c_241)}), NTAG(TAG_Nil)});
  V v_x2_245 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
  V v_t_2411;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_bs_246 = heff_field(v_x2_245, 0);
    V v_ms_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    V v_bs_248 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_246));
    V v_ms_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_247));
    V v_t_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_248; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_248); r_; });
    v_t_2411 = ({ V a_0 = v_t_2410; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_249; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_2414;
  switch (heff_tag_of(v_yes_242)) {
  case TAG_ATail: {
    V v_t_2412 = heff_field(v_yes_242, 0);
    v_t_2414 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_2412)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2413 = heff_field(v_yes_242, 0);
    v_t_2414 = (g_heff_2ecompile_2erc_2efvSts(heff_dup(v_ss_2413)));
    break;
  }
  default: heff_nomatch(v_yes_242);
  }
  V v_t_2417;
  switch (heff_tag_of(v_no_243)) {
  case TAG_ATail: {
    V v_t_2415 = heff_field(v_no_243, 0);
    v_t_2417 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_2415)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2416 = heff_field(v_no_243, 0);
    v_t_2417 = (g_heff_2ecompile_2erc_2efvSts(heff_dup(v_ss_2416)));
    break;
  }
  default: heff_nomatch(v_no_243);
  }
  V v_t_2418 = (g_prelude_2e_2b_2b_24f489629841x1061860251(heff_dup(heff_rfield(v_ce_240, 5)), v_t_2414, v_t_2417));
  V v_t_2419 = (g_prelude_2e_2b_2b(v_t_2411, v_t_2418));
  return (g_heff_2ecompile_2erc_2econdTestWith_24s95975426x780169483(v_ce_240, v_c_241, v_yes_242, v_no_243, v_t_2419));
}
V g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2erc_2econdTest_24s831914183x1702665178(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_entry, 2, 0};

V g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178(V v_ce_240, V v_v_241) {
top: ;
  switch (heff_tag_of(v_v_241)) {
  case TAG_SVar: {
    V v_x_242 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SVar = heff_take_reuse_n(v_v_241, 1ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    return heff_tag_at_n(v_ru_24v_241_24SVar, TAG_RLocal, 1, (V[]){v_x_242});
  }
  case TAG_SGlobal: {
    V v_g_243 = heff_field(v_v_241, 0);
    V v_ru_24v_241_24SGlobal = heff_take_reuse_n(v_v_241, 1ULL, 1);
    V v_x3_244 = ({ V a_0 = heff_dup(v_g_243); V b_1 = heff_get_n(v_ce_240, 0, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RGetRaw, 1, (V[]){v_g_243});
    }
    case TAG_Just: {
      heff_take_n(v_x3_244, 0ULL, 1);
      return heff_tag_at_n(v_ru_24v_241_24SGlobal, TAG_RClo, 1, (V[]){v_g_243});
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_SInt: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SStr: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SBytes: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFixed: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SFloat32: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrimFn: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SLam: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_STag: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SRec: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SProj: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  case TAG_SPrim: {
    return (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_241));
  }
  default: return heff_nomatch(v_v_241);
  }
}
V g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2ercDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ercDef_entry, 3, 0};

V g_heff_2ecompile_2erc_2ercDef(V v_facts_240, V v_reprs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkDef: {
    V v_key_243 = heff_field(v_x3_242, 0);
    V v_x33_245 = heff_field(v_x3_242, 2);
    switch (heff_tag_of(v_x33_245)) {
    case TAG_DefFun: {
      V v_xs_246 = heff_field(v_x33_245, 0);
      V v_x332_247 = heff_field(v_x33_245, 1);
      switch (heff_tag_of(v_x332_247)) {
      case TAG_MkBlock: {
        V v_t_248 = heff_field(v_x332_247, 0);
        V v_t_249 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_take_field(v_facts_240, 0), heff_take_field(v_facts_240, 1), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_facts_240, 3), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), v_reprs_241, heff_get_n(v_facts_240, 4, 5), NTAG(TAG_RepV)});
        return (g_heff_2ecompile_2erc_2efunRc(v_t_249, heff_dup(v_key_243), heff_dup(v_xs_246), heff_dup(v_t_248)));
      }
      default: return heff_nomatch(v_x332_247);
      }
    }
    case TAG_DefVal: {
      V v_x331_2410 = heff_field(v_x33_245, 0);
      switch (heff_tag_of(v_x331_2410)) {
      case TAG_MkBlock: {
        V v_t_2411 = heff_field(v_x331_2410, 0);
        V v_t_2412 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_take_field(v_facts_240, 0), heff_take_field(v_facts_240, 1), NTAG(TAG_Nothing), MK_INT(0LL), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), heff_take_field(v_facts_240, 3), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), v_reprs_241, heff_get_n(v_facts_240, 4, 5), NTAG(TAG_RepV)});
        HEFF_LAST return g_heff_2ecompile_2erc_2evalRc(v_t_2412, heff_dup(v_key_243), heff_dup(v_t_2411));
      }
      default: return heff_nomatch(v_x331_2410);
      }
    }
    default: return heff_nomatch(v_x33_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2ercDef_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2ercDef(a[0], a[1], a2); heff_drop(a2); return r;
}