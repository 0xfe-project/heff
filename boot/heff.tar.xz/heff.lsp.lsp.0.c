// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Quit 47258
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Timeout 14063
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_children 257181584
#define LBL_cut 308412
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_end 310101
#define LBL_equals 651658986
#define LBL_errors 652506774
#define LBL_hashes 722717031
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2edriver_2efixitiesGo(V, V);
V g_heff_2ebuild_2edriver_2efixitiesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2efixitiesGo_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2edeclLine(V);
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclLine_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595(V, V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595_clo;
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857(V, V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178_clo;
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137_clo;
V g_heff_2elsp_2elsp_2ehandled_24s724284008x903683530(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s724284008x903683530_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s724284008x903683530_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_clo;
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228(V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s471260846x370540228_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprobedIn(V, V, V);
V g_heff_2elsp_2elsp_2eprobedIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedIn_clo;
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_clo;
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(V, V, V);
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_clo;
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212_clo;
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128(V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(V, V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(V, V);
V g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s474875037x969107480_clo;
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s361191175x1417189158(V, V);
V g_list_2efoldl_24s361191175x1417189158_entry(V self, V *a);
extern Clo g_list_2efoldl_24s361191175x1417189158_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1946778938x2117155621(V, V);
V g_list_2ekeepIf_24s1946778938x2117155621_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1946778938x2117155621_clo;
V g_list_2ekeepIf_24s677751599x1843430141(V, V);
V g_list_2ekeepIf_24s677751599x1843430141_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s677751599x1843430141_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 9, "character");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = heff_strLength_lent(v_src_240, 0);
  V v_y_244;
  if (heff_intLe_c_lent(v_x_242, v_i_241, 0)) {
    v_y_244 = v_x_242;
  } else {
    heff_drop(v_x_242);
    v_y_244 = heff_dup(v_i_241);
  }
  V v_i_246;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_244, 1)) {
    v_i_246 = v_y_244;
  } else {
    heff_drop(v_y_244);
    v_i_246 = MK_INT(0LL);
  }
  V v_x_247 = heff_strLength_lent(v_src_240, 0);
  V v_y_249;
  if (heff_intLe_c_lent(v_x_247, v_i_241, 0)) {
    heff_drop(v_i_241);
    v_y_249 = v_x_247;
  } else {
    heff_drop(v_x_247);
    v_y_249 = v_i_241;
  }
  V v_t_2411;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_249, 1)) {
    v_t_2411 = v_y_249;
  } else {
    heff_drop(v_y_249);
    v_t_2411 = MK_INT(0LL);
  }
  V v_j_2412 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eposition_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_2414;
  if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
    heff_drop(v_j_2412);
    v_t_2414 = NTAG(TAG_Nothing);
  } else {
    v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2412});
  }
  HeffT3 v_t_2415 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, v_t_2411, MK_INT(0LL), MK_INT(0LL), v_t_2414));
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    heff_drop(v_t_2415.f[2]);
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_field_2416})});
    V v_t_2420 = (g_heff_2elsp_2elsp_2eunits16Go(v_src_240, heff_intSub(heff_dup(v_i_246), v_field_2417), v_i_246, MK_INT(0LL)));
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2422})});
  }
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eposition(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 5, "start");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(heff_rfield(v_sp_241, 0))));
  V v_x_243 = heff_take_field(v_sp_241, 0);
  V v_y_244 = heff_get_n(v_sp_241, 1, 2);
  V v_t_246;
  if (heff_intLe_c_lent(v_x_243, v_y_244, 0)) {
    heff_drop(v_x_243);
    v_t_246 = v_y_244;
  } else {
    heff_drop(v_y_244);
    v_t_246 = v_x_243;
  }
  V v_t_247 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_246));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), v_t_242}), v_t_248});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_249});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2erange(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str1, 2, "{-");
Clo g_heff_2elsp_2elsp_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2edeclsGo(V v_x1_240, V v_key_241, V v_above_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_above_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_l_245 = heff_dup(heff_rfield(v_l_243, 1));
    if (heff_strEq_c(heff_strSlice_lent(v_l_245, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str0))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_l_245);
      V v_t_248;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_248 = heff_get_n(v_l_243, 0, 2);
        break;
      }
      case TAG_Just: {
        V v_x_247 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop_rec(v_l_243, 2);
        v_t_248 = v_x_247;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_244;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_248});
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      goto top;
    } else {
      if (heff_strEq_c(heff_strSlice(v_l_245, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str1))) {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        V v_t_2411;
        switch (heff_tag_of(v_above_242)) {
        case TAG_Nothing: {
          v_t_2411 = heff_get_n(v_l_243, 0, 2);
          break;
        }
        case TAG_Just: {
          V v_x_2410 = heff_field(v_above_242, 0);
          heff_take_n(v_above_242, 1ULL, 1);
          heff_drop_rec(v_l_243, 2);
          v_t_2411 = v_x_2410;
          break;
        }
        default: heff_nomatch(v_above_242);
        }
        V t_0 = v_rest_244;
        V t_1 = v_key_241;
        V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        goto top;
      } else {
        V v_t_2412 = (g_heff_2elsp_2elsp_2edeclLine(heff_rfield(v_l_243, 1)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop(v_t_2412);
          V v_t_2413 = (g_heff_2elsp_2elsp_2ekeyOf(heff_rfield(v_l_243, 1)));
          if (heff_strEq_c_lent(v_t_2413, v_key_241, 1)) {
            heff_drop(v_above_242);
            heff_drop_rec(v_l_243, 2);
            heff_drop_cell(v_ru_24x1_240_24Cons, 2);
            V t_0 = v_rest_244;
            V t_1 = v_key_241;
            V t_2 = NTAG(TAG_Nothing);
            v_x1_240 = t_0;
            v_key_241 = t_1;
            v_above_242 = t_2;
            goto top;
          } else {
            V v_n_2415 = heff_dup(heff_rfield(v_l_243, 0));
            HeffT2 v_t_2416 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(heff_rfield(v_l_243, 1)));
            V v_t_2422;
            {
              V v_field_2417 = v_t_2416.f[0];
              V v_field_2418 = v_t_2416.f[1];
              V v_t_2420;
              switch (heff_tag_of(v_above_242)) {
              case TAG_Nothing: {
                v_t_2420 = heff_dup(heff_rfield(v_l_243, 0));
                break;
              }
              case TAG_Just: {
                V v_x_2419 = heff_field(v_above_242, 0);
                heff_take_n(v_above_242, 1ULL, 1);
                v_t_2420 = v_x_2419;
                break;
              }
              default: heff_nomatch(v_above_242);
              }
              V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2417, heff_dup(v_n_2415)), heff_intAdd(v_field_2418, v_n_2415)});
              v_t_2422 = heff_rec_n(2, shape_cut__name, (V[]){v_t_2420, v_t_2421});
            }
            V v_cell_2423 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
            V v_t_2424 = ({ V b_0 = heff_get_n(v_l_243, 1, 2); V r_ = (g_heff_2elsp_2elsp_2ekeyOf(b_0)); heff_drop(b_0); r_; });
            V v_u_2425 = (g_heff_2elsp_2elsp_2edeclsGo_24dps(v_rest_244, v_t_2424, NTAG(TAG_Nothing), heff_dup(v_cell_2423)));
            heff_drop(v_u_2425);
            return v_cell_2423;
          }
        } else {
          heff_drop(v_above_242);
          heff_drop_rec(v_l_243, 2);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_t_2412);
          V t_0 = v_rest_244;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          goto top;
        }
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2edeclsGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s677751599x1843430141(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str5, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str6, 4, "name");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_241, 1)});
  V v_x_244 = heff_get_n(heff_dup(heff_rfield(v_y_241, 2)), 1, 2);
  V v_y_245 = heff_get_n(heff_dup(heff_rfield(v_y_241, 3)), 1, 2);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_y_241, 2)), 0, 2);
  V v_t_248;
  if (heff_intLe_c_lent(v_x_244, v_y_245, 0)) {
    heff_drop(v_x_244);
    v_t_248 = v_y_245;
  } else {
    heff_drop(v_y_245);
    v_t_248 = v_x_244;
  }
  V v_t_249 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_t_246)));
  V v_t_2411;
  if (heff_intLe_c_lent(v_t_246, v_t_248, 0)) {
    heff_drop(v_t_246);
    v_t_2411 = v_t_248;
  } else {
    heff_drop(v_t_248);
    v_t_2411 = v_t_246;
  }
  V v_t_2412 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_2411));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), v_t_249}), v_t_2413});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2414})});
  V v_t_2416 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_take_field(v_y_241, 3)));
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), heff_get_n(v_y_241, 4, 5)));
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), v_t_2416}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str5), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str6), v_t_242}), v_t_2422});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2edocSymbol(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2417 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_src_240; V a_1 = v_m_2417; V r_ = (g_heff_2elsp_2elsp_2echildJson(a_0, a_1)); heff_drop(v_src_240); r_; });
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_247;
    if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL))) {
        int64_t v_t_246 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) + ((int64_t)32ULL));
        v_t_247 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_246))));
      } else {
        v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))));
      }
    } else {
      v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))));
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_247);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elowerGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V v_changed_240, V v_mods_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_244, 1))}));
    V v_t_247 = (g_list_2eany(v_t_246, v_changed_240));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
      V t_0 = v_changed_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_245;
      V t_3 = v_cell_248;
      v_changed_240 = t_0;
      v_mods_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_247);
      V v_t_2413 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_244, 8)));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_cell_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
        V v_u_2415 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
        V t_0 = v_changed_240;
        V t_1 = v_t_2416;
        V t_2 = v_rest_245;
        V t_3 = v_cell_2414;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_rec(v_c_244, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2413);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args) {
  V v_d_2411 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2411}));
  return ({ V a_0 = v_t_2412; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str0, 31, "Write the module claim `module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str1, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str2, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str4, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str6, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str7, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str9, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str10, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str11, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str12, 11, "isPreferred");
Clo g_heff_2elsp_2elsp_2eclaimAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimAction_entry, 5, 0};

V g_heff_2elsp_2elsp_2eclaimAction(V v_uri_240, V v_src_241, V v_n_242, V v_ds_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_text_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_247 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimAction_str0), heff_strAppend(v_n_242, ((V)&g_heff_2elsp_2elsp_2eclaimAction_str1)));
    V v_t_248 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str2), heff_tag_n(TAG_JString, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str4)})});
    V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_243})});
    V v_t_2411 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(heff_rfield(v_sp_245, 0))));
    V v_x_2412 = heff_take_field(v_sp_245, 0);
    V v_y_2413 = heff_get_n(v_sp_245, 1, 2);
    V v_t_2415;
    if (heff_intLe_c_lent(v_x_2412, v_y_2413, 0)) {
      heff_drop(v_x_2412);
      v_t_2415 = v_y_2413;
    } else {
      heff_drop(v_y_2413);
      v_t_2415 = v_x_2412;
    }
    V v_t_2416 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_2415));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str6), v_t_2416}), NTAG(TAG_Nil)});
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str7), v_t_2411}), v_t_2417});
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str9), heff_tag_n(TAG_JString, 1, (V[]){v_text_246})});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    V v_t_2422 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
    V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
    V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_t_2428 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str11), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, NTAG(TAG_Nil)});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str12), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2429});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2430})});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2431})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclaimAction(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_entry, 6, 0};

V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634(V v_st_240, V v_f_241, V v_d_242, V v_cut_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_2429 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam0, 1, 4, (V[]){heff_dup(v_f_241), heff_dup(v_d_242), heff_dup(v_cut_243), heff_dup(v_st_240)}), heff_get_n(v_st_240, 6, 7), v_f_241));
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam4, 1, 3, (V[]){v_z_244, v_d_242, v_z_245})});
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_d_242 = heff_env(self)[0];
  V v_cut_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2410 = heff_strSlice(heff_get_n(v_d_242, 1, 2), MK_INT(0LL), v_cut_243);
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2415, 1, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam3(V self, V *args) {
  V v_t_2421 = args[0];
  return v_t_2421;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam0(V self, V *args) {
  V v_p_246 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_cut_243 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_p_246, v_f_241, 2)) {
    heff_drop(v_p_246);
    heff_drop_rec(v_st_240, 7);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam1, 2, 2, (V[]){v_d_242, v_cut_243});
  } else {
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_cut_243);
    HeffT2 v_t_2411 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2413 = v_t_2411.f[1];
      int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
      if ((v_tag_2412 == ((int64_t)0ULL))) {
        heff_drop(v_p_246);
        V v_d_2415 = v_field_2413;
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam2, 2, 1, (V[]){v_d_2415});
      } else {
        heff_drop(v_field_2413);
        V v_path_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_246; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2419; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2419); r_; });
        V v_a_2422 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2420, ((V)&g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam3_clo)});
        V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2422})});
        V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
        V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
        V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
        V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
        V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
        V f_ = ((V)&g_co_2eop_24s22628809x1035315751_clo);
        args[0] = v_t_2428;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2438; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam5(V self, V *args) {
  V v_x_2433 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2434 = heff_get_n(v_x_2433, 0, 2);
  V v_program_2435 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2434)));
  V v_t_2436 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2434));
  V v_t_2437 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_242, 1)), v_t_2436, heff_get_n(v_x_2430, 1, 5)));
  V v_diags_2439 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam6, 1, 1, (V[]){v_d_242}), v_t_2437));
  V f_ = v_z_245;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2435, v_diags_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2431 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get())});
  V v_c_2432 = (g_heff_2ebuild_2esession_2ecachedGo_24s1130614146x626582412(heff_dup(heff_rfield(v_x_2430, 2)), heff_dup(heff_rfield(v_x_2430, 0)), v_t_2431));
  V f_ = v_c_2432;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s994155138x593855634_lam5, 1, 3, (V[]){v_d_242, v_x_2430, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_str0, 13, "textDocument/");
HEFF_LIT(g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_str1, 31, "workspace/didChangeWatchedFiles");
Clo g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_entry, 6, 0};

V g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289(V v_wire_240, V v_st_241, V v_m_242, V v_p_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_248;
  if (heff_strEq_c(heff_strSlice_lent(v_m_242, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_str0))) {
    v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_241, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_str1), 2)) {
      v_t_248 = ({ V rv_3 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_st_241, 119ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_248 = v_st_241;
    }
  }
  V v_t_249 = (g_heff_2elsp_2elsp_2enotified_24s471260846x370540228(v_wire_240, v_t_248, v_m_242, v_p_243));
  return heff_tail(v_t_249, 2, (V[]){v_z_244, v_z_245});
}
V g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2enotification_24s606526382x2118564289(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_entry, 3, 0};

V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(V v_wire_240, V v_st_241, V v_f_242) {
top: ;
  V v_c_243 = (g_heff_2ebuild_2eload_2epathsFor_24s1953010924x322299530(heff_dup(heff_rfield(v_st_241, 6)), heff_dup(v_f_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_lam0, 2, 4, (V[]){v_c_243, v_st_241, v_wire_240, v_f_242});
}
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = heff_dup(heff_rfield(v_st_241, 3));
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    return (g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212(v_wire_240, v_st_241, heff_get_n(v_x_246, 0, 6), v_f_242, v_hd_244, v_k_245));
  }
  case TAG_Just: {
    V v_pr_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_pr_248, 0)), heff_dup(heff_rfield(v_x_246, 0)))) {
      heff_drop_rec(v_x_246, 6);
      heff_drop(v_wire_240);
      heff_drop(v_f_242);
      heff_drop(v_hd_244);
      V v_t_2410 = heff_rec_n(2, shape_st__program, (V[]){v_st_241, heff_get_n(v_pr_248, 1, 2)});
      V f_ = v_k_245;
      args[0] = v_t_2410;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop_rec(v_pr_248, 2);
      return (g_heff_2elsp_2elsp_2eprojectAnew_24s1082519629x1487225212(v_wire_240, v_st_241, heff_get_n(v_x_246, 0, 6), v_f_242, v_hd_244, v_k_245));
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101_lam1, 1, 5, (V[]){v_st_241, v_wire_240, v_f_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_entry, 3, 0};

V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128(V v_wire_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam0, 2, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_242, 0);
    V v_rest_247 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_MkPair: {
      V v_f_249 = heff_field(v_x21_246, 1);
      V v_c_2410 = (g_heff_2elsp_2elsp_2eproject_24s343409559x1743592101(heff_dup(v_wire_240), v_st_241, heff_dup(v_f_249)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam1, 2, 3, (V[]){v_c_2410, v_wire_240, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(2, shape_st__program, (V[]){v_st_241, NTAG(TAG_Nil)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_program_2416 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2413, 1, 2), heff_take_field(v_x_2415, 1)));
  V v_t_2417 = ({ V rv_1 = v_program_2416; V rr_ = heff_rec_reuse_nf(v_x_2415, 1ULL, 2, shape_st__program, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2412;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_rest_247 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2414 = ({ V a_0 = v_wire_240; V a_1 = heff_dup(heff_rfield(v_x_2413, 0)); V a_2 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128(a_0, a_1, a_2)); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam3, 1, 2, (V[]){v_x_2413, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s882991243x1572004128_lam2, 1, 4, (V[]){v_wire_240, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str1, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str2, 8, "location");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str3, 13, "containerName");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str4, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str5, 4, "name");
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam1, 1, 0};
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_entry, 4, 0};

V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733(V v_wire_240, V v_st_241, V v_c_242, V v_y_243) {
top: ;
  V v_p_244 = heff_dup(heff_rfield(v_c_242, 1));
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2414;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_wire_240);
      heff_drop(v_p_244);
      V v_d_249 = v_field_247;
      v_c_2414 = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam0, 2, 1, (V[]){v_d_249});
    } else {
      heff_drop(v_field_247);
      V v_t_2413 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_244, ((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam1_clo)})}));
      v_c_2414 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2413}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam2, 2, 3, (V[]){v_c_2414, v_y_243, v_c_242});
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_d_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_get_n(v_d_249, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  return v_u_2412;
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_y_243 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_243, 0)});
  V v_t_2419 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_243, 1)});
  V v_t_2420 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_c_242, 0)});
  V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2417})});
  V v_t_2422 = ({ V b_0 = heff_get_n(v_c_242, 3, 14); V a_1 = heff_get_n(v_y_243, 3, 5); V r_ = (g_heff_2elsp_2elsp_2erange(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str1), v_t_2422}), NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str2), v_t_2424}), NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str3), v_t_2420}), v_t_2425});
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str4), v_t_2419}), v_t_2426});
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_str5), v_t_2418}), v_t_2427});
  V v_x_2429 = heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428});
  V f_ = v_k_2416;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_y_243 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2414;
  args[0] = v_hd_2415;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolJson_24s1850330948x828954733_lam3, 1, 3, (V[]){v_y_243, v_c_242, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_entry, 4, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806(V v_wire_240, V v_st_241, V v_query_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_t_248 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_246)));
    V v_t_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam1, 1, 1, (V[]){heff_dup(v_query_242)}), v_t_248));
    V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s2073548166x834852595(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_c_246), v_t_2411));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam2, 2, 5, (V[]){v_c_2412, v_wire_240, v_st_241, heff_dup(v_query_242), heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam1(V self, V *args) {
  V v_y_249 = args[0];
  V v_query_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_2410 = ({ V b_0 = heff_get_n(v_y_249, 0, 5); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_str0); V r_ = (g_heff_2elsp_2elsp_2elowerGo(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  return heff_intLe(MK_INT(0LL), heff_strFind(v_query_242, v_s_2410, MK_INT(0LL)));
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = (g_prelude_2e_2b_2b(v_x_2415, v_x_2417));
  V f_ = v_k_2414;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_query_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2416 = ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_query_242; V a_3 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806(a_0, a_1, a_2, a_3)); heff_drop(v_query_242); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam4, 1, 2, (V[]){v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_query_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s596426289x2107129806_lam3, 1, 6, (V[]){v_wire_240, v_st_241, v_query_242, v_rest_247, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str2, 4, "code");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str3, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str4, 5, "error");
HEFF_LIT(g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str5, 2, "id");
Clo g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_entry, 4, 0};

V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(V v_wire_240, V v_id_241, V v_code_242, V v_msg_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str1)})});
  V v_t_245 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_code_242})});
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str3), heff_tag_n(TAG_JString, 1, (V[]){v_msg_243})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str4), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_str5), v_id_241}), v_t_249});
  V v_t_2411 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2410})});
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2411, 1); r_; });
  V v_t_2413 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2413}));
  return heff_tail(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2414});
}
V g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ereplyError_24s1351194836x418868589(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str7, 2, "id");
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_entry, 4, 0};

V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857(V v_wire_240, V v_st_241, V v_id_242, V v_p_243) {
top: ;
  V v_c_244 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s321552613x83731986(heff_dup(v_wire_240), v_p_243));
  return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam0, 2, 4, (V[]){v_c_244, v_id_242, v_wire_240, v_st_241});
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_d_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2428, 1, 2)});
  V f_ = v_k_2430;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam5(V self, V *args) {
  V v_t_2434 = args[0];
  return v_t_2434;
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam3(V self, V *args) {
  V v_q_2423 = args[0];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2424 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_q_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      heff_drop(v_q_2423);
      V v_d_2428 = v_field_2426;
      return heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam4, 2, 1, (V[]){v_d_2428});
    } else {
      heff_drop(v_field_2426);
      V v_path_2432 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_q_2423; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2433 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2432; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2432); r_; });
      V v_a_2435 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2433, ((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam5_clo)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      V f_ = ((V)&g_co_2eop_24s22628809x1035315751_clo);
      args[0] = v_t_2441;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_d_2422 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2444 = (g_heff_2ebuild_2edriver_2efixitiesGo(NTAG(TAG_Nil), heff_get_n(v_x_2443, 0, 5)));
  return (g_heff_2elsp_2elsp_2eformattedIn_24s1670659863x1431969178(v_wire_240, v_st_241, v_id_242, v_d_2422, v_t_2444, v_hd_245, v_k_246));
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2453);
  V f_ = v_k_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_id_242 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str1)})});
    V v_t_249 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str2), v_t_249}), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str3), v_id_242}), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, v_t_2411})});
    V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2412, 1); r_; });
    V v_t_2414 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2413, NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2414}));
    return (g_co_2eop_24s495635622x733177935(v_t_2415, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam2, 1, 2, (V[]){v_k_246, v_st_241})));
  }
  case TAG_Just: {
    V v_f_2417 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    HeffT2 v_t_2418 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_f_2417));
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_247_24Just, 1);
        V v_d_2422 = v_field_2420;
        V v_c_2442 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam3, 1, 1, (V[]){heff_dup(v_st_241)}), heff_dup(heff_rfield(v_st_241, 6)), v_f_2417));
        V f_ = v_c_2442;
        heff_room[0] = heff_dup(v_hd_245);
        heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam6, 1, 6, (V[]){v_wire_240, v_st_241, v_id_242, v_d_2422, v_hd_245, v_k_246});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_f_2417);
        heff_drop(v_field_2420);
        V v_t_2445 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str4), heff_tag_at_n(v_ru_24x_247_24Just, TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str5)})});
        V v_t_2446 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
        V v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str6), v_t_2446}), NTAG(TAG_Nil)});
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_str7), v_id_242}), v_t_2447});
        V v_t_2449 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_t_2448})});
        V v_t_2450 = ({ V a_0 = v_t_2449; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2449, 1); r_; });
        V v_t_2451 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2450, NTAG(TAG_MkUnit)});
        V v_t_2452 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2451}));
        return (g_co_2eop_24s495635622x733177935(v_t_2452, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam7, 1, 2, (V[]){v_k_246, v_st_241})));
      }
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eformatted_24s1852382042x1257706857_lam1, 1, 5, (V[]){v_id_242, v_wire_240, v_hd_245, v_k_246, v_st_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_str0, 1, " ");
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam3, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam4(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_entry, 6, 0};

V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661(V v_wire_240, V v_st_241, V v_f_242, V v_program_243, V v_c_244, V v_s_245) {
top: ;
  V v_c_2433 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s453391823x1667036568(heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam0, 1, 4, (V[]){heff_dup(v_f_242), v_c_244, heff_dup(v_s_245), heff_dup(v_st_241)}), heff_get_n(v_st_241, 6, 7), v_f_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam4, 2, 4, (V[]){v_c_2433, v_wire_240, v_program_243, v_s_245});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_src_2410 = heff_get_n(v_c_244, 3, 14);
  V v_t_2411 = heff_strSlice(heff_dup(v_src_2410), MK_INT(0LL), heff_take_field(v_s_245, 3));
  V v_t_2412 = heff_strSlice(heff_dup(v_src_2410), heff_take_field(v_s_245, 4), heff_strLength(v_src_2410));
  V v_t_2413 = heff_strAppend(heff_get_n(v_s_245, 0, 5), v_t_2412);
  V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_str0), v_t_2413));
  V f_ = v_k_249;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_d_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2420);
  V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2419, 1, 2)});
  V f_ = v_k_2421;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam3(V self, V *args) {
  V v_t_2425 = args[0];
  return v_t_2425;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam0(V self, V *args) {
  V v_q_246 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_q_246, v_f_242, 2)) {
    heff_drop(v_q_246);
    heff_drop_rec(v_st_241, 7);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam1, 2, 2, (V[]){v_c_244, v_s_245});
  } else {
    heff_drop_rec(v_c_244, 14);
    heff_drop_rec(v_s_245, 5);
    HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_q_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2417 = v_t_2415.f[1];
      int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
      if ((v_tag_2416 == ((int64_t)0ULL))) {
        heff_drop(v_q_246);
        V v_d_2419 = v_field_2417;
        return heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam2, 2, 1, (V[]){v_d_2419});
      } else {
        heff_drop(v_field_2417);
        V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_q_246; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2423; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2423); r_; });
        V v_a_2426 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2424, ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam3_clo)});
        V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2426})});
        V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
        V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
        V f_ = ((V)&g_co_2eop_24s22628809x1035315751_clo);
        args[0] = v_t_2432;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam7(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_x_2436 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2438);
  V v_x1_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_x_2436, 0, 5)));
  V v_t_2443;
  switch (heff_tag_of(v_x1_2440)) {
  case TAG_Nil: {
    v_t_2443 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2441 = heff_field(v_x1_2440, 0);
    heff_take_n(v_x1_2440, 1ULL, 2);
    v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2441});
    break;
  }
  default: heff_nomatch(v_x1_2440);
  }
  V v_x_2444 = (g_heff_2elsp_2elsp_2eprobedIn(v_program_243, v_s_245, v_t_2443));
  V f_ = v_k_2439;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam8(V self, V *args) {
  V v_r_2445 = args[0];
  return v_r_2445;
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam6(V self, V *args) {
  V v_use_2437 = args[0];
  V v_x_2436 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2437;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam7, 2, 3, (V[]){v_x_2436, v_program_243, v_s_245});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam8_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam9(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    heff_take_n(v_x_2447, 0ULL, 1);
    v_t_2450 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_t_2449 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    v_t_2450 = v_t_2449;
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V f_ = v_k_2435;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam5(V self, V *args) {
  V v_x_2436 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_s_245 = heff_env(self)[2];
  V v_hd_2434 = heff_env(self)[3];
  V v_k_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2446 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam6, 1, 3, (V[]){v_x_2436, v_program_243, v_s_245})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2446, v_hd_2434, heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam9, 1, 1, (V[]){v_k_2435})));
}
V g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam4(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_program_243 = heff_env(self)[2];
  V v_s_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprobedType_24s1160041716x1359958661_lam5, 1, 5, (V[]){v_wire_240, v_program_243, v_s_245, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_entry, 5, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493(V v_wire_240, V v_st_241, V v_x2_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_z_243);
    return heff_tail(v_z_244, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    V v_c_247 = (g_heff_2elsp_2elsp_2echeckNow_24s467972391x2045008201(heff_dup(v_wire_240), v_st_241, heff_dup(v_f_245)));
    return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_lam0, 1, 4, (V[]){v_wire_240, heff_dup(v_rest_246), v_z_243, v_z_244})});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_wire_240; V a_1 = v_x_248; V a_2 = v_rest_246; V a_3 = v_z_243; V a_4 = v_z_244; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_rest_246); r_; });
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam12(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam12, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_entry, 4, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(V v_wire_240, V v_st_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_245 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam0_clo)})}));
  return (g_co_2eop_24s495635622x733177935(v_t_245, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam1, 1, 4, (V[]){v_st_241, v_wire_240, v_z_242, v_z_243})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return v_n_244;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam4(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2ehandle_24s419963604x509854137(v_wire_240, v_st_241, v_msg_2418, v_hd_2420, v_k_2421));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam5(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam3(V self, V *args) {
  V v_use_2419 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2418 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2419;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam4, 2, 3, (V[]){v_wire_240, v_st_241, v_msg_2418});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam5_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(v_wire_240, v_x_2426, v_z_242, v_z_243));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2418 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2425 = (g_heff_2elsp_2elsp_2ehandled_24s724284008x903683530(heff_dup(v_wire_240), v_st_241, v_msg_2418, v_x_2424));
  V f_ = v_c_2425;
  heff_room[0] = heff_dup(v_z_242);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam7, 1, 3, (V[]){v_wire_240, v_z_242, v_z_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam8(V self, V *args) {
  V v_n_2427 = args[0];
  return v_n_2427;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam11(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_st_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2433 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_2434 = (g_list_2ekeepIf_24s1946778938x2117155621(v_x_2429, v_t_2433));
  V v_t_2435 = (g_list_2emap_24s1415906091x1371825187(v_t_2434));
  return ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_t_2435; V a_3 = v_hd_2431; V a_4 = v_k_2432; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1828694484x943167493(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2435); r_; });
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam12(V self, V *args) {
  V v_r_2436 = args[0];
  return v_r_2436;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam10(V self, V *args) {
  V v_use_2430 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2430;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam11, 2, 3, (V[]){v_st_241, v_x_2429, v_wire_240});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam12_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam13(V self, V *args) {
  V v_x_2438 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2439 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_2440 = (g_list_2ekeepIf_24s1946778938x2117155621(v_x_2429, v_t_2439));
  V v_fs_2441 = (g_list_2emap_24s1415906091x1371825187(v_t_2440));
  V v_t_2445;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    V v_t_2443 = ({ V a_0 = heff_take_field(v_st_241, 2); V a_1 = v_fs_2441; V r_ = (g_heff_2elsp_2elsp_2eundue(a_0, a_1)); heff_drop(v_fs_2441); r_; });
    v_t_2445 = ({ V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_st_241, 123ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 16335u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    break;
  }
  case TAG_Right: {
    V v_st2_2444 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    heff_drop_rec(v_st_241, 7);
    heff_drop(v_fs_2441);
    v_t_2445 = v_st2_2444;
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  return (g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242(v_wire_240, v_t_2445, v_z_242, v_z_243));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2437 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam10, 1, 3, (V[]){heff_dup(v_st_241), heff_dup(v_x_2429), heff_dup(v_wire_240)})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2437, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam13, 1, 5, (V[]){v_st_241, v_x_2429, v_wire_240, v_z_242, v_z_243})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Message: {
    V v_msg_2418 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    V v_t_2423 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam3, 1, 3, (V[]){heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_msg_2418)})})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2423, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam6, 1, 5, (V[]){v_wire_240, v_st_241, v_msg_2418, v_z_242, v_z_243})));
  }
  case TAG_Timeout: {
    V v_t_2428 = heff_tr(heff_call(heff_dup(v_wire_240), 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam8_clo)})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2428, heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam9, 1, 4, (V[]){v_wire_240, v_st_241, v_z_242, v_z_243})));
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_241, 7);
    V v_t_2446 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})}));
    return (g_co_2eop_24s495635622x733177935(v_t_2446, v_z_242, v_z_243));
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_z_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = (g_std_2emap_2etoListOnto(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_248 = (g_list_2emap_24s366344330x1145113647(v_t_247));
  V v_t_2415;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    heff_drop(v_x_246);
    v_t_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_249 = heff_field(v_t_248, 0);
    V v_ds_2410 = heff_field(v_t_248, 1);
    heff_take_n(v_t_248, 3ULL, 2);
    V v_t_2411 = ({ V a_0 = v_d_249; V a_1 = v_ds_2410; V r_ = (g_list_2efoldl_24s361191175x1417189158(a_0, a_1)); heff_drop(v_ds_2410); r_; });
    V v_y_2412 = heff_intSub(v_t_2411, v_x_246);
    V v_t_2414;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2412, 1)) {
      v_t_2414 = v_y_2412;
    } else {
      heff_drop(v_y_2412);
      v_t_2414 = MK_INT(0LL);
    }
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_c_2416 = ({ V a_0 = heff_dup(v_wire_240); V a_1 = v_t_2415; V r_ = (g_heff_2elsp_2erpc_2eawait_24s474875037x969107480(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_z_242);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s155059918x357838242_lam2, 1, 4, (V[]){v_wire_240, v_st_241, v_z_242, v_z_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}