// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_PathUri 23459
#define TAG_Right 62770
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_Send 26077
#define LBL_at 9882
#define LBL_checked 974171621
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_cut 308412
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_hashes 722717031
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_watch 314261737
static uint32_t shape_cut__name[] = {LBL_cut, LBL_name};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_done__hashes[] = {LBL_done, LBL_hashes};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(V, V, V);
V g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(V, V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2eclaimAction(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimAction_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823(V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_clo;
V g_heff_2elsp_2elsp_2edeclLine(V);
V g_heff_2elsp_2elsp_2edeclLine_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclLine_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2edeclsGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_24dps_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608(V, V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608_clo;
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_clo;
V g_heff_2elsp_2elsp_2ejtrue_get(void);
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2ekeyOf(V);
V g_heff_2elsp_2elsp_2ekeyOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeyOf_clo;
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(V, V, V);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_clo;
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680(V, V, V);
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
HeffT2 g_heff_2elsp_2elsp_2enamedIn_24cpr(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubSources(V);
V g_heff_2elsp_2elsp_2enubSources_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubSources_clo;
V g_heff_2elsp_2elsp_2eoffsetGo(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eoffsetGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetGo_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(V, V, V);
V g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380(V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770(V, V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_clo;
V g_heff_2elsp_2elsp_2erenameVerdict(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_clo;
V g_heff_2elsp_2elsp_2erenameVerdict_24tok1(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenameVerdict_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameVerdict_24tok1_clo;
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_heff_2elsp_2erender_2enumDigits(V);
V g_heff_2elsp_2erender_2enumDigits_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2enumDigits_clo;
V g_heff_2elsp_2erender_2erepeated(V, V);
V g_heff_2elsp_2erender_2erepeated_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2erepeated_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1497517957x114012878(V);
V g_list_2eany_24s1497517957x114012878_entry(V self, V *a);
extern Clo g_list_2eany_24s1497517957x114012878_clo;
V g_list_2eany_24s1795474228x706402294(V, V);
V g_list_2eany_24s1795474228x706402294_entry(V self, V *a);
extern Clo g_list_2eany_24s1795474228x706402294_clo;
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2051016282x1892781518(V, V, V, V);
V g_list_2efoldl_24s2051016282x1892781518_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2051016282x1892781518_clo;
V g_list_2efoldl_24s655928500x1399206842(V, V);
V g_list_2efoldl_24s655928500x1399206842_entry(V self, V *a);
extern Clo g_list_2efoldl_24s655928500x1399206842_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2emap_2edelete_24s1614046289x1611773644(V, V);
V g_std_2emap_2edelete_24s1614046289x1611773644_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s1614046289x1611773644_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 9, "character");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = heff_strLength_lent(v_src_240, 0);
  V v_y_243;
  if (heff_intLe_c_lent(v_x_242, v_i_241, 0)) {
    v_y_243 = v_x_242;
  } else {
    heff_drop(v_x_242);
    v_y_243 = heff_dup(v_i_241);
  }
  V v_i_244;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
    v_i_244 = v_y_243;
  } else {
    heff_drop(v_y_243);
    v_i_244 = MK_INT(0LL);
  }
  V v_x_245 = heff_strLength_lent(v_src_240, 0);
  V v_y_246;
  if (heff_intLe_c_lent(v_x_245, v_i_241, 0)) {
    heff_drop(v_i_241);
    v_y_246 = v_x_245;
  } else {
    heff_drop(v_x_245);
    v_y_246 = v_i_241;
  }
  V v_t_247;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = MK_INT(0LL);
  }
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eposition_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  HeffT3 v_t_2410 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, v_t_247, MK_INT(0LL), MK_INT(0LL), v_t_249));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[2]);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_field_2411})});
    V v_t_2415 = (g_heff_2elsp_2elsp_2eunits16Go(v_src_240, heff_intSub(heff_dup(v_i_244), v_field_2412), v_i_244, MK_INT(0LL)));
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417})});
  }
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eposition(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 5, "start");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_start_242 = heff_take_field(v_sp_241, 0);
  V v_end_243 = heff_get_n(v_sp_241, 1, 2);
  V v_t_244 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_start_242)));
  V v_x_245 = v_start_242;
  V v_y_246 = v_end_243;
  V v_t_247;
  if (heff_intLe_c_lent(v_x_245, v_y_246, 0)) {
    heff_drop(v_x_245);
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = v_x_245;
  }
  V v_t_248 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), v_t_248}), NTAG(TAG_Nil)});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), v_t_244}), v_t_249});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2410});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2erange(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str0, 2, "--");
HEFF_LIT(g_heff_2elsp_2elsp_2edeclsGo_str1, 2, "{-");
Clo g_heff_2elsp_2elsp_2edeclsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edeclsGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2edeclsGo(V v_x1_240, V v_key_241, V v_above_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_above_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_text_245 = heff_take_field(v_l_243, 1);
    V v_at_246 = heff_get_n(v_l_243, 0, 2);
    V v_l_247 = heff_dup(v_text_245);
    if ((heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str0)) || heff_strEq_c(heff_strSlice_lent(v_l_247, MK_INT(0LL), MK_INT(2LL), 6), ((V)&g_heff_2elsp_2elsp_2edeclsGo_str1)))) {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_text_245);
      heff_drop(v_l_247);
      V v_t_249;
      switch (heff_tag_of(v_above_242)) {
      case TAG_Nothing: {
        v_t_249 = v_at_246;
        break;
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_above_242, 0);
        heff_take_n(v_above_242, 1ULL, 1);
        heff_drop(v_at_246);
        v_t_249 = v_x_248;
        break;
      }
      default: heff_nomatch(v_above_242);
      }
      V t_0 = v_rest_244;
      V t_1 = v_key_241;
      V t_2 = heff_tag_n(TAG_Just, 1, (V[]){v_t_249});
      v_x1_240 = t_0;
      v_key_241 = t_1;
      v_above_242 = t_2;
      goto top;
    } else {
      heff_drop(v_l_247);
      V v_t_2410 = (g_heff_2elsp_2elsp_2edeclLine(v_text_245));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2elsp_2elsp_2ekeyOf(v_text_245));
        V v_x1_2412 = heff_bool(heff_strEq_c_lent(v_t_2411, v_key_241, 0));
        heff_drop(v_t_2411);
        if (!(heff_dup(v_x1_2412) == NTAG(TAG_True))) {
          heff_drop(v_x1_2412);
          V v_n_2413 = heff_dup(v_at_246);
          HeffT2 v_t_2414 = (g_heff_2elsp_2elsp_2enamedIn_24cpr(v_text_245));
          V v_t_2420;
          {
            V v_field_2415 = v_t_2414.f[0];
            V v_field_2416 = v_t_2414.f[1];
            V v_t_2418;
            switch (heff_tag_of(v_above_242)) {
            case TAG_Nothing: {
              v_t_2418 = v_at_246;
              break;
            }
            case TAG_Just: {
              V v_x_2417 = heff_field(v_above_242, 0);
              heff_take_n(v_above_242, 1ULL, 1);
              heff_drop(v_at_246);
              v_t_2418 = v_x_2417;
              break;
            }
            default: heff_nomatch(v_above_242);
            }
            V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(v_field_2415, heff_dup(v_n_2413)), heff_intAdd(v_field_2416, v_n_2413)});
            v_t_2420 = heff_rec_n(2, shape_cut__name, (V[]){v_t_2418, v_t_2419});
          }
          V v_cell_2421 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
          V v_t_2422 = ({ V a_0 = v_text_245; V r_ = (g_heff_2elsp_2elsp_2ekeyOf(a_0)); heff_drop(v_text_245); r_; });
          V v_u_2423 = (g_heff_2elsp_2elsp_2edeclsGo_24dps(v_rest_244, v_t_2422, NTAG(TAG_Nothing), heff_dup(v_cell_2421)));
          heff_drop(v_u_2423);
          return v_cell_2421;
        } else {
          heff_drop(v_above_242);
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_text_245);
          heff_drop(v_at_246);
          heff_drop(v_x1_2412);
          V t_0 = v_rest_244;
          V t_1 = v_key_241;
          V t_2 = NTAG(TAG_Nothing);
          v_x1_240 = t_0;
          v_key_241 = t_1;
          v_above_242 = t_2;
          goto top;
        }
      } else {
        heff_drop(v_above_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_text_245);
        heff_drop(v_at_246);
        heff_drop(v_t_2410);
        V t_0 = v_rest_244;
        V t_1 = v_key_241;
        V t_2 = NTAG(TAG_Nothing);
        v_x1_240 = t_0;
        v_key_241 = t_1;
        v_above_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2edeclsGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 4, "name");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str5, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str6, 14, "selectionRange");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_name_242 = heff_take_field(v_y_241, 0);
  V v_kind_243 = heff_take_field(v_y_241, 1);
  V v_span_244 = heff_take_field(v_y_241, 2);
  V v_selection_245 = heff_take_field(v_y_241, 3);
  V v_children_246 = heff_get_n(v_y_241, 4, 5);
  V v_t_247 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), heff_tag_n(TAG_JString, 1, (V[]){v_name_242})});
  V v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_kind_243})});
  V v_x_249 = heff_take_field(v_span_244, 1);
  V v_y_2410 = heff_dup(heff_rfield(v_selection_245, 1));
  V v_t_2411 = heff_get_n(v_span_244, 0, 2);
  V v_t_2412;
  if (heff_intLe_c_lent(v_x_249, v_y_2410, 0)) {
    heff_drop(v_x_249);
    v_t_2412 = v_y_2410;
  } else {
    heff_drop(v_y_2410);
    v_t_2412 = v_x_249;
  }
  V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_t_2411)));
  V v_t_2414;
  if (heff_intLe_c_lent(v_t_2411, v_t_2412, 0)) {
    heff_drop(v_t_2411);
    v_t_2414 = v_t_2412;
  } else {
    heff_drop(v_t_2412);
    v_t_2414 = v_t_2411;
  }
  V v_t_2415 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_2414));
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), v_t_2415}), NTAG(TAG_Nil)});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), v_t_2413}), v_t_2416});
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2417})});
  V v_t_2419 = (g_heff_2elsp_2elsp_2erange(v_src_240, v_selection_245));
  V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), v_children_246));
  V v_t_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str6), v_t_2419}), v_t_2423});
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, v_t_2424})});
  return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2425})});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2edocSymbol(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2420 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_src_240; V a_1 = v_m_2420; V r_ = (g_heff_2elsp_2elsp_2echildJson(a_0, a_1)); heff_drop(v_src_240); r_; });
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_244;
    if (((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL)))) {
      int64_t v_t_243 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) + ((int64_t)32ULL));
      v_t_244 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_243))));
    } else {
      v_t_244 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))));
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_244);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elowerGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V v_changed_240, V v_mods_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_246 = heff_take_field(v_c_244, 1);
    V v_module_247 = heff_take_field(v_c_244, 0);
    V v_deps_248 = heff_get_n(v_c_244, 8, 14);
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_246)}));
    V v_t_2410 = (g_list_2eany(v_t_249, v_changed_240));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_deps_248);
      heff_drop(v_t_2410);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_246, heff_hole()});
      V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_changed_240;
      V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_247, v_mods_241});
      V t_2 = v_rest_245;
      V t_3 = v_cell_2411;
      v_changed_240 = t_0;
      v_mods_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}); V a_1 = v_deps_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_deps_248); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_cell_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_246, heff_hole()});
        V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
        heff_drop(v_u_2417);
        V t_0 = v_changed_240;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_247, v_mods_241});
        V t_2 = v_rest_245;
        V t_3 = v_cell_2416;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_path_246);
        heff_drop(v_module_247);
        heff_drop(v_t_2415);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args) {
  V v_d_2413 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2413}));
  return ({ V a_0 = v_t_2414; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str0, 31, "Write the module claim `module ");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str1, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str2, 5, "title");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str3, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str4, 8, "quickfix");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str5, 11, "diagnostics");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str6, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str7, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str8, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str9, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str10, 7, "changes");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str11, 4, "edit");
HEFF_LIT(g_heff_2elsp_2elsp_2eclaimAction_str12, 11, "isPreferred");
Clo g_heff_2elsp_2elsp_2eclaimAction_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eclaimAction_entry, 5, 0};

V g_heff_2elsp_2elsp_2eclaimAction(V v_uri_240, V v_src_241, V v_n_242, V v_ds_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_MkPair: {
    V v_sp_245 = heff_field(v_x5_244, 0);
    V v_text_246 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24MkPair = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_start_247 = heff_take_field(v_sp_245, 0);
    V v_end_248 = heff_get_n(v_sp_245, 1, 2);
    V v_t_249 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2eclaimAction_str0), heff_strAppend(v_n_242, ((V)&g_heff_2elsp_2elsp_2eclaimAction_str1)));
    V v_t_2410 = heff_tag_at_n(v_ru_24x5_244_24MkPair, TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str2), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str3), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str4)})});
    V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_ds_243})});
    V v_t_2413 = (g_heff_2elsp_2elsp_2eposition(v_src_241, heff_dup(v_start_247)));
    V v_x_2414 = v_start_247;
    V v_y_2415 = v_end_248;
    V v_t_2416;
    if (heff_intLe_c_lent(v_x_2414, v_y_2415, 0)) {
      heff_drop(v_x_2414);
      v_t_2416 = v_y_2415;
    } else {
      heff_drop(v_y_2415);
      v_t_2416 = v_x_2414;
    }
    V v_t_2417 = (g_heff_2elsp_2elsp_2eposition(v_src_241, v_t_2416));
    V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str6), v_t_2417}), NTAG(TAG_Nil)});
    V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str7), v_t_2413}), v_t_2418});
    V v_t_2420 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str8), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str9), heff_tag_n(TAG_JString, 1, (V[]){v_text_246})});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_t_2423 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag_n(TAG_MkPair, 2, (V[]){v_uri_240, heff_tag_n(TAG_JArray, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2425, NTAG(TAG_Nil)});
    V v_t_2427 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
    V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str11), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eclaimAction_str12), heff_dup(g_heff_2elsp_2elsp_2ejtrue_get())}), v_t_2430});
    V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2431})});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2432})});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2elsp_2elsp_2eclaimAction_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2eclaimAction(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3, 3, 0};
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam6(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry, 6, 0};

V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V v_st_240, V v_f_241, V v_d_242, V v_cut_243, V v_z_244, V v_z_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_240, 0);
  V v_lib_247 = heff_get_n(v_st_240, 6, 7);
  V v_c_2431 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam0, 1, 4, (V[]){heff_dup(v_f_241), heff_dup(v_d_242), heff_dup(v_cut_243), v_docs_246}), v_lib_247, v_f_241));
  return heff_tail(v_c_2431, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam6, 1, 3, (V[]){v_z_244, v_d_242, v_z_245})});
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(a[0], a[1], a[2], a3, a[4], a[5]); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_d_242 = heff_env(self)[0];
  V v_cut_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_249);
  V v_t_2411 = heff_strSlice(heff_get_n(v_d_242, 1, 2), MK_INT(0LL), v_cut_243);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_d_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2416);
  V v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2415, 1, 2)});
  V f_ = v_k_2417;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam5(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    v_t_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    v_t_2430 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){v_y_2429});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_2426;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2424;
  args[0] = v_hd_2425;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam5, 1, 1, (V[]){v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_cut_243 = heff_env(self)[2];
  V v_docs_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if (heff_strEq_c_lent(v_p_248, v_f_241, 2)) {
    heff_drop(v_p_248);
    heff_drop(v_docs_246);
    return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam1, 2, 2, (V[]){v_d_242, v_cut_243});
  } else {
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_cut_243);
    HeffT2 v_t_2412 = ({ V a_0 = v_docs_246; V a_1 = v_p_248; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
    {
      V v_field_2414 = v_t_2412.f[1];
      int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
      if ((v_tag_2413 == ((int64_t)0ULL))) {
        heff_drop(v_p_248);
        V v_d_2415 = v_field_2414;
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam2, 2, 1, (V[]){v_d_2415});
      } else {
        heff_drop(v_field_2414);
        V v_path_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_248; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
        V v_c_2420 = ({ V a_0 = v_path_2419; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2419); r_; });
        V v_c_2424 = heff_tr(heff_call(v_c_2420, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam3_clo)}));
        return heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam4, 2, 1, (V[]){v_c_2424});
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_242, 1, 2); V a_1 = v_x_2443; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_errors_2435 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2439 = heff_get_n(v_x_2438, 0, 2);
  V v_program_2440 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2439)));
  V v_t_2441 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2439));
  V v_t_2442 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_242, 1)), v_t_2441, v_errors_2435));
  V v_diags_2444 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam8, 1, 1, (V[]){v_d_242}), v_t_2442));
  V f_ = v_z_245;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2440, v_diags_2444});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_paths_2433 = heff_take_field(v_x_2432, 2);
  V v_sources_2434 = heff_take_field(v_x_2432, 0);
  V v_errors_2435 = heff_get_n(v_x_2432, 1, 5);
  V v_t_2436 = heff_rec_n(2, shape_done__hashes, (V[]){NTAG(TAG_Nil), heff_dup(g_std_2emap_2eempty_get())});
  V v_c_2437 = (g_heff_2ebuild_2esession_2ecachedGo_24s2043018961x1744095293(v_paths_2433, v_sources_2434, v_t_2436));
  V f_ = v_c_2437;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_lam7, 1, 3, (V[]){v_d_242, v_errors_2435, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_entry, 3, 0};

V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(V v_wire_240, V v_st_241, V v_f_242) {
top: ;
  V v_due_243 = heff_take_field(v_st_241, 2);
  V v_docs_244 = heff_take_field(v_st_241, 0);
  V v_checked_245 = heff_take_field(v_st_241, 1);
  V v_project_246 = heff_take_field(v_st_241, 3);
  V v_watch_247 = heff_take_field(v_st_241, 4);
  V v_shutdown_248 = heff_take_field(v_st_241, 5);
  V v_lib_249 = heff_get_n(v_st_241, 6, 7);
  V v_t_2410 = (g_std_2emap_2edelete_24s1614046289x1611773644(v_due_243, v_f_242));
  V v_c_2411 = (g_heff_2elsp_2elsp_2echeck_24s1233558532x916325476(heff_dup(v_wire_240), heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){v_docs_244, heff_dup(v_checked_245), v_t_2410, v_project_246, v_watch_247, v_shutdown_248, v_lib_249}), heff_dup(v_f_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam0, 2, 4, (V[]){v_c_2411, v_checked_245, v_f_242, v_wire_240});
}
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam2(V self, V *args) {
  V v_p_2416 = args[0];
  V v_f_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419;
  switch (heff_tag_of(v_p_2416)) {
  case TAG_MkPair: {
    V v_x_2417 = heff_dup(heff_field(v_p_2416, 0));
    v_t_2419 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_p_2416);
  }
  if (!heff_strEq_c_lent(v_t_2419, v_f_242, 0)) {
    heff_drop(v_t_2419);
    V v_t_2422;
    switch (heff_tag_of(v_p_2416)) {
    case TAG_MkPair: {
      V v_y_2421 = heff_field(v_p_2416, 1);
      heff_take_n(v_p_2416, 2ULL, 2);
      v_t_2422 = v_y_2421;
      break;
    }
    default: heff_nomatch(v_p_2416);
    }
    return ({ V a_0 = v_f_242; V b_1 = heff_get_n(v_t_2422, 1, 2); V r_ = (g_list_2eany_24s1795474228x706402294(a_0, b_1)); heff_drop(v_f_242); heff_drop(b_1); r_; });
  } else {
    heff_drop(v_p_2416);
    heff_drop(v_f_242);
    heff_drop(v_t_2419);
    return NTAG(TAG_False);
  }
}
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_checked_245 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_hd_2412 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = ({ V a_0 = v_checked_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_checked_245); r_; });
  V v_t_2423 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam2, 1, 1, (V[]){v_f_242}), v_t_2415));
  V v_t_2424 = (g_list_2emap_24s1415906091x1371825187(v_t_2423));
  return ({ V a_0 = v_wire_240; V a_1 = v_x_2414; V a_2 = v_t_2424; V a_3 = v_hd_2412; V a_4 = v_k_2413; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1887429370x1936002723(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2424); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_checked_245 = heff_env(self)[1];
  V v_f_242 = heff_env(self)[2];
  V v_wire_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1380377206x1015037453_lam1, 1, 5, (V[]){v_checked_245, v_f_242, v_wire_240, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry, 3, 0};

V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(V v_read_240, V v_lib_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_read_240);
    heff_drop(v_lib_241);
    return ((V)&g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_c_247 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1365796638x637065820(heff_dup(v_read_240), heff_dup(v_lib_241), heff_dup(v_f_245)));
    return heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam1, 2, 4, (V[]){v_c_247, v_read_240, v_lib_241, heff_dup(v_rest_246)});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2413 = (g_prelude_2e_2b_2b(heff_get_n(v_x_2410, 0, 5), v_x_2412));
  V f_ = v_k_249;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_read_240 = heff_env(self)[0];
  V v_lib_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2411 = ({ V a_0 = v_read_240; V a_1 = v_lib_241; V a_2 = v_rest_246; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a_0, a_1, a_2)); heff_drop(v_rest_246); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam3, 1, 2, (V[]){v_x_2410, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_read_240 = heff_env(self)[1];
  V v_lib_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992_lam2, 1, 5, (V[]){v_read_240, v_lib_241, v_rest_246, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_entry, 3, 0};

V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380(V v_wire_240, V v_st_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam0, 2, 1, (V[]){v_st_241});
  }
  case TAG_Cons: {
    V v_x21_246 = heff_field(v_x2_242, 0);
    V v_rest_247 = heff_field(v_x2_242, 1);
    switch (heff_tag_of(v_x21_246)) {
    case TAG_MkPair: {
      V v_f_249 = heff_field(v_x21_246, 1);
      V v_c_2410 = (g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(heff_dup(v_wire_240), v_st_241, heff_dup(v_f_249)));
      return heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam1, 2, 3, (V[]){v_c_2410, v_wire_240, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x21_246);
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_st_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(2, shape_st__program, (V[]){v_st_241, NTAG(TAG_Nil)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_program_2415 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_program_2418 = heff_take_field(v_x_2417, 1);
  V v_st_2419 = heff_get_n(v_x_2417, 0, 2);
  V v_program_2420 = (g_prelude_2e_2b_2b(v_program_2415, v_program_2418));
  V f_ = v_k_2412;
  args[0] = heff_rec_n(2, shape_st__program, (V[]){v_st_2419, v_program_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_rest_247 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_k_2412 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2414 = heff_take_field(v_x_2413, 0);
  V v_program_2415 = heff_get_n(v_x_2413, 1, 2);
  V v_c_2416 = ({ V a_0 = v_wire_240; V a_1 = v_st_2414; V a_2 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380(a_0, a_1, a_2)); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam3, 1, 2, (V[]){v_program_2415, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_rest_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eprojects_24s1795396058x542033380_lam2, 1, 4, (V[]){v_wire_240, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_str0, 0, "");
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam0, 2, 0};
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_entry, 4, 0};

V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819(V v_wire_240, V v_st_241, V v_query_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_wire_240);
    heff_drop(v_st_241);
    return ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    V v_t_248 = (g_heff_2ebuild_2equery_2esymbols(heff_dup(v_c_246)));
    V v_t_2411 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam1, 1, 1, (V[]){heff_dup(v_query_242)}), v_t_248));
    V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s1856590784x396031608(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(v_c_246), v_t_2411));
    return heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam2, 2, 5, (V[]){v_c_2412, v_wire_240, v_st_241, heff_dup(v_query_242), heff_dup(v_rest_247)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam1(V self, V *args) {
  V v_y_249 = args[0];
  V v_query_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_s_2410 = ({ V b_0 = heff_get_n(v_y_249, 0, 5); V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_str0); V r_ = (g_heff_2elsp_2elsp_2elowerGo(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_ret_24bool = heff_bool(heff_intLe_c(MK_INT(0LL), heff_strFind_lent(v_query_242, v_s_2410, MK_INT(0LL), 4)));
  heff_drop(v_query_242);
  heff_drop(v_s_2410);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2418 = (g_prelude_2e_2b_2b(v_x_2415, v_x_2417));
  V f_ = v_k_2414;
  args[0] = v_x_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_wire_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_query_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2413 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2416 = ({ V a_0 = v_wire_240; V a_1 = v_st_241; V a_2 = v_query_242; V a_3 = v_rest_247; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819(a_0, a_1, a_2, a_3)); heff_drop(v_query_242); heff_drop(v_rest_247); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam4, 1, 2, (V[]){v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_query_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2esymbolsJson_24s379468907x1668308819_lam3, 1, 6, (V[]){v_wire_240, v_st_241, v_query_242, v_rest_247, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_str0, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_str1, 5, "range");
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam1, 1, 0};
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_entry, 3, 0};

V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680(V v_wire_240, V v_st_241, V v_o_242) {
top: ;
  V v_path_243 = heff_take_field(v_o_242, 0);
  V v_source_244 = heff_take_field(v_o_242, 1);
  V v_span_245 = heff_get_n(v_o_242, 2, 4);
  V v_p_246 = v_path_243;
  HeffT2 v_t_247 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2415;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_wire_240);
      heff_drop(v_p_246);
      V v_d_2410 = v_field_249;
      v_c_2415 = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam0, 2, 1, (V[]){v_d_2410});
    } else {
      heff_drop(v_field_249);
      V v_t_2414 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_246, ((V)&g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam1_clo)})}));
      v_c_2415 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2414}));
    }
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam2, 2, 3, (V[]){v_c_2415, v_source_244, v_span_245});
}
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_d_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_get_n(v_d_2410, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam1(V self, V *args) {
  V v_u_2413 = args[0];
  return v_u_2413;
}
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_source_244 = heff_env(self)[0];
  V v_span_245 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_str0), heff_tag_n(TAG_JString, 1, (V[]){v_x_2418})});
  V v_t_2420 = ({ V a_0 = v_source_244; V a_1 = v_span_245; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_244); r_; });
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_str1), v_t_2420}), NTAG(TAG_Nil)});
  V v_x_2422 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
  V f_ = v_k_2417;
  args[0] = v_x_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_source_244 = heff_env(self)[1];
  V v_span_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2415;
  args[0] = v_hd_2416;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2elocationOf_24s2060828175x1229333680_lam3, 1, 3, (V[]){v_source_244, v_span_245, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str1, 36, "` would make heff fail elaborating (");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str2, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str3, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str4, 10, "renaming `");
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam10, 3, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam14(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam14, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_entry, 4, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770(V v_wire_240, V v_st_241, V v_t_242, V v_new_243) {
top: ;
  V v_c_244 = (g_heff_2elsp_2elsp_2eproject_24s1255814374x713621353(heff_dup(v_wire_240), heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 0))));
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam0, 2, 5, (V[]){v_c_244, v_t_242, v_wire_240, v_new_243, v_st_241});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam2(V self, V *args) {
  V v_p_2411 = args[0];
  V v_os_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2412 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2411, v_os_248));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2411, v_os_2412});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam6(V self, V *args) {
  V v_p_2424 = args[0];
  V v_os_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2425 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2424, v_os_2421));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2424, v_os_2425});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam7(V self, V *args) {
  V v_b_2427 = args[0];
  V v_new_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_path_2428 = heff_take_field(v_b_2427, 0);
  V v_occurrences_2429 = heff_get_n(v_b_2427, 1, 2);
  V v_os_2430 = v_occurrences_2429;
  V v_t_2433;
  switch (heff_tag_of(v_os_2430)) {
  case TAG_Nil: {
    v_t_2433 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2431 = heff_dup(heff_field(v_os_2430, 0));
    v_t_2433 = heff_get_n(v_x_2431, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2430);
  }
  V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2430));
  V v_t_2435 = ({ V b_0 = MK_INT(0LL); V a_1 = v_new_243; V a_2 = v_t_2433; V a_3 = v_t_2434; V r_ = (g_list_2efoldl_24s2051016282x1892781518(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2434); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2428, v_t_2435});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam8(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_q_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V v_t_2445;
  switch (heff_tag_of(v_q_2440)) {
  case TAG_MkPair: {
    V v_y_2444 = heff_field(v_q_2440, 1);
    heff_take_n(v_q_2440, 2ULL, 2);
    v_t_2445 = v_y_2444;
    break;
  }
  default: heff_nomatch(v_q_2440);
  }
  V f_ = v_k_2442;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2445});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam9(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_d_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2450);
  V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2449, 1, 2)});
  V f_ = v_k_2451;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  V v_hd_2456 = args[1];
  V v_k_2457 = args[2];
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2455});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam12(V self, V *args) {
  V v_x_2461 = args[0];
  V v_k_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2464;
  switch (heff_tag_of(v_x_2461)) {
  case TAG_Left: {
    heff_take_n(v_x_2461, 0ULL, 1);
    v_t_2464 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2463 = heff_field(v_x_2461, 0);
    V v_ru_24x_2461_24Right = heff_take_reuse_n(v_x_2461, 1ULL, 1);
    v_t_2464 = heff_tag_at_n(v_ru_24x_2461_24Right, TAG_Just, 1, (V[]){v_y_2463});
    break;
  }
  default: heff_nomatch(v_x_2461);
  }
  V f_ = v_k_2460;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam11(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_c_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2458;
  args[0] = v_hd_2459;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam12, 1, 1, (V[]){v_k_2460});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam5(V self, V *args) {
  V v_p_2420 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_new_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2421 = heff_get_n(v_t_242, 3, 4);
  V v_t_2422 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2421)));
  V v_t_2423 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2422));
  V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam6, 1, 1, (V[]){v_os_2421}), v_t_2423));
  V v_texts_2436 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam7, 1, 1, (V[]){v_new_243}), v_t_2426));
  HeffT2 v_t_2437 = (g_list_2efind_24s1807954837x1305454787_24cpr(v_p_2420, v_texts_2436));
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      heff_drop(v_p_2420);
      heff_drop_rec(v_st_241, 7);
      V v_q_2440 = v_field_2439;
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam8, 2, 1, (V[]){v_q_2440});
    } else {
      heff_drop(v_field_2439);
      HeffT2 v_t_2446 = ({ V b_0 = heff_get_n(v_st_241, 0, 7); V a_1 = v_p_2420; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2448 = v_t_2446.f[1];
        int64_t v_tag_2447 = ((int64_t)v_t_2446.f[0]);
        if ((v_tag_2447 == ((int64_t)0ULL))) {
          heff_drop(v_p_2420);
          V v_d_2449 = v_field_2448;
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam9, 2, 1, (V[]){v_d_2449});
        } else {
          heff_drop(v_field_2448);
          V v_path_2453 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
          V v_c_2454 = ({ V a_0 = v_path_2453; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2453); r_; });
          V v_c_2458 = heff_tr(heff_call(v_c_2454, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam10_clo)}));
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam11, 2, 1, (V[]){v_c_2458});
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam13(V self, V *args) {
  V v_x_2466 = args[0];
  V v_k_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sources_2467 = (g_heff_2elsp_2elsp_2enubSources(v_x_2466));
  V v_x_2468 = (g_list_2efoldl_24s655928500x1399206842(NTAG(TAG_Nil), v_sources_2467));
  V f_ = v_k_2418;
  args[0] = v_x_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2415 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_new_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2419 = (g_heff_2elsp_2elsp_2enubPaths(v_x_2415));
  V v_c_2465 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam5, 1, 3, (V[]){v_t_242, v_new_243, heff_dup(v_st_241)}); V a_1 = heff_get_n(v_st_241, 6, 7); V a_2 = v_t_2419; V r_ = (g_heff_2elsp_2elsp_2eloadAll_24s601012170x124188992(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  V f_ = v_c_2465;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam13, 1, 1, (V[]){v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam14(V self, V *args) {
  V v_r_2469 = args[0];
  return v_r_2469;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam3(V self, V *args) {
  V v_use_2416 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_new_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_use_2416;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam4, 2, 4, (V[]){v_x_2415, v_t_242, v_new_243, v_st_241});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam14_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam16(V self, V *args) {
  V v_c_2478 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2478, 1, 14)}));
  return ({ V a_0 = v_t_2479; V a_1 = v_x_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2415); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam17(V self, V *args) {
  V v_c_2483 = args[0];
  V v_x_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2484 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_2483, 1, 14)}));
  return ({ V a_0 = v_t_2484; V a_1 = v_x_2415; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2415); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam15(V self, V *args) {
  V v_x_2471 = args[0];
  V v_new_243 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_x_2415 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_2488;
  switch (heff_tag_of(v_x_2471)) {
  case TAG_Left: {
    V v_x_2472 = heff_field(v_x_2471, 0);
    V v_ru_24x_2471_24Left = heff_take_reuse_n(v_x_2471, 1ULL, 1);
    heff_drop(v_x_2415);
    V v_t_2473 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str1), heff_strAppend(v_x_2472, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str2)));
    V v_t_2474 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str3), heff_strAppend(v_new_243, v_t_2473));
    V v_t_2475 = heff_strAppend(heff_get_n(v_t_242, 2, 4), v_t_2474);
    V v_t_2476 = heff_tag_at_n(v_ru_24x_2471_24Left, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_str4), v_t_2475)});
    v_x_2488 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_247, 0, 2), v_t_2476});
    break;
  }
  case TAG_Right: {
    V v_y_2477 = heff_field(v_x_2471, 0);
    V v_ru_24x_2471_24Right = heff_take_reuse_n(v_x_2471, 1ULL, 1);
    V v_program_2480 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam16, 1, 1, (V[]){heff_dup(v_x_2415)}), heff_dup(heff_rfield(v_x_247, 1))));
    V v_t_2481 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2480));
    V v_t_2482 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2481; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_2481); r_; });
    V v_program_2485 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam17, 1, 1, (V[]){v_x_2415}), heff_dup(v_y_2477)));
    V v_t_2486 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_2485));
    V v_t_2487 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_2486; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_2486); r_; });
    v_x_2488 = (g_heff_2elsp_2elsp_2erenameVerdict_24tok1(v_ru_24x_2471_24Right, v_x_247, v_t_242, v_new_243, v_t_2482, v_t_2487, v_y_2477));
    break;
  }
  default: heff_nomatch(v_x_2471);
  }
  V f_ = v_k_246;
  args[0] = v_x_2488;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_wire_240 = heff_env(self)[1];
  V v_new_243 = heff_env(self)[2];
  V v_st_241 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_os_248 = heff_dup(heff_rfield(v_t_242, 3));
  V v_t_249 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_248)));
  V v_t_2410 = (g_heff_2elsp_2elsp_2enubPaths(v_t_249));
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam2, 1, 1, (V[]){v_os_248}), v_t_2410));
  V v_t_2414 = (g_list_2emap_24s582709368x2113456071(v_t_2413));
  V v_x_2415 = ({ V a_0 = v_t_2414; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_247, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2414); r_; });
  V v_t_2470 = heff_tr(heff_call(v_wire_240, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam3, 1, 4, (V[]){heff_dup(v_x_2415), heff_dup(v_t_242), heff_dup(v_new_243), v_st_241})})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2470, v_hd_245, heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam15, 1, 5, (V[]){v_new_243, v_t_242, v_x_247, v_x_2415, v_k_246})));
}
V g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_wire_240 = heff_env(self)[2];
  V v_new_243 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s455267229x1657251770_lam1, 1, 6, (V[]){v_t_242, v_wire_240, v_new_243, v_st_241, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str0, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str1, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str2, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str3, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str4, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str6, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str7, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str8, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str9, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str10, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str11, 7, "newText");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str12, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str13, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str14, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str15, 2, "id");
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_entry, 7, 0};

V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340(V v_wire_240, V v_st_241, V v_id_242, V v_d_243, V v_fix_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_244, heff_dup(heff_rfield(v_d_243, 1))));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop_rec(v_d_243, 2);
      V v_x_2410 = v_field_249;
      heff_drop(v_x_2410);
      V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str0), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str1)})});
      V v_t_2412 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str2), v_t_2412}), NTAG(TAG_Nil)});
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str3), v_id_242}), v_t_2413});
      V v_t_2415 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2414})});
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2415, 1); r_; });
      V v_t_2417 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2416, NTAG(TAG_MkUnit)});
      V v_t_2418 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2417}));
      return (g_co_2eop_24s615738393x1686646143(v_t_2418, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam0, 1, 2, (V[]){v_z_246, v_st_241})));
    } else {
      V v_t_2420 = v_field_249;
      if (heff_strEq_c(heff_dup(v_t_2420), heff_dup(heff_rfield(v_d_243, 1)))) {
        heff_drop_rec(v_d_243, 2);
        heff_drop(v_t_2420);
        V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str4), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str5)})});
        V v_t_2422 = heff_tag_n(TAG_JArray, 1, (V[]){NTAG(TAG_Nil)});
        V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str6), v_t_2422}), NTAG(TAG_Nil)});
        V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str7), v_id_242}), v_t_2423});
        V v_t_2425 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2424})});
        V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2425, 1); r_; });
        V v_t_2427 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
        V v_t_2428 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2427}));
        return (g_co_2eop_24s615738393x1686646143(v_t_2428, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam1, 1, 2, (V[]){v_z_246, v_st_241})));
      } else {
        V v_src_2430 = heff_dup(heff_rfield(v_d_243, 1));
        V v_t_2431 = heff_strLength(heff_get_n(v_d_243, 1, 2));
        V v_t_2432 = (g_heff_2elsp_2elsp_2eposition(v_src_2430, MK_INT(0LL)));
        V v_t_2433;
        if ((((int64_t)0ULL) <= heff_peek_word(v_t_2431))) {
          v_t_2433 = v_t_2431;
        } else {
          heff_drop(v_t_2431);
          v_t_2433 = MK_INT(0LL);
        }
        V v_t_2434 = ({ V a_0 = v_src_2430; V a_1 = v_t_2433; V r_ = (g_heff_2elsp_2elsp_2eposition(a_0, a_1)); heff_drop(v_src_2430); r_; });
        V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str8), v_t_2434}), NTAG(TAG_Nil)});
        V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str9), v_t_2432}), v_t_2435});
        V v_t_2437 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str10), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str11), heff_tag_n(TAG_JString, 1, (V[]){v_t_2420})});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2439})});
        V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
        V v_result_2442 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_2441});
        V v_t_2443 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str12), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str13)})});
        V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str14), v_result_2442}), NTAG(TAG_Nil)});
        V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_str15), v_id_242}), v_t_2444});
        V v_t_2446 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, v_t_2445})});
        V v_t_2447 = ({ V a_0 = v_t_2446; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2446, 1); r_; });
        V v_t_2448 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2447, NTAG(TAG_MkUnit)});
        V v_t_2449 = heff_tr(heff_call(v_wire_240, 1, (V[]){v_t_2448}));
        return (g_co_2eop_24s615738393x1686646143(v_t_2449, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam2, 1, 2, (V[]){v_z_246, v_st_241})));
      }
    }
  }
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam0(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eformattedIn_24s1854550836x1774104340_lam2(V self, V *args) {
  V v_x_2450 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str0, 4, "only");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str1, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str2, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str3, 12, "textDocument");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str4, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str5, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str6, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str7, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str8, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str9, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str10, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str11, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str12, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str13, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str14, 9, "character");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str15, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str16, 5, "start");
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_entry, 3, 0};

V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823(V v_wire_240, V v_a_241, V v_p_242) {
top: ;
  V v_program_243 = heff_take_field(v_a_241, 2);
  V v_text_244 = heff_take_field(v_a_241, 1);
  V v_st_245 = heff_get_n(v_a_241, 0, 3);
  V v_c_246 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1689976112x1685494482(heff_dup(v_wire_240), heff_dup(v_p_242)));
  return heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_lam0, 2, 6, (V[]){v_c_246, v_program_243, v_p_242, v_text_244, v_wire_240, v_st_245});
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_248 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  V v_wire_240 = heff_env(self)[4];
  V v_st_245 = heff_env(self)[5];
  V v_hd_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    heff_drop(v_program_243);
    heff_drop(v_p_242);
    heff_drop(v_text_244);
    heff_drop(v_wire_240);
    heff_drop(v_st_245);
    heff_drop(v_hd_247);
    V f_ = v_k_248;
    args[0] = NTAG(TAG_Nil);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_x1_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_243)));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nil: {
      heff_drop(v_program_243);
      heff_drop(v_p_242);
      heff_drop(v_text_244);
      heff_drop(v_wire_240);
      heff_drop(v_st_245);
      heff_drop(v_hd_247);
      heff_drop(v_f_2410);
      V f_ = v_k_248;
      args[0] = NTAG(TAG_Nil);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_x_2412 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Cons = heff_take_reuse_n(v_x1_2411, 1ULL, 2);
      V v_t_2414 = heff_tag_at_n(v_ru_24x1_2411_24Cons, TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str0), NTAG(TAG_Nil)});
      HeffT2 v_t_2415 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str1), v_t_2414}), heff_dup(v_p_242)));
      V v_t_2425;
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_it1_2418 = v_field_2417;
          switch (heff_tag_of(v_it1_2418)) {
          case TAG_JNull: {
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          case TAG_JArray: {
            V v_xs_2423 = heff_field(v_it1_2418, 0);
            heff_take_n(v_it1_2418, 1ULL, 1);
            v_t_2425 = ({ V a_0 = v_xs_2423; V r_ = (g_list_2eany_24s1497517957x114012878(a_0)); heff_drop(v_xs_2423); r_; });
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2418, 0ULL, 1);
            v_t_2425 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_it1_2418);
          }
        } else {
          heff_drop(v_field_2417);
          v_t_2425 = NTAG(TAG_True);
        }
      }
      if (((heff_dup(v_t_2425) == NTAG(TAG_True)) && heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 3)), heff_dup(v_text_244)))) {
        heff_drop(v_t_2425);
        V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str2), NTAG(TAG_Nil)});
        HeffT2 v_t_2427 = (g_json_2eat_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str3), v_t_2426}), heff_dup(v_p_242)));
        V v_t_2437;
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            V v_it1_2430 = v_field_2429;
            switch (heff_tag_of(v_it1_2430)) {
            case TAG_JNull: {
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str4);
              break;
            }
            case TAG_JBool: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str5);
              break;
            }
            case TAG_JInt: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str6);
              break;
            }
            case TAG_JFloat: {
              heff_take_na(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str7);
              break;
            }
            case TAG_JString: {
              V v_s_2434 = heff_field(v_it1_2430, 0);
              heff_take_n(v_it1_2430, 1ULL, 1);
              v_t_2437 = v_s_2434;
              break;
            }
            case TAG_JArray: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str8);
              break;
            }
            case TAG_JObject: {
              heff_take_n(v_it1_2430, 0ULL, 1);
              v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str9);
              break;
            }
            default: heff_nomatch(v_it1_2430);
            }
          } else {
            heff_drop(v_field_2429);
            v_t_2437 = ((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str10);
          }
        }
        V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str11), NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str12), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str13), v_t_2438})});
        HeffT2 v_t_2440 = (g_json_2eat_24cpr(v_t_2439, heff_dup(v_p_242)));
        V v_t_2464;
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str14), NTAG(TAG_Nil)});
          V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str15), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_str16), v_t_2443})});
          HeffT2 v_t_2445 = (g_json_2eat_24cpr(v_t_2444, v_p_242));
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            V v_t_2455;
            if ((v_tag_2441 == ((int64_t)0ULL))) {
              V v_it1_2448 = v_field_2442;
              switch (heff_tag_of(v_it1_2448)) {
              case TAG_JNull: {
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JInt: {
                V v_i_2450 = heff_field(v_it1_2448, 0);
                heff_take_n(v_it1_2448, 1ULL, 1);
                v_t_2455 = v_i_2450;
                break;
              }
              case TAG_JFloat: {
                double v_x_2451 = heff_tflat_f64(v_it1_2448, 0);
                heff_take_na(v_it1_2448, 0ULL, 1);
                v_t_2455 = heff_floor_f64(v_x_2451);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2448, 0ULL, 1);
                v_t_2455 = MK_INT(0LL);
                break;
              }
              default: heff_nomatch(v_it1_2448);
              }
            } else {
              heff_drop(v_field_2442);
              v_t_2455 = MK_INT(0LL);
            }
            V v_t_2463;
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              V v_it1_2456 = v_field_2447;
              switch (heff_tag_of(v_it1_2456)) {
              case TAG_JNull: {
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JInt: {
                V v_i_2458 = heff_field(v_it1_2456, 0);
                heff_take_n(v_it1_2456, 1ULL, 1);
                v_t_2463 = v_i_2458;
                break;
              }
              case TAG_JFloat: {
                double v_x_2459 = heff_tflat_f64(v_it1_2456, 0);
                heff_take_na(v_it1_2456, 0ULL, 1);
                v_t_2463 = heff_floor_f64(v_x_2459);
                break;
              }
              case TAG_JString: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2456, 0ULL, 1);
                v_t_2463 = MK_INT(0LL);
                break;
              }
              default: heff_nomatch(v_it1_2456);
              }
            } else {
              heff_drop(v_field_2447);
              v_t_2463 = MK_INT(0LL);
            }
            v_t_2464 = ({ V a_0 = v_text_244; V a_1 = v_t_2455; V a_2 = v_t_2463; V a_3 = MK_INT(0LL); V a_4 = MK_INT(0LL); V r_ = (g_heff_2elsp_2elsp_2eoffsetGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_text_244); r_; });
          }
        }
        return (g_heff_2elsp_2elsp_2esplitIn_24s2064005962x800307849(v_wire_240, v_st_245, v_f_2410, v_t_2437, v_program_243, v_x_2412, v_t_2464, v_hd_247, v_k_248));
      } else {
        heff_drop(v_program_243);
        heff_drop(v_p_242);
        heff_drop(v_text_244);
        heff_drop(v_wire_240);
        heff_drop(v_st_245);
        heff_drop(v_hd_247);
        heff_drop(v_f_2410);
        heff_drop_rec(v_x_2412, 14);
        heff_drop(v_t_2425);
        V f_ = v_k_248;
        args[0] = NTAG(TAG_Nil);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_program_243 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  V v_wire_240 = heff_env(self)[4];
  V v_st_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ecodeActions_24s1427741851x15587823_lam1, 1, 7, (V[]){v_k_248, v_program_243, v_p_242, v_text_244, v_wire_240, v_st_245, v_hd_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0, 8, "severity");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1, 6, "source");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2, 4, "heff");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4, 7, "message");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6, 1, "E");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7, 1, "W");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8, 1, "D");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9, 1, "0");
HEFF_LIT(g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10, 4, "code");
Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry, 3, 0};

V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V v_tok_240, V v_src_241, V v_d_242) {
top: ;
  V v_span_243 = heff_take_field(v_d_242, 3);
  V v_severity_244 = heff_take_field(v_d_242, 1);
  V v_note_245 = heff_take_field(v_d_242, 4);
  V v_msg_246 = heff_take_field(v_d_242, 2);
  V v_code_247 = heff_get_n(v_d_242, 0, 5);
  V v_t_248 = (g_heff_2elsp_2elsp_2erange(v_src_241, v_span_243));
  V v_t_249;
  switch (heff_tag_of(v_severity_244)) {
  case TAG_SError: {
    v_t_249 = MK_INT(1LL);
    break;
  }
  case TAG_SWarning: {
    v_t_249 = MK_INT(2LL);
    break;
  }
  case TAG_SDebug: {
    v_t_249 = MK_INT(4LL);
    break;
  }
  default: heff_nomatch(v_severity_244);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str0), heff_tag_at_n(v_tok_240, TAG_JInt, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str1), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str2)})});
  V v_t_2413;
  switch (heff_tag_of(v_note_245)) {
  case TAG_Nothing: {
    v_t_2413 = v_msg_246;
    break;
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_note_245, 0);
    heff_take_n(v_note_245, 1ULL, 1);
    v_t_2413 = heff_strAppend(v_msg_246, heff_strAppend(((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str3), v_n_2412));
    break;
  }
  default: heff_nomatch(v_note_245);
  }
  V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str5), v_t_248}), v_t_2416});
  V v_t_2423;
  if (heff_intEq_c_lent(v_code_247, MK_INT(0LL), 2)) {
    heff_drop(v_severity_244);
    heff_drop(v_code_247);
    v_t_2423 = NTAG(TAG_Nil);
  } else {
    V v_t_2418;
    switch (heff_tag_of(v_severity_244)) {
    case TAG_SError: {
      v_t_2418 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str6);
      break;
    }
    case TAG_SWarning: {
      v_t_2418 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str7);
      break;
    }
    case TAG_SDebug: {
      v_t_2418 = ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str8);
      break;
    }
    default: heff_nomatch(v_severity_244);
    }
    V v_t_2419 = (g_heff_2elsp_2erender_2enumDigits(heff_dup(v_code_247)));
    V v_t_2420 = (g_heff_2elsp_2erender_2erepeated(heff_intSub(MK_INT(4LL), v_t_2419), ((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str9)));
    V v_t_2421 = heff_strAppend(v_t_2420, heff_intShow(v_code_247));
    V v_t_2422 = heff_tag_n(TAG_JString, 1, (V[]){heff_strAppend(v_t_2418, v_t_2421)});
    v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2ediagnostic_24tok1_str10), v_t_2422}), NTAG(TAG_Nil)});
  }
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2423));
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2424});
}
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2ediagnostic_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}