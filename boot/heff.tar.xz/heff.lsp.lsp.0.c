// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_JArray 50516
#define TAG_JInt 58696
#define TAG_JObject 38239
#define TAG_JString 41091
#define LBL_checked 974171621
#define LBL_children 257181584
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_lib 316671
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_root 10001833
#define LBL_selection 2055983820
#define LBL_shutdown 575795380
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V, V);
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo;
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(V, V);
V g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306_clo;
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(V, V, V, V);
V g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039(V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_clo;
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(V, V);
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_clo;
V g_heff_2elsp_2elsp_2echildJson(V, V);
V g_heff_2elsp_2elsp_2echildJson_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echildJson_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819(V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1735462575x1745346429(V, V);
V g_list_2eany_24s1735462575x1745346429_entry(V self, V *a);
extern Clo g_list_2eany_24s1735462575x1745346429_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_std_2emap_2edelete_24s339308281x1667047697(V, V);
V g_std_2emap_2edelete_24s339308281x1667047697_entry(V self, V *a);
extern Clo g_std_2emap_2edelete_24s339308281x1667047697_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 9, "character");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = heff_strLength_lent(v_src_240, 0);
  V v_y_244;
  if (heff_intLe_c_lent(v_x_242, v_i_241, 0)) {
    v_y_244 = v_x_242;
  } else {
    heff_drop(v_x_242);
    v_y_244 = heff_dup(v_i_241);
  }
  V v_i_246;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_244, 1)) {
    v_i_246 = v_y_244;
  } else {
    heff_drop(v_y_244);
    v_i_246 = MK_INT(0LL);
  }
  V v_x_247 = heff_strLength_lent(v_src_240, 0);
  V v_y_249;
  if (heff_intLe_c_lent(v_x_247, v_i_241, 0)) {
    heff_drop(v_i_241);
    v_y_249 = v_x_247;
  } else {
    heff_drop(v_x_247);
    v_y_249 = v_i_241;
  }
  V v_t_2411;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_249, 1)) {
    v_t_2411 = v_y_249;
  } else {
    heff_drop(v_y_249);
    v_t_2411 = MK_INT(0LL);
  }
  V v_j_2412 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eposition_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_2414;
  if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
    heff_drop(v_j_2412);
    v_t_2414 = NTAG(TAG_Nothing);
  } else {
    v_t_2414 = heff_tag_n(TAG_Just, 1, (V[]){v_j_2412});
  }
  HeffT3 v_t_2415 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, v_t_2411, MK_INT(0LL), MK_INT(0LL), v_t_2414));
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    heff_drop(v_t_2415.f[2]);
    V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_field_2416})});
    V v_t_2420 = (g_heff_2elsp_2elsp_2eunits16Go(v_src_240, heff_intSub(heff_dup(v_i_246), v_field_2417), v_i_246, MK_INT(0LL)));
    V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2422})});
  }
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eposition(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2erange_str1, 5, "start");
Clo g_heff_2elsp_2elsp_2erange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erange_entry, 2, 0};

V g_heff_2elsp_2elsp_2erange(V v_src_240, V v_sp_241) {
top: ;
  V v_t_242 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(heff_rfield(v_sp_241, 0))));
  V v_x_243 = heff_take_field(v_sp_241, 0);
  V v_y_244 = heff_get_n(v_sp_241, 1, 2);
  V v_t_246;
  if (heff_intLe_c_lent(v_x_243, v_y_244, 0)) {
    heff_drop(v_x_243);
    v_t_246 = v_y_244;
  } else {
    heff_drop(v_y_244);
    v_t_246 = v_x_243;
  }
  V v_t_247 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_246));
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str0), v_t_247}), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erange_str1), v_t_242}), v_t_248});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_249});
}
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2erange(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2ecatMaybesL_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry, 2, 0};

V g_heff_2elsp_2elsp_2ecatMaybesL_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2ecatMaybesL_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ecatMaybesL_24dps(a[0], a[1]);
}
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str0, 3, "end");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str1, 5, "start");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str2, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str3, 8, "children");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str4, 14, "selectionRange");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str5, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2edocSymbol_str6, 4, "name");
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2edocSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2edocSymbol_entry, 2, 0};

V g_heff_2elsp_2elsp_2edocSymbol(V v_src_240, V v_y_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_JString, 1, (V[]){heff_take_field(v_y_241, 0)});
  V v_t_243 = heff_tag_n(TAG_JInt, 1, (V[]){heff_take_field(v_y_241, 1)});
  V v_x_244 = heff_get_n(heff_dup(heff_rfield(v_y_241, 2)), 1, 2);
  V v_y_245 = heff_get_n(heff_dup(heff_rfield(v_y_241, 3)), 1, 2);
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_y_241, 2)), 0, 2);
  V v_t_248;
  if (heff_intLe_c_lent(v_x_244, v_y_245, 0)) {
    heff_drop(v_x_244);
    v_t_248 = v_y_245;
  } else {
    heff_drop(v_y_245);
    v_t_248 = v_x_244;
  }
  V v_t_249 = (g_heff_2elsp_2elsp_2eposition(v_src_240, heff_dup(v_t_246)));
  V v_t_2411;
  if (heff_intLe_c_lent(v_t_246, v_t_248, 0)) {
    heff_drop(v_t_246);
    v_t_2411 = v_t_248;
  } else {
    heff_drop(v_t_248);
    v_t_2411 = v_t_246;
  }
  V v_t_2412 = (g_heff_2elsp_2elsp_2eposition(v_src_240, v_t_2411));
  V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str0), v_t_2412}), NTAG(TAG_Nil)});
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str1), v_t_249}), v_t_2413});
  V v_t_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str2), heff_tag_n(TAG_JObject, 1, (V[]){v_t_2414})});
  V v_t_2416 = (g_heff_2elsp_2elsp_2erange(v_src_240, heff_take_field(v_y_241, 3)));
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2edocSymbol_lam0, 1, 1, (V[]){heff_dup(v_src_240)}), heff_get_n(v_y_241, 4, 5)));
  V v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str3), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str4), v_t_2416}), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str5), v_t_243}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2edocSymbol_str6), v_t_242}), v_t_2422});
  return heff_tag_n(TAG_JObject, 1, (V[]){v_t_2423});
}
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2edocSymbol(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2edocSymbol_lam0(V self, V *args) {
  V v_m_2417 = args[0];
  V v_src_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_src_240; V a_1 = v_m_2417; V r_ = (g_heff_2elsp_2elsp_2echildJson(a_0, a_1)); heff_drop(v_src_240); r_; });
}
Clo g_heff_2elsp_2elsp_2elowerGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2elowerGo_entry, 3, 0};

V g_heff_2elsp_2elsp_2elowerGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_acc_242;
  } else {
    V v_t_247;
    if ((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) <= ((int64_t)90ULL))) {
        int64_t v_t_246 = (heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) + ((int64_t)32ULL));
        v_t_247 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_box_word(v_t_246))));
      } else {
        v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))));
      }
    } else {
      v_t_247 = heff_strSlice(heff_dup(v_s_240), heff_dup(v_i_241), heff_box_word((heff_peek_word(v_i_241) + ((int64_t)1ULL))));
    }
    V t_0 = v_s_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = heff_strAppend(v_acc_242, v_t_247);
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2elowerGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V v_changed_240, V v_mods_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_c_244, 1))}));
    V v_t_247 = (g_list_2eany(v_t_246, v_changed_240));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
      V t_0 = v_changed_240;
      V t_1 = v_t_2410;
      V t_2 = v_rest_245;
      V t_3 = v_cell_248;
      v_changed_240 = t_0;
      v_mods_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_247);
      V v_t_2413 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_244, 8)));
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        V v_cell_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
        V v_u_2415 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2414));
        heff_drop(v_u_2415);
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
        V t_0 = v_changed_240;
        V t_1 = v_t_2416;
        V t_2 = v_rest_245;
        V t_3 = v_cell_2414;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_rec(v_c_244, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2413);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args) {
  V v_d_2411 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2411}));
  return ({ V a_0 = v_t_2412; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(V v_st_240, V v_f_241) {
top: ;
  V v_t_242 = (g_std_2emap_2edelete_24s339308281x1667047697(heff_dup(heff_rfield(v_st_240, 2)), v_f_241));
  V v_t_243 = heff_rec_n(7, shape_docs__checked__due__project__watch__shutdown__lib, (V[]){heff_dup(heff_rfield(v_st_240, 0)), heff_dup(heff_rfield(v_st_240, 1)), v_t_242, heff_dup(heff_rfield(v_st_240, 3)), heff_dup(heff_rfield(v_st_240, 4)), heff_dup(heff_rfield(v_st_240, 5)), heff_dup(heff_rfield(v_st_240, 6))});
  V v_c_244 = (g_heff_2elsp_2elsp_2echeck_24s2030833921x548545306(v_t_243, heff_dup(v_f_241)));
  return heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam0, 2, 3, (V[]){v_c_244, v_st_240, v_f_241});
}
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam2(V self, V *args) {
  V v_p_249 = args[0];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412;
  switch (heff_tag_of(v_p_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_dup(heff_field(v_p_249, 0));
    v_t_2412 = v_x_2410;
    break;
  }
  default: heff_nomatch(v_p_249);
  }
  if (heff_strEq_c_lent(v_t_2412, v_f_241, 1)) {
    heff_drop(v_p_249);
    heff_drop(v_f_241);
    return NTAG(TAG_False);
  } else {
    V v_t_2416;
    switch (heff_tag_of(v_p_249)) {
    case TAG_MkPair: {
      V v_y_2415 = heff_field(v_p_249, 1);
      heff_take_n(v_p_249, 2ULL, 2);
      v_t_2416 = v_y_2415;
      break;
    }
    default: heff_nomatch(v_p_249);
    }
    return ({ V a_0 = v_f_241; V b_1 = heff_get_n(v_t_2416, 1, 2); V r_ = (g_list_2eany_24s1735462575x1745346429(a_0, b_1)); heff_drop(v_f_241); heff_drop(b_1); r_; });
  }
}
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = ({ V b_0 = heff_get_n(v_st_240, 1, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2417 = (g_list_2efilter(heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam2, 1, 1, (V[]){v_f_241}), v_t_248));
  V v_t_2418 = (g_list_2emap_24s1415906091x1371825187(v_t_2417));
  return ({ V a_0 = v_x_247; V a_1 = v_t_2418; V a_2 = v_hd_245; V a_3 = v_k_246; V r_ = (g_heff_2elsp_2elsp_2echeckAll_24s1039031146x647879192(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
}
V g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806_lam1, 1, 4, (V[]){v_st_240, v_f_241, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam0, 2, 0};
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_entry, 2, 0};

V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_st_240, 7);
    return ((V)&g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam0_clo);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2eload_2epathsFor_24s484373225x145046097(heff_dup(heff_rfield(v_st_240, 6)), heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam1, 2, 4, (V[]){v_c_246, v_st_240, v_rest_245, v_f_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819(a[0], a[1]);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_249, 0, 6), v_f_244});
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2410 = (g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819(v_st_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam3, 1, 3, (V[]){v_x_249, v_f_244, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erootsOf_24s1399916356x1103218819_lam2, 1, 5, (V[]){v_st_240, v_rest_245, v_hd_247, v_f_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_entry, 2, 0};

V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039(V v_st_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam0, 2, 1, (V[]){v_st_240});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_c_246 = (g_heff_2elsp_2elsp_2echeckNow_24s1543828617x290914806(v_st_240, heff_dup(v_f_244)));
    return heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam1, 2, 2, (V[]){v_c_246, heff_dup(v_rest_245)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_st_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_k_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = ({ V a_0 = v_x_249; V a_1 = v_rest_245; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2echeckDue_24s1924073403x1549637039_lam2, 1, 3, (V[]){v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}