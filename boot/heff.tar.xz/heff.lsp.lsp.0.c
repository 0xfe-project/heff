// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_Closed 4831
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Message 12631
#define TAG_Now 25954
#define TAG_PathUri 23459
#define TAG_Quit 47258
#define TAG_Right 62770
#define TAG_Send 26077
#define TAG_Timeout 14063
#define LBL_binder 558177493
#define LBL_checked 974171621
#define LBL_cut 308412
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_deps 9575179
#define LBL_diags 296935042
#define LBL_docs 9584386
#define LBL_done 9584713
#define LBL_due 309358
#define LBL_errors 652506774
#define LBL_key 315609
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_occurrences 673885394
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_st 10440
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_uri 325606
#define LBL_uses 10094739
#define LBL_watch 314261737
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_program__diags[] = {LBL_program, LBL_diags};
static uint32_t shape_st__text__program[] = {LBL_st, LBL_text, LBL_program};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2einFile(V, V, V);
V g_heff_2ebuild_2equery_2einFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFile_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631_clo;
V g_heff_2elsp_2elsp_2ecapabilities_get(void);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(V, V, V);
V g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694_clo;
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139(V, V, V, V, V);
V g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139_clo;
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950(V, V, V);
V g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950_clo;
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(V, V, V);
V g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843_clo;
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558(V, V, V);
V g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2ediagnostic(V, V);
V g_heff_2elsp_2elsp_2ediagnostic_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_clo;
V g_heff_2elsp_2elsp_2ediagnostic_24tok1(V, V, V);
V g_heff_2elsp_2elsp_2ediagnostic_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagnostic_24tok1_clo;
V g_heff_2elsp_2elsp_2ediagsOf(V, V, V);
V g_heff_2elsp_2elsp_2ediagsOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ediagsOf_clo;
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(V, V);
V g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510_clo;
V g_heff_2elsp_2elsp_2edocSymbol(V, V);
V g_heff_2elsp_2elsp_2edocSymbol_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edocSymbol_clo;
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051(V, V, V, V);
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_clo;
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913(V, V, V, V);
V g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913_clo;
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301_clo;
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199_clo;
V g_heff_2elsp_2elsp_2ehoverOf(V, V);
V g_heff_2elsp_2elsp_2ehoverOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehoverOf_clo;
V g_heff_2elsp_2elsp_2ekeptOf(V);
V g_heff_2elsp_2elsp_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeptOf_clo;
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734(V, V, V);
V g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734_clo;
V g_heff_2elsp_2elsp_2elowerGo(V, V, V);
V g_heff_2elsp_2elsp_2elowerGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elowerGo_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2enubRoots(V);
V g_heff_2elsp_2elsp_2enubRoots_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubRoots_clo;
V g_heff_2elsp_2elsp_2eoffsetIn(V, V);
V g_heff_2elsp_2elsp_2eoffsetIn_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eoffsetIn_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084(V, V, V, V, V);
V g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084_clo;
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958(V, V, V);
V g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958_clo;
V g_heff_2elsp_2elsp_2erange(V, V);
V g_heff_2elsp_2elsp_2erange_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erange_clo;
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1(V, V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530_24tok1_clo;
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_clo;
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503(V, V, V);
V g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503_clo;
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(V, V, V, V);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385(V, V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385_clo;
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711_clo;
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900(V, V, V, V);
V g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900_clo;
V g_heff_2elsp_2elsp_2eundue(V, V);
V g_heff_2elsp_2elsp_2eundue_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eundue_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(V, V, V);
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_clo;
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(V, V, V);
V g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_heff_2elsp_2erpc_2eawait_24s45816022x200024774(V, V, V, V);
V g_heff_2elsp_2erpc_2eawait_24s45816022x200024774_entry(V self, V *a);
extern Clo g_heff_2elsp_2erpc_2eawait_24s45816022x200024774_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(V, V, V);
V g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_entry(V self, V *a);
extern Clo g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396_clo;
V g_json_2equotedInto_2eescapeInto_241(V, V, V);
V g_json_2equotedInto_2eescapeInto_241_entry(V self, V *a);
extern Clo g_json_2equotedInto_2eescapeInto_241_clo;
V g_json_2estringify_2ewriteInto_240(V, V);
V g_json_2estringify_2ewriteInto_240_entry(V self, V *a);
extern Clo g_json_2estringify_2ewriteInto_240_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1836353438x580818415(V, V);
V g_list_2eany_24s1836353438x580818415_entry(V self, V *a);
extern Clo g_list_2eany_24s1836353438x580818415_clo;
V g_list_2eascending_24s1053575971x1138989897(V, V, V);
V g_list_2eascending_24s1053575971x1138989897_entry(V self, V *a);
extern Clo g_list_2eascending_24s1053575971x1138989897_clo;
V g_list_2edescending_24s136597790x1673774577(V, V, V);
V g_list_2edescending_24s136597790x1673774577_entry(V self, V *a);
extern Clo g_list_2edescending_24s136597790x1673774577_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
HeffT2 g_list_2efind_24s343666469x451168509_24cpr(V, V);
V g_list_2efoldl_24s1096141254x104586789(V, V);
V g_list_2efoldl_24s1096141254x104586789_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1096141254x104586789_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1201185697x960477413(V, V);
V g_list_2ekeepIf_24s1201185697x960477413_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1201185697x960477413_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1392650298x1192381411(V, V, V);
V g_list_2emap_24s1392650298x1192381411_entry(V self, V *a);
extern Clo g_list_2emap_24s1392650298x1192381411_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s328130413x305756849(V, V, V, V);
V g_list_2emap_24s328130413x305756849_entry(V self, V *a);
extern Clo g_list_2emap_24s328130413x305756849_clo;
V g_list_2emap_24s366344330x1145113647(V);
V g_list_2emap_24s366344330x1145113647_entry(V self, V *a);
extern Clo g_list_2emap_24s366344330x1145113647_clo;
V g_list_2emap_24s4199228x1154005405(V);
V g_list_2emap_24s4199228x1154005405_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_clo;
V g_list_2emap_24s4199228x1154005405_24tok2(V, V);
V g_list_2emap_24s4199228x1154005405_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s4199228x1154005405_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_list_2emergeRuns_24s655705766x180835539(V, V);
V g_list_2emergeRuns_24s655705766x180835539_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s655705766x180835539_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 9, "character");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = heff_strLength_lent(v_src_240, 0);
  V v_y_243;
  if (heff_intLe_c_lent(v_x_242, v_i_241, 0)) {
    v_y_243 = v_x_242;
  } else {
    heff_drop(v_x_242);
    v_y_243 = heff_dup(v_i_241);
  }
  V v_i_244;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
    v_i_244 = v_y_243;
  } else {
    heff_drop(v_y_243);
    v_i_244 = MK_INT(0LL);
  }
  V v_x_245 = heff_strLength_lent(v_src_240, 0);
  V v_y_246;
  if (heff_intLe_c_lent(v_x_245, v_i_241, 0)) {
    heff_drop(v_i_241);
    v_y_246 = v_x_245;
  } else {
    heff_drop(v_x_245);
    v_y_246 = v_i_241;
  }
  V v_t_247;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = MK_INT(0LL);
  }
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eposition_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  HeffT3 v_t_2410 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, v_t_247, MK_INT(0LL), MK_INT(0LL), v_t_249));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[2]);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_field_2411})});
    V v_t_2415 = (g_heff_2elsp_2elsp_2eunits16Go(v_src_240, heff_intSub(heff_dup(v_i_244), v_field_2412), v_i_244, MK_INT(0LL)));
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417})});
  }
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eposition(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V v_changed_240, V v_mods_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246 = (g_list_2eany_24s1836353438x580818415(heff_dup(v_c_244), v_changed_240));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
      V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
      V t_0 = v_changed_240;
      V t_1 = v_t_249;
      V t_2 = v_rest_245;
      V t_3 = v_cell_247;
      v_changed_240 = t_0;
      v_mods_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V v_t_2411 = (g_list_2eany(heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}), heff_rfield(v_c_244, 8)));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_c_244, 1)), heff_hole()});
        V v_u_2413 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2412));
        heff_drop(v_u_2413);
        V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_c_244, 0, 14), v_mods_241});
        V t_0 = v_changed_240;
        V t_1 = v_t_2414;
        V t_2 = v_rest_245;
        V t_3 = v_cell_2412;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_rec(v_c_244, 14);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_t_2411);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args) {
  V v_d_2410 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_2410; V a_1 = v_mods_241; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_d_2410); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam2, 3, 0};
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam5(V self, V *args);
Clo g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_entry, 6, 0};

V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195(V v_e_240, V v_st_241, V v_f_242, V v_d_243, V v_z_244, V v_z_245) {
top: ;
  V v_docs_246 = heff_take_field(v_st_241, 0);
  V v_lib_247 = heff_get_n(v_st_241, 6, 7);
  V v_c_2429 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s39142907x1515204265(heff_dup(v_e_240), heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam0, 1, 2, (V[]){v_docs_246, heff_dup(v_e_240)}), v_lib_247, v_f_242));
  return heff_tail(v_c_2429, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam5, 1, 4, (V[]){v_e_240, v_z_244, v_d_243, v_z_245})});
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_d_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2413);
  V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2412, 1, 2)});
  V f_ = v_k_2414;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2419});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2428;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2427 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    v_t_2428 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_Just, 1, (V[]){v_y_2427});
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V f_ = v_k_2424;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2422;
  args[0] = v_hd_2423;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam4, 1, 1, (V[]){v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_docs_246 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_249 = ({ V a_0 = v_docs_246; V a_1 = v_p_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_docs_246); r_; });
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      heff_drop(v_p_248);
      heff_drop(v_e_240);
      V v_d_2412 = v_field_2411;
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam1, 2, 1, (V[]){v_d_2412});
    } else {
      heff_drop(v_field_2411);
      V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_248));
      V v_c_2417 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2416; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2416); r_; });
      V v_t_2418 = (g_exception_2eattempted(v_e_240));
      V v_c_2422 = heff_tr(heff_call(v_c_2417, 2, (V[]){v_t_2418, ((V)&g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam2_clo)}));
      return heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam3, 2, 1, (V[]){v_c_2422});
    }
  }
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_d_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_d_243, 1, 2); V a_1 = v_x_2437; V r_ = (g_heff_2elsp_2elsp_2ediagnostic(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_full_2433 = heff_get_n(v_x_2432, 0, 2);
  V v_program_2434 = (g_heff_2elsp_2elsp_2ekeptOf(heff_dup(v_full_2433)));
  V v_t_2435 = (g_heff_2elsp_2elsp_2ekeptOf(v_full_2433));
  V v_t_2436 = (g_heff_2elsp_2elsp_2ediagsOf(heff_dup(heff_rfield(v_d_243, 1)), v_t_2435, heff_get_n(v_x_2430, 1, 5)));
  V v_diags_2438 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam7, 1, 1, (V[]){v_d_243}), v_t_2436));
  V f_ = v_z_245;
  args[0] = heff_rec_n(2, shape_program__diags, (V[]){v_program_2434, v_diags_2438});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2431 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(v_e_240, heff_dup(v_x_2430)));
  V f_ = v_c_2431;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eanalysed_24s1423086475x1436893195_lam6, 1, 3, (V[]){v_d_243, v_x_2430, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_str1, 0, "");
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam2(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam2, 1, 0};
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam3(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_entry, 7, 0};

V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815(V v_e_240, V v_st_241, V v_f_242, V v_d_243, V v_why_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam0, 1, 4, (V[]){heff_dup(v_d_243), heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_f_242)})})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_245), heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam3, 1, 7, (V[]){v_d_243, v_e_240, v_st_241, v_f_242, v_why_244, v_hd_245, v_k_246})));
}
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_d_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_src_2410 = heff_dup(heff_rfield(v_d_243, 1));
  V v_t_2411 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_243, 1), MK_INT(0LL)));
  V v_ds_2412 = ({ V a_0 = v_t_2411; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_str0); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  HeffT3 v_t_2413 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ds_2412; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_2412); r_; });
  V v_t_2419;
  {
    V v_field_2415 = v_t_2413.f[1];
    V v_field_2416 = v_t_2413.f[2];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      heff_drop(v_src_2410);
      V v_x_2417 = v_field_2415;
      V v_x12_2418 = v_field_2416;
      heff_drop(v_x12_2418);
      v_t_2419 = heff_get_n(v_x_2417, 0, 2);
    } else {
      heff_drop(v_field_2415);
      heff_drop(v_field_2416);
      v_t_2419 = heff_strLength(v_src_2410);
    }
  }
  return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_t_2419; V a_5 = v_hd_248; V a_6 = v_k_249; V r_ = (g_heff_2elsp_2elsp_2eanalysedUpTo_24s1419843778x1975000631(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2419); r_; });
}
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam2(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam0(V self, V *args) {
  V v_use_247 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_use_247;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam1, 2, 4, (V[]){v_d_243, v_e_240, v_st_241, v_f_242});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam2_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_why_244 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_243, 1), MK_INT(0LL)));
  V v_t_2428 = ({ V a_0 = v_t_2427; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s527022090x1270972815_str1); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_f_242; V a_3 = v_d_243; V a_4 = v_why_244; V a_5 = v_t_2428; V a_6 = v_x_2426; V a_7 = v_hd_245; V a_8 = v_k_246; V r_ = (g_heff_2elsp_2elsp_2estoppedFrom_24s1885518157x2017911385(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2428); heff_drop(v_x_2426); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_str1, 0, "");
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_entry, 3, 0};

V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(V v_e_240, V v_st_241, V v_p_242) {
top: ;
  V v_c_243 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), v_p_242));
  return heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam0, 2, 3, (V[]){v_c_243, v_st_241, v_e_240});
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2427 = heff_get_n(v_d_2412, 1, 2);
  HeffT2 v_t_2428 = ({ V a_0 = heff_rfield(v_x_2426, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
  V v_x_2434;
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      V v_c_2431 = v_field_2430;
      V v_text_2432 = heff_take_field(v_c_2431, 0);
      V v_program_2433 = heff_get_n(v_c_2431, 1, 2);
      if (heff_strEq_c_lent(v_text_2432, v_text_2427, 1)) {
        v_x_2434 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2426, v_text_2427, v_program_2433});
      } else {
        heff_drop(v_program_2433);
        v_x_2434 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2426, v_text_2427, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2430);
      v_x_2434 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2426, v_text_2427, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_d_2412 = heff_env(self)[0];
  V v_f_248 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_text_2437 = heff_get_n(v_d_2412, 1, 2);
  HeffT2 v_t_2438 = ({ V a_0 = heff_rfield(v_x_2436, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
  V v_x_2444;
  {
    V v_field_2440 = v_t_2438.f[1];
    int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
    if ((v_tag_2439 == ((int64_t)0ULL))) {
      V v_c_2441 = v_field_2440;
      V v_text_2442 = heff_take_field(v_c_2441, 0);
      V v_program_2443 = heff_get_n(v_c_2441, 1, 2);
      if (heff_strEq_c_lent(v_text_2442, v_text_2437, 1)) {
        v_x_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2436, v_text_2437, v_program_2443});
      } else {
        heff_drop(v_program_2443);
        v_x_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2436, v_text_2437, NTAG(TAG_Nil)});
      }
    } else {
      heff_drop(v_field_2440);
      v_x_2444 = heff_rec_n(3, shape_st__text__program, (V[]){v_x_2436, v_text_2437, NTAG(TAG_Nil)});
    }
  }
  V f_ = v_k_245;
  args[0] = v_x_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_hd_244);
    V v_t_247 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_str0), NTAG(TAG_Nil)});
    V f_ = v_k_245;
    args[0] = v_t_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_f_248 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    HeffT2 v_t_249 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_f_248));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_d_2412 = v_field_2411;
        HeffT2 v_t_2413 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 1), v_f_248));
        {
          V v_field_2415 = v_t_2413.f[1];
          int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
          if ((v_tag_2414 == ((int64_t)0ULL))) {
            V v_c_2416 = v_field_2415;
            if (heff_strEq_c(heff_get_n(v_c_2416, 0, 2), heff_dup(heff_rfield(v_d_2412, 1)))) {
              heff_drop(v_e_240);
              heff_drop(v_hd_244);
              V v_text_2417 = heff_get_n(v_d_2412, 1, 2);
              HeffT2 v_t_2418 = ({ V a_0 = heff_rfield(v_st_241, 1); V a_1 = v_f_248; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_f_248); r_; });
              V v_x_2424;
              {
                V v_field_2420 = v_t_2418.f[1];
                int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                if ((v_tag_2419 == ((int64_t)0ULL))) {
                  V v_c_2421 = v_field_2420;
                  V v_text_2422 = heff_take_field(v_c_2421, 0);
                  V v_program_2423 = heff_get_n(v_c_2421, 1, 2);
                  if (heff_strEq_c_lent(v_text_2422, v_text_2417, 1)) {
                    v_x_2424 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2417, v_program_2423});
                  } else {
                    heff_drop(v_program_2423);
                    v_x_2424 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2417, NTAG(TAG_Nil)});
                  }
                } else {
                  heff_drop(v_field_2420);
                  v_x_2424 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, v_text_2417, NTAG(TAG_Nil)});
                }
              }
              V f_ = v_k_245;
              args[0] = v_x_2424;
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              V v_c_2425 = (g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(v_e_240, v_st_241, heff_dup(v_f_248)));
              V f_ = v_c_2425;
              heff_room[0] = v_hd_244;
              heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam2, 1, 3, (V[]){v_d_2412, v_f_248, v_k_245});
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop(v_field_2415);
            V v_c_2435 = (g_heff_2elsp_2elsp_2echeck_24s2015952991x985040694(v_e_240, v_st_241, heff_dup(v_f_248)));
            V f_ = v_c_2435;
            heff_room[0] = v_hd_244;
            heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam3, 1, 3, (V[]){v_d_2412, v_f_248, v_k_245});
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      } else {
        heff_drop(v_e_240);
        heff_drop(v_hd_244);
        heff_drop(v_f_248);
        heff_drop(v_field_2411);
        V v_t_2445 = heff_rec_n(3, shape_st__text__program, (V[]){v_st_241, ((V)&g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_str1), NTAG(TAG_Nil)});
        V f_ = v_k_245;
        args[0] = v_t_2445;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680_lam1, 1, 4, (V[]){v_st_241, v_k_245, v_e_240, v_hd_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam0, 2, 0};
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_entry, 4, 0};

V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051(V v_e_240, V v_st_241, V v_c_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_c_242);
    return ((V)&g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam0_clo);
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_c_248 = (g_heff_2elsp_2elsp_2esymbolJson_24s47654120x2037056711(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_c_242), v_y_246));
    return heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam1, 2, 5, (V[]){v_c_248, v_e_240, v_st_241, v_c_242, v_rest_247});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_c_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2412 = (g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051(v_e_240, v_st_241, v_c_242, v_rest_247));
  V f_ = v_c_2412;
  heff_room[0] = v_hd_249;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam3, 1, 2, (V[]){v_k_2410, v_x_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_c_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2eeachSymbol_24s281744748x514211051_lam2, 1, 6, (V[]){v_e_240, v_st_241, v_c_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str0, 10, "initialize");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str1, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str2, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str3, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str4, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str5, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str6, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str7, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str8, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str9, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str10, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str11, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str12, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str13, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str14, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str15, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str16, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str17, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str18, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str19, 12, "capabilities");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str20, 9, "workspace");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str21, 19, "dynamicRegistration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str22, 21, "didChangeWatchedFiles");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str23, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str24, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str25, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str26, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str27, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str28, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str29, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str30, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str31, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str32, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str33, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str34, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str35, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str36, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str37, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str38, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str39, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str40, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str41, 4, "null");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str42, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str43, 18, "textDocument/hover");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str44, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str45, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str46, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str47, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str48, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str49, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str50, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str51, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str52, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str53, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str54, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str55, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str56, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str57, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str58, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str59, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str60, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str61, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str62, 23, "textDocument/definition");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str63, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str64, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str65, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str66, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str67, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str68, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str69, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str70, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str71, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str72, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str73, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str74, 3, "uri");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str75, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str76, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str77, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str78, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str79, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str80, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str81, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str82, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str83, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str84, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str85, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str86, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str87, 30, "textDocument/documentHighlight");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str88, 5, "range");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str89, 4, "kind");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str90, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str91, 2, "{\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str92, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str93, 1, ":");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str94, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str95, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str96, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str97, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str98, 1, ",");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str99, 1, "\"");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str100, 1, "}");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str101, 23, "textDocument/completion");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str102, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str103, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str104, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str105, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str106, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str107, 27, "textDocument/documentSymbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str108, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str109, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str110, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str111, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str112, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str113, 16, "workspace/symbol");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str114, 5, "query");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str115, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str116, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str117, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str118, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str119, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str120, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str121, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str122, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str123, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str124, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str125, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str126, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str127, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str128, 23, "textDocument/references");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str129, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str130, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str131, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str132, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str133, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str134, 18, "includeDeclaration");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str135, 7, "context");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str136, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str137, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str138, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str139, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str140, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str141, 26, "textDocument/prepareRename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str142, 19, "textDocument/rename");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str143, 7, "newName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str144, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str145, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str146, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str147, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str148, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str149, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str150, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str151, 23, "textDocument/formatting");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str152, 23, "textDocument/codeAction");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str153, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str154, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str155, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str156, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str157, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str158, 15, "heff/moduleName");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str159, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str160, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str161, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str162, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str163, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str164, 7, "jsonrpc");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str165, 3, "2.0");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str166, 6, "result");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str167, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str168, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str169, 10, "no method ");
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam1(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam6(V self, V *args); static Clo g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam6, 1, 0};
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam16(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam20(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam22(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam24(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam23(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam25(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam21(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam26(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam27(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam31(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam30(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam29(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam28(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam33(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam35(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam34(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam32(V self, V *args);
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam36(V self, V *args);
Clo g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_entry, 7, 0};

V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282(V v_e_240, V v_st_241, V v_m_242, V v_id_243, V v_p_244, V v_z_245, V v_z_246) {
top: ;
  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str0), 2)) {
    heff_drop(v_m_242);
    V v_t_247 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str1), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str2), MK_INT(0LL)));
    V v_acc_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str3)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str4));
    V v_t_249 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str5), heff_strAppend(v_acc_248, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str6)), MK_INT(0LL)));
    V v_acc_2410 = heff_strAppend(v_t_249, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str7));
    V v_t_2411 = heff_strAppend(heff_strAppend(v_acc_2410, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str8)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str9));
    V v_t_2412 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str10), v_t_2411, MK_INT(0LL)));
    V v_t_2413 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str11)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str12));
    V v_acc_2414 = ({ V a_0 = v_t_2413; V a_1 = v_id_243; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_243); r_; });
    V v_t_2415 = heff_strAppend(heff_strAppend(v_acc_2414, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str13)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str14));
    V v_t_2416 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str15), v_t_2415, MK_INT(0LL)));
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2416, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str16)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str17));
    V v_acc_2418 = ({ V a_0 = v_t_2417; V b_1 = heff_dup(g_heff_2elsp_2elsp_2ecapabilities_get()); V r_ = (g_json_2estringify_2ewriteInto_240(a_0, b_1)); heff_drop(b_1); r_; });
    V v_a_2419 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_2418, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str18)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2424, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam0, 1, 3, (V[]){v_p_244, v_st_241, v_z_246})));
  } else {
    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str23), 2)) {
      heff_drop(v_m_242);
      heff_drop(v_p_244);
      V v_t_2469 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str24), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str25), MK_INT(0LL)));
      V v_acc_2470 = heff_strAppend(heff_strAppend(v_t_2469, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str26)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str27));
      V v_t_2471 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str28), heff_strAppend(v_acc_2470, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str29)), MK_INT(0LL)));
      V v_acc_2472 = heff_strAppend(v_t_2471, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str30));
      V v_t_2473 = heff_strAppend(heff_strAppend(v_acc_2472, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str31)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str32));
      V v_t_2474 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str33), v_t_2473, MK_INT(0LL)));
      V v_t_2475 = heff_strAppend(heff_strAppend(v_t_2474, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str34)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str35));
      V v_acc_2476 = ({ V a_0 = v_t_2475; V a_1 = v_id_243; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_243); r_; });
      V v_t_2477 = heff_strAppend(heff_strAppend(v_acc_2476, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str36)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str37));
      V v_t_2478 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str38), v_t_2477, MK_INT(0LL)));
      V v_acc_2479 = heff_strAppend(heff_strAppend(v_t_2478, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str39)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str40));
      V v_t_2480 = heff_strAppend(heff_strAppend(v_acc_2479, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str41)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str42));
      V v_a_2481 = heff_tag_n(TAG_Send, 2, (V[]){v_t_2480, NTAG(TAG_MkUnit)});
      V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2481})});
      V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
      V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
      V v_t_2485 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2486, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam1, 1, 2, (V[]){v_st_241, v_z_246})));
    } else {
      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str43), 2)) {
        heff_drop(v_m_242);
        V v_c_2493 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
        return heff_tail(v_c_2493, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam2, 1, 5, (V[]){v_p_244, v_id_243, v_e_240, v_z_245, v_z_246})});
      } else {
        if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str62), 2)) {
          heff_drop(v_m_242);
          V v_c_24115 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
          return heff_tail(v_c_24115, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam4, 1, 5, (V[]){v_p_244, v_id_243, v_e_240, v_z_245, v_z_246})});
        } else {
          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str87), 2)) {
            heff_drop(v_m_242);
            V v_c_24174 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
            return heff_tail(v_c_24174, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam10, 1, 5, (V[]){v_p_244, v_id_243, v_e_240, v_z_245, v_z_246})});
          } else {
            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str101), 2)) {
              heff_drop(v_m_242);
              V v_c_24232 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
              return heff_tail(v_c_24232, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam12, 1, 5, (V[]){v_p_244, v_id_243, v_e_240, v_z_245, v_z_246})});
            } else {
              if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str107), 2)) {
                heff_drop(v_m_242);
                V v_c_24256 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, v_p_244));
                return heff_tail(v_c_24256, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam14, 1, 4, (V[]){v_id_243, v_e_240, v_z_245, v_z_246})});
              } else {
                if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str113), 2)) {
                  heff_drop(v_m_242);
                  V v_t_24280 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_241, 0), NTAG(TAG_Nil)));
                  V v_t_24281 = (g_list_2emap_24s1415906091x1371825187(v_t_24280));
                  V v_c_24282 = (g_heff_2elsp_2elsp_2erootsOf_24s1631821018x930599503(heff_dup(v_e_240), heff_dup(v_st_241), v_t_24281));
                  return heff_tail(v_c_24282, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam17, 1, 6, (V[]){v_e_240, v_st_241, v_z_245, v_p_244, v_id_243, v_z_246})});
                } else {
                  if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str128), 2)) {
                    heff_drop(v_m_242);
                    V v_c_24318 = (g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
                    return heff_tail(v_c_24318, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam21, 1, 5, (V[]){v_id_243, v_e_240, v_p_244, v_z_245, v_z_246})});
                  } else {
                    if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str141), 2)) {
                      heff_drop(v_m_242);
                      V v_c_24367 = (g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(heff_dup(v_e_240), v_st_241, v_p_244));
                      return heff_tail(v_c_24367, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam26, 1, 4, (V[]){v_e_240, v_id_243, v_z_245, v_z_246})});
                    } else {
                      if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str142), 2)) {
                        heff_drop(v_m_242);
                        V v_c_24369 = (g_heff_2elsp_2elsp_2ewithTarget_24s399965813x455752953(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
                        return heff_tail(v_c_24369, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam27, 1, 5, (V[]){v_p_244, v_e_240, v_id_243, v_z_245, v_z_246})});
                      } else {
                        if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str151), 2)) {
                          heff_drop(v_m_242);
                          V v_t_24383 = ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_id_243; V a_3 = v_p_244; V r_ = (g_heff_2elsp_2elsp_2eformatted_24s460501196x167986913(a_0, a_1, a_2, a_3)); heff_drop(v_id_243); r_; });
                          return heff_tail(v_t_24383, 2, (V[]){v_z_245, v_z_246});
                        } else {
                          if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str152), 2)) {
                            heff_drop(v_m_242);
                            V v_c_24384 = (g_heff_2elsp_2elsp_2ewithProgram_24s1001860877x438666680(heff_dup(v_e_240), v_st_241, heff_dup(v_p_244)));
                            return heff_tail(v_c_24384, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam28, 1, 5, (V[]){v_e_240, v_p_244, v_z_245, v_id_243, v_z_246})});
                          } else {
                            if (heff_strEq_c_lent(v_m_242, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str158), 2)) {
                              heff_drop(v_m_242);
                              V v_c_24404 = heff_tr(g_heff_2elsp_2elsp_2edocPath_24s1636327530x1513893510(heff_dup(v_e_240), v_p_244));
                              return heff_tail(v_c_24404, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam32, 1, 5, (V[]){v_id_243, v_e_240, v_z_245, v_z_246, v_st_241})});
                            } else {
                              heff_drop(v_p_244);
                              V v_c_24436 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s667428224x2036846530(v_e_240, v_id_243, MK_INT(-32601LL), heff_strAppend(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str169), v_m_242)));
                              return heff_tail(v_c_24436, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam36, 1, 2, (V[]){v_z_246, v_st_241})});
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2425);
  V v_w_2463;
  switch (heff_tag_of(v_p_244)) {
  case TAG_JNull: {
    v_w_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_JBool: {
    heff_take_n(v_p_244, 0ULL, 1);
    v_w_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_JInt: {
    heff_take_n(v_p_244, 0ULL, 1);
    v_w_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_JFloat: {
    heff_take_na(v_p_244, 0ULL, 1);
    v_w_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_JString: {
    heff_take_n(v_p_244, 0ULL, 1);
    v_w_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_JArray: {
    heff_take_n(v_p_244, 0ULL, 1);
    v_w_2463 = NTAG(TAG_False);
    break;
  }
  case TAG_JObject: {
    V v_fs_2431 = heff_field(v_p_244, 0);
    heff_take_n(v_p_244, 1ULL, 1);
    HeffT2 v_t_2432 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str19); V a_1 = v_fs_2431; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2431); r_; });
    {
      V v_field_2434 = v_t_2432.f[1];
      int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
      if ((v_tag_2433 == ((int64_t)0ULL))) {
        V v_p_2435 = v_field_2434;
        V v_t_2438;
        switch (heff_tag_of(v_p_2435)) {
        case TAG_MkPair: {
          V v_y_2437 = heff_field(v_p_2435, 1);
          heff_take_n(v_p_2435, 2ULL, 2);
          v_t_2438 = v_y_2437;
          break;
        }
        default: heff_nomatch(v_p_2435);
        }
        switch (heff_tag_of(v_t_2438)) {
        case TAG_JNull: {
          v_w_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2438, 0ULL, 1);
          v_w_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2438, 0ULL, 1);
          v_w_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2438, 0ULL, 1);
          v_w_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_t_2438, 0ULL, 1);
          v_w_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2438, 0ULL, 1);
          v_w_2463 = NTAG(TAG_False);
          break;
        }
        case TAG_JObject: {
          V v_fs_2444 = heff_field(v_t_2438, 0);
          heff_take_n(v_t_2438, 1ULL, 1);
          HeffT2 v_t_2445 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str20); V a_1 = v_fs_2444; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2444); r_; });
          {
            V v_field_2447 = v_t_2445.f[1];
            int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
            if ((v_tag_2446 == ((int64_t)0ULL))) {
              V v_p_2448 = v_field_2447;
              V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str21), NTAG(TAG_Nil)});
              V v_t_2452;
              switch (heff_tag_of(v_p_2448)) {
              case TAG_MkPair: {
                V v_y_2451 = heff_field(v_p_2448, 1);
                heff_take_n(v_p_2448, 2ULL, 2);
                v_t_2452 = v_y_2451;
                break;
              }
              default: heff_nomatch(v_p_2448);
              }
              HeffT2 v_t_2453 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str22), v_t_2449}); V a_1 = v_t_2452; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
              {
                V v_field_2455 = v_t_2453.f[1];
                int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                if ((v_tag_2454 == ((int64_t)0ULL))) {
                  V v_it1_2456 = v_field_2455;
                  switch (heff_tag_of(v_it1_2456)) {
                  case TAG_JNull: {
                    v_w_2463 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JBool: {
                    V v_b_2457 = heff_field(v_it1_2456, 0);
                    heff_take_n(v_it1_2456, 1ULL, 1);
                    v_w_2463 = v_b_2457;
                    break;
                  }
                  case TAG_JInt: {
                    heff_take_n(v_it1_2456, 0ULL, 1);
                    v_w_2463 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JFloat: {
                    heff_take_na(v_it1_2456, 0ULL, 1);
                    v_w_2463 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JString: {
                    heff_take_n(v_it1_2456, 0ULL, 1);
                    v_w_2463 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JArray: {
                    heff_take_n(v_it1_2456, 0ULL, 1);
                    v_w_2463 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_JObject: {
                    heff_take_n(v_it1_2456, 0ULL, 1);
                    v_w_2463 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_it1_2456);
                  }
                } else {
                  heff_drop(v_field_2455);
                  v_w_2463 = NTAG(TAG_False);
                }
              }
            } else {
              heff_drop(v_field_2447);
              v_w_2463 = NTAG(TAG_False);
            }
          }
          break;
        }
        default: heff_nomatch(v_t_2438);
        }
      } else {
        heff_drop(v_field_2434);
        v_w_2463 = NTAG(TAG_False);
      }
    }
    break;
  }
  default: heff_nomatch(v_p_244);
  }
  V v_due_2464 = heff_take_field(v_st_241, 2);
  V v_project_2465 = heff_take_field(v_st_241, 3);
  V v_shutdown_2466 = heff_take_field(v_st_241, 5);
  V v_lib_2467 = heff_take_field(v_st_241, 6);
  V v_t_2468 = ({ V rv_2 = v_due_2464; V rv_3 = v_project_2465; V rv_4 = v_w_2463; V rv_5 = v_shutdown_2466; V rv_6 = v_lib_2467; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_246;
  args[0] = v_t_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam1(V self, V *args) {
  V v_x_2487 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2487);
  V v_due_2488 = heff_take_field(v_st_241, 2);
  V v_project_2489 = heff_take_field(v_st_241, 3);
  V v_watch_2490 = heff_take_field(v_st_241, 4);
  V v_lib_2491 = heff_take_field(v_st_241, 6);
  V v_t_2492 = ({ V rv_2 = v_due_2488; V rv_3 = v_project_2489; V rv_4 = v_watch_2490; V rv_5 = NTAG(TAG_True); V rv_6 = v_lib_2491; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
  V f_ = v_z_246;
  args[0] = v_t_2492;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam3(V self, V *args) {
  V v_x_24114 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_2494 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24114);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_2494, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam2(V self, V *args) {
  V v_x_2494 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_result_2495 = (g_heff_2elsp_2elsp_2ehoverOf(heff_dup(v_x_2494), v_p_244));
  V v_t_2496 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str44), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str45), MK_INT(0LL)));
  V v_acc_2497 = heff_strAppend(heff_strAppend(v_t_2496, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str46)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str47));
  V v_t_2498 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str48), heff_strAppend(v_acc_2497, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str49)), MK_INT(0LL)));
  V v_acc_2499 = heff_strAppend(v_t_2498, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str50));
  V v_t_24100 = heff_strAppend(heff_strAppend(v_acc_2499, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str51)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str52));
  V v_t_24101 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str53), v_t_24100, MK_INT(0LL)));
  V v_t_24102 = heff_strAppend(heff_strAppend(v_t_24101, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str54)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str55));
  V v_acc_24103 = ({ V a_0 = v_t_24102; V a_1 = v_id_243; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_id_243); r_; });
  V v_t_24104 = heff_strAppend(heff_strAppend(v_acc_24103, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str56)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str57));
  V v_t_24105 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str58), v_t_24104, MK_INT(0LL)));
  V v_t_24106 = heff_strAppend(heff_strAppend(v_t_24105, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str59)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str60));
  V v_acc_24107 = ({ V a_0 = v_t_24106; V a_1 = v_result_2495; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop(v_result_2495); r_; });
  V v_a_24108 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_acc_24107, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str61)), NTAG(TAG_MkUnit)});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24110})});
  V v_t_24112 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
  V v_t_24113 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24113, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam3, 1, 2, (V[]){v_z_246, v_x_2494})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam5(V self, V *args) {
  V v_hd_24144 = args[0];
  V v_k_24145 = args[1];
  V v_d_24143 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24144);
  V f_ = v_k_24145;
  args[0] = heff_get_n(v_d_24143, 0, 2);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam6(V self, V *args) {
  V v_u_24146 = args[0];
  return v_u_24146;
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam8(V self, V *args) {
  V v_x_24155 = args[0];
  V v_source_24137 = heff_env(self)[0];
  V v_span_24138 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_24153 = heff_env(self)[4];
  V v_k_24154 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24156 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str74), heff_tag_n(TAG_JString, 1, (V[]){v_x_24155})});
  V v_t_24157 = ({ V a_0 = v_source_24137; V a_1 = v_span_24138; V r_ = (g_heff_2elsp_2elsp_2erange(a_0, a_1)); heff_drop(v_source_24137); r_; });
  V v_t_24158 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str75), v_t_24157}), NTAG(TAG_Nil)});
  V v_result_24159 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24156, v_t_24158})});
  V v_t_24160 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str76), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str77), MK_INT(0LL)));
  V v_acc_24161 = heff_strAppend(heff_strAppend(v_t_24160, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str78)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str79));
  V v_t_24162 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str80), heff_strAppend(v_acc_24161, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str81)), MK_INT(0LL)));
  V v_t_24163 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str82), v_result_24159}), NTAG(TAG_Nil)});
  V v_t_24164 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str83), v_id_243}), v_t_24163});
  V v_t_24165 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str84); V a_1 = heff_strAppend(v_t_24162, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str85)); V a_2 = v_t_24164; V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, a_2)); heff_drop_tag(v_t_24164, 2); r_; });
  V v_a_24166 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24165, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str86)), NTAG(TAG_MkUnit)});
  V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24166})});
  V v_t_24168 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24167})});
  V v_t_24169 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24168})});
  V v_t_24170 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24169})});
  V v_t_24171 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24170})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24171, v_hd_24153, v_k_24154));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam7(V self, V *args) {
  V v_hd_24153 = args[0];
  V v_k_24154 = args[1];
  V v_c_24152 = heff_env(self)[0];
  V v_source_24137 = heff_env(self)[1];
  V v_span_24138 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_24152;
  args[0] = heff_dup(v_hd_24153);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam8, 1, 6, (V[]){v_source_24137, v_span_24138, v_id_243, v_e_240, v_hd_24153, v_k_24154});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam9(V self, V *args) {
  V v_x_24173 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_24119 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24173);
  V f_ = v_z_246;
  args[0] = v_st_24119;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam4(V self, V *args) {
  V v_x_24116 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_program_24117 = heff_take_field(v_x_24116, 2);
  V v_text_24118 = heff_take_field(v_x_24116, 1);
  V v_st_24119 = heff_get_n(v_x_24116, 0, 3);
  V v_t_24120 = ({ V a_0 = v_text_24118; V a_1 = v_p_244; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24118); r_; });
  V v_t_24121 = (g_heff_2ebuild_2equery_2edefinitionAt(v_program_24117, v_t_24120));
  V v_c_24172;
  switch (heff_tag_of(v_t_24121)) {
  case TAG_Nothing: {
    V v_t_24122 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str63), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str64), MK_INT(0LL)));
    V v_acc_24123 = heff_strAppend(heff_strAppend(v_t_24122, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str65)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str66));
    V v_t_24124 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str67), heff_strAppend(v_acc_24123, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str68)), MK_INT(0LL)));
    V v_t_24125 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str69), NTAG(TAG_JNull)});
    V v_t_24126 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24125, NTAG(TAG_Nil)});
    V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str70), v_id_243}), v_t_24126});
    V v_t_24128 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str71); V a_1 = heff_strAppend(v_t_24124, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str72)); V a_2 = v_t_24127; V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, a_2)); heff_drop_tag(v_t_24127, 2); r_; });
    V v_a_24129 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24128, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str73)), NTAG(TAG_MkUnit)});
    V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24129})});
    V v_t_24131 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24130})});
    V v_t_24132 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24131})});
    V v_t_24133 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24132})});
    V v_t_24134 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24133})});
    v_c_24172 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, v_t_24134}));
    break;
  }
  case TAG_Just: {
    V v_d_24135 = heff_field(v_t_24121, 0);
    V v_ru_24t_24121_24Just = heff_take_reuse_n(v_t_24121, 1ULL, 1);
    V v_path_24136 = heff_take_field(v_d_24135, 0);
    V v_source_24137 = heff_take_field(v_d_24135, 1);
    V v_span_24138 = heff_get_n(v_d_24135, 2, 3);
    V v_p_24139 = v_path_24136;
    HeffT2 v_t_24140 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_24119, 0), v_p_24139));
    V v_c_24152;
    {
      V v_field_24142 = v_t_24140.f[1];
      int64_t v_tag_24141 = ((int64_t)v_t_24140.f[0]);
      if ((v_tag_24141 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24t_24121_24Just, 1);
        heff_drop(v_p_24139);
        V v_d_24143 = v_field_24142;
        v_c_24152 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam5, 2, 1, (V[]){v_d_24143});
      } else {
        heff_drop(v_field_24142);
        V v_t_24147 = heff_tag_at_n(v_ru_24t_24121_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_PathUri, 2, (V[]){v_p_24139, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam6_clo)})});
        V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
        V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
        V v_t_24150 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24149})});
        V v_t_24151 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24150})});
        v_c_24152 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_24151})}));
      }
    }
    v_c_24172 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam7, 2, 5, (V[]){v_c_24152, v_source_24137, v_span_24138, v_id_243, v_e_240});
    break;
  }
  default: heff_nomatch(v_t_24121);
  }
  V f_ = v_c_24172;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam9, 1, 2, (V[]){v_z_246, v_st_24119});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam11(V self, V *args) {
  V v_x_24231 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_24178 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24231);
  V f_ = v_z_246;
  args[0] = v_st_24178;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam10(V self, V *args) {
  V v_x_24175 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_program_24176 = heff_take_field(v_x_24175, 2);
  V v_text_24177 = heff_take_field(v_x_24175, 1);
  V v_st_24178 = heff_get_n(v_x_24175, 0, 3);
  V v_program_24179 = v_program_24176;
  V v_off_24180 = ({ V a_0 = v_text_24177; V a_1 = v_p_244; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24177); r_; });
  V v_x1_24181 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_24179)));
  V v_t_24216;
  switch (heff_tag_of(v_x1_24181)) {
  case TAG_Nil: {
    heff_drop(v_program_24179);
    heff_drop(v_off_24180);
    v_t_24216 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24182 = heff_field(v_x1_24181, 0);
    V v_ru_24x1_24181_24Cons = heff_take_reuse_n(v_x1_24181, 1ULL, 2);
    V v_x1_24184 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_24179)));
    switch (heff_tag_of(v_x1_24184)) {
    case TAG_Nil: {
      heff_drop(v_program_24179);
      heff_drop(v_off_24180);
      heff_drop(v_x_24182);
      heff_drop_cell(v_ru_24x1_24181_24Cons, 2);
      v_t_24216 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Cons: {
      V v_x_24185 = heff_field(v_x1_24184, 0);
      V v_ru_24x1_24184_24Cons = heff_take_reuse_n(v_x1_24184, 1ULL, 2);
      V v_t_24187 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_x_24185, 4)));
      V v_t_24188 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_24187));
      V v_t_24189 = ({ V a_0 = v_program_24179; V a_1 = v_x_24185; V a_2 = v_t_24188; V a_3 = v_off_24180; V r_ = (g_heff_2ebuild_2equery_2etargetIn(a_0, a_1, a_2, a_3)); heff_drop(v_program_24179); r_; });
      switch (heff_tag_of(v_t_24189)) {
      case TAG_Nothing: {
        heff_drop(v_x_24182);
        heff_drop_cell(v_ru_24x1_24181_24Cons, 2);
        heff_drop_cell(v_ru_24x1_24184_24Cons, 2);
        v_t_24216 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_t_24190 = heff_field(v_t_24189, 0);
        heff_take_n(v_t_24189, 1ULL, 1);
        V v_target_24191 = heff_take_field(v_t_24190, 0);
        V v_name_24192 = heff_get_n(v_t_24190, 1, 2);
        V v_lit_24193 = v_x_24182;
        V v_t_24194 = v_target_24191;
        V v_name_24195 = v_name_24192;
        V v_t_24196 = heff_dup(heff_rfield(v_t_24194, 2));
        switch (heff_tag_of(v_t_24196)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x1_24181_24Cons, 2);
          heff_drop_cell(v_ru_24x1_24184_24Cons, 2);
          V v_t_24197 = (g_heff_2ebuild_2equery_2einFile(v_t_24194, v_name_24195, v_lit_24193));
          V v_z_24198 = (g_prelude_2e_2b_2b(v_t_24197, NTAG(TAG_Nil)));
          v_t_24216 = v_z_24198;
          break;
        }
        case TAG_Just: {
          V v_b_24199 = heff_field(v_t_24196, 0);
          heff_take_n(v_t_24196, 1ULL, 1);
          heff_drop(v_name_24195);
          if (heff_strEq_c(heff_dup(heff_rfield(v_lit_24193, 1)), heff_get_n(v_t_24194, 0, 3))) {
            V v_t_24200 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_lit_24193, 4)));
            V v_t_24201 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_24200));
            HeffT2 v_t_24202 = ({ V a_0 = heff_dup(v_b_24199); V b_1 = heff_get_n(v_t_24201, 0, 2); HeffT2 r_ = (g_list_2efind_24s343666469x451168509_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
            {
              V v_field_24204 = v_t_24202.f[1];
              int64_t v_tag_24203 = ((int64_t)v_t_24202.f[0]);
              if ((v_tag_24203 == ((int64_t)0ULL))) {
                V v_l_24205 = v_field_24204;
                V v_binder_24206 = heff_take_field(v_l_24205, 1);
                V v_uses_24207 = heff_get_n(v_l_24205, 2, 3);
                V v_x_24208 = v_binder_24206;
                V v_t_24214;
                switch (heff_tag_of(v_uses_24207)) {
                case TAG_Nil: {
                  heff_drop_cell(v_ru_24x1_24184_24Cons, 2);
                  V v_t_24209 = heff_tag_at_n(v_ru_24x1_24181_24Cons, TAG_Cons, 2, (V[]){v_x_24208, NTAG(TAG_Nil)});
                  v_t_24214 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24209, NTAG(TAG_Nil)});
                  break;
                }
                case TAG_Cons: {
                  V v_y_24210 = heff_field(v_uses_24207, 0);
                  V v_ys_24211 = heff_field(v_uses_24207, 1);
                  heff_take_n(v_uses_24207, 3ULL, 2);
                  if (heff_intLe_c(heff_dup(heff_rfield(v_x_24208, 0)), heff_dup(heff_rfield(v_y_24210, 0)))) {
                    V v_t_24212 = heff_tag_at_n(v_ru_24x1_24181_24Cons, TAG_Cons, 2, (V[]){v_x_24208, NTAG(TAG_Nil)});
                    v_t_24214 = (g_list_2eascending_24s1053575971x1138989897(heff_dup(v_y_24210), heff_tag_at_n(v_ru_24x1_24184_24Cons, TAG_Cons, 2, (V[]){v_y_24210, v_t_24212}), v_ys_24211));
                  } else {
                    V v_t_24213 = heff_tag_at_n(v_ru_24x1_24181_24Cons, TAG_Cons, 2, (V[]){v_x_24208, NTAG(TAG_Nil)});
                    v_t_24214 = (g_list_2edescending_24s136597790x1673774577(heff_dup(v_y_24210), heff_tag_at_n(v_ru_24x1_24184_24Cons, TAG_Cons, 2, (V[]){v_y_24210, v_t_24213}), v_ys_24211));
                  }
                  break;
                }
                default: heff_nomatch(v_uses_24207);
                }
                V v_t_24215 = (g_list_2emergeRuns_24s655705766x180835539(NTAG(TAG_Nil), v_t_24214));
                v_t_24216 = (g_list_2emap_24s1392650298x1192381411(v_b_24199, v_lit_24193, v_t_24215));
              } else {
                heff_drop_cell(v_ru_24x1_24181_24Cons, 2);
                heff_drop_cell(v_ru_24x1_24184_24Cons, 2);
                heff_drop_rec(v_lit_24193, 14);
                heff_drop(v_b_24199);
                heff_drop(v_field_24204);
                v_t_24216 = NTAG(TAG_Nil);
              }
            }
          } else {
            heff_drop_cell(v_ru_24x1_24181_24Cons, 2);
            heff_drop_cell(v_ru_24x1_24184_24Cons, 2);
            heff_drop_rec(v_lit_24193, 14);
            heff_drop(v_b_24199);
            v_t_24216 = NTAG(TAG_Nil);
          }
          break;
        }
        default: heff_nomatch(v_t_24196);
        }
        break;
      }
      default: heff_nomatch(v_t_24189);
      }
      break;
    }
    default: heff_nomatch(v_x1_24184);
    }
    break;
  }
  default: heff_nomatch(v_x1_24181);
  }
  V v_t_24217 = (g_list_2emap_24s328130413x305756849(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str88), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str89), MK_INT(1LL), v_t_24216));
  V v_result_24218 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24217});
  V v_t_24219 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str90), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str91), MK_INT(0LL)));
  V v_acc_24220 = heff_strAppend(heff_strAppend(v_t_24219, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str92)), ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str93));
  V v_t_24221 = (g_json_2equotedInto_2eescapeInto_241(((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str94), heff_strAppend(v_acc_24220, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str95)), MK_INT(0LL)));
  V v_t_24222 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str96), v_result_24218}), NTAG(TAG_Nil)});
  V v_t_24223 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str97), v_id_243}), v_t_24222});
  V v_t_24224 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str98); V a_1 = heff_strAppend(v_t_24221, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str99)); V a_2 = v_t_24223; V r_ = (g_json_2ejoinInto_2erestInto_240_24s585270905x1510312396(a_0, a_1, a_2)); heff_drop_tag(v_t_24223, 2); r_; });
  V v_a_24225 = heff_tag_n(TAG_Send, 2, (V[]){heff_strAppend(v_t_24224, ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str100)), NTAG(TAG_MkUnit)});
  V v_t_24226 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24225})});
  V v_t_24227 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24226})});
  V v_t_24228 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24227})});
  V v_t_24229 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24228})});
  V v_t_24230 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24229})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24230, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam11, 1, 2, (V[]){v_z_246, v_st_24178})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam13(V self, V *args) {
  V v_x_24255 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_24236 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24255);
  V f_ = v_z_246;
  args[0] = v_st_24236;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam12(V self, V *args) {
  V v_x_24233 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_program_24234 = heff_take_field(v_x_24233, 2);
  V v_text_24235 = heff_take_field(v_x_24233, 1);
  V v_st_24236 = heff_get_n(v_x_24233, 0, 3);
  V v_x1_24237 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24234));
  V v_t_24242;
  switch (heff_tag_of(v_x1_24237)) {
  case TAG_Nil: {
    heff_drop(v_p_244);
    heff_drop(v_text_24235);
    v_t_24242 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24238 = heff_field(v_x1_24237, 0);
    V v_ru_24x1_24237_24Cons = heff_take_reuse_n(v_x1_24237, 1ULL, 2);
    V v_t_24240 = ({ V a_0 = v_text_24235; V a_1 = v_p_244; V r_ = (g_heff_2elsp_2elsp_2eoffsetIn(a_0, a_1)); heff_drop(v_text_24235); r_; });
    V v_t_24241 = (g_heff_2ebuild_2equery_2ecompletionsAt(v_x_24238, v_t_24240));
    v_t_24242 = (g_list_2emap_24s4199228x1154005405_24tok2(v_ru_24x1_24237_24Cons, v_t_24241));
    break;
  }
  default: heff_nomatch(v_x1_24237);
  }
  V v_result_24243 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24242});
  V v_t_24244 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str102), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str103)})});
  V v_t_24245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str104), v_result_24243}), NTAG(TAG_Nil)});
  V v_t_24246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str105), v_id_243}), v_t_24245});
  V v_t_24247 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24244, v_t_24246})});
  V v_t_24248 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str106); V a_1 = v_t_24247; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24247, 1); r_; });
  V v_a_24249 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24248, NTAG(TAG_MkUnit)});
  V v_t_24250 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24249})});
  V v_t_24251 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24250})});
  V v_t_24252 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24251})});
  V v_t_24253 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24252})});
  V v_t_24254 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24253})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24254, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam13, 1, 2, (V[]){v_z_246, v_st_24236})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam15(V self, V *args) {
  V v_y_24265 = args[0];
  V v_text_24259 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elsp_2elsp_2edocSymbol(v_text_24259, v_y_24265));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam16(V self, V *args) {
  V v_x_24279 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_24260 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24279);
  V f_ = v_z_246;
  args[0] = v_st_24260;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam14(V self, V *args) {
  V v_x_24257 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_program_24258 = heff_take_field(v_x_24257, 2);
  V v_text_24259 = heff_take_field(v_x_24257, 1);
  V v_st_24260 = heff_get_n(v_x_24257, 0, 3);
  V v_x1_24261 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_24258));
  V v_t_24266;
  switch (heff_tag_of(v_x1_24261)) {
  case TAG_Nil: {
    heff_drop(v_text_24259);
    v_t_24266 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_x_24262 = heff_field(v_x1_24261, 0);
    V v_ru_24x1_24261_24Cons = heff_take_reuse_n(v_x1_24261, 1ULL, 2);
    V v_t_24264 = (g_heff_2ebuild_2equery_2esymbols(v_x_24262));
    v_t_24266 = (g_list_2emap_24tok2(v_ru_24x1_24261_24Cons, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam15, 1, 1, (V[]){v_text_24259}), v_t_24264));
    break;
  }
  default: heff_nomatch(v_x1_24261);
  }
  V v_result_24267 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24266});
  V v_t_24268 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str108), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str109)})});
  V v_t_24269 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str110), v_result_24267}), NTAG(TAG_Nil)});
  V v_t_24270 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str111), v_id_243}), v_t_24269});
  V v_t_24271 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24268, v_t_24270})});
  V v_t_24272 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str112); V a_1 = v_t_24271; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24271, 1); r_; });
  V v_a_24273 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24272, NTAG(TAG_MkUnit)});
  V v_t_24274 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24273})});
  V v_t_24275 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24274})});
  V v_t_24276 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24275})});
  V v_t_24277 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24276})});
  V v_t_24278 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24277})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24278, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam16, 1, 2, (V[]){v_z_246, v_st_24260})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam20(V self, V *args) {
  V v_x_24317 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_24287 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24317);
  V f_ = v_z_246;
  args[0] = v_st_24287;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam19(V self, V *args) {
  V v_x_24304 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_24287 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24305 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str123), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str124)})});
  V v_t_24306 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str125), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24304})});
  V v_t_24307 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24306, NTAG(TAG_Nil)});
  V v_t_24308 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str126), v_id_243}), v_t_24307});
  V v_t_24309 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24305, v_t_24308})});
  V v_t_24310 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str127); V a_1 = v_t_24309; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24309, 1); r_; });
  V v_a_24311 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24310, NTAG(TAG_MkUnit)});
  V v_t_24312 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24311})});
  V v_t_24313 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24312})});
  V v_t_24314 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24313})});
  V v_t_24315 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24314})});
  V v_t_24316 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24315})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24316, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam20, 1, 2, (V[]){v_z_246, v_st_24287})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam18(V self, V *args) {
  V v_x_24286 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_24287 = heff_take_field(v_x_24286, 0);
  V v_program_24288 = heff_get_n(v_x_24286, 1, 2);
  V v_t_24289 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str114), NTAG(TAG_Nil)});
  HeffT2 v_t_24290 = ({ V a_0 = v_t_24289; V a_1 = v_p_244; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_24289, 2); r_; });
  V v_t_24301;
  {
    V v_field_24292 = v_t_24290.f[1];
    int64_t v_tag_24291 = ((int64_t)v_t_24290.f[0]);
    V v_t_24300;
    if ((v_tag_24291 == ((int64_t)0ULL))) {
      V v_it1_24293 = v_field_24292;
      switch (heff_tag_of(v_it1_24293)) {
      case TAG_JNull: {
        v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str115);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24293, 0ULL, 1);
        v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str116);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24293, 0ULL, 1);
        v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str117);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24293, 0ULL, 1);
        v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str118);
        break;
      }
      case TAG_JString: {
        V v_s_24297 = heff_field(v_it1_24293, 0);
        heff_take_n(v_it1_24293, 1ULL, 1);
        v_t_24300 = v_s_24297;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24293, 0ULL, 1);
        v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str119);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24293, 0ULL, 1);
        v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str120);
        break;
      }
      default: heff_nomatch(v_it1_24293);
      }
    } else {
      heff_drop(v_field_24292);
      v_t_24300 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str121);
    }
    v_t_24301 = ({ V a_0 = v_t_24300; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str122); V r_ = (g_heff_2elsp_2elsp_2elowerGo(a_0, a_1, a_2)); heff_drop(v_t_24300); r_; });
  }
  V v_t_24302 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24288));
  V v_c_24303 = ({ V a_0 = heff_dup(v_e_240); V a_1 = heff_dup(v_st_24287); V a_2 = v_t_24301; V a_3 = v_t_24302; V r_ = (g_heff_2elsp_2elsp_2esymbolsJson_24s1011824396x901870900(a_0, a_1, a_2, a_3)); heff_drop(v_t_24301); heff_drop(v_t_24302); r_; });
  V f_ = v_c_24303;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam19, 1, 5, (V[]){v_id_243, v_e_240, v_z_245, v_z_246, v_st_24287});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam17(V self, V *args) {
  V v_x_24283 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24284 = (g_heff_2elsp_2elsp_2enubRoots(v_x_24283));
  V v_c_24285 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_st_241; V a_2 = v_t_24284; V r_ = (g_heff_2elsp_2elsp_2eprojects_24s1707000738x2010893958(a_0, a_1, a_2)); heff_drop(v_t_24284); r_; });
  V f_ = v_c_24285;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam18, 1, 5, (V[]){v_p_244, v_e_240, v_z_245, v_id_243, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam22(V self, V *args) {
  V v_o_24335 = args[0];
  V v_p_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24336 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str134), NTAG(TAG_Nil)});
  HeffT2 v_t_24337 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str135), v_t_24336}); V a_1 = v_p_244; HeffT2 r_ = (g_json_2eat_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_24347;
  {
    V v_field_24339 = v_t_24337.f[1];
    int64_t v_tag_24338 = ((int64_t)v_t_24337.f[0]);
    if ((v_tag_24338 == ((int64_t)0ULL))) {
      V v_it1_24340 = v_field_24339;
      switch (heff_tag_of(v_it1_24340)) {
      case TAG_JNull: {
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      case TAG_JBool: {
        V v_b_24341 = heff_field(v_it1_24340, 0);
        heff_take_n(v_it1_24340, 1ULL, 1);
        v_t_24347 = v_b_24341;
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24340, 0ULL, 1);
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24340, 0ULL, 1);
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_24340, 0ULL, 1);
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24340, 0ULL, 1);
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24340, 0ULL, 1);
        v_t_24347 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_it1_24340);
      }
    } else {
      heff_drop(v_field_24339);
      v_t_24347 = NTAG(TAG_True);
    }
  }
  V v_ret_24bool = heff_bool(((heff_dup(v_t_24347) == NTAG(TAG_True)) || !(heff_dup(heff_rfield(v_o_24335, 3)) == NTAG(TAG_True))));
  heff_drop_rec(v_o_24335, 4);
  heff_drop(v_t_24347);
  return v_ret_24bool;
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam24(V self, V *args) {
  V v_x_24352 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_24350 = heff_env(self)[2];
  V v_k_24351 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24353 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str136), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str137)})});
  V v_t_24354 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str138), heff_tag_n(TAG_JArray, 1, (V[]){v_x_24352})});
  V v_t_24355 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24354, NTAG(TAG_Nil)});
  V v_t_24356 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str139), v_id_243}), v_t_24355});
  V v_t_24357 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24353, v_t_24356})});
  V v_t_24358 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str140); V a_1 = v_t_24357; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24357, 1); r_; });
  V v_a_24359 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24358, NTAG(TAG_MkUnit)});
  V v_t_24360 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24359})});
  V v_t_24361 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24360})});
  V v_t_24362 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24361})});
  V v_t_24363 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24362})});
  V v_t_24364 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24363})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24364, v_hd_24350, v_k_24351));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam23(V self, V *args) {
  V v_hd_24350 = args[0];
  V v_k_24351 = args[1];
  V v_c_24349 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24349;
  args[0] = heff_dup(v_hd_24350);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam24, 1, 4, (V[]){v_id_243, v_e_240, v_hd_24350, v_k_24351});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam25(V self, V *args) {
  V v_x_24366 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_24321 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24366);
  V f_ = v_z_246;
  args[0] = v_st_24321;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam21(V self, V *args) {
  V v_x_24319 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_target_24320 = heff_take_field(v_x_24319, 2);
  V v_st_24321 = heff_get_n(v_x_24319, 0, 3);
  V v_c_24365;
  switch (heff_tag_of(v_target_24320)) {
  case TAG_Nothing: {
    heff_drop(v_p_244);
    V v_t_24322 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str129), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str130)})});
    V v_t_24323 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str131), NTAG(TAG_JNull)});
    V v_t_24324 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24323, NTAG(TAG_Nil)});
    V v_t_24325 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str132), v_id_243}), v_t_24324});
    V v_t_24326 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24322, v_t_24325})});
    V v_t_24327 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str133); V a_1 = v_t_24326; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24326, 1); r_; });
    V v_a_24328 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24327, NTAG(TAG_MkUnit)});
    V v_t_24329 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24328})});
    V v_t_24330 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24329})});
    V v_t_24331 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24330})});
    V v_t_24332 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24331})});
    V v_t_24333 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24332})});
    v_c_24365 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){v_e_240, v_t_24333}));
    break;
  }
  case TAG_Just: {
    V v_t_24334 = heff_field(v_target_24320, 0);
    heff_take_n(v_target_24320, 1ULL, 1);
    V v_t_24348 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam22, 1, 1, (V[]){v_p_244}), heff_get_n(v_t_24334, 3, 4)));
    V v_c_24349 = (g_heff_2elsp_2elsp_2elocations_24s1274802749x411269734(heff_dup(v_e_240), heff_dup(v_st_24321), v_t_24348));
    v_c_24365 = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam23, 2, 3, (V[]){v_c_24349, v_id_243, v_e_240});
    break;
  }
  default: heff_nomatch(v_target_24320);
  }
  V f_ = v_c_24365;
  heff_room[0] = v_z_245;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam25, 1, 2, (V[]){v_z_246, v_st_24321});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam26(V self, V *args) {
  V v_x_24368 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2elsp_2elsp_2eprepared_24s651611443x1633097084(v_e_240, v_id_243, v_x_24368, v_z_245, v_z_246));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam27(V self, V *args) {
  V v_x_24370 = args[0];
  V v_p_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_id_243 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24371 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str143), NTAG(TAG_Nil)});
  HeffT2 v_t_24372 = ({ V a_0 = v_t_24371; V a_1 = v_p_244; HeffT2 r_ = (g_json_2eat_24cpr(a_0, a_1)); heff_drop_tag(v_t_24371, 2); r_; });
  V v_t_24382;
  {
    V v_field_24374 = v_t_24372.f[1];
    int64_t v_tag_24373 = ((int64_t)v_t_24372.f[0]);
    if ((v_tag_24373 == ((int64_t)0ULL))) {
      V v_it1_24375 = v_field_24374;
      switch (heff_tag_of(v_it1_24375)) {
      case TAG_JNull: {
        v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str144);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_24375, 0ULL, 1);
        v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str145);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_24375, 0ULL, 1);
        v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str146);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_24375, 0ULL, 1);
        v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str147);
        break;
      }
      case TAG_JString: {
        V v_s_24379 = heff_field(v_it1_24375, 0);
        heff_take_n(v_it1_24375, 1ULL, 1);
        v_t_24382 = v_s_24379;
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_24375, 0ULL, 1);
        v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str148);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_24375, 0ULL, 1);
        v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str149);
        break;
      }
      default: heff_nomatch(v_it1_24375);
      }
    } else {
      heff_drop(v_field_24374);
      v_t_24382 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str150);
    }
  }
  return (g_heff_2elsp_2elsp_2erenamed_24s1722283860x916421341(v_e_240, v_id_243, v_t_24382, v_x_24370, v_z_245, v_z_246));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam31(V self, V *args) {
  V v_x_24403 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_x_24385 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24403);
  V f_ = v_z_246;
  args[0] = heff_get_n(v_x_24385, 0, 3);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam30(V self, V *args) {
  V v_x_24389 = args[0];
  V v_x_24387 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_x_24385 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_24390 = (g_prelude_2e_2b_2b(v_x_24389, v_x_24387));
  V v_result_24391 = heff_tag_n(TAG_JArray, 1, (V[]){v_t_24390});
  V v_t_24392 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str153), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str154)})});
  V v_t_24393 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str155), v_result_24391}), NTAG(TAG_Nil)});
  V v_t_24394 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str156), v_id_243}), v_t_24393});
  V v_t_24395 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24392, v_t_24394})});
  V v_t_24396 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str157); V a_1 = v_t_24395; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24395, 1); r_; });
  V v_a_24397 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24396, NTAG(TAG_MkUnit)});
  V v_t_24398 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24397})});
  V v_t_24399 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24398})});
  V v_t_24400 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24399})});
  V v_t_24401 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24400})});
  V v_t_24402 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24401})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24402, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam31, 1, 2, (V[]){v_z_246, v_x_24385})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam29(V self, V *args) {
  V v_x_24387 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_24385 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_id_243 = heff_env(self)[4];
  V v_z_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_24388 = (g_heff_2elsp_2elsp_2eclaimFixes_24s2013969339x2062276950(heff_dup(v_e_240), heff_dup(heff_rfield(v_x_24385, 0)), v_p_244));
  V f_ = v_c_24388;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam30, 1, 6, (V[]){v_x_24387, v_id_243, v_e_240, v_z_245, v_z_246, v_x_24385});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam28(V self, V *args) {
  V v_x_24385 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_id_243 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_24386 = (g_heff_2elsp_2elsp_2ecodeActions_24s265826942x386408558(heff_dup(v_e_240), heff_dup(v_x_24385), heff_dup(v_p_244)));
  V f_ = v_c_24386;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam29, 1, 6, (V[]){v_e_240, v_x_24385, v_p_244, v_z_245, v_id_243, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam33(V self, V *args) {
  V v_x_24418 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24418);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam35(V self, V *args) {
  V v_x_24435 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24435);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam34(V self, V *args) {
  V v_x_24421 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24422 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str164), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str165)})});
  V v_t_24424;
  switch (heff_tag_of(v_x_24421)) {
  case TAG_Nothing: {
    v_t_24424 = NTAG(TAG_JNull);
    break;
  }
  case TAG_Just: {
    V v_n_24423 = heff_field(v_x_24421, 0);
    V v_ru_24x_24421_24Just = heff_take_reuse_n(v_x_24421, 1ULL, 1);
    v_t_24424 = heff_tag_at_n(v_ru_24x_24421_24Just, TAG_JString, 1, (V[]){v_n_24423});
    break;
  }
  default: heff_nomatch(v_x_24421);
  }
  V v_t_24425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str166), v_t_24424}), NTAG(TAG_Nil)});
  V v_t_24426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str167), v_id_243}), v_t_24425});
  V v_t_24427 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24422, v_t_24426})});
  V v_t_24428 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str168); V a_1 = v_t_24427; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24427, 1); r_; });
  V v_a_24429 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24428, NTAG(TAG_MkUnit)});
  V v_t_24430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24429})});
  V v_t_24431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24430})});
  V v_t_24432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24431})});
  V v_t_24433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24432})});
  V v_t_24434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24433})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24434, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam35, 1, 2, (V[]){v_z_246, v_st_241})));
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam32(V self, V *args) {
  V v_x_24405 = args[0];
  V v_id_243 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_24405)) {
  case TAG_Nothing: {
    V v_t_24406 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str159), heff_tag_n(TAG_JString, 1, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str160)})});
    V v_t_24407 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str161), NTAG(TAG_JNull)});
    V v_t_24408 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24407, NTAG(TAG_Nil)});
    V v_t_24409 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str162), v_id_243}), v_t_24408});
    V v_t_24410 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_24406, v_t_24409})});
    V v_t_24411 = ({ V a_0 = ((V)&g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_str163); V a_1 = v_t_24410; V r_ = (g_json_2estringify_2ewriteInto_240(a_0, a_1)); heff_drop_tag(v_t_24410, 1); r_; });
    V v_a_24412 = heff_tag_n(TAG_Send, 2, (V[]){v_t_24411, NTAG(TAG_MkUnit)});
    V v_t_24413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24412})});
    V v_t_24414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24413})});
    V v_t_24415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24414})});
    V v_t_24416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24415})});
    V v_t_24417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24416})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_24417, v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam33, 1, 2, (V[]){v_z_246, v_st_241})));
  }
  case TAG_Just: {
    V v_f_24419 = heff_field(v_x_24405, 0);
    heff_take_n(v_x_24405, 1ULL, 1);
    V v_c_24420 = (g_heff_2elsp_2elsp_2eclaimOf_24s15166512x1460547843(heff_dup(v_e_240), heff_dup(v_st_241), v_f_24419));
    V f_ = v_c_24420;
    heff_room[0] = heff_dup(v_z_245);
    heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam34, 1, 5, (V[]){v_id_243, v_e_240, v_z_245, v_z_246, v_st_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24405);
  }
}
V g_heff_2elsp_2elsp_2erequest_24s473494387x1457883282_lam36(V self, V *args) {
  V v_x_24437 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24437);
  V f_ = v_z_246;
  args[0] = v_st_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam0(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam0, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam5(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam5, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam8(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam8, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam11(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam12(V self, V *args); static Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam12, 1, 0};
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam10(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_entry, 4, 0};

V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(V v_e_240, V v_st_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam1, 1, 4, (V[]){v_st_241, v_e_240, v_hd_242, v_k_243}));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam0(V self, V *args) {
  V v_n_244 = args[0];
  return v_n_244;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam4(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2ehandle_24s99238182x2018879301(v_e_240, v_st_241, v_msg_2420, v_hd_2422, v_k_2423));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam5(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam3(V self, V *args) {
  V v_use_2421 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2421;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam4, 2, 3, (V[]){v_e_240, v_st_241, v_msg_2420});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam5_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam7(V self, V *args) {
  V v_x_2432 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(v_e_240, v_x_2432, v_hd_242, v_k_243));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam6(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_msg_2420 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2431 = (g_heff_2elsp_2elsp_2ehandled_24s2116096330x1417917199(heff_dup(v_e_240), v_st_241, v_msg_2420, v_x_2430));
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam7, 1, 3, (V[]){v_e_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam8(V self, V *args) {
  V v_n_2433 = args[0];
  return v_n_2433;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam11(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_st_241 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2443 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_2444 = (g_list_2ekeepIf_24s1201185697x960477413(v_x_2439, v_t_2443));
  V v_t_2445 = (g_list_2emap_24s1415906091x1371825187(v_t_2444));
  return ({ V a_0 = v_e_240; V a_1 = v_st_241; V a_2 = v_t_2445; V a_3 = v_hd_2441; V a_4 = v_k_2442; V r_ = (g_heff_2elsp_2elsp_2echeckDue_24s334706138x2123592139(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2445); r_; });
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam12(V self, V *args) {
  V v_r_2446 = args[0];
  return v_r_2446;
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam10(V self, V *args) {
  V v_use_2440 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_use_2440;
  heff_room[0] = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam11, 2, 3, (V[]){v_st_241, v_x_2439, v_e_240});
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam12_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam13(V self, V *args) {
  V v_x_2452 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_x_2439 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2453 = heff_dup(v_st_241);
  V v_t_2454 = ({ V b_0 = heff_get_n(v_st_241, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2455 = (g_list_2ekeepIf_24s1201185697x960477413(v_x_2439, v_t_2454));
  V v_fs_2456 = (g_list_2emap_24s1415906091x1371825187(v_t_2455));
  V v_x3_2457 = v_x_2452;
  V v_t_2465;
  switch (heff_tag_of(v_x3_2457)) {
  case TAG_Left: {
    heff_take_n(v_x3_2457, 0ULL, 1);
    V v_t_2459 = ({ V a_0 = heff_take_field(v_st_2453, 2); V a_1 = v_fs_2456; V r_ = (g_heff_2elsp_2elsp_2eundue(a_0, a_1)); heff_drop(v_fs_2456); r_; });
    V v_project_2460 = heff_take_field(v_st_2453, 3);
    V v_watch_2461 = heff_take_field(v_st_2453, 4);
    V v_shutdown_2462 = heff_take_field(v_st_2453, 5);
    V v_lib_2463 = heff_take_field(v_st_2453, 6);
    v_t_2465 = ({ V rv_2 = v_t_2459; V rv_3 = v_project_2460; V rv_4 = v_watch_2461; V rv_5 = v_shutdown_2462; V rv_6 = v_lib_2463; V rr_ = heff_rec_reuse_nf(v_st_2453, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
    break;
  }
  case TAG_Right: {
    V v_st2_2464 = heff_field(v_x3_2457, 0);
    heff_take_n(v_x3_2457, 1ULL, 1);
    heff_drop_rec(v_st_2453, 7);
    heff_drop(v_fs_2456);
    v_t_2465 = v_st2_2464;
    break;
  }
  default: heff_nomatch(v_x3_2457);
  }
  return (g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998(v_e_240, v_t_2465, v_hd_242, v_k_243));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam9(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam10, 1, 3, (V[]){heff_dup(v_st_241), heff_dup(v_x_2439), heff_dup(v_e_240)})})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), heff_dup(v_hd_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam13, 1, 5, (V[]){v_st_241, v_x_2439, v_e_240, v_hd_242, v_k_243})));
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Message: {
    V v_msg_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Message = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_t_2425 = heff_tag_at_n(v_ru_24x_2419_24Message, TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam3, 1, 3, (V[]){heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_msg_2420)})})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam6, 1, 5, (V[]){v_e_240, v_st_241, v_msg_2420, v_hd_242, v_k_243})));
  }
  case TAG_Timeout: {
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Now, 1, (V[]){((V)&g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam8_clo)})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_hd_242), heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam9, 1, 4, (V[]){v_st_241, v_e_240, v_hd_242, v_k_243})));
  }
  case TAG_Closed: {
    heff_drop_rec(v_st_241, 7);
    V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Quit, 1, (V[]){MK_INT(1LL)})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2470}), v_hd_242, v_k_243));
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = (g_std_2eordmap_2etoList_2etoListOnto_240(heff_rfield(v_st_241, 2), NTAG(TAG_Nil)));
  V v_t_2412 = (g_list_2emap_24s366344330x1145113647(v_t_2411));
  V v_t_2418;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nil: {
    heff_drop(v_x_2410);
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_d_2413 = heff_field(v_t_2412, 0);
    V v_ds_2414 = heff_field(v_t_2412, 1);
    heff_take_n(v_t_2412, 3ULL, 2);
    V v_t_2415 = ({ V a_0 = v_d_2413; V a_1 = v_ds_2414; V r_ = (g_list_2efoldl_24s1096141254x104586789(a_0, a_1)); heff_drop(v_ds_2414); r_; });
    V v_y_2416 = heff_intSub(v_t_2415, v_x_2410);
    V v_t_2417;
    if (heff_intLe_c_lent(MK_INT(0LL), v_y_2416, 1)) {
      v_t_2417 = v_y_2416;
    } else {
      heff_drop(v_y_2416);
      v_t_2417 = MK_INT(0LL);
    }
    v_t_2418 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2417});
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  return ({ V a_0 = heff_dup(v_e_240); V a_1 = v_t_2418; V a_2 = heff_dup(v_hd_242); V a_3 = heff_clo_n(g_heff_2elsp_2elsp_2eserveFrom_24s1776041695x1608492998_lam2, 1, 4, (V[]){v_e_240, v_st_241, v_hd_242, v_k_243}); V r_ = (g_heff_2elsp_2erpc_2eawait_24s45816022x200024774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2418); r_; });
}