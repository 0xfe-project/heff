// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Attempt 14217
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Throw 56084
#define LBL_analysis 1868176469
#define LBL_at 9882
#define LBL_bind 9519364
#define LBL_checked 974171621
#define LBL_current 1358797751
#define LBL_cut 308412
#define LBL_deps 9575179
#define LBL_docs 9584386
#define LBL_due 309358
#define LBL_kept 9783717
#define LBL_lib 316671
#define LBL_local 304503685
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_occurrences 673885394
#define LBL_off 319465
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_project 2070030684
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_shutdown 575795380
#define LBL_source 1050636102
#define LBL_st 10440
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_watch 314261737
static uint32_t shape_analysis__at[] = {LBL_analysis, LBL_at};
static uint32_t shape_docs__checked__due__project__watch__shutdown__lib[] = {LBL_docs, LBL_checked, LBL_due, LBL_project, LBL_watch, LBL_shutdown, LBL_lib};
static uint32_t shape_path__occurrences[] = {LBL_path, LBL_occurrences};
static uint32_t shape_path__target__name__occurrences[] = {LBL_path, LBL_target, LBL_name, LBL_occurrences};
static uint32_t shape_root__names__program__current__kept[] = {LBL_root, LBL_names, LBL_program, LBL_current, LBL_kept};
static uint32_t shape_st__off__target[] = {LBL_st, LBL_off, LBL_target};
static uint32_t shape_st__program[] = {LBL_st, LBL_program};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2elsp_2elsp_2eaffectedGo(V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_clo;
V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V, V, V, V);
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo;
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372_clo;
V g_heff_2elsp_2elsp_2edeclsGo(V, V, V);
V g_heff_2elsp_2elsp_2edeclsGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2edeclsGo_clo;
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427_clo;
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265(V, V, V, V);
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_clo;
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562(V, V, V);
V g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562_clo;
V g_heff_2elsp_2elsp_2elinesFrom(V, V);
V g_heff_2elsp_2elsp_2elinesFrom_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2elinesFrom_clo;
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968(V, V, V, V, V);
V g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968_clo;
V g_heff_2elsp_2elsp_2enubCheckedPaths(V);
V g_heff_2elsp_2elsp_2enubCheckedPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubCheckedPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths(V);
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_clo;
V g_heff_2elsp_2elsp_2enubPaths_24dps(V, V);
V g_heff_2elsp_2elsp_2enubPaths_24dps_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2enubPaths_24dps_clo;
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_clo;
V g_heff_2elsp_2elsp_2eposition(V, V);
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eposition_clo;
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(V, V, V);
V g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417_clo;
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894(V, V, V);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_clo;
V g_heff_2elsp_2elsp_2erenamedTarget(V, V);
V g_heff_2elsp_2elsp_2erenamedTarget_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erenamedTarget_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161(V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_clo;
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(V, V, V, V);
V g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1_clo;
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223_clo;
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538(V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_clo;
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872(V, V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872_clo;
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(V, V, V, V, V, V, V);
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_clo;
V g_heff_2elsp_2elsp_2eunits16Go(V, V, V, V);
V g_heff_2elsp_2elsp_2eunits16Go_entry(V self, V *a);
extern Clo g_heff_2elsp_2elsp_2eunits16Go_clo;
HeffT3 g_heff_2elsp_2erender_2elineColAt_24cpr(V, V, V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24s1807954837x1305454787_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s198101905x967505038(V, V, V, V);
V g_list_2efoldl_24s198101905x967505038_entry(V self, V *a);
extern Clo g_list_2efoldl_24s198101905x967505038_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s304198972x561714839(V, V);
V g_list_2ekeepIf_24s304198972x561714839_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s304198972x561714839_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s582709368x2113456071(V);
V g_list_2emap_24s582709368x2113456071_entry(V self, V *a);
extern Clo g_list_2emap_24s582709368x2113456071_clo;
V g_list_2emap_24s831190316x576961335(V);
V g_list_2emap_24s831190316x576961335_entry(V self, V *a);
extern Clo g_list_2emap_24s831190316x576961335_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str0, 1, "\012");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str1, 4, "line");
HEFF_LIT(g_heff_2elsp_2elsp_2eposition_str2, 9, "character");
Clo g_heff_2elsp_2elsp_2eposition_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eposition_entry, 2, 0};

V g_heff_2elsp_2elsp_2eposition(V v_src_240, V v_i_241) {
top: ;
  V v_x_242 = heff_strLength_lent(v_src_240, 0);
  V v_y_243;
  if (heff_intLe_c_lent(v_x_242, v_i_241, 0)) {
    v_y_243 = v_x_242;
  } else {
    heff_drop(v_x_242);
    v_y_243 = heff_dup(v_i_241);
  }
  V v_i_244;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_243, 1)) {
    v_i_244 = v_y_243;
  } else {
    heff_drop(v_y_243);
    v_i_244 = MK_INT(0LL);
  }
  V v_x_245 = heff_strLength_lent(v_src_240, 0);
  V v_y_246;
  if (heff_intLe_c_lent(v_x_245, v_i_241, 0)) {
    heff_drop(v_i_241);
    v_y_246 = v_x_245;
  } else {
    heff_drop(v_x_245);
    v_y_246 = v_i_241;
  }
  V v_t_247;
  if (heff_intLe_c_lent(MK_INT(0LL), v_y_246, 1)) {
    v_t_247 = v_y_246;
  } else {
    heff_drop(v_y_246);
    v_t_247 = MK_INT(0LL);
  }
  V v_j_248 = heff_strFind_lent(((V)&g_heff_2elsp_2elsp_2eposition_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_248, MK_INT(0LL), 2)) {
    heff_drop(v_j_248);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_248});
  }
  HeffT3 v_t_2410 = (g_heff_2elsp_2erender_2elineColAt_24cpr(v_src_240, v_t_247, MK_INT(0LL), MK_INT(0LL), v_t_249));
  {
    V v_field_2411 = v_t_2410.f[0];
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[2]);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str1), heff_tag_n(TAG_JInt, 1, (V[]){v_field_2411})});
    V v_t_2415 = (g_heff_2elsp_2elsp_2eunits16Go(v_src_240, heff_intSub(heff_dup(v_i_244), v_field_2412), v_i_244, MK_INT(0LL)));
    V v_t_2416 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2elsp_2elsp_2eposition_str2), heff_tag_n(TAG_JInt, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, v_t_2417})});
  }
}
V g_heff_2elsp_2elsp_2eposition_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eposition(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2elsp_2elsp_2enubPaths_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2enubPaths_entry, 1, 0};

V g_heff_2elsp_2elsp_2enubPaths(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2elsp_2elsp_2enubPaths_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2elsp_2elsp_2enubPaths_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2enubPaths(a[0]);
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2eaffectedGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry, 4, 0};

V g_heff_2elsp_2elsp_2eaffectedGo_24dps(V v_changed_240, V v_mods_241, V v_x3_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_mods_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_path_246 = heff_take_field(v_c_244, 1);
    V v_module_247 = heff_take_field(v_c_244, 0);
    V v_deps_248 = heff_get_n(v_c_244, 8, 14);
    V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_path_246)}));
    V v_t_2410 = (g_list_2eany(v_t_249, v_changed_240));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_deps_248);
      heff_drop(v_t_2410);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_246, heff_hole()});
      V v_u_2412 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2411));
      heff_drop(v_u_2412);
      V t_0 = v_changed_240;
      V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_247, v_mods_241});
      V t_2 = v_rest_245;
      V t_3 = v_cell_2411;
      v_changed_240 = t_0;
      v_mods_241 = t_1;
      v_x3_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_2410);
      V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0, 1, 1, (V[]){heff_dup(v_mods_241)}); V a_1 = v_deps_248; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_deps_248); r_; });
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        V v_cell_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_path_246, heff_hole()});
        V v_u_2417 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2416));
        heff_drop(v_u_2417);
        V t_0 = v_changed_240;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_module_247, v_mods_241});
        V t_2 = v_rest_245;
        V t_3 = v_cell_2416;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_path_246);
        heff_drop(v_module_247);
        heff_drop(v_t_2415);
        V t_0 = v_changed_240;
        V t_1 = v_mods_241;
        V t_2 = v_rest_245;
        V t_3 = v_d_243;
        v_changed_240 = t_0;
        v_mods_241 = t_1;
        v_x3_242 = t_2;
        v_d_243 = t_3;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2elsp_2elsp_2eaffectedGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2elsp_2elsp_2eaffectedGo_24dps_lam0(V self, V *args) {
  V v_d_2413 = args[0];
  V v_mods_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_d_2413}));
  return ({ V a_0 = v_t_2414; V a_1 = v_mods_241; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_mods_241); r_; });
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam3(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam3, 1, 0};
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_entry, 7, 0};

V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(V v_st_240, V v_f_241, V v_d_242, V v_ds_243, V v_lo_244, V v_hi_245, V v_a_246) {
top: ;
  if (heff_intLe_c(heff_intSub(heff_dup(v_hi_245), heff_dup(v_lo_244)), MK_INT(1LL))) {
    heff_drop(v_st_240);
    heff_drop(v_f_241);
    heff_drop_rec(v_d_242, 2);
    heff_drop(v_hi_245);
    HeffT3 v_t_247 = (g_list_2edrop_24cpr(v_lo_244, v_ds_243));
    {
      V v_field_249 = v_t_247.f[1];
      V v_field_2410 = v_t_247.f[2];
      V v_tag_248 = heff_box_i64(((int64_t)v_t_247.f[0]));
      return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam0, 2, 4, (V[]){v_tag_248, v_field_249, v_field_2410, v_a_246});
    }
  } else {
    return heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam1, 2, 7, (V[]){v_lo_244, v_hi_245, heff_dup(v_ds_243), v_d_242, v_st_240, v_f_241, v_a_246});
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_tag_248 = heff_env(self)[0];
  V v_field_249 = heff_env(self)[1];
  V v_field_2410 = heff_env(self)[2];
  V v_a_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_hd_2411);
  V v_t_2415;
  if ((heff_unbox_i64(v_tag_248) == ((int64_t)0ULL))) {
    V v_x_2413 = v_field_249;
    V v_x12_2414 = v_field_2410;
    heff_drop(v_x12_2414);
    v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2413});
  } else {
    heff_drop(v_field_249);
    heff_drop(v_field_2410);
    v_t_2415 = NTAG(TAG_Nothing);
  }
  V f_ = v_k_2412;
  args[0] = heff_rec_n(2, shape_analysis__at, (V[]){v_a_246, v_t_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam3(V self, V *args) {
  V v_r_2429 = args[0];
  return v_r_2429;
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam2(V self, V *args) {
  V v_use_2418 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_lo_244 = heff_env(self)[1];
  V v_hi_245 = heff_env(self)[2];
  V v_ds_243 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_st_240 = heff_env(self)[5];
  V v_f_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_k_2419 = heff_dup(heff_rfield(v_hd_2416, 0));
  V v_t_2420 = heff_intDiv(heff_intAdd(v_lo_244, v_hi_245), MK_INT(2LL));
  HeffT3 v_t_2421 = ({ V a_0 = v_t_2420; V a_1 = v_ds_243; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_243); r_; });
  V v_t_2427;
  {
    V v_field_2423 = v_t_2421.f[1];
    V v_field_2424 = v_t_2421.f[2];
    int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
    if ((v_tag_2422 == ((int64_t)0ULL))) {
      V v_x_2425 = v_field_2423;
      V v_x12_2426 = v_field_2424;
      heff_drop(v_x12_2426);
      v_t_2427 = heff_get_n(v_x_2425, 0, 2);
    } else {
      heff_drop(v_field_2423);
      heff_drop(v_field_2424);
      v_t_2427 = heff_strLength(heff_dup(heff_rfield(v_d_242, 1)));
    }
  }
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_t_2427; V a_4 = v_hd_2416; V a_5 = v_k_2419; V r_ = heff_tr(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2427); r_; });
  V f_ = v_use_2418;
  heff_room[0] = v_t_2428;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam3_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_lo_244 = heff_env(self)[0];
  V v_hi_245 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_ds_243 = heff_env(self)[5];
  V v_a_246 = heff_env(self)[6];
  V v_hd_2416 = heff_env(self)[7];
  V v_k_2417 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    heff_take_n(v_x_2436, 0ULL, 1);
    V v_t_2438 = heff_intDiv(heff_intAdd(heff_dup(v_lo_244), v_hi_245), MK_INT(2LL));
    V v_t_2439 = ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_ds_243; V a_4 = v_lo_244; V a_5 = v_t_2438; V a_6 = v_a_246; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_ds_243); r_; });
    V f_ = v_t_2439;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    heff_drop(v_a_246);
    V v_t_2441 = heff_intDiv(heff_intAdd(v_lo_244, heff_dup(v_hi_245)), MK_INT(2LL));
    V v_t_2442 = ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_ds_243; V a_4 = v_t_2441; V a_5 = v_hi_245; V a_6 = v_y_2440; V r_ = (g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_ds_243); r_; });
    V f_ = v_t_2442;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_lo_244 = heff_env(self)[0];
  V v_hi_245 = heff_env(self)[1];
  V v_ds_243 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_f_241 = heff_env(self)[5];
  V v_a_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam2, 1, 7, (V[]){heff_dup(v_hd_2416), heff_dup(v_lo_244), heff_dup(v_hi_245), heff_dup(v_ds_243), heff_dup(v_d_242), heff_dup(v_st_240), heff_dup(v_f_241)})})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
  V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
  args[0] = v_t_2435;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2estoppedGo_24s1129001331x7494177_lam4, 1, 9, (V[]){v_lo_244, v_hi_245, v_st_240, v_f_241, v_d_242, v_ds_243, v_a_246, v_hd_2416, v_k_2417});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_str1, 0, "");
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam1(V self, V *args); static Clo g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam1, 1, 0};
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam2(V self, V *args);
Clo g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_entry, 6, 0};

V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538(V v_st_240, V v_f_241, V v_d_242, V v_why_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam0, 1, 4, (V[]){heff_dup(v_hd_244), heff_dup(v_d_242), heff_dup(v_st_240), heff_dup(v_f_241)})})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_2425, heff_clo_n(g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam2, 1, 6, (V[]){v_d_242, v_st_240, v_f_241, v_why_243, v_hd_244, v_k_245})});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam1(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam0(V self, V *args) {
  V v_use_246 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_k_247 = heff_dup(heff_rfield(v_hd_244, 0));
  V v_src_248 = heff_dup(heff_rfield(v_d_242, 1));
  V v_t_249 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_242, 1), MK_INT(0LL)));
  V v_ds_2410 = ({ V a_0 = v_t_249; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_str0); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  HeffT3 v_t_2411 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ds_2410; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_ds_2410); r_; });
  V v_t_2417;
  {
    V v_field_2413 = v_t_2411.f[1];
    V v_field_2414 = v_t_2411.f[2];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      heff_drop(v_src_248);
      V v_x_2415 = v_field_2413;
      V v_x12_2416 = v_field_2414;
      heff_drop(v_x12_2416);
      v_t_2417 = heff_get_n(v_x_2415, 0, 2);
    } else {
      heff_drop(v_field_2413);
      heff_drop(v_field_2414);
      v_t_2417 = heff_strLength(v_src_248);
    }
  }
  V v_t_2418 = ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_t_2417; V a_4 = v_hd_244; V a_5 = v_k_247; V r_ = heff_tr(g_heff_2elsp_2elsp_2eanalysedUpTo_24s897874363x1114805372(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2417); r_; });
  V f_ = v_use_246;
  heff_room[0] = v_t_2418;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam1_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_why_243 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2427 = (g_heff_2elsp_2elsp_2elinesFrom(heff_rfield(v_d_242, 1), MK_INT(0LL)));
  V v_t_2428 = ({ V a_0 = v_t_2427; V b_1 = ((V)&g_heff_2elsp_2elsp_2estoppedAt_24s1342565053x250171538_str1); V a_2 = NTAG(TAG_Nothing); V r_ = (g_heff_2elsp_2elsp_2edeclsGo(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  return ({ V a_0 = v_st_240; V a_1 = v_f_241; V a_2 = v_d_242; V a_3 = v_why_243; V a_4 = v_t_2428; V a_5 = v_x_2426; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2elsp_2elsp_2estoppedFrom_24s676731730x1459630872(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_t_2428); heff_drop(v_x_2426); r_; });
}
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str1, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str2, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str3, 36, "` would make heff fail elaborating (");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str4, 1, ")");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str5, 10, "renaming `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str6, 6, "` to `");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str7, 13, "` would make ");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str8, 14, " more error(s)");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str9, 1, "`");
HEFF_LIT(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str10, 60, "` is already a name some of these occurrences would refer to");
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam3(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam6(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam7(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam8(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam9(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam10(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam10, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam12(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam11(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam11, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam14(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam13(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam5(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam15(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam16(V self, V *args); static Clo g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam16, 1, 0};
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam4(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam18(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam19(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam17(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam2(V self, V *args);
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_entry, 3, 0};

V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894(V v_st_240, V v_t_241, V v_new_242) {
top: ;
  V v_st_243 = heff_dup(v_st_240);
  V v_t_244 = heff_dup(v_t_241);
  V v_target_245 = heff_take_field(v_t_244, 1);
  V v_name_246 = heff_take_field(v_t_244, 2);
  V v_path_247 = heff_get_n(v_t_244, 0, 4);
  V v_new_248 = heff_dup(v_new_242);
  V v_t_249 = heff_get_n(v_target_245, 2, 3);
  V v_c_2424;
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    V v_t_2410 = v_name_246;
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_new_248, NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2411})});
    v_c_2424 = (g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(v_st_243, v_path_247, v_t_2412));
    break;
  }
  case TAG_Just: {
    V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 0ULL, 1);
    HeffT2 v_t_2414 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_243, 1), v_path_247));
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      if ((v_tag_2415 == ((int64_t)0ULL))) {
        heff_drop(v_name_246);
        heff_drop(v_path_247);
        heff_drop(v_new_248);
        heff_drop_cell(v_ru_24t_249_24Just, 1);
        V v_e_2417 = v_field_2416;
        v_c_2424 = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam0, 2, 2, (V[]){v_st_243, v_e_2417});
      } else {
        heff_drop(v_field_2416);
        V v_t_2421 = v_name_246;
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_new_248, NTAG(TAG_Nil)});
        V v_t_2423 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2422})});
        v_c_2424 = (g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(v_st_243, v_path_247, v_t_2423));
      }
    }
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam1, 2, 4, (V[]){v_c_2424, v_t_241, v_new_242, v_st_240});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894(a[0], a[1], a[2]);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam0(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_st_243 = heff_env(self)[0];
  V v_e_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2418);
  V v_t_2420 = heff_rec_n(2, shape_st__program, (V[]){v_st_243, heff_get_n(v_e_2417, 1, 2)});
  V f_ = v_k_2419;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam3(V self, V *args) {
  V v_p_2431 = args[0];
  V v_os_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2432 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2431, v_os_2428));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2431, v_os_2432});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam6(V self, V *args) {
  V v_p_2442 = args[0];
  V v_os_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_os_2443 = (g_list_2ekeepIf_24s304198972x561714839(v_p_2442, v_os_2439));
  return heff_rec_n(2, shape_path__occurrences, (V[]){v_p_2442, v_os_2443});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam7(V self, V *args) {
  V v_b_2445 = args[0];
  V v_new_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_path_2446 = heff_take_field(v_b_2445, 0);
  V v_occurrences_2447 = heff_get_n(v_b_2445, 1, 2);
  V v_os_2448 = v_occurrences_2447;
  V v_t_2451;
  switch (heff_tag_of(v_os_2448)) {
  case TAG_Nil: {
    v_t_2451 = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2449 = heff_dup(heff_field(v_os_2448, 0));
    v_t_2451 = heff_get_n(v_x_2449, 1, 4);
    break;
  }
  default: heff_nomatch(v_os_2448);
  }
  V v_t_2452 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_os_2448));
  V v_t_2453 = ({ V b_0 = MK_INT(0LL); V a_1 = v_new_242; V a_2 = v_t_2451; V a_3 = v_t_2452; V r_ = (g_list_2efoldl_24s198101905x967505038(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2452); r_; });
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_path_2446, v_t_2453});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam8(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_q_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2459);
  V v_t_2463;
  switch (heff_tag_of(v_q_2458)) {
  case TAG_MkPair: {
    V v_y_2462 = heff_field(v_q_2458, 1);
    heff_take_n(v_q_2458, 2ULL, 2);
    v_t_2463 = v_y_2462;
    break;
  }
  default: heff_nomatch(v_q_2458);
  }
  V f_ = v_k_2460;
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_t_2463});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam9(V self, V *args) {
  V v_hd_2468 = args[0];
  V v_k_2469 = args[1];
  V v_d_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2468);
  V v_t_2470 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_d_2467, 1, 2)});
  V f_ = v_k_2469;
  args[0] = v_t_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam10(V self, V *args) {
  V v_r_2473 = args[0];
  return v_r_2473;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam12(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k_2486 = args[1];
  V v_x_2484 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2485);
  V f_ = v_k_2486;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2484});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam11(V self, V *args) {
  V v_x_2481 = args[0];
  switch (heff_tag_of(v_x_2481)) {
  case TAG_Left: {
    V v_err_2482 = heff_field(v_x_2481, 0);
    V v_ru_24x_2481_24Left = heff_take_reuse_n(v_x_2481, 1ULL, 1);
    V v_t_2483 = heff_tag_at_n(v_ru_24x_2481_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2482})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2483));
  }
  case TAG_Right: {
    V v_x_2484 = heff_field(v_x_2481, 0);
    heff_take_n(v_x_2481, 1ULL, 1);
    return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam12, 2, 1, (V[]){v_x_2484});
  }
  default: return heff_nomatch(v_x_2481);
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_k_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2493;
  switch (heff_tag_of(v_x_2490)) {
  case TAG_Left: {
    heff_take_n(v_x_2490, 0ULL, 1);
    v_t_2493 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2492 = heff_field(v_x_2490, 0);
    V v_ru_24x_2490_24Right = heff_take_reuse_n(v_x_2490, 1ULL, 1);
    v_t_2493 = heff_tag_at_n(v_ru_24x_2490_24Right, TAG_Just, 1, (V[]){v_y_2492});
    break;
  }
  default: heff_nomatch(v_x_2490);
  }
  V f_ = v_k_2489;
  args[0] = v_t_2493;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2487;
  args[0] = v_hd_2488;
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam14, 1, 1, (V[]){v_k_2489});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam5(V self, V *args) {
  V v_p_2438 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_os_2439 = heff_get_n(v_t_241, 3, 4);
  V v_t_2440 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2439)));
  V v_t_2441 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2440));
  V v_t_2444 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam6, 1, 1, (V[]){v_os_2439}), v_t_2441));
  V v_texts_2454 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam7, 1, 1, (V[]){v_new_242}), v_t_2444));
  HeffT2 v_t_2455 = ({ V a_0 = v_p_2438; V a_1 = v_texts_2454; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(a_0, a_1)); heff_drop(v_texts_2454); r_; });
  {
    V v_field_2457 = v_t_2455.f[1];
    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
    if ((v_tag_2456 == ((int64_t)0ULL))) {
      heff_drop(v_p_2438);
      heff_drop_rec(v_st_240, 7);
      V v_q_2458 = v_field_2457;
      return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam8, 2, 1, (V[]){v_q_2458});
    } else {
      heff_drop(v_field_2457);
      HeffT2 v_t_2464 = ({ V b_0 = heff_get_n(v_st_240, 0, 7); V a_1 = v_p_2438; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2466 = v_t_2464.f[1];
        int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
        if ((v_tag_2465 == ((int64_t)0ULL))) {
          heff_drop(v_p_2438);
          V v_d_2467 = v_field_2466;
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam9, 2, 1, (V[]){v_d_2467});
        } else {
          heff_drop(v_field_2466);
          V v_path_2471 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_p_2438));
          V v_t_2472 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2471; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2471); r_; });
          V v_a_2474 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2472, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam10_clo)});
          V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2474})});
          V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
          V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
          V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
          V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
          V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})});
          V v_c_2487 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2480}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam11_clo)));
          return heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam13, 2, 1, (V[]){v_c_2487});
        }
      }
    }
  }
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam15(V self, V *args) {
  V v_s_2494 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_s_2494, 2, 8)}));
  return ({ V a_0 = v_t_2495; V a_1 = v_x_2435; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2435); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam16(V self, V *args) {
  V v_r_2497 = args[0];
  return v_r_2497;
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam4(V self, V *args) {
  V v_use_2436 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_k_2437 = heff_dup(heff_rfield(v_hd_2425, 0));
  V v_t_2496 = heff_tr(g_heff_2elsp_2elsp_2eelabFiles_24s1639825206x2060005427(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam5, 1, 3, (V[]){heff_dup(v_t_241), v_new_242, heff_dup(v_st_240)}), heff_get_n(v_st_240, 6, 7), heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam15, 1, 1, (V[]){heff_dup(v_x_2435)}), heff_dup(g_std_2eordmap_2eempty_get()), heff_get_n(v_t_241, 0, 4), v_x_2435, v_hd_2425, v_k_2437));
  V f_ = v_use_2436;
  heff_room[0] = v_t_2496;
  heff_room[1] = ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam16_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam18(V self, V *args) {
  V v_c_24114 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24115 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_24114, 1, 14)}));
  return ({ V a_0 = v_t_24115; V a_1 = v_x_2435; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2435); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam19(V self, V *args) {
  V v_c_24119 = args[0];
  V v_x_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24120 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_c_24119, 1, 14)}));
  return ({ V a_0 = v_t_24120; V a_1 = v_x_2435; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_x_2435); r_; });
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam17(V self, V *args) {
  V v_x_24104 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_new_242 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_k_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x_24135;
  switch (heff_tag_of(v_x_24104)) {
  case TAG_Left: {
    V v_x_24105 = heff_field(v_x_24104, 0);
    V v_ru_24x_24104_24Left = heff_take_reuse_n(v_x_24104, 1ULL, 1);
    heff_drop(v_x_2435);
    V v_t_24106 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str1), heff_get_n(v_t_241, 2, 4));
    V v_t_24107 = heff_strAppend(heff_strAppend(v_t_24106, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str2)), v_new_242);
    V v_t_24108 = heff_strAppend(heff_strAppend(v_t_24107, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str3)), v_x_24105);
    V v_t_24109 = heff_tag_at_n(v_ru_24x_24104_24Left, TAG_Just, 1, (V[]){heff_strAppend(v_t_24108, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str4))});
    v_x_24135 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_x_2427, 0, 2), v_t_24109});
    break;
  }
  case TAG_Right: {
    V v_y_24110 = heff_field(v_x_24104, 0);
    V v_ru_24x_24104_24Right = heff_take_reuse_n(v_x_24104, 1ULL, 1);
    V v_before_24111 = heff_dup(v_x_2427);
    V v_t_24112 = v_t_241;
    V v_new_24113 = v_new_242;
    V v_program_24116 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam18, 1, 1, (V[]){heff_dup(v_x_2435)}), heff_get_n(v_x_2427, 1, 2)));
    V v_t_24117 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24116));
    V v_errorsBefore_24118 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_24117; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_24117); r_; });
    V v_program_24121 = (g_list_2ekeepIf(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam19, 1, 1, (V[]){v_x_2435}), heff_dup(heff_rfield(v_y_24110, 0))));
    V v_t_24122 = (g_heff_2elsp_2elsp_2enubCheckedPaths(v_program_24121));
    V v_errorsAfter_24123 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_t_24122; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_t_24122); r_; });
    V v_after_24124 = heff_get_n(v_y_24110, 0, 2);
    V v_t_24134;
    if (heff_intLt_c_lent(v_errorsBefore_24118, v_errorsAfter_24123, 0)) {
      heff_drop(v_after_24124);
      V v_t_24125 = heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str5), heff_get_n(v_t_24112, 2, 4));
      V v_t_24126 = heff_strAppend(heff_strAppend(v_t_24125, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str6)), v_new_24113);
      V v_t_24127 = heff_intShow(heff_intSub(v_errorsAfter_24123, v_errorsBefore_24118));
      V v_t_24128 = heff_strAppend(heff_strAppend(v_t_24126, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str7)), v_t_24127);
      v_t_24134 = heff_tag_at_n(v_ru_24x_24104_24Right, TAG_Just, 1, (V[]){heff_strAppend(v_t_24128, ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str8))});
    } else {
      heff_drop(v_errorsBefore_24118);
      heff_drop(v_errorsAfter_24123);
      V v_t_24129 = (g_heff_2elsp_2elsp_2erenamedTarget(heff_dup(v_t_24112), heff_dup(v_new_24113)));
      V v_xs_24130 = (g_heff_2ebuild_2equery_2eoccurrences(v_after_24124, v_t_24129, heff_dup(v_new_24113)));
      V v_x_24131 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_24130; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_24130); r_; });
      V v_y_24132 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_24112, 3, 4); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
      if (!heff_intEq_c_lent(v_x_24131, v_y_24132, 0)) {
        heff_drop(v_x_24131);
        heff_drop(v_y_24132);
        V v_t_24133 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str9), v_new_24113), ((V)&g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_str10));
        v_t_24134 = heff_tag_at_n(v_ru_24x_24104_24Right, TAG_Just, 1, (V[]){v_t_24133});
      } else {
        heff_drop_cell(v_ru_24x_24104_24Right, 1);
        heff_drop(v_new_24113);
        heff_drop(v_x_24131);
        heff_drop(v_y_24132);
        v_t_24134 = NTAG(TAG_Nothing);
      }
    }
    v_x_24135 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_get_n(v_before_24111, 0, 2), v_t_24134});
    break;
  }
  default: heff_nomatch(v_x_24104);
  }
  V f_ = v_k_2426;
  args[0] = v_x_24135;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_k_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_os_2428 = heff_dup(heff_rfield(v_t_241, 3));
  V v_t_2429 = (g_list_2emap_24s831190316x576961335(heff_dup(v_os_2428)));
  V v_t_2430 = (g_heff_2elsp_2elsp_2enubPaths(v_t_2429));
  V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam3, 1, 1, (V[]){v_os_2428}), v_t_2430));
  V v_t_2434 = (g_list_2emap_24s582709368x2113456071(v_t_2433));
  V v_x_2435 = ({ V a_0 = v_t_2434; V a_1 = NTAG(TAG_Nil); V a_2 = heff_dup(heff_rfield(v_x_2427, 1)); V r_ = (g_heff_2elsp_2elsp_2eaffectedGo(a_0, a_1, a_2)); heff_drop(v_t_2434); r_; });
  V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Attempt, 1, (V[]){heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam4, 1, 5, (V[]){heff_dup(v_hd_2425), heff_dup(v_t_241), heff_dup(v_new_242), v_st_240, heff_dup(v_x_2435)})})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tr(heff_call(heff_take_field(v_hd_2425, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})}));
  V f_ = heff_get_n(v_hd_2425, 1, 3);
  heff_room[0] = v_t_24103;
  heff_room[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam17, 1, 5, (V[]){v_t_241, v_new_242, v_x_2427, v_x_2435, v_k_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam1(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_new_242 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2elsp_2elsp_2erenameChecked_24s1276104613x887863894_lam2, 1, 5, (V[]){v_t_241, v_hd_2425, v_new_242, v_st_240, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str0, 6, "method");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str1, 2, "id");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str2, 6, "params");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str3, 8, "shutdown");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str4, 9, "shut down");
HEFF_LIT(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str5, 6, "params");
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_lam0(V self, V *args);
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_lam1(V self, V *args);
Clo g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_entry, 4, 0};

V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265(V v_st_240, V v_msg_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_2423;
  switch (heff_tag_of(v_msg_241)) {
  case TAG_JNull: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JBool: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JInt: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JFloat: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JString: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JArray: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_JObject: {
    V v_fs_249 = heff_dup(heff_field(v_msg_241, 0));
    HeffT2 v_t_2410 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str0); V a_1 = v_fs_249; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_249); r_; });
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_p_2413 = v_field_2412;
        V v_t_2416;
        switch (heff_tag_of(v_p_2413)) {
        case TAG_MkPair: {
          V v_y_2415 = heff_field(v_p_2413, 1);
          heff_take_n(v_p_2413, 2ULL, 2);
          v_t_2416 = v_y_2415;
          break;
        }
        default: heff_nomatch(v_p_2413);
        }
        switch (heff_tag_of(v_t_2416)) {
        case TAG_JNull: {
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JString: {
          V v_s_2420 = heff_field(v_t_2416, 0);
          V v_ru_24t_2416_24JString = heff_take_reuse_n(v_t_2416, 1ULL, 1);
          v_t_2423 = heff_tag_at_n(v_ru_24t_2416_24JString, TAG_Just, 1, (V[]){v_s_2420});
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_JObject: {
          heff_take_n(v_t_2416, 0ULL, 1);
          v_t_2423 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_t_2416);
        }
      } else {
        heff_drop(v_field_2412);
        v_t_2423 = NTAG(TAG_Nothing);
      }
    }
    break;
  }
  default: heff_nomatch(v_msg_241);
  }
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    heff_drop(v_msg_241);
    heff_drop(v_z_242);
    return heff_tail(v_z_243, 1, (V[]){v_st_240});
  }
  case TAG_Just: {
    V v_m_2424 = heff_field(v_t_2423, 0);
    V v_ru_24t_2423_24Just = heff_take_reuse_n(v_t_2423, 1ULL, 1);
    V v_t_2438;
    switch (heff_tag_of(v_msg_241)) {
    case TAG_JNull: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JBool: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JInt: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JFloat: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JString: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JArray: {
      heff_drop_cell(v_ru_24t_2423_24Just, 1);
      v_t_2438 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_JObject: {
      V v_fs_2430 = heff_dup(heff_field(v_msg_241, 0));
      HeffT2 v_t_2431 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str1); V a_1 = v_fs_2430; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2430); r_; });
      {
        V v_field_2433 = v_t_2431.f[1];
        int64_t v_tag_2432 = ((int64_t)v_t_2431.f[0]);
        if ((v_tag_2432 == ((int64_t)0ULL))) {
          V v_p_2434 = v_field_2433;
          V v_t_2437;
          switch (heff_tag_of(v_p_2434)) {
          case TAG_MkPair: {
            V v_y_2436 = heff_field(v_p_2434, 1);
            heff_take_n(v_p_2434, 2ULL, 2);
            v_t_2437 = v_y_2436;
            break;
          }
          default: heff_nomatch(v_p_2434);
          }
          v_t_2438 = heff_tag_at_n(v_ru_24t_2423_24Just, TAG_Just, 1, (V[]){v_t_2437});
        } else {
          heff_drop_cell(v_ru_24t_2423_24Just, 1);
          heff_drop(v_field_2433);
          v_t_2438 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_msg_241);
    }
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      V v_p_2451;
      switch (heff_tag_of(v_msg_241)) {
      case TAG_JNull: {
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JString: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_msg_241, 0ULL, 1);
        v_p_2451 = NTAG(TAG_JNull);
        break;
      }
      case TAG_JObject: {
        V v_fs_2444 = heff_field(v_msg_241, 0);
        heff_take_n(v_msg_241, 1ULL, 1);
        HeffT2 v_t_2445 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str2); V a_1 = v_fs_2444; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2444); r_; });
        {
          V v_field_2447 = v_t_2445.f[1];
          int64_t v_tag_2446 = ((int64_t)v_t_2445.f[0]);
          if ((v_tag_2446 == ((int64_t)0ULL))) {
            V v_p_2448 = v_field_2447;
            switch (heff_tag_of(v_p_2448)) {
            case TAG_MkPair: {
              V v_y_2450 = heff_field(v_p_2448, 1);
              heff_take_n(v_p_2448, 2ULL, 2);
              v_p_2451 = v_y_2450;
              break;
            }
            default: heff_nomatch(v_p_2448);
            }
          } else {
            heff_drop(v_field_2447);
            v_p_2451 = NTAG(TAG_JNull);
          }
        }
        break;
      }
      default: heff_nomatch(v_msg_241);
      }
      V v_c_2452 = (g_heff_2elsp_2elsp_2ekeepsProject_24s775112097x37738562(heff_dup(v_st_240), v_m_2424, heff_dup(v_p_2451)));
      return heff_tail(v_c_2452, 2, (V[]){heff_dup(v_z_242), heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_lam0, 1, 5, (V[]){v_st_240, v_m_2424, v_p_2451, v_z_242, v_z_243})});
    }
    case TAG_Just: {
      V v_id_2465 = heff_field(v_t_2438, 0);
      V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 1ULL, 1);
      if (((heff_dup(heff_rfield(v_st_240, 5)) == NTAG(TAG_True)) && !heff_strEq_c_lent(v_m_2424, ((V)&g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str3), 2))) {
        heff_drop(v_msg_241);
        heff_drop(v_m_2424);
        V v_c_2466 = heff_tr(g_heff_2elsp_2elsp_2ereplyError_24s150653372x554795161_24tok1(v_ru_24t_2438_24Just, v_id_2465, MK_INT(-32600LL), ((V)&g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str4)));
        return heff_tail(v_c_2466, 2, (V[]){v_z_242, heff_clo_n(g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_lam1, 1, 2, (V[]){v_z_243, v_st_240})});
      } else {
        heff_drop_cell(v_ru_24t_2438_24Just, 1);
        V v_t_2480;
        switch (heff_tag_of(v_msg_241)) {
        case TAG_JNull: {
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JBool: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JInt: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JFloat: {
          heff_take_na(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JString: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JArray: {
          heff_take_n(v_msg_241, 0ULL, 1);
          v_t_2480 = NTAG(TAG_JNull);
          break;
        }
        case TAG_JObject: {
          V v_fs_2473 = heff_field(v_msg_241, 0);
          heff_take_n(v_msg_241, 1ULL, 1);
          HeffT2 v_t_2474 = ({ V b_0 = ((V)&g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_str5); V a_1 = v_fs_2473; HeffT2 r_ = (g_list_2efind_24s1807954837x1305454787_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_fs_2473); r_; });
          {
            V v_field_2476 = v_t_2474.f[1];
            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
            if ((v_tag_2475 == ((int64_t)0ULL))) {
              V v_p_2477 = v_field_2476;
              switch (heff_tag_of(v_p_2477)) {
              case TAG_MkPair: {
                V v_y_2479 = heff_field(v_p_2477, 1);
                heff_take_n(v_p_2477, 2ULL, 2);
                v_t_2480 = v_y_2479;
                break;
              }
              default: heff_nomatch(v_p_2477);
              }
            } else {
              heff_drop(v_field_2476);
              v_t_2480 = NTAG(TAG_JNull);
            }
          }
          break;
        }
        default: heff_nomatch(v_msg_241);
        }
        return (g_heff_2elsp_2elsp_2erequest_24s1554887560x1029217223(v_st_240, v_m_2424, v_id_2465, v_t_2480, v_z_242, v_z_243));
      }
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_t_2423);
  }
}
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265(a[0], a[1], a[2], a[3]);
}
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_lam0(V self, V *args) {
  V v_x_2453 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_m_2424 = heff_env(self)[1];
  V v_p_2451 = heff_env(self)[2];
  V v_z_242 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464;
  if ((heff_dup(v_x_2453) == NTAG(TAG_True))) {
    heff_drop(v_x_2453);
    v_t_2464 = v_st_240;
  } else {
    heff_drop(v_x_2453);
    V v_s_2454 = v_st_240;
    V v_t_2455 = heff_dup(heff_rfield(v_s_2454, 3));
    switch (heff_tag_of(v_t_2455)) {
    case TAG_Nothing: {
      v_t_2464 = v_s_2454;
      break;
    }
    case TAG_Just: {
      V v_pr_2456 = heff_field(v_t_2455, 0);
      heff_take_n(v_t_2455, 1ULL, 1);
      V v_due_2457 = heff_take_field(v_s_2454, 2);
      V v_watch_2458 = heff_take_field(v_s_2454, 4);
      V v_shutdown_2459 = heff_take_field(v_s_2454, 5);
      V v_lib_2460 = heff_take_field(v_s_2454, 6);
      V v_program_2461 = heff_take_field(v_pr_2456, 2);
      V v_kept_2462 = heff_take_field(v_pr_2456, 4);
      V v_t_2463 = ({ V rv_2 = v_program_2461; V rv_3 = NTAG(TAG_False); V rv_4 = v_kept_2462; V rr_ = heff_rec_reuse_nf(v_pr_2456, 3ULL, 5, shape_root__names__program__current__kept, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
      v_t_2464 = ({ V rv_2 = v_due_2457; V rv_3 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2463}); V rv_4 = v_watch_2458; V rv_5 = v_shutdown_2459; V rv_6 = v_lib_2460; V rr_ = heff_rec_reuse_nf(v_s_2454, 3ULL, 7, shape_docs__checked__due__project__watch__shutdown__lib, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; rr_; });
      break;
    }
    default: heff_nomatch(v_t_2455);
    }
  }
  return ({ V a_0 = v_t_2464; V a_1 = v_m_2424; V a_2 = v_p_2451; V a_3 = v_z_242; V a_4 = v_z_243; V r_ = (g_heff_2elsp_2elsp_2enotified_24s966980539x1224111968(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_m_2424); r_; });
}
V g_heff_2elsp_2elsp_2ehandle_24s1424375712x1266486265_lam1(V self, V *args) {
  V v_x_2467 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2467);
  V f_ = v_z_243;
  args[0] = v_st_240;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_lam0(V self, V *args);
Clo g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_entry, 7, 0};

V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2(V v_tok_240, V v_a_241, V v_f_242, V v_off_243, V v_t_244, V v_z_245, V v_z_246) {
top: ;
  V v_target_247 = heff_take_field(v_t_244, 0);
  V v_name_248 = heff_get_n(v_t_244, 1, 2);
  V v_st_249 = heff_take_field(v_a_241, 0);
  V v_program_2410 = heff_get_n(v_a_241, 2, 3);
  V v_t_2411 = heff_dup(heff_rfield(v_target_247, 2));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){heff_dup(v_name_248), NTAG(TAG_Nil)});
    V v_c_2413 = (g_heff_2elsp_2elsp_2eprojectFor_24s1942280151x168798417(v_st_249, heff_dup(v_f_242), heff_tag_n(TAG_Just, 1, (V[]){v_t_2412})));
    return heff_tail(v_c_2413, 2, (V[]){v_z_245, heff_clo_n(g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_lam0, 1, 6, (V[]){v_name_248, v_program_2410, v_target_247, v_f_242, v_z_246, v_off_243})});
  }
  case TAG_Just: {
    V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop_cell(v_tok_240, 2);
    heff_drop(v_z_245);
    V v_name_2424 = heff_dup(v_name_248);
    V v_occurrences_2425 = (g_heff_2ebuild_2equery_2eoccurrences(v_program_2410, heff_dup(v_target_247), v_name_248));
    V v_target_2426 = heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2424, v_occurrences_2425})});
    return heff_tail(v_z_246, 1, (V[]){heff_rec_n(3, shape_st__off__target, (V[]){v_st_249, v_off_243, v_target_2426})});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2elsp_2elsp_2epointedIn_24s659901941x1388349171_24tok2_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_name_248 = heff_env(self)[0];
  V v_program_2410 = heff_env(self)[1];
  V v_target_247 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  V v_off_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_program_2415 = heff_take_field(v_x_2414, 1);
  V v_st_2416 = heff_get_n(v_x_2414, 0, 2);
  V v_name_2417 = heff_dup(v_name_248);
  V v_t_2420;
  switch (heff_tag_of(v_program_2415)) {
  case TAG_Nil: {
    v_t_2420 = v_program_2410;
    break;
  }
  case TAG_Cons: {
    heff_drop(v_program_2410);
    v_t_2420 = v_program_2415;
    break;
  }
  default: heff_nomatch(v_program_2415);
  }
  V v_occurrences_2421 = (g_heff_2ebuild_2equery_2eoccurrences(v_t_2420, heff_dup(v_target_247), v_name_248));
  V v_target_2422 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(4, shape_path__target__name__occurrences, (V[]){v_f_242, v_target_247, v_name_2417, v_occurrences_2421})});
  V f_ = v_z_246;
  args[0] = heff_rec_n(3, shape_st__off__target, (V[]){v_st_2416, v_off_243, v_target_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}