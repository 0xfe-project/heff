// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Abn 13049
#define TAG_AbsConst 8406
#define TAG_Bug 14592
#define TAG_Div 16157
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkAbs 54862
#define TAG_Ok 9325
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_byName 571997869
#define LBL_fixed 298804110
#define LBL_global 704121550
#define LBL_keys 9783995
#define LBL_local 304503685
#define LBL_op 10312
#define LBL_values 1123329101
static uint32_t shape_fixed__op[] = {LBL_fixed, LBL_op};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_local__global[] = {LBL_local, LBL_global};
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340(V, V, V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340_clo;
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(V, V, V, V);
V g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581_clo;
V g_heff_2ecompile_2einterp_2ebyteString(V, V);
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ebyteString_clo;
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void);
V g_heff_2ecompile_2einterp_2edigitsEndV(V, V);
V g_heff_2ecompile_2einterp_2edigitsEndV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2edigitsEndV_clo;
V g_heff_2ecompile_2einterp_2eevalEach(V, V, V);
V g_heff_2ecompile_2einterp_2eevalEach_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalEach_clo;
V g_heff_2ecompile_2einterp_2eevalFields(V, V, V);
V g_heff_2ecompile_2einterp_2eevalFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalFields_clo;
V g_heff_2ecompile_2einterp_2eevalIn(V, V, V);
V g_heff_2ecompile_2einterp_2eevalIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eevalIn_clo;
V g_heff_2ecompile_2einterp_2efixedInt2(V, V, V, V);
V g_heff_2ecompile_2einterp_2efixedInt2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2efixedInt2_clo;
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void);
V g_heff_2ecompile_2einterp_2ehashFrom(V, V, V);
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ehashFrom_clo;
double g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_w(V, V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitudeOf(V, V, V, V);
V g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_clo;
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(V, V, V);
V g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733_clo;
V g_heff_2ecompile_2einterp_2enotAFloat64_get(void);
V g_heff_2ecompile_2einterp_2enotAString_get(void);
V g_heff_2ecompile_2einterp_2enotBytes_get(void);
HeffT2 g_heff_2ecompile_2einterp_2enthTh_24cpr(V, V);
V g_heff_2ecompile_2einterp_2eprim(V);
V g_heff_2ecompile_2einterp_2eprim_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprim_clo;
V g_heff_2ecompile_2einterp_2eprojV(V, V);
V g_heff_2ecompile_2einterp_2eprojV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprojV_clo;
V g_heff_2ecompile_2einterp_2eprojV_24tok1(V, V, V);
V g_heff_2ecompile_2einterp_2eprojV_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eprojV_24tok1_clo;
double g_heff_2ecompile_2einterp_2escaledF_w(double, V);
V g_heff_2ecompile_2einterp_2escaledF(V, V);
V g_heff_2ecompile_2einterp_2escaledF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2escaledF_clo;
V g_heff_2ecompile_2einterp_2esetAt(V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_clo;
V g_heff_2ecompile_2einterp_2esetAt_24dps(V, V, V, V);
V g_heff_2ecompile_2einterp_2esetAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2esetAt_24dps_clo;
V g_heff_2ecompile_2einterp_2etwoTo(V);
V g_heff_2ecompile_2einterp_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoTo_clo;
double g_heff_2ecompile_2einterp_2etwoToF_w(V);
V g_heff_2ecompile_2einterp_2etwoToF(V);
V g_heff_2ecompile_2einterp_2etwoToF_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2etwoToF_clo;
V g_heff_2ecompile_2einterp_2eword64_get(void);
V g_heff_2ecompile_2einterp_2ewordFrom(V, V, V, V);
V g_heff_2ecompile_2einterp_2ewordFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2ewordFrom_clo;
V g_heff_2eelab_2efixed_2efixedMin(V);
V g_heff_2eelab_2efixed_2efixedMin_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedMin_clo;
V g_heff_2eelab_2efixed_2efixedPrimName(V);
V g_heff_2eelab_2efixed_2efixedPrimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2efixedPrimName_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1344708576x2031305372(V, V);
V g_list_2efoldl_24s1344708576x2031305372_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1344708576x2031305372_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2ecompile_2einterp_2enotAString_str0, 40, "a primitive given what is not a `String`");

static V g_heff_2ecompile_2einterp_2enotAString_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2enotAString_st;
static V g_heff_2ecompile_2einterp_2enotAString_init(void) {
  return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2enotAString_str0)});
}
V g_heff_2ecompile_2einterp_2enotAString_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2enotAString_st)) return g_heff_2ecompile_2einterp_2enotAString_val;
  return heff_global(&g_heff_2ecompile_2einterp_2enotAString_val, &g_heff_2ecompile_2einterp_2enotAString_st, g_heff_2ecompile_2einterp_2enotAString_init);
}
Clo g_heff_2ecompile_2einterp_2ebyteString_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebyteString_entry, 2, 0};

V g_heff_2ecompile_2einterp_2ebyteString(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_VFun: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VCons: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VTag: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VInt: {
      V v_c_248 = heff_field(v_x11_242, 0);
      V v_t_249 = heff_strFromByte(heff_box_u8(heff_from_int_u8(heff_dup(v_c_248))));
      V t_0 = v_rest_243;
      V t_1 = heff_strAppend(v_acc_241, v_t_249);
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VFloat: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VFloat32: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VStr: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VRune: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VArr: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VBytes: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VBits: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_VErased: {
      V t_0 = v_rest_243;
      V t_1 = v_acc_241;
      v_x1_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2ebyteString_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2ebyteString(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2escaledF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2escaledF_entry, 2, 0};

double g_heff_2ecompile_2einterp_2escaledF_w(double v_x_240, V v_k_241) {
top: ;
  if (heff_intLt_c_lent(v_k_241, MK_INT(-1000LL), 2)) {
    double v_t_242 = (g_heff_2ecompile_2einterp_2etwoToF_w(MK_INT(-1000LL)));
    double t_0 = (v_x_240 * v_t_242);
    V t_1 = heff_intAdd(v_k_241, MK_INT(1000LL));
    v_x_240 = t_0;
    v_k_241 = t_1;
    goto top;
  } else {
    if (heff_intLt_c_lent(MK_INT(1000LL), v_k_241, 1)) {
      double v_t_243 = (g_heff_2ecompile_2einterp_2etwoToF_w(MK_INT(1000LL)));
      double t_0 = (v_x_240 * v_t_243);
      V t_1 = heff_intSub(v_k_241, MK_INT(1000LL));
      v_x_240 = t_0;
      v_k_241 = t_1;
      goto top;
    } else {
      double v_t_244 = (g_heff_2ecompile_2einterp_2etwoToF_w(v_k_241));
      return (v_x_240 * v_t_244);
    }
  }
}
V g_heff_2ecompile_2einterp_2escaledF(V v_box_24x_240, V v_k_241) {
  double v_x_240 = heff_unbox_f64(v_box_24x_240);
  return heff_box_f64((g_heff_2ecompile_2einterp_2escaledF_w(v_x_240, v_k_241)));
}
V g_heff_2ecompile_2einterp_2escaledF_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2escaledF(a[0], a[1]);
}
Clo g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_entry, 4, 0};

double g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_w(V v_box_24eb_240, V v_fb_241, V v_e_242, V v_m_243) {
  int64_t v_eb_240 = heff_unbox_word(v_box_24eb_240);
top: ;
  V v_t_244 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word(v_eb_240)));
  if (heff_intEq_c(heff_dup(v_e_242), heff_intSub(v_t_244, MK_INT(1LL)))) {
    heff_drop(v_fb_241);
    heff_drop(v_e_242);
    if (heff_intEq_c(v_m_243, MK_INT(0LL))) {
      return ((1.0) / (0.0));
    } else {
      return ((0.0) / (0.0));
    }
  } else {
    if (heff_intEq_c_lent(v_e_242, MK_INT(0LL), 2)) {
      heff_drop(v_e_242);
      V v_t_245 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((v_eb_240 - ((int64_t)1ULL)))));
      V v_t_246 = heff_intSub(heff_intSub(MK_INT(2LL), v_t_245), v_fb_241);
      return (g_heff_2ecompile_2einterp_2escaledF_w(heff_from_int_f64(v_m_243), v_t_246));
    } else {
      V v_t_247 = (g_heff_2ecompile_2einterp_2etwoTo(heff_dup(v_fb_241)));
      double v_t_248 = heff_from_int_f64(heff_intAdd(v_m_243, v_t_247));
      V v_t_249 = (g_heff_2ecompile_2einterp_2etwoTo(heff_box_word((v_eb_240 - ((int64_t)1ULL)))));
      V v_t_2410 = heff_intAdd(heff_intSub(v_e_242, v_t_249), MK_INT(1LL));
      return (g_heff_2ecompile_2einterp_2escaledF_w(v_t_248, heff_intSub(v_t_2410, v_fb_241)));
    }
  }
}
V g_heff_2ecompile_2einterp_2eieeeMagnitudeOf(V v_box_24eb_240, V v_fb_241, V v_e_242, V v_m_243) {
  return heff_box_f64((g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_w(v_box_24eb_240, v_fb_241, v_e_242, v_m_243)));
}
V g_heff_2ecompile_2einterp_2eieeeMagnitudeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eieeeMagnitudeOf(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2einterp_2edigitsEndV_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2edigitsEndV_entry, 2, 0};

V g_heff_2ecompile_2einterp_2edigitsEndV(V v_t_240, V v_i_241) {
top: ;
  if (((((int64_t)48ULL) <= heff_unbox_word(heff_strByteAt_lent(v_t_240, v_i_241, 0))) && (heff_unbox_word(heff_strByteAt_lent(v_t_240, v_i_241, 0)) <= ((int64_t)57ULL)))) {
    V t_0 = v_t_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_t_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2ecompile_2einterp_2edigitsEndV_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2edigitsEndV(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2einterp_2esetAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2esetAt_entry, 3, 0};

V g_heff_2ecompile_2einterp_2esetAt(V v_x1_240, V v_i_241, V v_x_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
      heff_drop(v_i_241);
      heff_drop(v_y_243);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_ys_244});
    } else {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_y_243, heff_hole()});
      V v_u_246 = (g_heff_2ecompile_2einterp_2esetAt_24dps(v_ys_244, heff_intSub(v_i_241, MK_INT(1LL)), v_x_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2einterp_2esetAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2esetAt(a[0], a[1], a[2]);
}

static V g_heff_2ecompile_2einterp_2eword64_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2eword64_st;
static V g_heff_2ecompile_2einterp_2eword64_init(void) {
  return (g_heff_2eelab_2efixed_2etwoTo(MK_INT(64LL)));
}
V g_heff_2ecompile_2einterp_2eword64_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2eword64_st)) return g_heff_2ecompile_2einterp_2eword64_val;
  return heff_global(&g_heff_2ecompile_2einterp_2eword64_val, &g_heff_2ecompile_2einterp_2eword64_st, g_heff_2ecompile_2einterp_2eword64_init);
}
Clo g_heff_2ecompile_2einterp_2ehashFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ehashFrom_entry, 3, 0};

V g_heff_2ecompile_2einterp_2ehashFrom(V v_s_240, V v_i_241, V v_h_242) {
top: ;
  if (heff_intLe_c(heff_intAdd(heff_dup(v_i_241), MK_INT(8LL)), heff_strLength_lent(v_s_240, 0))) {
    V v_w_243 = (g_heff_2ecompile_2einterp_2ewordFrom(v_s_240, heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(7LL)), MK_INT(0LL)));
    V v_t_244 = heff_intMod(heff_intMul(heff_dup(v_h_242), MK_INT(32LL)), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
    V v_t_245 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(59LL)));
    V v_a_246 = heff_intAdd(v_t_244, heff_intDiv(v_h_242, v_t_245));
    V v_t_247 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_246, v_w_243));
    V v_t_248 = heff_intMod(heff_intMul(v_t_247, HEFF_BIG("5871781006564002453")), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(8LL));
    V t_2 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_h_242 = t_2;
    goto top;
  } else {
    if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
      int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
      V v_w_2410 = (g_heff_2ecompile_2einterp_2ewordFrom(v_s_240, v_i_241, heff_box_word(v_t_249), MK_INT(0LL)));
      V v_t_2411 = heff_intMod(heff_intMul(heff_dup(v_h_242), MK_INT(32LL)), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
      V v_t_2412 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(59LL)));
      V v_a_2413 = heff_intAdd(v_t_2411, heff_intDiv(v_h_242, v_t_2412));
      V v_t_2414 = (g_heff_2ecompile_2einterp_2eintBits_24s2147340586x904600733(MK_INT(2LL), v_a_2413, v_w_2410));
      return heff_intMod(heff_intMul(v_t_2414, HEFF_BIG("5871781006564002453")), heff_dup(g_heff_2ecompile_2einterp_2eword64_get()));
    } else {
      heff_drop(v_i_241);
      return v_h_242;
    }
  }
}
V g_heff_2ecompile_2einterp_2ehashFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2einterp_2ehashFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str2, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str3, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str6, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str7, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str8, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str9, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str10, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str11, 13, "no primitive ");
HEFF_LIT(g_heff_2ecompile_2einterp_2efixedInt2_str12, 13, "no primitive ");
Clo g_heff_2ecompile_2einterp_2efixedInt2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efixedInt2_entry, 4, 0};

V g_heff_2ecompile_2einterp_2efixedInt2(V v_w_240, V v_op_241, V v_a_242, V v_b_243) {
top: ;
  switch (heff_tag_of(v_op_241)) {
  case TAG_OpAdd: {
    V v_t_244 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_245 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_246 = heff_intSub(heff_intAdd(v_a_242, v_b_243), v_t_245);
    V v_t_247;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_247 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_247 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_247 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_247 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_247 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_247 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_247 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_248 = (g_heff_2eelab_2efixed_2etwoTo(v_t_247));
    V v_t_249 = heff_intAdd(v_t_244, heff_intMod(v_t_246, v_t_248));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_249})});
  }
  case TAG_OpSub: {
    V v_t_2410 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2411 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2412 = heff_intSub(heff_intSub(v_a_242, v_b_243), v_t_2411);
    V v_t_2413;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2413 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2413 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2413 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2413 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2413 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2413 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2413 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2413 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2413 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2414 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2413));
    V v_t_2415 = heff_intAdd(v_t_2410, heff_intMod(v_t_2412, v_t_2414));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2415})});
  }
  case TAG_OpMul: {
    V v_t_2416 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2417 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
    V v_t_2418 = heff_intSub(heff_intMul(v_a_242, v_b_243), v_t_2417);
    V v_t_2419;
    switch (heff_tag_of(v_w_240)) {
    case TAG_I8: {
      v_t_2419 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2419 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2419 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2419 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2419 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2419 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2419 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_240);
    }
    V v_t_2420 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2419));
    V v_t_2421 = heff_intAdd(v_t_2416, heff_intMod(v_t_2418, v_t_2420));
    return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_t_2421})});
  }
  case TAG_OpDiv: {
    if (heff_intEq_c_lent(v_b_243, MK_INT(0LL), 2)) {
      heff_drop(v_a_242);
      heff_drop(v_b_243);
      V v_t_2422 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2423 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2424;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2424 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2424 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2424 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2424 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2424 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2424 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2424 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2424 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2424 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2425 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2424));
      V v_t_2426 = heff_intMod(heff_intSub(MK_INT(0LL), v_t_2423), v_t_2425);
      V v_t_2427 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2422, v_t_2426)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2427});
    } else {
      V v_t_2428 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2429;
      if ((heff_intEq_c(heff_intMod(heff_dup(v_a_242), heff_dup(v_b_243)), MK_INT(0LL)) ? 0 : (heff_intLt_c_lent(v_a_242, MK_INT(0LL), 2) ? heff_intLe_c_lent(MK_INT(0LL), v_b_243, 1) : heff_intLt_c_lent(v_b_243, MK_INT(0LL), 2)))) {
        v_t_2429 = heff_intAdd(heff_intDiv(v_a_242, v_b_243), MK_INT(1LL));
      } else {
        v_t_2429 = heff_intDiv(v_a_242, v_b_243);
      }
      V v_t_2430 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2431;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2431 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2431 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2431 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2431 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2431 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2431 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2431 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2431 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2431 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2432 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2431));
      V v_t_2433 = heff_intMod(heff_intSub(v_t_2429, v_t_2430), v_t_2432);
      V v_t_2434 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2428, v_t_2433)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2434});
    }
  }
  case TAG_OpRem: {
    if (heff_intEq_c_lent(v_b_243, MK_INT(0LL), 2)) {
      heff_drop(v_b_243);
      V v_t_2435 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2436 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2437;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2437 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2437 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2437 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2437 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2437 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2437 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2437 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2438 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2437));
      V v_t_2439 = heff_intMod(heff_intSub(v_a_242, v_t_2436), v_t_2438);
      V v_t_2440 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2435, v_t_2439)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2440});
    } else {
      V v_t_2441 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2442;
      if ((heff_intEq_c(heff_intMod(heff_dup(v_a_242), heff_dup(v_b_243)), MK_INT(0LL)) ? 0 : (heff_intLt_c_lent(v_a_242, MK_INT(0LL), 2) ? heff_intLe_c_lent(MK_INT(0LL), v_b_243, 1) : heff_intLt_c_lent(v_b_243, MK_INT(0LL), 2)))) {
        v_t_2442 = heff_intAdd(heff_intDiv(heff_dup(v_a_242), heff_dup(v_b_243)), MK_INT(1LL));
      } else {
        v_t_2442 = heff_intDiv(heff_dup(v_a_242), heff_dup(v_b_243));
      }
      V v_t_2443 = heff_intSub(v_a_242, heff_intMul(v_b_243, v_t_2442));
      V v_t_2444 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_2445;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_2445 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_2445 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_2445 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_2445 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_2445 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_2445 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_2445 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_2445 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_2445 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_2446 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2445));
      V v_t_2447 = heff_intMod(heff_intSub(v_t_2443, v_t_2444), v_t_2446);
      V v_t_2448 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2441, v_t_2447)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2448});
    }
  }
  case TAG_OpEq: {
    heff_drop(v_w_240);
    V v_t_2449;
    if (heff_intEq_c(v_a_242, v_b_243)) {
      v_t_2449 = ((V)&g_heff_2ecompile_2einterp_2efixedInt2_str0);
    } else {
      v_t_2449 = ((V)&g_heff_2ecompile_2einterp_2efixedInt2_str1);
    }
    V v_t_2450 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2450});
  }
  case TAG_OpLt: {
    heff_drop(v_w_240);
    V v_t_2451;
    if (heff_intLt_c(v_a_242, v_b_243)) {
      v_t_2451 = ((V)&g_heff_2ecompile_2einterp_2efixedInt2_str2);
    } else {
      v_t_2451 = ((V)&g_heff_2ecompile_2einterp_2efixedInt2_str3);
    }
    V v_t_2452 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2452});
  }
  case TAG_OpLe: {
    heff_drop(v_w_240);
    V v_t_2453;
    if (heff_intLe_c(v_a_242, v_b_243)) {
      v_t_2453 = ((V)&g_heff_2ecompile_2einterp_2efixedInt2_str4);
    } else {
      v_t_2453 = ((V)&g_heff_2ecompile_2einterp_2efixedInt2_str5);
    }
    V v_t_2454 = heff_tag_n(TAG_VTag, 2, (V[]){v_t_2453, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2454});
  }
  case TAG_OpAnd: {
    V v_w_2455 = v_w_240;
    V v_a_2456 = v_a_242;
    V v_b_2457 = v_b_243;
    V v_t_2458;
    switch (heff_tag_of(v_w_2455)) {
    case TAG_I8: {
      v_t_2458 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2458 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2458 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2458 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2458 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2458 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2458 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2458 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2458 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2455);
    }
    V v_t_2459;
    switch (heff_tag_of(v_w_2455)) {
    case TAG_I8: {
      v_t_2459 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2459 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2459 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2459 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2459 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2459 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2459 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2459 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2459 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2455);
    }
    V v_t_2460 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2459));
    V v_t_2461;
    switch (heff_tag_of(v_w_2455)) {
    case TAG_I8: {
      v_t_2461 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2461 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2461 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2461 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2461 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2461 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2461 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2455);
    }
    V v_t_2462 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2461));
    V v_n_2463 = (g_heff_2ecompile_2einterp_2ebitwise_24s1499070346x2018626103(v_t_2458, heff_intMod(v_a_2456, v_t_2460), heff_intMod(v_b_2457, v_t_2462)));
    V v_t_2464 = (g_heff_2eelab_2efixed_2efixedMin(v_w_2455));
    V v_t_2465 = (g_heff_2eelab_2efixed_2efixedMin(v_w_2455));
    V v_t_2466;
    switch (heff_tag_of(v_w_2455)) {
    case TAG_I8: {
      v_t_2466 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2466 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2466 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2466 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2466 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2466 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2466 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2466 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2466 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2455);
    }
    V v_t_2467 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2466));
    V v_t_2468 = heff_intMod(heff_intSub(v_n_2463, v_t_2465), v_t_2467);
    V v_t_2469 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2464, v_t_2468)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2469});
  }
  case TAG_OpOr: {
    V v_lit_2470 = MK_INT(0LL);
    V v_lit_2471 = MK_INT(1LL);
    V v_lit_2472 = MK_INT(0LL);
    V v_w_2473 = v_w_240;
    V v_a_2474 = v_a_242;
    V v_b_2475 = v_b_243;
    V v_t_2476;
    switch (heff_tag_of(v_w_2473)) {
    case TAG_I8: {
      v_t_2476 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2476 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2476 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2476 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2476 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2476 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2476 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2476 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2476 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2473);
    }
    V v_t_2477;
    switch (heff_tag_of(v_w_2473)) {
    case TAG_I8: {
      v_t_2477 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2477 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2477 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2477 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2477 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2477 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2477 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2477 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2477 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2473);
    }
    V v_t_2478 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2477));
    V v_t_2479;
    switch (heff_tag_of(v_w_2473)) {
    case TAG_I8: {
      v_t_2479 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2479 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2479 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2479 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2479 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2479 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2479 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2479 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2479 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2473);
    }
    V v_t_2480 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2479));
    V v_n_2481 = (g_heff_2ecompile_2einterp_2ebitwise_24s412137238x677449340(v_lit_2470, v_lit_2471, v_lit_2472, v_t_2476, heff_intMod(v_a_2474, v_t_2478), heff_intMod(v_b_2475, v_t_2480)));
    V v_t_2482 = (g_heff_2eelab_2efixed_2efixedMin(v_w_2473));
    V v_t_2483 = (g_heff_2eelab_2efixed_2efixedMin(v_w_2473));
    V v_t_2484;
    switch (heff_tag_of(v_w_2473)) {
    case TAG_I8: {
      v_t_2484 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2484 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2484 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2484 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2484 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2484 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2484 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2484 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2484 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2473);
    }
    V v_t_2485 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2484));
    V v_t_2486 = heff_intMod(heff_intSub(v_n_2481, v_t_2483), v_t_2485);
    V v_t_2487 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2482, v_t_2486)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_2487});
  }
  case TAG_OpXor: {
    V v_lit_2488 = MK_INT(2LL);
    V v_w_2489 = v_w_240;
    V v_a_2490 = v_a_242;
    V v_b_2491 = v_b_243;
    V v_t_2492;
    switch (heff_tag_of(v_w_2489)) {
    case TAG_I8: {
      v_t_2492 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2492 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2492 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2492 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2492 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2492 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2492 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2492 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2492 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2489);
    }
    V v_t_2493;
    switch (heff_tag_of(v_w_2489)) {
    case TAG_I8: {
      v_t_2493 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2493 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2493 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2493 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2493 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2493 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2493 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2493 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2493 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2489);
    }
    V v_t_2494 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2493));
    V v_t_2495;
    switch (heff_tag_of(v_w_2489)) {
    case TAG_I8: {
      v_t_2495 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_2495 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_2495 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_2495 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_2495 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_2495 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_2495 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_2495 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_2495 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2489);
    }
    V v_t_2496 = (g_heff_2eelab_2efixed_2etwoTo(v_t_2495));
    V v_n_2497 = (g_heff_2ecompile_2einterp_2ebitwise_24s612837565x2144654581(v_lit_2488, v_t_2492, heff_intMod(v_a_2490, v_t_2494), heff_intMod(v_b_2491, v_t_2496)));
    V v_t_2498 = (g_heff_2eelab_2efixed_2efixedMin(v_w_2489));
    V v_t_2499 = (g_heff_2eelab_2efixed_2efixedMin(v_w_2489));
    V v_t_24100;
    switch (heff_tag_of(v_w_2489)) {
    case TAG_I8: {
      v_t_24100 = MK_INT(8LL);
      break;
    }
    case TAG_I16: {
      v_t_24100 = MK_INT(16LL);
      break;
    }
    case TAG_I32: {
      v_t_24100 = MK_INT(32LL);
      break;
    }
    case TAG_I64: {
      v_t_24100 = MK_INT(64LL);
      break;
    }
    case TAG_U8: {
      v_t_24100 = MK_INT(8LL);
      break;
    }
    case TAG_U16: {
      v_t_24100 = MK_INT(16LL);
      break;
    }
    case TAG_U32: {
      v_t_24100 = MK_INT(32LL);
      break;
    }
    case TAG_U64: {
      v_t_24100 = MK_INT(64LL);
      break;
    }
    case TAG_F32: {
      v_t_24100 = MK_INT(32LL);
      break;
    }
    default: heff_nomatch(v_w_2489);
    }
    V v_t_24101 = (g_heff_2eelab_2efixed_2etwoTo(v_t_24100));
    V v_t_24102 = heff_intMod(heff_intSub(v_n_2497, v_t_2499), v_t_24101);
    V v_t_24103 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_2498, v_t_24102)});
    return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24103});
  }
  case TAG_OpShl: {
    if (heff_intLt_c_lent(v_b_243, MK_INT(0LL), 2)) {
      V v_t_24104;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_24104 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_24104 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_24104 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_24104 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_24104 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_24104 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_24104 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_24104 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_24104 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_24105 = heff_intMod(heff_intSub(MK_INT(0LL), v_b_243), v_t_24104);
      V v_t_24106 = (g_heff_2eelab_2efixed_2etwoTo(v_t_24105));
      V v_t_24107 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_242, v_t_24106)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24107});
    } else {
      V v_t_24108;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_24108 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_24108 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_24108 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_24108 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_24108 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_24108 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_24108 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_24108 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_24108 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_24109 = (g_heff_2eelab_2efixed_2etwoTo(heff_intMod(v_b_243, v_t_24108)));
      V v_n_24110 = heff_intMul(v_a_242, v_t_24109);
      V v_t_24111 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_24112 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_24113;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_24113 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_24113 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_24113 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_24113 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_24113 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_24113 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_24113 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_24113 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_24113 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_24114 = (g_heff_2eelab_2efixed_2etwoTo(v_t_24113));
      V v_t_24115 = heff_intMod(heff_intSub(v_n_24110, v_t_24112), v_t_24114);
      V v_t_24116 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_24111, v_t_24115)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24116});
    }
  }
  case TAG_OpShr: {
    if (heff_intLt_c_lent(v_b_243, MK_INT(0LL), 2)) {
      V v_t_24117;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_24117 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_24117 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_24117 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_24117 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_24117 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_24117 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_24117 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_24117 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_24117 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_24118 = heff_intMod(heff_intSub(MK_INT(0LL), v_b_243), v_t_24117);
      V v_t_24119 = (g_heff_2eelab_2efixed_2etwoTo(v_t_24118));
      V v_n_24120 = heff_intMul(v_a_242, v_t_24119);
      V v_t_24121 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_24122 = (g_heff_2eelab_2efixed_2efixedMin(v_w_240));
      V v_t_24123;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_24123 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_24123 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_24123 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_24123 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_24123 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_24123 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_24123 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_24123 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_24123 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_24124 = (g_heff_2eelab_2efixed_2etwoTo(v_t_24123));
      V v_t_24125 = heff_intMod(heff_intSub(v_n_24120, v_t_24122), v_t_24124);
      V v_t_24126 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intAdd(v_t_24121, v_t_24125)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24126});
    } else {
      V v_t_24127;
      switch (heff_tag_of(v_w_240)) {
      case TAG_I8: {
        v_t_24127 = MK_INT(8LL);
        break;
      }
      case TAG_I16: {
        v_t_24127 = MK_INT(16LL);
        break;
      }
      case TAG_I32: {
        v_t_24127 = MK_INT(32LL);
        break;
      }
      case TAG_I64: {
        v_t_24127 = MK_INT(64LL);
        break;
      }
      case TAG_U8: {
        v_t_24127 = MK_INT(8LL);
        break;
      }
      case TAG_U16: {
        v_t_24127 = MK_INT(16LL);
        break;
      }
      case TAG_U32: {
        v_t_24127 = MK_INT(32LL);
        break;
      }
      case TAG_U64: {
        v_t_24127 = MK_INT(64LL);
        break;
      }
      case TAG_F32: {
        v_t_24127 = MK_INT(32LL);
        break;
      }
      default: heff_nomatch(v_w_240);
      }
      V v_t_24128 = (g_heff_2eelab_2efixed_2etwoTo(heff_intMod(v_b_243, v_t_24127)));
      V v_t_24129 = heff_tag_n(TAG_VInt, 1, (V[]){heff_intDiv(v_a_242, v_t_24128)});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24129});
    }
  }
  case TAG_OpShow: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24130 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str6), v_t_24130)});
  }
  case TAG_OpFromInt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24131 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str7), v_t_24131)});
  }
  case TAG_OpToInt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24132 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str8), v_t_24132)});
  }
  case TAG_OpSqrt: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24133 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str9), v_t_24133)});
  }
  case TAG_OpFromFloat: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24134 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str10), v_t_24134)});
  }
  case TAG_OpToFloat: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24135 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str11), v_t_24135)});
  }
  case TAG_OpFloor: {
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    V v_t_24136 = (g_heff_2eelab_2efixed_2efixedPrimName(heff_rec_n(2, shape_fixed__op, (V[]){v_w_240, v_op_241})));
    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2efixedInt2_str12), v_t_24136)});
  }
  default: return heff_nomatch(v_op_241);
  }
}
V g_heff_2ecompile_2einterp_2efixedInt2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2efixedInt2(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_st;
static V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_st)) return g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_val;
  return heff_global(&g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_val, &g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_st, g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_init);
}
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VFloat: {
        double v_a_2413 = heff_tflat_f64(v_v_245, 0);
        heff_take_na(v_v_245, 0ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VFloat: {
          double v_b_2419 = heff_tflat_f64(v_v_247, 0);
          heff_take_na(v_v_247, 0ULL, 1);
          V v_t_2420 = heff_tag_at_nf(v_ru_24x1_246_24Ok, TAG_VFloat, 1, 1u, (V[]){heff_word_f64((v_a_2413 + v_b_2419))});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2420});
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBytes: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBytes: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotAFloat64_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2efloat2_24s796759719x1811396793_lam1, 2, 1, (V[]){v_a_241})})});
}
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam0(V self, V *args); static Clo g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam0, 2, 0};

static V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_val;
static HEFF_ONCE g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_st;
static V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_init(void) {
  return heff_tag_n(TAG_VFun, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam0_clo)});
}
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_st)) return g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_val;
  return heff_global(&g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_val, &g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_st, g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_init);
}
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam1(V self, V *args) {
  V v_d_242 = args[0];
  V v_b_243 = args[1];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_244 = heff_tr(heff_call(v_a_241, 1, (V[]){heff_dup(v_d_242)}));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Ok: {
    V v_v_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Ok = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_246 = heff_tr(heff_call(v_b_243, 1, (V[]){v_d_242}));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_Ok: {
      V v_v_247 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Ok = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      switch (heff_tag_of(v_v_245)) {
      case TAG_VFun: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VCons: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VTag: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VInt: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat: {
        heff_take_na(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VFloat32: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VStr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VRune: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VArr: {
        heff_take_n(v_v_245, 0ULL, 1);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VBytes: {
        V v_a_2418 = heff_field(v_v_245, 0);
        heff_take_n(v_v_245, 1ULL, 1);
        switch (heff_tag_of(v_v_247)) {
        case TAG_VFun: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VCons: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VTag: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VInt: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat: {
          heff_take_na(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VFloat32: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VStr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VRune: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VArr: {
          heff_take_n(v_v_247, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VBytes: {
          V v_b_2429 = heff_field(v_v_247, 0);
          heff_take_n(v_v_247, 1ULL, 1);
          V v_t_2430 = heff_tag_at_n(v_ru_24x1_246_24Ok, TAG_VBytes, 1, (V[]){heff_strAppend(v_a_2418, v_b_2429)});
          return heff_tag_at_n(v_ru_24x1_244_24Ok, TAG_Ok, 1, (V[]){v_t_2430});
        }
        case TAG_VBits: {
          heff_take_n(v_v_247, 0ULL, 2);
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        case TAG_VErased: {
          heff_drop_cell(v_ru_24x1_244_24Ok, 1);
          heff_drop_cell(v_ru_24x1_246_24Ok, 1);
          heff_drop(v_a_2418);
          return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
        }
        default: return heff_nomatch(v_v_247);
        }
      }
      case TAG_VBits: {
        heff_take_n(v_v_245, 0ULL, 2);
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      case TAG_VErased: {
        heff_drop_cell(v_ru_24x1_244_24Ok, 1);
        heff_drop(v_v_247);
        heff_drop_cell(v_ru_24x1_246_24Ok, 1);
        return heff_dup(g_heff_2ecompile_2einterp_2enotBytes_get());
      }
      default: return heff_nomatch(v_v_245);
      }
    }
    case TAG_Abn: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Abn);
    }
    case TAG_Div: {
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return NTAG(TAG_Div);
    }
    case TAG_Bug: {
      V v_what_2435 = heff_field(v_x1_246, 0);
      V v_ru_24x1_246_24Bug = heff_take_reuse_n(v_x1_246, 1ULL, 1);
      heff_drop(v_v_245);
      heff_drop_cell(v_ru_24x1_244_24Ok, 1);
      return heff_tag_at_n(v_ru_24x1_246_24Bug, TAG_Bug, 1, (V[]){v_what_2435});
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  case TAG_Abn: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Abn);
  }
  case TAG_Div: {
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return NTAG(TAG_Div);
  }
  case TAG_Bug: {
    V v_what_2436 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Bug = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_d_242);
    heff_drop(v_b_243);
    return heff_tag_at_n(v_ru_24x1_244_24Bug, TAG_Bug, 1, (V[]){v_what_2436});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_a_241 = args[1];
  heff_drop(v_d_240);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2ebytes2_24s1550080933x1828439405_lam1, 2, 1, (V[]){v_a_241})})});
}
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str0, 6, "local ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str1, 16, " is not in scope");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str2, 16, " is not in scope");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str3, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str4, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str5, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str6, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str7, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str8, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str9, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str10, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str11, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str12, 30, "applied what is not a function");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str13, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str14, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str15, 1, "_");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str16, 12, "no case for ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str17, 12, "no case for ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str18, 1, "_");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str19, 12, "no case for ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str20, 12, "no case for ");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str21, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str22, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str23, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str24, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str25, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str26, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str27, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str28, 27, "a case of what is not a tag");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str29, 28, "a term that is not evaluated");
HEFF_LIT(g_heff_2ecompile_2einterp_2eevalIn_str30, 28, "a term that is not evaluated");
V g_heff_2ecompile_2einterp_2eevalIn_lam0(V self, V *args);
V g_heff_2ecompile_2einterp_2eevalIn_lam1(V self, V *args);
V g_heff_2ecompile_2einterp_2eevalIn_lam2(V self, V *args);
V g_heff_2ecompile_2einterp_2eevalIn_lam3(V self, V *args);
V g_heff_2ecompile_2einterp_2eevalIn_lam4(V self, V *args); static Clo g_heff_2ecompile_2einterp_2eevalIn_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalIn_lam4, 1, 0};
V g_heff_2ecompile_2einterp_2eevalIn_lam5(V self, V *args);
V g_heff_2ecompile_2einterp_2eevalIn_lam6(V self, V *args);
V g_heff_2ecompile_2einterp_2eevalIn_lam7(V self, V *args);
Clo g_heff_2ecompile_2einterp_2eevalIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2einterp_2eevalIn_entry, 3, 0};

V g_heff_2ecompile_2einterp_2eevalIn(V v_d_240, V v_e_241, V v_t_242) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(1099512727287627776LL), v_d_240, 1) || (((int64_t)100000000ULL) < heff_unbox_word(heff_intMod(heff_dup(v_d_240), MK_INT(1099511627776LL)))))) {
    heff_drop(v_d_240);
    heff_drop_rec(v_e_241, 2);
    heff_drop(v_t_242);
    return NTAG(TAG_Div);
  } else {
    switch (heff_tag_of(v_t_242)) {
    case TAG_SLocal: {
      V v_i_243 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLocal = heff_take_reuse_n(v_t_242, 1ULL, 1);
      HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_e_241, 0, 2); V a_1 = heff_dup(v_i_243); HeffT2 r_ = (g_heff_2ecompile_2einterp_2enthTh_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          heff_drop(v_i_243);
          heff_drop_cell(v_ru_24t_242_24SLocal, 1);
          V v_v_247 = v_field_246;
          return heff_tail(v_v_247, 1, (V[]){v_d_240});
        } else {
          heff_drop(v_d_240);
          heff_drop(v_field_246);
          V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eevalIn_str0), heff_intShow(v_i_243));
          return heff_tag_at_n(v_ru_24t_242_24SLocal, TAG_Bug, 1, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2einterp_2eevalIn_str1))});
        }
      }
    }
    case TAG_SGlobal: {
      V v_x_249 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SGlobal = heff_take_reuse_n(v_t_242, 1ULL, 1);
      HeffT2 v_t_2410 = ({ V b_0 = heff_get_n(v_e_241, 1, 2); V a_1 = v_x_249; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        if ((v_tag_2411 == ((int64_t)0ULL))) {
          heff_drop(v_x_249);
          heff_drop_cell(v_ru_24t_242_24SGlobal, 1);
          V v_v_2413 = v_field_2412;
          return heff_tail(v_v_2413, 1, (V[]){v_d_240});
        } else {
          heff_drop(v_d_240);
          heff_drop(v_field_2412);
          return heff_tag_at_n(v_ru_24t_242_24SGlobal, TAG_Bug, 1, (V[]){heff_strAppend(v_x_249, ((V)&g_heff_2ecompile_2einterp_2eevalIn_str2))});
        }
      }
    }
    case TAG_SCode: {
      V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_at_n(v_ru_24t_242_24SCode, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SApp: {
      V v_t1_2415 = heff_field(v_t_242, 0);
      V v_t2_2416 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_t_2417 = heff_intAdd(heff_intAdd(heff_dup(v_d_240), MK_INT(1099511627776LL)), MK_INT(1LL));
      V v_x1_2418 = heff_tr(g_heff_2ecompile_2einterp_2eevalIn(v_t_2417, heff_dup(v_e_241), v_t1_2415));
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_Ok: {
        V v_v_2419 = heff_field(v_x1_2418, 0);
        V v_ru_24x1_2418_24Ok = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
        V v_t_2420 = heff_intAdd(heff_intAdd(heff_dup(v_d_240), MK_INT(1099511627776LL)), MK_INT(1LL));
        V v_x1_2421 = heff_tr(g_heff_2ecompile_2einterp_2eevalIn(v_t_2420, v_e_241, v_t2_2416));
        switch (heff_tag_of(v_x1_2421)) {
        case TAG_Ok: {
          V v_v_2422 = heff_field(v_x1_2421, 0);
          V v_ru_24x1_2421_24Ok = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
          switch (heff_tag_of(v_v_2419)) {
          case TAG_VFun: {
            V v_f_2423 = heff_field(v_v_2419, 0);
            heff_take_n(v_v_2419, 1ULL, 1);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
            return heff_tail(v_f_2423, 2, (V[]){v_d_240, heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam0, 1, 1, (V[]){v_v_2422})});
          }
          case TAG_VCons: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str3)});
          }
          case TAG_VTag: {
            heff_take_n(v_v_2419, 0ULL, 2);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str4)});
          }
          case TAG_VInt: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str5)});
          }
          case TAG_VFloat: {
            heff_take_na(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str6)});
          }
          case TAG_VFloat32: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str7)});
          }
          case TAG_VStr: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str8)});
          }
          case TAG_VRune: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str9)});
          }
          case TAG_VArr: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str10)});
          }
          case TAG_VBytes: {
            heff_take_n(v_v_2419, 0ULL, 1);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str11)});
          }
          case TAG_VBits: {
            heff_take_n(v_v_2419, 0ULL, 2);
            heff_drop(v_d_240);
            heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
            heff_drop(v_v_2422);
            return heff_tag_at_n(v_ru_24x1_2421_24Ok, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str12)});
          }
          case TAG_VErased: {
            heff_drop(v_d_240);
            heff_drop(v_v_2422);
            heff_drop_cell(v_ru_24x1_2421_24Ok, 1);
            return heff_tag_at_n(v_ru_24x1_2418_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
          }
          default: return heff_nomatch(v_v_2419);
          }
        }
        case TAG_Abn: {
          heff_drop(v_d_240);
          heff_drop(v_v_2419);
          heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
          return NTAG(TAG_Abn);
        }
        case TAG_Div: {
          heff_drop(v_d_240);
          heff_drop(v_v_2419);
          heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
          return NTAG(TAG_Div);
        }
        case TAG_Bug: {
          V v_what_2437 = heff_field(v_x1_2421, 0);
          V v_ru_24x1_2421_24Bug = heff_take_reuse_n(v_x1_2421, 1ULL, 1);
          heff_drop(v_d_240);
          heff_drop(v_v_2419);
          heff_drop_cell(v_ru_24x1_2418_24Ok, 1);
          return heff_tag_at_n(v_ru_24x1_2421_24Bug, TAG_Bug, 1, (V[]){v_what_2437});
        }
        default: return heff_nomatch(v_x1_2421);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop_rec(v_e_241, 2);
        heff_drop(v_t2_2416);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop_rec(v_e_241, 2);
        heff_drop(v_t2_2416);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_2438 = heff_field(v_x1_2418, 0);
        V v_ru_24x1_2418_24Bug = heff_take_reuse_n(v_x1_2418, 1ULL, 1);
        heff_drop(v_d_240);
        heff_drop_rec(v_e_241, 2);
        heff_drop(v_t2_2416);
        return heff_tag_at_n(v_ru_24x1_2418_24Bug, TAG_Bug, 1, (V[]){v_what_2438});
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    case TAG_SLam: {
      V v_it2_2440 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_240);
      switch (heff_tag_of(v_it2_2440)) {
      case TAG_MkAbs: {
        V v_body_2442 = heff_field(v_it2_2440, 1);
        heff_take_n(v_it2_2440, 2ULL, 2);
        return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam1, 2, 2, (V[]){v_e_241, v_body_2442})})});
      }
      case TAG_AbsConst: {
        V v_body_2447 = heff_field(v_it2_2440, 0);
        V v_ru_24it2_2440_24AbsConst = heff_take_reuse_n(v_it2_2440, 1ULL, 1);
        return heff_tag_at_n(v_ru_24it2_2440_24AbsConst, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VFun, 1, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam2, 2, 2, (V[]){v_e_241, v_body_2447})})});
      }
      default: return heff_nomatch(v_it2_2440);
      }
    }
    case TAG_SCons: {
      V v_fs_2450 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V v_keys_2451 = heff_take_field(v_fs_2450, 0);
      V v_values_2452 = heff_get_n(v_fs_2450, 2, 3);
      V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2451), heff_arrayToList(v_values_2452)));
      HEFF_LAST return g_heff_2ecompile_2einterp_2eevalFields(heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam3, 1, 2, (V[]){v_d_240, v_e_241}), v_t_2453, ((V)&g_heff_2ecompile_2einterp_2eevalIn_lam4_clo));
    }
    case TAG_SProj: {
      V v_t2_2461 = heff_field(v_t_242, 0);
      V v_x_2462 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_t_2463 = heff_intAdd(heff_intAdd(v_d_240, MK_INT(1099511627776LL)), MK_INT(1LL));
      V v_x1_2464 = heff_tr(g_heff_2ecompile_2einterp_2eevalIn(v_t_2463, v_e_241, v_t2_2461));
      switch (heff_tag_of(v_x1_2464)) {
      case TAG_Ok: {
        V v_v_2465 = heff_field(v_x1_2464, 0);
        V v_ru_24x1_2464_24Ok = heff_take_reuse_n(v_x1_2464, 1ULL, 1);
        HEFF_LAST return g_heff_2ecompile_2einterp_2eprojV_24tok1(v_ru_24x1_2464_24Ok, v_v_2465, v_x_2462);
      }
      case TAG_Abn: {
        heff_drop(v_x_2462);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_x_2462);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_2466 = heff_field(v_x1_2464, 0);
        V v_ru_24x1_2464_24Bug = heff_take_reuse_n(v_x1_2464, 1ULL, 1);
        heff_drop(v_x_2462);
        return heff_tag_at_n(v_ru_24x1_2464_24Bug, TAG_Bug, 1, (V[]){v_what_2466});
      }
      default: return heff_nomatch(v_x1_2464);
      }
    }
    case TAG_STag: {
      V v_x_2467 = heff_field(v_t_242, 0);
      V v_ts_2468 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      HEFF_LAST return g_heff_2ecompile_2einterp_2eevalEach(heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam5, 1, 2, (V[]){v_d_240, v_e_241}), heff_arrayToList(v_ts_2468), heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam6, 1, 1, (V[]){v_x_2467}));
    }
    case TAG_SMatch: {
      V v_scrut_2472 = heff_field(v_t_242, 0);
      V v_cases_2473 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 3ULL, 2);
      V v_byName_2474 = heff_take_field(v_cases_2473, 1);
      V v_values_2475 = heff_get_n(v_cases_2473, 2, 3);
      V v_t_2476 = heff_intAdd(heff_intAdd(heff_dup(v_d_240), MK_INT(1099511627776LL)), MK_INT(1LL));
      V v_x1_2477 = heff_tr(g_heff_2ecompile_2einterp_2eevalIn(v_t_2476, heff_dup(v_e_241), v_scrut_2472));
      switch (heff_tag_of(v_x1_2477)) {
      case TAG_Ok: {
        V v_v_2478 = heff_field(v_x1_2477, 0);
        V v_ru_24x1_2477_24Ok = heff_take_reuse_n(v_x1_2477, 1ULL, 1);
        switch (heff_tag_of(v_v_2478)) {
        case TAG_VFun: {
          V v_ru_24v_2478_24VFun = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VFun, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str13)});
        }
        case TAG_VCons: {
          V v_ru_24v_2478_24VCons = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VCons, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str14)});
        }
        case TAG_VTag: {
          V v_x_2481 = heff_field(v_v_2478, 0);
          V v_vs_2482 = heff_field(v_v_2478, 1);
          heff_take_n(v_v_2478, 3ULL, 2);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          HeffT2 v_t_2483 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_byName_2474, v_x_2481));
          {
            V v_field_2485 = v_t_2483.f[1];
            int64_t v_tag_2484 = ((int64_t)v_t_2483.f[0]);
            if ((v_tag_2484 == ((int64_t)0ULL))) {
              V v_i_2486 = v_field_2485;
              V v_xs_2487 = heff_dup(v_values_2475);
              if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2486, 1) && heff_intLt_c(heff_dup(v_i_2486), heff_arrayLength_lent(v_xs_2487, 0)))) {
                heff_drop(v_byName_2474);
                heff_drop(v_values_2475);
                heff_drop(v_x_2481);
                V v_t_2488 = heff_arrayIndex(v_xs_2487, v_i_2486);
                switch (heff_tag_of(v_t_2488)) {
                case TAG_MkPair: {
                  V v_body_2490 = heff_field(v_t_2488, 1);
                  heff_take_n(v_t_2488, 2ULL, 2);
                  V v_t_2491 = (g_list_2efoldl_24s1344708576x2031305372(v_e_241, v_vs_2482));
                  V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
                  V t_1 = v_t_2491;
                  V t_2 = v_body_2490;
                  v_d_240 = t_0;
                  v_e_241 = t_1;
                  v_t_242 = t_2;
                  goto top;
                }
                default: return heff_nomatch(v_t_2488);
                }
              } else {
                heff_drop(v_vs_2482);
                heff_drop(v_i_2486);
                heff_drop(v_xs_2487);
                HeffT2 v_t_2492 = ({ V a_0 = v_byName_2474; V b_1 = ((V)&g_heff_2ecompile_2einterp_2eevalIn_str15); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_byName_2474); heff_drop(b_1); r_; });
                {
                  V v_field_2494 = v_t_2492.f[1];
                  int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                  if ((v_tag_2493 == ((int64_t)0ULL))) {
                    V v_i_2495 = v_field_2494;
                    V v_xs_2496 = v_values_2475;
                    if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2495, 1) && heff_intLt_c(heff_dup(v_i_2495), heff_arrayLength_lent(v_xs_2496, 0)))) {
                      heff_drop(v_x_2481);
                      V v_t_2497 = heff_arrayIndex(v_xs_2496, v_i_2495);
                      switch (heff_tag_of(v_t_2497)) {
                      case TAG_MkPair: {
                        V v_body_2499 = heff_field(v_t_2497, 1);
                        heff_take_n(v_t_2497, 2ULL, 2);
                        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
                        V t_1 = v_e_241;
                        V t_2 = v_body_2499;
                        v_d_240 = t_0;
                        v_e_241 = t_1;
                        v_t_242 = t_2;
                        goto top;
                      }
                      default: return heff_nomatch(v_t_2497);
                      }
                    } else {
                      heff_drop(v_d_240);
                      heff_drop_rec(v_e_241, 2);
                      heff_drop(v_i_2495);
                      heff_drop(v_xs_2496);
                      return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eevalIn_str16), v_x_2481)});
                    }
                  } else {
                    heff_drop(v_d_240);
                    heff_drop_rec(v_e_241, 2);
                    heff_drop(v_values_2475);
                    heff_drop(v_field_2494);
                    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eevalIn_str17), v_x_2481)});
                  }
                }
              }
            } else {
              heff_drop(v_vs_2482);
              heff_drop(v_field_2485);
              HeffT2 v_t_24100 = ({ V a_0 = v_byName_2474; V b_1 = ((V)&g_heff_2ecompile_2einterp_2eevalIn_str18); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, b_1)); heff_drop(v_byName_2474); heff_drop(b_1); r_; });
              {
                V v_field_24102 = v_t_24100.f[1];
                int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                if ((v_tag_24101 == ((int64_t)0ULL))) {
                  V v_i_24103 = v_field_24102;
                  V v_xs_24104 = v_values_2475;
                  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_24103, 1) && heff_intLt_c(heff_dup(v_i_24103), heff_arrayLength_lent(v_xs_24104, 0)))) {
                    heff_drop(v_x_2481);
                    V v_t_24105 = heff_arrayIndex(v_xs_24104, v_i_24103);
                    switch (heff_tag_of(v_t_24105)) {
                    case TAG_MkPair: {
                      V v_body_24107 = heff_field(v_t_24105, 1);
                      heff_take_n(v_t_24105, 2ULL, 2);
                      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
                      V t_1 = v_e_241;
                      V t_2 = v_body_24107;
                      v_d_240 = t_0;
                      v_e_241 = t_1;
                      v_t_242 = t_2;
                      goto top;
                    }
                    default: return heff_nomatch(v_t_24105);
                    }
                  } else {
                    heff_drop(v_d_240);
                    heff_drop_rec(v_e_241, 2);
                    heff_drop(v_i_24103);
                    heff_drop(v_xs_24104);
                    return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eevalIn_str19), v_x_2481)});
                  }
                } else {
                  heff_drop(v_d_240);
                  heff_drop_rec(v_e_241, 2);
                  heff_drop(v_values_2475);
                  heff_drop(v_field_24102);
                  return heff_tag_n(TAG_Bug, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2einterp_2eevalIn_str20), v_x_2481)});
                }
              }
            }
          }
        }
        case TAG_VInt: {
          V v_ru_24v_2478_24VInt = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VInt, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str21)});
        }
        case TAG_VFloat: {
          V v_ru_24v_2478_24VFloat = heff_take_reuse_na(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VFloat, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str22)});
        }
        case TAG_VFloat32: {
          V v_ru_24v_2478_24VFloat32 = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VFloat32, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str23)});
        }
        case TAG_VStr: {
          V v_ru_24v_2478_24VStr = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VStr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str24)});
        }
        case TAG_VRune: {
          V v_ru_24v_2478_24VRune = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VRune, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str25)});
        }
        case TAG_VArr: {
          V v_ru_24v_2478_24VArr = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VArr, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str26)});
        }
        case TAG_VBytes: {
          V v_ru_24v_2478_24VBytes = heff_take_reuse_n(v_v_2478, 0ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_at_n(v_ru_24v_2478_24VBytes, TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str27)});
        }
        case TAG_VBits: {
          heff_take_n(v_v_2478, 0ULL, 2);
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          heff_drop_cell(v_ru_24x1_2477_24Ok, 1);
          return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str28)});
        }
        case TAG_VErased: {
          heff_drop(v_d_240);
          heff_drop_rec(v_e_241, 2);
          heff_drop(v_byName_2474);
          heff_drop(v_values_2475);
          return heff_tag_at_n(v_ru_24x1_2477_24Ok, TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
        }
        default: return heff_nomatch(v_v_2478);
        }
      }
      case TAG_Abn: {
        heff_drop(v_d_240);
        heff_drop_rec(v_e_241, 2);
        heff_drop(v_byName_2474);
        heff_drop(v_values_2475);
        return NTAG(TAG_Abn);
      }
      case TAG_Div: {
        heff_drop(v_d_240);
        heff_drop_rec(v_e_241, 2);
        heff_drop(v_byName_2474);
        heff_drop(v_values_2475);
        return NTAG(TAG_Div);
      }
      case TAG_Bug: {
        V v_what_24117 = heff_field(v_x1_2477, 0);
        V v_ru_24x1_2477_24Bug = heff_take_reuse_n(v_x1_2477, 1ULL, 1);
        heff_drop(v_d_240);
        heff_drop_rec(v_e_241, 2);
        heff_drop(v_byName_2474);
        heff_drop(v_values_2475);
        return heff_tag_at_n(v_ru_24x1_2477_24Bug, TAG_Bug, 1, (V[]){v_what_24117});
      }
      default: return heff_nomatch(v_x1_2477);
      }
    }
    case TAG_SSpecialize: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_n(TAG_Ok, 1, (V[]){NTAG(TAG_VErased)});
    }
    case TAG_SIs: {
      V v_t2_24121 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_24121;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SOpaque: {
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str29)});
    }
    case TAG_SAbandon: {
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return NTAG(TAG_Abn);
    }
    case TAG_SRec: {
      V v_t2_24122 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_24122;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SFix: {
      V v_ty_24123 = heff_field(v_t_242, 0);
      V v_it2_24124 = heff_field(v_t_242, 1);
      V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
      switch (heff_tag_of(v_it2_24124)) {
      case TAG_MkAbs: {
        V v_x_24125 = heff_field(v_it2_24124, 0);
        V v_body_24126 = heff_field(v_it2_24124, 1);
        heff_take_n(v_it2_24124, 3ULL, 2);
        V v_t_24129 = heff_tag_at_n(v_ru_24t_242_24SFix, TAG_Cons, 2, (V[]){heff_clo_n(g_heff_2ecompile_2einterp_2eevalIn_lam7, 1, 4, (V[]){v_ty_24123, v_x_24125, heff_dup(v_body_24126), heff_dup(v_e_241)}), heff_dup(heff_rfield(v_e_241, 0))});
        V v_t_24130 = ({ V rv_0 = v_t_24129; V rr_ = heff_rec_reuse_nf(v_e_241, 2ULL, 2, shape_local__global, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_t_24130;
        V t_2 = v_body_24126;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      case TAG_AbsConst: {
        V v_body_24131 = heff_field(v_it2_24124, 0);
        heff_take_n(v_it2_24124, 1ULL, 1);
        heff_drop(v_ty_24123);
        heff_drop_cell(v_ru_24t_242_24SFix, 2);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_e_241;
        V t_2 = v_body_24131;
        v_d_240 = t_0;
        v_e_241 = t_1;
        v_t_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_it2_24124);
      }
    }
    case TAG_SImplicit: {
      V v_t2_24133 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
      V t_1 = v_e_241;
      V t_2 = v_t2_24133;
      v_d_240 = t_0;
      v_e_241 = t_1;
      v_t_242 = t_2;
      goto top;
    }
    case TAG_SPrim: {
      V v_x_24134 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SPrim = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      V v_t_24135 = ({ V a_0 = v_x_24134; V r_ = (g_heff_2ecompile_2einterp_2eprim(a_0)); heff_drop(v_x_24134); r_; });
      return heff_tag_at_n(v_ru_24t_242_24SPrim, TAG_Ok, 1, (V[]){v_t_24135});
    }
    case TAG_SMetaApp: {
      heff_take_n(v_t_242, 0ULL, 3);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_n(TAG_Bug, 1, (V[]){((V)&g_heff_2ecompile_2einterp_2eevalIn_str30)});
    }
    case TAG_SLitInt: {
      V v_i_24139 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitInt = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_at_n(v_ru_24t_242_24SLitInt, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_i_24139})});
    }
    case TAG_SLitFloat: {
      double v_x_24140 = heff_tflat_f64(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat = heff_take_reuse_na(v_t_242, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_at_n(v_ru_24t_242_24SLitFloat, TAG_Ok, 1, (V[]){heff_tag_nf(TAG_VFloat, 1, 1u, (V[]){heff_word_f64(v_x_24140)})});
    }
    case TAG_SLitString: {
      V v_s_24141 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitString = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_at_n(v_ru_24t_242_24SLitString, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VStr, 1, (V[]){v_s_24141})});
    }
    case TAG_SLitBytes: {
      V v_s_24142 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitBytes = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_at_n(v_ru_24t_242_24SLitBytes, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VBytes, 1, (V[]){v_s_24142})});
    }
    case TAG_SLitRune: {
      V v_c_24143 = heff_field(v_t_242, 0);
      V v_ru_24t_242_24SLitRune = heff_take_reuse_n(v_t_242, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_at_n(v_ru_24t_242_24SLitRune, TAG_Ok, 1, (V[]){heff_tag_n(TAG_VRune, 1, (V[]){v_c_24143})});
    }
    case TAG_SLitFixed: {
      V v_i_24145 = heff_field(v_t_242, 1);
      heff_take_n(v_t_242, 2ULL, 2);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VInt, 1, (V[]){v_i_24145})});
    }
    case TAG_SLitFloat32: {
      double v_x_24146 = heff_tflat_f64(v_t_242, 0);
      V v_ru_24t_242_24SLitFloat32 = heff_take_reuse_na(v_t_242, 0ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_e_241, 2);
      V v_t_24147 = heff_tag_at_n(v_ru_24t_242_24SLitFloat32, TAG_VFloat32, 1, (V[]){heff_box_f32(((float)v_x_24146))});
      return heff_tag_n(TAG_Ok, 1, (V[]){v_t_24147});
    }
    default: return heff_nomatch(v_t_242);
    }
  }
}
V g_heff_2ecompile_2einterp_2eevalIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2einterp_2eevalIn(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2einterp_2eevalIn_lam0(V self, V *args) {
  V v_d_2424 = args[0];
  V v_v_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_d_2424);
  return heff_tag_n(TAG_Ok, 1, (V[]){v_v_2422});
}
V g_heff_2ecompile_2einterp_2eevalIn_lam1(V self, V *args) {
  V v_dc_2443 = args[0];
  V v_v_2444 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_body_2442 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2445 = heff_tag_n(TAG_Cons, 2, (V[]){v_v_2444, heff_take_field(v_e_241, 0)});
  V v_t_2446 = ({ V rv_0 = v_t_2445; V rr_ = heff_rec_reuse_nf(v_e_241, 2ULL, 2, shape_local__global, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  return (g_heff_2ecompile_2einterp_2eevalIn(heff_intAdd(v_dc_2443, MK_INT(1LL)), v_t_2446, v_body_2442));
}
V g_heff_2ecompile_2einterp_2eevalIn_lam2(V self, V *args) {
  V v_dc_2448 = args[0];
  V v_u_2449 = args[1];
  V v_e_241 = heff_env(self)[0];
  V v_body_2447 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  return (g_heff_2ecompile_2einterp_2eevalIn(heff_intAdd(v_dc_2448, MK_INT(1LL)), v_e_241, v_body_2447));
}
V g_heff_2ecompile_2einterp_2eevalIn_lam3(V self, V *args) {
  V v_t2_2454 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_intAdd(heff_intAdd(v_d_240, MK_INT(1099511627776LL)), MK_INT(1LL));
  return (g_heff_2ecompile_2einterp_2eevalIn(v_t_2455, v_e_241, v_t2_2454));
}
V g_heff_2ecompile_2einterp_2eevalIn_lam4(V self, V *args) {
  V v_vs_2456 = args[0];
  V v_t_2457 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_vs_2456)));
  V v_t_2458 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_vs_2456));
  V v_t_2459 = (g_list_2emap_24s1173914895x100384474(v_vs_2456));
  V v_t_2460 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2457), v_t_2458, heff_arrayFromList(v_t_2459)});
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VCons, 1, (V[]){v_t_2460})});
}
V g_heff_2ecompile_2einterp_2eevalIn_lam5(V self, V *args) {
  V v_t2_2469 = args[0];
  V v_d_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2470 = heff_intAdd(heff_intAdd(v_d_240, MK_INT(1099511627776LL)), MK_INT(1LL));
  return (g_heff_2ecompile_2einterp_2eevalIn(v_t_2470, v_e_241, v_t2_2469));
}
V g_heff_2ecompile_2einterp_2eevalIn_lam6(V self, V *args) {
  V v_vs_2471 = args[0];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Ok, 1, (V[]){heff_tag_n(TAG_VTag, 2, (V[]){v_x_2467, v_vs_2471})});
}
V g_heff_2ecompile_2einterp_2eevalIn_lam7(V self, V *args) {
  V v_dc_24127 = args[0];
  V v_ty_24123 = heff_env(self)[0];
  V v_x_24125 = heff_env(self)[1];
  V v_body_24126 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24128 = heff_tag_n(TAG_SFix, 2, (V[]){v_ty_24123, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_24125, v_body_24126})});
  return (g_heff_2ecompile_2einterp_2eevalIn(v_dc_24127, v_e_241, v_t_24128));
}