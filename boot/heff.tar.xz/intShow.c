// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"

static V g_intShow_val;
static int g_intShow_st;
static V g_intShow_init(void) {
  return ((V)&prim_intShow_clo);
}
V g_intShow_get(void) {
  if (g_intShow_st == 2) return g_intShow_val;
  if (g_intShow_st == 1) heff_fail("defined by itself");
  g_intShow_st = 1;
  g_intShow_val = heff_tr(g_intShow_init());
  g_intShow_st = 2;
  return g_intShow_val;
}