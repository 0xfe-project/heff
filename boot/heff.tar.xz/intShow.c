// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static V prim_intShow_entry(V self, V *a) { (void)self; return heff_intShow(a[0]); }
static Clo prim_intShow_clo = {{0x80000000u, K_CLO, 0}, prim_intShow_entry, 1, 0};
V g_intShow_get(void);

static V g_intShow_val;
static HEFF_ONCE g_intShow_st;
static V g_intShow_init(void) {
  return ((V)&prim_intShow_clo);
}
V g_intShow_get(void) {
  if (HEFF_DONE(g_intShow_st)) return g_intShow_val;
  return heff_global(&g_intShow_val, &g_intShow_st, g_intShow_init);
}