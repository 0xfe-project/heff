// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbandonWord 52431
#define TAG_ArrayWord 24229
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_DeclareField 57313
#define TAG_F32 16337
#define TAG_FixedWord 19198
#define TAG_FloatWord 12460
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_IntWord 51777
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkCatchArm 36970
#define TAG_MkEquation 38417
#define TAG_MkSegment 38079
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_RuneWord 42901
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtBind 30050
#define TAG_StmtExpr 2862
#define TAG_StmtLet 16809
#define TAG_StmtLetMut 50164
#define TAG_StringWord 15530
#define TAG_TypeWord 10401
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_cmt 308164
#define LBL_comments 142722952
#define LBL_decl 9574769
#define LBL_decls 296817955
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_i 323
#define LBL_imports 10411951
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_text 10052084
#define LBL_tok 324554
static uint32_t shape_e__decl[] = {LBL_e, LBL_decl};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
V g_heff_2esyntax_2efmt_2elex_2elexGo(V, V, V, V, V);
V g_heff_2esyntax_2efmt_2elex_2elexGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elex_2elexGo_clo;
V g_heff_2esyntax_2eformat_2ecatchKey(V, V);
V g_heff_2esyntax_2eformat_2ecatchKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ecatchKey_clo;
V g_heff_2esyntax_2eformat_2eequationKey(V, V);
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2eequationKey_clo;
V g_heff_2esyntax_2eformat_2efieldDeclKey(V, V);
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo;
V g_heff_2esyntax_2eformat_2efieldSetKey(V, V);
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo;
V g_heff_2esyntax_2eformat_2ekeyDeclF(V, V);
V g_heff_2esyntax_2eformat_2ekeyDeclF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyDeclF_clo;
V g_heff_2esyntax_2eformat_2ekeyTermF(V, V);
V g_heff_2esyntax_2eformat_2ekeyTermF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2ekeyTermF_clo;
V g_heff_2esyntax_2eformat_2ekeys_get(void);
V g_heff_2esyntax_2eformat_2elamKey(V, V);
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2elamKey_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V, V, V, V);
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(V);
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_clo;
V g_heff_2esyntax_2eformat_2estmtKey(V, V);
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estmtKey_clo;
V g_heff_2esyntax_2eformat_2estrsEq(V, V);
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2estrsEq_clo;
V g_heff_2esyntax_2eimport_2eimportsGo(V, V, V, V);
V g_heff_2esyntax_2eimport_2eimportsGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsGo_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1047941608x1265580215(V, V, V, V, V, V, V);
V g_list_2emap_24s1047941608x1265580215_entry(V self, V *a);
extern Clo g_list_2emap_24s1047941608x1265580215_clo;
V g_list_2emap_24s1561756891x1126436879(V);
V g_list_2emap_24s1561756891x1126436879_entry(V self, V *a);
extern Clo g_list_2emap_24s1561756891x1126436879_clo;
V g_list_2emap_24s2016443462x370533815(V);
V g_list_2emap_24s2016443462x370533815_entry(V self, V *a);
extern Clo g_list_2emap_24s2016443462x370533815_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s313852718x340738167(V, V);
V g_list_2emap_24s313852718x340738167_entry(V self, V *a);
extern Clo g_list_2emap_24s313852718x340738167_clo;
V g_list_2emap_24s903588428x1469638784(V, V);
V g_list_2emap_24s903588428x1469638784_entry(V self, V *a);
extern Clo g_list_2emap_24s903588428x1469638784_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str1, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str2, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str3, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str4, 3, "utf");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str5, 7, "default");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str6, 1, "*");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str7, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str8, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str9, 4, "true");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str10, 5, "false");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str11, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str14, 7, "segment");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str15, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str16, 1, "(");
Clo g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_entry, 1, 0};

V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkSegment: {
      V v_v_243 = heff_field(v_x21_241, 0);
      V v_ty_244 = heff_field(v_x21_241, 1);
      V v_size_245 = heff_field(v_x21_241, 2);
      V v_little_246 = heff_field(v_x21_241, 3);
      V v_signed_247 = heff_field(v_x21_241, 4);
      heff_take_n(v_x21_241, 31ULL, 5);
      V v_t_248 = (g_heff_2esyntax_2eformat_2epatKey(v_v_243));
      V v_t_2410;
      switch (heff_tag_of(v_ty_244)) {
      case TAG_SegmentInteger: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str0);
        break;
      }
      case TAG_SegmentBinary: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str1);
        break;
      }
      case TAG_SegmentBits: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str2);
        break;
      }
      case TAG_SegmentFloat: {
        v_t_2410 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str3);
        break;
      }
      case TAG_SegmentUtf: {
        V v_n_249 = heff_field(v_ty_244, 0);
        heff_take_n(v_ty_244, 1ULL, 1);
        v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str4), heff_intShow(v_n_249));
        break;
      }
      default: heff_nomatch(v_ty_244);
      }
      V v_t_2416;
      switch (heff_tag_of(v_size_245)) {
      case TAG_SizeDefault: {
        v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str5);
        break;
      }
      case TAG_SizeNumber: {
        V v_n_2411 = heff_field(v_size_245, 0);
        heff_take_n(v_size_245, 1ULL, 1);
        v_t_2416 = heff_intShow(v_n_2411);
        break;
      }
      case TAG_SizeName: {
        V v_x_2412 = heff_field(v_size_245, 0);
        V v_unit_2414 = heff_field(v_size_245, 2);
        heff_take_n(v_size_245, 5ULL, 3);
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str6), heff_intShow(v_unit_2414));
        v_t_2416 = heff_strAppend(v_x_2412, v_t_2415);
        break;
      }
      default: heff_nomatch(v_size_245);
      }
      V v_t_2417;
      if ((heff_dup(v_little_246) == NTAG(TAG_True))) {
        heff_drop(v_little_246);
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str7);
      } else {
        heff_drop(v_little_246);
        v_t_2417 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str8);
      }
      V v_t_2418;
      if ((heff_dup(v_signed_247) == NTAG(TAG_True))) {
        heff_drop(v_signed_247);
        v_t_2418 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str9);
      } else {
        heff_drop(v_signed_247);
        v_t_2418 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str10);
      }
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2419})});
      V v_parts_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2420})});
      V v_x2_2422 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str11), v_parts_2421));
      V v_t_2425;
      switch (heff_tag_of(v_x2_2422)) {
      case TAG_Nil: {
        v_t_2425 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str12);
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_x2_2422, 0);
        V v_xs_2424 = heff_field(v_x2_2422, 1);
        heff_take_n(v_x2_2422, 3ULL, 2);
        v_t_2425 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str13); V a_1 = v_x_2423; V a_2 = v_xs_2424; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2424); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2422);
      }
      V v_t_2426 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str14), heff_strAppend(v_t_2425, ((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str15)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_str16), v_t_2426);
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2esegmentKey_24s1945427424x576711064(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str3, 3, "var");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str7, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str8, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str9, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str10, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str11, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str12, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str13, 3, "tag");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str14, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str15, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str16, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str17, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str18, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str19, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str20, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str21, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str22, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str23, 2, "op");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str24, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str25, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str26, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str27, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str28, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str29, 3, "int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str30, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str32, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str33, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str34, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str35, 5, "float");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str36, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str37, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str38, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str39, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str40, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str41, 6, "string");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str42, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str43, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str44, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str45, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str46, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str47, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str48, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str49, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str50, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str51, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str52, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str53, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str54, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str55, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str56, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str57, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str58, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str59, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str60, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str61, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str62, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str63, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str64, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str65, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str66, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str67, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str68, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str69, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str70, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str71, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str72, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str73, 6, "record");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str74, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str75, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str76, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str77, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str78, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str79, 6, "String");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str80, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str81, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str82, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str83, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str84, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str85, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str86, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str87, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str88, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str89, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str90, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str91, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str92, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str93, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str94, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str95, 4, "word");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str96, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str97, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str98, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str99, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str100, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str101, 2, "as");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str102, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2epatKey_str103, 1, "(");
Clo g_heff_2esyntax_2eformat_2epatKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2epatKey_entry, 1, 0};

V g_heff_2esyntax_2eformat_2epatKey(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_244 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
      V v_x2_245 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str0), v_t_244));
      V v_t_248;
      switch (heff_tag_of(v_x2_245)) {
      case TAG_Nil: {
        v_t_248 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_246 = heff_field(v_x2_245, 0);
        V v_xs_247 = heff_field(v_x2_245, 1);
        heff_take_n(v_x2_245, 3ULL, 2);
        v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
        break;
      }
      default: heff_nomatch(v_x2_245);
      }
      V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str3), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2epatKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str5), v_t_249);
    }
    case TAG_PatTag: {
      V v_t_2410 = heff_field(v_x11_241, 0);
      V v_ps_2412 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2413 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2412));
      V v_t_2416;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nil: {
        v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str6);
        break;
      }
      case TAG_Cons: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        V v_xs_2415 = heff_field(v_x2_2413, 1);
        heff_take_n(v_x2_2413, 3ULL, 2);
        v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str7); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str8), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2epatKey_str9)));
      V v_t_2418 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
      V v_parts_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2418});
      V v_x2_2420 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str10), v_parts_2419));
      V v_t_2423;
      switch (heff_tag_of(v_x2_2420)) {
      case TAG_Nil: {
        v_t_2423 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str11);
        break;
      }
      case TAG_Cons: {
        V v_x_2421 = heff_field(v_x2_2420, 0);
        V v_xs_2422 = heff_field(v_x2_2420, 1);
        heff_take_n(v_x2_2420, 3ULL, 2);
        v_t_2423 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str12); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2420);
      }
      V v_t_2424 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str13), heff_strAppend(v_t_2423, ((V)&g_heff_2esyntax_2eformat_2epatKey_str14)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str15), v_t_2424);
    }
    case TAG_PatOp: {
      V v_x_2425 = heff_field(v_x11_241, 0);
      V v_ps_2427 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_x2_2428 = (g_list_2emap(((V)&g_heff_2esyntax_2eformat_2epatKey_clo), v_ps_2427));
      V v_t_2431;
      switch (heff_tag_of(v_x2_2428)) {
      case TAG_Nil: {
        v_t_2431 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str16);
        break;
      }
      case TAG_Cons: {
        V v_x_2429 = heff_field(v_x2_2428, 0);
        V v_xs_2430 = heff_field(v_x2_2428, 1);
        heff_take_n(v_x2_2428, 3ULL, 2);
        v_t_2431 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str17); V a_1 = v_x_2429; V a_2 = v_xs_2430; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2430); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2428);
      }
      V v_t_2432 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str18), heff_strAppend(v_t_2431, ((V)&g_heff_2esyntax_2eformat_2epatKey_str19)));
      V v_t_2433 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
      V v_parts_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2425, v_t_2433});
      V v_x2_2435 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str20), v_parts_2434));
      V v_t_2438;
      switch (heff_tag_of(v_x2_2435)) {
      case TAG_Nil: {
        v_t_2438 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str21);
        break;
      }
      case TAG_Cons: {
        V v_x_2436 = heff_field(v_x2_2435, 0);
        V v_xs_2437 = heff_field(v_x2_2435, 1);
        heff_take_n(v_x2_2435, 3ULL, 2);
        v_t_2438 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str22); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2435);
      }
      V v_t_2439 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str23), heff_strAppend(v_t_2438, ((V)&g_heff_2esyntax_2eformat_2epatKey_str24)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str25), v_t_2439);
    }
    case TAG_PatInt: {
      V v_i_2440 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2441 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_intShow(v_i_2440), NTAG(TAG_Nil)});
      V v_x2_2442 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str26), v_t_2441));
      V v_t_2445;
      switch (heff_tag_of(v_x2_2442)) {
      case TAG_Nil: {
        v_t_2445 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str27);
        break;
      }
      case TAG_Cons: {
        V v_x_2443 = heff_field(v_x2_2442, 0);
        V v_xs_2444 = heff_field(v_x2_2442, 1);
        heff_take_n(v_x2_2442, 3ULL, 2);
        v_t_2445 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str28); V a_1 = v_x_2443; V a_2 = v_xs_2444; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2444); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2442);
      }
      V v_t_2446 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str29), heff_strAppend(v_t_2445, ((V)&g_heff_2esyntax_2eformat_2epatKey_str30)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str31), v_t_2446);
    }
    case TAG_PatFloat: {
      V v_x_2447 = heff_tget_v(v_x11_241, 0);
      heff_take_na(v_x11_241, 0ULL, 1);
      V v_t_2448 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_floatShow(v_x_2447), NTAG(TAG_Nil)});
      V v_x2_2449 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str32), v_t_2448));
      V v_t_2452;
      switch (heff_tag_of(v_x2_2449)) {
      case TAG_Nil: {
        v_t_2452 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str33);
        break;
      }
      case TAG_Cons: {
        V v_x_2450 = heff_field(v_x2_2449, 0);
        V v_xs_2451 = heff_field(v_x2_2449, 1);
        heff_take_n(v_x2_2449, 3ULL, 2);
        v_t_2452 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str34); V a_1 = v_x_2450; V a_2 = v_xs_2451; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2451); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2449);
      }
      V v_t_2453 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str35), heff_strAppend(v_t_2452, ((V)&g_heff_2esyntax_2eformat_2epatKey_str36)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str37), v_t_2453);
    }
    case TAG_PatString: {
      V v_x_2454 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2455 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_x_2454, NTAG(TAG_Nil)});
      V v_x2_2456 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str38), v_t_2455));
      V v_t_2459;
      switch (heff_tag_of(v_x2_2456)) {
      case TAG_Nil: {
        v_t_2459 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str39);
        break;
      }
      case TAG_Cons: {
        V v_x_2457 = heff_field(v_x2_2456, 0);
        V v_xs_2458 = heff_field(v_x2_2456, 1);
        heff_take_n(v_x2_2456, 3ULL, 2);
        v_t_2459 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str40); V a_1 = v_x_2457; V a_2 = v_xs_2458; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2458); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2456);
      }
      V v_t_2460 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str41), heff_strAppend(v_t_2459, ((V)&g_heff_2esyntax_2eformat_2epatKey_str42)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str43), v_t_2460);
    }
    case TAG_PatBinary: {
      V v_segs_2461 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x2_2462 = (g_list_2emap_24s2016443462x370533815(v_segs_2461));
      V v_t_2465;
      switch (heff_tag_of(v_x2_2462)) {
      case TAG_Nil: {
        v_t_2465 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str44);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x2_2462, 0);
        V v_xs_2464 = heff_field(v_x2_2462, 1);
        heff_take_n(v_x2_2462, 3ULL, 2);
        v_t_2465 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str45); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2462);
      }
      V v_t_2466 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str46), heff_strAppend(v_t_2465, ((V)&g_heff_2esyntax_2eformat_2epatKey_str47)));
      V v_parts_2467 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
      V v_x2_2468 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str48), v_parts_2467));
      V v_t_2471;
      switch (heff_tag_of(v_x2_2468)) {
      case TAG_Nil: {
        v_t_2471 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str49);
        break;
      }
      case TAG_Cons: {
        V v_x_2469 = heff_field(v_x2_2468, 0);
        V v_xs_2470 = heff_field(v_x2_2468, 1);
        heff_take_n(v_x2_2468, 3ULL, 2);
        v_t_2471 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str50); V a_1 = v_x_2469; V a_2 = v_xs_2470; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2470); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2468);
      }
      V v_t_2472 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str51), heff_strAppend(v_t_2471, ((V)&g_heff_2esyntax_2eformat_2epatKey_str52)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str53), v_t_2472);
    }
    case TAG_PatRune: {
      V v_c_2473 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2474 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){heff_intShow(v_c_2473), NTAG(TAG_Nil)});
      V v_x2_2475 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str54), v_t_2474));
      V v_t_2478;
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_Nil: {
        v_t_2478 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str55);
        break;
      }
      case TAG_Cons: {
        V v_x_2476 = heff_field(v_x2_2475, 0);
        V v_xs_2477 = heff_field(v_x2_2475, 1);
        heff_take_n(v_x2_2475, 3ULL, 2);
        v_t_2478 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str56); V a_1 = v_x_2476; V a_2 = v_xs_2477; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2477); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2475);
      }
      V v_t_2479 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str57), heff_strAppend(v_t_2478, ((V)&g_heff_2esyntax_2eformat_2epatKey_str58)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str59), v_t_2479);
    }
    case TAG_PatRecord: {
      V v_fs_2480 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_x2_2481 = (g_list_2emap_24s1047941608x1265580215(((V)&g_heff_2esyntax_2eformat_2epatKey_str60), ((V)&g_heff_2esyntax_2eformat_2epatKey_str61), ((V)&g_heff_2esyntax_2eformat_2epatKey_str62), ((V)&g_heff_2esyntax_2eformat_2epatKey_str63), ((V)&g_heff_2esyntax_2eformat_2epatKey_str64), ((V)&g_heff_2esyntax_2eformat_2epatKey_str65), v_fs_2480));
      V v_t_2484;
      switch (heff_tag_of(v_x2_2481)) {
      case TAG_Nil: {
        v_t_2484 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str66);
        break;
      }
      case TAG_Cons: {
        V v_x_2482 = heff_field(v_x2_2481, 0);
        V v_xs_2483 = heff_field(v_x2_2481, 1);
        heff_take_n(v_x2_2481, 3ULL, 2);
        v_t_2484 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str67); V a_1 = v_x_2482; V a_2 = v_xs_2483; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2483); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2481);
      }
      V v_t_2485 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str68), heff_strAppend(v_t_2484, ((V)&g_heff_2esyntax_2eformat_2epatKey_str69)));
      V v_parts_2486 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2485, NTAG(TAG_Nil)});
      V v_x2_2487 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str70), v_parts_2486));
      V v_t_2490;
      switch (heff_tag_of(v_x2_2487)) {
      case TAG_Nil: {
        v_t_2490 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str71);
        break;
      }
      case TAG_Cons: {
        V v_x_2488 = heff_field(v_x2_2487, 0);
        V v_xs_2489 = heff_field(v_x2_2487, 1);
        heff_take_n(v_x2_2487, 3ULL, 2);
        v_t_2490 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str72); V a_1 = v_x_2488; V a_2 = v_xs_2489; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2489); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2487);
      }
      V v_t_2491 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str73), heff_strAppend(v_t_2490, ((V)&g_heff_2esyntax_2eformat_2epatKey_str74)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str75), v_t_2491);
    }
    case TAG_PatWord: {
      V v_w_2492 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_t_2494;
      switch (heff_tag_of(v_w_2492)) {
      case TAG_TypeWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str76);
        break;
      }
      case TAG_IntWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str77);
        break;
      }
      case TAG_FloatWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str78);
        break;
      }
      case TAG_StringWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str79);
        break;
      }
      case TAG_RuneWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str80);
        break;
      }
      case TAG_ArrayWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str81);
        break;
      }
      case TAG_AbandonWord: {
        v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str82);
        break;
      }
      case TAG_FixedWord: {
        V v_w_2493 = heff_field(v_w_2492, 0);
        heff_take_n(v_w_2492, 1ULL, 1);
        switch (heff_tag_of(v_w_2493)) {
        case TAG_I8: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str83);
          break;
        }
        case TAG_I16: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str84);
          break;
        }
        case TAG_I32: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str85);
          break;
        }
        case TAG_I64: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str86);
          break;
        }
        case TAG_U8: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str87);
          break;
        }
        case TAG_U16: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str88);
          break;
        }
        case TAG_U32: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str89);
          break;
        }
        case TAG_U64: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str90);
          break;
        }
        case TAG_F32: {
          v_t_2494 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str91);
          break;
        }
        default: heff_nomatch(v_w_2493);
        }
        break;
      }
      default: heff_nomatch(v_w_2492);
      }
      V v_t_2495 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_2494, NTAG(TAG_Nil)});
      V v_x2_2496 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str92), v_t_2495));
      V v_t_2499;
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_Nil: {
        v_t_2499 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str93);
        break;
      }
      case TAG_Cons: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_xs_2498 = heff_field(v_x2_2496, 1);
        heff_take_n(v_x2_2496, 3ULL, 2);
        v_t_2499 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str94); V a_1 = v_x_2497; V a_2 = v_xs_2498; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2498); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2496);
      }
      V v_t_24100 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str95), heff_strAppend(v_t_2499, ((V)&g_heff_2esyntax_2eformat_2epatKey_str96)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str97), v_t_24100);
    }
    case TAG_PatAs: {
      V v_x_24101 = heff_field(v_x11_241, 0);
      V v_q_24103 = heff_field(v_x11_241, 2);
      heff_take_n(v_x11_241, 5ULL, 3);
      V v_t_24104 = (g_heff_2esyntax_2eformat_2epatKey(v_q_24103));
      V v_t_24105 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_Cons, 2, (V[]){v_t_24104, NTAG(TAG_Nil)});
      V v_parts_24106 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24101, v_t_24105});
      V v_x2_24107 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2epatKey_str98), v_parts_24106));
      V v_t_24110;
      switch (heff_tag_of(v_x2_24107)) {
      case TAG_Nil: {
        v_t_24110 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str99);
        break;
      }
      case TAG_Cons: {
        V v_x_24108 = heff_field(v_x2_24107, 0);
        V v_xs_24109 = heff_field(v_x2_24107, 1);
        heff_take_n(v_x2_24107, 3ULL, 2);
        v_t_24110 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2epatKey_str100); V a_1 = v_x_24108; V a_2 = v_xs_24109; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24109); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24107);
      }
      V v_t_24111 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str101), heff_strAppend(v_t_24110, ((V)&g_heff_2esyntax_2eformat_2epatKey_str102)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2epatKey_str103), v_t_24111);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2epatKey(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str3, 4, "name");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str9, 8, "implicit");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str15, 3, "ann");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2elamKey_str17, 1, "(");
Clo g_heff_2esyntax_2eformat_2elamKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2elamKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2elamKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_LamName: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24LamName = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_241_24LamName, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
    V v_x2_245 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2elamKey_str0), v_t_244));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str3), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2elamKey_str4)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str5), v_t_249);
  }
  case TAG_LamImplicit: {
    V v_x_2410 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24LamImplicit = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    heff_drop_rec(v_r_240, 2);
    V v_t_2412 = heff_tag_at_n(v_ru_24x2_241_24LamImplicit, TAG_Cons, 2, (V[]){v_x_2410, NTAG(TAG_Nil)});
    V v_x2_2413 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2elamKey_str6), v_t_2412));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str8); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str9), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2eformat_2elamKey_str10)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str11), v_t_2417);
  }
  case TAG_LamAnn: {
    V v_x_2418 = heff_field(v_x2_241, 0);
    V v_t_2420 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2420}));
    V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, NTAG(TAG_Nil)});
    V v_parts_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, v_t_2422});
    V v_x2_2424 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2elamKey_str12), v_parts_2423));
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2elamKey_str14); V a_1 = v_x_2425; V a_2 = v_xs_2426; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2428 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str15), heff_strAppend(v_t_2427, ((V)&g_heff_2esyntax_2eformat_2elamKey_str16)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2elamKey_str17), v_t_2428);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2elamKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2elamKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str3, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str9, 5, "field");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str15, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldDeclKey_str17, 1, "(");
Clo g_heff_2esyntax_2eformat_2efieldDeclKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldDeclKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldDeclKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_x214_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      switch (heff_tag_of(v_x214_247)) {
      case TAG_Nothing: {
        V v_t_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_246}));
        V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
        V v_parts_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_249});
        V v_x2_2411 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str0), v_parts_2410));
        V v_t_2414;
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Nil: {
          v_t_2414 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2412 = heff_field(v_x2_2411, 0);
          V v_xs_2413 = heff_field(v_x2_2411, 1);
          heff_take_n(v_x2_2411, 3ULL, 2);
          v_t_2414 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str2); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2411);
        }
        V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str3), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str4)));
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str5), v_t_2415);
      }
      case TAG_Just: {
        V v_d_2416 = heff_field(v_x214_247, 0);
        heff_take_n(v_x214_247, 1ULL, 1);
        V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_t_246}));
        V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_d_2416}));
        V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_parts_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2419})});
        V v_x2_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str6), v_parts_2420));
        V v_t_2424;
        switch (heff_tag_of(v_x2_2421)) {
        case TAG_Nil: {
          v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2422 = heff_field(v_x2_2421, 0);
          V v_xs_2423 = heff_field(v_x2_2421, 1);
          heff_take_n(v_x2_2421, 3ULL, 2);
          v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2421);
        }
        V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str10)));
        return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str11), v_t_2425);
      }
      default: return heff_nomatch(v_x214_247);
      }
    }
    case TAG_BadFieldDecl: {
      V v_e_2426 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2426}));
      V v_parts_2428 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str12), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str15), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldDeclKey_str17), v_t_2433);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldDeclKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldDeclKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str3, 3, "set");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str9, 3, "bad");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2efieldSetKey_str11, 1, "(");
Clo g_heff_2esyntax_2eformat_2efieldSetKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2efieldSetKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2efieldSetKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_SetField: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str5), v_t_2414);
    }
    case TAG_BadFieldSet: {
      V v_e_2415 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2415}));
      V v_parts_2417 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
      V v_x2_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str6), v_parts_2417));
      V v_t_2421;
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Nil: {
        v_t_2421 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2419 = heff_field(v_x2_2418, 0);
        V v_xs_2420 = heff_field(v_x2_2418, 1);
        heff_take_n(v_x2_2418, 3ULL, 2);
        v_t_2421 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str8); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2418);
      }
      V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str9), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2efieldSetKey_str11), v_t_2422);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2efieldSetKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2efieldSetKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str0, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str2, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str3, 4, "bind");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str4, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str5, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str6, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str7, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str8, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str9, 3, "let");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str10, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str11, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str12, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str13, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str14, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str15, 4, "expr");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str16, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str17, 1, "(");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str18, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str19, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str20, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str21, 3, "mut");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str22, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2estmtKey_str23, 1, "(");
Clo g_heff_2esyntax_2eformat_2estmtKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estmtKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estmtKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_StmtBind: {
      V v_x_244 = heff_field(v_x21_242, 0);
      V v_e_246 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_246}));
      V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_parts_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_t_248});
      V v_x2_2410 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str0), v_parts_249));
      V v_t_2413;
      switch (heff_tag_of(v_x2_2410)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_x2_2410, 0);
        V v_xs_2412 = heff_field(v_x2_2410, 1);
        heff_take_n(v_x2_2410, 3ULL, 2);
        v_t_2413 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str2); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2410);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str3), heff_strAppend(v_t_2413, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str4)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str5), v_t_2414);
    }
    case TAG_StmtLet: {
      V v_p_2415 = heff_field(v_x21_242, 0);
      V v_e_2416 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24StmtLet = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_2417 = (g_heff_2esyntax_2eformat_2epatKey(v_p_2415));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2416}));
      V v_t_2419 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
      V v_parts_2420 = heff_tag_at_n(v_ru_24x21_242_24StmtLet, TAG_Cons, 2, (V[]){v_t_2417, v_t_2419});
      V v_x2_2421 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str6), v_parts_2420));
      V v_t_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_t_2424 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str7);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_t_2424 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str8); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str9), heff_strAppend(v_t_2424, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str10)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str11), v_t_2425);
    }
    case TAG_StmtExpr: {
      V v_e_2426 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2426}));
      V v_parts_2428 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      V v_x2_2429 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str12), v_parts_2428));
      V v_t_2432;
      switch (heff_tag_of(v_x2_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str13);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_x2_2429, 0);
        V v_xs_2431 = heff_field(v_x2_2429, 1);
        heff_take_n(v_x2_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str14); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2429);
      }
      V v_t_2433 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str15), heff_strAppend(v_t_2432, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str16)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str17), v_t_2433);
    }
    case TAG_StmtLetMut: {
      V v_x_2434 = heff_field(v_x21_242, 0);
      V v_e_2436 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_t_2437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2436}));
      V v_t_2438 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
      V v_parts_2439 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2434, v_t_2438});
      V v_x2_2440 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2estmtKey_str18), v_parts_2439));
      V v_t_2443;
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_Nil: {
        v_t_2443 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str19);
        break;
      }
      case TAG_Cons: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_xs_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        v_t_2443 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2estmtKey_str20); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2440);
      }
      V v_t_2444 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str21), heff_strAppend(v_t_2443, ((V)&g_heff_2esyntax_2eformat_2estmtKey_str22)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2estmtKey_str23), v_t_2444);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2estmtKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2estmtKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str7, 8, "equation");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2eequationKey_str9, 1, "(");
Clo g_heff_2esyntax_2eformat_2eequationKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2eequationKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2eequationKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_x2_248 = (g_list_2emap_24s1561756891x1126436879(v_ps_246));
      V v_t_2411;
      switch (heff_tag_of(v_x2_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_x2_248, 0);
        V v_xs_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str1); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_x2_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str2), heff_strAppend(v_t_2411, ((V)&g_heff_2esyntax_2eformat_2eequationKey_str3)));
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_rhs_247}));
      V v_t_2414 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
      V v_parts_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_244, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2414})});
      V v_x2_2416 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2eequationKey_str4), v_parts_2415));
      V v_t_2419;
      switch (heff_tag_of(v_x2_2416)) {
      case TAG_Nil: {
        v_t_2419 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2417 = heff_field(v_x2_2416, 0);
        V v_xs_2418 = heff_field(v_x2_2416, 1);
        heff_take_n(v_x2_2416, 3ULL, 2);
        v_t_2419 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2eequationKey_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2416);
      }
      V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str7), heff_strAppend(v_t_2419, ((V)&g_heff_2esyntax_2eformat_2eequationKey_str8)));
      return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2eequationKey_str9), v_t_2420);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2eequationKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2eequationKey(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str1, 2, ", ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str2, 1, "[");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str3, 1, "]");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str4, 1, " ");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str5, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str6, 0, "");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str7, 5, "catch");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2eformat_2ecatchKey_str9, 1, "(");
Clo g_heff_2esyntax_2eformat_2ecatchKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ecatchKey_entry, 2, 0};

V g_heff_2esyntax_2eformat_2ecatchKey(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkCatchArm: {
    V v_b_242 = heff_field(v_x2_241, 0);
    V v_ss_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24MkCatchArm = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2eformat_2elamKey(heff_dup(v_r_240), v_b_242));
    V v_x2_245 = (g_list_2emap_24s313852718x340738167(v_r_240, v_ss_243));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2esyntax_2eformat_2ecatchKey_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ecatchKey_str1); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ecatchKey_str2), heff_strAppend(v_t_248, ((V)&g_heff_2esyntax_2eformat_2ecatchKey_str3)));
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24MkCatchArm, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_parts_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, v_t_2410});
    V v_x2_2412 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2esyntax_2eformat_2ecatchKey_str4), v_parts_2411));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2esyntax_2eformat_2ecatchKey_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = ((V)&g_heff_2esyntax_2eformat_2ecatchKey_str6); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ecatchKey_str7), heff_strAppend(v_t_2415, ((V)&g_heff_2esyntax_2eformat_2ecatchKey_str8)));
    return heff_strAppend(((V)&g_heff_2esyntax_2eformat_2ecatchKey_str9), v_t_2416);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2eformat_2ecatchKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2eformat_2ecatchKey(a[0], a[1]);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam0, 1, 0};
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args); static Clo g_heff_2esyntax_2eformat_2ekeys_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2ekeys_lam1, 1, 0};

static V g_heff_2esyntax_2eformat_2ekeys_val;
static HEFF_ONCE g_heff_2esyntax_2eformat_2ekeys_st;
static V g_heff_2esyntax_2eformat_2ekeys_init(void) {
  return heff_rec_n(2, shape_e__decl, (V[]){((V)&g_heff_2esyntax_2eformat_2ekeys_lam0_clo), ((V)&g_heff_2esyntax_2eformat_2ekeys_lam1_clo)});
}
V g_heff_2esyntax_2eformat_2ekeys_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2eformat_2ekeys_st)) return g_heff_2esyntax_2eformat_2ekeys_val;
  return heff_global(&g_heff_2esyntax_2eformat_2ekeys_val, &g_heff_2esyntax_2eformat_2ekeys_st, g_heff_2esyntax_2eformat_2ekeys_init);
}
V g_heff_2esyntax_2eformat_2ekeys_lam0(V self, V *args) {
  V v_n_240 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyTermF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_n_240));
}
V g_heff_2esyntax_2eformat_2ekeys_lam1(V self, V *args) {
  V v_d_241 = args[0];
  return (g_heff_2esyntax_2eformat_2ekeyDeclF(heff_dup(g_heff_2esyntax_2eformat_2ekeys_get()), v_d_241));
}
Clo g_heff_2esyntax_2eformat_2estrsEq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2eformat_2estrsEq_entry, 2, 0};

V g_heff_2esyntax_2eformat_2estrsEq(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2eformat_2estrsEq_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2esyntax_2eformat_2estrsEq(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str0, 76, "formatting would lose or move a comment across code (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str1, 68, "formatting would change what the file means (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str2, 68, "formatting would change what the file means (a bug of the formatter)");
HEFF_LIT(g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str3, 49, "formatting would change the header or the imports");

HeffT2 g_heff_2esyntax_2eformat_2esameMeaning_24cpr(V v_src_240, V v_out_241, V v_a_242, V v_b_243) {
top: ;
  V v_x1_244 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 0), heff_rfield(v_b_243, 0)));
  if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    V v_t_245 = (g_heff_2esyntax_2eformat_2estrsEq(heff_rfield(v_a_242, 1), heff_rfield(v_b_243, 1)));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_x1_246 = ({ V b_0 = heff_get_n(v_a_242, 2, 3); V b_1 = heff_get_n(v_b_243, 2, 3); V r_ = (g_heff_2esyntax_2eformat_2estrsEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
      if ((heff_dup(v_x1_246) == NTAG(TAG_True))) {
        heff_drop(v_x1_246);
        V v_t_247 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(v_src_240, MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
        V v_src_248 = heff_get_n(v_t_247, 3, 4);
        V v_t_249 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        V v_t_2410 = ({ V a_0 = v_src_248; V a_1 = v_t_249; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_248); r_; });
        V v_t_2411 = ({ V b_0 = MK_INT(0LL); V a_1 = heff_get_n(v_t_2410, 2, 3); V r_ = (g_list_2emap_24s903588428x1469638784(b_0, a_1)); heff_drop(b_0); r_; });
        V v_t_2412 = heff_tr(g_heff_2esyntax_2eimport_2eimportsGo(heff_dup(v_out_241), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)));
        V v_src_2413 = heff_get_n(v_t_2412, 3, 4);
        V v_t_2414 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        V v_t_2415 = ({ V a_0 = v_src_2413; V a_1 = v_t_2414; V a_2 = NTAG(TAG_Nil); V a_3 = NTAG(TAG_Nil); V a_4 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2efmt_2elex_2elexGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_src_2413); r_; });
        V v_t_2416 = ({ V b_0 = MK_INT(0LL); V a_1 = heff_get_n(v_t_2415, 2, 3); V r_ = (g_list_2emap_24s903588428x1469638784(b_0, a_1)); heff_drop(b_0); r_; });
        V v_x1_2417 = ({ V a_0 = v_t_2411; V a_1 = v_t_2416; V r_ = (g_heff_2esyntax_2eformat_2estrsEq(a_0, a_1)); heff_drop(v_t_2411); heff_drop(v_t_2416); r_; });
        if ((heff_dup(v_x1_2417) == NTAG(TAG_True))) {
          heff_drop(v_x1_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_out_241}});
        } else {
          heff_drop(v_out_241);
          heff_drop(v_x1_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str0)}});
        }
      } else {
        heff_drop(v_src_240);
        heff_drop(v_out_241);
        heff_drop(v_x1_246);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str1)}});
      }
    } else {
      heff_drop(v_src_240);
      heff_drop(v_out_241);
      heff_drop_rec(v_a_242, 3);
      heff_drop_rec(v_b_243, 3);
      heff_drop(v_t_245);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str2)}});
    }
  } else {
    heff_drop(v_src_240);
    heff_drop(v_out_241);
    heff_drop_rec(v_a_242, 3);
    heff_drop_rec(v_b_243, 3);
    heff_drop(v_x1_244);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2esyntax_2eformat_2esameMeaning_24cpr_str3)}});
  }
}