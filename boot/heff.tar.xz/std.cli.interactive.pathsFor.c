// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Among 19600
#define TAG_Dirs 41877
#define TAG_Files 59123
#define TAG_None 17785
V g_std_2ecli_2einteractive_2epathsFor_2etaken_241(V, V, V);
V g_std_2ecli_2einteractive_2epathsFor_2etaken_241_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2epathsFor_2etaken_241_clo;
V g_std_2ecli_2einteractive_2eslashFrom(V, V);
V g_std_2ecli_2einteractive_2eslashFrom_entry(V self, V *a);
extern Clo g_std_2ecli_2einteractive_2eslashFrom_clo;
HEFF_LIT(g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str0, 1, "/");
HEFF_LIT(g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str1, 1, "/");
HEFF_LIT(g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str2, 1, ".");
HEFF_LIT(g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str3, 1, ".");
Clo g_std_2ecli_2einteractive_2epathsFor_2etaken_241_clo = {{0x80000000u, K_CLO, 0}, g_std_2ecli_2einteractive_2epathsFor_2etaken_241_entry, 3, 0};

V g_std_2ecli_2einteractive_2epathsFor_2etaken_241(V v_c_240, V v_w_241, V v_n_242) {
top: ;
  V v_c_243 = v_c_240;
  V v_n_244 = heff_dup(v_n_242);
  V v_t_2412;
  switch (heff_tag_of(v_c_243)) {
  case TAG_None: {
    heff_drop(v_n_244);
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  case TAG_Files: {
    V v_sfx_245 = heff_field(v_c_243, 0);
    heff_take_n(v_c_243, 1ULL, 1);
    int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_n_244, 0)) - ((int64_t)1ULL));
    V v_t_247 = heff_strSlice_lent(v_n_244, heff_box_word(v_t_246), heff_strLength_lent(v_n_244, 0), 6);
    v_t_2412 = heff_bool((heff_strEq_c_lent(v_t_247, ((V)&g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str0), 2) || ({ int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_n_244, 0)) - heff_unbox_word(heff_strLength_lent(v_sfx_245, 0))); int c_ = ({ V v_t_2422 = heff_strSlice_lent(v_n_244, heff_box_word(v_t_248), heff_strLength_lent(v_n_244, 0), 6); int c_ = heff_strEq_c_lent(v_t_2422, v_sfx_245, 0); heff_drop(v_t_2422); c_; }); c_; })));
    heff_drop(v_n_244);
    heff_drop(v_sfx_245);
    heff_drop(v_t_247);
    break;
  }
  case TAG_Dirs: {
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_n_244, 0)) - ((int64_t)1ULL));
    V v_t_2410 = heff_strSlice(heff_dup(v_n_244), heff_box_word(v_t_249), heff_strLength(v_n_244));
    v_t_2412 = heff_bool(heff_strEq_c_lent(v_t_2410, ((V)&g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str1), 2));
    heff_drop(v_t_2410);
    break;
  }
  case TAG_Among: {
    heff_take_n(v_c_243, 0ULL, 1);
    heff_drop(v_n_244);
    v_t_2412 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2412) == NTAG(TAG_True)) && ({ int64_t v_t_2413 = (heff_unbox_word(heff_strLength_lent(v_w_241, 0)) - ((int64_t)1ULL)); int c_ = ({ V v_t_2414 = (g_std_2ecli_2einteractive_2eslashFrom(v_w_241, heff_box_word(v_t_2413))); int c_ = ({ V v_t_2415 = heff_strSlice_lent(v_w_241, MK_INT(0LL), heff_intAdd_lent(v_t_2414, MK_INT(1LL), 2), 6); int c_ = ({ V v_prefix_2416 = heff_strSlice_lent(v_w_241, heff_strLength_lent(v_t_2415, 0), heff_strLength_lent(v_w_241, 0), 6); int c_ = ({ V v_t_2417 = heff_strSlice_lent(v_n_242, MK_INT(0LL), heff_strLength_lent(v_prefix_2416, 0), 6); int c_ = (heff_strEq_c_lent(v_t_2417, v_prefix_2416, 0) && ({ int64_t v_t_2418 = (heff_unbox_word(heff_strLength_lent(v_w_241, 0)) - ((int64_t)1ULL)); int c_ = ({ V v_t_2419 = (g_std_2ecli_2einteractive_2eslashFrom(v_w_241, heff_box_word(v_t_2418))); int c_ = ({ V v_t_2420 = heff_strSlice_lent(v_w_241, MK_INT(0LL), heff_intAdd_lent(v_t_2419, MK_INT(1LL), 2), 6); int c_ = ({ V v_s_2421 = heff_strSlice_lent(v_w_241, heff_strLength_lent(v_t_2420, 0), heff_strLength_lent(v_w_241, 0), 6); int c_ = (heff_strEq_c(heff_strSlice_lent(v_s_2421, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str2)) || !heff_strEq_c(heff_strSlice_lent(v_n_242, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_std_2ecli_2einteractive_2epathsFor_2etaken_241_str3))); heff_drop(v_s_2421); c_; }); heff_drop(v_t_2420); c_; }); heff_drop(v_t_2419); c_; }); c_; })); heff_drop(v_t_2417); c_; }); heff_drop(v_prefix_2416); c_; }); heff_drop(v_t_2415); c_; }); heff_drop(v_t_2414); c_; }); c_; })));
  heff_drop(v_n_242);
  heff_drop(v_t_2412);
  return v_ret_24bool;
}
V g_std_2ecli_2einteractive_2epathsFor_2etaken_241_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_std_2ecli_2einteractive_2epathsFor_2etaken_241(a[0], a1, a[2]); heff_drop(a1); return r;
}