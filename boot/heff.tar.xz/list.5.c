// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_Boxed 28180
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_HS 9084
#define TAG_IBind 27068
#define TAG_KnownRec 32578
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_OSimple 59809
#define TAG_Often 32846
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SDebug 8687
#define TAG_SDecl 12991
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_SWarning 44190
#define TAG_TagVariant 25174
#define TAG_Unreached 46435
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define TAG_Wants 58903
#define TAG_Within 10658
#define LBL_at 9882
#define LBL_back 9511342
#define LBL_binder 558177493
#define LBL_by 9918
#define LBL_copies 592412158
#define LBL_defines 1776893014
#define LBL_done 9584713
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_front 299063875
#define LBL_integrations 139286697
#define LBL_key 315609
#define LBL_launch 837298910
#define LBL_long 9823043
#define LBL_name 9869138
#define LBL_param 307795111
#define LBL_parent 951717845
#define LBL_path 9928940
#define LBL_pending 1696753626
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_size 10026184
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tags 10047712
#define LBL_task 10048076
#define LBL_text 10052084
#define LBL_total 311908190
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_v 336
#define LBL_version 583465758
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_front__back[] = {LBL_front, LBL_back};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_task__parent__name__done__total[] = {LBL_task, LBL_parent, LBL_name, LBL_done, LBL_total};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eaddJs(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2ebuildsSize(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(V);
V g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_entry(V self, V *a);
extern Clo g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2eranges_2efnOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2efnOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2efnOne_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2eloops(V);
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eloops_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_heff_2esyntax_2esurface_2edeclNameOf(V);
V g_heff_2esyntax_2esurface_2edeclNameOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclNameOf_clo;
V g_list_2eall_24s457861111x1513113784(V, V);
V g_list_2eall_24s457861111x1513113784_entry(V self, V *a);
extern Clo g_list_2eall_24s457861111x1513113784_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1477604419x1568736711(V, V);
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a);
extern Clo g_list_2eany_24s1477604419x1568736711_clo;
V g_list_2eany_24s1877524499x1789047582(V, V);
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a);
extern Clo g_list_2eany_24s1877524499x1789047582_clo;
V g_list_2eany_24s2046291842x47540086(V, V, V, V);
V g_list_2eany_24s2046291842x47540086_entry(V self, V *a);
extern Clo g_list_2eany_24s2046291842x47540086_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2eany_24s313956312x193471538(V, V, V, V);
V g_list_2eany_24s313956312x193471538_entry(V self, V *a);
extern Clo g_list_2eany_24s313956312x193471538_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
V g_list_2eany_24s52266323x652150664(V);
V g_list_2eany_24s52266323x652150664_entry(V self, V *a);
extern Clo g_list_2eany_24s52266323x652150664_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1597853107x1363733222_24cpr(V, V, V, V, V, V);
HeffT2 g_list_2efind_24s1867824208x1412174996_24cpr(V, V);
HeffT2 g_list_2efind_24s192032632x1721482126_24cpr(V, V);
V g_list_2efoldl_24f700195413x1431112932(V, V, V);
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a);
extern Clo g_list_2efoldl_24f700195413x1431112932_clo;
V g_list_2efoldl_24f71125586x1381947330(V, V, V, V);
V g_list_2efoldl_24f71125586x1381947330_entry(V self, V *a);
extern Clo g_list_2efoldl_24f71125586x1381947330_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1794308634x1384130934(V, V, V, V, V);
V g_list_2efoldl_24s1794308634x1384130934_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1794308634x1384130934_clo;
V g_list_2efoldl_24s1817528582x392224400(V, V, V);
V g_list_2efoldl_24s1817528582x392224400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1817528582x392224400_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s1923368998x1291788787(V, V);
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1923368998x1291788787_clo;
V g_list_2efoldl_24s192900907x155689445(V, V, V);
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a);
extern Clo g_list_2efoldl_24s192900907x155689445_clo;
V g_list_2efoldl_24s1934210846x602559163(V, V);
V g_list_2efoldl_24s1934210846x602559163_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1934210846x602559163_clo;
V g_list_2efoldl_24s2062876492x2082655823_24scalars(V, V, V);
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2efoldl_24s740336339x1862813792(V, V);
V g_list_2efoldl_24s740336339x1862813792_entry(V self, V *a);
extern Clo g_list_2efoldl_24s740336339x1862813792_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2efoldl_24s937655778x647278584(V, V);
V g_list_2efoldl_24s937655778x647278584_entry(V self, V *a);
extern Clo g_list_2efoldl_24s937655778x647278584_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2efoldl_24s989097923x484436710(V, V);
V g_list_2efoldl_24s989097923x484436710_entry(V self, V *a);
extern Clo g_list_2efoldl_24s989097923x484436710_clo;
V g_list_2ekeepIf_24f1278780364x1365377410(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_clo;
V g_list_2ekeepIf_24f1278780364x1365377410_24dps(V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_24dps_clo;
V g_list_2ekeepIf_24s1063601026x1972672043_24dps(V, V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_24dps_clo;
V g_list_2ekeepIf_24s1111636858x612918583(V, V, V);
V g_list_2ekeepIf_24s1111636858x612918583_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1111636858x612918583_clo;
V g_list_2ekeepIf_24s1111636858x612918583_24dps(V, V, V, V);
V g_list_2ekeepIf_24s1111636858x612918583_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1111636858x612918583_24dps_clo;
V g_list_2ekeepIf_24s1161549307x1906011635_24dps(V, V);
V g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_24dps_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2ekeepIf_24s1220809684x843195562_24dps(V, V, V);
V g_list_2ekeepIf_24s1220809684x843195562_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_24dps_clo;
V g_list_2ekeepIf_24s1266148589x1647110933(V);
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_clo;
V g_list_2ekeepIf_24s1266148589x1647110933_24dps(V, V);
V g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_24dps_clo;
V g_list_2ekeepIf_24s183165982x1490920686_24dps(V, V);
V g_list_2ekeepIf_24s183165982x1490920686_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_24dps_clo;
V g_list_2ekeepIf_24s1992606061x1037009925_24dps(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24s1992606061x1037009925_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1992606061x1037009925_24dps_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap_24f1213328022x1811586494(V, V);
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_clo;
V g_list_2emap_24f1213328022x1811586494_24dps(V, V, V);
V g_list_2emap_24f1213328022x1811586494_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_24dps_clo;
V g_list_2emap_24f1502491305x440718220_24dps(V, V, V);
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_24dps_clo;
V g_list_2emap_24f405781872x1513910762(V, V, V, V, V, V);
V g_list_2emap_24f405781872x1513910762_entry(V self, V *a);
extern Clo g_list_2emap_24f405781872x1513910762_clo;
V g_list_2emap_24f405781872x1513910762_24dps(V, V, V, V, V, V, V);
V g_list_2emap_24f405781872x1513910762_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f405781872x1513910762_24dps_clo;
V g_list_2emap_24s1112048172x371485672(V);
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_clo;
V g_list_2emap_24s1112048172x371485672_24dps(V, V);
V g_list_2emap_24s1112048172x371485672_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1112048172x371485672_24dps_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1224226459x189329095(V, V, V);
V g_list_2emap_24s1224226459x189329095_entry(V self, V *a);
extern Clo g_list_2emap_24s1224226459x189329095_clo;
V g_list_2emap_24s1224226459x189329095_24dps(V, V, V, V);
V g_list_2emap_24s1224226459x189329095_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1224226459x189329095_24dps_clo;
V g_list_2emap_24s1310249268x749995235_24dps(V, V, V, V);
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_24dps_clo;
V g_list_2emap_24s1354671438x1264137843_24dps(V, V);
V g_list_2emap_24s1354671438x1264137843_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354671438x1264137843_24dps_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s1382928954x1260344933_24dps(V, V, V, V);
V g_list_2emap_24s1382928954x1260344933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_24dps_clo;
V g_list_2emap_24s1543151117x629172256(V);
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_clo;
V g_list_2emap_24s1543151117x629172256_24dps(V, V);
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s2016093283x1174801437_24dps(V, V, V);
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_24dps_clo;
V g_list_2emap_24s2021078391x832341393(V, V, V);
V g_list_2emap_24s2021078391x832341393_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_clo;
V g_list_2emap_24s2021078391x832341393_24dps(V, V, V, V);
V g_list_2emap_24s2021078391x832341393_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2021078391x832341393_24dps_clo;
V g_list_2emap_24s2029035892x1571084362_24dps(V, V);
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24dps_clo;
V g_list_2emap_24s2029035892x1571084362_24tok2(V, V);
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s231073986x752637537_24dps(V, V, V);
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_24dps_clo;
V g_list_2emap_24s348263401x2104816219(V);
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_clo;
V g_list_2emap_24s348263401x2104816219_24dps(V, V);
V g_list_2emap_24s348263401x2104816219_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s348263401x2104816219_24dps_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s418652630x628827683_24dps(V, V);
V g_list_2emap_24s418652630x628827683_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_24dps_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s549405518x243689326_24dps(V, V);
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_24dps_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s588563787x236154271(V, V, V, V);
V g_list_2emap_24s588563787x236154271_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_clo;
V g_list_2emap_24s588563787x236154271_24dps(V, V, V, V, V);
V g_list_2emap_24s588563787x236154271_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_24dps_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s620499005x2067584111_24dps(V, V, V);
V g_list_2emap_24s620499005x2067584111_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_24dps_clo;
V g_list_2emap_24s674081137x339217813(V);
V g_list_2emap_24s674081137x339217813_entry(V self, V *a);
extern Clo g_list_2emap_24s674081137x339217813_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24s675147852x248982264_24dps(V, V, V);
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s900318151x1569363206_24dps(V, V, V, V);
V g_list_2emap_24s900318151x1569363206_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s900318151x1569363206_24dps_clo;
V g_list_2emap_24s94444922x1860431141(V);
V g_list_2emap_24s94444922x1860431141_entry(V self, V *a);
extern Clo g_list_2emap_24s94444922x1860431141_clo;
V g_list_2emap_24s94444922x1860431141_24dps(V, V);
V g_list_2emap_24s94444922x1860431141_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s94444922x1860431141_24dps_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s961097229x1129443801_24dps(V, V);
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_24dps_clo;
V g_list_2ezipWith_24s1604775524x1614188687(V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_clo;
V g_list_2ezipWith_24s1604775524x1614188687_24dps(V, V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo;
V g_list_2ezipWith_24s1891751394x1524628247_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s1891751394x1524628247_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1891751394x1524628247_24dps_clo;
V g_list_2ezipWith_24s1928181476x241816070_24dps(V, V, V);
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f686409757x475266571(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f686409757x475266571_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f686409757x475266571_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);

HeffT2 g_list_2efind_24cpr(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_xs_243);
      heff_drop(v_t_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2emap_24s2029035892x1571084362_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_24dps_entry, 2, 0};

V g_list_2emap_24s2029035892x1571084362_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1604775524x1614188687_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1604775524x1614188687_entry, 3, 0};

V g_list_2ezipWith_24s1604775524x1614188687(V v_lit_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_dup(heff_field(v_x_243, 0));
        v_a_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_a_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 2ULL, 2);
        v_a_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2416;
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Unreached: {
        heff_drop(v_y_245);
        v_t_2416 = v_a_249;
        break;
      }
      case TAG_Within: {
        V v_t_2415 = ({ V a_0 = v_a_2412; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2eranges_2erangeEq(a_0, a_1)); heff_drop_tag(v_a_2412, 2); heff_drop(v_y_245); r_; });
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          v_t_2416 = v_a_249;
        } else {
          heff_drop(v_t_2415);
          v_t_2416 = heff_intAdd(v_a_249, heff_dup(v_lit_240));
        }
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = (g_list_2ezipWith_24s1604775524x1614188687_24dps(v_lit_240, v_xs_244, v_ys_246, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1604775524x1614188687(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1477604419x1568736711_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1477604419x1568736711_entry, 2, 0};

V g_list_2eany_24s1477604419x1568736711(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_242, v_lit_240, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1477604419x1568736711_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1477604419x1568736711(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1923368998x1291788787_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1923368998x1291788787_entry, 2, 0};

V g_list_2efoldl_24s1923368998x1291788787(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1923368998x1291788787_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1923368998x1291788787(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s26403090x581733227_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s26403090x581733227_entry, 4, 0};

V g_list_2efoldl_24s26403090x581733227(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eranges_2efnOne(v_lit_240, v_lit_241, v_z_242, heff_dup(v_x_244)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s26403090x581733227(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s620499005x2067584111_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s620499005x2067584111_entry, 2, 0};

V g_list_2emap_24s620499005x2067584111(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s620499005x2067584111_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s620499005x2067584111(a[0], a[1]);
}
Clo g_list_2emap_24s2016093283x1174801437_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016093283x1174801437_24dps_entry, 3, 0};

V g_list_2emap_24s2016093283x1174801437_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016093283x1174801437_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1844509821x2028168277_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_entry, 1, 0};

V g_list_2emap_24s1844509821x2028168277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_241));
    V v_t_2415;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_246 = v_field_245;
        v_t_2415 = v_a_246;
      } else {
        if ((v_tag_244 == ((int64_t)1ULL))) {
          V v_a_247 = v_field_245;
          V v_t_2410;
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_249 = heff_dup(heff_field(v_a_247, 1));
            v_t_2410 = v_a_249;
            break;
          }
          default: heff_nomatch(v_a_247);
          }
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_247}), v_t_2410});
        } else {
          V v_a_2411 = v_field_245;
          V v_t_2414;
          switch (heff_tag_of(v_a_2411)) {
          case TAG_At: {
            V v_a_2413 = heff_dup(heff_field(v_a_2411, 1));
            v_t_2414 = v_a_2413;
            break;
          }
          default: heff_nomatch(v_a_2411);
          }
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2411}), v_t_2414});
        }
      }
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s1844509821x2028168277_24dps(v_xs_242, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277(a[0]);
}
Clo g_list_2emap_24s961097229x1129443801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s961097229x1129443801_entry, 1, 0};

V g_list_2emap_24s961097229x1129443801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s961097229x1129443801_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s961097229x1129443801(a[0]);
}
Clo g_list_2emap_24s513391942x823299088_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_entry, 1, 0};

V g_list_2emap_24s513391942x823299088(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_248 = (g_list_2emap_24s158244903x55062455(v_a_247));
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, v_t_248});
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          V v_ru_24a_249_24At = heff_take_reuse_n(v_a_249, 3ULL, 2);
          v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_249_24At, v_a_2411, v_a_2410));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s513391942x823299088_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088(a[0]);
}
Clo g_list_2emap_24s348263401x2104816219_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s348263401x2104816219_entry, 1, 0};

V g_list_2emap_24s348263401x2104816219(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2esurface_2edeclNameOf(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s348263401x2104816219_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s348263401x2104816219_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s348263401x2104816219(a[0]);
}
Clo g_list_2emap_24s1543151117x629172256_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_entry, 1, 0};

V g_list_2emap_24s1543151117x629172256(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1543151117x629172256_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256(a[0]);
}
Clo g_list_2ezipWith_24s1891751394x1524628247_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1891751394x1524628247_24dps_entry, 6, 0};

V g_list_2ezipWith_24s1891751394x1524628247_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_243, 0);
    V v_xs_247 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_246);
      heff_drop(v_xs_247);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_248 = heff_field(v_x3_244, 0);
      V v_ys_249 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_2411;
      if (heff_strEq_c_lent(v_x_246, v_lit_240, 0)) {
        heff_drop(v_x_246);
        V v_t_2410 = heff_strAppend(heff_dup(v_lit_242), heff_intShow(v_y_248));
        v_t_2411 = heff_strAppend(heff_dup(v_lit_241), v_t_2410);
      } else {
        heff_drop(v_y_248);
        v_t_2411 = v_x_246;
      }
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_247;
      V t_4 = v_ys_249;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_x3_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s1891751394x1524628247_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ezipWith_24s1891751394x1524628247_24dps(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s549405518x243689326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s549405518x243689326_24dps_entry, 2, 0};

V g_list_2emap_24s549405518x243689326_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2445;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_EVar: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x12_245, 0ULL, 4);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2446 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2445, heff_hole()});
    V v_u_2447 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2446));
    heff_drop(v_u_2447);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2446;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s549405518x243689326_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1112048172x371485672_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1112048172x371485672_entry, 1, 0};

V g_list_2emap_24s1112048172x371485672(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2442;
    switch (heff_tag_of(v_x_241)) {
    case TAG_EVar: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_241, 0ULL, 4);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_241, 0ULL, 3);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_241, 0ULL, 1);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_241, 0ULL, 2);
      v_t_2442 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2443 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2442, heff_hole()});
    V v_u_2444 = (g_list_2emap_24s1112048172x371485672_24dps(v_xs_242, heff_dup(v_cell_2443)));
    heff_drop(v_u_2444);
    return v_cell_2443;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1112048172x371485672_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1112048172x371485672(a[0]);
}
Clo g_list_2emap_24s418652630x628827683_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s418652630x628827683_24dps_entry, 2, 0};

V g_list_2emap_24s418652630x628827683_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2444 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2443, heff_hole()});
    V v_u_2445 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2444));
    heff_drop(v_u_2445);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2444;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s418652630x628827683_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s418652630x628827683_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1794308634x1384130934_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1794308634x1384130934_entry, 5, 0};

V g_list_2efoldl_24s1794308634x1384130934(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 2ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_z_243)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_z_243, 0);
      V v_a_248 = heff_field(v_z_243, 1);
      V v_ru_24z_243_24MkPair = heff_take_reuse_n(v_z_243, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_intShow(heff_dup(v_a_248)));
      V v_t_2410 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_249), v_a_247});
      v_t_2411 = heff_tag_at_n(v_ru_24z_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, heff_intAdd(v_a_248, heff_dup(v_lit_242))});
      break;
    }
    default: heff_nomatch(v_z_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2411;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s1794308634x1384130934_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1794308634x1384130934(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1123370502x1982532655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_24dps_entry, 2, 0};

V g_list_2emap_24s1123370502x1982532655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s183165982x1490920686_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s183165982x1490920686_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s183165982x1490920686_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s183165982x1490920686_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s183165982x1490920686_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s740336339x1862813792_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s740336339x1862813792_entry, 2, 0};

V g_list_2efoldl_24s740336339x1862813792(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s740336339x1862813792_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s740336339x1862813792(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s94444922x1860431141_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s94444922x1860431141_entry, 1, 0};

V g_list_2emap_24s94444922x1860431141(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s94444922x1860431141_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s94444922x1860431141_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s94444922x1860431141(a[0]);
}
Clo g_list_2efoldl_24s788715611x32297348_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s788715611x32297348_entry, 2, 0};

V g_list_2efoldl_24s788715611x32297348(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_a_246, v_z_240));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s788715611x32297348(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2eany_24s1877524499x1789047582_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1877524499x1789047582_entry, 2, 0};

V g_list_2eany_24s1877524499x1789047582(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2429;
    switch (heff_tag_of(v_x_242)) {
    case TAG_PartVal: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SVar: {
        V v_a_245 = heff_field(v_a_244, 0);
        v_t_2429 = heff_bool(heff_strEq_c_lent(v_lit_240, v_a_245, 0));
        break;
      }
      case TAG_SGlobal: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        v_t_2429 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    case TAG_PartOp: {
      v_t_2429 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2429);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1877524499x1789047582_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2eany_24s1877524499x1789047582(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1817528582x392224400_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1817528582x392224400_entry, 3, 0};

V g_list_2efoldl_24s1817528582x392224400(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246;
    if ((heff_dup(v_lit_240) == NTAG(TAG_True))) {
      V v_t_245 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_RepV)});
      v_t_246 = heff_tag_n(TAG_Often, 1, (V[]){v_t_245});
    } else {
      v_t_246 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_RepV)});
    }
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_243}), v_z_241});
    V t_0 = v_lit_240;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_247});
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1817528582x392224400_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efoldl_24s1817528582x392224400(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s348204425x880103432_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s348204425x880103432_entry, 2, 0};

V g_list_2efoldl_24s348204425x880103432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_n(TAG_IBind, 2, (V[]){v_t_246, heff_tag_n(TAG_OSimple, 1, (V[]){v_t_249})});
    V t_0 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s348204425x880103432(a[0], a[1]);
}
Clo g_list_2eany_24s52266323x652150664_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s52266323x652150664_entry, 1, 0};

V g_list_2eany_24s52266323x652150664(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = (g_heff_2ecompile_2erepr_2eloops(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s52266323x652150664_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s52266323x652150664(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1310249268x749995235_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1310249268x749995235_24dps_entry, 4, 0};

V g_list_2emap_24s1310249268x749995235_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erepr_2edecidedIn(v_lit_240, v_lit_241, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s1310249268x749995235_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s361779565x1527579812_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s361779565x1527579812_entry, 1, 0};

V g_list_2eany_24s361779565x1527579812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        V v_t_249 = (g_heff_2ecompile_2eborrow_2ebuildsSize(v_t_248, heff_dup(v_b_245)));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_249);
          V t_0 = v_xs_242;
          v_x2_240 = t_0;
          goto top;
        }
      }
      default: return heff_nomatch(v_vs_244);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s361779565x1527579812(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1416922510x485352908_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1416922510x485352908_entry, 2, 0};

V g_list_2efoldl_24s1416922510x485352908(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1416922510x485352908(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s976906006x1321876394_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s976906006x1321876394_entry, 4, 0};

V g_list_2efoldl_24s976906006x1321876394(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_2458;
    switch (heff_tag_of(v_x_244)) {
    case TAG_PartVal: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24PartVal = heff_take_reuse_n(v_x_244, 1ULL, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_SVar: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_246, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SProj: {
        V v_a_2424 = heff_field(v_a_246, 0);
        V v_a_2426 = heff_field(v_a_246, 2);
        heff_take_n(v_a_246, 5ULL, 4);
        switch (heff_tag_of(v_a_2424)) {
        case TAG_SVar: {
          V v_a_2428 = heff_field(v_a_2424, 0);
          heff_take_n(v_a_2424, 1ULL, 1);
          switch (heff_tag_of(v_a_2426)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24x3_243_24Cons, 2);
            heff_drop_cell(v_ru_24x_244_24PartVal, 1);
            heff_drop(v_a_2428);
            v_t_2458 = v_z_242;
            break;
          }
          case TAG_Cons: {
            V v_t_2431 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_2426; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_a_2426, 2); r_; });
            V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2428, heff_tag_at_n(v_ru_24x_244_24PartVal, TAG_KnownRec, 1, (V[]){v_t_2431})});
            v_t_2458 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2432, v_z_242});
            break;
          }
          default: heff_nomatch(v_a_2426);
          }
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SInt: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFloat: {
          heff_take_na(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SStr: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SBytes: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFixed: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFloat32: {
          heff_take_na(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SPrimFn: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SLam: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_STag: {
          heff_take_n(v_a_2424, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SRec: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SProj: {
          heff_take_n(v_a_2424, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SPrim: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        default: heff_nomatch(v_a_2424);
        }
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_243_24Cons, 2);
      v_t_2458 = v_z_242;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2458;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s976906006x1321876394(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s231073986x752637537_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231073986x752637537_24dps_entry, 3, 0};

V g_list_2emap_24s231073986x752637537_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231073986x752637537_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s522807745x1556762248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s522807745x1556762248_entry, 2, 0};

V g_list_2efoldl_24s522807745x1556762248(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_a_247)));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s522807745x1556762248(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1367173129x1257089258_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_entry, 1, 0};

V g_list_2emap_24s1367173129x1257089258(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1367173129x1257089258_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258(a[0]);
}
Clo g_list_2emap_24s1354671438x1264137843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354671438x1264137843_24dps_entry, 2, 0};

V g_list_2emap_24s1354671438x1264137843_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2egenerate_2egenExp_24s1881857797x800014078(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354671438x1264137843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354671438x1264137843_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1928181476x241816070_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1928181476x241816070_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, heff_tag_n(TAG_EVar, 1, (V[]){v_y_245})});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1928181476x241816070_24dps(a[0], a[1], a[2]);
}

HeffT2 g_list_2efind_24s192032632x1721482126_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 5);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24s1659194469x1936830512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1659194469x1936830512_entry, 2, 0};

V g_list_2efoldl_24s1659194469x1936830512(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_x_242));
    V v_t_2411;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      V v_ru_24a_244_24MkPair = heff_take_reuse_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        V v_ru_24z_240_24MkPair = heff_take_reuse_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2e_2b_2b_24tok2(v_ru_24a_244_24MkPair, v_a_245, v_a_247));
        V v_t_2410 = (g_prelude_2e_2b_2b_24tok2(v_ru_24z_240_24MkPair, v_a_246, v_a_248));
        v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, v_t_2410});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1659194469x1936830512(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str1, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str2, 2, ");");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str3, 10, "heff_drop(");
Clo g_list_2emap_24s577269653x49010166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_24dps_entry, 2, 0};

V g_list_2emap_24s577269653x49010166_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkDrop: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nothing: {
        V v_t_246 = ({ V a_0 = v_x_244; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s577269653x49010166_24dps_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
        V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str1), v_t_246), ((V)&g_list_2emap_24s577269653x49010166_24dps_str2));
        v_t_249 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str3), v_t_247);
        break;
      }
      case TAG_Just: {
        V v_k_248 = heff_field(v_x12_245, 0);
        heff_take_n(v_x12_245, 1ULL, 1);
        v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_244); heff_drop(v_k_248); r_; });
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1382928954x1260344933_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1382928954x1260344933_24dps_entry, 4, 0};

V g_list_2emap_24s1382928954x1260344933_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_intShow(v_x_244), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1382928954x1260344933_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1382928954x1260344933_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s588563787x236154271_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588563787x236154271_entry, 4, 0};

V g_list_2emap_24s588563787x236154271(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_242)));
    V v_t_2413 = heff_strAppend(heff_intShow(v_t_248), v_t_2412);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2413), heff_hole()});
    V v_u_2415 = (g_list_2emap_24s588563787x236154271_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s588563787x236154271_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588563787x236154271(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24s1882737314x358197882_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1882737314x358197882_entry, 4, 0};

V g_list_2efoldl_24s1882737314x358197882(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2enamesInGo(v_lit_240, heff_rfield(v_x_244, 1), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2efoldl_24s1882737314x358197882(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s989097923x484436710_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s989097923x484436710_entry, 2, 0};

V g_list_2efoldl_24s989097923x484436710(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    HeffT2 v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_t_2417;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_a_2416 = v_field_2415;
        v_t_2417 = v_a_2416;
      } else {
        heff_drop(v_field_2415);
        v_t_2417 = NTAG(TAG_Nil);
      }
    }
    V v_t_2418 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_t_246, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2417})));
    V t_0 = v_t_2418;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s989097923x484436710_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s989097923x484436710(a[0], a[1]);
}
Clo g_list_2emap_24s380834591x871125279_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_24dps_entry, 2, 0};

V g_list_2emap_24s380834591x871125279_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s313956312x193471538_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s313956312x193471538_entry, 4, 0};

V g_list_2eany_24s313956312x193471538(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strSlice(heff_dup(v_x_244), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_242, 1)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s313956312x193471538_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s313956312x193471538(a0, a1, a2, a3); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s1934210846x602559163_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1934210846x602559163_entry, 2, 0};

V g_list_2efoldl_24s1934210846x602559163(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      v_t_249 = v_a_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      v_t_2412 = heff_dup(v_a_2410);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 2ULL, 2);
      v_t_2415 = v_a_2414;
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = (g_std_2emap_2einsert_24s93785294x875597928(v_z_240, v_t_249, v_t_2415));
    V t_0 = v_t_2416;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1934210846x602559163_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1934210846x602559163(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s937655778x647278584_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s937655778x647278584_entry, 2, 0};

V g_list_2efoldl_24s937655778x647278584(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s1934210846x602559163(v_z_240, heff_rfield(v_x_242, 1)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s937655778x647278584_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s937655778x647278584(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s425699049x1164890302_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s425699049x1164890302_entry, 3, 0};

V g_list_2efoldl_24s425699049x1164890302(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddJs(heff_dup(v_lit_240), v_z_241, v_x_243));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s425699049x1164890302(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1494296198x1800016121_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1494296198x1800016121_entry, 3, 0};

V g_list_2efoldl_24s1494296198x1800016121(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddGroup(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1494296198x1800016121(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2eall_24s457861111x1513113784_clo = {{0x80000000u, K_CLO, 0}, g_list_2eall_24s457861111x1513113784_entry, 2, 0};

V g_list_2eall_24s457861111x1513113784(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ty_244 = heff_dup(heff_rfield(v_x_242, 1));
    V v_size_245 = heff_dup(heff_rfield(v_x_242, 2));
    HeffT2 v_t_246 = ({ V a_0 = v_ty_244; V a_1 = v_size_245; HeffT2 r_ = (g_heff_2esyntax_2epresyntax_2esegmentOdd_24cpr(a_0, a_1)); heff_drop(v_ty_244); heff_drop(v_size_245); r_; });
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        V v_a_249 = v_field_248;
        if (heff_intEq_c_lent(v_a_249, v_lit_240, 1)) {
          V t_0 = v_lit_240;
          V t_1 = v_xs_243;
          v_lit_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        } else {
          heff_drop(v_lit_240);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_lit_240);
        heff_drop(v_field_248);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eall_24s457861111x1513113784_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eall_24s457861111x1513113784(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s570961906x1112476114_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_24dps_entry, 2, 0};

V g_list_2emap_24s570961906x1112476114_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2elabelOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str10, 0, "");
Clo g_list_2emap_24s218655275x981659442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_24dps_entry, 2, 0};

V g_list_2emap_24s218655275x981659442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_VFun: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2411 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2417 = v_s_2411;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str8);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str9);
      break;
    }
    case TAG_VErased: {
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str10);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s1161549307x1906011635_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s1161549307x1906011635_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_SError: {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1161549307x1906011635_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1161549307x1906011635_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s900318151x1569363206_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s900318151x1569363206_24dps_entry, 4, 0};

V g_list_2emap_24s900318151x1569363206_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_name_246 = heff_take_field(v_x_244, 0);
    V v_tags_247 = heff_get_n(v_x_244, 1, 3);
    V v_t_248;
    if ((heff_dup(v_tags_247) == NTAG(TAG_True))) {
      heff_drop(v_tags_247);
      v_t_248 = heff_dup(v_lit_240);
    } else {
      heff_drop(v_tags_247);
      v_t_248 = heff_dup(v_lit_241);
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_name_246, v_t_248), heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s900318151x1569363206_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s900318151x1569363206_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2ekeepIf_24s1266148589x1647110933_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1266148589x1647110933_entry, 1, 0};

V g_list_2ekeepIf_24s1266148589x1647110933(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_241, 2)) == NTAG(TAG_True))) {
      V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s1266148589x1647110933_24dps(v_xs_242, heff_dup(v_cell_243)));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1266148589x1647110933(a[0]);
}
Clo g_list_2emap_24s173442543x1801751270_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_24dps_entry, 2, 0};

V g_list_2emap_24s173442543x1801751270_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x11_244, 0);
        V v_tsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 3);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_246, v_tsp_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2000102784x314586828_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_entry, 1, 0};

V g_list_2emap_24s2000102784x314586828(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s2000102784x314586828_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828(a[0]);
}
Clo g_list_2emap_24s1224226459x189329095_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1224226459x189329095_entry, 3, 0};

V g_list_2emap_24s1224226459x189329095(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 14);
    heff_drop_rec(v_lit_241, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_lit_241, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_x_243, 1)), heff_dup(heff_rfield(v_lit_241, 1)))));
    V v_t_246 = heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_lit_240, 1)), heff_dup(heff_rfield(v_lit_240, 3)), v_x_243, v_t_245});
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s1224226459x189329095_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1224226459x189329095_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1224226459x189329095(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s680990791x1764841948_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s680990791x1764841948_entry, 7, 0};

V g_list_2efoldl_24s680990791x1764841948(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_z_245, V v_x3_246) {
top: ;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_242);
    heff_drop(v_lit_244);
    return v_z_245;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x3_246, 0);
    V v_xs_248 = heff_field(v_x3_246, 1);
    V v_ru_24x3_246_24Cons = heff_take_reuse_n(v_x3_246, 3ULL, 2);
    V v_t_2411;
    if (heff_strEq_c_lent(v_x_247, v_lit_240, 0)) {
      heff_drop(v_x_247);
      switch (heff_tag_of(v_z_245)) {
      case TAG_Nil: {
        if ((heff_dup(v_lit_241) == NTAG(TAG_True))) {
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          v_t_2411 = NTAG(TAG_Nil);
        } else {
          v_t_2411 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_242), NTAG(TAG_Nil)});
        }
        break;
      }
      case TAG_Cons: {
        V v_a_249 = heff_dup(heff_field(v_z_245, 0));
        V v_a_2410 = heff_dup(heff_field(v_z_245, 1));
        if (heff_strEq_c_lent(v_a_249, v_lit_243, 1)) {
          heff_drop(v_a_2410);
          v_t_2411 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_244), v_z_245});
        } else {
          heff_drop_tag(v_z_245, 2);
          heff_drop_cell(v_ru_24x3_246_24Cons, 2);
          v_t_2411 = v_a_2410;
        }
        break;
      }
      default: heff_nomatch(v_z_245);
      }
    } else {
      v_t_2411 = heff_tag_at_n(v_ru_24x3_246_24Cons, TAG_Cons, 2, (V[]){v_x_247, v_z_245});
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_t_2411;
    V t_6 = v_xs_248;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_z_245 = t_5;
    v_x3_246 = t_6;
    goto top;
  }
  default: return heff_nomatch(v_x3_246);
  }
}
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s680990791x1764841948(a0, a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s675147852x248982264_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s675147852x248982264_entry, 2, 0};

V g_list_2emap_24s675147852x248982264(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_path_244 = heff_take_field(v_x_242, 1);
    V v_version_245 = heff_get_n(v_x_242, 2, 3);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_by__path__version, (V[]){heff_dup(v_lit_240), v_path_244, v_version_245}), heff_hole()});
    V v_u_247 = (g_list_2emap_24s675147852x248982264_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s675147852x248982264_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s675147852x248982264(a[0], a[1]);
}
Clo g_list_2eany_24s241416889x826324235_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s241416889x826324235_entry, 3, 0};

V g_list_2eany_24s241416889x826324235(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_path_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_version_246 = heff_dup(heff_rfield(v_x_243, 1));
    if ((heff_strEq_c_lent(v_path_245, v_lit_240, 0) && heff_strEq_c_lent(v_version_246, v_lit_241, 0))) {
      heff_drop(v_path_245);
      heff_drop(v_version_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_path_245);
      heff_drop(v_version_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s241416889x826324235_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s241416889x826324235(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1220809684x843195562_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1220809684x843195562_entry, 2, 0};

V g_list_2ekeepIf_24s1220809684x843195562(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1220809684x843195562_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1220809684x843195562(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2021078391x832341393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2021078391x832341393_entry, 3, 0};

V g_list_2emap_24s2021078391x832341393(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240))) {
      V v_t_245 = heff_intAdd(heff_take_field(v_x_243, 3), heff_dup(v_lit_241));
      v_t_246 = ({ V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_x_243, 23ULL, 5, shape_task__parent__name__done__total, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_246 = v_x_243;
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s2021078391x832341393_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s2021078391x832341393_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2021078391x832341393(a[0], a[1], a[2]);
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0(V self, V *args);
Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2062876492x2082655823_24scalars_entry, 3, 0};

V g_list_2efoldl_24s2062876492x2082655823_24scalars(V v_front_240, V v_back_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_front__back, (V[]){v_front_240, v_back_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V t_0 = v_front_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0, 1, 1, (V[]){v_x_243}), v_back_241});
    V t_2 = v_xs_244;
    v_front_240 = t_0;
    v_back_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2062876492x2082655823_24scalars(a[0], a[1], a[2]);
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_245);
  return v_x_243;
}
Clo g_list_2ekeepIf_24s1063601026x1972672043_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s1063601026x1972672043_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_x_243, 0)) - heff_unbox_word(heff_strLength_lent(v_lit_240, 0)));
    V v_t_246 = heff_strSlice(heff_dup(v_x_243), heff_box_word(v_t_245), heff_strLength_lent(v_x_243, 0));
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1063601026x1972672043_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1063601026x1972672043_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s192900907x155689445_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s192900907x155689445_entry, 3, 0};

V g_list_2efoldl_24s192900907x155689445(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_at_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_launch_246 = heff_dup(heff_rfield(v_x_243, 2));
    V v_pending_247 = heff_dup(heff_rfield(v_x_243, 1));
    V v_t_248 = (g_prelude_2e_2b_2b_24f686409757x475266571(v_z_241, v_at_245, v_launch_246, heff_dup(v_lit_240), heff_get_n(v_pending_247, 4, 7)));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s192900907x155689445(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1992606061x1037009925_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1992606061x1037009925_24dps_entry, 7, 0};

V g_list_2ekeepIf_24s1992606061x1037009925_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_245, 0);
    V v_xs_248 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_x_247, 0));
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_t_2412 = (g_list_2emap_24s674081137x339217813(heff_strRunes(v_t_2411)));
    V v_a_2413 = heff_strOfRunes(v_t_2412);
    V v_t_2414 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_a_2413}));
    V v_t_2415 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_lit_244), NTAG(TAG_Nil)});
    V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_lit_242), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_lit_243), v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_lit_240), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_lit_241), v_t_2416})});
    V v_a_2418 = ({ V a_0 = v_t_2414; V a_1 = v_t_2417; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_2417, 2); r_; });
    if (!(heff_dup(v_a_2418) == NTAG(TAG_True))) {
      heff_drop(v_a_2418);
      V v_cell_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, heff_hole()});
      V v_u_2420 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2419));
      heff_drop(v_u_2420);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_cell_2419;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    } else {
      heff_drop(v_x_247);
      heff_drop(v_a_2418);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_248;
      V t_6 = v_d_246;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2ekeepIf_24s1992606061x1037009925_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1992606061x1037009925_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}

HeffT2 g_list_2efind_24s1597853107x1363733222_24cpr(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_strAppend(heff_dup(heff_rfield(v_x_246, 0)), heff_dup(v_lit_242));
    V v_t_249 = heff_strFind(heff_strAppend(heff_dup(v_lit_241), v_t_248), heff_dup(v_lit_243), heff_dup(v_lit_244));
    if (heff_intLe_c_lent(v_lit_240, v_t_249, 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_xs_247);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_246}});
    } else {
      heff_drop_rec(v_x_246, 3);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_245)}});
  }
}
Clo g_list_2eany_24s2046291842x47540086_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s2046291842x47540086_entry, 4, 0};

V g_list_2eany_24s2046291842x47540086(V v_box_24lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_t_246 = heff_strLength(heff_dup(heff_rfield(v_x_244, 1)));
    if (((v_lit_240 < heff_peek_word(v_t_246)) || (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_241)) || heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), heff_dup(v_lit_242))))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      int64_t t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2eany_24s2046291842x47540086_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2eany_24s2046291842x47540086(a[0], a1, a2, a3); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2ekeepIf_24s1111636858x612918583_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1111636858x612918583_entry, 3, 0};

V g_list_2ekeepIf_24s1111636858x612918583(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_x_243, 0)), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_245, v_lit_241, 1)) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = (g_list_2ekeepIf_24s1111636858x612918583_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2ekeepIf_24s1111636858x612918583_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2ekeepIf_24s1111636858x612918583(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}

HeffT2 g_list_2efind_24s1867824208x1412174996_24cpr(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_xs_243);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop_rec(v_x_242, 4);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efoldl_24f71125586x1381947330_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f71125586x1381947330_entry, 4, 0};

V g_list_2efoldl_24f71125586x1381947330(V v_lit_240, V v_z_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_242))) {
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f71125586x1381947330_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_list_2efoldl_24f71125586x1381947330(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24f405781872x1513910762_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f405781872x1513910762_entry, 6, 0};

V g_list_2emap_24f405781872x1513910762(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_p_244, V v_x2_245) {
top: ;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_p_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24Cons = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_244), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_intShow(v_x_246), heff_dup(v_lit_243));
      V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(v_lit_242), v_t_249));
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_245_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2410), heff_hole()});
      V v_u_2412 = (g_list_2emap_24f405781872x1513910762_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_p_244, v_xs_247, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    } else {
      heff_drop(v_x_246);
      heff_drop_cell(v_ru_24x2_245_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_p_244;
      V t_5 = v_xs_247;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_p_244 = t_4;
      v_x2_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_list_2emap_24f405781872x1513910762_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f405781872x1513910762(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1502491305x440718220_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1502491305x440718220_24dps_entry, 3, 0};

V g_list_2emap_24f1502491305x440718220_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2emap_24s864521685x1610969087(v_ys_241));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2ehint(v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_245;
    V t_1 = v_ys_241;
    V t_2 = v_cell_247;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1502491305x440718220_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f700195413x1431112932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f700195413x1431112932_entry, 3, 0};

V g_list_2efoldl_24f700195413x1431112932(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_xs_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_243); r_; });
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_t_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x1_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f700195413x1431112932(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f1213328022x1811586494_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1213328022x1811586494_entry, 2, 0};

V g_list_2emap_24f1213328022x1811586494(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_binder_244 = heff_take_field(v_x_242, 0);
    V v_use_245 = heff_get_n(v_x_242, 1, 2);
    V v_a_246 = heff_get_n(v_binder_244, 1, 3);
    V v_start_247 = heff_take_field(v_a_246, 0);
    V v_end_248 = heff_get_n(v_a_246, 1, 2);
    V v_a_249 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_2410 = heff_take_field(v_a_249, 0);
    V v_end_2411 = heff_get_n(v_a_249, 1, 2);
    if ((heff_intEq_c_lent(v_start_247, v_start_2410, 0) && heff_intEq_c_lent(v_end_248, v_end_2411, 0))) {
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_start_2410);
      heff_drop(v_end_2411);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_use_245, heff_hole()});
      V v_u_2413 = (g_list_2emap_24f1213328022x1811586494_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_use_245);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_start_2410);
      heff_drop(v_end_2411);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1213328022x1811586494(a[0], a[1]);
}
Clo g_list_2ekeepIf_24f1278780364x1365377410_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1278780364x1365377410_entry, 7, 0};

V g_list_2ekeepIf_24f1278780364x1365377410(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_lit_242), heff_dup(v_lit_243), heff_intAdd(heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_x_2410 = heff_strAppend(v_t_249, v_x_247);
    V v_t_2411 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_2411, v_lit_241, 1)) {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2413 = (g_list_2ekeepIf_24f1278780364x1365377410_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    } else {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_x_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2ekeepIf_24f1278780364x1365377410_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2ekeepIf_24f1278780364x1365377410(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_list_2emap_24s2029035892x1571084362_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_24tok2_entry, 2, 0};

V g_list_2emap_24s2029035892x1571084362_24tok2(V v_tok_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_245 = (g_list_2emap_24s2029035892x1571084362_24dps(v_xs_243, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2029035892x1571084362_24tok2_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362_24tok2(a[0], a[1]);
}