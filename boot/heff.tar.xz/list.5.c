// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AssocLeft 30812
#define TAG_AssocNone 34711
#define TAG_AssocRight 63268
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_Binds 36386
#define TAG_Boxed 28180
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_HS 9084
#define TAG_IBind 27068
#define TAG_IsCheckable 22614
#define TAG_IsInferable 49402
#define TAG_IsType 1727
#define TAG_Kept 49931
#define TAG_MkAlt 55173
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_MkFieldPat 14710
#define TAG_None 17785
#define TAG_OSimple 59809
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_Pinned 8573
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define TAG_SetPath 11095
#define TAG_TChk 23015
#define TAG_TInf 28962
#define TAG_TagVariant 25174
#define TAG_Text 56194
#define TAG_VArr 15466
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42634
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define LBL_assoc 294479919
#define LBL_body 9524841
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_dir 308999
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_from 9647217
#define LBL_holds 300818350
#define LBL_id 10114
#define LBL_item 9738202
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_long 9823043
#define LBL_looser 850054335
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_ok 10307
#define LBL_ops 319788
#define LBL_parent 951717845
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tighter 1059982480
#define LBL_ty 10476
#define LBL_use 325633
#define LBL_watch 314261737
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2ebuildsSize(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2efuse_2eproducerOf(V, V);
V g_heff_2ecompile_2efuse_2eproducerOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2eproducerOf_clo;
V g_heff_2ecompile_2efuse_2etailsOf(V);
V g_heff_2ecompile_2efuse_2etailsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2efuse_2etailsOf_clo;
V g_heff_2ecompile_2einterp_2eshowValGo(V, V);
V g_heff_2ecompile_2einterp_2eshowValGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2einterp_2eshowValGo_clo;
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2erepr_2eflatFields_get(void);
V g_heff_2ecompile_2erepr_2efourTo(V);
V g_heff_2ecompile_2erepr_2efourTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2efourTo_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(V);
V g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143_clo;
V g_heff_2eelab_2eprint_2ecommaSep(V);
V g_heff_2eelab_2eprint_2ecommaSep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2ecommaSep_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2epr_get(void);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2etoplevel_2ethawOne(V, V);
V g_heff_2eelab_2etoplevel_2ethawOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawOne_clo;
V g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get(void);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(V, V);
V g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2elayout_2ertrimEnd_clo;
V g_heff_2esyntax_2eformat_2epatKey(V);
V g_heff_2esyntax_2eformat_2epatKey_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eformat_2epatKey_clo;
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(V);
V g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277_clo;
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(V);
V g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_clo;
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(V);
V g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400_clo;
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(V);
V g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
V g_list_2efilter_24s1018181017x1541469354_24dps(V, V);
V g_list_2efilter_24s1018181017x1541469354_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_24dps_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
V g_list_2efilter_24s1064353769x1815078842_24dps(V, V);
V g_list_2efilter_24s1064353769x1815078842_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_24dps_clo;
V g_list_2efilter_24s1490692278x809324339_24dps(V, V);
V g_list_2efilter_24s1490692278x809324339_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1490692278x809324339_24dps_clo;
V g_list_2efilter_24s1880530801x1683594418(V, V);
V g_list_2efilter_24s1880530801x1683594418_entry(V self, V *a);
extern Clo g_list_2efilter_24s1880530801x1683594418_clo;
V g_list_2efilter_24s1880530801x1683594418_24dps(V, V, V);
V g_list_2efilter_24s1880530801x1683594418_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1880530801x1683594418_24dps_clo;
V g_list_2efilter_24s2018073091x1385246979(V);
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_clo;
V g_list_2efilter_24s2018073091x1385246979_24dps(V, V);
V g_list_2efilter_24s2018073091x1385246979_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_24dps_clo;
V g_list_2efilter_24s2056490818x625949248_24dps(V, V, V);
V g_list_2efilter_24s2056490818x625949248_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2056490818x625949248_24dps_clo;
V g_list_2efilter_24s2102446697x281519753(V);
V g_list_2efilter_24s2102446697x281519753_entry(V self, V *a);
extern Clo g_list_2efilter_24s2102446697x281519753_clo;
V g_list_2efilter_24s2102446697x281519753_24dps(V, V);
V g_list_2efilter_24s2102446697x281519753_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2102446697x281519753_24dps_clo;
V g_list_2efind_24s913819130x636901392(V, V);
V g_list_2efind_24s913819130x636901392_entry(V self, V *a);
extern Clo g_list_2efind_24s913819130x636901392_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1199449138x692104932(V, V, V);
V g_list_2efoldl_24f1199449138x692104932_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1199449138x692104932_clo;
V g_list_2efoldl_24f1715293669x1931437372(V, V, V, V);
V g_list_2efoldl_24f1715293669x1931437372_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1715293669x1931437372_clo;
V g_list_2efoldl_24f1717515461x1947736435(V, V, V, V);
V g_list_2efoldl_24f1717515461x1947736435_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1717515461x1947736435_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1347985788x1836008258(V, V);
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1347985788x1836008258_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s1472875662x470242985(V, V);
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1472875662x470242985_clo;
V g_list_2efoldl_24s1486300758x450371661(V, V, V);
V g_list_2efoldl_24s1486300758x450371661_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1486300758x450371661_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1854174827x1081689521(V, V);
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1854174827x1081689521_clo;
V g_list_2efoldl_24s2126981320x1580482478(V, V);
V g_list_2efoldl_24s2126981320x1580482478_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2126981320x1580482478_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s316188476x878636287(V, V);
V g_list_2efoldl_24s316188476x878636287_entry(V self, V *a);
extern Clo g_list_2efoldl_24s316188476x878636287_clo;
V g_list_2efoldl_24s324619290x435523318(V, V);
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a);
extern Clo g_list_2efoldl_24s324619290x435523318_clo;
V g_list_2efoldl_24s337463599x663364213(V, V);
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a);
extern Clo g_list_2efoldl_24s337463599x663364213_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s616126380x659562620(V, V);
V g_list_2efoldl_24s616126380x659562620_entry(V self, V *a);
extern Clo g_list_2efoldl_24s616126380x659562620_clo;
V g_list_2efoldl_24s775969440x1318400394(V, V, V);
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s775969440x1318400394_clo;
V g_list_2efoldl_24s895442511x653187280(V, V, V);
V g_list_2efoldl_24s895442511x653187280_entry(V self, V *a);
extern Clo g_list_2efoldl_24s895442511x653187280_clo;
V g_list_2efoldl_24s897254394x2030899844(V, V, V);
V g_list_2efoldl_24s897254394x2030899844_entry(V self, V *a);
extern Clo g_list_2efoldl_24s897254394x2030899844_clo;
V g_list_2efoldl_24s964765707x1396946999(V, V);
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s964765707x1396946999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1256088967x1733220017_24dps(V, V, V, V);
V g_list_2emap_24f1256088967x1733220017_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1256088967x1733220017_24dps_clo;
V g_list_2emap_24f131620269x1652606631_24dps(V, V, V, V);
V g_list_2emap_24f131620269x1652606631_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f131620269x1652606631_24dps_clo;
V g_list_2emap_24f1686943972x1657456902(V, V);
V g_list_2emap_24f1686943972x1657456902_entry(V self, V *a);
extern Clo g_list_2emap_24f1686943972x1657456902_clo;
V g_list_2emap_24f1686943972x1657456902_24dps(V, V, V);
V g_list_2emap_24f1686943972x1657456902_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1686943972x1657456902_24dps_clo;
V g_list_2emap_24f1824207880x1057248167(V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1824207880x1057248167_entry(V self, V *a);
extern Clo g_list_2emap_24f1824207880x1057248167_clo;
V g_list_2emap_24f1824207880x1057248167_24dps(V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24f1824207880x1057248167_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1824207880x1057248167_24dps_clo;
V g_list_2emap_24f482741271x1112521151_24dps(V, V, V, V, V, V);
V g_list_2emap_24f482741271x1112521151_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f482741271x1112521151_24dps_clo;
V g_list_2emap_24s1006477676x1816442814(V, V, V);
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_clo;
V g_list_2emap_24s1006477676x1816442814_24dps(V, V, V, V);
V g_list_2emap_24s1006477676x1816442814_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1006477676x1816442814_24dps_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1195846327x230486685_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s1195846327x230486685_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1195846327x230486685_24dps_clo;
V g_list_2emap_24s1221903513x233153387(V);
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a);
extern Clo g_list_2emap_24s1221903513x233153387_clo;
V g_list_2emap_24s1221903513x233153387_24dps(V, V);
V g_list_2emap_24s1221903513x233153387_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1221903513x233153387_24dps_clo;
V g_list_2emap_24s1230969749x2018313496(V);
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_clo;
V g_list_2emap_24s1230969749x2018313496_24dps(V, V);
V g_list_2emap_24s1230969749x2018313496_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1230969749x2018313496_24dps_clo;
V g_list_2emap_24s1354328764x1362350361_24dps(V, V);
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1354328764x1362350361_24dps_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_list_2emap_24s1534624020x121531103_24dps(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s1534624020x121531103_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1534624020x121531103_24dps_clo;
V g_list_2emap_24s1543151117x629172256(V);
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_clo;
V g_list_2emap_24s1543151117x629172256_24dps(V, V);
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s1887874170x1747433177(V);
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_clo;
V g_list_2emap_24s1887874170x1747433177_24dps(V, V);
V g_list_2emap_24s1887874170x1747433177_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1887874170x1747433177_24dps_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s272272626x1430728348_24dps(V, V, V, V, V, V, V, V, V, V, V, V);
V g_list_2emap_24s272272626x1430728348_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s272272626x1430728348_24dps_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s386875578x1005587669_24dps(V, V);
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s386875578x1005587669_24dps_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s404123879x745642248_24dps(V, V);
V g_list_2emap_24s404123879x745642248_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_24dps_clo;
V g_list_2emap_24s500158289x1934493753_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s500158289x1934493753_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s500158289x1934493753_24dps_clo;
V g_list_2emap_24s510639937x1058700299_24dps(V, V);
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s510639937x1058700299_24dps_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s539093115x379698116_24dps(V, V);
V g_list_2emap_24s539093115x379698116_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s539093115x379698116_24dps_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s725725455x1186198702_24dps(V, V);
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s725725455x1186198702_24dps_clo;
V g_list_2emap_24s764064723x821001015(V);
V g_list_2emap_24s764064723x821001015_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_clo;
V g_list_2emap_24s764064723x821001015_24dps(V, V);
V g_list_2emap_24s764064723x821001015_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_24dps_clo;
V g_list_2emap_24s891258639x530975267_24dps(V, V, V);
V g_list_2emap_24s891258639x530975267_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s891258639x530975267_24dps_clo;
V g_list_2emap_24s952531872x538225679(V, V);
V g_list_2emap_24s952531872x538225679_entry(V self, V *a);
extern Clo g_list_2emap_24s952531872x538225679_clo;
V g_list_2emap_24s952531872x538225679_24dps(V, V, V);
V g_list_2emap_24s952531872x538225679_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s952531872x538225679_24dps_clo;
V g_list_2emerge_24s1347843181x1368204458_24dps(V, V, V);
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo;
V g_list_2emerge_24s1840066165x1513718921_24dps(V, V, V);
V g_list_2emerge_24s1840066165x1513718921_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_24dps_clo;
V g_list_2ezipWith_24s1610853704x1401907306(V, V, V);
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1610853704x1401907306_clo;
V g_list_2ezipWith_24s1610853704x1401907306_24dps(V, V, V, V);
V g_list_2ezipWith_24s1610853704x1401907306_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1610853704x1401907306_24dps_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s1958630276x749154843_24dps(V, V, V);
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo;
V g_list_2ezipWith_24s738847920x410598254_24dps(V, V, V);
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f368057430x559112032(V, V);
V g_prelude_2e_2b_2b_24f368057430x559112032_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f368057430x559112032_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2edoc_2e_3c_3e(V, V);
V g_std_2edoc_2e_3c_3e_entry(V self, V *a);
extern Clo g_std_2edoc_2e_3c_3e_clo;
V g_std_2edoc_2ehardline_get(void);
Clo g_list_2efoldl_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_entry, 3, 0};

V g_list_2efoldl(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){v_z_241, heff_dup(v_x_243)}));
    V t_0 = v_f_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_f_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1116451536x2100070357_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1116451536x2100070357_entry, 3, 0};

V g_list_2efoldl_24s1116451536x2100070357(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_xs_244 = heff_field(v_x3_242, 1);
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1116451536x2100070357(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efilter_24s2056490818x625949248_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2056490818x625949248_24dps_entry, 3, 0};

V g_list_2efilter_24s2056490818x625949248_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLt_c(heff_dup(v_lit_240), heff_strLength(heff_dup(v_x_243)))) {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s2056490818x625949248_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2056490818x625949248_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emerge_24s1347843181x1368204458_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1347843181x1368204458_24dps_entry, 3, 0};

V g_list_2emerge_24s1347843181x1368204458_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 7);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_x_243, 2)), heff_dup(heff_rfield(v_y_245, 2)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_248;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_2410;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1347843181x1368204458_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1347843181x1368204458_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1844509821x2028168277_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_entry, 1, 0};

V g_list_2emap_24s1844509821x2028168277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_248;
      break;
    }
    case TAG_IsType: {
      V v_a_249 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2412;
      switch (heff_tag_of(v_a_249)) {
      case TAG_At: {
        V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
        v_t_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_a_249);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_249}), v_t_2412});
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    V v_cell_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s1844509821x2028168277_24dps(v_xs_242, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277(a[0]);
}
Clo g_list_2emap_24s1887874170x1747433177_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1887874170x1747433177_entry, 1, 0};

V g_list_2emap_24s1887874170x1747433177(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033(v_x_241));
    V v_t_2413;
    switch (heff_tag_of(v_a_243)) {
    case TAG_IsInferable: {
      V v_a_244 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_247;
      switch (heff_tag_of(v_a_244)) {
      case TAG_At: {
        V v_a_246 = heff_dup(heff_field(v_a_244, 1));
        v_t_247 = v_a_246;
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_TInf, 1, (V[]){v_a_244}), v_t_247});
      break;
    }
    case TAG_IsCheckable: {
      V v_a_248 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      V v_t_2411;
      switch (heff_tag_of(v_a_248)) {
      case TAG_At: {
        V v_a_2410 = heff_dup(heff_field(v_a_248, 1));
        v_t_2411 = v_a_2410;
        break;
      }
      default: heff_nomatch(v_a_248);
      }
      v_t_2413 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_TChk, 1, (V[]){v_a_248}), v_t_2411});
      break;
    }
    case TAG_IsType: {
      V v_a_2412 = heff_field(v_a_243, 0);
      heff_take_n(v_a_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_2413 = v_a_2412;
      break;
    }
    default: heff_nomatch(v_a_243);
    }
    V v_cell_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
    V v_u_2415 = (g_list_2emap_24s1887874170x1747433177_24dps(v_xs_242, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1887874170x1747433177_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1887874170x1747433177(a[0]);
}
Clo g_list_2emap_24s1230969749x2018313496_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1230969749x2018313496_entry, 1, 0};

V g_list_2emap_24s1230969749x2018313496(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2ealtOf_24s1421917657x1943947277(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1230969749x2018313496_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1230969749x2018313496_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1230969749x2018313496(a[0]);
}
Clo g_list_2emap_24s539093115x379698116_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s539093115x379698116_24dps_entry, 2, 0};

V g_list_2emap_24s539093115x379698116_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2epresyntax_2eparamOf_24s398354074x1975292629(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s539093115x379698116_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s539093115x379698116_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s513391942x823299088_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_entry, 1, 0};

V g_list_2emap_24s513391942x823299088(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_248 = (g_list_2emap_24s158244903x55062455(v_a_247));
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, v_t_248});
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          heff_take_n(v_a_249, 3ULL, 2);
          v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2411, v_a_2410));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s513391942x823299088_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088(a[0]);
}
Clo g_list_2emap_24s386875578x1005587669_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s386875578x1005587669_24dps_entry, 2, 0};

V g_list_2emap_24s386875578x1005587669_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2esyntax_2epresyntax_2edeclN_24s1395291674x1719447400(v_a_244));
      v_t_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_At, 2, (V[]){v_t_246, v_a_245});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s386875578x1005587669_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s386875578x1005587669_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1543151117x629172256_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_entry, 1, 0};

V g_list_2emap_24s1543151117x629172256(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1543151117x629172256_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256(a[0]);
}
Clo g_list_2efoldl_24s1347985788x1836008258_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1347985788x1836008258_entry, 2, 0};

V g_list_2efoldl_24s1347985788x1836008258(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_x_242)));
    V v_t_245 = (g_prelude_2e_2b_2b_24f368057430x559112032(v_z_240, v_t_244));
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1347985788x1836008258_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1347985788x1836008258(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1123370502x1982532655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_24dps_entry, 2, 0};

V g_list_2emap_24s1123370502x1982532655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s895442511x653187280_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s895442511x653187280_entry, 3, 0};

V g_list_2efoldl_24s895442511x653187280(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_247;
    if (heff_intLt_c(heff_dup(v_x_243), heff_dup(g_heff_2ecompile_2erepr_2eflatFields_get()))) {
      V v_t_246 = (g_heff_2ecompile_2erepr_2efourTo(heff_dup(v_x_243)));
      v_t_247 = heff_intAdd(v_z_241, heff_intMul(heff_dup(v_lit_240), v_t_246));
    } else {
      v_t_247 = v_z_241;
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_247;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s895442511x653187280_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s895442511x653187280(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s964765707x1396946999_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s964765707x1396946999_entry, 2, 0};

V g_list_2efoldl_24s964765707x1396946999(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_242)}), v_z_240});
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Pinned, 1, (V[]){v_x_242}), v_t_244});
    V t_0 = v_t_245;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s964765707x1396946999_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s964765707x1396946999(a[0], a[1]);
}
Clo g_list_2efoldl_24s348204425x880103432_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s348204425x880103432_entry, 2, 0};

V g_list_2efoldl_24s348204425x880103432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_IBind, 2, (V[]){v_t_246, heff_tag_n(TAG_OSimple, 1, (V[]){v_t_249})});
    V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s348204425x880103432(a[0], a[1]);
}
Clo g_list_2efoldl_24s1854174827x1081689521_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1854174827x1081689521_entry, 2, 0};

V g_list_2efoldl_24s1854174827x1081689521(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_x22_245 = heff_field(v_x_242, 1);
      V v_ru_24x_242_24MkPair = heff_take_reuse_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x22_245)) {
      case TAG_RepV: {
        V v_t_246 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_244)}), v_z_240});
        v_t_2410 = heff_tag_at_n(v_ru_24x_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_244}), v_t_246});
        break;
      }
      case TAG_RepFix: {
        V v_t_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_244)}), v_z_240});
        v_t_2410 = heff_tag_at_n(v_ru_24x_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_244, v_x22_245}), v_t_248});
        break;
      }
      case TAG_RepF64: {
        V v_t_249 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Binds, 1, (V[]){heff_dup(v_x_244)}), v_z_240});
        v_t_2410 = heff_tag_at_n(v_ru_24x_242_24MkPair, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Kept, 2, (V[]){v_x_244, v_x22_245}), v_t_249});
        break;
      }
      default: heff_nomatch(v_x22_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_2410;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1854174827x1081689521_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1854174827x1081689521(a[0], a[1]);
}
Clo g_list_2eany_24s361779565x1527579812_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s361779565x1527579812_entry, 1, 0};

V g_list_2eany_24s361779565x1527579812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      V v_x1_248;
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        v_x1_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        v_x1_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      if ((heff_dup(v_x1_248) == NTAG(TAG_True))) {
        heff_drop(v_x1_248);
        v_t_2410 = NTAG(TAG_False);
      } else {
        heff_drop(v_x1_248);
        V v_t_249 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        v_t_2410 = (g_heff_2ecompile_2eborrow_2ebuildsSize(v_t_249, heff_dup(v_b_245)));
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2410);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s361779565x1527579812(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1416922510x485352908_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1416922510x485352908_entry, 2, 0};

V g_list_2efoldl_24s1416922510x485352908(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1416922510x485352908(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s272272626x1430728348_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s272272626x1430728348_24dps_entry, 12, 0};

V g_list_2emap_24s272272626x1430728348_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_lit_249, V v_x2_2410, V v_d_2411) {
top: ;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    heff_drop(v_lit_249);
    return heff_setField(v_d_2411, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2410, 0);
    V v_xs_2413 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24Cons = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    V v_t_2423;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_a_2414 = heff_field(v_x_2412, 0);
      V v_a_2415 = heff_field(v_x_2412, 1);
      heff_take_n(v_x_2412, 3ULL, 2);
      V v_t_2416 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2414, heff_dup(v_lit_242)));
      V v_t_2417 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2416, heff_dup(v_lit_243)));
      V v_a_2418 = (g_list_2emap(heff_dup(heff_rfield(g_heff_2eelab_2eprint_2epr_get(), 1)), heff_arrayToList(v_a_2415)));
      V v_t_2419 = ({ V a_0 = v_a_2418; V r_ = (g_heff_2eelab_2eprint_2ecommaSep(a_0)); heff_drop(v_a_2418); r_; });
      V v_t_2420 = heff_strAppend(heff_dup(v_lit_246), heff_strAppend(v_t_2419, heff_dup(v_lit_247)));
      V v_t_2421 = heff_strAppend(heff_dup(v_lit_245), heff_strAppend(v_t_2420, heff_dup(v_lit_248)));
      V v_t_2422 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2421, heff_dup(v_lit_249)));
      v_t_2423 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2417, v_t_2422));
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_2410_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_2411, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_lit_249;
    V t_10 = v_xs_2413;
    V t_11 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_lit_249 = t_9;
    v_x2_2410 = t_10;
    v_d_2411 = t_11;
    goto top;
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_list_2emap_24s272272626x1430728348_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s272272626x1430728348_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
}
Clo g_list_2emap_24s500158289x1934493753_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s500158289x1934493753_24dps_entry, 8, 0};

V g_list_2emap_24s500158289x1934493753_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2416;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      heff_take_n(v_x_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2eelab_2eprint_2eescFrom(v_a_2410, heff_dup(v_lit_242)));
      V v_t_2413 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2412, heff_dup(v_lit_243)));
      V v_t_2414 = ({ V a_0 = v_a_2411; V r_ = (g_heff_2eelab_2eprint_2earmOf_24s249199213x1382765143(a_0)); heff_drop(v_a_2411); r_; });
      V v_t_2415 = heff_strAppend(heff_dup(v_lit_244), heff_strAppend(v_t_2414, heff_dup(v_lit_245)));
      v_t_2416 = heff_strAppend(heff_dup(v_lit_240), heff_strAppend(v_t_2413, v_t_2415));
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2417 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
    V v_u_2418 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2417;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s500158289x1934493753_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s500158289x1934493753_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2efoldl_24s522807745x1556762248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s522807745x1556762248_entry, 2, 0};

V g_list_2efoldl_24s522807745x1556762248(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s522807745x1556762248(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1367173129x1257089258_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_entry, 1, 0};

V g_list_2emap_24s1367173129x1257089258(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1367173129x1257089258_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258(a[0]);
}
Clo g_list_2efoldl_24s324619290x435523318_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s324619290x435523318_entry, 2, 0};

V g_list_2efoldl_24s324619290x435523318(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_248 = (g_heff_2ecompile_2efuse_2etailsOf(v_t_247));
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s324619290x435523318_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s324619290x435523318(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s738847920x410598254_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s738847920x410598254_24dps_entry, 3, 0};

V g_list_2ezipWith_24s738847920x410598254_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      heff_take_n(v_ys_241, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkArm: {
        V v_a_247 = heff_dup(heff_field(v_x_243, 0));
        v_t_2410 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2414;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkArm: {
        V v_a_2412 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 2ULL, 3);
        v_t_2414 = v_a_2412;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2410, v_t_2414, v_y_245}), heff_hole()});
      V v_u_2416 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_2415;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s738847920x410598254_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s738847920x410598254_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s2102446697x281519753_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2102446697x281519753_entry, 1, 0};

V g_list_2efilter_24s2102446697x281519753(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_a_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_243 = heff_dup(heff_field(v_x_241, 0));
      v_a_245 = v_a_243;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_248;
    switch (heff_tag_of(v_a_245)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_a_245, 1);
      heff_take_n(v_a_245, 2ULL, 2);
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s2102446697x281519753_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    } else {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2102446697x281519753_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2102446697x281519753(a[0]);
}
Clo g_list_2efoldl_24s316188476x878636287_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s316188476x878636287_entry, 2, 0};

V g_list_2efoldl_24s316188476x878636287(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_a_244 = (g_heff_2ecompile_2efuse_2eproducerOf(heff_dup(heff_rfield(v_x_242, 0)), heff_rfield(v_x_242, 2)));
    V v_t_246;
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      v_t_246 = v_z_240;
      break;
    }
    case TAG_Just: {
      V v_a_245 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      v_t_246 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_x_242, 0)), v_a_245, v_z_240));
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_246;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s316188476x878636287_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s316188476x878636287(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s510639937x1058700299_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s510639937x1058700299_24dps_entry, 2, 0};

V g_list_2emap_24s510639937x1058700299_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 3, 5), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s510639937x1058700299_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s510639937x1058700299_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1610853704x1401907306_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1610853704x1401907306_entry, 3, 0};

V g_list_2ezipWith_24s1610853704x1401907306(V v_lit_240, V v_xs_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_ys_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_241, 0);
    V v_xs2_244 = heff_field(v_xs_241, 1);
    V v_ru_24xs_241_24Cons = heff_take_reuse_n(v_xs_241, 3ULL, 2);
    switch (heff_tag_of(v_ys_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_242, 0);
      V v_ys2_246 = heff_field(v_ys_242, 1);
      heff_take_n(v_ys_242, 3ULL, 2);
      V v_t_247 = heff_strAppend(v_x_243, heff_strAppend(heff_dup(v_lit_240), v_y_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24xs_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = (g_list_2ezipWith_24s1610853704x1401907306_24dps(v_lit_240, v_xs2_244, v_ys2_246, heff_dup(v_cell_248)));
      heff_drop(v_u_249);
      return v_cell_248;
    }
    default: return heff_nomatch(v_ys_242);
    }
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_list_2ezipWith_24s1610853704x1401907306_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1610853704x1401907306(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s1659194469x1936830512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1659194469x1936830512_entry, 2, 0};

V g_list_2efoldl_24s1659194469x1936830512(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_x_242));
    V v_t_2411;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2e_2b_2b(v_a_245, v_a_247));
        V v_t_2410 = (g_prelude_2e_2b_2b(v_a_246, v_a_248));
        v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, v_t_2410});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1659194469x1936830512(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str1, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str2, 2, ");");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str3, 10, "heff_drop(");
Clo g_list_2emap_24s577269653x49010166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_24dps_entry, 2, 0};

V g_list_2emap_24s577269653x49010166_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkDrop: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nothing: {
        V v_t_246 = (g_heff_2ecompile_2eemitc_2emangleW(v_x_244, MK_INT(0LL), MK_INT(0LL), ((V)&g_list_2emap_24s577269653x49010166_24dps_str0)));
        V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str1), v_t_246), ((V)&g_list_2emap_24s577269653x49010166_24dps_str2));
        v_t_249 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str3), v_t_247);
        break;
      }
      case TAG_Just: {
        V v_k_248 = heff_field(v_x12_245, 0);
        heff_take_n(v_x12_245, 1ULL, 1);
        v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_k_248); r_; });
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1006477676x1816442814_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1006477676x1816442814_entry, 3, 0};

V g_list_2emap_24s1006477676x1816442814(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_strAppend(heff_intShow(v_x_243), heff_dup(v_lit_241));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_245), heff_hole()});
    V v_u_247 = (g_list_2emap_24s1006477676x1816442814_24dps(v_lit_240, v_lit_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1006477676x1816442814_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1006477676x1816442814(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1018181017x1541469354_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1018181017x1541469354_24dps_entry, 2, 0};

V g_list_2efilter_24s1018181017x1541469354_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = ({ V a_0 = v_t_246; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_247);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_a_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1018181017x1541469354_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1018181017x1541469354_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s380834591x871125279_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_24dps_entry, 2, 0};

V g_list_2emap_24s380834591x871125279_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1486300758x450371661_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1486300758x450371661_entry, 3, 0};

V g_list_2efoldl_24s1486300758x450371661(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_intAdd(v_z_241, heff_strLength(heff_dup(v_x_243)));
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_t_245, v_lit_240);
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1486300758x450371661_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1486300758x450371661(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s616126380x659562620_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s616126380x659562620_entry, 2, 0};

V g_list_2efoldl_24s616126380x659562620(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s2126981320x1580482478(v_z_240, heff_rfield(v_x_242, 3)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s616126380x659562620_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s616126380x659562620(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s891258639x530975267_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s891258639x530975267_24dps_entry, 3, 0};

V g_list_2emap_24s891258639x530975267_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 2ULL, 2);
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2411 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_t_2410; V r_ = (g_heff_2ecompile_2einterp_2eshowValGo(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2412 = heff_strAppend(v_t_247, heff_strAppend(heff_dup(v_lit_240), v_t_2411));
    V v_cell_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
    V v_u_2414 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2413));
    heff_drop(v_u_2414);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_2413;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s891258639x530975267_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s891258639x530975267_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s897254394x2030899844_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s897254394x2030899844_entry, 3, 0};

V g_list_2efoldl_24s897254394x2030899844(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_2419;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_246, 0);
        if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_lit_240))) {
          v_t_2419 = v_z_241;
        } else {
          if (heff_strEq_c(heff_dup(v_a_247), heff_dup(v_a_245))) {
            v_t_2419 = v_z_241;
          } else {
            V v_t_2410 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_a_247), heff_dup(v_a_245)));
            v_t_2419 = heff_tr(heff_call(heff_get_n(v_t_2410, 3, 5), 1, (V[]){v_z_241}));
          }
        }
        break;
      }
      case TAG_PTag: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PLit: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PRec: {
        v_t_2419 = v_z_241;
        break;
      }
      case TAG_PAs: {
        v_t_2419 = v_z_241;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_t_2419;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s897254394x2030899844_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s897254394x2030899844(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s337463599x663364213_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s337463599x663364213_entry, 2, 0};

V g_list_2efoldl_24s337463599x663364213(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2eelab_2etoplevel_2ethawOne(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s337463599x663364213_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s337463599x663364213(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1354328764x1362350361_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1354328764x1362350361_24dps_entry, 2, 0};

V g_list_2emap_24s1354328764x1362350361_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_t_246, 0, 2), heff_hole()});
    V v_u_248 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_243;
    V t_1 = v_cell_247;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1354328764x1362350361_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1354328764x1362350361_24dps(a[0], a[1]);
}
Clo g_list_2emerge_24s1840066165x1513718921_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1840066165x1513718921_24dps_entry, 3, 0};

V g_list_2emerge_24s1840066165x1513718921_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_xs_240, 0));
    V v_xs2_244 = heff_dup(heff_field(v_xs_240, 1));
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 10);
      heff_drop(v_xs2_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      heff_drop_tag(v_xs_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_y_245, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs2_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys2_246});
        V t_2 = v_cell_248;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs2_244});
        V t_1 = v_ys2_246;
        V t_2 = v_cell_2410;
        v_xs_240 = t_0;
        v_ys_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2emerge_24s1840066165x1513718921_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1840066165x1513718921_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s570961906x1112476114_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_24dps_entry, 2, 0};

V g_list_2emap_24s570961906x1112476114_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2elabelOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str9, 0, "");
Clo g_list_2emap_24s218655275x981659442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_24dps_entry, 2, 0};

V g_list_2emap_24s218655275x981659442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_242)) {
    case TAG_VFun: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2411 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2415 = v_s_2411;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str8);
      break;
    }
    case TAG_VErased: {
      v_t_2415 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str9);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2416));
    heff_drop(v_u_2417);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2416;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1064353769x1815078842_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1064353769x1815078842_entry, 1, 0};

V g_list_2efilter_24s1064353769x1815078842(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 1));
    switch (heff_tag_of(v_t_243)) {
    case TAG_SError: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s1064353769x1815078842_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_SWarning: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_SDebug: {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1064353769x1815078842(a[0]);
}
Clo g_list_2emap_24s1534624020x121531103_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1534624020x121531103_24dps_entry, 11, 0};

V g_list_2emap_24s1534624020x121531103_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_lit_248, V v_x2_249, V v_d_2410) {
top: ;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    heff_drop(v_lit_248);
    return heff_setField(v_d_2410, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_249, 0);
    V v_xs_2412 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24Cons = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_t_2413 = heff_take_field(v_x_2411, 1);
    V v_t_2414;
    switch (heff_tag_of(v_t_2413)) {
    case TAG_AssocLeft: {
      v_t_2414 = heff_dup(v_lit_241);
      break;
    }
    case TAG_AssocRight: {
      v_t_2414 = heff_dup(v_lit_242);
      break;
    }
    case TAG_AssocNone: {
      v_t_2414 = heff_dup(v_lit_243);
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    V v_t_2415 = heff_take_field(v_x_2411, 3);
    V v_t_2416;
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      v_t_2416 = heff_dup(v_lit_244);
    } else {
      heff_drop(v_t_2415);
      v_t_2416 = heff_dup(v_lit_245);
    }
    V v_t_2417 = heff_take_field(v_x_2411, 2);
    V v_t_2420;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_Nil: {
      v_t_2420 = heff_dup(v_lit_247);
      break;
    }
    case TAG_Cons: {
      V v_a_2418 = heff_field(v_t_2417, 0);
      V v_a_2419 = heff_field(v_t_2417, 1);
      heff_take_n(v_t_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = heff_dup(v_lit_248); V a_1 = v_a_2418; V a_2 = v_a_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2419); r_; });
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    V v_t_2421 = heff_strAppend(v_t_2416, heff_strAppend(heff_dup(v_lit_246), v_t_2420));
    V v_t_2422 = heff_strAppend(heff_intShow(v_t_2414), v_t_2421);
    V v_t_2423 = heff_strAppend(heff_get_n(v_x_2411, 0, 5), heff_strAppend(heff_dup(v_lit_240), v_t_2422));
    V v_cell_2424 = heff_tag_at_n(v_ru_24x2_249_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_2410, MK_INT(1LL), heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_lit_246;
    V t_7 = v_lit_247;
    V t_8 = v_lit_248;
    V t_9 = v_xs_2412;
    V t_10 = v_cell_2424;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_lit_246 = t_6;
    v_lit_247 = t_7;
    v_lit_248 = t_8;
    v_x2_249 = t_9;
    v_d_2410 = t_10;
    goto top;
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_list_2emap_24s1534624020x121531103_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1534624020x121531103_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
Clo g_list_2emap_24s952531872x538225679_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s952531872x538225679_entry, 2, 0};

V g_list_2emap_24s952531872x538225679(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_strAppend(heff_dup(v_lit_240), heff_take_field(v_x_242, 1));
    V v_t_245 = heff_strAppend(heff_get_n(v_x_242, 0, 2), v_t_244);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = (g_list_2emap_24s952531872x538225679_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s952531872x538225679_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s952531872x538225679(a[0], a[1]);
}
Clo g_list_2efoldl_24s775969440x1318400394_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s775969440x1318400394_entry, 3, 0};

V g_list_2efoldl_24s775969440x1318400394(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_intShow(heff_strLength(heff_dup(v_x_243)));
    V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(heff_dup(v_lit_240), v_x_243));
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_prelude_2e_2b_2b(v_t_247, v_z_241));
    V t_0 = v_lit_240;
    V t_1 = v_t_248;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s775969440x1318400394_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s775969440x1318400394(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s1221903513x233153387_str0, 1, "\012");
HEFF_LIT(g_list_2emap_24s1221903513x233153387_str1, 0, "");
HEFF_LIT(g_list_2emap_24s1221903513x233153387_str2, 0, "");
Clo g_list_2emap_24s1221903513x233153387_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1221903513x233153387_entry, 1, 0};

V g_list_2emap_24s1221903513x233153387(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x2_243 = (g_prelude_2esplitFrom(((V)&g_list_2emap_24s1221903513x233153387_str0), heff_get_n(v_x_241, 0, 2), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_s_246;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      v_s_246 = ((V)&g_list_2emap_24s1221903513x233153387_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x2_243, 0);
      V v_xs_245 = heff_field(v_x2_243, 1);
      heff_take_n(v_x2_243, 3ULL, 2);
      v_s_246 = ({ V a_0 = heff_dup(g_heff_2esyntax_2efmt_2elayout_2enewlineMark_get()); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    V v_t_248;
    if (heff_strEq_c(heff_dup(v_s_246), ((V)&g_list_2emap_24s1221903513x233153387_str2))) {
      heff_drop(v_s_246);
      v_t_248 = NTAG(TAG_None);
    } else {
      v_t_248 = heff_tag_n(TAG_Text, 1, (V[]){v_s_246});
    }
    V v_t_249 = (g_std_2edoc_2e_3c_3e(heff_dup(g_std_2edoc_2ehardline_get()), v_t_248));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = (g_list_2emap_24s1221903513x233153387_24dps(v_xs_242, heff_dup(v_cell_2410)));
    heff_drop(v_u_2411);
    return v_cell_2410;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1221903513x233153387_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1221903513x233153387(a[0]);
}
Clo g_list_2emap_24s725725455x1186198702_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s725725455x1186198702_24dps_entry, 2, 0};

V g_list_2emap_24s725725455x1186198702_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2esyntax_2efmt_2elayout_2ertrimEnd(heff_dup(v_x_242), heff_strLength(heff_dup(v_x_242))));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_strSlice(v_x_242, MK_INT(0LL), v_t_244), heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s725725455x1186198702_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s725725455x1186198702_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1195846327x230486685_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1195846327x230486685_24dps_entry, 8, 0};

V g_list_2emap_24s1195846327x230486685_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246, V v_d_247) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return heff_setField(v_d_247, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_246, 0);
    V v_xs_249 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_x_248)) {
    case TAG_MkFieldPat: {
      V v_a_2410 = heff_field(v_x_248, 0);
      V v_a_2411 = heff_field(v_x_248, 1);
      V v_ru_24x_248_24MkFieldPat = heff_take_reuse_n(v_x_248, 3ULL, 2);
      V v_t_2412 = (g_heff_2esyntax_2eformat_2epatKey(v_a_2411));
      V v_t_2413 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_a_2414 = heff_tag_at_n(v_ru_24x_248_24MkFieldPat, TAG_Cons, 2, (V[]){v_a_2410, v_t_2413});
      V v_a_2415 = (g_list_2emap_24s1367796012x2117543847(heff_dup(v_lit_242), v_a_2414));
      V v_t_2418;
      switch (heff_tag_of(v_a_2415)) {
      case TAG_Nil: {
        v_t_2418 = heff_dup(v_lit_243);
        break;
      }
      case TAG_Cons: {
        V v_a_2416 = heff_field(v_a_2415, 0);
        V v_a_2417 = heff_field(v_a_2415, 1);
        heff_take_n(v_a_2415, 3ULL, 2);
        v_t_2418 = ({ V a_0 = heff_dup(v_lit_244); V a_1 = v_a_2416; V a_2 = v_a_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_a_2417); r_; });
        break;
      }
      default: heff_nomatch(v_a_2415);
      }
      V v_t_2419 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2418, heff_dup(v_lit_245)));
      v_t_2420 = heff_strAppend(heff_dup(v_lit_240), v_t_2419);
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    V v_cell_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, heff_hole()});
    V v_u_2422 = heff_setField(v_d_247, MK_INT(1LL), heff_dup(v_cell_2421));
    heff_drop(v_u_2422);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_lit_243;
    V t_4 = v_lit_244;
    V t_5 = v_lit_245;
    V t_6 = v_xs_249;
    V t_7 = v_cell_2421;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_lit_243 = t_3;
    v_lit_244 = t_4;
    v_lit_245 = t_5;
    v_x2_246 = t_6;
    v_d_247 = t_7;
    goto top;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s1195846327x230486685_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1195846327x230486685_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_list_2ezipWith_24s1958630276x749154843_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_entry, 2, 0};

V g_list_2ezipWith_24s1958630276x749154843(V v_xs_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_xs_240, 0);
    V v_xs2_243 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs2_243);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_ys_241, 0);
      V v_ys2_245 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_246 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_244, 0, 2), v_x_242});
      V v_cell_247 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2ezipWith_24s1958630276x749154843_24dps(v_xs2_243, v_ys2_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1958630276x749154843_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1958630276x749154843_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1958630276x749154843_24dps(V v_xs_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_xs_240)) {
  case TAG_Nil: {
    heff_drop(v_ys_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_xs_240, 0);
    V v_xs2_244 = heff_field(v_xs_240, 1);
    V v_ru_24xs_240_24Cons = heff_take_reuse_n(v_xs_240, 3ULL, 2);
    switch (heff_tag_of(v_ys_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs2_244);
      heff_drop_cell(v_ru_24xs_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_ys_241, 0);
      V v_ys2_246 = heff_field(v_ys_241, 1);
      V v_ru_24ys_241_24Cons = heff_take_reuse_n(v_ys_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24xs_240_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_y_245, 0, 2), v_x_243});
      V v_cell_248 = heff_tag_at_n(v_ru_24ys_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs2_244;
      V t_1 = v_ys2_246;
      V t_2 = v_cell_248;
      v_xs_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_ys_241);
    }
  }
  default: return heff_nomatch(v_xs_240);
  }
}
V g_list_2ezipWith_24s1958630276x749154843_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1958630276x749154843_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_list_2emap_24s404123879x745642248_str0, 8, ", dir = ");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str1, 2, " }");
HEFF_LIT(g_list_2emap_24s404123879x745642248_str2, 9, "{ name = ");
Clo g_list_2emap_24s404123879x745642248_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s404123879x745642248_entry, 1, 0};

V g_list_2emap_24s404123879x745642248(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ebuild_2eproject_2equoted(heff_take_field(v_x_241, 0)));
    V v_t_244 = (g_heff_2ebuild_2eproject_2equoted(heff_get_n(v_x_241, 1, 2)));
    V v_t_245 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str0), heff_strAppend(v_t_244, ((V)&g_list_2emap_24s404123879x745642248_str1)));
    V v_t_246 = heff_strAppend(((V)&g_list_2emap_24s404123879x745642248_str2), heff_strAppend(v_t_243, v_t_245));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_list_2emap_24s404123879x745642248_24dps(v_xs_242, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s404123879x745642248_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s404123879x745642248(a[0]);
}
Clo g_list_2efilter_24s2018073091x1385246979_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2018073091x1385246979_entry, 1, 0};

V g_list_2efilter_24s2018073091x1385246979(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s2018073091x1385246979_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2018073091x1385246979(a[0]);
}
Clo g_list_2emap_24s173442543x1801751270_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_24dps_entry, 2, 0};

V g_list_2emap_24s173442543x1801751270_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x11_244, 0);
        V v_tsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 3);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_246, v_tsp_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2000102784x314586828_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_entry, 1, 0};

V g_list_2emap_24s2000102784x314586828(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s2000102784x314586828_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828(a[0]);
}
Clo g_list_2efoldl_24s1472875662x470242985_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1472875662x470242985_entry, 2, 0};

V g_list_2efoldl_24s1472875662x470242985(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ebuild_2equery_2edocMdStep(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1472875662x470242985(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1026998256x1634433314_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1026998256x1634433314_entry, 2, 0};

V g_list_2efoldl_24s1026998256x1634433314(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetPath: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1026998256x1634433314(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s302194196x751324068_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s302194196x751324068_entry, 2, 0};

V g_list_2efoldl_24s302194196x751324068(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_247 = heff_field(v_a_244, 1);
        v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_247));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s302194196x751324068(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1880530801x1683594418_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1880530801x1683594418_entry, 2, 0};

V g_list_2efilter_24s1880530801x1683594418(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_242, 1)), heff_dup(v_lit_240))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = (g_list_2efilter_24s1880530801x1683594418_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 5);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1880530801x1683594418_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1880530801x1683594418(a[0], a[1]);
}
Clo g_list_2emap_24s764064723x821001015_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s764064723x821001015_entry, 1, 0};

V g_list_2emap_24s764064723x821001015(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_x_241, 0)), heff_get_n(v_x_241, 1, 2)});
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s764064723x821001015_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s764064723x821001015_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s764064723x821001015(a[0]);
}
Clo g_list_2emap_24s764064723x821001015_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s764064723x821001015_24dps_entry, 2, 0};

V g_list_2emap_24s764064723x821001015_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_x_242, 0)), heff_get_n(v_x_242, 1, 2)});
    V v_cell_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s764064723x821001015_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s764064723x821001015_24dps(a[0], a[1]);
}
Clo g_list_2efilter_24s1490692278x809324339_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1490692278x809324339_24dps_entry, 2, 0};

V g_list_2efilter_24s1490692278x809324339_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = heff_dup(heff_rfield(v_x_242, 1));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_242, 10);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1490692278x809324339_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1490692278x809324339_24dps(a[0], a[1]);
}
Clo g_list_2efind_24s913819130x636901392_clo = {{0x80000000u, K_CLO, 0}, g_list_2efind_24s913819130x636901392_entry, 2, 0};

V g_list_2efind_24s913819130x636901392(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      v_t_246 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c(v_t_246, heff_dup(v_lit_240))) {
      heff_drop(v_lit_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efind_24s913819130x636901392_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efind_24s913819130x636901392(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24f482741271x1112521151_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f482741271x1112521151_24dps_entry, 6, 0};

V g_list_2emap_24f482741271x1112521151_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_p_243, V v_x2_244, V v_d_245) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_p_243);
    return heff_setField(v_d_245, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_244, 0);
    V v_xs_247 = heff_field(v_x2_244, 1);
    V v_ru_24x2_244_24Cons = heff_take_reuse_n(v_x2_244, 3ULL, 2);
    V v_t_248 = heff_tr(heff_call(heff_dup(v_p_243), 1, (V[]){heff_dup(v_x_246)}));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_take_field(v_x_246, 1), heff_dup(v_lit_242));
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_246, 2), heff_get_n(v_x_246, 3, 7)});
      V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_249), v_t_2410, NTAG(TAG_Nothing)});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_244_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_245, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    } else {
      heff_drop_rec(v_x_246, 7);
      heff_drop_cell(v_ru_24x2_244_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_p_243;
      V t_4 = v_xs_247;
      V t_5 = v_d_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_p_243 = t_3;
      v_x2_244 = t_4;
      v_d_245 = t_5;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2emap_24f482741271x1112521151_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f482741271x1112521151_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_list_2emap_24f1824207880x1057248167_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1824207880x1057248167_entry, 9, 0};

V g_list_2emap_24f1824207880x1057248167(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_lit_247, V v_x2_248) {
top: ;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    heff_drop(v_lit_246);
    heff_drop(v_lit_247);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24Cons = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_245), heff_dup(v_lit_246)), heff_dup(v_lit_247))) {
      heff_drop(v_x_249);
      heff_drop_cell(v_ru_24x2_248_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_lit_247;
      V t_8 = v_xs_2410;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_lit_247 = t_7;
      v_x2_248 = t_8;
      goto top;
    } else {
      V v_t_2414;
      if (heff_strEq_c(heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_240), heff_dup(v_lit_241)), heff_dup(v_lit_242))) {
        V v_t_2413 = heff_strSlice(heff_dup(v_x_249), heff_dup(v_lit_244), heff_strLength(v_x_249));
        v_t_2414 = heff_strAppend(heff_dup(v_lit_243), v_t_2413);
      } else {
        v_t_2414 = v_x_249;
      }
      V v_cell_2415 = heff_tag_at_n(v_ru_24x2_248_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
      V v_u_2416 = (g_list_2emap_24f1824207880x1057248167_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_lit_246, v_lit_247, v_xs_2410, heff_dup(v_cell_2415)));
      heff_drop(v_u_2416);
      return v_cell_2415;
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_list_2emap_24f1824207880x1057248167_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1824207880x1057248167(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
Clo g_list_2emap_24f1686943972x1657456902_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1686943972x1657456902_entry, 2, 0};

V g_list_2emap_24f1686943972x1657456902(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 2), heff_hole()});
      V v_u_246 = (g_list_2emap_24f1686943972x1657456902_24dps(v_p_240, v_xs_243, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    } else {
      heff_drop_rec(v_x_242, 2);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1686943972x1657456902_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1686943972x1657456902(a[0], a[1]);
}
Clo g_list_2efoldl_24f1715293669x1931437372_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1715293669x1931437372_entry, 4, 0};

V g_list_2efoldl_24f1715293669x1931437372(V v_z_240, V v_p_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLt_c(heff_dup(v_b_243), heff_dup(v_a_242))) {
    heff_drop(v_p_241);
    heff_drop(v_a_242);
    heff_drop(v_b_243);
    return v_z_240;
  } else {
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_a_242)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_242), v_z_240});
      V t_1 = v_p_241;
      V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
      V t_3 = v_b_243;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_a_242 = t_2;
      v_b_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = v_z_240;
      V t_1 = v_p_241;
      V t_2 = heff_intAdd(v_a_242, MK_INT(1LL));
      V t_3 = v_b_243;
      v_z_240 = t_0;
      v_p_241 = t_1;
      v_a_242 = t_2;
      v_b_243 = t_3;
      goto top;
    }
  }
}
V g_list_2efoldl_24f1715293669x1931437372_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1715293669x1931437372(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f1256088967x1733220017_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1256088967x1733220017_24dps_entry, 4, 0};

V g_list_2emap_24f1256088967x1733220017_24dps(V v_f_240, V v_p_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_p_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_244}));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_f_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_f_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_f_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_f_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f1256088967x1733220017_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1256088967x1733220017_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24f131620269x1652606631_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f131620269x1652606631_24dps_entry, 4, 0};

V g_list_2emap_24f131620269x1652606631_24dps(V v_lit_240, V v_p_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_244)}));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_244, 0, 8));
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_cell_248;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_245;
      V t_3 = v_d_243;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      v_d_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f131620269x1652606631_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f131620269x1652606631_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efoldl_24f1199449138x692104932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1199449138x692104932_entry, 3, 0};

V g_list_2efoldl_24f1199449138x692104932(V v_lit_240, V v_z_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 2)), 6, 10);
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2efoldl_24f1199449138x692104932_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24f1199449138x692104932(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24f1717515461x1947736435_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1717515461x1947736435_entry, 4, 0};

V g_list_2efoldl_24f1717515461x1947736435(V v_lit_240, V v_z_241, V v_seen_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_seen_242);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_rest_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_dup(v_x_244), v_seen_242));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_lit_240;
      V t_1 = v_z_241;
      V t_2 = v_seen_242;
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    } else {
      heff_drop(v_t_246);
      V t_0 = heff_dup(v_lit_240);
      V t_1 = heff_intAdd(v_z_241, v_lit_240);
      V t_2 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, v_seen_242});
      V t_3 = v_rest_245;
      v_lit_240 = t_0;
      v_z_241 = t_1;
      v_seen_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efoldl_24f1717515461x1947736435_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f1717515461x1947736435(a[0], a[1], a[2], a[3]);
}