// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadVariant 54613
#define TAG_Boxed 28180
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_HS 9084
#define TAG_IBind 27068
#define TAG_IVal 40987
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_OSimple 59809
#define TAG_Often 32846
#define TAG_RepV 61860
#define TAG_SDecl 12991
#define TAG_TagVariant 25174
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define TAG_Wants 58903
#define LBL_back 9511342
#define LBL_binder 558177493
#define LBL_body 9524841
#define LBL_by 9918
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_forwards 1228451848
#define LBL_front 299063875
#define LBL_given 299725719
#define LBL_groups 709681407
#define LBL_hash 9690581
#define LBL_key 315609
#define LBL_name 9869138
#define LBL_numeric 378927440
#define LBL_params 951713969
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_use 325633
#define LBL_version 583465758
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_front__back[] = {LBL_front, LBL_back};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_params__numeric__forwards[] = {LBL_params, LBL_numeric, LBL_forwards};
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
V g_heff_2ebuild_2etesting_2eplaceBefore(V, V);
V g_heff_2ebuild_2etesting_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2etesting_2eplaceBefore_clo;
V g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012(V, V);
V g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2ebuildsHere(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsHere_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsHere_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eemitc_2eunboxedCTypes_get(void);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
HeffT2 g_heff_2ecompile_2eranges_2eplaceOf_24cpr(V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erefcount_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erefcount_2efreeGo_clo;
HeffT2 g_heff_2ecompile_2erefcount_2efvW_24cpr(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2ecompile_2erepr_2eloops(V);
V g_heff_2ecompile_2erepr_2eloops_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2eloops_clo;
V g_heff_2ecompile_2esimplify_2epushable(V);
V g_heff_2ecompile_2esimplify_2epushable_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2epushable_clo;
V g_heff_2eelab_2eprint_2eescFrom(V, V);
V g_heff_2eelab_2eprint_2eescFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eescFrom_clo;
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(V);
V g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(V, V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2_clo;
V g_list_2eany_24s107933070x152985962(V, V, V, V, V);
V g_list_2eany_24s107933070x152985962_entry(V self, V *a);
extern Clo g_list_2eany_24s107933070x152985962_clo;
V g_list_2eany_24s241416889x826324235(V, V, V);
V g_list_2eany_24s241416889x826324235_entry(V self, V *a);
extern Clo g_list_2eany_24s241416889x826324235_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
V g_list_2eany_24s52266323x652150664(V);
V g_list_2eany_24s52266323x652150664_entry(V self, V *a);
extern Clo g_list_2eany_24s52266323x652150664_clo;
V g_list_2eany_24s688114072x773797180(V, V);
V g_list_2eany_24s688114072x773797180_entry(V self, V *a);
extern Clo g_list_2eany_24s688114072x773797180_clo;
V g_list_2eascending_24s132974174x1969749601(V, V, V);
V g_list_2eascending_24s132974174x1969749601_entry(V self, V *a);
extern Clo g_list_2eascending_24s132974174x1969749601_clo;
V g_list_2eascending_24s408704122x680527522(V, V, V);
V g_list_2eascending_24s408704122x680527522_entry(V self, V *a);
extern Clo g_list_2eascending_24s408704122x680527522_clo;
V g_list_2ecollapse_24s1001369766x1542204099(V, V);
V g_list_2ecollapse_24s1001369766x1542204099_entry(V self, V *a);
extern Clo g_list_2ecollapse_24s1001369766x1542204099_clo;
V g_list_2edescending_24s604988964x1962429671(V, V, V);
V g_list_2edescending_24s604988964x1962429671_entry(V self, V *a);
extern Clo g_list_2edescending_24s604988964x1962429671_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1050197499x1941129217(V, V);
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1050197499x1941129217_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1707192740x1747748619(V, V);
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1707192740x1747748619_clo;
V g_list_2efoldl_24s1817528582x392224400(V, V, V);
V g_list_2efoldl_24s1817528582x392224400_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1817528582x392224400_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s2062876492x2082655823_24scalars(V, V, V);
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo;
V g_list_2efoldl_24s2096737737x1558226812(V, V);
V g_list_2efoldl_24s2096737737x1558226812_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2096737737x1558226812_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24f1278780364x1365377410(V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_clo;
V g_list_2ekeepIf_24f1278780364x1365377410_24dps(V, V, V, V, V, V, V, V);
V g_list_2ekeepIf_24f1278780364x1365377410_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24f1278780364x1365377410_24dps_clo;
V g_list_2ekeepIf_24s1220809684x843195562(V, V);
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_clo;
V g_list_2ekeepIf_24s1220809684x843195562_24dps(V, V, V);
V g_list_2ekeepIf_24s1220809684x843195562_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1220809684x843195562_24dps_clo;
V g_list_2ekeepIf_24s1266148589x1647110933(V);
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_clo;
V g_list_2ekeepIf_24s1266148589x1647110933_24dps(V, V);
V g_list_2ekeepIf_24s1266148589x1647110933_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1266148589x1647110933_24dps_clo;
V g_list_2ekeepIf_24s183165982x1490920686_24dps(V, V);
V g_list_2ekeepIf_24s183165982x1490920686_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s183165982x1490920686_24dps_clo;
V g_list_2ekeepIf_24s403268044x1108109324_24dps(V, V, V);
V g_list_2ekeepIf_24s403268044x1108109324_24dps_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s403268044x1108109324_24dps_clo;
V g_list_2emap_24f1213328022x1811586494(V, V);
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_clo;
V g_list_2emap_24f1213328022x1811586494_24dps(V, V, V);
V g_list_2emap_24f1213328022x1811586494_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1213328022x1811586494_24dps_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1310249268x749995235_24dps(V, V, V, V);
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s191715292x1660526539(V, V, V, V, V, V, V);
V g_list_2emap_24s191715292x1660526539_entry(V self, V *a);
extern Clo g_list_2emap_24s191715292x1660526539_clo;
V g_list_2emap_24s191715292x1660526539_24dps(V, V, V, V, V, V, V, V);
V g_list_2emap_24s191715292x1660526539_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s191715292x1660526539_24dps_clo;
V g_list_2emap_24s2098427539x1767581560(V, V, V, V);
V g_list_2emap_24s2098427539x1767581560_entry(V self, V *a);
extern Clo g_list_2emap_24s2098427539x1767581560_clo;
V g_list_2emap_24s2098427539x1767581560_24dps(V, V, V, V, V);
V g_list_2emap_24s2098427539x1767581560_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2098427539x1767581560_24dps_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s418652630x628827683_24dps(V, V);
V g_list_2emap_24s418652630x628827683_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s418652630x628827683_24dps_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s549405518x243689326_24dps(V, V);
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_24dps_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s620499005x2067584111_24dps(V, V, V);
V g_list_2emap_24s620499005x2067584111_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_24dps_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24s675147852x248982264_24dps(V, V, V);
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_24dps_clo;
V g_list_2emap_24s94444922x1860431141(V);
V g_list_2emap_24s94444922x1860431141_entry(V self, V *a);
extern Clo g_list_2emap_24s94444922x1860431141_clo;
V g_list_2emap_24s94444922x1860431141_24dps(V, V);
V g_list_2emap_24s94444922x1860431141_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s94444922x1860431141_24dps_clo;
V g_list_2emergeRuns_24s1264244840x54231393(V, V);
V g_list_2emergeRuns_24s1264244840x54231393_entry(V self, V *a);
extern Clo g_list_2emergeRuns_24s1264244840x54231393_clo;
V g_list_2epushRun_24s794731864x1832547445(V, V, V);
V g_list_2epushRun_24s794731864x1832547445_entry(V self, V *a);
extern Clo g_list_2epushRun_24s794731864x1832547445_clo;
V g_list_2ezipWith_24s1928181476x241816070_24dps(V, V, V);
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo;
V g_list_2ezipWith_24s952564628x174753269(V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_clo;
V g_list_2ezipWith_24s952564628x174753269_24dps(V, V, V, V, V, V);
V g_list_2ezipWith_24s952564628x174753269_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s952564628x174753269_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);

HeffT2 g_list_2efind_24cpr(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_list_2efoldl_24s26403090x581733227_lam0(V self, V *args);
V g_list_2efoldl_24s26403090x581733227_lam1(V self, V *args);
V g_list_2efoldl_24s26403090x581733227_lam2(V self, V *args);
Clo g_list_2efoldl_24s26403090x581733227_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s26403090x581733227_entry, 4, 0};

V g_list_2efoldl_24s26403090x581733227(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_esc_246 = heff_dup(v_lit_240);
    V v_scans_247 = heff_dup(v_lit_241);
    V v_m_248 = v_z_242;
    V v_d_249 = v_x_244;
    V v_body_2410 = heff_take_field(v_d_249, 2);
    V v_key_2411 = heff_get_n(v_d_249, 0, 3);
    V v_t_2490;
    switch (heff_tag_of(v_body_2410)) {
    case TAG_EVar: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_ELam: {
      V v_xs_2414 = heff_field(v_body_2410, 0);
      heff_take_n(v_body_2410, 1ULL, 2);
      HeffT2 v_t_2416 = ({ V a_0 = v_esc_246; V a_1 = v_key_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_esc_246); r_; });
      {
        V v_field_2418 = v_t_2416.f[1];
        int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
        if ((v_tag_2417 == ((int64_t)0ULL))) {
          heff_drop(v_scans_247);
          heff_drop(v_key_2411);
          heff_drop(v_xs_2414);
          V v_x_2419 = v_field_2418;
          heff_drop(v_x_2419);
          v_t_2490 = v_m_248;
        } else {
          heff_drop(v_field_2418);
          V v_xs_2420 = v_xs_2414;
          HeffT2 v_t_2421 = ({ V a_0 = v_scans_247; V a_1 = v_key_2411; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_scans_247); r_; });
          V v_s_2425;
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_x_2424 = v_field_2423;
              v_s_2425 = v_x_2424;
            } else {
              heff_drop(v_field_2423);
              v_s_2425 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get());
            }
          }
          V v_numeric_2426 = heff_take_field(v_s_2425, 0);
          V v_given_2427 = heff_get_n(v_s_2425, 1, 5);
          V v_t_2433 = (g_list_2ekeepIf(heff_clo_n(g_list_2efoldl_24s26403090x581733227_lam0, 1, 1, (V[]){v_numeric_2426}), heff_dup(v_xs_2420)));
          V v_t_2441 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s26403090x581733227_lam1, 2, 1, (V[]){heff_dup(v_xs_2420)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2433; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2433); r_; });
          V v_t_2454 = ({ V a_0 = heff_clo_n(g_list_2efoldl_24s26403090x581733227_lam2, 2, 1, (V[]){heff_dup(v_xs_2420)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_given_2427; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_given_2427); r_; });
          v_t_2490 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_248, v_key_2411, heff_rec_n(3, shape_params__numeric__forwards, (V[]){v_xs_2420, v_t_2441, v_t_2454})));
        }
      }
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_body_2410, 0ULL, 3);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_body_2410, 0ULL, 4);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_body_2410, 0ULL, 3);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_body_2410, 0ULL, 3);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_body_2410, 0ULL, 1);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_body_2410, 0ULL, 2);
      heff_drop(v_esc_246);
      heff_drop(v_scans_247);
      heff_drop(v_key_2411);
      v_t_2490 = v_m_248;
      break;
    }
    default: heff_nomatch(v_body_2410);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2490;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s26403090x581733227(a[0], a[1], a[2], a[3]);
}
V g_list_2efoldl_24s26403090x581733227_lam0(V self, V *args) {
  V v_x_2428 = args[0];
  V v_numeric_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2429 = ({ V a_0 = v_numeric_2426; V a_1 = v_x_2428; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(a_0, a_1)); heff_drop(v_numeric_2426); heff_drop(v_x_2428); r_; });
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2430 == ((int64_t)0ULL)) && ({ V v_x_2432 = heff_dup(v_field_2431); int c_ = 1; heff_drop(v_x_2432); c_; })));
    heff_drop(v_field_2431);
    return v_ret_24bool;
  }
}
V g_list_2efoldl_24s26403090x581733227_lam1(V self, V *args) {
  V v_is_2434 = args[0];
  V v_x_2435 = args[1];
  V v_xs_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V a_0 = v_x_2435; V a_1 = MK_INT(0LL); V a_2 = v_xs_2420; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eplaceOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2435); heff_drop(v_xs_2420); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      V v_j_2439 = v_field_2438;
      V v_t_2440 = (g_list_2eany_24s688114072x773797180(heff_dup(v_j_2439), v_is_2434));
      if ((heff_dup(v_t_2440) == NTAG(TAG_True))) {
        heff_drop(v_j_2439);
        heff_drop(v_t_2440);
        return v_is_2434;
      } else {
        heff_drop(v_t_2440);
        return heff_tag_n(TAG_Cons, 2, (V[]){v_j_2439, v_is_2434});
      }
    } else {
      heff_drop(v_field_2438);
      return v_is_2434;
    }
  }
}
V g_list_2efoldl_24s26403090x581733227_lam2(V self, V *args) {
  V v_acc_2442 = args[0];
  V v_p_2443 = args[1];
  V v_xs_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446;
  switch (heff_tag_of(v_p_2443)) {
  case TAG_MkPair: {
    V v_y_2445 = heff_dup(heff_field(v_p_2443, 1));
    v_t_2446 = v_y_2445;
    break;
  }
  default: heff_nomatch(v_p_2443);
  }
  HeffT2 v_t_2447 = ({ V a_0 = v_t_2446; V a_1 = MK_INT(0LL); V a_2 = v_xs_2420; HeffT2 r_ = (g_heff_2ecompile_2eranges_2eplaceOf_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2446); heff_drop(v_xs_2420); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      V v_j_2450 = v_field_2449;
      V v_t_2453;
      switch (heff_tag_of(v_p_2443)) {
      case TAG_MkPair: {
        V v_x_2451 = heff_field(v_p_2443, 0);
        heff_take_n(v_p_2443, 1ULL, 2);
        v_t_2453 = v_x_2451;
        break;
      }
      default: heff_nomatch(v_p_2443);
      }
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2453, v_j_2450}), v_acc_2442});
    } else {
      heff_drop(v_p_2443);
      heff_drop(v_field_2449);
      return v_acc_2442;
    }
  }
}
Clo g_list_2emap_24s620499005x2067584111_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s620499005x2067584111_entry, 2, 0};

V g_list_2emap_24s620499005x2067584111(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s620499005x2067584111_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s620499005x2067584111(a[0], a[1]);
}
Clo g_list_2emap_24s1844509821x2028168277_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_entry, 1, 0};

V g_list_2emap_24s1844509821x2028168277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_241));
    V v_t_2415;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_246 = v_field_245;
        v_t_2415 = v_a_246;
      } else {
        if ((v_tag_244 == ((int64_t)1ULL))) {
          V v_a_247 = v_field_245;
          V v_t_2410;
          switch (heff_tag_of(v_a_247)) {
          case TAG_At: {
            V v_a_249 = heff_dup(heff_field(v_a_247, 1));
            v_t_2410 = v_a_249;
            break;
          }
          default: heff_nomatch(v_a_247);
          }
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_247}), v_t_2410});
        } else {
          V v_a_2411 = v_field_245;
          V v_t_2414;
          switch (heff_tag_of(v_a_2411)) {
          case TAG_At: {
            V v_a_2413 = heff_dup(heff_field(v_a_2411, 1));
            v_t_2414 = v_a_2413;
            break;
          }
          default: heff_nomatch(v_a_2411);
          }
          v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2411}), v_t_2414});
        }
      }
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s1844509821x2028168277_24dps(v_xs_242, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277(a[0]);
}
Clo g_list_2emap_24s513391942x823299088_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_entry, 1, 0};

V g_list_2emap_24s513391942x823299088(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_248 = (g_list_2emap_24s158244903x55062455(v_a_247));
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, v_t_248});
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          V v_ru_24a_249_24At = heff_take_reuse_n(v_a_249, 3ULL, 2);
          v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_24tok2(v_ru_24a_249_24At, v_a_2411, v_a_2410));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s513391942x823299088_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088(a[0]);
}
Clo g_list_2emap_24s549405518x243689326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s549405518x243689326_24dps_entry, 2, 0};

V g_list_2emap_24s549405518x243689326_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2445;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_EVar: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x12_245, 0ULL, 4);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_nf(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EBool: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_ESet: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EValues: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2445 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2446 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2445, heff_hole()});
    V v_u_2447 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2446));
    heff_drop(v_u_2447);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2446;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s549405518x243689326_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s418652630x628827683_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s418652630x628827683_24dps_entry, 2, 0};

V g_list_2emap_24s418652630x628827683_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2443;
    switch (heff_tag_of(v_x_242)) {
    case TAG_EVar: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x_242, 0ULL, 4);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x_242, 0ULL, 3);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2443 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2444 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2443, heff_hole()});
    V v_u_2445 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2444));
    heff_drop(v_u_2445);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2444;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s418652630x628827683_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s418652630x628827683_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1123370502x1982532655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_24dps_entry, 2, 0};

V g_list_2emap_24s1123370502x1982532655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655_24dps(a[0], a[1]);
}
Clo g_list_2ekeepIf_24s183165982x1490920686_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s183165982x1490920686_24dps_entry, 2, 0};

V g_list_2ekeepIf_24s183165982x1490920686_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2esimplify_2epushable(heff_dup(v_x_242)));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s183165982x1490920686_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s183165982x1490920686_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s94444922x1860431141_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s94444922x1860431141_entry, 1, 0};

V g_list_2emap_24s94444922x1860431141(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_SDecl, 1, (V[]){v_x_241}), heff_hole()});
    V v_u_244 = (g_list_2emap_24s94444922x1860431141_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s94444922x1860431141_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s94444922x1860431141(a[0]);
}
Clo g_list_2efoldl_24s788715611x32297348_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s788715611x32297348_entry, 2, 0};

V g_list_2efoldl_24s788715611x32297348(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_a_246, v_z_240));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s788715611x32297348(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1817528582x392224400_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1817528582x392224400_entry, 3, 0};

V g_list_2efoldl_24s1817528582x392224400(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_246;
    if ((heff_dup(v_lit_240) == NTAG(TAG_True))) {
      V v_t_245 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_RepV)});
      v_t_246 = heff_tag_n(TAG_Often, 1, (V[]){v_t_245});
    } else {
      v_t_246 = heff_tag_n(TAG_Wants, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_RepV)});
    }
    V v_t_247 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Boxed, 1, (V[]){v_x_243}), v_z_241});
    V t_0 = v_lit_240;
    V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_247});
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1817528582x392224400_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efoldl_24s1817528582x392224400(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s348204425x880103432_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s348204425x880103432_entry, 2, 0};

V g_list_2efoldl_24s348204425x880103432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_n(TAG_IBind, 2, (V[]){v_t_246, heff_tag_n(TAG_OSimple, 1, (V[]){v_t_249})});
    V t_0 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s348204425x880103432(a[0], a[1]);
}
Clo g_list_2eany_24s52266323x652150664_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s52266323x652150664_entry, 1, 0};

V g_list_2eany_24s52266323x652150664(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = (g_heff_2ecompile_2erepr_2eloops(v_a_245));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_246);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s52266323x652150664_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s52266323x652150664(a0); heff_drop(a0); return r;
}
Clo g_list_2emap_24s1310249268x749995235_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1310249268x749995235_24dps_entry, 4, 0};

V g_list_2emap_24s1310249268x749995235_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erepr_2edecidedIn(v_lit_240, v_lit_241, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s1310249268x749995235_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2eany_24s361779565x1527579812_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s361779565x1527579812_entry, 1, 0};

V g_list_2eany_24s361779565x1527579812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        V t_0 = v_xs_242;
        v_x2_240 = t_0;
        goto top;
      }
      case TAG_Cons: {
        V v_n_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        V v_t_249 = (g_heff_2ecompile_2eborrow_2ebuildsHere(heff_dup(v_n_248), v_b_245));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_n_248);
          heff_drop(v_t_249);
          return NTAG(TAG_True);
        } else {
          heff_drop(v_t_249);
          V v_t_2410 = (g_heff_2ecompile_2eir_2epartsOnto(heff_dup(v_b_245), NTAG(TAG_Nil)));
          V v_t_2411 = (g_heff_2ecompile_2eborrow_2eanyW_24s1601186482x1706087012(v_n_248, v_t_2410));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            return NTAG(TAG_True);
          } else {
            heff_drop(v_t_2411);
            V t_0 = v_xs_242;
            v_x2_240 = t_0;
            goto top;
          }
        }
      }
      default: return heff_nomatch(v_vs_244);
      }
    }
    default: return heff_nomatch(v_x_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s361779565x1527579812(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1416922510x485352908_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1416922510x485352908_entry, 2, 0};

V g_list_2efoldl_24s1416922510x485352908(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1416922510x485352908(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s1050197499x1941129217_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1050197499x1941129217_entry, 2, 0};

V g_list_2efoldl_24s1050197499x1941129217(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_244 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_IVal, 1, (V[]){v_x_242}), NTAG(TAG_Nil)});
    HeffT2 v_t_245 = (g_heff_2ecompile_2erefcount_2efvW_24cpr(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_244));
    V v_t_2412;
    {
      V v_field_246 = v_t_245.f[0];
      V v_field_247 = v_t_245.f[1];
      V v_a_248 = v_field_246;
      V v_a_249 = v_field_247;
      V v_a_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_a_249));
      V v_t_2411 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_a_248; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_a_248); r_; });
      v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_a_2410; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erefcount_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
    }
    V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_z_240));
    V t_0 = v_t_2413;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1050197499x1941129217_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1050197499x1941129217(a[0], a[1]);
}
Clo g_list_2emap_24s191715292x1660526539_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s191715292x1660526539_entry, 7, 0};

V g_list_2emap_24s191715292x1660526539(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_2415;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_247, 0);
      V v_a_2410 = heff_field(v_x_247, 1);
      heff_take_n(v_x_247, 3ULL, 2);
      V v_t_2411 = ({ V a_0 = v_a_249; V a_1 = heff_dup(v_lit_242); V r_ = (g_heff_2eelab_2eprint_2eescFrom(a_0, a_1)); heff_drop(v_a_249); r_; });
      V v_t_2412 = heff_strAppend(heff_strAppend(heff_dup(v_lit_241), v_t_2411), heff_dup(v_lit_243));
      V v_t_2413 = heff_strAppend(heff_strAppend(heff_dup(v_lit_240), v_t_2412), heff_dup(v_lit_244));
      V v_t_2414 = ({ V a_0 = v_a_2410; V r_ = (g_heff_2eelab_2eprint_2eshowTypeF_24s1530367201x192279500(a_0)); heff_drop(v_a_2410); r_; });
      v_t_2415 = heff_strAppend(heff_strAppend(v_t_2413, v_t_2414), heff_dup(v_lit_245));
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    V v_cell_2416 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_t_2415, heff_hole()});
    V v_u_2417 = (g_list_2emap_24s191715292x1660526539_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2416)));
    heff_drop(v_u_2417);
    return v_cell_2416;
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2emap_24s191715292x1660526539_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s191715292x1660526539(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_list_2efoldl_24s522807745x1556762248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s522807745x1556762248_entry, 2, 0};

V g_list_2efoldl_24s522807745x1556762248(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_a_247)));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s522807745x1556762248(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1928181476x241816070_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1928181476x241816070_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, heff_tag_n(TAG_EVar, 1, (V[]){v_y_245})});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1928181476x241816070_24dps(a[0], a[1], a[2]);
}
Clo g_list_2ekeepIf_24s403268044x1108109324_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s403268044x1108109324_24dps_entry, 3, 0};

V g_list_2ekeepIf_24s403268044x1108109324_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_243, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_t_2417;
    if (heff_strEq_c_lent(v_t_247, v_lit_240, 1)) {
      v_t_2417 = NTAG(TAG_True);
    } else {
      V v_t_2419;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_249 = heff_dup(heff_field(v_x_243, 1));
        v_t_2419 = v_a_249;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      v_t_2417 = heff_strEq_lent(v_t_2419, v_lit_240, 1);
    }
    V v_t_2413;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_False: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_2410;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s403268044x1108109324_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s403268044x1108109324_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1659194469x1936830512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1659194469x1936830512_entry, 2, 0};

V g_list_2efoldl_24s1659194469x1936830512(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_x_242));
    V v_t_2411;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      V v_ru_24a_244_24MkPair = heff_take_reuse_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        V v_ru_24z_240_24MkPair = heff_take_reuse_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2e_2b_2b_24tok2(v_ru_24a_244_24MkPair, v_a_245, v_a_247));
        V v_t_2410 = (g_prelude_2e_2b_2b_24tok2(v_ru_24z_240_24MkPair, v_a_246, v_a_248));
        v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, v_t_2410});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1659194469x1936830512(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str1, 10, "heff_drop(");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str2, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str3, 2, ");");
Clo g_list_2emap_24s577269653x49010166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_24dps_entry, 2, 0};

V g_list_2emap_24s577269653x49010166_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkDrop: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nothing: {
        V v_t_246 = ({ V a_0 = v_x_244; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s577269653x49010166_24dps_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
        V v_t_247 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str1), heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str2), v_t_246));
        v_t_249 = heff_strAppend(v_t_247, ((V)&g_list_2emap_24s577269653x49010166_24dps_str3));
        break;
      }
      case TAG_Just: {
        V v_k_248 = heff_field(v_x12_245, 0);
        heff_take_n(v_x12_245, 1ULL, 1);
        v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_244); heff_drop(v_k_248); r_; });
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s952564628x174753269_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s952564628x174753269_entry, 5, 0};

V g_list_2ezipWith_24s952564628x174753269(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_x3_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_x_245);
      heff_drop(v_xs_246);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_247 = heff_field(v_x3_244, 0);
      V v_ys_248 = heff_field(v_x3_244, 1);
      heff_take_n(v_x3_244, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_240), heff_intShow(v_y_247));
      V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, heff_dup(v_lit_241)), v_x_245);
      V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, heff_dup(v_lit_242)), heff_hole()});
      V v_u_2412 = (g_list_2ezipWith_24s952564628x174753269_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_246, v_ys_248, heff_dup(v_cell_2411)));
      heff_drop(v_u_2412);
      return v_cell_2411;
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2ezipWith_24s952564628x174753269_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s952564628x174753269(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s1882737314x358197882_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1882737314x358197882_entry, 4, 0};

V g_list_2efoldl_24s1882737314x358197882(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2enamesInGo(v_lit_240, heff_rfield(v_x_244, 1), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2efoldl_24s1882737314x358197882(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str0, 11, "static V g_");
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str1, 5, "_val;");
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str2, 11, "_init(void)");
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str3, 22, "static V heff_perform(");
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str4, 7, "static ");
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str5, 3, " g_");
HEFF_LIT(g_list_2emap_24s380834591x871125279_24dps_str6, 12, "static HeffT");
Clo g_list_2emap_24s380834591x871125279_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_24dps_entry, 2, 0};

V g_list_2emap_24s380834591x871125279_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_l_244 = v_x_242;
    V v_t_247;
    if ((heff_strEq_c(heff_strSlice_lent(v_l_244, MK_INT(0LL), MK_INT(11LL), 6), ((V)&g_list_2emap_24s380834591x871125279_24dps_str0)) && ({ int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_l_244, 0)) - ((int64_t)5ULL)); int c_ = ({ V v_t_2410 = heff_strSlice(heff_dup(v_l_244), heff_box_word(v_t_245), heff_strLength_lent(v_l_244, 0)); int c_ = (heff_strEq_c_lent(v_t_2410, ((V)&g_list_2emap_24s380834591x871125279_24dps_str1), 2) ? 0 : !heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_list_2emap_24s380834591x871125279_24dps_str2), v_l_244, MK_INT(0LL), 5))); heff_drop(v_t_2410); c_; }); c_; }))) {
      v_t_247 = heff_strSlice(heff_dup(v_l_244), MK_INT(7LL), heff_strLength(v_l_244));
    } else {
      if (heff_strEq_c(heff_strSlice_lent(v_l_244, MK_INT(0LL), MK_INT(22LL), 6), ((V)&g_list_2emap_24s380834591x871125279_24dps_str3))) {
        v_t_247 = heff_strSlice(heff_dup(v_l_244), MK_INT(7LL), heff_strLength(v_l_244));
      } else {
        V v_t_246 = ({ V a_0 = ((V)&g_list_2emap_24s380834591x871125279_24dps_str4); V a_1 = ((V)&g_list_2emap_24s380834591x871125279_24dps_str5); V a_2 = v_l_244; V b_3 = MK_INT(0LL); V b_4 = heff_dup(g_heff_2ecompile_2eemitc_2eunboxedCTypes_get()); V r_ = (g_list_2eany_24s107933070x152985962(a_0, a_1, a_2, b_3, b_4)); heff_drop(b_3); heff_drop(b_4); r_; });
        if (((heff_dup(v_t_246) == NTAG(TAG_True)) || heff_strEq_c(heff_strSlice_lent(v_l_244, MK_INT(0LL), MK_INT(12LL), 6), ((V)&g_list_2emap_24s380834591x871125279_24dps_str6)))) {
          heff_drop(v_t_246);
          v_t_247 = heff_strSlice(heff_dup(v_l_244), MK_INT(7LL), heff_strLength(v_l_244));
        } else {
          heff_drop(v_t_246);
          v_t_247 = v_l_244;
        }
      }
    }
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
    V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V t_0 = v_xs_243;
    V t_1 = v_cell_248;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1707192740x1747748619_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1707192740x1747748619_entry, 2, 0};

V g_list_2efoldl_24s1707192740x1747748619(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_list_2efoldl_24s2096737737x1558226812(v_z_240, heff_dup(heff_rfield(v_x_242, 0))));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1707192740x1747748619_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1707192740x1747748619(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str10, 0, "");
HEFF_LIT(g_list_2emap_24s570961906x1112476114_24dps_str11, 0, "");
Clo g_list_2emap_24s570961906x1112476114_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_24dps_entry, 2, 0};

V g_list_2emap_24s570961906x1112476114_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_v_244 = v_x_242;
    V v_t_2418;
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_248 = heff_dup(heff_field(v_v_244, 1));
      v_t_2418 = v_vs_248;
      break;
    }
    case TAG_VInt: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2418 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_244);
    }
    HeffT3 v_t_2419 = ({ V a_0 = MK_INT(0LL); V a_1 = v_t_2418; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2438;
    {
      V v_field_2421 = v_t_2419.f[1];
      V v_field_2422 = v_t_2419.f[2];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_x_2423 = v_field_2421;
        V v_x12_2424 = v_field_2422;
        heff_drop(v_x12_2424);
        switch (heff_tag_of(v_x_2423)) {
        case TAG_VFun: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str0);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str1);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2423, 0ULL, 2);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str2);
          break;
        }
        case TAG_VInt: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str3);
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str4);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str5);
          break;
        }
        case TAG_VStr: {
          V v_s_2432 = heff_field(v_x_2423, 0);
          heff_take_n(v_x_2423, 1ULL, 1);
          v_t_2438 = v_s_2432;
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str6);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str7);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2423, 0ULL, 1);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str8);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2423, 0ULL, 2);
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str9);
          break;
        }
        case TAG_VErased: {
          v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str10);
          break;
        }
        default: heff_nomatch(v_x_2423);
        }
      } else {
        heff_drop(v_field_2421);
        heff_drop(v_field_2422);
        v_t_2438 = ((V)&g_list_2emap_24s570961906x1112476114_24dps_str11);
      }
    }
    V v_t_2452;
    switch (heff_tag_of(v_v_244)) {
    case TAG_VFun: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VTag: {
      V v_vs_2442 = heff_field(v_v_244, 1);
      heff_take_n(v_v_244, 2ULL, 2);
      v_t_2452 = v_vs_2442;
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VStr: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_v_244, 0ULL, 1);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_v_244, 0ULL, 2);
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    case TAG_VErased: {
      v_t_2452 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_v_244);
    }
    HeffT3 v_t_2453 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2452; HeffT3 r_ = (g_list_2edrop_24cpr(a_0, a_1)); heff_drop(v_t_2452); r_; });
    V v_t_2472;
    {
      V v_field_2455 = v_t_2453.f[1];
      V v_field_2456 = v_t_2453.f[2];
      int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
      if ((v_tag_2454 == ((int64_t)0ULL))) {
        V v_x_2457 = v_field_2455;
        V v_x12_2458 = v_field_2456;
        heff_drop(v_x12_2458);
        switch (heff_tag_of(v_x_2457)) {
        case TAG_VFun: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VCons: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VTag: {
          heff_take_n(v_x_2457, 0ULL, 2);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VInt: {
          V v_i_2463 = heff_field(v_x_2457, 0);
          heff_take_n(v_x_2457, 1ULL, 1);
          v_t_2472 = v_i_2463;
          break;
        }
        case TAG_VFloat: {
          heff_take_na(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VFloat32: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VStr: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VRune: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VArr: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VBytes: {
          heff_take_n(v_x_2457, 0ULL, 1);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VBits: {
          heff_take_n(v_x_2457, 0ULL, 2);
          v_t_2472 = MK_INT(0LL);
          break;
        }
        case TAG_VErased: {
          v_t_2472 = MK_INT(0LL);
          break;
        }
        default: heff_nomatch(v_x_2457);
        }
      } else {
        heff_drop(v_field_2455);
        heff_drop(v_field_2456);
        v_t_2472 = MK_INT(0LL);
      }
    }
    V v_cell_2473 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2438, v_t_2472}), heff_hole()});
    V v_u_2474 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2473));
    heff_drop(v_u_2474);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2473;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str10, 0, "");
Clo g_list_2emap_24s218655275x981659442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_24dps_entry, 2, 0};

V g_list_2emap_24s218655275x981659442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_VFun: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2411 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2417 = v_s_2411;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str8);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str9);
      break;
    }
    case TAG_VErased: {
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str10);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2098427539x1767581560_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2098427539x1767581560_entry, 4, 0};

V g_list_2emap_24s2098427539x1767581560(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_path_246 = heff_take_field(v_x_244, 0);
    V v_version_247 = heff_take_field(v_x_244, 1);
    V v_hash_248 = heff_get_n(v_x_244, 2, 3);
    V v_t_249 = heff_strAppend(heff_strAppend(v_path_246, heff_dup(v_lit_240)), v_version_247);
    V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, heff_dup(v_lit_241)), v_hash_248);
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(v_t_2410, heff_dup(v_lit_242)), heff_hole()});
    V v_u_2412 = (g_list_2emap_24s2098427539x1767581560_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s2098427539x1767581560_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2098427539x1767581560(a[0], a[1], a[2], a[3]);
}
Clo g_list_2eascending_24s132974174x1969749601_clo = {{0x80000000u, K_CLO, 0}, g_list_2eascending_24s132974174x1969749601_entry, 3, 0};

V g_list_2eascending_24s132974174x1969749601(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  V v_path_243 = heff_take_field(v_x_240, 0);
  V v_version_244 = heff_get_n(v_x_240, 1, 3);
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_path_243);
    heff_drop(v_version_244);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_246 = heff_field(v_x4_242, 0);
    V v_ys_247 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    if (heff_strLt_c(heff_dup(v_path_243), heff_dup(heff_rfield(v_y_246, 0)))) {
      heff_drop(v_path_243);
      heff_drop(v_version_244);
      V t_0 = heff_dup(v_y_246);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_acc_241});
      V t_2 = v_ys_247;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    } else {
      if (heff_strEq_c(v_path_243, heff_dup(heff_rfield(v_y_246, 0)))) {
        V v_x1_248 = ({ V a_0 = v_version_244; V a_1 = heff_rfield(v_y_246, 1); V r_ = (g_heff_2ebuild_2eproject_2enewer(a_0, a_1)); heff_drop(v_version_244); r_; });
        if (!(heff_dup(v_x1_248) == NTAG(TAG_True))) {
          heff_drop(v_x1_248);
          V t_0 = heff_dup(v_y_246);
          V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_acc_241});
          V t_2 = v_ys_247;
          v_x_240 = t_0;
          v_acc_241 = t_1;
          v_x4_242 = t_2;
          goto top;
        } else {
          heff_drop(v_x1_248);
          V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_247})});
        }
      } else {
        heff_drop(v_version_244);
        V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_246, v_ys_247})});
      }
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2eascending_24s132974174x1969749601_entry(V self, V *a) {
  (void)self;
  return g_list_2eascending_24s132974174x1969749601(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s675147852x248982264_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s675147852x248982264_entry, 2, 0};

V g_list_2emap_24s675147852x248982264(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_path_244 = heff_take_field(v_x_242, 1);
    V v_version_245 = heff_get_n(v_x_242, 2, 3);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_by__path__version, (V[]){heff_dup(v_lit_240), v_path_244, v_version_245}), heff_hole()});
    V v_u_247 = (g_list_2emap_24s675147852x248982264_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s675147852x248982264_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s675147852x248982264(a[0], a[1]);
}
Clo g_list_2eany_24s241416889x826324235_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s241416889x826324235_entry, 3, 0};

V g_list_2eany_24s241416889x826324235(V v_lit_240, V v_lit_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_path_245 = heff_dup(heff_rfield(v_x_243, 0));
    V v_version_246 = heff_dup(heff_rfield(v_x_243, 1));
    if ((heff_strEq_c_lent(v_path_245, v_lit_240, 0) && heff_strEq_c_lent(v_version_246, v_lit_241, 0))) {
      heff_drop(v_path_245);
      heff_drop(v_version_246);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_path_245);
      heff_drop(v_version_246);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2eany_24s241416889x826324235_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2eany_24s241416889x826324235(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2ekeepIf_24s1220809684x843195562_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1220809684x843195562_entry, 2, 0};

V g_list_2ekeepIf_24s1220809684x843195562(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if (heff_strEq_c_lent(v_t_246, v_lit_240, 1)) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_248 = (g_list_2ekeepIf_24s1220809684x843195562_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ekeepIf_24s1220809684x843195562_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2ekeepIf_24s1220809684x843195562(a0, a[1]); heff_drop(a0); return r;
}
Clo g_list_2ekeepIf_24s1266148589x1647110933_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24s1266148589x1647110933_entry, 1, 0};

V g_list_2ekeepIf_24s1266148589x1647110933(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    if (!(heff_dup(heff_rfield(v_x_241, 2)) == NTAG(TAG_True))) {
      V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_244 = (g_list_2ekeepIf_24s1266148589x1647110933_24dps(v_xs_242, heff_dup(v_cell_243)));
      heff_drop(v_u_244);
      return v_cell_243;
    } else {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ekeepIf_24s1266148589x1647110933_entry(V self, V *a) {
  (void)self;
  return g_list_2ekeepIf_24s1266148589x1647110933(a[0]);
}
Clo g_list_2emap_24s173442543x1801751270_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_24dps_entry, 2, 0};

V g_list_2emap_24s173442543x1801751270_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x11_244, 0);
        V v_tsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 3);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_246, v_tsp_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270_24dps(a[0], a[1]);
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0(V self, V *args);
Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2062876492x2082655823_24scalars_entry, 3, 0};

V g_list_2efoldl_24s2062876492x2082655823_24scalars(V v_front_240, V v_back_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_front__back, (V[]){v_front_240, v_back_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V t_0 = v_front_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0, 1, 1, (V[]){v_x_243}), v_back_241});
    V t_2 = v_xs_244;
    v_front_240 = t_0;
    v_back_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2062876492x2082655823_24scalars(a[0], a[1], a[2]);
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_245);
  return v_x_243;
}
Clo g_list_2edescending_24s604988964x1962429671_clo = {{0x80000000u, K_CLO, 0}, g_list_2edescending_24s604988964x1962429671_entry, 3, 0};

V g_list_2edescending_24s604988964x1962429671(V v_x_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_x_240, 4);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x4_242, 0);
    V v_ys_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = heff_get_n(v_x_240, 1, 4); V a_1 = heff_rfield(v_y_243, 1); V r_ = (g_heff_2ebuild_2etesting_2eplaceBefore(b_0, a_1)); heff_drop(b_0); r_; });
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_acc_241, heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_ys_244})});
    } else {
      heff_drop(v_t_245);
      V t_0 = heff_dup(v_y_243);
      V t_1 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_y_243, v_acc_241});
      V t_2 = v_ys_244;
      v_x_240 = t_0;
      v_acc_241 = t_1;
      v_x4_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_list_2edescending_24s604988964x1962429671_entry(V self, V *a) {
  (void)self;
  return g_list_2edescending_24s604988964x1962429671(a[0], a[1], a[2]);
}
Clo g_list_2emergeRuns_24s1264244840x54231393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emergeRuns_24s1264244840x54231393_entry, 2, 0};

V g_list_2emergeRuns_24s1264244840x54231393(V v_stack_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_run_242 = heff_field(v_x3_241, 0);
    V v_x32_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24MkPair = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    switch (heff_tag_of(v_x32_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
      return ({ V a_0 = v_run_242; V a_1 = v_stack_240; V r_ = (g_list_2ecollapse_24s1001369766x1542204099(a_0, a_1)); heff_drop(v_stack_240); r_; });
    }
    case TAG_Cons: {
      V v_x_244 = heff_field(v_x32_243, 0);
      V v_xs_245 = heff_field(v_x32_243, 1);
      V v_ru_24x32_243_24Cons = heff_take_reuse_n(v_x32_243, 3ULL, 2);
      V v_t_246 = (g_list_2epushRun_24s794731864x1832547445(MK_INT(0LL), v_run_242, v_stack_240));
      V v_t_2413;
      switch (heff_tag_of(v_xs_245)) {
      case TAG_Nil: {
        V v_t_247 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
        v_t_2413 = heff_tag_at_n(v_ru_24x3_241_24MkPair, TAG_MkPair, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
        break;
      }
      case TAG_Cons: {
        V v_y_248 = heff_field(v_xs_245, 0);
        V v_ys_249 = heff_field(v_xs_245, 1);
        V v_ru_24xs_245_24Cons = heff_take_reuse_n(v_xs_245, 3ULL, 2);
        heff_drop_cell(v_ru_24x3_241_24MkPair, 2);
        V v_t_2410 = (g_heff_2ebuild_2etesting_2eplaceBefore(heff_rfield(v_x_244, 1), heff_rfield(v_y_248, 1)));
        if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
          heff_drop(v_t_2410);
          V v_t_2411 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2413 = (g_list_2eascending_24s408704122x680527522(heff_dup(v_y_248), heff_tag_at_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_t_2411}), v_ys_249));
        } else {
          heff_drop(v_t_2410);
          V v_t_2412 = heff_tag_at_n(v_ru_24x32_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, NTAG(TAG_Nil)});
          v_t_2413 = (g_list_2edescending_24s604988964x1962429671(heff_dup(v_y_248), heff_tag_at_n(v_ru_24xs_245_24Cons, TAG_Cons, 2, (V[]){v_y_248, v_t_2412}), v_ys_249));
        }
        break;
      }
      default: heff_nomatch(v_xs_245);
      }
      V t_0 = v_t_246;
      V t_1 = v_t_2413;
      v_stack_240 = t_0;
      v_x3_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x32_243);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2emergeRuns_24s1264244840x54231393_entry(V self, V *a) {
  (void)self;
  return g_list_2emergeRuns_24s1264244840x54231393(a[0], a[1]);
}
Clo g_list_2emap_24f1213328022x1811586494_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1213328022x1811586494_entry, 2, 0};

V g_list_2emap_24f1213328022x1811586494(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_binder_244 = heff_take_field(v_x_242, 0);
    V v_use_245 = heff_get_n(v_x_242, 1, 2);
    V v_a_246 = heff_get_n(v_binder_244, 1, 3);
    V v_start_247 = heff_take_field(v_a_246, 0);
    V v_end_248 = heff_get_n(v_a_246, 1, 2);
    V v_a_249 = heff_dup(heff_rfield(v_lit_240, 1));
    V v_start_2410 = heff_take_field(v_a_249, 0);
    V v_end_2411 = heff_get_n(v_a_249, 1, 2);
    if ((heff_intEq_c_lent(v_start_247, v_start_2410, 0) && heff_intEq_c_lent(v_end_248, v_end_2411, 0))) {
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_start_2410);
      heff_drop(v_end_2411);
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_use_245, heff_hole()});
      V v_u_2413 = (g_list_2emap_24f1213328022x1811586494_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    } else {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_use_245);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_start_2410);
      heff_drop(v_end_2411);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f1213328022x1811586494_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1213328022x1811586494(a[0], a[1]);
}
Clo g_list_2ekeepIf_24f1278780364x1365377410_clo = {{0x80000000u, K_CLO, 0}, g_list_2ekeepIf_24f1278780364x1365377410_entry, 7, 0};

V g_list_2ekeepIf_24f1278780364x1365377410(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_244);
    heff_drop(v_lit_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24Cons = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_t_249 = heff_strSlice(heff_dup(v_lit_242), heff_dup(v_lit_243), heff_intAdd(heff_dup(v_lit_244), heff_dup(v_lit_245)));
    V v_x_2410 = heff_strAppend(v_t_249, v_x_247);
    V v_t_2411 = heff_strSlice(heff_dup(v_x_2410), heff_dup(v_lit_240), heff_strLength_lent(v_lit_241, 0));
    if (heff_strEq_c_lent(v_t_2411, v_lit_241, 1)) {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_246_24Cons, TAG_Cons, 2, (V[]){v_x_2410, heff_hole()});
      V v_u_2413 = (g_list_2ekeepIf_24f1278780364x1365377410_24dps(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244, v_lit_245, v_xs_248, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    } else {
      heff_drop_cell(v_ru_24x2_246_24Cons, 2);
      heff_drop(v_x_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_xs_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_x2_246 = t_6;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2ekeepIf_24f1278780364x1365377410_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V r = g_list_2ekeepIf_24f1278780364x1365377410(a0, a1, a2, a3, a[4], a[5], a[6]); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); return r;
}