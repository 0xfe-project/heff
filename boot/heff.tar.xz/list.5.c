// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadVariant 54613
#define TAG_CInf 46723
#define TAG_CType 17595
#define TAG_DeclareField 57313
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_HS 9084
#define TAG_IBind 27068
#define TAG_KnownRec 32578
#define TAG_MkArm 55352
#define TAG_MkDrop 35958
#define TAG_OSimple 59809
#define TAG_PartOp 18051
#define TAG_PartVal 41444
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepInt 62369
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SError 24172
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TagVariant 25174
#define TAG_Unreached 46435
#define TAG_VArr 15466
#define TAG_VBits 41784
#define TAG_VBytes 2140
#define TAG_VCons 11629
#define TAG_VErased 42635
#define TAG_VFloat 27713
#define TAG_VFloat32 20700
#define TAG_VFun 20360
#define TAG_VInt 23032
#define TAG_VRune 5564
#define TAG_VStr 32826
#define TAG_VTag 33187
#define TAG_Within 10658
#define LBL_at 9882
#define LBL_back 9511342
#define LBL_by 9918
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_field 298786068
#define LBL_forwards 1228451848
#define LBL_from 9647217
#define LBL_front 299063875
#define LBL_implicit 319715269
#define LBL_integrations 139286697
#define LBL_key 315609
#define LBL_launch 837298910
#define LBL_library 398066429
#define LBL_long 9823043
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_path 9928940
#define LBL_pending 1696753626
#define LBL_renames 1324191545
#define LBL_severity 75955546
#define LBL_short 310771862
#define LBL_shown 310772011
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_version 583465758
static uint32_t shape_by__path__version[] = {LBL_by, LBL_path, LBL_version};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_front__back[] = {LBL_front, LBL_back};
static uint32_t shape_module__path__shown__source__renames__implicit__library[] = {LBL_module, LBL_path, LBL_shown, LBL_source, LBL_renames, LBL_implicit, LBL_library};
static uint32_t shape_name__span[] = {LBL_name, LBL_span};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eaddJs(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo;
V g_heff_2ebuild_2edriver_2ehint(V);
V g_heff_2ebuild_2edriver_2ehint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ehint_clo;
V g_heff_2ebuild_2edriver_2elabelOfV(V);
V g_heff_2ebuild_2edriver_2elabelOfV_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elabelOfV_clo;
V g_heff_2ecompile_2eborrow_2eborDef(V, V);
V g_heff_2ecompile_2eborrow_2eborDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eborDef_clo;
V g_heff_2ecompile_2eborrow_2ebuildsSize(V, V);
V g_heff_2ecompile_2eborrow_2ebuildsSize_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2ebuildsSize_clo;
V g_heff_2ecompile_2eemitc_2edropAs(V, V);
V g_heff_2ecompile_2eemitc_2edropAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2edropAs_clo;
V g_heff_2ecompile_2eemitc_2eelemS(V, V);
V g_heff_2ecompile_2eemitc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eelemS_clo;
V g_heff_2ecompile_2eemitc_2eknownTags_get(void);
V g_heff_2ecompile_2eemitc_2emangleW(V, V, V, V);
V g_heff_2ecompile_2eemitc_2emangleW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2emangleW_clo;
V g_heff_2ecompile_2eemitc_2enamesInGo(V, V, V, V);
V g_heff_2ecompile_2eemitc_2enamesInGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2enamesInGo_clo;
V g_heff_2ecompile_2eemitc_2epubLine(V);
V g_heff_2ecompile_2eemitc_2epubLine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2epubLine_clo;
V g_heff_2ecompile_2eemitc_2etagsLbls(V);
V g_heff_2ecompile_2eemitc_2etagsLbls_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2etagsLbls_clo;
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(V, V);
V g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937_clo;
V g_heff_2ecompile_2eprims_2efixedImpl(V);
V g_heff_2ecompile_2eprims_2efixedImpl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eprims_2efixedImpl_clo;
V g_heff_2ecompile_2eranges_2efnOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2efnOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2efnOne_clo;
V g_heff_2ecompile_2eranges_2erangeEq(V, V);
V g_heff_2ecompile_2eranges_2erangeEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangeEq_clo;
V g_heff_2ecompile_2erepr_2edecidedIn(V, V, V);
V g_heff_2ecompile_2erepr_2edecidedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2edecidedIn_clo;
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2esyntax_2efixity_2ereserved_get(void);
HeffT2 g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf(V, V);
V g_heff_2esyntax_2epresyntax_2efieldDeclOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldDeclOf_clo;
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(V);
V g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1673346944x1460195389(V, V, V, V, V, V, V, V);
V g_list_2eany_24s1673346944x1460195389_entry(V self, V *a);
extern Clo g_list_2eany_24s1673346944x1460195389_clo;
V g_list_2eany_24s1817246263x1083513945(V, V);
V g_list_2eany_24s1817246263x1083513945_entry(V self, V *a);
extern Clo g_list_2eany_24s1817246263x1083513945_clo;
V g_list_2eany_24s361779565x1527579812(V);
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a);
extern Clo g_list_2eany_24s361779565x1527579812_clo;
V g_list_2eany_24s811553642x27402676(V, V, V, V, V, V, V);
V g_list_2eany_24s811553642x27402676_entry(V self, V *a);
extern Clo g_list_2eany_24s811553642x27402676_clo;
V g_list_2efilter_24f75237897x367824150_24dps(V, V, V);
V g_list_2efilter_24f75237897x367824150_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24f75237897x367824150_24dps_clo;
V g_list_2efilter_24s1018181017x1541469354_24dps(V, V);
V g_list_2efilter_24s1018181017x1541469354_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1018181017x1541469354_24dps_clo;
V g_list_2efilter_24s1535080205x545126304_24dps(V, V, V, V, V);
V g_list_2efilter_24s1535080205x545126304_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1535080205x545126304_24dps_clo;
V g_list_2efilter_24s1623010005x1805617852(V);
V g_list_2efilter_24s1623010005x1805617852_entry(V self, V *a);
extern Clo g_list_2efilter_24s1623010005x1805617852_clo;
V g_list_2efilter_24s1646962431x688731818_24dps(V, V, V);
V g_list_2efilter_24s1646962431x688731818_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1646962431x688731818_24dps_clo;
V g_list_2efilter_24s1791954930x928584331_24dps(V, V);
V g_list_2efilter_24s1791954930x928584331_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1791954930x928584331_24dps_clo;
V g_list_2efilter_24s1820448628x561773228(V, V, V, V);
V g_list_2efilter_24s1820448628x561773228_entry(V self, V *a);
extern Clo g_list_2efilter_24s1820448628x561773228_clo;
V g_list_2efilter_24s1820448628x561773228_24dps(V, V, V, V, V);
V g_list_2efilter_24s1820448628x561773228_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1820448628x561773228_24dps_clo;
V g_list_2efilter_24s1826815879x1318332352_24dps(V, V);
V g_list_2efilter_24s1826815879x1318332352_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1826815879x1318332352_24dps_clo;
V g_list_2efilter_24s1836620197x1700774439(V);
V g_list_2efilter_24s1836620197x1700774439_entry(V self, V *a);
extern Clo g_list_2efilter_24s1836620197x1700774439_clo;
V g_list_2efilter_24s1836620197x1700774439_24dps(V, V);
V g_list_2efilter_24s1836620197x1700774439_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s1836620197x1700774439_24dps_clo;
V g_list_2efilter_24s2018073091x1385246979(V);
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_clo;
V g_list_2efilter_24s2018073091x1385246979_24dps(V, V);
V g_list_2efilter_24s2018073091x1385246979_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2018073091x1385246979_24dps_clo;
V g_list_2efilter_24s2101000672x961294372_24dps(V, V, V, V, V);
V g_list_2efilter_24s2101000672x961294372_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s2101000672x961294372_24dps_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efilter_24s727803713x1346936525_24dps(V, V, V);
V g_list_2efilter_24s727803713x1346936525_24dps_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_24dps_clo;
HeffT2 g_list_2efind_24cpr(V, V);
V g_list_2efoldl_24f1841208961x1043590714(V, V, V, V, V);
V g_list_2efoldl_24f1841208961x1043590714_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1841208961x1043590714_clo;
V g_list_2efoldl_24f700195413x1431112932(V, V, V);
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a);
extern Clo g_list_2efoldl_24f700195413x1431112932_clo;
V g_list_2efoldl_24s1111748987x306062113(V, V, V);
V g_list_2efoldl_24s1111748987x306062113_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1111748987x306062113_clo;
V g_list_2efoldl_24s1416922510x485352908(V, V);
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1416922510x485352908_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s1659194469x1936830512(V, V);
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1659194469x1936830512_clo;
V g_list_2efoldl_24s1794308634x1384130934(V, V, V, V, V);
V g_list_2efoldl_24s1794308634x1384130934_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1794308634x1384130934_clo;
V g_list_2efoldl_24s1882737314x358197882(V, V, V, V);
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1882737314x358197882_clo;
V g_list_2efoldl_24s192900907x155689445(V, V, V);
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a);
extern Clo g_list_2efoldl_24s192900907x155689445_clo;
V g_list_2efoldl_24s2062876492x2082655823_24scalars(V, V, V);
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo;
V g_list_2efoldl_24s2082573419x947677806(V, V);
V g_list_2efoldl_24s2082573419x947677806_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2082573419x947677806_clo;
V g_list_2efoldl_24s26403090x581733227(V, V, V, V);
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a);
extern Clo g_list_2efoldl_24s26403090x581733227_clo;
V g_list_2efoldl_24s348204425x880103432(V, V);
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s348204425x880103432_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s477184376x1963488659(V, V);
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a);
extern Clo g_list_2efoldl_24s477184376x1963488659_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788715611x32297348(V, V);
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788715611x32297348_clo;
V g_list_2efoldl_24s842401018x360740028(V, V);
V g_list_2efoldl_24s842401018x360740028_entry(V self, V *a);
extern Clo g_list_2efoldl_24s842401018x360740028_clo;
V g_list_2efoldl_24s976906006x1321876394(V, V, V, V);
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a);
extern Clo g_list_2efoldl_24s976906006x1321876394_clo;
V g_list_2emap_24f134831722x1788320834(V, V, V);
V g_list_2emap_24f134831722x1788320834_entry(V self, V *a);
extern Clo g_list_2emap_24f134831722x1788320834_clo;
V g_list_2emap_24f134831722x1788320834_24dps(V, V, V, V);
V g_list_2emap_24f134831722x1788320834_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f134831722x1788320834_24dps_clo;
V g_list_2emap_24f1502491305x440718220_24dps(V, V, V);
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1502491305x440718220_24dps_clo;
V g_list_2emap_24f1799988110x1394031252_24dps(V, V, V, V, V);
V g_list_2emap_24f1799988110x1394031252_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f1799988110x1394031252_24dps_clo;
V g_list_2emap_24f966602123x1640556393(V, V);
V g_list_2emap_24f966602123x1640556393_entry(V self, V *a);
extern Clo g_list_2emap_24f966602123x1640556393_clo;
V g_list_2emap_24f966602123x1640556393_24dps(V, V, V);
V g_list_2emap_24f966602123x1640556393_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24f966602123x1640556393_24dps_clo;
V g_list_2emap_24s1123370502x1982532655_24dps(V, V);
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1123370502x1982532655_24dps_clo;
V g_list_2emap_24s1310249268x749995235_24dps(V, V, V, V);
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1310249268x749995235_24dps_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
V g_list_2emap_24s1367173129x1257089258_24dps(V, V);
V g_list_2emap_24s1367173129x1257089258_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_24dps_clo;
V g_list_2emap_24s1382928954x1260344933_24dps(V, V, V, V);
V g_list_2emap_24s1382928954x1260344933_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1382928954x1260344933_24dps_clo;
V g_list_2emap_24s1543151117x629172256(V);
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_clo;
V g_list_2emap_24s1543151117x629172256_24dps(V, V);
V g_list_2emap_24s1543151117x629172256_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1543151117x629172256_24dps_clo;
V g_list_2emap_24s158244903x55062455(V);
V g_list_2emap_24s158244903x55062455_entry(V self, V *a);
extern Clo g_list_2emap_24s158244903x55062455_clo;
V g_list_2emap_24s173442543x1801751270_24dps(V, V);
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_24dps_clo;
V g_list_2emap_24s1844509821x2028168277(V);
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_clo;
V g_list_2emap_24s1844509821x2028168277_24dps(V, V);
V g_list_2emap_24s1844509821x2028168277_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1844509821x2028168277_24dps_clo;
V g_list_2emap_24s1951926392x340347826_24dps(V, V, V, V);
V g_list_2emap_24s1951926392x340347826_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s1951926392x340347826_24dps_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s2000102784x314586828_24dps(V, V);
V g_list_2emap_24s2000102784x314586828_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_24dps_clo;
V g_list_2emap_24s2016093283x1174801437_24dps(V, V, V);
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2016093283x1174801437_24dps_clo;
V g_list_2emap_24s2029035892x1571084362_24dps(V, V);
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s2029035892x1571084362_24dps_clo;
V g_list_2emap_24s218655275x981659442_24dps(V, V);
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s218655275x981659442_24dps_clo;
V g_list_2emap_24s231073986x752637537_24dps(V, V, V);
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_24dps_clo;
V g_list_2emap_24s380834591x871125279_24dps(V, V);
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s380834591x871125279_24dps_clo;
V g_list_2emap_24s513391942x823299088(V);
V g_list_2emap_24s513391942x823299088_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_clo;
V g_list_2emap_24s513391942x823299088_24dps(V, V);
V g_list_2emap_24s513391942x823299088_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s513391942x823299088_24dps_clo;
V g_list_2emap_24s549405518x243689326_24dps(V, V);
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s549405518x243689326_24dps_clo;
V g_list_2emap_24s570961906x1112476114_24dps(V, V);
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s570961906x1112476114_24dps_clo;
V g_list_2emap_24s577269653x49010166_24dps(V, V);
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s577269653x49010166_24dps_clo;
V g_list_2emap_24s588563787x236154271(V, V, V, V);
V g_list_2emap_24s588563787x236154271_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_clo;
V g_list_2emap_24s588563787x236154271_24dps(V, V, V, V, V);
V g_list_2emap_24s588563787x236154271_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s588563787x236154271_24dps_clo;
V g_list_2emap_24s620499005x2067584111(V, V);
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_clo;
V g_list_2emap_24s620499005x2067584111_24dps(V, V, V);
V g_list_2emap_24s620499005x2067584111_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s620499005x2067584111_24dps_clo;
V g_list_2emap_24s675147852x248982264(V, V);
V g_list_2emap_24s675147852x248982264_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_clo;
V g_list_2emap_24s675147852x248982264_24dps(V, V, V);
V g_list_2emap_24s675147852x248982264_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s675147852x248982264_24dps_clo;
V g_list_2emap_24s764064723x821001015(V);
V g_list_2emap_24s764064723x821001015_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_clo;
V g_list_2emap_24s764064723x821001015_24dps(V, V);
V g_list_2emap_24s764064723x821001015_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_24dps_clo;
V g_list_2emap_24s864521685x1610969087(V);
V g_list_2emap_24s864521685x1610969087_entry(V self, V *a);
extern Clo g_list_2emap_24s864521685x1610969087_clo;
V g_list_2emap_24s961097229x1129443801(V);
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_clo;
V g_list_2emap_24s961097229x1129443801_24dps(V, V);
V g_list_2emap_24s961097229x1129443801_24dps_entry(V self, V *a);
extern Clo g_list_2emap_24s961097229x1129443801_24dps_clo;
V g_list_2emerge_24s1840066165x1513718921_24dps(V, V, V);
V g_list_2emerge_24s1840066165x1513718921_24dps_entry(V self, V *a);
extern Clo g_list_2emerge_24s1840066165x1513718921_24dps_clo;
V g_list_2ezipWith_24s1604775524x1614188687(V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_clo;
V g_list_2ezipWith_24s1604775524x1614188687_24dps(V, V, V, V);
V g_list_2ezipWith_24s1604775524x1614188687_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1604775524x1614188687_24dps_clo;
V g_list_2ezipWith_24s1928181476x241816070_24dps(V, V, V);
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f686409757x475266571(V, V, V, V, V);
V g_prelude_2e_2b_2b_24f686409757x475266571_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f686409757x475266571_clo;
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);

HeffT2 g_list_2efind_24cpr(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_xs_243);
      heff_drop(v_t_244);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_x_242}});
    } else {
      heff_drop(v_x_242);
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_list_2efilter_24s727803713x1346936525_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s727803713x1346936525_24dps_entry, 3, 0};

V g_list_2efilter_24s727803713x1346936525_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c_lent(v_x_243, v_lit_240, 0)) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s727803713x1346936525_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2efilter_24s727803713x1346936525_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24s2029035892x1571084362_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2029035892x1571084362_24dps_entry, 2, 0};

V g_list_2emap_24s2029035892x1571084362_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 2ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){NTAG(TAG_FtAny), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2029035892x1571084362_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2029035892x1571084362_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1604775524x1614188687_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1604775524x1614188687_entry, 3, 0};

V g_list_2ezipWith_24s1604775524x1614188687(V v_lit_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_x3_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_Nil: {
      heff_drop(v_lit_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_242, 0);
      V v_ys_246 = heff_field(v_x3_242, 1);
      heff_take_n(v_x3_242, 3ULL, 2);
      V v_a_249;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_247 = heff_dup(heff_field(v_x_243, 0));
        v_a_249 = v_a_247;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_a_2412;
      switch (heff_tag_of(v_x_243)) {
      case TAG_MkPair: {
        V v_a_2411 = heff_field(v_x_243, 1);
        heff_take_n(v_x_243, 2ULL, 2);
        v_a_2412 = v_a_2411;
        break;
      }
      default: heff_nomatch(v_x_243);
      }
      V v_t_2416;
      switch (heff_tag_of(v_a_2412)) {
      case TAG_Unreached: {
        heff_drop(v_y_245);
        v_t_2416 = v_a_249;
        break;
      }
      case TAG_Within: {
        V v_t_2415 = ({ V a_0 = v_a_2412; V a_1 = v_y_245; V r_ = (g_heff_2ecompile_2eranges_2erangeEq(a_0, a_1)); heff_drop_tag(v_a_2412, 2); heff_drop(v_y_245); r_; });
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          v_t_2416 = v_a_249;
        } else {
          heff_drop(v_t_2415);
          v_t_2416 = heff_intAdd(v_a_249, heff_dup(v_lit_240));
        }
        break;
      }
      default: heff_nomatch(v_a_2412);
      }
      V v_cell_2417 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2416, heff_hole()});
      V v_u_2418 = (g_list_2ezipWith_24s1604775524x1614188687_24dps(v_lit_240, v_xs_244, v_ys_246, heff_dup(v_cell_2417)));
      heff_drop(v_u_2418);
      return v_cell_2417;
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2ezipWith_24s1604775524x1614188687_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1604775524x1614188687(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1836620197x1700774439_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1836620197x1700774439_entry, 1, 0};

V g_list_2efilter_24s1836620197x1700774439(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_241, 1));
      v_t_245 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = heff_get_n(v_t_245, 2, 3);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      heff_drop(v_x_241);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      heff_take_n(v_t_246, 0ULL, 2);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_2410 = (g_list_2efilter_24s1836620197x1700774439_24dps(v_xs_242, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1836620197x1700774439_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1836620197x1700774439(a[0]);
}
Clo g_list_2efoldl_24s477184376x1963488659_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s477184376x1963488659_entry, 2, 0};

V g_list_2efoldl_24s477184376x1963488659(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_dup(v_x_242), NTAG(TAG_MkUnit)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s477184376x1963488659_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s477184376x1963488659(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s26403090x581733227_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s26403090x581733227_entry, 4, 0};

V g_list_2efoldl_24s26403090x581733227(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eranges_2efnOne(v_lit_240, v_lit_241, v_z_242, heff_dup(v_x_244)));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_246;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s26403090x581733227_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a3 = a[3]; V r = g_list_2efoldl_24s26403090x581733227(a0, a1, a[2], a3); heff_drop(a0); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_list_2emap_24s620499005x2067584111_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s620499005x2067584111_entry, 2, 0};

V g_list_2emap_24s620499005x2067584111(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_242}), heff_dup(v_lit_240)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s620499005x2067584111_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s620499005x2067584111_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s620499005x2067584111(a[0], a[1]);
}
Clo g_list_2emap_24s2016093283x1174801437_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2016093283x1174801437_24dps_entry, 3, 0};

V g_list_2emap_24s2016093283x1174801437_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2efieldDeclOf(heff_dup(v_lit_240), v_x_243));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
    V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
    heff_drop(v_u_247);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_246;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s2016093283x1174801437_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2016093283x1174801437_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s1844509821x2028168277_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1844509821x2028168277_entry, 1, 0};

V g_list_2emap_24s1844509821x2028168277(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2esyntax_2epresyntax_2eclassifyTermF_24s208140465x650413033_24cpr(v_x_241));
    V v_t_2417;
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_a_247 = v_field_245;
        v_t_2417 = v_a_247;
      } else {
        if ((v_tag_244 == ((int64_t)1ULL))) {
          V v_a_249 = v_field_245;
          V v_t_2412;
          switch (heff_tag_of(v_a_249)) {
          case TAG_At: {
            V v_a_2411 = heff_dup(heff_field(v_a_249, 1));
            v_t_2412 = v_a_2411;
            break;
          }
          default: heff_nomatch(v_a_249);
          }
          v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_a_249}), v_t_2412});
        } else {
          V v_a_2413 = v_field_245;
          V v_t_2416;
          switch (heff_tag_of(v_a_2413)) {
          case TAG_At: {
            V v_a_2415 = heff_dup(heff_field(v_a_2413, 1));
            v_t_2416 = v_a_2415;
            break;
          }
          default: heff_nomatch(v_a_2413);
          }
          v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CType, 1, (V[]){v_a_2413}), v_t_2416});
        }
      }
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = (g_list_2emap_24s1844509821x2028168277_24dps(v_xs_242, heff_dup(v_cell_2418)));
    heff_drop(v_u_2419);
    return v_cell_2418;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1844509821x2028168277_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1844509821x2028168277(a[0]);
}
Clo g_list_2emap_24s961097229x1129443801_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s961097229x1129443801_entry, 1, 0};

V g_list_2emap_24s961097229x1129443801(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2esyntax_2epresyntax_2efieldSetOf_24s383133391x1335463183(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s961097229x1129443801_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s961097229x1129443801_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s961097229x1129443801(a[0]);
}
Clo g_list_2emap_24s513391942x823299088_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s513391942x823299088_entry, 1, 0};

V g_list_2emap_24s513391942x823299088(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      V v_ru_24x_241_24At = heff_take_reuse_n(v_x_241, 3ULL, 2);
      V v_t_2413;
      switch (heff_tag_of(v_a_243)) {
      case TAG_TagVariant: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        V v_a_247 = heff_field(v_a_243, 2);
        V v_ru_24a_243_24TagVariant = heff_take_reuse_n(v_a_243, 7ULL, 3);
        V v_t_248 = (g_list_2emap_24s158244903x55062455(v_a_247));
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24TagVariant, TAG_TagVariant, 3, (V[]){v_a_245, v_a_246, v_t_248});
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_243, 0);
        V v_ru_24a_243_24BadVariant = heff_take_reuse_n(v_a_243, 1ULL, 1);
        V v_t_2412;
        switch (heff_tag_of(v_a_249)) {
        case TAG_At: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_a_2411 = heff_field(v_a_249, 1);
          heff_take_n(v_a_249, 3ULL, 2);
          v_t_2412 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_a_2411, v_a_2410));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        v_t_2413 = heff_tag_at_n(v_ru_24a_243_24BadVariant, TAG_BadVariant, 1, (V[]){v_t_2412});
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      v_t_2414 = heff_tag_at_n(v_ru_24x_241_24At, TAG_At, 2, (V[]){v_t_2413, v_a_244});
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2415 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
    V v_u_2416 = (g_list_2emap_24s513391942x823299088_24dps(v_xs_242, heff_dup(v_cell_2415)));
    heff_drop(v_u_2416);
    return v_cell_2415;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s513391942x823299088_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s513391942x823299088(a[0]);
}
Clo g_list_2emap_24s1543151117x629172256_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1543151117x629172256_entry, 1, 0};

V g_list_2emap_24s1543151117x629172256(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eprims_2efixedImpl(v_x_241));
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s1543151117x629172256_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1543151117x629172256_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1543151117x629172256(a[0]);
}
Clo g_list_2emap_24s549405518x243689326_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s549405518x243689326_24dps_entry, 2, 0};

V g_list_2emap_24s549405518x243689326_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2440;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_EVar: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EGlobal: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ELam: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_True);
        break;
      }
      case TAG_EApp: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ELet: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ERecord: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EProj: {
        heff_take_n(v_x12_245, 0ULL, 4);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ETag: {
        heff_take_n(v_x12_245, 0ULL, 3);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EMatch: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrim: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_ECall: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EInt: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat: {
        heff_take_na(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EStr: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EBytes: {
        heff_take_n(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFixed: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFloat32: {
        heff_take_na(v_x12_245, 0ULL, 1);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EAbandon: {
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      case TAG_EFix: {
        heff_take_n(v_x12_245, 0ULL, 2);
        v_t_2440 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2441 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2440, heff_hole()});
    V v_u_2442 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2441));
    heff_drop(v_u_2442);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2441;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s549405518x243689326_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s549405518x243689326_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s1794308634x1384130934_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1794308634x1384130934_entry, 5, 0};

V g_list_2efoldl_24s1794308634x1384130934(V v_lit_240, V v_lit_241, V v_lit_242, V v_z_243, V v_x3_244) {
top: ;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return v_z_243;
  }
  case TAG_Cons: {
    V v_xs_246 = heff_field(v_x3_244, 1);
    V v_ru_24x3_244_24Cons = heff_take_reuse_n(v_x3_244, 2ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_z_243)) {
    case TAG_MkPair: {
      V v_a_247 = heff_field(v_z_243, 0);
      V v_a_248 = heff_field(v_z_243, 1);
      V v_ru_24z_243_24MkPair = heff_take_reuse_n(v_z_243, 3ULL, 2);
      V v_t_249 = heff_strAppend(heff_dup(v_lit_241), heff_intShow(heff_dup(v_a_248)));
      V v_t_2410 = heff_tag_at_n(v_ru_24x3_244_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_249), v_a_247});
      v_t_2411 = heff_tag_at_n(v_ru_24z_243_24MkPair, TAG_MkPair, 2, (V[]){v_t_2410, heff_intAdd(v_a_248, heff_dup(v_lit_242))});
      break;
    }
    default: heff_nomatch(v_z_243);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_lit_242;
    V t_3 = v_t_2411;
    V t_4 = v_xs_246;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_lit_242 = t_2;
    v_z_243 = t_3;
    v_x3_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x3_244);
  }
}
V g_list_2efoldl_24s1794308634x1384130934_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1794308634x1384130934(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2emap_24s1123370502x1982532655_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1123370502x1982532655_24dps_entry, 2, 0};

V g_list_2emap_24s1123370502x1982532655_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_HS, 1, (V[]){v_x_242}), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = v_xs_243;
    V t_1 = v_cell_244;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1123370502x1982532655_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1123370502x1982532655_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s788715611x32297348_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s788715611x32297348_entry, 2, 0};

V g_list_2efoldl_24s788715611x32297348(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkArm: {
      V v_a_246 = heff_field(v_x_242, 2);
      v_t_247 = heff_tr(g_heff_2ecompile_2eimperative_2epartsTl_24s681398288x1052536937(v_a_246, v_z_240));
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_t_247;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s788715611x32297348_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s788715611x32297348(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s348204425x880103432_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s348204425x880103432_entry, 2, 0};

V g_list_2efoldl_24s348204425x880103432(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2410 = heff_tag_n(TAG_IBind, 2, (V[]){v_t_246, heff_tag_n(TAG_OSimple, 1, (V[]){v_t_249})});
    V t_0 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, v_z_240});
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s348204425x880103432_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s348204425x880103432(a[0], a[1]);
}
Clo g_list_2emap_24s1310249268x749995235_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1310249268x749995235_24dps_entry, 4, 0};

V g_list_2emap_24s1310249268x749995235_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = (g_heff_2ecompile_2erepr_2edecidedIn(v_lit_240, v_lit_241, v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1310249268x749995235_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_list_2emap_24s1310249268x749995235_24dps(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1826815879x1318332352_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1826815879x1318332352_24dps_entry, 2, 0};

V g_list_2efilter_24s1826815879x1318332352_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_RepV: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_246, 0ULL, 1);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepF64: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepInt: {
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2413 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2412;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1826815879x1318332352_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1826815879x1318332352_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s361779565x1527579812_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s361779565x1527579812_entry, 1, 0};

V g_list_2eany_24s361779565x1527579812(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_vs_244 = heff_field(v_x_241, 1);
      V v_b_245 = heff_field(v_x_241, 2);
      switch (heff_tag_of(v_vs_244)) {
      case TAG_Nil: {
        v_t_249 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_244));
        v_t_249 = (g_heff_2ecompile_2eborrow_2ebuildsSize(v_t_248, heff_dup(v_b_245)));
        break;
      }
      default: heff_nomatch(v_vs_244);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_249);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2eany_24s361779565x1527579812_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2eany_24s361779565x1527579812(a0); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s1416922510x485352908_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1416922510x485352908_entry, 2, 0};

V g_list_2efoldl_24s1416922510x485352908(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_heff_2ecompile_2eborrow_2eborDef(v_z_240, heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1416922510x485352908_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s1416922510x485352908(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s1535080205x545126304_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1535080205x545126304_24dps_entry, 5, 0};

V g_list_2efilter_24s1535080205x545126304_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_a_247 = (g_list_2efoldl_24s65689923x209800052(heff_dup(v_lit_240), heff_dup(v_lit_241), v_x_245));
    if (heff_intLe_c_lent(v_lit_242, v_a_247, 2)) {
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_2410 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_249));
      heff_drop(v_u_2410);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1535080205x545126304_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1535080205x545126304_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24s1111748987x306062113_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1111748987x306062113_entry, 3, 0};

V g_list_2efoldl_24s1111748987x306062113(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_z_241, 0));
      v_t_247 = v_a_245;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2410;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_249 = heff_dup(heff_field(v_z_241, 1));
      v_t_2410 = v_a_249;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2413;
    switch (heff_tag_of(v_z_241)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_z_241, 0);
      heff_take_n(v_z_241, 1ULL, 2);
      v_t_2413 = v_a_2411;
      break;
    }
    default: heff_nomatch(v_z_241);
    }
    V v_t_2414 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_t_2410, heff_get_n(v_x_243, 0, 3), v_t_2413));
    V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkPair, 2, (V[]){heff_intAdd(v_t_247, heff_dup(v_lit_240)), v_t_2414});
    V t_0 = v_lit_240;
    V t_1 = v_t_2415;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1111748987x306062113_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1111748987x306062113(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s231073986x752637537_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s231073986x752637537_24dps_entry, 3, 0};

V g_list_2emap_24s231073986x752637537_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_x_243), heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_lit_240;
    V t_1 = v_xs_244;
    V t_2 = v_cell_245;
    v_lit_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s231073986x752637537_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s231073986x752637537_24dps(a[0], a[1], a[2]);
}
Clo g_list_2eany_24s1817246263x1083513945_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1817246263x1083513945_entry, 2, 0};

V g_list_2eany_24s1817246263x1083513945(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_lit_240, v_x_242, 0)) {
      heff_drop(v_lit_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2eany_24s1817246263x1083513945_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2eany_24s1817246263x1083513945(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efoldl_24s522807745x1556762248_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s522807745x1556762248_entry, 2, 0};

V g_list_2efoldl_24s522807745x1556762248(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_242, 1);
      switch (heff_tag_of(v_a_245)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_a_245, 1);
        v_t_248 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(heff_dup(v_a_247)));
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249 = (g_prelude_2e_2b_2b(v_t_248, v_z_240));
    V t_0 = v_t_249;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s522807745x1556762248(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2emap_24s1367173129x1257089258_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1367173129x1257089258_entry, 1, 0};

V g_list_2emap_24s1367173129x1257089258(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_x_241, 0, 4), heff_hole()});
    V v_u_244 = (g_list_2emap_24s1367173129x1257089258_24dps(v_xs_242, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1367173129x1257089258(a[0]);
}
Clo g_list_2efoldl_24s976906006x1321876394_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s976906006x1321876394_entry, 4, 0};

V g_list_2efoldl_24s976906006x1321876394(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_ru_24x3_243_24Cons = heff_take_reuse_n(v_x3_243, 3ULL, 2);
    V v_t_2458;
    switch (heff_tag_of(v_x_244)) {
    case TAG_PartVal: {
      V v_a_246 = heff_field(v_x_244, 0);
      V v_ru_24x_244_24PartVal = heff_take_reuse_n(v_x_244, 1ULL, 1);
      switch (heff_tag_of(v_a_246)) {
      case TAG_SVar: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFloat: {
        heff_take_na(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SFloat32: {
        heff_take_na(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_a_246, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_STag: {
        heff_take_n(v_a_246, 0ULL, 3);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      case TAG_SProj: {
        V v_a_2424 = heff_field(v_a_246, 0);
        V v_a_2426 = heff_field(v_a_246, 2);
        heff_take_n(v_a_246, 5ULL, 4);
        switch (heff_tag_of(v_a_2424)) {
        case TAG_SVar: {
          V v_a_2428 = heff_field(v_a_2424, 0);
          heff_take_n(v_a_2424, 1ULL, 1);
          switch (heff_tag_of(v_a_2426)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24x3_243_24Cons, 2);
            heff_drop_cell(v_ru_24x_244_24PartVal, 1);
            heff_drop(v_a_2428);
            v_t_2458 = v_z_242;
            break;
          }
          case TAG_Cons: {
            V v_t_2431 = ({ V a_0 = heff_dup(v_lit_240); V a_1 = heff_dup(v_lit_241); V a_2 = v_a_2426; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop_tag(v_a_2426, 2); r_; });
            V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){v_a_2428, heff_tag_at_n(v_ru_24x_244_24PartVal, TAG_KnownRec, 1, (V[]){v_t_2431})});
            v_t_2458 = heff_tag_at_n(v_ru_24x3_243_24Cons, TAG_Cons, 2, (V[]){v_t_2432, v_z_242});
            break;
          }
          default: heff_nomatch(v_a_2426);
          }
          break;
        }
        case TAG_SGlobal: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SInt: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFloat: {
          heff_take_na(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SStr: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SBytes: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFixed: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SFloat32: {
          heff_take_na(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SPrimFn: {
          heff_take_n(v_a_2424, 0ULL, 1);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SLam: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_STag: {
          heff_take_n(v_a_2424, 0ULL, 3);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SRec: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SProj: {
          heff_take_n(v_a_2424, 0ULL, 4);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        case TAG_SPrim: {
          heff_take_n(v_a_2424, 0ULL, 2);
          heff_drop_cell(v_ru_24x3_243_24Cons, 2);
          heff_drop_cell(v_ru_24x_244_24PartVal, 1);
          heff_drop(v_a_2426);
          v_t_2458 = v_z_242;
          break;
        }
        default: heff_nomatch(v_a_2424);
        }
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_a_246, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_243_24Cons, 2);
        heff_drop_cell(v_ru_24x_244_24PartVal, 1);
        v_t_2458 = v_z_242;
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    case TAG_PartOp: {
      heff_take_n(v_x_244, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_243_24Cons, 2);
      v_t_2458 = v_z_242;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_2458;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s976906006x1321876394_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s976906006x1321876394(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s1791954930x928584331_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1791954930x928584331_24dps_entry, 2, 0};

V g_list_2efilter_24s1791954930x928584331_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_dup(heff_field(v_x_242, 1));
      v_t_246 = v_a_245;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 2ULL, 2);
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    switch (heff_tag_of(v_t_249)) {
    case TAG_RepV: {
      V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
      heff_drop(v_u_2411);
      V t_0 = v_xs_243;
      V t_1 = v_cell_2410;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepFix: {
      heff_take_n(v_t_249, 0ULL, 1);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepF64: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_RepInt: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1791954930x928584331_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1791954930x928584331_24dps(a[0], a[1]);
}
Clo g_list_2ezipWith_24s1928181476x241816070_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2ezipWith_24s1928181476x241816070_24dps_entry, 3, 0};

V g_list_2ezipWith_24s1928181476x241816070_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    heff_drop(v_x3_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_240, 0);
    V v_xs_244 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      V v_t_247 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, heff_tag_n(TAG_EVar, 1, (V[]){v_y_245})});
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_248;
      v_x2_240 = t_0;
      v_x3_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2ezipWith_24s1928181476x241816070_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2ezipWith_24s1928181476x241816070_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24s2082573419x947677806_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2082573419x947677806_entry, 2, 0};

V g_list_2efoldl_24s2082573419x947677806(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, heff_dup(heff_rfield(v_x_242, 0)), heff_dup(v_x_242)));
    V t_0 = v_t_244;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s2082573419x947677806_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_list_2efoldl_24s2082573419x947677806(a[0], a1); heff_drop(a1); return r;
}
Clo g_list_2efilter_24s2101000672x961294372_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2101000672x961294372_24dps_entry, 5, 0};

V g_list_2efilter_24s2101000672x961294372_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_245, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s2101000672x961294372_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2efilter_24s2101000672x961294372_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efilter_24s1820448628x561773228_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1820448628x561773228_entry, 4, 0};

V g_list_2efilter_24s1820448628x561773228(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_244, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = (g_list_2efilter_24s1820448628x561773228_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop(v_x_244);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_245;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1820448628x561773228_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2efilter_24s1820448628x561773228(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efilter_24s1820448628x561773228_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1820448628x561773228_24dps_entry, 5, 0};

V g_list_2efilter_24s1820448628x561773228_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_245, v_lit_240, v_lit_241, 0), heff_dup(v_lit_242))) {
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
      V v_u_249 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_248;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2efilter_24s1820448628x561773228_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_list_2efilter_24s1820448628x561773228_24dps(a0, a1, a2, a[3], a[4]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1659194469x1936830512_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1659194469x1936830512_entry, 2, 0};

V g_list_2efoldl_24s1659194469x1936830512(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_a_244 = (g_heff_2ecompile_2eemitc_2etagsLbls(v_x_242));
    V v_t_2411;
    switch (heff_tag_of(v_a_244)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_a_244, 0);
      V v_a_246 = heff_field(v_a_244, 1);
      heff_take_n(v_a_244, 3ULL, 2);
      switch (heff_tag_of(v_z_240)) {
      case TAG_MkPair: {
        V v_a_247 = heff_field(v_z_240, 0);
        V v_a_248 = heff_field(v_z_240, 1);
        heff_take_n(v_z_240, 3ULL, 2);
        V v_t_249 = (g_prelude_2e_2b_2b(v_a_245, v_a_247));
        V v_t_2410 = (g_prelude_2e_2b_2b(v_a_246, v_a_248));
        v_t_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_MkPair, 2, (V[]){v_t_249, v_t_2410});
        break;
      }
      default: heff_nomatch(v_z_240);
      }
      break;
    }
    default: heff_nomatch(v_a_244);
    }
    V t_0 = v_t_2411;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s1659194469x1936830512_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s1659194469x1936830512(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str1, 2, "v_");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str2, 2, ");");
HEFF_LIT(g_list_2emap_24s577269653x49010166_24dps_str3, 10, "heff_drop(");
Clo g_list_2emap_24s577269653x49010166_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s577269653x49010166_24dps_entry, 2, 0};

V g_list_2emap_24s577269653x49010166_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkDrop: {
      V v_x_244 = heff_field(v_x_242, 0);
      V v_x12_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_x12_245)) {
      case TAG_Nothing: {
        V v_t_246 = ({ V a_0 = v_x_244; V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = ((V)&g_list_2emap_24s577269653x49010166_24dps_str0); V r_ = (g_heff_2ecompile_2eemitc_2emangleW(a_0, a_1, a_2, a_3)); heff_drop(v_x_244); r_; });
        V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str1), v_t_246), ((V)&g_list_2emap_24s577269653x49010166_24dps_str2));
        v_t_249 = heff_strAppend(((V)&g_list_2emap_24s577269653x49010166_24dps_str3), v_t_247);
        break;
      }
      case TAG_Just: {
        V v_k_248 = heff_field(v_x12_245, 0);
        heff_take_n(v_x12_245, 1ULL, 1);
        v_t_249 = ({ V a_0 = v_x_244; V a_1 = v_k_248; V r_ = (g_heff_2ecompile_2eemitc_2edropAs(a_0, a_1)); heff_drop(v_x_244); heff_drop(v_k_248); r_; });
        break;
      }
      default: heff_nomatch(v_x12_245);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2410;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s577269653x49010166_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s577269653x49010166_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s1382928954x1260344933_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1382928954x1260344933_24dps_entry, 4, 0};

V g_list_2emap_24s1382928954x1260344933_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_246 = heff_strAppend(heff_intShow(v_x_244), heff_dup(v_lit_241));
    V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_246), heff_hole()});
    V v_u_248 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_247;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1382928954x1260344933_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s1382928954x1260344933_24dps(a[0], a[1], a[2], a[3]);
}
Clo g_list_2emap_24s588563787x236154271_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s588563787x236154271_entry, 4, 0};

V g_list_2emap_24s588563787x236154271(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_248;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_247 = heff_dup(heff_field(v_x_244, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2411;
    switch (heff_tag_of(v_x_244)) {
    case TAG_MkPair: {
      V v_a_249 = heff_field(v_x_244, 0);
      heff_take_n(v_x_244, 1ULL, 2);
      v_t_2411 = v_a_249;
      break;
    }
    default: heff_nomatch(v_x_244);
    }
    V v_t_2412 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(v_t_2411, heff_dup(v_lit_242)));
    V v_t_2413 = heff_strAppend(heff_intShow(v_t_248), v_t_2412);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(heff_dup(v_lit_240), v_t_2413), heff_hole()});
    V v_u_2415 = (g_list_2emap_24s588563787x236154271_24dps(v_lit_240, v_lit_241, v_lit_242, v_xs_245, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24s588563787x236154271_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s588563787x236154271(a[0], a[1], a[2], a[3]);
}
Clo g_list_2efilter_24s1018181017x1541469354_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1018181017x1541469354_24dps_entry, 2, 0};

V g_list_2efilter_24s1018181017x1541469354_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_a_247 = ({ V a_0 = v_t_246; V b_1 = heff_dup(g_heff_2ecompile_2eemitc_2eknownTags_get()); V r_ = (g_heff_2ecompile_2eemitc_2eelemS(a_0, b_1)); heff_drop(v_t_246); heff_drop(b_1); r_; });
    if ((heff_dup(v_a_247) == NTAG(TAG_True))) {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_a_247);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop(v_a_247);
      V v_cell_248 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
      V v_u_249 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_248));
      heff_drop(v_u_249);
      V t_0 = v_xs_243;
      V t_1 = v_cell_248;
      v_x2_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s1018181017x1541469354_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1018181017x1541469354_24dps(a[0], a[1]);
}
Clo g_list_2eany_24s1673346944x1460195389_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s1673346944x1460195389_entry, 8, 0};

V g_list_2eany_24s1673346944x1460195389(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_x2_247) {
top: ;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    heff_drop(v_lit_243);
    heff_drop(v_lit_245);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    V v_t_2410 = heff_strAppend(heff_dup(v_lit_241), heff_strAppend(heff_dup(v_x_248), heff_dup(v_lit_242)));
    V v_t_2413;
    switch (heff_tag_of(v_lit_244)) {
    case TAG_MkPair: {
      V v_a_2411 = heff_field(v_lit_244, 0);
      v_t_2413 = heff_dup(v_a_2411);
      break;
    }
    default: heff_nomatch(v_lit_244);
    }
    V v_t_2414 = heff_strAppend(heff_dup(v_lit_243), heff_strAppend(v_t_2413, heff_dup(v_lit_245)));
    if (heff_intLe_c(heff_dup(v_lit_240), heff_strFind_lent(v_t_2410, v_t_2414, v_lit_246, 3))) {
      heff_drop(v_lit_240);
      heff_drop(v_lit_241);
      heff_drop(v_lit_242);
      heff_drop(v_lit_243);
      heff_drop(v_lit_245);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_lit_243;
      V t_4 = v_lit_244;
      V t_5 = v_lit_245;
      V t_6 = v_lit_246;
      V t_7 = v_xs_249;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_lit_243 = t_3;
      v_lit_244 = t_4;
      v_lit_245 = t_5;
      v_lit_246 = t_6;
      v_x2_247 = t_7;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
V g_list_2eany_24s1673346944x1460195389_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V a6 = a[6]; V a7 = a[7]; V r = g_list_2eany_24s1673346944x1460195389(a[0], a[1], a[2], a[3], a4, a[5], a6, a7); heff_drop(a4); heff_drop(a6); heff_drop(a7); return r;
}
Clo g_list_2efoldl_24s1882737314x358197882_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1882737314x358197882_entry, 4, 0};

V g_list_2efoldl_24s1882737314x358197882(V v_lit_240, V v_lit_241, V v_z_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return v_z_242;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x3_243, 0);
    V v_xs_245 = heff_field(v_x3_243, 1);
    V v_t_246 = (g_heff_2ecompile_2eemitc_2enamesInGo(v_lit_240, heff_rfield(v_x_244, 1), heff_dup(v_lit_241), NTAG(TAG_Nil)));
    V v_t_247 = (g_prelude_2e_2b_2b(v_t_246, v_z_242));
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_t_247;
    V t_3 = v_xs_245;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_z_242 = t_2;
    v_x3_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_list_2efoldl_24s1882737314x358197882_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_list_2efoldl_24s1882737314x358197882(a0, a[1], a[2], a3); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_list_2efoldl_24s842401018x360740028_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s842401018x360740028_entry, 2, 0};

V g_list_2efoldl_24s842401018x360740028(V v_z_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    return v_z_240;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_dup(heff_field(v_x_242, 0));
      v_t_246 = v_a_244;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_248 = heff_dup(heff_field(v_x_242, 1));
      v_t_249 = v_a_248;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_2410 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      v_t_2412 = v_a_2410;
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    HeffT2 v_t_2413 = ({ V a_0 = v_z_240; V a_1 = v_t_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_t_2412); r_; });
    V v_t_2418;
    {
      V v_field_2415 = v_t_2413.f[1];
      int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
      if ((v_tag_2414 == ((int64_t)0ULL))) {
        V v_a_2417 = v_field_2415;
        v_t_2418 = v_a_2417;
      } else {
        heff_drop(v_field_2415);
        v_t_2418 = NTAG(TAG_Nil);
      }
    }
    V v_t_2419 = (g_std_2emap_2einsert_24s1305793909x1049798133(v_z_240, v_t_246, heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, v_t_2418})));
    V t_0 = v_t_2419;
    V t_1 = v_xs_243;
    v_z_240 = t_0;
    v_x3_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_list_2efoldl_24s842401018x360740028_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s842401018x360740028(a[0], a[1]);
}
Clo g_list_2emap_24s380834591x871125279_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s380834591x871125279_24dps_entry, 2, 0};

V g_list_2emap_24s380834591x871125279_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eemitc_2epubLine(v_x_242));
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s380834591x871125279_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s380834591x871125279_24dps(a[0], a[1]);
}
Clo g_list_2efoldl_24s425699049x1164890302_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s425699049x1164890302_entry, 3, 0};

V g_list_2efoldl_24s425699049x1164890302(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddJs(heff_dup(v_lit_240), v_z_241, v_x_243));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s425699049x1164890302(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2efoldl_24s1494296198x1800016121_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s1494296198x1800016121_entry, 3, 0};

V g_list_2efoldl_24s1494296198x1800016121(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ebuild_2ebackcache_2eaddGroup(heff_dup(v_lit_240), v_z_241, heff_dup(v_x_243)));
    V t_0 = v_lit_240;
    V t_1 = v_t_245;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s1494296198x1800016121(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_list_2emerge_24s1840066165x1513718921_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emerge_24s1840066165x1513718921_24dps_entry, 3, 0};

V g_list_2emerge_24s1840066165x1513718921_24dps(V v_x2_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x3_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_dup(heff_field(v_x2_240, 0));
    V v_xs_244 = heff_dup(heff_field(v_x2_240, 1));
    switch (heff_tag_of(v_x3_241)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_243, 10);
      heff_drop(v_xs_244);
      return heff_setField(v_d_242, MK_INT(1LL), v_x2_240);
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x3_241, 0);
      V v_ys_246 = heff_field(v_x3_241, 1);
      V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
      heff_drop_tag(v_x2_240, 2);
      if (heff_intLe_c(heff_dup(heff_rfield(v_y_245, 0)), heff_dup(heff_rfield(v_x_243, 0)))) {
        V v_cell_248 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
        V v_u_249 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_248));
        heff_drop(v_u_249);
        V t_0 = v_xs_244;
        V t_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_y_245, v_ys_246});
        V t_2 = v_cell_248;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        V v_cell_2410 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_y_245, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_xs_244});
        V t_1 = v_ys_246;
        V t_2 = v_cell_2410;
        v_x2_240 = t_0;
        v_x3_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x3_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emerge_24s1840066165x1513718921_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emerge_24s1840066165x1513718921_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24s1646962431x688731818_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s1646962431x688731818_24dps_entry, 3, 0};

V g_list_2efilter_24s1646962431x688731818_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_dup(v_x_243), heff_dup(heff_rfield(v_lit_240, 1)))) {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2efilter_24s1646962431x688731818_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s1646962431x688731818_24dps(a[0], a[1], a[2]);
}
Clo g_list_2emap_24s570961906x1112476114_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s570961906x1112476114_24dps_entry, 2, 0};

V g_list_2emap_24s570961906x1112476114_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244 = ({ V a_0 = v_x_242; V r_ = (g_heff_2ebuild_2edriver_2elabelOfV(a_0)); heff_drop(v_x_242); r_; });
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_243;
    V t_1 = v_cell_245;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s570961906x1112476114_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s570961906x1112476114_24dps(a[0], a[1]);
}
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str0, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str1, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str2, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str3, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str4, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str5, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str6, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str7, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str8, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str9, 0, "");
HEFF_LIT(g_list_2emap_24s218655275x981659442_24dps_str10, 0, "");
Clo g_list_2emap_24s218655275x981659442_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s218655275x981659442_24dps_entry, 2, 0};

V g_list_2emap_24s218655275x981659442_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2417;
    switch (heff_tag_of(v_x_242)) {
    case TAG_VFun: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str0);
      break;
    }
    case TAG_VCons: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str1);
      break;
    }
    case TAG_VTag: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str2);
      break;
    }
    case TAG_VInt: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str3);
      break;
    }
    case TAG_VFloat: {
      heff_take_na(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str4);
      break;
    }
    case TAG_VFloat32: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str5);
      break;
    }
    case TAG_VStr: {
      V v_s_2411 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 1);
      v_t_2417 = v_s_2411;
      break;
    }
    case TAG_VRune: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str6);
      break;
    }
    case TAG_VArr: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str7);
      break;
    }
    case TAG_VBytes: {
      heff_take_n(v_x_242, 0ULL, 1);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str8);
      break;
    }
    case TAG_VBits: {
      heff_take_n(v_x_242, 0ULL, 2);
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str9);
      break;
    }
    case TAG_VErased: {
      v_t_2417 = ((V)&g_list_2emap_24s218655275x981659442_24dps_str10);
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2418 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2417, heff_hole()});
    V v_u_2419 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2418));
    heff_drop(v_u_2419);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2418;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s218655275x981659442_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s218655275x981659442_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s675147852x248982264_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s675147852x248982264_entry, 2, 0};

V g_list_2emap_24s675147852x248982264(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_rec_n(3, shape_by__path__version, (V[]){heff_dup(v_lit_240), heff_take_field(v_x_242, 1), heff_get_n(v_x_242, 2, 3)});
    V v_cell_245 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, heff_hole()});
    V v_u_246 = (g_list_2emap_24s675147852x248982264_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24s675147852x248982264_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s675147852x248982264(a[0], a[1]);
}
Clo g_list_2efilter_24s2018073091x1385246979_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24s2018073091x1385246979_entry, 1, 0};

V g_list_2efilter_24s2018073091x1385246979(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_dup(heff_rfield(v_x_241, 2));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_241, 3);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, heff_hole()});
      V v_u_245 = (g_list_2efilter_24s2018073091x1385246979_24dps(v_xs_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2efilter_24s2018073091x1385246979_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24s2018073091x1385246979(a[0]);
}
Clo g_list_2emap_24s173442543x1801751270_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s173442543x1801751270_24dps_entry, 2, 0};

V g_list_2emap_24s173442543x1801751270_24dps(V v_x2_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_x11_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_x11_244)) {
      case TAG_TagVariant: {
        V v_t_246 = heff_field(v_x11_244, 0);
        V v_tsp_247 = heff_field(v_x11_244, 1);
        heff_take_n(v_x11_244, 3ULL, 3);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_t_246, v_tsp_247})});
        break;
      }
      case TAG_BadVariant: {
        heff_take_n(v_x11_244, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_xs_243;
    V t_1 = v_cell_2411;
    v_x2_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s173442543x1801751270_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s173442543x1801751270_24dps(a[0], a[1]);
}
Clo g_list_2emap_24s2000102784x314586828_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s2000102784x314586828_entry, 1, 0};

V g_list_2emap_24s2000102784x314586828(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_DeclareField: {
        V v_x_245 = heff_field(v_x11_243, 0);
        V v_sp_246 = heff_field(v_x11_243, 1);
        heff_take_n(v_x11_243, 3ULL, 4);
        v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_name__span, (V[]){v_x_245, v_sp_246})});
        break;
      }
      case TAG_BadFieldDecl: {
        heff_take_n(v_x11_243, 0ULL, 1);
        v_t_2410 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_list_2emap_24s2000102784x314586828_24dps(v_xs_242, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s2000102784x314586828(a[0]);
}
Clo g_list_2emap_24s764064723x821001015_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s764064723x821001015_entry, 1, 0};

V g_list_2emap_24s764064723x821001015(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_x_241, 0), heff_get_n(v_x_241, 1, 2)});
    V v_cell_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_t_243, heff_hole()});
    V v_u_245 = (g_list_2emap_24s764064723x821001015_24dps(v_xs_242, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_list_2emap_24s764064723x821001015_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24s764064723x821001015(a[0]);
}
Clo g_list_2emap_24s1951926392x340347826_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24s1951926392x340347826_24dps_entry, 4, 0};

V g_list_2emap_24s1951926392x340347826_24dps(V v_lit_240, V v_lit_241, V v_x2_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_242, 0);
    V v_xs_245 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_248;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), heff_dup(v_lit_240))) {
      V v_t_247 = heff_strAppend(heff_take_field(v_x_244, 3), heff_dup(v_lit_241));
      v_t_248 = ({ V rv_3 = v_t_247; V rr_ = heff_rec_reuse_nf(v_x_244, 119ULL, 7, shape_module__path__shown__source__renames__implicit__library, 16191u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      v_t_248 = v_x_244;
    }
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_249));
    heff_drop(v_u_2410);
    V t_0 = v_lit_240;
    V t_1 = v_lit_241;
    V t_2 = v_xs_245;
    V t_3 = v_cell_249;
    v_lit_240 = t_0;
    v_lit_241 = t_1;
    v_x2_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24s1951926392x340347826_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24s1951926392x340347826_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_list_2efoldl_24s192900907x155689445_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s192900907x155689445_entry, 3, 0};

V g_list_2efoldl_24s192900907x155689445(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 1)), 4, 7);
    V v_t_246 = (g_prelude_2e_2b_2b_24f686409757x475266571(v_z_241, heff_dup(heff_rfield(v_x_243, 0)), heff_dup(heff_rfield(v_x_243, 2)), heff_dup(v_lit_240), v_t_245));
    V t_0 = v_lit_240;
    V t_1 = v_t_246;
    V t_2 = v_xs_244;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_list_2efoldl_24s192900907x155689445(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0(V self, V *args);
Clo g_list_2efoldl_24s2062876492x2082655823_24scalars_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24s2062876492x2082655823_24scalars_entry, 3, 0};

V g_list_2efoldl_24s2062876492x2082655823_24scalars(V v_front_240, V v_back_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_front__back, (V[]){v_front_240, v_back_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V t_0 = v_front_240;
    V t_1 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_clo_n(g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0, 1, 1, (V[]){v_x_243}), v_back_241});
    V t_2 = v_xs_244;
    v_front_240 = t_0;
    v_back_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24s2062876492x2082655823_24scalars(a[0], a[1], a[2]);
}
V g_list_2efoldl_24s2062876492x2082655823_24scalars_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_245);
  return v_x_243;
}
Clo g_list_2eany_24s811553642x27402676_clo = {{0x80000000u, K_CLO, 0}, g_list_2eany_24s811553642x27402676_entry, 7, 0};

V g_list_2eany_24s811553642x27402676(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_x2_246) {
top: ;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    heff_drop(v_lit_245);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), heff_dup(v_lit_240))) {
      heff_drop(v_lit_245);
      return NTAG(TAG_True);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 1)), heff_dup(v_lit_241))) {
        heff_drop(v_lit_245);
        return NTAG(TAG_True);
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_247, 0)), heff_dup(v_lit_242))) {
          heff_drop(v_lit_245);
          return NTAG(TAG_True);
        } else {
          V v_t_2412 = heff_strFind(heff_dup(v_lit_243), heff_dup(heff_rfield(v_x_247, 0)), heff_dup(v_lit_244));
          if (heff_intLt_c_lent(v_t_2412, v_lit_245, 1)) {
            V t_0 = v_lit_240;
            V t_1 = v_lit_241;
            V t_2 = v_lit_242;
            V t_3 = v_lit_243;
            V t_4 = v_lit_244;
            V t_5 = v_lit_245;
            V t_6 = v_xs_248;
            v_lit_240 = t_0;
            v_lit_241 = t_1;
            v_lit_242 = t_2;
            v_lit_243 = t_3;
            v_lit_244 = t_4;
            v_lit_245 = t_5;
            v_x2_246 = t_6;
            goto top;
          } else {
            heff_drop(v_lit_245);
            return NTAG(TAG_True);
          }
        }
      }
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_list_2eany_24s811553642x27402676_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a6 = a[6]; V r = g_list_2eany_24s811553642x27402676(a0, a1, a2, a3, a4, a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a6); return r;
}
Clo g_list_2emap_24f1799988110x1394031252_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1799988110x1394031252_24dps_entry, 5, 0};

V g_list_2emap_24f1799988110x1394031252_24dps(V v_lit_240, V v_lit_241, V v_lit_242, V v_x2_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_lit_242);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_243, 0);
    V v_xs_246 = heff_field(v_x2_243, 1);
    V v_ru_24x2_243_24Cons = heff_take_reuse_n(v_x2_243, 3ULL, 2);
    V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_x_245, 1))}));
    V v_t_248 = ({ V a_0 = v_t_247; V b_1 = heff_dup(g_heff_2esyntax_2efixity_2ereserved_get()); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_strAppend(heff_take_field(v_x_245, 1), heff_dup(v_lit_242));
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 2), heff_get_n(v_x_245, 3, 7)});
      V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){heff_dup(v_lit_240), NTAG(TAG_SError), heff_strAppend(heff_dup(v_lit_241), v_t_249), v_t_2410, NTAG(TAG_Nothing)});
      V v_cell_2412 = heff_tag_at_n(v_ru_24x2_243_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2412));
      heff_drop(v_u_2413);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_cell_2412;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    } else {
      heff_drop_rec(v_x_245, 7);
      heff_drop_cell(v_ru_24x2_243_24Cons, 2);
      heff_drop(v_t_248);
      V t_0 = v_lit_240;
      V t_1 = v_lit_241;
      V t_2 = v_lit_242;
      V t_3 = v_xs_246;
      V t_4 = v_d_244;
      v_lit_240 = t_0;
      v_lit_241 = t_1;
      v_lit_242 = t_2;
      v_x2_243 = t_3;
      v_d_244 = t_4;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_list_2emap_24f1799988110x1394031252_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1799988110x1394031252_24dps(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_list_2efoldl_24f1841208961x1043590714_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f1841208961x1043590714_entry, 5, 0};

V g_list_2efoldl_24f1841208961x1043590714(V v_lit_240, V v_z_241, V v_lit_242, V v_n_243, V v_x2_244) {
top: ;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_n_243);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    if (heff_intLe_c_lent(v_n_243, MK_INT(0LL), 2)) {
      heff_drop(v_lit_240);
      heff_drop(v_n_243);
      return v_z_241;
    } else {
      if (heff_strEq_c_lent(v_x_245, v_lit_242, 0)) {
        V t_0 = heff_dup(v_lit_240);
        V t_1 = heff_intAdd(v_z_241, v_lit_240);
        V t_2 = v_lit_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      } else {
        V t_0 = v_lit_240;
        V t_1 = v_z_241;
        V t_2 = v_lit_242;
        V t_3 = heff_intSub(v_n_243, MK_INT(1LL));
        V t_4 = v_xs_246;
        v_lit_240 = t_0;
        v_z_241 = t_1;
        v_lit_242 = t_2;
        v_n_243 = t_3;
        v_x2_244 = t_4;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_244);
  }
}
V g_list_2efoldl_24f1841208961x1043590714_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a4 = a[4]; V r = g_list_2efoldl_24f1841208961x1043590714(a[0], a[1], a2, a[3], a4); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_list_2emap_24f966602123x1640556393_str0, 13, "static Clo g_");
Clo g_list_2emap_24f966602123x1640556393_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f966602123x1640556393_entry, 2, 0};

V g_list_2emap_24f966602123x1640556393(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_242, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24f966602123x1640556393_str0))) {
      V v_t_245 = heff_strSlice(heff_dup(v_x_242), heff_dup(v_lit_240), heff_strLength(v_x_242));
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_245, heff_hole()});
      V v_u_247 = (g_list_2emap_24f966602123x1640556393_24dps(v_lit_240, v_xs_243, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f966602123x1640556393_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f966602123x1640556393(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_list_2emap_24f966602123x1640556393_24dps_str0, 13, "static Clo g_");
Clo g_list_2emap_24f966602123x1640556393_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f966602123x1640556393_24dps_entry, 3, 0};

V g_list_2emap_24f966602123x1640556393_24dps(V v_lit_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_strEq_c(heff_strSlice_lent(v_x_243, MK_INT(0LL), MK_INT(13LL), 6), ((V)&g_list_2emap_24f966602123x1640556393_24dps_str0))) {
      V v_t_246 = heff_strSlice(heff_dup(v_x_243), heff_dup(v_lit_240), heff_strLength(v_x_243));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_cell_247;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_lit_240;
      V t_1 = v_xs_244;
      V t_2 = v_d_242;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_list_2emap_24f966602123x1640556393_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_list_2emap_24f966602123x1640556393_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_list_2emap_24f1502491305x440718220_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f1502491305x440718220_24dps_entry, 3, 0};

V g_list_2emap_24f1502491305x440718220_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2emap_24s864521685x1610969087(v_ys_241));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2ehint(v_x_244));
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
    heff_drop(v_u_248);
    V t_0 = v_xs_245;
    V t_1 = v_ys_241;
    V t_2 = v_cell_247;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2emap_24f1502491305x440718220_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f1502491305x440718220_24dps(a[0], a[1], a[2]);
}
Clo g_list_2efoldl_24f700195413x1431112932_clo = {{0x80000000u, K_CLO, 0}, g_list_2efoldl_24f700195413x1431112932_entry, 3, 0};

V g_list_2efoldl_24f700195413x1431112932(V v_lit_240, V v_z_241, V v_x1_242) {
top: ;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    V v_xs_244 = heff_field(v_x1_242, 1);
    heff_take_n(v_x1_242, 3ULL, 2);
    V v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_243); r_; });
    V t_0 = heff_dup(v_lit_240);
    V t_1 = heff_intAdd(v_z_241, v_lit_240);
    V t_2 = v_t_245;
    v_lit_240 = t_0;
    v_z_241 = t_1;
    v_x1_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_242);
  }
}
V g_list_2efoldl_24f700195413x1431112932_entry(V self, V *a) {
  (void)self;
  return g_list_2efoldl_24f700195413x1431112932(a[0], a[1], a[2]);
}
Clo g_list_2emap_24f134831722x1788320834_clo = {{0x80000000u, K_CLO, 0}, g_list_2emap_24f134831722x1788320834_entry, 3, 0};

V g_list_2emap_24f134831722x1788320834(V v_lit_240, V v_p_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_240);
    heff_drop(v_p_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_p_241), 1, (V[]){heff_dup(v_x_243)}));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_strAppend(heff_dup(v_lit_240), heff_get_n(v_x_243, 0, 8));
      V v_cell_247 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
      V v_u_248 = (g_list_2emap_24f134831722x1788320834_24dps(v_lit_240, v_p_241, v_xs_244, heff_dup(v_cell_247)));
      heff_drop(v_u_248);
      return v_cell_247;
    } else {
      heff_drop_rec(v_x_243, 8);
      heff_drop_cell(v_ru_24x2_242_24Cons, 2);
      heff_drop(v_t_245);
      V t_0 = v_lit_240;
      V t_1 = v_p_241;
      V t_2 = v_xs_244;
      v_lit_240 = t_0;
      v_p_241 = t_1;
      v_x2_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_list_2emap_24f134831722x1788320834_entry(V self, V *a) {
  (void)self;
  return g_list_2emap_24f134831722x1788320834(a[0], a[1], a[2]);
}
Clo g_list_2efilter_24f75237897x367824150_24dps_clo = {{0x80000000u, K_CLO, 0}, g_list_2efilter_24f75237897x367824150_24dps_entry, 3, 0};

V g_list_2efilter_24f75237897x367824150_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_t_243 = (g_list_2efilter_24s1623010005x1805617852(v_ys_241));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_240, 0);
    V v_xs_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246 = heff_dup(heff_rfield(v_x_244, 2));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_245;
      V t_1 = v_ys_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    } else {
      heff_drop_rec(v_x_244, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      heff_drop(v_t_246);
      V t_0 = v_xs_245;
      V t_1 = v_ys_241;
      V t_2 = v_d_242;
      v_x1_240 = t_0;
      v_ys_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_list_2efilter_24f75237897x367824150_24dps_entry(V self, V *a) {
  (void)self;
  return g_list_2efilter_24f75237897x367824150_24dps(a[0], a[1], a[2]);
}