// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Right 62770
#define TAG_WriteErr 37283
#define LBL_errors 652506774
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok2_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(V v_o_240, V v_hd_241, V v_outPath_242, V v_k_243, V v_bad_244, V v_x_245) {
top: ;
  switch (heff_tag_of(v_x_245)) {
  case TAG_Left: {
    V v_ru_24x_245_24Left = heff_take_reuse_n(v_x_245, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(v_ru_24x_245_24Left, heff_get_n(v_o_240, 1, 2), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam0, 1, 3, (V[]){v_outPath_242, v_hd_241, v_k_243})));
  }
  case TAG_Right: {
    V v_ru_24x_245_24Right = heff_take_reuse_n(v_x_245, 0ULL, 1);
    heff_drop(v_outPath_242);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1061819055x1895126974_24tok1(v_ru_24x_245_24Right, heff_dup(heff_rfield(v_o_240, 1)), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam2, 1, 4, (V[]){heff_dup(v_bad_244), v_o_240, v_k_243, v_hd_241})));
  }
  default: return heff_nomatch(v_x_245);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_hd_241, v_k_243));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_outPath_242 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_drop(v_x_247);
  heff_clo_take(self, 3);
  V v_t_248 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_str0), v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_str1));
  V v_t_249 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_248, NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s297957795x1045074450(heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam1, 1, 2, (V[]){v_hd_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_bad_244 = heff_env(self)[0];
  V v_o_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  heff_drop(v_x_2423);
  if (!(heff_dup(v_bad_244) == NTAG(TAG_True))) {
    heff_clo_take(self, 4);
    heff_drop(v_bad_244);
    V v_t_2424 = heff_get_n(v_o_240, 1, 2);
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nil: {
      heff_drop(v_hd_241);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_ru_24t_2424_24Cons = heff_take_reuse_n(v_t_2424, 0ULL, 2);
      V v_t_2427 = heff_tag_at_n(v_ru_24t_2424_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_241, v_k_243));
    }
    default: return heff_nomatch(v_t_2424);
    }
  } else {
    heff_clo_take(self, 4);
    heff_drop(v_bad_244);
    heff_drop_rec(v_o_240, 2);
    V v_t_2433 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), v_hd_241, v_k_243));
  }
}