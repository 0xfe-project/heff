// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Anonymous 24551
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSmallTyp 41275
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_VCons 11629
#define TAG_VOpaque 37311
#define LBL_aliases 1464806715
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_defaults 1389419502
#define LBL_dflt 9576017
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_fields 672433636
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_large 304101205
#define LBL_len 316559
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_sol 323594
#define LBL_solStx 1050338738
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_level__fields__defaults__large[] = {LBL_level, LBL_fields, LBL_defaults, LBL_large};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_ty__sol__solStx__arity__name__span[] = {LBL_ty, LBL_sol, LBL_solStx, LBL_arity, LBL_name, LBL_span};
V g_array_2eempty_get(void);
V g_co_2eplus_24s645371449x668519272_get(void);
V g_heff_2eelab_2eenvironment_2ebindName(V, V, V);
V g_heff_2eelab_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindName_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2efixed_2etwoTo(V);
V g_heff_2eelab_2efixed_2etwoTo_entry(V self, V *a);
extern Clo g_heff_2eelab_2efixed_2etwoTo_clo;
V g_heff_2eelab_2ememoed_2eapp(V, V);
V g_heff_2eelab_2ememoed_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eapp_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2eprimFloat_get(void);
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(V, V, V);
V g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eadvanceSelf(V, V, V, V);
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eadvanceSelf_clo;
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eandList_24acc(V, V);
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_24acc_clo;
V g_heff_2eelab_2erules_2eanyP(V, V);
V g_heff_2eelab_2erules_2eanyP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eanyP_clo;
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2erules_2eatFloat32(V, V, V);
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eatFloat32_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V, V);
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2edefaultAt(V, V, V, V);
V g_heff_2eelab_2erules_2edefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultAt_clo;
V g_heff_2eelab_2erules_2edelayChkOn(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkOn_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edownFrom(V);
V g_heff_2eelab_2erules_2edownFrom_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
V g_heff_2eelab_2erules_2eentriesGo_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo;
V g_heff_2eelab_2erules_2eeqBareStr(V, V, V, V);
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeqBareStr_clo;
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2erules_2efillHole(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efillHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efillHole_clo;
V g_heff_2eelab_2erules_2eformGo(V, V, V);
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eformGo_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultAt(V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2ekeepRecovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2ekeepRecovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ekeepRecovered_clo;
V g_heff_2eelab_2erules_2elargeField(V, V, V, V);
V g_heff_2eelab_2erules_2elargeField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elargeField_clo;
V g_heff_2eelab_2erules_2elookupP(V, V);
V g_heff_2eelab_2erules_2elookupP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elookupP_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(V, V);
V g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135_clo;
V g_heff_2eelab_2erules_2enamesFor(V);
V g_heff_2eelab_2erules_2enamesFor_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamesFor_clo;
V g_heff_2eelab_2erules_2enestedField(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enestedField_clo;
V g_heff_2eelab_2erules_2eprimFloat_get(void);
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordNameOf(V, V, V, V);
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordNameOf_clo;
V g_heff_2eelab_2erules_2erecordTagIn(V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTagIn_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
V g_heff_2eelab_2erules_2erecoverWith(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecoverWith_clo;
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get(void);
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2elocalsAt(V, V);
V g_heff_2eelab_2evalue_2elocalsAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elocalsAt_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_map_2einsert_24s1689409319x1710080871(V, V, V);
V g_map_2einsert_24s1689409319x1710080871_entry(V self, V *a);
extern Clo g_map_2einsert_24s1689409319x1710080871_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s567992785x1569911877(V, V);
V g_map_2elookup_24s567992785x1569911877_entry(V self, V *a);
extern Clo g_map_2elookup_24s567992785x1569911877_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam0(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry, 2, 0};

V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V v_d_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    return heff_intLe(v_d_240, heff_dup(v_i_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SCode: {
    V v_a_244 = heff_field(v_t_241, 0);
    HEFF_LAST return g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(v_d_240, v_a_244);
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_t_241, 0);
    V v_a_246 = heff_field(v_t_241, 1);
    V v_t_247 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_240), v_f_245));
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_d_240);
      heff_drop(v_t_247);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_247);
      V t_0 = v_d_240;
      V t_1 = v_a_246;
      v_d_240 = t_0;
      v_t_241 = t_1;
      goto top;
    }
  }
  case TAG_SLam: {
    V v_dd_248 = heff_field(v_t_241, 0);
    V v_t2_249 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_t2_249)) {
    case TAG_MkAbs: {
      V v_b_2411 = heff_field(v_t2_249, 1);
      V v_t_2412 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_248));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_d_240);
        heff_drop(v_t_2412);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2412);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2411;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_t2_249, 0);
      V v_t_2414 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_248));
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_d_240);
        heff_drop(v_t_2414);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2414);
        V t_0 = v_d_240;
        V t_1 = v_b_2413;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_t2_249);
    }
  }
  case TAG_SCons: {
    V v_dct_2415 = heff_field(v_t_241, 0);
    V v_t_2416 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2415, 0)));
    V v_t_2417 = heff_arrayToList(heff_dup(heff_rfield(v_dct_2415, 2)));
    V v_t_2418 = (g_heff_2eutil_2edict_2ezipKV(v_t_2416, v_t_2417));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam0, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2418); r_; });
  }
  case TAG_SProj: {
    V v_e_2422 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2422;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_STag: {
    V v_as_2425 = heff_field(v_t_241, 1);
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam1, 1, 1, (V[]){v_d_240}); V b_1 = heff_arrayToList(heff_dup(v_as_2425)); V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, b_1)); heff_drop(b_1); r_; });
  }
  case TAG_SMatch: {
    V v_e_2427 = heff_field(v_t_241, 0);
    V v_cs_2428 = heff_field(v_t_241, 1);
    V v_t_2429 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_240), v_e_2427));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_d_240);
      heff_drop(v_t_2429);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2429);
      V v_t_2430 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2428, 0)));
      V v_t_2431 = heff_arrayToList(heff_dup(heff_rfield(v_cs_2428, 2)));
      V v_t_2432 = (g_heff_2eutil_2edict_2ezipKV(v_t_2430, v_t_2431));
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam2, 1, 1, (V[]){v_d_240}); V a_1 = v_t_2432; V r_ = (g_heff_2eelab_2erules_2eanyP(a_0, a_1)); heff_drop(v_t_2432); r_; });
    }
  }
  case TAG_SSpecialize: {
    V v_e_2439 = heff_field(v_t_241, 0);
    V v_v_2441 = heff_field(v_t_241, 2);
    V v_t_2442 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(heff_dup(v_d_240), v_e_2439));
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_d_240);
      heff_drop(v_t_2442);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2442);
      V t_0 = v_d_240;
      V t_1 = v_v_2441;
      v_d_240 = t_0;
      v_t_241 = t_1;
      goto top;
    }
  }
  case TAG_SIs: {
    V v_e_2443 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2443;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SAbandon: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SRec: {
    V v_e_2444 = heff_field(v_t_241, 0);
    V t_0 = v_d_240;
    V t_1 = v_e_2444;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_dd_2445 = heff_field(v_t_241, 0);
    V v_t2_2446 = heff_field(v_t_241, 1);
    switch (heff_tag_of(v_t2_2446)) {
    case TAG_MkAbs: {
      V v_b_2448 = heff_field(v_t2_2446, 1);
      V v_t_2449 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_2445));
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_d_240);
        heff_drop(v_t_2449);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2449);
        V t_0 = heff_intAdd(v_d_240, MK_INT(1LL));
        V t_1 = v_b_2448;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    case TAG_AbsConst: {
      V v_b_2450 = heff_field(v_t2_2446, 0);
      V v_t_2451 = (g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(heff_dup(v_d_240), v_dd_2445));
      if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
        heff_drop(v_d_240);
        heff_drop(v_t_2451);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2451);
        V t_0 = v_d_240;
        V t_1 = v_b_2450;
        v_d_240 = t_0;
        v_t_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_t2_2446);
    }
  }
  case TAG_SImplicit: {
    V v_e_2453 = heff_field(v_t_241, 1);
    V t_0 = v_d_240;
    V t_1 = v_e_2453;
    v_d_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SMetaApp: {
    V v_ty_2457 = heff_field(v_t_241, 2);
    HEFF_LAST return g_heff_2eelab_2erules_2ementionsTypeF_24s1532608485x1727564135(v_d_240, v_ty_2457);
  }
  case TAG_SLitInt: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitString: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitBytes: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitRune: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFixed: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  case TAG_SLitFloat32: {
    heff_drop(v_d_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam0(V self, V *args) {
  V v_x3_2419 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2419)) {
  case TAG_MkPair: {
    V v_v_2421 = heff_field(v_x3_2419, 1);
    heff_take_n(v_x3_2419, 2ULL, 2);
    return ({ V a_0 = v_d_240; V a_1 = v_v_2421; V r_ = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a_0, a_1)); heff_drop(v_v_2421); r_; });
  }
  default: return heff_nomatch(v_x3_2419);
  }
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam1(V self, V *args) {
  V v_t_2426 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_d_240; V a_1 = v_t_2426; V r_ = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a_0, a_1)); heff_drop(v_t_2426); r_; });
}
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_lam2(V self, V *args) {
  V v_x3_2433 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_MkPair: {
    V v_x32_2435 = heff_field(v_x3_2433, 1);
    heff_take_n(v_x3_2433, 2ULL, 2);
    switch (heff_tag_of(v_x32_2435)) {
    case TAG_MkPair: {
      V v_xs_2436 = heff_field(v_x32_2435, 0);
      V v_b_2437 = heff_field(v_x32_2435, 1);
      heff_take_n(v_x32_2435, 3ULL, 2);
      V v_t_2438 = heff_intAdd(v_d_240, heff_arrayLength(v_xs_2436));
      return ({ V a_0 = v_t_2438; V a_1 = v_b_2437; V r_ = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(a_0, a_1)); heff_drop(v_b_2437); r_; });
    }
    default: return heff_nomatch(v_x32_2435);
    }
  }
  default: return heff_nomatch(v_x3_2433);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str0, 4, "meta");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str1, 4, ") : ");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2efreshMeta_str3, 1, "\?");
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam0, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2efreshMeta_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_lam5, 1, 0};
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2efreshMeta_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efreshMeta_entry, 7, 0};

V g_heff_2eelab_2erules_2efreshMeta(V v_len_240, V v_locals_241, V v_ty_242, V v_name_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam0_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam1, 1, 7, (V[]){v_ty_242, v_len_240, v_name_243, v_sp_244, v_hd_245, heff_dup(v_locals_241), v_k_246})});
}
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2efreshMeta(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2efreshMeta_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 4, 8);
}
V g_heff_2eelab_2erules_2efreshMeta_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_rec_n(6, shape_ty__sol__solStx__arity__name__span, (V[]){v_ty_242, NTAG(TAG_Nothing), NTAG(TAG_Nothing), v_len_240, v_name_243, v_sp_244});
  V v_mc_2414 = (g_map_2einsert_24s1689409319x1710080871(heff_dup(v_x_2411), v_t_2413, heff_take_field(v_c_2412, 3)));
  return ({ V rv_3 = v_mc_2414; V rv_4 = heff_intAdd(v_x_2411, MK_INT(1LL)); V rr_ = heff_rec_reuse_nf(v_c_2412, 231ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 64575u, 0u); heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2eelab_2erules_2efreshMeta_lam5(V self, V *args) {
  V v_c_2423 = args[0];
  return heff_get_n(v_c_2423, 3, 8);
}
V g_heff_2eelab_2erules_2efreshMeta_lam7(V self, V *args) {
  V v_u_2428 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_name_243 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_u_2428);
  V v_xs_2429 = (g_heff_2eelab_2erules_2enamesFor(heff_dup(v_len_240)));
  V v_t_2430 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_len_240, v_ty_242));
  V v_t_2431 = ({ V a_0 = v_x_2427; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2427); r_; });
  V v_t_2432 = heff_tr(heff_call(heff_get_n(v_t_2431, 1, 2), 1, (V[]){v_t_2430}));
  V v_t_2433 = ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_2429; V a_3 = v_t_2432; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2432); r_; });
  V v_t_2434 = heff_strAppend(v_name_243, heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str1), v_t_2433));
  V v_t_2435 = heff_strAppend(heff_intShow(v_x_2411), heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str2), v_t_2434));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2efreshMeta_str3), v_t_2435);
}
V g_heff_2eelab_2erules_2efreshMeta_lam9(V self, V *args) {
  V v_sp_27_2443 = args[0];
  V v_i_2444 = args[1];
  V v_locals_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = ({ V a_0 = v_locals_241; V a_1 = v_i_2444; V r_ = heff_tr(g_heff_2eelab_2evalue_2elocalsAt(a_0, a_1)); heff_drop(v_locals_241); r_; });
  return heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_27_2443, v_t_2445});
}
V g_heff_2eelab_2erules_2efreshMeta_lam10(V self, V *args) {
  V v_u_2447 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2447);
  return v_ty_242;
}
V g_heff_2eelab_2erules_2efreshMeta_lam8(V self, V *args) {
  V v_x_2438 = args[0];
  V v_len_240 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_locals_241 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2438);
  V v_t_2439 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(heff_dup(v_len_240), MK_INT(1LL))));
  V v_t_2440 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_dup(v_len_240), heff_dup(v_ty_242)));
  V v_t_2441 = heff_tag_n(TAG_SMetaApp, 3, (V[]){heff_dup(v_x_2411), heff_arrayFromList(v_t_2439), v_t_2440});
  V v_t_2442 = (g_heff_2eelab_2erules_2edownFrom(heff_intSub(v_len_240, MK_INT(1LL))));
  V v_sp_2446 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam9, 2, 1, (V[]){v_locals_241}); V a_1 = NTAG(TAG_SpId); V a_2 = v_t_2442; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2442); r_; });
  V v_t_2448 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HMeta, 1, (V[]){v_x_2411}), v_sp_2446, heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam10, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_x_2449 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2441, v_t_2448});
  V f_ = v_k_246;
  args[0] = v_x_2449;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efreshMeta_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_name_243 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2436 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_244, ((V)&g_heff_2eelab_2erules_2efreshMeta_str0), heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam7, 1, 5, (V[]){heff_dup(v_len_240), heff_dup(v_ty_242), v_x_2427, v_name_243, heff_dup(v_x_2411)})}), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  V f_ = heff_get_n(v_hd_245, 1, 3);
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam8, 1, 5, (V[]){v_len_240, v_ty_242, v_x_2411, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2422);
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efreshMeta_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2425}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2426;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam6, 1, 8, (V[]){v_sp_244, v_len_240, v_ty_242, v_name_243, v_x_2411, v_hd_245, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  V v_name_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_locals_241 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2419 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2421;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam4, 1, 8, (V[]){v_hd_245, v_sp_244, v_len_240, v_ty_242, v_name_243, v_x_2411, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efreshMeta_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_ty_242 = heff_env(self)[0];
  V v_len_240 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_sp_244 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_locals_241 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam2, 1, 5, (V[]){heff_dup(v_ty_242), heff_dup(v_len_240), heff_dup(v_name_243), heff_dup(v_sp_244), heff_dup(v_x_2411)})})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2416}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2417;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efreshMeta_lam3, 1, 8, (V[]){v_hd_245, v_sp_244, v_len_240, v_ty_242, v_name_243, v_x_2411, v_locals_241, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str0, 5, "solve");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str1, 5, ") := ");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str2, 2, " (");
HEFF_LIT(g_heff_2eelab_2erules_2esolveHole_str3, 1, "\?");
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam0, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2esolveHole_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_lam3, 1, 0};
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2esolveHole_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esolveHole_entry, 8, 0};

V g_heff_2eelab_2erules_2esolveHole(V v_g_240, V v_cs_241, V v_m_242, V v_holeVal_243, V v_argStx_244, V v_argVal_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2411, heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam1, 1, 8, (V[]){v_m_242, v_g_240, v_cs_241, v_holeVal_243, v_argVal_245, v_hd_246, v_k_247, v_argStx_244})});
}
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esolveHole(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2erules_2esolveHole_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2erules_2esolveHole_lam3(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get_n(v_c_2418, 3, 8);
}
V g_heff_2eelab_2erules_2esolveHole_lam5(V self, V *args) {
  V v_u_2423 = args[0];
  V v_e_2415 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2423);
  V v_t_2424 = (g_heff_2eelab_2eunify_2elamsU(heff_take_field(v_e_2415, 3), v_argStx_244));
  V v_t_2425 = ({ V a_0 = v_x_2422; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_2422); r_; });
  V v_e_2426 = heff_tr(heff_call(heff_get_n(v_t_2425, 0, 2), 1, (V[]){v_t_2424}));
  V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil), v_e_2426));
  V v_t_2428 = heff_strAppend(heff_get_n(v_e_2415, 4, 6), heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str1), v_t_2427));
  V v_t_2429 = heff_strAppend(heff_intShow(v_m_242), heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str2), v_t_2428));
  return heff_strAppend(((V)&g_heff_2eelab_2erules_2esolveHole_str3), v_t_2429);
}
V g_heff_2eelab_2erules_2esolveHole_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  V f_ = v_k_247;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esolveHole_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_2415 = heff_env(self)[0];
  V v_argStx_244 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2430 = heff_rec_n(3, shape_span__kind__text, (V[]){heff_dup(heff_rfield(v_e_2415, 5)), ((V)&g_heff_2eelab_2erules_2esolveHole_str0), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam5, 1, 4, (V[]){v_e_2415, v_argStx_244, v_x_2422, v_m_242})});
  V v_t_2431 = heff_tag_n(TAG_Trace, 2, (V[]){v_t_2430, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2432;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam6, 1, 1, (V[]){v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esolveHole_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_e_2415 = heff_env(self)[1];
  V v_argStx_244 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2esolveHole_lam3_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2420}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2421;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam4, 1, 5, (V[]){v_e_2415, v_argStx_244, v_m_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esolveHole_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_holeVal_243 = heff_env(self)[3];
  V v_argVal_245 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_argStx_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = ({ V a_0 = heff_dup(v_m_242); V a_1 = v_x_2412; V r_ = (g_map_2elookup_24s567992785x1569911877(a_0, a_1)); heff_drop(v_x_2412); r_; });
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    heff_drop(v_m_242);
    heff_drop(v_argStx_244);
    V v_t_2414 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
    return (g_heff_2eelab_2emeta_2eliftU(v_t_2414, v_hd_246, v_k_247));
  }
  case TAG_Just: {
    V v_e_2415 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    V v_t_2416 = heff_dup(heff_rfield(v_e_2415, 1));
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop(v_cs_241);
      heff_drop(v_holeVal_243);
      heff_drop(v_argVal_245);
      return (g_heff_2eelab_2erules_2efillHole(v_g_240, heff_dup(v_m_242), heff_dup(v_e_2415), heff_dup(v_argStx_244), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2esolveHole_lam2, 1, 5, (V[]){v_hd_246, v_e_2415, v_argStx_244, v_m_242, v_k_247})));
    }
    case TAG_Just: {
      heff_take_n(v_t_2416, 0ULL, 1);
      heff_drop(v_m_242);
      heff_drop(v_argStx_244);
      heff_drop_rec(v_e_2415, 6);
      V v_t_2436 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s645371449x668519272_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s1083296175x849233889_get()), v_g_240, v_cs_241, v_holeVal_243, v_argVal_245));
      return (g_heff_2eelab_2emeta_2eliftU(v_t_2436, v_hd_246, v_k_247));
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2eeqBareStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeqBareStr_entry, 4, 0};

V g_heff_2eelab_2erules_2eeqBareStr(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243) {
top: ;
  V v_e_244 = (g_heff_2eelab_2ereadback_2ereadbBare_24s1683437041x888012172(heff_take_field(v_cs_241, 0), v_h_242, v_sp_243));
  V v_t_2410 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2eeqBareStr_lam0, 1, 1, (V[]){v_g_240})));
  V v_e_2411 = heff_tr(heff_call(heff_get_n(v_t_2410, 0, 2), 1, (V[]){v_e_244}));
  HEFF_LAST return g_heff_2esyntax_2esurfaceprint_2eelF_24s1146193008x96932138(MK_INT(0LL), MK_INT(0LL), heff_get_n(v_cs_241, 1, 2), v_e_2411);
}
V g_heff_2eelab_2erules_2eeqBareStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeqBareStr(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eeqBareStr_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_246 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_245)));
  V v_t_247 = ({ V b_0 = heff_get_n(v_g_240, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x2_248 = ({ V a_0 = v_t_247; V a_1 = v_x_245; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    return v_d_246;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    heff_drop(v_d_246);
    return v_x_249;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2eelab_2erules_2erecoverWith_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecoverWith_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2erecoverWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecoverWith_entry, 7, 0};

V g_heff_2eelab_2erules_2erecoverWith(V v_e_240, V v_a_241, V v_d_242, V v_saved_243, V v_waiting_244, V v_hd_245, V v_k_246) {
top: ;
  return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_a_241), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam0, 1, 6, (V[]){v_d_242, v_saved_243, v_waiting_244, v_hd_245, v_a_241, v_k_246})));
}
V g_heff_2eelab_2erules_2erecoverWith_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erecoverWith(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2erecoverWith_lam3(V self, V *args) {
  V v_u_2411 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2411);
  return v_a_241;
}
V g_heff_2eelab_2erules_2erecoverWith_lam2(V self, V *args) {
  V v_u_2410 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  V v_t_2412 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(NTAG(TAG_HError), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam3, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2412});
}
V g_heff_2eelab_2erules_2erecoverWith_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_a_241 = heff_env(self)[0];
  V v_k_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_249);
  V v_t_2413 = heff_rec_n(2, shape_stx__val, (V[]){NTAG(TAG_SAbandon), heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam2, 1, 1, (V[]){v_a_241})});
  V f_ = v_k_246;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecoverWith_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_saved_243 = heff_env(self)[1];
  V v_waiting_244 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248;
  if ((heff_dup(v_x_247) == NTAG(TAG_True))) {
    heff_drop(v_x_247);
    v_t_248 = ({ V rv_0 = MK_INT(-1LL); V rr_ = heff_rec_reuse_nf(v_d_242, 30ULL, 5, shape_code__severity__msg__span__note, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  } else {
    heff_drop(v_x_247);
    v_t_248 = v_d_242;
  }
  return (g_heff_2eelab_2erules_2ekeepRecovered(v_t_248, v_saved_243, v_waiting_244, v_hd_245, heff_clo_n(g_heff_2eelab_2erules_2erecoverWith_lam1, 1, 2, (V[]){v_a_241, v_k_246})));
}
Clo g_heff_2eelab_2erules_2ecatMaybesR_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2ecatMaybesR_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2ecatMaybesR_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2ecatMaybesR_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str3, 1, "_");
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertImplicits_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertImplicits(V v_e_240, V v_sp_241, V v_m_242, V v_ty0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam0, 1, 1, (V[]){v_ty0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam1, 1, 5, (V[]){v_k_245, v_m_242, v_e_240, v_sp_241, v_hd_244})});
}
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertImplicits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ty0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_ty0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_call(heff_get_n(v_x_2423, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2424 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2428 = v_n_2424;
    break;
  }
  case TAG_CloConst: {
    v_t_2428 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2428, v_m_242, heff_dup(v_x_2423)));
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2415, 1);
    V v_body_2432 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_call(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam3, 1, 1, (V[]){v_x_2423})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2423, 2);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2429, v_t_2443, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args) {
  V v_u_2459 = args[0];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  V v_x1_2460 = heff_tr(heff_call(heff_get_n(v_x_2449, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2461;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2463;
  }
  default: return heff_nomatch(v_x1_2460);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args) {
  V v_x_2449 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2454;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2450 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2454 = v_n_2450;
    break;
  }
  case TAG_CloConst: {
    v_t_2454 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str3);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2455 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2454, v_m_242, heff_dup(v_x_2449)));
  V v_x1_2465;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2457 = heff_field(v_cod_2415, 1);
    V v_body_2458 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2465 = heff_tr(heff_call(v_body_2458, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2457, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam5, 1, 1, (V[]){v_x_2449})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2464 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2449, 2);
    v_x1_2465 = v_body_2464;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2469;
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_Nom: {
    V v_x_2466 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_t_2469 = v_x_2466;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2465, 0ULL, 1);
    v_t_2469 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2468 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_t_2469 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x1_2465);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2455, v_t_2469, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_it_2411)) {
  case TAG_LikeU: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_it_2411, 1);
    V v_cod_2415 = heff_field(v_it_2411, 2);
    V v_it4_2416 = heff_field(v_it_2411, 3);
    heff_take_n(v_it_2411, 14ULL, 4);
    switch (heff_tag_of(v_it4_2416)) {
    case TAG_Expl: {
      heff_drop(v_e_240);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_244, 3);
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Impl: {
      V v_t_2421;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2417 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2421 = v_n_2417;
        break;
      }
      case TAG_CloConst: {
        v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2422 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_x_2410, v_dom_2414, v_t_2421));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam2, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Inst: {
      heff_drop(v_x_2410);
      V v_t_2448;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2444 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2448 = v_n_2444;
        break;
      }
      case TAG_CloConst: {
        v_t_2448 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str2);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_240), heff_dup(v_sp_241), v_dom_2414, v_t_2448, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam4, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245})));
    }
    default: return heff_nomatch(v_it4_2416);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_it_2411, 0ULL, 3);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeSum: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_it_2411);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionFormation_str0, 137, "an implicit argument without a default must have a large type (a small one could never be inferred: its values are statically irrelevant)");
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionFormation_entry, 2, 0};

V g_heff_2eelab_2erules_2efunctionFormation(V v_x1_240, V v_cod_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Anonymous: {
    V v_dom_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Anonymous = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24Anonymous, TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam0, 1, 2, (V[]){v_dom_242, heff_dup(v_cod_241)})});
  }
  case TAG_Named: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    V v_dom_2415 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam4, 1, 3, (V[]){v_dom_2415, v_x_2414, heff_dup(v_cod_241)})});
  }
  case TAG_NamedImplicit: {
    V v_sp_2434 = heff_field(v_x1_240, 0);
    V v_x_2435 = heff_field(v_x1_240, 1);
    V v_dom_2436 = heff_field(v_x1_240, 2);
    V v_dflt_2437 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam8, 1, 5, (V[]){v_dom_2436, v_dflt_2437, v_sp_2434, v_x_2435, heff_dup(v_cod_241)})});
  }
  case TAG_NamedInstance: {
    V v_x_2470 = heff_field(v_x1_240, 1);
    V v_dom_2471 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam13, 1, 3, (V[]){v_dom_2471, v_x_2470, heff_dup(v_cod_241)})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2efunctionFormation(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_x_2413 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_243, 1, 6), v_t_2412, v_x_248, heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2411})));
  V f_ = v_k_247;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_cod_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_249 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2410 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2410;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam3, 1, 3, (V[]){v_e_243, v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam2, 1, 4, (V[]){v_cod_241, v_e_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_242 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_242, 0);
    heff_take_n(v_dom_242, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam1, 2, 3, (V[]){v_c_245, v_cod_241, v_e_243});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_2416, 0)), 2, 4);
  V v_x_2433 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_2416, 1, 6), v_t_2432, v_x_2421, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2414, v_x_2431})));
  V f_ = v_k_2420;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2421, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_sc_2427 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2414), v_t_2426, heff_dup(heff_rfield(v_e_2416, 0))));
  V v_c_2430;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2428 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2429 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2427, heff_dup(heff_rfield(v_e_2416, 1)), heff_dup(heff_rfield(v_e_2416, 2)), heff_dup(heff_rfield(v_e_2416, 3)), heff_dup(heff_rfield(v_e_2416, 4)), heff_dup(heff_rfield(v_e_2416, 5))});
    v_c_2430 = heff_tr(heff_call(v_f_2428, 1, (V[]){v_t_2429}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2430;
  heff_room[0] = v_hd_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam7, 1, 4, (V[]){v_e_2416, v_x_2421, v_x_2414, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_e_2416 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam6, 1, 5, (V[]){v_x_2414, v_e_2416, v_cod_241, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args) {
  V v_e_2416 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2418;
  switch (heff_tag_of(v_dom_2415)) {
  case TAG_MkTyp: {
    V v_f_2417 = heff_field(v_dom_2415, 0);
    heff_take_n(v_dom_2415, 1ULL, 1);
    v_c_2418 = heff_tr(heff_call(v_f_2417, 1, (V[]){heff_dup(v_e_2416)}));
    break;
  }
  default: heff_nomatch(v_dom_2415);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam5, 2, 4, (V[]){v_c_2418, v_x_2414, v_e_2416, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_2438 = heff_env(self)[0];
  V v_x_2456 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_k_2442 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_e_2438, 0)), 2, 4);
  V v_x_2468 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Impl), v_x_2456, heff_get_n(v_e_2438, 1, 6), v_t_2467, v_x_2443, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2435, v_x_2466})));
  V f_ = v_k_2442;
  args[0] = v_x_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_e_2438 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  V v_hd_2441 = heff_env(self)[4];
  V v_k_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2443, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2461;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_t_2461 = v_x_2458;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    v_t_2461 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_t_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_sc_2462 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2435), v_t_2461, heff_dup(heff_rfield(v_e_2438, 0))));
  V v_c_2465;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2463 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2464 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2462, heff_dup(heff_rfield(v_e_2438, 1)), heff_dup(heff_rfield(v_e_2438, 2)), heff_dup(heff_rfield(v_e_2438, 3)), heff_dup(heff_rfield(v_e_2438, 4)), heff_dup(heff_rfield(v_e_2438, 5))});
    v_c_2465 = heff_tr(heff_call(v_f_2463, 1, (V[]){v_t_2464}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2465;
  heff_room[0] = v_hd_2441;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam12, 1, 5, (V[]){v_e_2438, v_x_2456, v_x_2443, v_x_2435, v_k_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_dflt_2437 = heff_env(self)[0];
  V v_sp_2434 = heff_env(self)[1];
  V v_hd_2441 = heff_env(self)[2];
  V v_k_2442 = heff_env(self)[3];
  V v_e_2438 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  V v_cod_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2443, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2448;
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_t_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2446 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2446); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2447; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2444);
  }
  V v_t_2450;
  switch (heff_tag_of(v_x1_2448)) {
  case TAG_Small: {
    switch (heff_tag_of(v_dflt_2437)) {
    case TAG_Nothing: {
      v_t_2450 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_dflt_2437);
    }
    break;
  }
  case TAG_Large: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2448);
  }
  if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2443, 2);
    heff_drop(v_dflt_2437);
    heff_drop_rec(v_e_2438, 6);
    heff_drop(v_x_2435);
    heff_drop(v_cod_241);
    heff_drop(v_t_2450);
    V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(324LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionFormation_str0), v_sp_2434, NTAG(TAG_Nothing)});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_2441, 2), 1, (V[]){v_t_2453}));
    V f_ = heff_get_n(v_hd_2441, 1, 3);
    heff_room[0] = v_t_2454;
    heff_room[1] = v_k_2442;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_2434);
    heff_drop(v_t_2450);
    V v_c_2455 = (g_heff_2eelab_2erules_2eimplicitDefaultAt(heff_dup(v_e_2438), heff_dup(v_x_2443), v_dflt_2437));
    V f_ = v_c_2455;
    heff_room[0] = heff_dup(v_hd_2441);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam11, 1, 6, (V[]){v_x_2443, v_x_2435, v_e_2438, v_cod_241, v_hd_2441, v_k_2442});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_dflt_2437 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_e_2438 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_cod_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam10, 1, 7, (V[]){v_dflt_2437, v_sp_2434, v_hd_2441, v_k_2442, v_e_2438, v_x_2435, v_cod_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args) {
  V v_e_2438 = args[0];
  V v_dom_2436 = heff_env(self)[0];
  V v_dflt_2437 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_cod_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2440;
  switch (heff_tag_of(v_dom_2436)) {
  case TAG_MkTyp: {
    V v_f_2439 = heff_field(v_dom_2436, 0);
    heff_take_n(v_dom_2436, 1ULL, 1);
    v_c_2440 = heff_tr(heff_call(v_f_2439, 1, (V[]){heff_dup(v_e_2438)}));
    break;
  }
  default: heff_nomatch(v_dom_2436);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam9, 2, 6, (V[]){v_c_2440, v_dflt_2437, v_sp_2434, v_e_2438, v_x_2435, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args) {
  V v_x_2487 = args[0];
  V v_e_2472 = heff_env(self)[0];
  V v_x_2477 = heff_env(self)[1];
  V v_x_2470 = heff_env(self)[2];
  V v_k_2476 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2488 = heff_get_n(heff_dup(heff_rfield(v_e_2472, 0)), 2, 4);
  V v_x_2489 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Inst), NTAG(TAG_Nothing), heff_get_n(v_e_2472, 1, 6), v_t_2488, v_x_2477, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2470, v_x_2487})));
  V f_ = v_k_2476;
  args[0] = v_x_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args) {
  V v_x_2477 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_e_2472 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2475 = heff_env(self)[3];
  V v_k_2476 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2477, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2482;
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_Nom: {
    V v_x_2479 = heff_field(v_x1_2478, 0);
    heff_take_n(v_x1_2478, 1ULL, 1);
    v_t_2482 = v_x_2479;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2482 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2481 = heff_field(v_x1_2478, 0);
    heff_take_n(v_x1_2478, 1ULL, 1);
    v_t_2482 = v_x_2481;
    break;
  }
  default: heff_nomatch(v_x1_2478);
  }
  V v_sc_2483 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2470), v_t_2482, heff_dup(heff_rfield(v_e_2472, 0))));
  V v_c_2486;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2484 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2485 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2483, heff_dup(heff_rfield(v_e_2472, 1)), heff_dup(heff_rfield(v_e_2472, 2)), heff_dup(heff_rfield(v_e_2472, 3)), heff_dup(heff_rfield(v_e_2472, 4)), heff_dup(heff_rfield(v_e_2472, 5))});
    v_c_2486 = heff_tr(heff_call(v_f_2484, 1, (V[]){v_t_2485}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2486;
  heff_room[0] = v_hd_2475;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam16, 1, 4, (V[]){v_e_2472, v_x_2477, v_x_2470, v_k_2476});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_c_2474 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  V v_e_2472 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2474;
  args[0] = heff_dup(v_hd_2475);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam15, 1, 5, (V[]){v_x_2470, v_e_2472, v_cod_241, v_hd_2475, v_k_2476});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args) {
  V v_e_2472 = args[0];
  V v_dom_2471 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2474;
  switch (heff_tag_of(v_dom_2471)) {
  case TAG_MkTyp: {
    V v_f_2473 = heff_field(v_dom_2471, 0);
    heff_take_n(v_dom_2471, 1ULL, 1);
    v_c_2474 = heff_tr(heff_call(v_f_2473, 1, (V[]){heff_dup(v_e_2472)}));
    break;
  }
  default: heff_nomatch(v_dom_2471);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam14, 2, 4, (V[]){v_c_2474, v_x_2470, v_e_2472, v_cod_241});
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayChkOn_str0, 5, "delay");
HEFF_LIT(g_heff_2eelab_2erules_2edelayChkOn_str1, 21, " waits for its type \?");
V g_heff_2eelab_2erules_2edelayChkOn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkOn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayChkOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayChkOn_entry, 8, 0};

V g_heff_2eelab_2erules_2edelayChkOn(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_keyTy_244, V v_ty_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 2, 4);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = heff_dup(v_ty_245); V a_3 = heff_dup(v_what_242); V a_4 = heff_dup(v_sp_241); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam0, 1, 8, (V[]){v_e_240, v_sp_241, v_what_242, heff_dup(v_c_243), v_ty_245, v_hd_246, v_keyTy_244, v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2edelayChkOn_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayChkOn(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayChkOn_lam2(V self, V *args) {
  V v_u_2454 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2454);
  V v_t_2455 = heff_get_n(v_x_2410, 0, 2);
  V v_t_2491;
  switch (heff_tag_of(v_t_2455)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2455, 0ULL, 3);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2480 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 3);
    v_t_2491 = v_k_2480;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2455, 0ULL, 2);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2455, 0ULL, 1);
    v_t_2491 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2455);
  }
  V v_t_2492 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayChkOn_str1), heff_intShow(v_t_2491));
  return heff_strAppend(v_what_242, v_t_2492);
}
V g_heff_2eelab_2erules_2edelayChkOn_lam4(V self, V *args) {
  V v_u_2496 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2496);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2edelayChkOn_lam3(V self, V *args) {
  V v_x_2495 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2495);
  V v_t_2497 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam4, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_nf(v_x_2410, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2497;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edelayChkOn_lam1(V self, V *args) {
  V v_x_2453 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2453);
  V v_t_2493 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2edelayChkOn_str0), heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam2, 1, 2, (V[]){heff_dup(v_x_2410), v_what_242})}), NTAG(TAG_MkUnit)});
  V v_t_2494 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2494;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam3, 1, 2, (V[]){v_x_2410, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2edelayChkOn_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_what_242 = heff_env(self)[2];
  V v_c_243 = heff_env(self)[3];
  V v_ty_245 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_keyTy_244 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = heff_dup(heff_rfield(v_x_2410, 0));
  V v_t_2447;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_SLocal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SGlobal: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SCode: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SApp: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLam: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SCons: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SProj: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_STag: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SMatch: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_2411, 0ULL, 3);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SIs: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SOpaque: {
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SAbandon: {
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SRec: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SFix: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SImplicit: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SMetaApp: {
    V v_k_2436 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 3);
    v_t_2447 = v_k_2436;
    break;
  }
  case TAG_SLitInt: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitString: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitRune: {
    heff_take_n(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_t_2411, 0ULL, 2);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_t_2411, 0ULL, 1);
    v_t_2447 = MK_INT(-1LL);
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_chk_2448 = ({ V a_0 = v_e_240; V a_1 = heff_dup(v_sp_241); V a_2 = heff_dup(v_what_242); V a_3 = v_c_243; V a_4 = v_ty_245; V a_5 = v_t_2447; V a_6 = heff_dup(v_x_2410); V r_ = (g_heff_2eelab_2erules_2edelayedCheck(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_243); r_; });
  V v_t_2449 = heff_tr(heff_call(v_chk_2448, 2, (V[]){heff_dup(v_hd_246), heff_dup(heff_rfield(v_hd_246, 0))}));
  V v_t_2450 = heff_tag_n(TAG_Delay, 3, (V[]){v_keyTy_244, v_t_2449, NTAG(TAG_MkUnit)});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2451}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2452;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayChkOn_lam1, 1, 5, (V[]){v_sp_241, v_x_2410, v_what_242, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eprimFloat_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eprimFloat_lam0, 3, 0};

static V g_heff_2eelab_2erules_2eprimFloat_val;
static HEFF_ONCE g_heff_2eelab_2erules_2eprimFloat_st;
static V g_heff_2eelab_2erules_2eprimFloat_init(void) {
  return heff_tag_n(TAG_MkTyp, 1, (V[]){((V)&g_heff_2eelab_2erules_2eprimFloat_lam0_clo)});
}
V g_heff_2eelab_2erules_2eprimFloat_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2erules_2eprimFloat_st)) return g_heff_2eelab_2erules_2eprimFloat_val;
  return heff_global(&g_heff_2eelab_2erules_2eprimFloat_val, &g_heff_2eelab_2erules_2eprimFloat_st, g_heff_2eelab_2erules_2eprimFloat_init);
}
V g_heff_2eelab_2erules_2eprimFloat_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_hd_241 = args[1];
  V v_k_242 = args[2];
  heff_drop(v_e_240);
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2eelab_2ememoed_2eprimFloat_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat32_str0, 70, " is out of range for Float32, whose greatest is 3.4028234663852886e+38");
HEFF_LIT(g_heff_2eelab_2erules_2eatFloat32_str1, 70, " is out of range for Float32, whose greatest is 3.4028234663852886e+38");
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eatFloat32_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2eatFloat32_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_lam3, 1, 0};
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2eatFloat32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eatFloat32_entry, 3, 0};

V g_heff_2eelab_2erules_2eatFloat32(V v_sp_240, V v_text_241, V v_x_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL)));
  V v_t_244 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL)));
  double v_y_245 = heff_from_int_f64(heff_intSub(v_t_243, v_t_244));
  if ((v_y_245 <= heff_peek_f64(v_x_242))) {
    heff_drop(v_x_242);
    return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam0, 2, 2, (V[]){v_text_241, v_sp_240});
  } else {
    V v_t_2413 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(103LL)));
    V v_t_2414 = (g_heff_2eelab_2efixed_2etwoTo(MK_INT(128LL)));
    double v_t_2415 = heff_from_int_f64(heff_intSub(v_t_2413, v_t_2414));
    if ((heff_peek_f64(v_x_242) <= v_t_2415)) {
      heff_drop(v_x_242);
      return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam1, 2, 2, (V[]){v_text_241, v_sp_240});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_text_241);
      return heff_clo_n(g_heff_2eelab_2erules_2eatFloat32_lam2, 2, 1, (V[]){v_x_242});
    }
  }
}
V g_heff_2eelab_2erules_2eatFloat32_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eatFloat32(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eatFloat32_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k2_248 = args[1];
  V v_text_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat32_str0)), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_247, 2), 1, (V[]){v_t_2411}));
  V f_ = heff_get_n(v_hd_247, 1, 3);
  args[0] = v_t_2412;
  args[1] = v_k2_248;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eatFloat32_lam1(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_text_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(346LL), NTAG(TAG_SError), heff_strAppend(v_text_241, ((V)&g_heff_2eelab_2erules_2eatFloat32_str1)), v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2421}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2422;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eatFloat32_lam3(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2eatFloat32_lam2(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2423);
  V v_t_2426 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_nf(TAG_SLitFloat32, 1, 1u, (V[]){heff_word_f64(heff_unbox_f64(v_x_242))}), ((V)&g_heff_2eelab_2erules_2eatFloat32_lam3_clo)});
  V f_ = v_k_2424;
  args[0] = v_t_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eformGo_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_lam0, 2, 0};
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eformGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eformGo_entry, 3, 0};

V g_heff_2eelab_2erules_2eformGo(V v_e_27_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_e_27_240, 6);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eelab_2erules_2eformGo_lam0_clo);
  }
  case TAG_Cons: {
    V v_fd_246 = heff_field(v_x3_242, 0);
    V v_rest_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_dup(heff_rfield(v_fd_246, 1));
    V v_c_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkTyp: {
      V v_f_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_c_2410 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_dup(v_e_27_240)}));
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam1, 2, 5, (V[]){v_c_2410, v_e_27_240, v_i_241, v_fd_246, v_rest_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eformGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eformGo(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2eformGo_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V v_t_245 = heff_rec_n(4, shape_level__fields__defaults__large, (V[]){NTAG(TAG_Small), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nothing)});
  V f_ = v_k_244;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_fd_246 = heff_env(self)[1];
  V v_x_2415 = heff_env(self)[2];
  V v_e_27_240 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_l1_2425 = heff_take_field(v_x_2424, 0);
  V v_x1_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2413, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_l2_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_t_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_l2_2430 = ({ V a_0 = v_t_2427; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2427); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2428 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_l2_2430 = ({ V a_0 = v_t_2428; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2428); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_l2_2430 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2429); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_t_2431;
  switch (heff_tag_of(v_l1_2425)) {
  case TAG_Small: {
    v_t_2431 = v_l2_2430;
    break;
  }
  case TAG_Large: {
    switch (heff_tag_of(v_l2_2430)) {
    case TAG_Small: {
      v_t_2431 = v_l1_2425;
      break;
    }
    case TAG_Large: {
      v_t_2431 = v_l2_2430;
      break;
    }
    case TAG_TopL: {
      v_t_2431 = v_l2_2430;
      break;
    }
    default: heff_nomatch(v_l2_2430);
    }
    break;
  }
  case TAG_TopL: {
    switch (heff_tag_of(v_l2_2430)) {
    case TAG_Small: {
      v_t_2431 = v_l1_2425;
      break;
    }
    case TAG_Large: {
      v_t_2431 = v_l1_2425;
      break;
    }
    case TAG_TopL: {
      v_t_2431 = v_l2_2430;
      break;
    }
    default: heff_nomatch(v_l2_2430);
    }
    break;
  }
  default: heff_nomatch(v_l1_2425);
  }
  V v_t_2432 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_fd_246, 0)), heff_dup(heff_rfield(v_x_2413, 0))});
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_take_field(v_x_2424, 1)});
  V v_ds_2434 = heff_take_field(v_x_2424, 2);
  V v_t_2437;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    v_t_2437 = v_ds_2434;
    break;
  }
  case TAG_Just: {
    V v_d_2435 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    V v_t_2436 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(heff_rfield(v_fd_246, 0)), v_d_2435});
    v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_ds_2434});
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_t_2438 = (g_heff_2eelab_2erules_2elargeField(v_e_27_240, heff_get_n(v_fd_246, 0, 3), v_x_2413, heff_get_n(v_x_2424, 3, 4)));
  V v_x_2439 = heff_rec_n(4, shape_level__fields__defaults__large, (V[]){v_t_2431, v_t_2433, v_t_2437, v_t_2438});
  V f_ = v_k_2412;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eformGo_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_fd_246 = heff_env(self)[1];
  V v_e_27_240 = heff_env(self)[2];
  V v_i_241 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2413, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2420;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_Nom: {
    V v_x_2417 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = v_x_2417;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2416, 0ULL, 1);
    v_t_2420 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2419 = heff_field(v_x1_2416, 0);
    heff_take_n(v_x1_2416, 1ULL, 1);
    v_t_2420 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_sc_2421 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(heff_rfield(v_fd_246, 0)), v_t_2420, heff_dup(heff_rfield(v_e_27_240, 0))));
  V v_t_2422 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2421, heff_dup(heff_rfield(v_e_27_240, 1)), heff_dup(heff_rfield(v_e_27_240, 2)), heff_dup(heff_rfield(v_e_27_240, 3)), heff_dup(heff_rfield(v_e_27_240, 4)), heff_dup(heff_rfield(v_e_27_240, 5))});
  V v_c_2423 = (g_heff_2eelab_2erules_2eformGo(v_t_2422, heff_intAdd(v_i_241, MK_INT(1LL)), v_rest_247));
  V f_ = v_c_2423;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam4, 1, 5, (V[]){v_x_2413, v_fd_246, v_x_2415, v_e_27_240, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_27_240 = heff_env(self)[0];
  V v_i_241 = heff_env(self)[1];
  V v_fd_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2414 = (g_heff_2eelab_2erules_2edefaultAt(heff_dup(v_e_27_240), heff_dup(v_i_241), heff_dup(v_x_2413), heff_dup(heff_rfield(v_fd_246, 2))));
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam3, 1, 7, (V[]){v_x_2413, v_fd_246, v_e_27_240, v_i_241, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eformGo_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_27_240 = heff_env(self)[1];
  V v_i_241 = heff_env(self)[2];
  V v_fd_246 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2eformGo_lam2, 1, 6, (V[]){v_e_27_240, v_i_241, v_fd_246, v_hd_2411, v_rest_247, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2eadvanceSelf_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2eadvanceSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eadvanceSelf_entry, 4, 0};

V g_heff_2eelab_2erules_2eadvanceSelf(V v_gk_240, V v_a_241, V v_fieldTypes_242, V v_done_243) {
top: ;
  V v_xs_244 = heff_dup(heff_rfield(v_fieldTypes_242, 0));
  V v_t_2411 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_244, 0), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam0, 1, 4, (V[]){v_xs_244, heff_dup(v_done_243), heff_dup(v_gk_240), heff_dup(v_a_241)}));
  V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_fieldTypes_242, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_VCons, 1, (V[]){v_t_2412})});
  HEFF_LAST return g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam2, 1, 1, (V[]){v_a_241}), v_t_2413);
}
V g_heff_2eelab_2erules_2eadvanceSelf_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2eadvanceSelf(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam1(V self, V *args) {
  V v_u_248 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_a_241;
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_xs_244 = heff_env(self)[0];
  V v_done_243 = heff_env(self)[1];
  V v_gk_240 = heff_env(self)[2];
  V v_a_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_f_246 = heff_arrayIndex(v_xs_244, v_i_245);
  V v_t_247 = ({ V a_0 = v_done_243; V a_1 = heff_dup(v_f_246); V r_ = (g_heff_2eelab_2erules_2elookupP(a_0, a_1)); heff_drop(v_done_243); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    V v_t_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_gk_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2eadvanceSelf_lam1, 1, 1, (V[]){v_a_241}), NTAG(TAG_Nothing)));
    return (g_heff_2eelab_2evalue_2eproj(v_t_249, v_f_246));
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    heff_drop(v_gk_240);
    heff_drop(v_a_241);
    heff_drop(v_f_246);
    return heff_tag_at_n(v_ru_24t_247_24Just, TAG_Nom, 1, (V[]){v_v_2410});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2erules_2eadvanceSelf_lam2(V self, V *args) {
  V v_u_2414 = args[0];
  V v_a_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2414);
  return v_a_241;
}
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_entry, 1, 0};

V g_heff_2eelab_2erules_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_y_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eandList_str1), heff_dup(v_y_243)));
      }
      case TAG_Cons: {
        V v_s_247 = heff_dup(v_x_241);
        V v_s_248 = heff_strAppend(v_s_247, ((V)&g_heff_2eelab_2erules_2eandList_str2));
        return (g_heff_2eelab_2erules_2eandList_24acc(v_x12_242, v_s_248));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eandList(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eentriesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eentriesGo(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_246, 5);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_pl_248 = heff_field(v_x5_244, 0);
      V v_pls_249 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_pl_248)) {
      case TAG_Nothing: {
        v_t_2412 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_246), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_pl_248, 0);
        V v_ru_24pl_248_24Just = heff_take_reuse_n(v_pl_248, 1ULL, 1);
        V v_t_2411 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2410);
        v_t_2412 = heff_tag_at_n(v_ru_24pl_248_24Just, TAG_SLocal, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_pl_248);
      }
      V v_t_2413 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_246, 0, 5), v_t_2412});
      V v_cell_2414 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = (g_heff_2eelab_2erules_2eentriesGo_24dps(v_n_240, v_k_241, v_places_242, v_rest_247, v_pls_249, heff_intAdd(v_i_245, MK_INT(1LL)), heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTagIn_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam1, 2, 0};
V g_heff_2eelab_2erules_2erecordTagIn_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTagIn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_lam2, 2, 0};
Clo g_heff_2eelab_2erules_2erecordTagIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTagIn_entry, 5, 0};

V g_heff_2eelab_2erules_2erecordTagIn(V v_e_240, V v_a_241, V v_vs_242, V v_x_243, V v_tsp_244) {
top: ;
  V v_t_245 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_243), heff_rfield(v_vs_242, 1)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop_rec(v_vs_242, 3);
    heff_drop(v_x_243);
    heff_drop(v_tsp_244);
    return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam0_clo);
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_xs_249 = heff_get_n(v_vs_242, 2, 3);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_248))) {
      if (heff_intLt_c(heff_dup(v_i_248), heff_arrayLength_lent(v_xs_249, 0))) {
        V v_x_2412 = heff_arrayIndex(v_xs_249, v_i_248);
        heff_drop(v_x_2412);
        return heff_tail(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_240, heff_dup(v_a_241), v_x_243, v_tsp_244, v_a_241});
      } else {
        heff_drop(v_e_240);
        heff_drop(v_a_241);
        heff_drop(v_x_243);
        heff_drop(v_tsp_244);
        heff_drop(v_i_248);
        heff_drop(v_xs_249);
        return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam1_clo);
      }
    } else {
      heff_drop(v_e_240);
      heff_drop(v_a_241);
      heff_drop(v_x_243);
      heff_drop(v_tsp_244);
      heff_drop(v_i_248);
      heff_drop(v_xs_249);
      return ((V)&g_heff_2eelab_2erules_2erecordTagIn_lam2_clo);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordTagIn(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTagIn_lam2(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTags_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordTags(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop(v_vs_242);
    return ((V)&g_heff_2eelab_2erules_2erecordTags_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      V v_c_2410 = heff_tr(g_heff_2eelab_2erules_2erecordTagIn(heff_dup(v_e_240), heff_dup(v_a_241), heff_dup(v_vs_242), heff_dup(v_x_248), heff_dup(v_tsp_249)));
      return heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam1, 2, 5, (V[]){v_c_2410, v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2erecordTags(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V r_ = (g_heff_2eelab_2erules_2erecordTags(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_vs_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam2, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecaseLet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecaseLet_entry, 3, 0};

V g_heff_2eelab_2erules_2ecaseLet(V v_x_240, V v_scrutSyn_241, V v_body_242) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam0, 2, 3, (V[]){heff_dup(v_scrutSyn_241), v_x_240, heff_dup(v_body_242)})});
}
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2ecaseLet(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2ecaseLet_lam3(V self, V *args) {
  V v_c_2412 = args[0];
  V v_a0_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2412, 3, 8); V a_1 = v_a0_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2ecaseLet_lam5(V self, V *args) {
  V v_v_2417 = args[0];
  V v_scope_27_2418 = args[1];
  V v_body_242 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_v_2417);
  switch (heff_tag_of(v_body_242)) {
  case TAG_MkChk: {
    V v_f_2419 = heff_field(v_body_242, 0);
    heff_take_n(v_body_242, 1ULL, 1);
    V v_t_2420 = ({ V rv_0 = v_scope_27_2418; V rr_ = heff_rec_reuse_nf(v_e_243, 62ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4092u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_f_2419;
    args[0] = v_t_2420;
    args[1] = v_b_244;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  default: return heff_nomatch(v_body_242);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam7(V self, V *args) {
  V v_u_2430 = args[0];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2416});
}
V g_heff_2eelab_2erules_2ecaseLet_lam8(V self, V *args) {
  V v_u_2434 = args[0];
  V v_b_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_b_244});
}
V g_heff_2eelab_2erules_2ecaseLet_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_2416 = heff_env(self)[1];
  V v_b_244 = heff_env(self)[2];
  V v_x_240 = heff_env(self)[3];
  V v_scrut_2410 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2423 = heff_take_field(v_e_243, 2);
  V v_t_2426;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_ForNominative: {
    v_t_2426 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2423, 0ULL, 2);
    v_t_2426 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2429 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2428, heff_dup(v_x_2416)));
  V v_dom_2431 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2429, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam7, 1, 1, (V[]){v_x_2416})});
  V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
  V v_t_2433 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(v_t_2432, MK_INT(1LL)), heff_dup(v_b_244)));
  V v_cod_2435 = heff_tag_n(TAG_MkAbs, 2, (V[]){heff_dup(v_x_240), heff_rec_n(2, shape_stx__val, (V[]){v_t_2433, heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam8, 1, 1, (V[]){v_b_244})})});
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_t_2437 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_dup(heff_rfield(v_e_243, 1)), v_t_2436, v_dom_2431, v_cod_2435));
  V v_t_2438 = (g_heff_2eelab_2ememoed_2elam(v_t_2426, heff_get_n(v_e_243, 1, 6), v_t_2427, v_t_2437, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_240, v_x_2422})));
  V v_x_2439 = (g_heff_2eelab_2ememoed_2eapp(v_t_2438, v_scrut_2410));
  V f_ = v_k_248;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  V v_b_244 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_scrut_2410 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2421 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_240), heff_dup(v_x_2416), heff_dup(heff_rfield(v_e_243, 0)), heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam5, 2, 3, (V[]){v_body_242, heff_dup(v_e_243), heff_dup(v_b_244)})));
  V f_ = v_c_2421;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam6, 1, 6, (V[]){v_e_243, v_x_2416, v_b_244, v_x_240, v_scrut_2410, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecaseLet_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_249)) {
  case TAG_MkPair: {
    V v_scrut_2410 = heff_field(v_x_249, 0);
    V v_a0_2411 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 2);
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam3, 1, 1, (V[]){v_a0_2411})})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2414}));
    V f_ = heff_dup(heff_rfield(v_hd_247, 1));
    heff_room[0] = v_t_2415;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam4, 1, 7, (V[]){v_x_240, v_e_243, v_body_242, v_b_244, v_hd_247, v_scrut_2410, v_k_248});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2erules_2ecaseLet_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  V v_body_242 = heff_env(self)[3];
  V v_b_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam2, 1, 6, (V[]){v_hd_247, v_x_240, v_e_243, v_body_242, v_b_244, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecaseLet_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_b_244 = args[1];
  V v_scrutSyn_241 = heff_env(self)[0];
  V v_x_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_246;
  switch (heff_tag_of(v_scrutSyn_241)) {
  case TAG_MkSyn: {
    V v_f_245 = heff_field(v_scrutSyn_241, 0);
    heff_take_n(v_scrutSyn_241, 1ULL, 1);
    v_c_246 = heff_tr(heff_call(v_f_245, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_scrutSyn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2ecaseLet_lam1, 2, 5, (V[]){v_c_246, v_x_240, v_e_243, v_body_242, v_b_244});
}
V g_heff_2eelab_2erules_2erecordNameOf_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam1, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam2, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam3, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam4, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam5, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam6, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam7, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam8, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam9, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam10, 2, 0};
Clo g_heff_2eelab_2erules_2erecordNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordNameOf(V v_e_240, V v_a_241, V v_x_242, V v_xsp_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_LikeU: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_244, 0ULL, 4);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam1_clo);
  }
  case TAG_LikeRecord: {
    V v_capture_2415 = heff_field(v_t_244, 1);
    V v_fieldTypes_2416 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 6ULL, 3);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
    V v_t_2418 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_fieldTypes_2416, 1)));
    V v_t_2420;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      v_t_2420 = heff_abandon();
      break;
    }
    case TAG_Just: {
      V v_i_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2420 = v_i_2419;
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2421 = (g_heff_2eelab_2erules_2efieldTyAt(v_t_2417, v_capture_2415, v_fieldTypes_2416, v_t_2420, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Nothing: {
      heff_drop_rec(v_e_240, 6);
      heff_drop(v_a_241);
      heff_drop(v_x_242);
      heff_drop(v_xsp_243);
      return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam2_clo);
    }
    case TAG_Just: {
      V v_t_2424 = heff_field(v_t_2421, 0);
      heff_take_n(v_t_2421, 1ULL, 1);
      return heff_tail(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_240, v_a_241, v_x_242, v_xsp_243, v_t_2424});
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam3_clo);
  }
  case TAG_LikeInt: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam4_clo);
  }
  case TAG_LikeFloat: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam5_clo);
  }
  case TAG_LikeString: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam6_clo);
  }
  case TAG_LikeRune: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam7_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam8_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam9_clo);
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam10_clo);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordNameOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam3(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam4(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam5(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam6(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam8(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam9(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam10(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  heff_drop(v_hd_2442);
  V f_ = v_k_2443;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enestedField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enestedField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enestedField_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enestedField_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enestedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enestedField_entry, 7, 0};

V g_heff_2eelab_2erules_2enestedField(V v_upd_240, V v_sp_241, V v_r_242, V v_g_243, V v_a_244, V v_x_245, V v_fs_246) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam0, 2, 7, (V[]){v_sp_241, v_r_242, v_g_243, v_a_244, v_x_245, v_upd_240, v_fs_246})});
}
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enestedField(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2enestedField_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_247 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_fty_248 = heff_env(self)[3];
  V v_t_2414 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2esameField(v_sp_241, v_e_247, v_x_245, v_fty_248, v_x_2416, v_t_2414, v_hd_2410, v_k_2411));
}
V g_heff_2eelab_2erules_2enestedField_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_upd_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_fs_246 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  V v_fty_248 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_m_2413 = heff_field(v_x_2412, 0);
    V v_t_2414 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    V v_c_2415 = heff_tr(heff_call(v_upd_240, 6, (V[]){heff_dup(v_sp_241), v_r_242, heff_dup(v_e_247), v_m_2413, heff_dup(v_t_2414), v_fs_246}));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_2410);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam3, 1, 7, (V[]){v_sp_241, v_e_247, v_x_245, v_fty_248, v_t_2414, v_hd_2410, v_k_2411});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eelab_2erules_2enestedField_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_upd_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_e_247 = heff_env(self)[4];
  V v_fs_246 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  V v_fty_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam2, 1, 9, (V[]){v_upd_240, v_sp_241, v_r_242, v_e_247, v_fs_246, v_hd_2410, v_x_245, v_fty_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enestedField_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_fty_248 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_r_242 = heff_env(self)[1];
  V v_g_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_upd_240 = heff_env(self)[5];
  V v_fs_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2eelab_2erules_2eupdatedField(heff_dup(v_sp_241), heff_dup(v_e_247), heff_dup(v_r_242), v_g_243, v_a_244, heff_dup(v_x_245)));
  return heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam1, 2, 8, (V[]){v_c_249, v_upd_240, v_sp_241, v_r_242, v_e_247, v_fs_246, v_x_245, v_fty_248});
}
HEFF_LIT(g_heff_2eelab_2erules_2easSmall_str0, 19, "expected small type");
V g_heff_2eelab_2erules_2easSmall_lam2(V self, V *args);
V g_heff_2eelab_2erules_2easSmall_lam1(V self, V *args);
V g_heff_2eelab_2erules_2easSmall_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2easSmall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2easSmall_entry, 2, 0};

V g_heff_2eelab_2erules_2easSmall(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkSmallTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam0, 1, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2easSmall(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2easSmall_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_247, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_t_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_249; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_249); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2410 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  V v_t_2413;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Small: {
    v_t_2413 = NTAG(TAG_True);
    break;
  }
  case TAG_Large: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2413 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_245, 3);
    heff_drop(v_t_2413);
    V f_ = v_k_246;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop_rec(v_x_247, 2);
    heff_drop(v_t_2413);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2easSmall_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2416}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2417;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2easSmall_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2easSmall_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}