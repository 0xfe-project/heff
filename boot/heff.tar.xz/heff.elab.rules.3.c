// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Anonymous 24551
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntoCons 46138
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSmallTyp 41275
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_Put 28059
#define TAG_RestoreWaiting 10254
#define TAG_SError 24172
#define TAG_SLocal 28569
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_defaults 1389419502
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__ty__keys__defaults__written[] = {LBL_span, LBL_ty, LBL_keys, LBL_defaults, LBL_written};
V g_array_2eempty_get(void);
V g_heff_2eelab_2eenvironment_2ebindName(V, V, V);
V g_heff_2eelab_2eenvironment_2ebindName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindName_clo;
V g_heff_2eelab_2ememoed_2efunctionD(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eandList_24acc(V, V);
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_24acc_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2easSmall(V, V);
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2easSmall_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
V g_heff_2eelab_2erules_2econstLam(V);
V g_heff_2eelab_2erules_2econstLam_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econstLam_clo;
HeffT1 g_heff_2eelab_2erules_2edelayAt_24cpr(V, V, V);
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
V g_heff_2eelab_2erules_2eentriesGo_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo;
V g_heff_2eelab_2erules_2eetaArg(V, V, V);
V g_heff_2eelab_2erules_2eetaArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eetaArg_clo;
HeffT1 g_heff_2eelab_2erules_2eetaArg_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2egivenType(V);
V g_heff_2eelab_2erules_2egivenType_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egivenType_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2eimplicitDefaultAt(V, V, V);
V g_heff_2eelab_2erules_2eimplicitDefaultAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitDefaultAt_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2elazySyn(V, V);
V g_heff_2eelab_2erules_2elazySyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazySyn_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2enestedField(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enestedField_clo;
HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V, V);
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordNameOf(V, V, V, V);
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordNameOf_clo;
V g_heff_2eelab_2erules_2erecordTagIn(V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordTagIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTagIn_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V, V);
V g_heff_2eelab_2erules_2esameField(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esameField_clo;
V g_heff_2eelab_2erules_2etriedCandidate(V, V, V, V, V);
V g_heff_2eelab_2erules_2etriedCandidate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etriedCandidate_clo;
V g_heff_2eelab_2erules_2eupdatedField(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eupdatedField_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eupdatedField_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edefaultsOf(V);
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edefaultsOf_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str0, 3, "Int");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str1, 7, "Float64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str2, 6, "String");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str3, 4, "Rune");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str4, 5, "Array");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str5, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str6, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str7, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str8, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str9, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str10, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str11, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str12, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str13, 7, "Float32");

HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V v_mc_240, V v_v_241) {
top: ;
  V v_it_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_it_242)) {
  case TAG_VNeu: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_expansion_246 = heff_field(v_it_242, 3);
    heff_take_n(v_it_242, 9ULL, 5);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_expansion_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HGlobal: {
      V v_k_249 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      V v_t_2410 = heff_tr(heff_call(v_expansion_246, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_IntoCons: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_k_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_NotApplicable: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_249}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2410)}});
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_expansion_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HError: {
      heff_drop(v_expansion_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_it1_243)}});
    }
  }
  case TAG_VCode: {
    V v_t_2413 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 1);
    V v_it_2414 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_t_2413));
    switch (heff_tag_of(v_it_2414)) {
    case TAG_VU: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VDecode: {
      V v_it1_2416 = heff_field(v_it_2414, 0);
      heff_take_n(v_it_2414, 1ULL, 5);
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HGlobal: {
        V v_k_2422 = heff_field(v_it1_2416, 0);
        heff_take_n(v_it1_2416, 1ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_2422}});
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2416)}});
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_it_2414, 0ULL, 6);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VRecord: {
      heff_take_n(v_it_2414, 0ULL, 4);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VSum: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str0)}});
    }
    case TAG_VPrimFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str1)}});
    }
    case TAG_VPrimString: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str2)}});
    }
    case TAG_VPrimRune: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str3)}});
    }
    case TAG_VPrimArray: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str4)}});
    }
    case TAG_VFixed: {
      V v_w_2436 = heff_field(v_it_2414, 0);
      heff_take_n(v_it_2414, 1ULL, 1);
      V v_f_2437;
      switch (heff_tag_of(v_w_2436)) {
      case TAG_I8: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str5);
        break;
      }
      case TAG_I16: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str6);
        break;
      }
      case TAG_I32: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str7);
        break;
      }
      case TAG_I64: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str8);
        break;
      }
      case TAG_U8: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str9);
        break;
      }
      case TAG_U16: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str10);
        break;
      }
      case TAG_U32: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str11);
        break;
      }
      case TAG_U64: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str12);
        break;
      }
      case TAG_F32: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str13);
        break;
      }
      default: heff_nomatch(v_w_2436);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
    }
    default: return ((HeffT2){{heff_nomatch(v_it_2414)}});
    }
  }
  case TAG_VLam: {
    heff_take_n(v_it_242, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_it_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_it_242)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str3, 1, "_");
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertImplicits_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertImplicits(V v_e_240, V v_sp_241, V v_m_242, V v_ty0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam0, 1, 1, (V[]){v_ty0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam1, 1, 5, (V[]){v_k_245, v_m_242, v_e_240, v_sp_241, v_hd_244})});
}
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertImplicits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ty0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_ty0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_call(heff_get_n(v_x_2423, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2424 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2428 = v_n_2424;
    break;
  }
  case TAG_CloConst: {
    v_t_2428 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2428, v_m_242, heff_dup(v_x_2423)));
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2415, 1);
    V v_body_2432 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_call(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam3, 1, 1, (V[]){v_x_2423})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2423, 2);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2429, v_t_2443, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args) {
  V v_u_2459 = args[0];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  V v_x1_2460 = heff_tr(heff_call(heff_get_n(v_x_2449, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2461;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2463;
  }
  default: return heff_nomatch(v_x1_2460);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args) {
  V v_x_2449 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2454;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2450 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2454 = v_n_2450;
    break;
  }
  case TAG_CloConst: {
    v_t_2454 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str3);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2455 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2454, v_m_242, heff_dup(v_x_2449)));
  V v_x1_2465;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2457 = heff_field(v_cod_2415, 1);
    V v_body_2458 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2465 = heff_tr(heff_call(v_body_2458, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2457, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam5, 1, 1, (V[]){v_x_2449})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2464 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2449, 2);
    v_x1_2465 = v_body_2464;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2469;
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_Nom: {
    V v_x_2466 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_t_2469 = v_x_2466;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2465, 0ULL, 1);
    v_t_2469 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2468 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_t_2469 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x1_2465);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2455, v_t_2469, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_it_2411)) {
  case TAG_LikeU: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_it_2411, 1);
    V v_cod_2415 = heff_field(v_it_2411, 2);
    V v_it4_2416 = heff_field(v_it_2411, 3);
    heff_take_n(v_it_2411, 14ULL, 4);
    switch (heff_tag_of(v_it4_2416)) {
    case TAG_Expl: {
      heff_drop(v_e_240);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_244, 3);
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Impl: {
      V v_t_2421;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2417 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2421 = v_n_2417;
        break;
      }
      case TAG_CloConst: {
        v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2422 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_x_2410, v_dom_2414, v_t_2421));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam2, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Inst: {
      heff_drop(v_x_2410);
      V v_t_2448;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2444 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2448 = v_n_2444;
        break;
      }
      case TAG_CloConst: {
        v_t_2448 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str2);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_240), heff_dup(v_sp_241), v_dom_2414, v_t_2448, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam4, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245})));
    }
    default: return heff_nomatch(v_it4_2416);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_it_2411, 0ULL, 3);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeSum: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_it_2411);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionFormation_str0, 137, "an implicit argument without a default must have a large type (a small one could never be inferred: its values are statically irrelevant)");
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionFormation_entry, 2, 0};

V g_heff_2eelab_2erules_2efunctionFormation(V v_x1_240, V v_cod_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Anonymous: {
    V v_dom_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Anonymous = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24Anonymous, TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam0, 1, 2, (V[]){v_dom_242, heff_dup(v_cod_241)})});
  }
  case TAG_Named: {
    V v_x_2414 = heff_field(v_x1_240, 0);
    V v_dom_2415 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam4, 1, 3, (V[]){v_dom_2415, v_x_2414, heff_dup(v_cod_241)})});
  }
  case TAG_NamedImplicit: {
    V v_sp_2434 = heff_field(v_x1_240, 0);
    V v_x_2435 = heff_field(v_x1_240, 1);
    V v_dom_2436 = heff_field(v_x1_240, 2);
    V v_dflt_2437 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam8, 1, 5, (V[]){v_dom_2436, v_dflt_2437, v_sp_2434, v_x_2435, heff_dup(v_cod_241)})});
  }
  case TAG_NamedInstance: {
    V v_x_2470 = heff_field(v_x1_240, 1);
    V v_dom_2471 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam13, 1, 3, (V[]){v_dom_2471, v_x_2470, heff_dup(v_cod_241)})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2efunctionFormation(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 2, 4);
  V v_x_2413 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_243, 1, 6), v_t_2412, v_x_248, heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2411})));
  V f_ = v_k_247;
  args[0] = v_x_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_cod_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_249 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2410 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2410;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam3, 1, 3, (V[]){v_e_243, v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam2, 1, 4, (V[]){v_cod_241, v_e_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_242 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_242, 0);
    heff_take_n(v_dom_242, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam1, 2, 3, (V[]){v_c_245, v_cod_241, v_e_243});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args) {
  V v_x_2431 = args[0];
  V v_e_2416 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_k_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_get_n(heff_dup(heff_rfield(v_e_2416, 0)), 2, 4);
  V v_x_2433 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_2416, 1, 6), v_t_2432, v_x_2421, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2414, v_x_2431})));
  V f_ = v_k_2420;
  args[0] = v_x_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_e_2416 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2419 = heff_env(self)[3];
  V v_k_2420 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2421, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_sc_2427 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2414), v_t_2426, heff_dup(heff_rfield(v_e_2416, 0))));
  V v_c_2430;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2428 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2429 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2427, heff_dup(heff_rfield(v_e_2416, 1)), heff_dup(heff_rfield(v_e_2416, 2)), heff_dup(heff_rfield(v_e_2416, 3)), heff_dup(heff_rfield(v_e_2416, 4)), heff_dup(heff_rfield(v_e_2416, 5))});
    v_c_2430 = heff_tr(heff_call(v_f_2428, 1, (V[]){v_t_2429}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2430;
  heff_room[0] = v_hd_2419;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam7, 1, 4, (V[]){v_e_2416, v_x_2421, v_x_2414, v_k_2420});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_c_2418 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_e_2416 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2418;
  args[0] = heff_dup(v_hd_2419);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam6, 1, 5, (V[]){v_x_2414, v_e_2416, v_cod_241, v_hd_2419, v_k_2420});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args) {
  V v_e_2416 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2418;
  switch (heff_tag_of(v_dom_2415)) {
  case TAG_MkTyp: {
    V v_f_2417 = heff_field(v_dom_2415, 0);
    heff_take_n(v_dom_2415, 1ULL, 1);
    v_c_2418 = heff_tr(heff_call(v_f_2417, 1, (V[]){heff_dup(v_e_2416)}));
    break;
  }
  default: heff_nomatch(v_dom_2415);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam5, 2, 4, (V[]){v_c_2418, v_x_2414, v_e_2416, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args) {
  V v_x_2466 = args[0];
  V v_e_2438 = heff_env(self)[0];
  V v_x_2456 = heff_env(self)[1];
  V v_x_2443 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_k_2442 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2467 = heff_get_n(heff_dup(heff_rfield(v_e_2438, 0)), 2, 4);
  V v_x_2468 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Impl), v_x_2456, heff_get_n(v_e_2438, 1, 6), v_t_2467, v_x_2443, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2435, v_x_2466})));
  V f_ = v_k_2442;
  args[0] = v_x_2468;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  V v_x_2443 = heff_env(self)[0];
  V v_x_2435 = heff_env(self)[1];
  V v_e_2438 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  V v_hd_2441 = heff_env(self)[4];
  V v_k_2442 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_2457 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2443, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2461;
  switch (heff_tag_of(v_x1_2457)) {
  case TAG_Nom: {
    V v_x_2458 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_t_2461 = v_x_2458;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2457, 0ULL, 1);
    v_t_2461 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2460 = heff_field(v_x1_2457, 0);
    heff_take_n(v_x1_2457, 1ULL, 1);
    v_t_2461 = v_x_2460;
    break;
  }
  default: heff_nomatch(v_x1_2457);
  }
  V v_sc_2462 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2435), v_t_2461, heff_dup(heff_rfield(v_e_2438, 0))));
  V v_c_2465;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2463 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2464 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2462, heff_dup(heff_rfield(v_e_2438, 1)), heff_dup(heff_rfield(v_e_2438, 2)), heff_dup(heff_rfield(v_e_2438, 3)), heff_dup(heff_rfield(v_e_2438, 4)), heff_dup(heff_rfield(v_e_2438, 5))});
    v_c_2465 = heff_tr(heff_call(v_f_2463, 1, (V[]){v_t_2464}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2465;
  heff_room[0] = v_hd_2441;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam12, 1, 5, (V[]){v_e_2438, v_x_2456, v_x_2443, v_x_2435, v_k_2442});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_dflt_2437 = heff_env(self)[0];
  V v_sp_2434 = heff_env(self)[1];
  V v_hd_2441 = heff_env(self)[2];
  V v_k_2442 = heff_env(self)[3];
  V v_e_2438 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  V v_cod_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2443, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2448;
  switch (heff_tag_of(v_x1_2444)) {
  case TAG_Nom: {
    V v_t_2445 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2445; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2446 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2446; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2446); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2447 = heff_field(v_x1_2444, 0);
    heff_take_n(v_x1_2444, 1ULL, 1);
    v_x1_2448 = ({ V a_0 = v_t_2447; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2444);
  }
  V v_t_2450;
  switch (heff_tag_of(v_x1_2448)) {
  case TAG_Small: {
    switch (heff_tag_of(v_dflt_2437)) {
    case TAG_Nothing: {
      v_t_2450 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      v_t_2450 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_dflt_2437);
    }
    break;
  }
  case TAG_Large: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2448);
  }
  if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2443, 2);
    heff_drop(v_dflt_2437);
    heff_drop_rec(v_e_2438, 6);
    heff_drop(v_x_2435);
    heff_drop(v_cod_241);
    heff_drop(v_t_2450);
    V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(324LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionFormation_str0), v_sp_2434, NTAG(TAG_Nothing)});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_2441, 2), 1, (V[]){v_t_2453}));
    V f_ = heff_get_n(v_hd_2441, 1, 3);
    heff_room[0] = v_t_2454;
    heff_room[1] = v_k_2442;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_2434);
    heff_drop(v_t_2450);
    V v_c_2455 = (g_heff_2eelab_2erules_2eimplicitDefaultAt(heff_dup(v_e_2438), heff_dup(v_x_2443), v_dflt_2437));
    V f_ = v_c_2455;
    heff_room[0] = heff_dup(v_hd_2441);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam11, 1, 6, (V[]){v_x_2443, v_x_2435, v_e_2438, v_cod_241, v_hd_2441, v_k_2442});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_c_2440 = heff_env(self)[0];
  V v_dflt_2437 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_e_2438 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_cod_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2440;
  args[0] = heff_dup(v_hd_2441);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam10, 1, 7, (V[]){v_dflt_2437, v_sp_2434, v_hd_2441, v_k_2442, v_e_2438, v_x_2435, v_cod_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args) {
  V v_e_2438 = args[0];
  V v_dom_2436 = heff_env(self)[0];
  V v_dflt_2437 = heff_env(self)[1];
  V v_sp_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_cod_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2440;
  switch (heff_tag_of(v_dom_2436)) {
  case TAG_MkTyp: {
    V v_f_2439 = heff_field(v_dom_2436, 0);
    heff_take_n(v_dom_2436, 1ULL, 1);
    v_c_2440 = heff_tr(heff_call(v_f_2439, 1, (V[]){heff_dup(v_e_2438)}));
    break;
  }
  default: heff_nomatch(v_dom_2436);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam9, 2, 6, (V[]){v_c_2440, v_dflt_2437, v_sp_2434, v_e_2438, v_x_2435, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args) {
  V v_x_2487 = args[0];
  V v_e_2472 = heff_env(self)[0];
  V v_x_2477 = heff_env(self)[1];
  V v_x_2470 = heff_env(self)[2];
  V v_k_2476 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2488 = heff_get_n(heff_dup(heff_rfield(v_e_2472, 0)), 2, 4);
  V v_x_2489 = (g_heff_2eelab_2ememoed_2efunctionD(NTAG(TAG_Inst), NTAG(TAG_Nothing), heff_get_n(v_e_2472, 1, 6), v_t_2488, v_x_2477, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2470, v_x_2487})));
  V f_ = v_k_2476;
  args[0] = v_x_2489;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args) {
  V v_x_2477 = args[0];
  V v_x_2470 = heff_env(self)[0];
  V v_e_2472 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2475 = heff_env(self)[3];
  V v_k_2476 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2477, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2482;
  switch (heff_tag_of(v_x1_2478)) {
  case TAG_Nom: {
    V v_x_2479 = heff_field(v_x1_2478, 0);
    heff_take_n(v_x1_2478, 1ULL, 1);
    v_t_2482 = v_x_2479;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2478, 0ULL, 1);
    v_t_2482 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2481 = heff_field(v_x1_2478, 0);
    heff_take_n(v_x1_2478, 1ULL, 1);
    v_t_2482 = v_x_2481;
    break;
  }
  default: heff_nomatch(v_x1_2478);
  }
  V v_sc_2483 = (g_heff_2eelab_2eenvironment_2ebindName(heff_dup(v_x_2470), v_t_2482, heff_dup(heff_rfield(v_e_2472, 0))));
  V v_c_2486;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2484 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2485 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2483, heff_dup(heff_rfield(v_e_2472, 1)), heff_dup(heff_rfield(v_e_2472, 2)), heff_dup(heff_rfield(v_e_2472, 3)), heff_dup(heff_rfield(v_e_2472, 4)), heff_dup(heff_rfield(v_e_2472, 5))});
    v_c_2486 = heff_tr(heff_call(v_f_2484, 1, (V[]){v_t_2485}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2486;
  heff_room[0] = v_hd_2475;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam16, 1, 4, (V[]){v_e_2472, v_x_2477, v_x_2470, v_k_2476});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k_2476 = args[1];
  V v_c_2474 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  V v_e_2472 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2474;
  args[0] = heff_dup(v_hd_2475);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam15, 1, 5, (V[]){v_x_2470, v_e_2472, v_cod_241, v_hd_2475, v_k_2476});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args) {
  V v_e_2472 = args[0];
  V v_dom_2471 = heff_env(self)[0];
  V v_x_2470 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2474;
  switch (heff_tag_of(v_dom_2471)) {
  case TAG_MkTyp: {
    V v_f_2473 = heff_field(v_dom_2471, 0);
    heff_take_n(v_dom_2471, 1ULL, 1);
    v_c_2474 = heff_tr(heff_call(v_f_2473, 1, (V[]){heff_dup(v_e_2472)}));
    break;
  }
  default: heff_nomatch(v_dom_2471);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam14, 2, 4, (V[]){v_c_2474, v_x_2470, v_e_2472, v_cod_241});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etriedCandidate_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_lam0, 1, 0};
V g_heff_2eelab_2erules_2etriedCandidate_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etriedCandidate_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_lam2, 1, 0};
V g_heff_2eelab_2erules_2etriedCandidate_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2etriedCandidate_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_lam5, 1, 0};
V g_heff_2eelab_2erules_2etriedCandidate_lam6(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam7(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam10(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam9(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam8(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etriedCandidate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_entry, 5, 0};

V g_heff_2eelab_2erules_2etriedCandidate(V v_e_240, V v_goal_241, V v_c_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etriedCandidate_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam1, 1, 5, (V[]){v_hd_243, heff_dup(v_c_242), v_e_240, v_goal_241, v_k_244})});
}
V g_heff_2eelab_2erules_2etriedCandidate_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2etriedCandidate(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam0(V self, V *args) {
  V v_st_245 = args[0];
  return v_st_245;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam2(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam5(V self, V *args) {
  V v_st_2417 = args[0];
  return v_st_2417;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2421, 1, 8); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_249, 1, 8); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_x_2424 = heff_bool(heff_intEq_c_lent(v_t_2422, v_t_2423, 0));
  heff_drop(v_t_2422);
  heff_drop(v_t_2423);
  V f_ = heff_get_n(v_hd_243, 0, 3);
  args[0] = v_x_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etriedCandidate_lam5_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2419}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2420;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam6, 1, 2, (V[]){v_x_249, v_hd_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam7(V self, V *args) {
  V v_s_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_s_2426);
  V f_ = heff_get_n(v_hd_243, 0, 3);
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam10(V self, V *args) {
  V v_x_2438 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_k_244;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam9(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2437;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam10, 1, 2, (V[]){v_k_244, v_x_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2431 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2433;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam9, 1, 4, (V[]){v_x_2413, v_hd_243, v_k_244, v_x_2430});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415;
  switch (heff_tag_of(v_c_242)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_242, 0);
    heff_take_n(v_c_242, 1ULL, 1);
    v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_240, v_goal_241}));
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  V v_t_2425 = heff_tr(heff_call(v_c_2415, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam4, 1, 2, (V[]){heff_dup(v_hd_243), heff_dup(v_x_249)})}));
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2425, heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam7, 1, 1, (V[]){heff_dup(v_hd_243)})})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2428}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam8, 1, 4, (V[]){v_x_249, v_hd_243, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2etriedCandidate_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam3, 1, 6, (V[]){v_c_242, v_e_240, v_goal_241, v_hd_243, v_x_249, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_entry, 1, 0};

V g_heff_2eelab_2erules_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2eandList_str1), heff_dup(v_y_245)));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_dup(v_x_241);
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2eelab_2erules_2eandList_str2));
        return (g_heff_2eelab_2erules_2eandList_24acc(v_x12_242, v_s_2410));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eandList(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eentriesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eentriesGo(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_246, 5);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_pl_248 = heff_field(v_x5_244, 0);
      V v_pls_249 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_pl_248)) {
      case TAG_Nothing: {
        v_t_2412 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_246), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_pl_248, 0);
        V v_ru_24pl_248_24Just = heff_take_reuse_n(v_pl_248, 1ULL, 1);
        V v_t_2411 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2410);
        v_t_2412 = heff_tag_at_n(v_ru_24pl_248_24Just, TAG_SLocal, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_pl_248);
      }
      V v_t_2413 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_246, 0, 5), v_t_2412});
      V v_cell_2414 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = (g_heff_2eelab_2erules_2eentriesGo_24dps(v_n_240, v_k_241, v_places_242, v_rest_247, v_pls_249, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str0, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str1, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str2, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str3, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str4, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str5, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str6, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str7, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str8, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str9, 55, "tried to check a record expression at a non-record type");
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V v_sp_240, V v_fieldSettings_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam0, 4, 2, (V[]){v_sp_240, v_fieldSettings_241})}});
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e0_242 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2erules_2eletted(v_e0_242, v_x_2410, v_x_2435, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_fieldSettings_241 = heff_env(self)[3];
  V v_e0_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_LikeU: {
    V v_ru_24t_2411_24LikeU = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_at_n(v_ru_24t_2411_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2411, 0ULL, 4);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2423}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2424;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRecord: {
    V v_capture_2426 = heff_field(v_t_2411, 1);
    V v_fieldTypes_2427 = heff_field(v_t_2411, 2);
    heff_take_n(v_t_2411, 6ULL, 3);
    V v_keys_2428 = heff_take_field(v_fieldTypes_2427, 0);
    V v_values_2429 = heff_get_n(v_fieldTypes_2427, 2, 3);
    V v_t_2430 = (g_heff_2eelab_2evalue_2edefaultsOf(heff_dup(v_x_2410)));
    V v_t_2431 = (g_list_2emap_24s1367173129x1257089258(heff_dup(v_fieldSettings_241)));
    V v_t_2432 = heff_rec_n(5, shape_span__ty__keys__defaults__written, (V[]){v_sp_240, heff_dup(v_x_2410), heff_arrayToList(heff_dup(v_keys_2428)), v_t_2430, v_t_2431});
    V v_t_2433 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2428), heff_arrayToList(v_values_2429)));
    V v_c_2434 = (g_heff_2eelab_2erules_2eintroGo(heff_dup(v_e0_242), v_t_2432, NTAG(TAG_Nil), v_capture_2426, v_fieldSettings_241, v_t_2433));
    V f_ = v_c_2434;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam3, 1, 4, (V[]){v_e0_242, v_x_2410, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2411_24LikeSum = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2438 = heff_tag_at_n(v_ru_24t_2411_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2439}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2440;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2443}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2444;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2447}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2448;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2451}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2452;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2455}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2456;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2411_24LikeArray = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2459 = heff_tag_at_n(v_ru_24t_2411_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2460}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2461;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2411_24LikeFixed = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2464 = heff_tag_at_n(v_ru_24t_2411_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2465}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2466;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2469}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam0(V self, V *args) {
  V v_e0_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_fieldSettings_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam2, 1, 5, (V[]){v_sp_240, v_hd_244, v_k_245, v_fieldSettings_241, v_e0_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2eetaArg_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eetaArg_entry, 3, 0};

V g_heff_2eelab_2erules_2eetaArg(V v_sp_240, V v_l_241, V v_dom_242) {
top: ;
  HeffT1 v_t_243 = (g_heff_2eelab_2erules_2eetaArg_24cpr(v_sp_240, v_l_241, v_dom_242));
  {
    V v_field_244 = v_t_243.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_244});
  }
}
V g_heff_2eelab_2erules_2eetaArg_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eetaArg(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTags_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordTags(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop(v_vs_242);
    return ((V)&g_heff_2eelab_2erules_2erecordTags_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      V v_c_2410 = heff_tr(g_heff_2eelab_2erules_2erecordTagIn(heff_dup(v_e_240), heff_dup(v_a_241), heff_dup(v_vs_242), heff_dup(v_x_248), heff_dup(v_tsp_249)));
      return heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam1, 2, 5, (V[]){v_c_2410, v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2erecordTags(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2413);
  V v_t_2414 = ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V r_ = (g_heff_2eelab_2erules_2erecordTags(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_vs_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam2, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, v_rest_247, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam1, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam2, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam3, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam4, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam5, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam6, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam7, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam8(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam8, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam9(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam9, 2, 0};
V g_heff_2eelab_2erules_2erecordNameOf_lam10(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordNameOf_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_lam10, 2, 0};
Clo g_heff_2eelab_2erules_2erecordNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordNameOf_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordNameOf(V v_e_240, V v_a_241, V v_x_242, V v_xsp_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_a_241)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_LikeU: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_244, 0ULL, 4);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam1_clo);
  }
  case TAG_LikeRecord: {
    V v_capture_2415 = heff_field(v_t_244, 1);
    V v_fieldTypes_2416 = heff_field(v_t_244, 2);
    heff_take_n(v_t_244, 6ULL, 3);
    V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
    HeffT2 v_t_2418 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_fieldTypes_2416, 1), v_x_242));
    V v_t_2422;
    {
      V v_field_2420 = v_t_2418.f[1];
      int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
      if ((v_tag_2419 == ((int64_t)0ULL))) {
        V v_i_2421 = v_field_2420;
        v_t_2422 = v_i_2421;
      } else {
        heff_drop(v_field_2420);
        v_t_2422 = heff_abandon();
      }
    }
    HeffT2 v_t_2423 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_t_2417, v_capture_2415, v_fieldTypes_2416, v_t_2422, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
    {
      V v_field_2425 = v_t_2423.f[1];
      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
      if ((v_tag_2424 == ((int64_t)0ULL))) {
        V v_t_2426 = v_field_2425;
        return heff_tail(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_240, v_a_241, v_x_242, v_xsp_243, v_t_2426});
      } else {
        heff_drop_rec(v_e_240, 6);
        heff_drop(v_a_241);
        heff_drop(v_x_242);
        heff_drop(v_xsp_243);
        heff_drop(v_field_2425);
        return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam2_clo);
      }
    }
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam3_clo);
  }
  case TAG_LikeInt: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam4_clo);
  }
  case TAG_LikeFloat: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam5_clo);
  }
  case TAG_LikeString: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam6_clo);
  }
  case TAG_LikeRune: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam7_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam8_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam9_clo);
  }
  case TAG_NoRules: {
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_a_241);
    heff_drop(v_x_242);
    heff_drop(v_xsp_243);
    return ((V)&g_heff_2eelab_2erules_2erecordNameOf_lam10_clo);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2erules_2erecordNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2erecordNameOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam2(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam6(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  heff_drop(v_hd_2436);
  V f_ = v_k_2437;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam7(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam8(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam9(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordNameOf_lam10(V self, V *args) {
  V v_hd_2446 = args[0];
  V v_k_2447 = args[1];
  heff_drop(v_hd_2446);
  V f_ = v_k_2447;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2enestedField_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enestedField_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enestedField_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enestedField_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2enestedField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enestedField_entry, 7, 0};

V g_heff_2eelab_2erules_2enestedField(V v_upd_240, V v_sp_241, V v_r_242, V v_g_243, V v_a_244, V v_x_245, V v_fs_246) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam0, 2, 7, (V[]){v_sp_241, v_r_242, v_g_243, v_a_244, v_x_245, v_upd_240, v_fs_246})});
}
V g_heff_2eelab_2erules_2enestedField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enestedField(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2erules_2enestedField_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_sp_241 = heff_env(self)[0];
  V v_e_247 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_fty_248 = heff_env(self)[3];
  V v_t_2414 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2esameField(v_sp_241, v_e_247, v_x_245, v_fty_248, v_x_2416, v_t_2414, v_hd_2410, v_k_2411));
}
V g_heff_2eelab_2erules_2enestedField_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_upd_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_fs_246 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  V v_fty_248 = heff_env(self)[7];
  V v_k_2411 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_m_2413 = heff_field(v_x_2412, 0);
    V v_t_2414 = heff_field(v_x_2412, 1);
    heff_take_n(v_x_2412, 3ULL, 2);
    V v_c_2415 = heff_tr(heff_call(v_upd_240, 6, (V[]){heff_dup(v_sp_241), v_r_242, heff_dup(v_e_247), v_m_2413, heff_dup(v_t_2414), v_fs_246}));
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_2410);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam3, 1, 7, (V[]){v_sp_241, v_e_247, v_x_245, v_fty_248, v_t_2414, v_hd_2410, v_k_2411});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2412);
  }
}
V g_heff_2eelab_2erules_2enestedField_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_upd_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_r_242 = heff_env(self)[3];
  V v_e_247 = heff_env(self)[4];
  V v_fs_246 = heff_env(self)[5];
  V v_x_245 = heff_env(self)[6];
  V v_fty_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam2, 1, 9, (V[]){v_upd_240, v_sp_241, v_r_242, v_e_247, v_fs_246, v_hd_2410, v_x_245, v_fty_248, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enestedField_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_fty_248 = args[1];
  V v_sp_241 = heff_env(self)[0];
  V v_r_242 = heff_env(self)[1];
  V v_g_243 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_upd_240 = heff_env(self)[5];
  V v_fs_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2eelab_2erules_2eupdatedField(heff_dup(v_sp_241), heff_dup(v_e_247), v_r_242, v_g_243, v_a_244, heff_dup(v_x_245)));
  return heff_clo_n(g_heff_2eelab_2erules_2enestedField_lam1, 2, 8, (V[]){v_c_249, v_upd_240, v_sp_241, v_r_242, v_e_247, v_fs_246, v_x_245, v_fty_248});
}
HEFF_LIT(g_heff_2eelab_2erules_2easSmall_str0, 19, "expected small type");
HEFF_LIT(g_heff_2eelab_2erules_2easSmall_str1, 19, "expected small type");
V g_heff_2eelab_2erules_2easSmall_lam2(V self, V *args);
V g_heff_2eelab_2erules_2easSmall_lam1(V self, V *args);
V g_heff_2eelab_2erules_2easSmall_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2easSmall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2easSmall_entry, 2, 0};

V g_heff_2eelab_2erules_2easSmall(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkSmallTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam0, 1, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2easSmall_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2easSmall(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2easSmall_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_247, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2412;
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Nom: {
    V v_t_249 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_249; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_249); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2410 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2410; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2410); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2411 = heff_field(v_x1_248, 0);
    heff_take_n(v_x1_248, 1ULL, 1);
    v_x1_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x1_248);
  }
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Small: {
    heff_drop(v_sp_240);
    heff_drop_rec(v_hd_245, 3);
    V f_ = v_k_246;
    args[0] = v_x_247;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Large: {
    heff_drop_rec(v_x_247, 2);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2easSmall_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_TopL: {
    heff_drop_rec(v_x_247, 2);
    V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(309LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2easSmall_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_245, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_246;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x1_2412);
  }
}
V g_heff_2eelab_2erules_2easSmall_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2easSmall_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_243 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2easSmall_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
HEFF_LIT(g_heff_2eelab_2erules_2elazySyn_str0, 12, "builtin.Lazy");
V g_heff_2eelab_2erules_2elazySyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam7(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam8(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam9(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam10(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam11(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam12(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam13(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam14(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam15(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elazySyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elazySyn_entry, 2, 0};

V g_heff_2eelab_2erules_2elazySyn(V v_sp_240, V v_s_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam0, 1, 2, (V[]){heff_dup(v_s_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2elazySyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2elazySyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2elazySyn_lam3(V self, V *args) {
  V v_c_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 2ULL, 2);
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elazySyn_lam5(V self, V *args) {
  V v_e2_2419 = args[0];
  V v_hd_2420 = args[1];
  V v_k_2421 = args[2];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2419);
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elazySyn_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_dup(heff_field(v_x_2433, 1));
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V v_t_2437 = (g_heff_2eelab_2erules_2egivenType(v_t_2436));
  V v_t_2440;
  switch (heff_tag_of(v_x_2433)) {
  case TAG_MkPair: {
    V v_x_2438 = heff_field(v_x_2433, 0);
    heff_take_n(v_x_2433, 1ULL, 2);
    v_t_2440 = v_x_2438;
    break;
  }
  default: heff_nomatch(v_x_2433);
  }
  V v_t_2441 = (g_heff_2eelab_2erules_2econstLam(v_t_2440));
  HeffT1 v_t_2442 = ({ V a_0 = v_sp_240; V a_1 = v_t_2437; V a_2 = v_t_2441; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2437); heff_drop(v_t_2441); r_; });
  {
    V v_field_2443 = v_t_2442.f[0];
    V v_f_2444 = v_field_2443;
    V f_ = v_f_2444;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2454;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_y_2453 = heff_dup(heff_field(v_x_2451, 1));
    v_t_2454 = v_y_2453;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2455 = (g_heff_2eelab_2erules_2egivenType(v_t_2454));
  V v_t_2458;
  switch (heff_tag_of(v_x_2451)) {
  case TAG_MkPair: {
    V v_x_2456 = heff_field(v_x_2451, 0);
    heff_take_n(v_x_2451, 1ULL, 2);
    v_t_2458 = v_x_2456;
    break;
  }
  default: heff_nomatch(v_x_2451);
  }
  V v_t_2459 = (g_heff_2eelab_2erules_2econstLam(v_t_2458));
  HeffT1 v_t_2460 = ({ V a_0 = v_sp_240; V a_1 = v_t_2455; V a_2 = v_t_2459; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2455); heff_drop(v_t_2459); r_; });
  {
    V v_field_2461 = v_t_2460.f[0];
    V v_f_2462 = v_field_2461;
    V f_ = v_f_2462;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam8(V self, V *args) {
  V v_x_2467 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2470;
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkPair: {
    V v_y_2469 = heff_dup(heff_field(v_x_2467, 1));
    v_t_2470 = v_y_2469;
    break;
  }
  default: heff_nomatch(v_x_2467);
  }
  V v_t_2471 = (g_heff_2eelab_2erules_2egivenType(v_t_2470));
  V v_t_2474;
  switch (heff_tag_of(v_x_2467)) {
  case TAG_MkPair: {
    V v_x_2472 = heff_field(v_x_2467, 0);
    heff_take_n(v_x_2467, 1ULL, 2);
    v_t_2474 = v_x_2472;
    break;
  }
  default: heff_nomatch(v_x_2467);
  }
  V v_t_2475 = (g_heff_2eelab_2erules_2econstLam(v_t_2474));
  HeffT1 v_t_2476 = ({ V a_0 = v_sp_240; V a_1 = v_t_2471; V a_2 = v_t_2475; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2471); heff_drop(v_t_2475); r_; });
  {
    V v_field_2477 = v_t_2476.f[0];
    V v_f_2478 = v_field_2477;
    V f_ = v_f_2478;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam9(V self, V *args) {
  V v_x_2482 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2485;
  switch (heff_tag_of(v_x_2482)) {
  case TAG_MkPair: {
    V v_y_2484 = heff_dup(heff_field(v_x_2482, 1));
    v_t_2485 = v_y_2484;
    break;
  }
  default: heff_nomatch(v_x_2482);
  }
  V v_t_2486 = (g_heff_2eelab_2erules_2egivenType(v_t_2485));
  V v_t_2489;
  switch (heff_tag_of(v_x_2482)) {
  case TAG_MkPair: {
    V v_x_2487 = heff_field(v_x_2482, 0);
    heff_take_n(v_x_2482, 1ULL, 2);
    v_t_2489 = v_x_2487;
    break;
  }
  default: heff_nomatch(v_x_2482);
  }
  V v_t_2490 = (g_heff_2eelab_2erules_2econstLam(v_t_2489));
  HeffT1 v_t_2491 = ({ V a_0 = v_sp_240; V a_1 = v_t_2486; V a_2 = v_t_2490; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2486); heff_drop(v_t_2490); r_; });
  {
    V v_field_2492 = v_t_2491.f[0];
    V v_f_2493 = v_field_2492;
    V f_ = v_f_2493;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam10(V self, V *args) {
  V v_x_2497 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24100;
  switch (heff_tag_of(v_x_2497)) {
  case TAG_MkPair: {
    V v_y_2499 = heff_dup(heff_field(v_x_2497, 1));
    v_t_24100 = v_y_2499;
    break;
  }
  default: heff_nomatch(v_x_2497);
  }
  V v_t_24101 = (g_heff_2eelab_2erules_2egivenType(v_t_24100));
  V v_t_24104;
  switch (heff_tag_of(v_x_2497)) {
  case TAG_MkPair: {
    V v_x_24102 = heff_field(v_x_2497, 0);
    heff_take_n(v_x_2497, 1ULL, 2);
    v_t_24104 = v_x_24102;
    break;
  }
  default: heff_nomatch(v_x_2497);
  }
  V v_t_24105 = (g_heff_2eelab_2erules_2econstLam(v_t_24104));
  HeffT1 v_t_24106 = ({ V a_0 = v_sp_240; V a_1 = v_t_24101; V a_2 = v_t_24105; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_24101); heff_drop(v_t_24105); r_; });
  {
    V v_field_24107 = v_t_24106.f[0];
    V v_f_24108 = v_field_24107;
    V f_ = v_f_24108;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam11(V self, V *args) {
  V v_x_24112 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24115;
  switch (heff_tag_of(v_x_24112)) {
  case TAG_MkPair: {
    V v_y_24114 = heff_dup(heff_field(v_x_24112, 1));
    v_t_24115 = v_y_24114;
    break;
  }
  default: heff_nomatch(v_x_24112);
  }
  V v_t_24116 = (g_heff_2eelab_2erules_2egivenType(v_t_24115));
  V v_t_24119;
  switch (heff_tag_of(v_x_24112)) {
  case TAG_MkPair: {
    V v_x_24117 = heff_field(v_x_24112, 0);
    heff_take_n(v_x_24112, 1ULL, 2);
    v_t_24119 = v_x_24117;
    break;
  }
  default: heff_nomatch(v_x_24112);
  }
  V v_t_24120 = (g_heff_2eelab_2erules_2econstLam(v_t_24119));
  HeffT1 v_t_24121 = ({ V a_0 = v_sp_240; V a_1 = v_t_24116; V a_2 = v_t_24120; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_24116); heff_drop(v_t_24120); r_; });
  {
    V v_field_24122 = v_t_24121.f[0];
    V v_f_24123 = v_field_24122;
    V f_ = v_f_24123;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam12(V self, V *args) {
  V v_x_24127 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24130;
  switch (heff_tag_of(v_x_24127)) {
  case TAG_MkPair: {
    V v_y_24129 = heff_dup(heff_field(v_x_24127, 1));
    v_t_24130 = v_y_24129;
    break;
  }
  default: heff_nomatch(v_x_24127);
  }
  V v_t_24131 = (g_heff_2eelab_2erules_2egivenType(v_t_24130));
  V v_t_24134;
  switch (heff_tag_of(v_x_24127)) {
  case TAG_MkPair: {
    V v_x_24132 = heff_field(v_x_24127, 0);
    heff_take_n(v_x_24127, 1ULL, 2);
    v_t_24134 = v_x_24132;
    break;
  }
  default: heff_nomatch(v_x_24127);
  }
  V v_t_24135 = (g_heff_2eelab_2erules_2econstLam(v_t_24134));
  HeffT1 v_t_24136 = ({ V a_0 = v_sp_240; V a_1 = v_t_24131; V a_2 = v_t_24135; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_24131); heff_drop(v_t_24135); r_; });
  {
    V v_field_24137 = v_t_24136.f[0];
    V v_f_24138 = v_field_24137;
    V f_ = v_f_24138;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam13(V self, V *args) {
  V v_x_24143 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24146;
  switch (heff_tag_of(v_x_24143)) {
  case TAG_MkPair: {
    V v_y_24145 = heff_dup(heff_field(v_x_24143, 1));
    v_t_24146 = v_y_24145;
    break;
  }
  default: heff_nomatch(v_x_24143);
  }
  V v_t_24147 = (g_heff_2eelab_2erules_2egivenType(v_t_24146));
  V v_t_24150;
  switch (heff_tag_of(v_x_24143)) {
  case TAG_MkPair: {
    V v_x_24148 = heff_field(v_x_24143, 0);
    heff_take_n(v_x_24143, 1ULL, 2);
    v_t_24150 = v_x_24148;
    break;
  }
  default: heff_nomatch(v_x_24143);
  }
  V v_t_24151 = (g_heff_2eelab_2erules_2econstLam(v_t_24150));
  HeffT1 v_t_24152 = ({ V a_0 = v_sp_240; V a_1 = v_t_24147; V a_2 = v_t_24151; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_24147); heff_drop(v_t_24151); r_; });
  {
    V v_field_24153 = v_t_24152.f[0];
    V v_f_24154 = v_field_24153;
    V f_ = v_f_24154;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam14(V self, V *args) {
  V v_x_24159 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24162;
  switch (heff_tag_of(v_x_24159)) {
  case TAG_MkPair: {
    V v_y_24161 = heff_dup(heff_field(v_x_24159, 1));
    v_t_24162 = v_y_24161;
    break;
  }
  default: heff_nomatch(v_x_24159);
  }
  V v_t_24163 = (g_heff_2eelab_2erules_2egivenType(v_t_24162));
  V v_t_24166;
  switch (heff_tag_of(v_x_24159)) {
  case TAG_MkPair: {
    V v_x_24164 = heff_field(v_x_24159, 0);
    heff_take_n(v_x_24159, 1ULL, 2);
    v_t_24166 = v_x_24164;
    break;
  }
  default: heff_nomatch(v_x_24159);
  }
  V v_t_24167 = (g_heff_2eelab_2erules_2econstLam(v_t_24166));
  HeffT1 v_t_24168 = ({ V a_0 = v_sp_240; V a_1 = v_t_24163; V a_2 = v_t_24167; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_24163); heff_drop(v_t_24167); r_; });
  {
    V v_field_24169 = v_t_24168.f[0];
    V v_f_24170 = v_field_24169;
    V f_ = v_f_24170;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam15(V self, V *args) {
  V v_x_24174 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24177;
  switch (heff_tag_of(v_x_24174)) {
  case TAG_MkPair: {
    V v_y_24176 = heff_dup(heff_field(v_x_24174, 1));
    v_t_24177 = v_y_24176;
    break;
  }
  default: heff_nomatch(v_x_24174);
  }
  V v_t_24178 = (g_heff_2eelab_2erules_2egivenType(v_t_24177));
  V v_t_24181;
  switch (heff_tag_of(v_x_24174)) {
  case TAG_MkPair: {
    V v_x_24179 = heff_field(v_x_24174, 0);
    heff_take_n(v_x_24174, 1ULL, 2);
    v_t_24181 = v_x_24179;
    break;
  }
  default: heff_nomatch(v_x_24174);
  }
  V v_t_24182 = (g_heff_2eelab_2erules_2econstLam(v_t_24181));
  HeffT1 v_t_24183 = ({ V a_0 = v_sp_240; V a_1 = v_t_24178; V a_2 = v_t_24182; HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, a_1, a_2)); heff_drop(v_t_24178); heff_drop(v_t_24182); r_; });
  {
    V v_field_24184 = v_t_24183.f[0];
    V v_f_24185 = v_field_24184;
    V f_ = v_f_24185;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    V v_ru_24t_2416_24LikeU = heff_take_reuse_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_2415);
    V v_t_2418 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2elazySyn_str0)));
    V v_t_2422 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2416_24LikeU, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam5, 3, 1, (V[]){v_x_247})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    HeffT1 v_t_2423 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_sp_240; V a_2 = v_t_2418; V a_3 = v_t_2422; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_t_2418); heff_drop(v_t_2422); r_; });
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_f_2425 = v_field_2424;
      V f_ = v_f_2425;
      heff_room[0] = v_e_242;
      heff_room[1] = v_hd_245;
      heff_room[2] = v_k_246;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2416, 0ULL, 4);
    V v_t_2432;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2430 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2432 = v_x_2430;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_2432, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam6, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2416, 0ULL, 3);
    V v_t_2450;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2448 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2450 = v_x_2448;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_2450, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam7, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_2416, 0ULL, 1);
    V v_t_2466;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2464 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2466 = v_x_2464;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_2466, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam8, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeInt: {
    V v_t_2481;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2481 = v_x_2479;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_2481, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam9, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeFloat: {
    V v_t_2496;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2494 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2496 = v_x_2494;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_2496, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam10, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeString: {
    V v_t_24111;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_24111 = v_x_24109;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_24111, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam11, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeRune: {
    V v_t_24126;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_24124 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_24126 = v_x_24124;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_24126, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam12, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_2416, 0ULL, 1);
    V v_t_24142;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_24140 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_24142 = v_x_24140;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_24142, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam13, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_2416, 0ULL, 1);
    V v_t_24158;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_24156 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_24158 = v_x_24156;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_24158, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam14, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  case TAG_NoRules: {
    V v_t_24173;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_24171 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_24173 = v_x_24171;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_24173, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam15, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  default: return heff_nomatch(v_t_2416);
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam3, 1, 1, (V[]){heff_dup(v_x_247)})})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam4, 1, 5, (V[]){v_sp_240, v_x_247, v_e_242, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elazySyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam2, 1, 4, (V[]){v_hd_245, v_sp_240, v_e_242, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elazySyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam1, 2, 3, (V[]){v_c_244, v_sp_240, v_e_242});
}