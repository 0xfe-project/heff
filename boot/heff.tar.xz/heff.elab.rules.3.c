// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Anonymous 24551
#define TAG_BDelayedBy 11524
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Delay 58579
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_F32 16337
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_IntoCons 46138
#define TAG_LSnoc 32613
#define TAG_Large 60129
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_Named 2049
#define TAG_NamedImplicit 12352
#define TAG_NamedInstance 32632
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_NotApplicable 40298
#define TAG_Put 28059
#define TAG_RestoreWaiting 10254
#define TAG_SCode 58360
#define TAG_SError 24172
#define TAG_SFunction 64505
#define TAG_SLam 1658
#define TAG_SLocal 28569
#define TAG_SaveDelayed 42463
#define TAG_Small 51389
#define TAG_SpApp 44612
#define TAG_Throw 56084
#define TAG_TopL 65516
#define TAG_Trace 9637
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_chk 308000
#define LBL_code 9554612
#define LBL_defaults 1389419502
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_recovered 474271923
#define LBL_ret 322331
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
#define LBL_values 1123329101
#define LBL_written 1834876765
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_span__ty__keys__defaults__written[] = {LBL_span, LBL_ty, LBL_keys, LBL_defaults, LBL_written};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2eenvironment_2ebindAt(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ebindAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ebindAt_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(V, V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858_clo;
V g_heff_2eelab_2ememoed_2eiapp(V, V, V);
V g_heff_2eelab_2ememoed_2eiapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2eiapp_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo;
V g_heff_2eelab_2emeta_2eblockedTy(V, V, V);
V g_heff_2eelab_2emeta_2eblockedTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eblockedTy_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eandList(V);
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_clo;
V g_heff_2eelab_2erules_2eandList_24acc(V, V);
V g_heff_2eelab_2erules_2eandList_24acc_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eandList_24acc_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2ecodeAt(V, V, V, V, V);
V g_heff_2eelab_2erules_2ecodeAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecodeAt_clo;
HeffT1 g_heff_2eelab_2erules_2edelayAt_24cpr(V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayChkBy_clo;
V g_heff_2eelab_2erules_2edelayLambda(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayLambda_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayLambda_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
V g_heff_2eelab_2erules_2eentriesGo_24dps(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_24dps_clo;
V g_heff_2eelab_2erules_2efindPrim(V, V);
V g_heff_2eelab_2erules_2efindPrim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efindPrim_clo;
V g_heff_2eelab_2erules_2efreshMeta(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efreshMeta_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efreshMeta_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionElimC_24cpr(V, V, V, V, V);
V g_heff_2eelab_2erules_2efunctionFormation(V, V);
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efunctionFormation_clo;
V g_heff_2eelab_2erules_2eimplicitArg(V, V, V, V, V);
V g_heff_2eelab_2erules_2eimplicitArg_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitArg_clo;
V g_heff_2eelab_2erules_2einsertImplicits(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertImplicits_clo;
V g_heff_2eelab_2erules_2einsertInstance(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einsertInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einsertInstance_clo;
V g_heff_2eelab_2erules_2eintroGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintroGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintroGo_clo;
V g_heff_2eelab_2erules_2elambdaChk(V, V, V, V);
V g_heff_2eelab_2erules_2elambdaChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elambdaChk_clo;
HeffT1 g_heff_2eelab_2erules_2elambdaChk_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2elazySyn(V, V);
V g_heff_2eelab_2erules_2elazySyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elazySyn_clo;
V g_heff_2eelab_2erules_2eletted(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletted_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_clo;
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(V, V);
V g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940_clo;
V g_heff_2eelab_2erules_2emetaOfStx(V);
V g_heff_2eelab_2erules_2emetaOfStx_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2emetaOfStx_clo;
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365_clo;
HeffT1 g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr(V, V);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583(V, V, V);
V g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583_clo;
HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V, V);
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
HeffT1 g_heff_2eelab_2erules_2erecovering_24cpr(V);
HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate0(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate0_clo;
V g_heff_2eelab_2erules_2esumFormation_24map0(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map0_clo;
V g_heff_2eelab_2erules_2esumFormation_24map1(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map1_clo;
V g_heff_2eelab_2erules_2etriedCandidate(V, V, V, V, V);
V g_heff_2eelab_2erules_2etriedCandidate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etriedCandidate_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2edefaultsOf(V);
V g_heff_2eelab_2evalue_2edefaultsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2edefaultsOf_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1367173129x1257089258(V);
V g_list_2emap_24s1367173129x1257089258_entry(V self, V *a);
extern Clo g_list_2emap_24s1367173129x1257089258_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str0, 3, "Int");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str1, 7, "Float64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str2, 6, "String");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str3, 4, "Rune");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str4, 5, "Array");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str5, 4, "Int8");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str6, 5, "Int16");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str7, 5, "Int32");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str8, 5, "Int64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str9, 5, "UInt8");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str10, 6, "UInt16");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str11, 6, "UInt32");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str12, 6, "UInt64");
HEFF_LIT(g_heff_2eelab_2erules_2erigidFormer_24cpr_str13, 7, "Float32");

HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V v_mc_240, V v_v_241) {
top: ;
  V v_it_242 = (g_heff_2eelab_2evalue_2eforceEl(v_mc_240, v_v_241));
  switch (heff_tag_of(v_it_242)) {
  case TAG_VNeu: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_expansion_246 = heff_field(v_it_242, 3);
    heff_take_n(v_it_242, 9ULL, 5);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_expansion_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HGlobal: {
      V v_k_249 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      V v_t_2410 = heff_tr(heff_call(v_expansion_246, 1, (V[]){NTAG(TAG_MkUnit)}));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_IntoCons: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_k_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_NotApplicable: {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_249}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2410)}});
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_expansion_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_HError: {
      heff_drop(v_expansion_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_it1_243)}});
    }
  }
  case TAG_VCode: {
    V v_t_2413 = heff_field(v_it_242, 0);
    heff_take_n(v_it_242, 1ULL, 1);
    V v_it_2414 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_t_2413));
    switch (heff_tag_of(v_it_2414)) {
    case TAG_VU: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VDecode: {
      V v_it1_2416 = heff_field(v_it_2414, 0);
      heff_take_n(v_it_2414, 1ULL, 5);
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HGlobal: {
        V v_k_2422 = heff_field(v_it1_2416, 0);
        heff_take_n(v_it1_2416, 1ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_k_2422}});
      }
      case TAG_HMeta: {
        heff_take_n(v_it1_2416, 0ULL, 1);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_HError: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2416)}});
      }
    }
    case TAG_VFunction: {
      heff_take_n(v_it_2414, 0ULL, 6);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VRecord: {
      heff_take_n(v_it_2414, 0ULL, 4);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VSum: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_VPrimInt: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str0)}});
    }
    case TAG_VPrimFloat: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str1)}});
    }
    case TAG_VPrimString: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str2)}});
    }
    case TAG_VPrimRune: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str3)}});
    }
    case TAG_VPrimArray: {
      heff_take_n(v_it_2414, 0ULL, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str4)}});
    }
    case TAG_VFixed: {
      V v_w_2436 = heff_field(v_it_2414, 0);
      heff_take_n(v_it_2414, 1ULL, 1);
      V v_f_2437;
      switch (heff_tag_of(v_w_2436)) {
      case TAG_I8: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str5);
        break;
      }
      case TAG_I16: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str6);
        break;
      }
      case TAG_I32: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str7);
        break;
      }
      case TAG_I64: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str8);
        break;
      }
      case TAG_U8: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str9);
        break;
      }
      case TAG_U16: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str10);
        break;
      }
      case TAG_U32: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str11);
        break;
      }
      case TAG_U64: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str12);
        break;
      }
      case TAG_F32: {
        v_f_2437 = ((V)&g_heff_2eelab_2erules_2erigidFormer_24cpr_str13);
        break;
      }
      default: heff_nomatch(v_w_2436);
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2437}});
    }
    default: return ((HeffT2){{heff_nomatch(v_it_2414)}});
    }
  }
  case TAG_VLam: {
    heff_take_n(v_it_242, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VCons: {
    heff_take_n(v_it_242, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_VOpaque: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_it_242)}});
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2einsertImplicits_str3, 1, "_");
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args);
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einsertImplicits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einsertImplicits_entry, 6, 0};

V g_heff_2eelab_2erules_2einsertImplicits(V v_e_240, V v_sp_241, V v_m_242, V v_ty0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam0, 1, 1, (V[]){v_ty0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam1, 1, 5, (V[]){v_k_245, v_m_242, v_e_240, v_sp_241, v_hd_244})});
}
V g_heff_2eelab_2erules_2einsertImplicits_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einsertImplicits(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2erules_2einsertImplicits_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_ty0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_ty0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2einsertImplicits_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  V v_x1_2434 = heff_tr(heff_call(heff_get_n(v_x_2423, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2435;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    return v_x_2437;
  }
  default: return heff_nomatch(v_x1_2434);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2428;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2424 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2428 = v_n_2424;
    break;
  }
  case TAG_CloConst: {
    v_t_2428 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str1);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2429 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2428, v_m_242, heff_dup(v_x_2423)));
  V v_x1_2439;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2431 = heff_field(v_cod_2415, 1);
    V v_body_2432 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2439 = heff_tr(heff_call(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam3, 1, 1, (V[]){v_x_2423})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2438 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2423, 2);
    v_x1_2439 = v_body_2438;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x1_2439)) {
  case TAG_Nom: {
    V v_x_2440 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2440;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2439, 0ULL, 1);
    v_t_2443 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2442 = heff_field(v_x1_2439, 0);
    heff_take_n(v_x1_2439, 1ULL, 1);
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x1_2439);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2429, v_t_2443, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam5(V self, V *args) {
  V v_u_2459 = args[0];
  V v_x_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2459);
  V v_x1_2460 = heff_tr(heff_call(heff_get_n(v_x_2449, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2461;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    return v_x_2463;
  }
  default: return heff_nomatch(v_x1_2460);
  }
}
V g_heff_2eelab_2erules_2einsertImplicits_lam4(V self, V *args) {
  V v_x_2449 = args[0];
  V v_cod_2415 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2454;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_n_2450 = heff_dup(heff_field(v_cod_2415, 0));
    v_t_2454 = v_n_2450;
    break;
  }
  case TAG_CloConst: {
    v_t_2454 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str3);
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2455 = (g_heff_2eelab_2ememoed_2eiapp(v_t_2454, v_m_242, heff_dup(v_x_2449)));
  V v_x1_2465;
  switch (heff_tag_of(v_cod_2415)) {
  case TAG_MkClo: {
    V v_vs_2457 = heff_field(v_cod_2415, 1);
    V v_body_2458 = heff_field(v_cod_2415, 2);
    heff_take_n(v_cod_2415, 6ULL, 3);
    v_x1_2465 = heff_tr(heff_call(v_body_2458, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2457, heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam5, 1, 1, (V[]){v_x_2449})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2464 = heff_field(v_cod_2415, 0);
    heff_take_n(v_cod_2415, 1ULL, 1);
    heff_drop_rec(v_x_2449, 2);
    v_x1_2465 = v_body_2464;
    break;
  }
  default: heff_nomatch(v_cod_2415);
  }
  V v_t_2469;
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_Nom: {
    V v_x_2466 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_t_2469 = v_x_2466;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2465, 0ULL, 1);
    v_t_2469 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2468 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_t_2469 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x1_2465);
  }
  return (g_heff_2eelab_2erules_2einsertImplicits(v_e_240, v_sp_241, v_t_2455, v_t_2469, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2einsertImplicits_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_m_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_it_2411)) {
  case TAG_LikeU: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFunction: {
    V v_dom_2414 = heff_field(v_it_2411, 1);
    V v_cod_2415 = heff_field(v_it_2411, 2);
    V v_it4_2416 = heff_field(v_it_2411, 3);
    heff_take_n(v_it_2411, 14ULL, 4);
    switch (heff_tag_of(v_it4_2416)) {
    case TAG_Expl: {
      heff_drop(v_e_240);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_244, 3);
      heff_drop(v_dom_2414);
      heff_drop(v_cod_2415);
      V f_ = v_k_245;
      args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Impl: {
      V v_t_2421;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2417 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2421 = v_n_2417;
        break;
      }
      case TAG_CloConst: {
        v_t_2421 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str0);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_c_2422 = (g_heff_2eelab_2erules_2eimplicitArg(heff_dup(v_e_240), heff_dup(v_sp_241), v_x_2410, v_dom_2414, v_t_2421));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam2, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Inst: {
      heff_drop(v_x_2410);
      V v_t_2448;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_n_2444 = heff_dup(heff_field(v_cod_2415, 0));
        v_t_2448 = v_n_2444;
        break;
      }
      case TAG_CloConst: {
        v_t_2448 = ((V)&g_heff_2eelab_2erules_2einsertImplicits_str2);
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      return (g_heff_2eelab_2erules_2einsertInstance(heff_dup(v_e_240), heff_dup(v_sp_241), v_dom_2414, v_t_2448, heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2erules_2einsertImplicits_lam4, 1, 6, (V[]){v_cod_2415, v_m_242, v_e_240, v_sp_241, v_hd_244, v_k_245})));
    }
    default: return heff_nomatch(v_it4_2416);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_it_2411, 0ULL, 3);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeSum: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeInt: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFloat: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeString: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeRune: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeArray: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_it_2411, 0ULL, 1);
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_NoRules: {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_244, 3);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_m_242, v_x_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_it_2411);
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionFormation_str0, 137, "an implicit argument without a default must have a large type (a small one could never be inferred: its values are statically irrelevant)");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionFormation_str1, 83, "an implicit argument's default names definitions only, not the parameters before it");
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args); static Clo g_heff_2eelab_2erules_2efunctionFormation_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionFormation_lam12, 2, 0};
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args); static Clo g_heff_2eelab_2erules_2efunctionFormation_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionFormation_lam16, 1, 0};
V g_heff_2eelab_2erules_2efunctionFormation_lam17(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam19(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam18(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam21(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam20(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam25(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam24(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam23(V self, V *args);
V g_heff_2eelab_2erules_2efunctionFormation_lam22(V self, V *args);
Clo g_heff_2eelab_2erules_2efunctionFormation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionFormation_entry, 2, 0};

V g_heff_2eelab_2erules_2efunctionFormation(V v_x1_240, V v_cod_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Anonymous: {
    V v_dom_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Anonymous = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_240_24Anonymous, TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam0, 1, 2, (V[]){v_dom_242, heff_dup(v_cod_241)})});
  }
  case TAG_Named: {
    V v_x_2442 = heff_field(v_x1_240, 0);
    V v_dom_2443 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam5, 1, 3, (V[]){v_dom_2443, v_x_2442, heff_dup(v_cod_241)})});
  }
  case TAG_NamedImplicit: {
    V v_sp_2462 = heff_field(v_x1_240, 0);
    V v_x_2463 = heff_field(v_x1_240, 1);
    V v_dom_2464 = heff_field(v_x1_240, 2);
    V v_dflt_2465 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam9, 1, 5, (V[]){v_dom_2464, v_dflt_2465, v_sp_2462, v_x_2463, heff_dup(v_cod_241)})});
  }
  case TAG_NamedInstance: {
    V v_x_24142 = heff_field(v_x1_240, 1);
    V v_dom_24143 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam22, 1, 3, (V[]){v_dom_24143, v_x_24142, heff_dup(v_cod_241)})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2efunctionFormation(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2efunctionFormation_lam4(V self, V *args) {
  V v_u_2428 = args[0];
  V v_val_2413 = heff_env(self)[0];
  V v_val_2421 = heff_env(self)[1];
  V v_implicit_2415 = heff_env(self)[2];
  V v_dflt_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_u_2428);
  V v_x1_2429 = heff_tr(heff_call(heff_dup(v_val_2413), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2433;
  switch (heff_tag_of(v_x1_2429)) {
  case TAG_Nom: {
    V v_t_2430 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_t_2433 = ({ V a_0 = v_t_2430; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2430); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2431 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_t_2433 = ({ V a_0 = v_t_2431; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2431); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2432 = heff_field(v_x1_2429, 0);
    heff_take_n(v_x1_2429, 1ULL, 1);
    v_t_2433 = ({ V a_0 = v_t_2432; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2432); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2429);
  }
  V v_x1_2434 = heff_tr(heff_call(v_val_2421, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2438;
  switch (heff_tag_of(v_x1_2434)) {
  case TAG_Nom: {
    V v_x_2435 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    v_t_2438 = v_x_2435;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2434, 0ULL, 1);
    v_t_2438 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2437 = heff_field(v_x1_2434, 0);
    heff_take_n(v_x1_2434, 1ULL, 1);
    v_t_2438 = v_x_2437;
    break;
  }
  default: heff_nomatch(v_x1_2434);
  }
  V v_t_2439 = heff_tr(heff_call(v_val_2413, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2440 = heff_tag_n(TAG_VFunction, 6, (V[]){v_t_2433, v_t_2438, heff_tag_n(TAG_CloConst, 1, (V[]){v_t_2439}), v_implicit_2415, v_dflt_2416, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2440});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_lit_2412 = v_x_2411;
  V v_val_2413 = heff_take_field(v_lit_2412, 1);
  V v_stx_2414 = heff_get_n(v_lit_2412, 0, 2);
  V v_implicit_2415 = NTAG(TAG_Expl);
  V v_dflt_2416 = NTAG(TAG_Nothing);
  V v_g_2417 = heff_take_field(v_e_243, 1);
  heff_drop(v_g_2417);
  V v_vs_2418 = heff_get_n(heff_get_n(v_e_243, 0, 6), 2, 5);
  heff_drop(v_vs_2418);
  V v_dom_2419 = v_x_248;
  V v_stx_2420 = heff_take_field(v_dom_2419, 0);
  V v_val_2421 = heff_get_n(v_dom_2419, 1, 2);
  V v_x1_2422 = heff_tr(heff_call(heff_dup(v_val_2413), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_t_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2423); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2424 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2424); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2425); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2427 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2426, v_stx_2420, heff_tag_n(TAG_AbsConst, 1, (V[]){v_stx_2414}), heff_dup(v_implicit_2415), heff_dup(v_dflt_2416)});
  V v_x_2441 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2427, heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam4, 1, 4, (V[]){v_val_2413, v_val_2421, v_implicit_2415, v_dflt_2416})});
  V f_ = v_k_247;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_cod_241 = heff_env(self)[0];
  V v_e_243 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_249 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    v_c_2410 = heff_tr(heff_call(v_f_249, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2410;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam3, 1, 3, (V[]){v_e_243, v_x_248, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  V v_e_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam2, 1, 4, (V[]){v_cod_241, v_e_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam0(V self, V *args) {
  V v_e_243 = args[0];
  V v_dom_242 = heff_env(self)[0];
  V v_cod_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_245;
  switch (heff_tag_of(v_dom_242)) {
  case TAG_MkTyp: {
    V v_f_244 = heff_field(v_dom_242, 0);
    heff_take_n(v_dom_242, 1ULL, 1);
    v_c_245 = heff_tr(heff_call(v_f_244, 1, (V[]){heff_dup(v_e_243)}));
    break;
  }
  default: heff_nomatch(v_dom_242);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam1, 2, 3, (V[]){v_c_245, v_cod_241, v_e_243});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_e_2444 = heff_env(self)[0];
  V v_x_2442 = heff_env(self)[1];
  V v_x_2449 = heff_env(self)[2];
  V v_k_2448 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2460 = heff_get_n(heff_dup(heff_rfield(v_e_2444, 0)), 2, 5);
  V v_x_2461 = (g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(v_x_2442, v_x_2459, NTAG(TAG_Expl), NTAG(TAG_Nothing), heff_get_n(v_e_2444, 1, 6), v_t_2460, v_x_2449));
  V f_ = v_k_2448;
  args[0] = v_x_2461;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_x_2442 = heff_env(self)[0];
  V v_e_2444 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_2447 = heff_env(self)[3];
  V v_k_2448 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2449, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_2454;
  switch (heff_tag_of(v_x1_2450)) {
  case TAG_Nom: {
    V v_x_2451 = heff_field(v_x1_2450, 0);
    heff_take_n(v_x1_2450, 1ULL, 1);
    v_a_2454 = v_x_2451;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2450, 0ULL, 1);
    v_a_2454 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2453 = heff_field(v_x1_2450, 0);
    heff_take_n(v_x1_2450, 1ULL, 1);
    v_a_2454 = v_x_2453;
    break;
  }
  default: heff_nomatch(v_x1_2450);
  }
  V v_sc_2455 = (g_heff_2eelab_2eenvironment_2ebindAt(heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), heff_dup(v_x_2442), v_a_2454, heff_dup(heff_rfield(v_e_2444, 0))));
  V v_c_2458;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_2456 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_2457 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_2455, heff_dup(heff_rfield(v_e_2444, 1)), heff_dup(heff_rfield(v_e_2444, 2)), heff_dup(heff_rfield(v_e_2444, 3)), heff_dup(heff_rfield(v_e_2444, 4)), heff_dup(heff_rfield(v_e_2444, 5))});
    v_c_2458 = heff_tr(heff_call(v_f_2456, 1, (V[]){v_t_2457}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_2458;
  heff_room[0] = v_hd_2447;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam8, 1, 4, (V[]){v_e_2444, v_x_2442, v_x_2449, v_k_2448});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_x_2442 = heff_env(self)[1];
  V v_e_2444 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam7, 1, 5, (V[]){v_x_2442, v_e_2444, v_cod_241, v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam5(V self, V *args) {
  V v_e_2444 = args[0];
  V v_dom_2443 = heff_env(self)[0];
  V v_x_2442 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2446;
  switch (heff_tag_of(v_dom_2443)) {
  case TAG_MkTyp: {
    V v_f_2445 = heff_field(v_dom_2443, 0);
    heff_take_n(v_dom_2443, 1ULL, 1);
    v_c_2446 = heff_tr(heff_call(v_f_2445, 1, (V[]){heff_dup(v_e_2444)}));
    break;
  }
  default: heff_nomatch(v_dom_2443);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam6, 2, 4, (V[]){v_c_2446, v_x_2442, v_e_2444, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam12(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam16(V self, V *args) {
  V v_c0_24105 = args[0];
  return heff_get_n(v_c0_24105, 3, 9);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam17(V self, V *args) {
  V v_x_24109 = args[0];
  V v_x_24104 = heff_env(self)[0];
  V v_sp_2496 = heff_env(self)[1];
  V v_hd_24102 = heff_env(self)[2];
  V v_k_24103 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24110 = ({ V a_0 = v_x_24109; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_x_24109); r_; });
  V v_stx_24111 = heff_tr(heff_call(heff_get_n(v_t_24110, 0, 2), 1, (V[]){heff_take_field(v_x_24104, 0)}));
  V v_t_24112 = (g_heff_2eelab_2erules_2ementionsTermF_24s358032249x338352940(MK_INT(0LL), heff_dup(v_stx_24111)));
  if ((heff_dup(v_t_24112) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_24104, 2);
    heff_drop(v_stx_24111);
    heff_drop(v_t_24112);
    V v_t_24113 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(345LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionFormation_str1), v_sp_2496, NTAG(TAG_Nothing)});
    V v_t_24114 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tr(heff_call(heff_take_field(v_hd_24102, 2), 1, (V[]){v_t_24115}));
    V f_ = heff_get_n(v_hd_24102, 1, 3);
    heff_room[0] = v_t_24116;
    heff_room[1] = v_k_24103;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_2496);
    heff_drop_rec(v_hd_24102, 3);
    heff_drop(v_t_24112);
    V v_t_24117 = ({ V rv_0 = v_stx_24111; V rr_ = heff_rec_reuse_nf(v_x_24104, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V f_ = v_k_24103;
    args[0] = v_t_24117;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_lam15(V self, V *args) {
  V v_x_24104 = args[0];
  V v_hd_24102 = heff_env(self)[0];
  V v_sp_2496 = heff_env(self)[1];
  V v_k_24103 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2efunctionFormation_lam16_clo)})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_24102, 2)), 1, (V[]){v_t_24107}));
  V f_ = heff_dup(heff_rfield(v_hd_24102, 1));
  heff_room[0] = v_t_24108;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam17, 1, 4, (V[]){v_x_24104, v_sp_2496, v_hd_24102, v_k_24103});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam14(V self, V *args) {
  V v_hd_24102 = args[0];
  V v_k_24103 = args[1];
  V v_c_24101 = heff_env(self)[0];
  V v_sp_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24101;
  args[0] = heff_dup(v_hd_24102);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam15, 1, 3, (V[]){v_hd_24102, v_sp_2496, v_k_24103});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam13(V self, V *args) {
  V v_e_2498 = args[0];
  V v_a_2499 = args[1];
  V v_c_2497 = heff_env(self)[0];
  V v_sp_2496 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_24101;
  switch (heff_tag_of(v_c_2497)) {
  case TAG_MkChk: {
    V v_f_24100 = heff_field(v_c_2497, 0);
    heff_take_n(v_c_2497, 1ULL, 1);
    v_c_24101 = heff_tr(heff_call(v_f_24100, 2, (V[]){v_e_2498, v_a_2499}));
    break;
  }
  default: heff_nomatch(v_c_2497);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam14, 2, 2, (V[]){v_c_24101, v_sp_2496});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam19(V self, V *args) {
  V v_x_24125 = args[0];
  V v_k_24124 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24126 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_x_24125, 0, 2)});
  V f_ = v_k_24124;
  args[0] = v_t_24126;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam18(V self, V *args) {
  V v_hd_24123 = args[0];
  V v_k_24124 = args[1];
  V v_c_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_24122;
  args[0] = v_hd_24123;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam19, 1, 1, (V[]){v_k_24124});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam21(V self, V *args) {
  V v_x_24138 = args[0];
  V v_e_2466 = heff_env(self)[0];
  V v_x_2463 = heff_env(self)[1];
  V v_x_24128 = heff_env(self)[2];
  V v_x_2471 = heff_env(self)[3];
  V v_k_2470 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24139 = heff_get_n(heff_dup(heff_rfield(v_e_2466, 0)), 2, 5);
  V v_x_24140 = (g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(v_x_2463, v_x_24138, NTAG(TAG_Impl), v_x_24128, heff_get_n(v_e_2466, 1, 6), v_t_24139, v_x_2471));
  V f_ = v_k_2470;
  args[0] = v_x_24140;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam20(V self, V *args) {
  V v_x_24128 = args[0];
  V v_x_2471 = heff_env(self)[0];
  V v_x_2463 = heff_env(self)[1];
  V v_e_2466 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  V v_hd_2469 = heff_env(self)[4];
  V v_k_2470 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x1_24129 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2471, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_24133;
  switch (heff_tag_of(v_x1_24129)) {
  case TAG_Nom: {
    V v_x_24130 = heff_field(v_x1_24129, 0);
    heff_take_n(v_x1_24129, 1ULL, 1);
    v_a_24133 = v_x_24130;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24129, 0ULL, 1);
    v_a_24133 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24132 = heff_field(v_x1_24129, 0);
    heff_take_n(v_x1_24129, 1ULL, 1);
    v_a_24133 = v_x_24132;
    break;
  }
  default: heff_nomatch(v_x1_24129);
  }
  V v_sc_24134 = (g_heff_2eelab_2eenvironment_2ebindAt(heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), heff_dup(v_x_2463), v_a_24133, heff_dup(heff_rfield(v_e_2466, 0))));
  V v_c_24137;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_24135 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_24136 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_24134, heff_dup(heff_rfield(v_e_2466, 1)), heff_dup(heff_rfield(v_e_2466, 2)), heff_dup(heff_rfield(v_e_2466, 3)), heff_dup(heff_rfield(v_e_2466, 4)), heff_dup(heff_rfield(v_e_2466, 5))});
    v_c_24137 = heff_tr(heff_call(v_f_24135, 1, (V[]){v_t_24136}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_24137;
  heff_room[0] = v_hd_2469;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam21, 1, 5, (V[]){v_e_2466, v_x_2463, v_x_24128, v_x_2471, v_k_2470});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam11(V self, V *args) {
  V v_x_2471 = args[0];
  V v_dflt_2465 = heff_env(self)[0];
  V v_sp_2462 = heff_env(self)[1];
  V v_hd_2469 = heff_env(self)[2];
  V v_k_2470 = heff_env(self)[3];
  V v_e_2466 = heff_env(self)[4];
  V v_x_2463 = heff_env(self)[5];
  V v_cod_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2472 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2471, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x1_2476;
  switch (heff_tag_of(v_x1_2472)) {
  case TAG_Nom: {
    V v_t_2473 = heff_field(v_x1_2472, 0);
    heff_take_n(v_x1_2472, 1ULL, 1);
    v_x1_2476 = ({ V a_0 = v_t_2473; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2473); r_; });
    break;
  }
  case TAG_Describe: {
    V v_t_2474 = heff_field(v_x1_2472, 0);
    heff_take_n(v_x1_2472, 1ULL, 1);
    v_x1_2476 = ({ V a_0 = v_t_2474; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2474); r_; });
    break;
  }
  case TAG_Become: {
    V v_t_2475 = heff_field(v_x1_2472, 0);
    heff_take_n(v_x1_2472, 1ULL, 1);
    v_x1_2476 = ({ V a_0 = v_t_2475; V r_ = (g_heff_2eelab_2evalue_2elevelOf(a_0)); heff_drop(v_t_2475); r_; });
    break;
  }
  default: heff_nomatch(v_x1_2472);
  }
  V v_t_2478;
  switch (heff_tag_of(v_x1_2476)) {
  case TAG_Small: {
    switch (heff_tag_of(v_dflt_2465)) {
    case TAG_Nothing: {
      v_t_2478 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      v_t_2478 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_dflt_2465);
    }
    break;
  }
  case TAG_Large: {
    v_t_2478 = NTAG(TAG_False);
    break;
  }
  case TAG_TopL: {
    v_t_2478 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_2476);
  }
  if ((heff_dup(v_t_2478) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2471, 2);
    heff_drop(v_dflt_2465);
    heff_drop_rec(v_e_2466, 6);
    heff_drop(v_x_2463);
    heff_drop(v_cod_241);
    heff_drop(v_t_2478);
    V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(324LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionFormation_str0), v_sp_2462, NTAG(TAG_Nothing)});
    V v_t_2480 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){v_t_2481}));
    V f_ = heff_get_n(v_hd_2469, 1, 3);
    heff_room[0] = v_t_2482;
    heff_room[1] = v_k_2470;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_sp_2462);
    heff_drop(v_t_2478);
    V v_e_2483 = heff_dup(v_e_2466);
    V v_ty_2484 = heff_dup(v_x_2471);
    V v_x3_2485 = v_dflt_2465;
    V v_c_24127;
    switch (heff_tag_of(v_x3_2485)) {
    case TAG_Nothing: {
      heff_drop_rec(v_e_2483, 6);
      heff_drop_rec(v_ty_2484, 2);
      v_c_24127 = ((V)&g_heff_2eelab_2erules_2efunctionFormation_lam12_clo);
      break;
    }
    case TAG_Just: {
      V v_d_2488 = heff_field(v_x3_2485, 0);
      V v_ru_24x3_2485_24Just = heff_take_reuse_n(v_x3_2485, 1ULL, 1);
      V v_span_2489 = heff_take_field(v_d_2488, 1);
      V v_chk_2490 = heff_get_n(v_d_2488, 0, 2);
      V v_x1_2491 = heff_tr(heff_call(heff_get_n(v_ty_2484, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
      V v_a_2495;
      switch (heff_tag_of(v_x1_2491)) {
      case TAG_Nom: {
        V v_x_2492 = heff_field(v_x1_2491, 0);
        heff_take_n(v_x1_2491, 1ULL, 1);
        v_a_2495 = v_x_2492;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2491, 0ULL, 1);
        v_a_2495 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2494 = heff_field(v_x1_2491, 0);
        heff_take_n(v_x1_2491, 1ULL, 1);
        v_a_2495 = v_x_2494;
        break;
      }
      default: heff_nomatch(v_x1_2491);
      }
      V v_sp_2496 = v_span_2489;
      V v_c_2497 = v_chk_2490;
      HeffT1 v_t_24118 = ({ V b_0 = heff_tag_at_n(v_ru_24x3_2485_24Just, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam13, 2, 2, (V[]){v_c_2497, v_sp_2496})}); HeffT1 r_ = (g_heff_2eelab_2erules_2erecovering_24cpr(b_0)); heff_drop(b_0); r_; });
      V v_c_24122;
      {
        V v_field_24119 = v_t_24118.f[0];
        V v_f_24120 = v_field_24119;
        V v_t_24121 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_2483, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
        v_c_24122 = heff_tr(heff_call(v_f_24120, 2, (V[]){v_t_24121, v_a_2495}));
      }
      v_c_24127 = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam18, 2, 1, (V[]){v_c_24122});
      break;
    }
    default: heff_nomatch(v_x3_2485);
    }
    V f_ = v_c_24127;
    heff_room[0] = heff_dup(v_hd_2469);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam20, 1, 6, (V[]){v_x_2471, v_x_2463, v_e_2466, v_cod_241, v_hd_2469, v_k_2470});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2erules_2efunctionFormation_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  V v_c_2468 = heff_env(self)[0];
  V v_dflt_2465 = heff_env(self)[1];
  V v_sp_2462 = heff_env(self)[2];
  V v_e_2466 = heff_env(self)[3];
  V v_x_2463 = heff_env(self)[4];
  V v_cod_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2468;
  args[0] = heff_dup(v_hd_2469);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam11, 1, 7, (V[]){v_dflt_2465, v_sp_2462, v_hd_2469, v_k_2470, v_e_2466, v_x_2463, v_cod_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam9(V self, V *args) {
  V v_e_2466 = args[0];
  V v_dom_2464 = heff_env(self)[0];
  V v_dflt_2465 = heff_env(self)[1];
  V v_sp_2462 = heff_env(self)[2];
  V v_x_2463 = heff_env(self)[3];
  V v_cod_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2468;
  switch (heff_tag_of(v_dom_2464)) {
  case TAG_MkTyp: {
    V v_f_2467 = heff_field(v_dom_2464, 0);
    heff_take_n(v_dom_2464, 1ULL, 1);
    v_c_2468 = heff_tr(heff_call(v_f_2467, 1, (V[]){heff_dup(v_e_2466)}));
    break;
  }
  default: heff_nomatch(v_dom_2464);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam10, 2, 6, (V[]){v_c_2468, v_dflt_2465, v_sp_2462, v_e_2466, v_x_2463, v_cod_241});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam25(V self, V *args) {
  V v_x_24159 = args[0];
  V v_e_24144 = heff_env(self)[0];
  V v_x_24142 = heff_env(self)[1];
  V v_x_24149 = heff_env(self)[2];
  V v_k_24148 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_vs_24160 = heff_get_n(heff_dup(heff_rfield(v_e_24144, 0)), 2, 5);
  V v_x_24161 = (g_heff_2eelab_2ememoed_2efunctionD_24s2068334511x1917712858(v_x_24142, v_x_24159, NTAG(TAG_Inst), NTAG(TAG_Nothing), heff_get_n(v_e_24144, 1, 6), v_vs_24160, v_x_24149));
  V f_ = v_k_24148;
  args[0] = v_x_24161;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam24(V self, V *args) {
  V v_x_24149 = args[0];
  V v_x_24142 = heff_env(self)[0];
  V v_e_24144 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  V v_hd_24147 = heff_env(self)[3];
  V v_k_24148 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_24150 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_24149, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_a_24154;
  switch (heff_tag_of(v_x1_24150)) {
  case TAG_Nom: {
    V v_x_24151 = heff_field(v_x1_24150, 0);
    heff_take_n(v_x1_24150, 1ULL, 1);
    v_a_24154 = v_x_24151;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24150, 0ULL, 1);
    v_a_24154 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24153 = heff_field(v_x1_24150, 0);
    heff_take_n(v_x1_24150, 1ULL, 1);
    v_a_24154 = v_x_24153;
    break;
  }
  default: heff_nomatch(v_x1_24150);
  }
  V v_sc_24155 = (g_heff_2eelab_2eenvironment_2ebindAt(heff_tag_n(TAG_BDelayedBy, 1, (V[]){MK_INT(0LL)}), heff_dup(v_x_24142), v_a_24154, heff_dup(heff_rfield(v_e_24144, 0))));
  V v_c_24158;
  switch (heff_tag_of(v_cod_241)) {
  case TAG_MkTyp: {
    V v_f_24156 = heff_field(v_cod_241, 0);
    heff_take_n(v_cod_241, 1ULL, 1);
    V v_t_24157 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_sc_24155, heff_dup(heff_rfield(v_e_24144, 1)), heff_dup(heff_rfield(v_e_24144, 2)), heff_dup(heff_rfield(v_e_24144, 3)), heff_dup(heff_rfield(v_e_24144, 4)), heff_dup(heff_rfield(v_e_24144, 5))});
    v_c_24158 = heff_tr(heff_call(v_f_24156, 1, (V[]){v_t_24157}));
    break;
  }
  default: heff_nomatch(v_cod_241);
  }
  V f_ = v_c_24158;
  heff_room[0] = v_hd_24147;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam25, 1, 4, (V[]){v_e_24144, v_x_24142, v_x_24149, v_k_24148});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionFormation_lam23(V self, V *args) {
  V v_hd_24147 = args[0];
  V v_k_24148 = args[1];
  V v_c_24146 = heff_env(self)[0];
  V v_x_24142 = heff_env(self)[1];
  V v_e_24144 = heff_env(self)[2];
  V v_cod_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24146;
  args[0] = heff_dup(v_hd_24147);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam24, 1, 5, (V[]){v_x_24142, v_e_24144, v_cod_241, v_hd_24147, v_k_24148});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionFormation_lam22(V self, V *args) {
  V v_e_24144 = args[0];
  V v_dom_24143 = heff_env(self)[0];
  V v_x_24142 = heff_env(self)[1];
  V v_cod_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_24146;
  switch (heff_tag_of(v_dom_24143)) {
  case TAG_MkTyp: {
    V v_f_24145 = heff_field(v_dom_24143, 0);
    heff_take_n(v_dom_24143, 1ULL, 1);
    v_c_24146 = heff_tr(heff_call(v_f_24145, 1, (V[]){heff_dup(v_e_24144)}));
    break;
  }
  default: heff_nomatch(v_dom_24143);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionFormation_lam23, 2, 4, (V[]){v_c_24146, v_x_24142, v_e_24144, v_cod_241});
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayChkBy_str0, 5, "delay");
HEFF_LIT(g_heff_2eelab_2erules_2edelayChkBy_str1, 21, " waits for its type \?");
V g_heff_2eelab_2erules_2edelayChkBy_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkBy_lam4(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkBy_lam3(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkBy_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayChkBy_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayChkBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayChkBy_entry, 8, 0};

V g_heff_2eelab_2erules_2edelayChkBy(V v_waits_240, V v_e_241, V v_sp_242, V v_what_243, V v_c_244, V v_ty_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 0, 5);
  V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_e_241, 0)), 2, 5);
  return ({ V a_0 = v_t_248; V a_1 = v_t_249; V a_2 = heff_dup(v_ty_245); V a_3 = heff_dup(v_what_243); V a_4 = heff_dup(v_sp_242); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkBy_lam0, 1, 8, (V[]){v_e_241, v_sp_242, v_what_243, heff_dup(v_c_244), v_ty_245, v_waits_240, v_hd_246, v_k_247}); V r_ = (g_heff_2eelab_2erules_2efreshMeta(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_249); r_; });
}
V g_heff_2eelab_2erules_2edelayChkBy_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2edelayChkBy(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2edelayChkBy_lam2(V self, V *args) {
  V v_u_2415 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_what_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2415);
  V v_t_2416 = ({ V b_0 = heff_get_n(v_x_2410, 0, 2); V r_ = (g_heff_2eelab_2erules_2emetaOfStx(b_0)); heff_drop(b_0); r_; });
  return heff_strAppend(heff_strAppend(v_what_243, ((V)&g_heff_2eelab_2erules_2edelayChkBy_str1)), heff_intShow(v_t_2416));
}
V g_heff_2eelab_2erules_2edelayChkBy_lam4(V self, V *args) {
  V v_u_2420 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2420);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_x_2410, 1, 2)});
}
V g_heff_2eelab_2erules_2edelayChkBy_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V v_t_2421 = ({ V rv_1 = heff_clo_n(g_heff_2eelab_2erules_2edelayChkBy_lam4, 1, 1, (V[]){heff_dup(v_x_2410)}); V rr_ = heff_rec_reuse_nf(v_x_2410, 1ULL, 2, shape_stx__val, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_247;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2edelayChkBy_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_what_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2417 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_242, ((V)&g_heff_2eelab_2erules_2edelayChkBy_str0), heff_clo_n(g_heff_2eelab_2erules_2edelayChkBy_lam2, 1, 2, (V[]){heff_dup(v_x_2410), v_what_243})}), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
  V f_ = heff_get_n(v_hd_246, 1, 3);
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayChkBy_lam3, 1, 2, (V[]){v_x_2410, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2edelayChkBy_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_what_243 = heff_env(self)[2];
  V v_c_244 = heff_env(self)[3];
  V v_ty_245 = heff_env(self)[4];
  V v_waits_240 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2411 = (g_heff_2eelab_2erules_2emetaOfStx(heff_rfield(v_x_2410, 0)));
  V v_t_2412 = ({ V a_0 = v_e_241; V a_1 = heff_dup(v_sp_242); V a_2 = heff_dup(v_what_243); V a_3 = v_c_244; V a_4 = v_ty_245; V a_5 = v_t_2411; V a_6 = heff_dup(v_x_2410); V r_ = (g_heff_2eelab_2erules_2edelayedCheck(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_c_244); r_; });
  V v_c_2413 = heff_tr(heff_call(v_waits_240, 1, (V[]){v_t_2412}));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayChkBy_lam1, 1, 5, (V[]){v_sp_242, v_x_2410, v_what_243, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str3, 6, "lambda");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str4, 4, "#arg");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str5, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str6, 70, "` takes no argument: a definition of a `mutual` block is a function, `");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str7, 10, " : A -> B`");
HEFF_LIT(g_heff_2eelab_2erules_2elambdaChk_24cpr_str8, 57, "tried to check a lambda expression at a non-function type");
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam12(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam13(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2elambdaChk_24cpr(V v_waits_240, V v_sp_241, V v_x_242, V v_body_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam0, 4, 4, (V[]){v_x_242, heff_dup(v_body_243), heff_dup(v_waits_240), v_sp_241})}});
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam4(V self, V *args) {
  V v_u_2424 = args[0];
  V v_v_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_v_2419;
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam7(V self, V *args) {
  V v_u_2449 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2449);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_k_2440 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2442 = heff_take_field(v_e_244, 2);
  V v_t_2445;
  switch (heff_tag_of(v_t_2442)) {
  case TAG_ForNominative: {
    v_t_2445 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2442, 0ULL, 2);
    v_t_2445 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2442);
  }
  V v_t_2446 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
  V v_t_2447 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
  V v_t_2448 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2447, heff_dup(v_x_2412)));
  V v_x_2450 = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(v_x_242, v_x_2441, v_t_2445, heff_get_n(v_e_244, 1, 6), v_t_2446, heff_rec_n(2, shape_stx__val, (V[]){v_t_2448, heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam7, 1, 1, (V[]){v_x_2412})})));
  V f_ = v_k_2440;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam5(V self, V *args) {
  V v_hd_2439 = args[0];
  V v_k_2440 = args[1];
  V v_c_2438 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2438;
  args[0] = v_hd_2439;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam6, 1, 4, (V[]){v_e_244, v_x_2412, v_x_242, v_k_2440});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam3(V self, V *args) {
  V v_v_2419 = args[0];
  V v_scope_27_2420 = args[1];
  V v_cod_2416 = heff_env(self)[0];
  V v_body_243 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2426;
  switch (heff_tag_of(v_cod_2416)) {
  case TAG_MkClo: {
    V v_vs_2422 = heff_field(v_cod_2416, 1);
    V v_body_2423 = heff_field(v_cod_2416, 2);
    heff_take_n(v_cod_2416, 6ULL, 3);
    v_x1_2426 = heff_tr(heff_call(v_body_2423, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2422, heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam4, 1, 1, (V[]){heff_dup(v_v_2419)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2425 = heff_field(v_cod_2416, 0);
    heff_take_n(v_cod_2416, 1ULL, 1);
    v_x1_2426 = v_body_2425;
    break;
  }
  default: heff_nomatch(v_cod_2416);
  }
  V v_a_2430;
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_Nom: {
    V v_x_2427 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_a_2430 = v_x_2427;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2426, 0ULL, 1);
    v_a_2430 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2429 = heff_field(v_x1_2426, 0);
    heff_take_n(v_x1_2426, 1ULL, 1);
    v_a_2430 = v_x_2429;
    break;
  }
  default: heff_nomatch(v_x1_2426);
  }
  V v_c_2438;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2431 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    V v_t_2432 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_2435;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2419);
      v_t_2435 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2433 = heff_field(v_t_2432, 0);
      V v_sp_2434 = heff_field(v_t_2432, 1);
      V v_ru_24t_2432_24ForDescriptive = heff_take_reuse_n(v_t_2432, 3ULL, 2);
      v_t_2435 = heff_tag_at_n(v_ru_24t_2432_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2433, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2434, v_v_2419})});
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    V v_t_2436 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_2437 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2420, heff_dup(heff_rfield(v_e_244, 1)), v_t_2435, v_t_2436, heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
    v_c_2438 = heff_tr(heff_call(v_f_2431, 2, (V[]){v_t_2437, v_a_2430}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam5, 2, 4, (V[]){v_c_2438, v_e_244, v_x_2412, v_x_242});
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam9(V self, V *args) {
  V v_u_2464 = args[0];
  V v_v_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2464);
  return v_v_2457;
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam12(V self, V *args) {
  V v_u_24100 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24100);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam11(V self, V *args) {
  V v_x_2487 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2416 = heff_env(self)[2];
  V v_k_2486 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2488 = heff_take_field(v_e_244, 2);
  V v_t_2491;
  switch (heff_tag_of(v_t_2488)) {
  case TAG_ForNominative: {
    v_t_2491 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2488, 0ULL, 2);
    v_t_2491 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2488);
  }
  V v_t_2492 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
  V v_t_2493 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
  V v_t_2494 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2493, heff_dup(v_x_2412)));
  V v_t_2499;
  switch (heff_tag_of(v_cod_2416)) {
  case TAG_MkClo: {
    V v_n_2495 = heff_field(v_cod_2416, 0);
    heff_take_n(v_cod_2416, 1ULL, 3);
    v_t_2499 = v_n_2495;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2416, 0ULL, 1);
    v_t_2499 = ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str2);
    break;
  }
  default: heff_nomatch(v_cod_2416);
  }
  V v_x_24101 = (g_heff_2eelab_2ememoed_2elam(v_t_2491, heff_get_n(v_e_244, 1, 6), v_t_2492, heff_rec_n(2, shape_stx__val, (V[]){v_t_2494, heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam12, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_2499, v_x_2487})));
  V f_ = v_k_2486;
  args[0] = v_x_24101;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam10(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k_2486 = args[1];
  V v_c_2484 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2484;
  args[0] = v_hd_2485;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam11, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2416, v_k_2486});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam8(V self, V *args) {
  V v_v_2457 = args[0];
  V v_scope_27_2458 = args[1];
  V v_waits_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2416 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2417 = heff_env(self)[6];
  V v_dom_2415 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT1 v_t_2459 = ({ V a_0 = v_waits_240; V a_1 = v_sp_241; V a_2 = v_x_242; V a_3 = v_body_243; HeffT1 r_ = (g_heff_2eelab_2erules_2elambdaChk_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_waits_240); heff_drop(v_body_243); r_; });
  {
    V v_field_2460 = v_t_2459.f[0];
    V v_x1_2466;
    switch (heff_tag_of(v_cod_2416)) {
    case TAG_MkClo: {
      V v_vs_2462 = heff_dup(heff_field(v_cod_2416, 1));
      V v_body_2463 = heff_dup(heff_field(v_cod_2416, 2));
      v_x1_2466 = heff_tr(heff_call(v_body_2463, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2462, heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam9, 1, 1, (V[]){heff_dup(v_v_2457)})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2465 = heff_dup(heff_field(v_cod_2416, 0));
      v_x1_2466 = v_body_2465;
      break;
    }
    default: heff_nomatch(v_cod_2416);
    }
    V v_a_2470;
    switch (heff_tag_of(v_x1_2466)) {
    case TAG_Nom: {
      V v_x_2467 = heff_field(v_x1_2466, 0);
      heff_take_n(v_x1_2466, 1ULL, 1);
      v_a_2470 = v_x_2467;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2466, 0ULL, 1);
      v_a_2470 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2469 = heff_field(v_x1_2466, 0);
      heff_take_n(v_x1_2466, 1ULL, 1);
      v_a_2470 = v_x_2469;
      break;
    }
    default: heff_nomatch(v_x1_2466);
    }
    V v_f_2471 = v_field_2460;
    V v_t_2472 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_2475;
    switch (heff_tag_of(v_t_2472)) {
    case TAG_ForNominative: {
      v_t_2475 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2473 = heff_field(v_t_2472, 0);
      V v_sp_2474 = heff_field(v_t_2472, 1);
      V v_ru_24t_2472_24ForDescriptive = heff_take_reuse_n(v_t_2472, 3ULL, 2);
      v_t_2475 = heff_tag_at_n(v_ru_24t_2472_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2473, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2474, heff_dup(v_v_2457)})});
      break;
    }
    default: heff_nomatch(v_t_2472);
    }
    V v_t_2476 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_2482;
    switch (heff_tag_of(v_implicit_2417)) {
    case TAG_Expl: {
      heff_drop(v_v_2457);
      heff_drop(v_dom_2415);
      v_t_2482 = heff_dup(heff_rfield(v_e_244, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2457);
      heff_drop(v_dom_2415);
      v_t_2482 = heff_dup(heff_rfield(v_e_244, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_2481;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_n_2477 = heff_dup(heff_field(v_cod_2416, 0));
        v_t_2481 = v_n_2477;
        break;
      }
      case TAG_CloConst: {
        v_t_2481 = ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str1);
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_2481, v_dom_2415, v_v_2457}), heff_dup(heff_rfield(v_e_244, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2417);
    }
    V v_t_2483 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2458, heff_dup(heff_rfield(v_e_244, 1)), v_t_2475, v_t_2476, heff_dup(heff_rfield(v_e_244, 4)), v_t_2482});
    V v_c_2484 = heff_tr(heff_call(v_f_2471, 2, (V[]){v_t_2483, v_a_2470}));
    return heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam10, 2, 4, (V[]){v_c_2484, v_e_244, v_x_2412, v_cod_2416});
  }
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam13(V self, V *args) {
  V v_x_24103 = args[0];
  V v_waits_240 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_24139;
  if ((heff_dup(v_waits_240) == NTAG(TAG_True))) {
    heff_drop(v_waits_240);
    V v_t_24144;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24105 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24105)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24105, 0ULL, 1);
        v_t_24144 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24105, 0ULL, 1);
        v_t_24144 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24105, 0ULL, 1);
        v_t_24144 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24144 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24105);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24144 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    switch (heff_tag_of(v_t_24144)) {
    case TAG_True: {
      v_t_24139 = heff_bool(!(heff_dup(v_x_24103) == NTAG(TAG_True)));
      heff_drop(v_x_24103);
      break;
    }
    case TAG_False: {
      heff_drop(v_x_24103);
      v_t_24139 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_24144);
    }
  } else {
    heff_drop(v_x_24103);
    heff_drop(v_waits_240);
    v_t_24139 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_24139)) {
  case TAG_True: {
    V v_t_24126 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(v_sp_241); V a_2 = v_x_242; V a_3 = v_body_243; V r_ = (g_heff_2eelab_2erules_2elambdaChk(b_0, a_1, a_2, a_3)); heff_drop(b_0); heff_drop(v_body_243); r_; });
    return ({ V a_0 = v_e_244; V a_1 = v_sp_241; V a_2 = ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str3); V a_3 = v_t_24126; V a_4 = v_x_2412; V a_5 = v_hd_246; V a_6 = v_k_247; V r_ = (g_heff_2eelab_2erules_2edelayLambda(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_24126); r_; });
  }
  case TAG_False: {
    heff_drop(v_x_2412);
    heff_drop(v_body_243);
    heff_drop_rec(v_e_244, 6);
    V v_x_24127 = v_x_242;
    int64_t v_t_24128 = (heff_unbox_word(heff_strLength_lent(v_x_24127, 0)) - ((int64_t)4ULL));
    V v_t_24129 = heff_strSlice(heff_dup(v_x_24127), heff_box_word(v_t_24128), heff_strLength_lent(v_x_24127, 0));
    V v_msg_24133;
    if (heff_strEq_c(v_t_24129, ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str4))) {
      int64_t v_t_24130 = (heff_unbox_word(heff_strLength_lent(v_x_24127, 0)) - ((int64_t)4ULL));
      V v_f_24131 = heff_strSlice(v_x_24127, MK_INT(0LL), heff_box_word(v_t_24130));
      V v_t_24132 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str5), heff_dup(v_f_24131)), ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str6));
      v_msg_24133 = heff_strAppend(heff_strAppend(v_t_24132, v_f_24131), ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str7));
    } else {
      heff_drop(v_x_24127);
      v_msg_24133 = ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str8);
    }
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), v_msg_24133, v_sp_241, NTAG(TAG_Nothing)});
    V v_t_24135 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24136}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24137;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_24139);
  }
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_body_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_k_247 = heff_env(self)[4];
  V v_waits_240 = heff_env(self)[5];
  V v_sp_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeFunction: {
    V v_dom_2415 = heff_field(v_t_2413, 1);
    V v_cod_2416 = heff_field(v_t_2413, 2);
    V v_implicit_2417 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2418;
    switch (heff_tag_of(v_implicit_2417)) {
    case TAG_Expl: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2417);
    }
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_waits_240);
      heff_drop(v_sp_241);
      heff_drop(v_implicit_2417);
      heff_drop(v_t_2418);
      V v_t_2451 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_242), v_dom_2415, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam3, 2, 5, (V[]){v_cod_2416, v_body_243, v_e_244, v_x_2412, v_x_242})));
      V f_ = v_t_2451;
      heff_room[0] = v_hd_246;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2418);
      V v_t_2456;
      switch (heff_tag_of(v_cod_2416)) {
      case TAG_MkClo: {
        V v_n_2452 = heff_dup(heff_field(v_cod_2416, 0));
        v_t_2456 = v_n_2452;
        break;
      }
      case TAG_CloConst: {
        v_t_2456 = ((V)&g_heff_2eelab_2erules_2elambdaChk_24cpr_str0);
        break;
      }
      default: heff_nomatch(v_cod_2416);
      }
      V v_t_24102 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2456, heff_dup(v_dom_2415), heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam8, 2, 9, (V[]){v_waits_240, v_sp_241, v_x_242, v_body_243, v_cod_2416, v_e_244, v_implicit_2417, v_dom_2415, v_x_2412})));
      V f_ = v_t_24102;
      heff_room[0] = v_hd_246;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: {
    heff_drop(v_t_2413);
    return (g_heff_2eelab_2emeta_2eblockedTy(heff_dup(v_x_2412), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam13, 1, 8, (V[]){v_waits_240, v_x_2412, v_sp_241, v_x_242, v_body_243, v_e_244, v_hd_246, v_k_247})));
  }
  }
}
V g_heff_2eelab_2erules_2elambdaChk_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_body_243 = heff_env(self)[1];
  V v_waits_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elambdaChk_24cpr_lam2, 1, 7, (V[]){v_x_242, v_e_244, v_body_243, v_hd_246, v_k_247, v_waits_240, v_sp_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2etriedCandidate_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_lam0, 1, 0};
V g_heff_2eelab_2erules_2etriedCandidate_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2etriedCandidate_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_lam2, 1, 0};
V g_heff_2eelab_2erules_2etriedCandidate_lam5(V self, V *args); static Clo g_heff_2eelab_2erules_2etriedCandidate_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_lam5, 1, 0};
V g_heff_2eelab_2erules_2etriedCandidate_lam6(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam4(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam7(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam10(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam9(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam8(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam3(V self, V *args);
V g_heff_2eelab_2erules_2etriedCandidate_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2etriedCandidate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etriedCandidate_entry, 5, 0};

V g_heff_2eelab_2erules_2etriedCandidate(V v_e_240, V v_goal_241, V v_c_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etriedCandidate_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam1, 1, 5, (V[]){v_hd_243, heff_dup(v_c_242), v_e_240, v_goal_241, v_k_244})});
}
V g_heff_2eelab_2erules_2etriedCandidate_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2etriedCandidate(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam0(V self, V *args) {
  V v_st_245 = args[0];
  return v_st_245;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam2(V self, V *args) {
  V v_sv_2410 = args[0];
  return v_sv_2410;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam5(V self, V *args) {
  V v_st_2418 = args[0];
  return v_st_2418;
}
V g_heff_2eelab_2erules_2etriedCandidate_lam6(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2422, 1, 9); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_249, 1, 9); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_x_2425 = heff_bool(heff_intEq_c_lent(v_t_2423, v_t_2424, 0));
  heff_drop(v_t_2423);
  heff_drop(v_t_2424);
  V f_ = v_k_2416;
  args[0] = v_x_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2417);
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2etriedCandidate_lam5_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2420}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2421;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam6, 1, 2, (V[]){v_x_249, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam7(V self, V *args) {
  V v_s_2427 = args[0];
  V v_hd_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_s_2427);
  V f_ = heff_get_n(v_hd_243, 0, 3);
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam10(V self, V *args) {
  V v_x_2439 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2439);
  V f_ = v_k_244;
  args[0] = v_x_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2etriedCandidate_lam9(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_x_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_RestoreWaiting, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){v_t_2437}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam10, 1, 2, (V[]){v_k_244, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432 = heff_tag_n(TAG_Put, 2, (V[]){v_x_249, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2434;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam9, 1, 4, (V[]){v_x_2413, v_hd_243, v_k_244, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_goal_241 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2415;
  switch (heff_tag_of(v_c_242)) {
  case TAG_MkChk: {
    V v_f_2414 = heff_field(v_c_242, 0);
    heff_take_n(v_c_242, 1ULL, 1);
    v_c_2415 = heff_tr(heff_call(v_f_2414, 2, (V[]){v_e_240, v_goal_241}));
    break;
  }
  default: heff_nomatch(v_c_242);
  }
  V v_k_2416 = heff_dup(heff_rfield(v_hd_243, 0));
  V v_t_2426 = heff_tr(heff_call(v_c_2415, 2, (V[]){heff_dup(v_hd_243), heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam4, 1, 3, (V[]){heff_dup(v_hd_243), heff_dup(v_x_249), v_k_2416})}));
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2426, heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam7, 1, 1, (V[]){heff_dup(v_hd_243)})})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_2429}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2430;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam8, 1, 4, (V[]){v_x_249, v_hd_243, v_x_2413, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2etriedCandidate_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_goal_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_SaveDelayed, 1, (V[]){((V)&g_heff_2eelab_2erules_2etriedCandidate_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_dup(heff_rfield(v_hd_243, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2etriedCandidate_lam3, 1, 6, (V[]){v_c_242, v_e_240, v_goal_241, v_hd_243, v_x_249, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str1, 5, " and ");
HEFF_LIT(g_heff_2eelab_2erules_2eandList_str2, 2, ", ");
Clo g_heff_2eelab_2erules_2eandList_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eandList_entry, 1, 0};

V g_heff_2eelab_2erules_2eandList(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eelab_2erules_2eandList_str0);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return heff_dup(v_x_241);
    }
    case TAG_Cons: {
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Cons: {
          V v_y_245 = heff_field(v_x12_242, 0);
          return heff_strAppend(heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2eelab_2erules_2eandList_str1)), heff_dup(v_y_245));
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        V v_s_249 = heff_strAppend(heff_dup(v_x_241), ((V)&g_heff_2eelab_2erules_2eandList_str2));
        return (g_heff_2eelab_2erules_2eandList_24acc(v_x12_242, v_s_249));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eandList_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eandList(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eentriesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eentriesGo_entry, 6, 0};

V g_heff_2eelab_2erules_2eentriesGo(V v_n_240, V v_k_241, V v_places_242, V v_x4_243, V v_x5_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_k_241);
    heff_drop(v_places_242);
    heff_drop(v_x5_244);
    heff_drop(v_i_245);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      heff_drop(v_n_240);
      heff_drop(v_k_241);
      heff_drop(v_places_242);
      heff_drop(v_i_245);
      heff_drop_rec(v_m_246, 5);
      heff_drop(v_rest_247);
      heff_drop_cell(v_ru_24x4_243_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_pl_248 = heff_field(v_x5_244, 0);
      V v_pls_249 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      V v_t_2412;
      switch (heff_tag_of(v_pl_248)) {
      case TAG_Nothing: {
        v_t_2412 = heff_tr(g_heff_2eelab_2erules_2ecodeAt(heff_dup(v_n_240), heff_dup(v_k_241), heff_dup(v_places_242), heff_dup(v_m_246), heff_dup(v_i_245)));
        break;
      }
      case TAG_Just: {
        V v_p_2410 = heff_field(v_pl_248, 0);
        V v_ru_24pl_248_24Just = heff_take_reuse_n(v_pl_248, 1ULL, 1);
        V v_t_2411 = heff_intSub(heff_intSub(heff_dup(v_k_241), MK_INT(1LL)), v_p_2410);
        v_t_2412 = heff_tag_at_n(v_ru_24pl_248_24Just, TAG_SLocal, 1, (V[]){v_t_2411});
        break;
      }
      default: heff_nomatch(v_pl_248);
      }
      V v_t_2413 = heff_tag_at_n(v_ru_24x5_244_24Cons, TAG_MkPair, 2, (V[]){heff_get_n(v_m_246, 0, 5), v_t_2412});
      V v_cell_2414 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2413, heff_hole()});
      V v_u_2415 = (g_heff_2eelab_2erules_2eentriesGo_24dps(v_n_240, v_k_241, v_places_242, v_rest_247, v_pls_249, heff_box_word((heff_unbox_word(v_i_245) + ((int64_t)1ULL))), heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eentriesGo(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str0, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str1, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str2, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str3, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str4, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str5, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str6, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str7, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str8, 55, "tried to check a record expression at a non-record type");
HEFF_LIT(g_heff_2eelab_2erules_2erecordIntro_24cpr_str9, 55, "tried to check a record expression at a non-record type");
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2erecordIntro_24cpr(V v_sp_240, V v_fieldSettings_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam0, 4, 2, (V[]){v_sp_240, v_fieldSettings_241})}});
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_e0_242 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2erules_2eletted(v_e0_242, v_x_2410, v_x_2435, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_k_245 = heff_env(self)[2];
  V v_fieldSettings_241 = heff_env(self)[3];
  V v_e0_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2410)));
  switch (heff_tag_of(v_t_2411)) {
  case TAG_LikeU: {
    V v_ru_24t_2411_24LikeU = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2414 = heff_tag_at_n(v_ru_24t_2411_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2415}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2416;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2411, 0ULL, 4);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str1), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2423}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2424;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRecord: {
    V v_capture_2426 = heff_field(v_t_2411, 1);
    V v_fieldTypes_2427 = heff_field(v_t_2411, 2);
    heff_take_n(v_t_2411, 6ULL, 3);
    V v_keys_2428 = heff_take_field(v_fieldTypes_2427, 0);
    V v_values_2429 = heff_get_n(v_fieldTypes_2427, 2, 3);
    V v_t_2430 = (g_heff_2eelab_2evalue_2edefaultsOf(heff_dup(v_x_2410)));
    V v_t_2431 = (g_list_2emap_24s1367173129x1257089258(heff_dup(v_fieldSettings_241)));
    V v_t_2432 = heff_rec_n(5, shape_span__ty__keys__defaults__written, (V[]){v_sp_240, heff_dup(v_x_2410), heff_arrayToList(heff_dup(v_keys_2428)), v_t_2430, v_t_2431});
    V v_t_2433 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2428), heff_arrayToList(v_values_2429)));
    V v_c_2434 = (g_heff_2eelab_2erules_2eintroGo(heff_dup(v_e0_242), v_t_2432, NTAG(TAG_Nil), v_capture_2426, v_fieldSettings_241, v_t_2433));
    V f_ = v_c_2434;
    heff_room[0] = heff_dup(v_hd_244);
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam3, 1, 4, (V[]){v_e0_242, v_x_2410, v_hd_244, v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2411_24LikeSum = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str2), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2438 = heff_tag_at_n(v_ru_24t_2411_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2439}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2440;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2441 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str3), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2443}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2444;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2447}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2448;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2449 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2451}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2452;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2455}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2456;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2411_24LikeArray = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2459 = heff_tag_at_n(v_ru_24t_2411_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2460}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2461;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2411_24LikeFixed = heff_take_reuse_n(v_t_2411, 0ULL, 1);
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2464 = heff_tag_at_n(v_ru_24t_2411_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2465}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2466;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2410);
    heff_drop(v_fieldSettings_241);
    heff_drop(v_e0_242);
    V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(305LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2erecordIntro_24cpr_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2469}));
    V f_ = heff_get_n(v_hd_244, 1, 3);
    heff_room[0] = v_t_2470;
    heff_room[1] = v_k_245;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2411);
  }
}
V g_heff_2eelab_2erules_2erecordIntro_24cpr_lam0(V self, V *args) {
  V v_e0_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_fieldSettings_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordIntro_24cpr_lam2, 1, 5, (V[]){v_sp_240, v_hd_244, v_k_245, v_fieldSettings_241, v_e0_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2esumFormation_24map1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24map1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map1_lam0, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_24map1_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24map1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map1_lam1, 1, 0};
Clo g_heff_2eelab_2erules_2esumFormation_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24map1_entry, 2, 0};

V g_heff_2eelab_2erules_2esumFormation_24map1(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_xs_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_m_243 = heff_arrayLength_lent(v_xs_242, 0);
      V v_t_248;
      if ((heff_peek_word(v_m_243) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_242);
        v_t_248 = heff_arrayGenerate(v_m_243, ((V)&g_heff_2eelab_2erules_2esumFormation_24map1_lam0_clo));
      } else {
        V v_m_245 = heff_arrayIndex_lent(v_xs_242, MK_INT(0LL), 2);
        V v_y_246 = heff_get_n(v_m_245, 0, 2);
        V v_t_247 = heff_arrayKeepsAs_lent(v_xs_242, v_y_246, 0);
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_m_243);
          heff_drop(v_t_247);
          v_t_248 = (g_heff_2eelab_2erules_2esumFormation_24map0(MK_INT(1LL), heff_arraySet(v_xs_242, MK_INT(0LL), v_y_246)));
        } else {
          heff_drop(v_t_247);
          v_t_248 = ({ V a_0 = v_xs_242; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_243, v_y_246); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
        }
      }
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), v_t_248);
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_xs_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_m_243 = heff_arrayLength_lent(v_xs_242, 0);
    V v_t_248;
    if ((heff_peek_word(v_m_243) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_242);
      v_t_248 = heff_arrayGenerate(v_m_243, ((V)&g_heff_2eelab_2erules_2esumFormation_24map1_lam1_clo));
    } else {
      V v_m_245 = heff_arrayIndex_lent(v_xs_242, MK_INT(0LL), 2);
      V v_y_246 = heff_get_n(v_m_245, 0, 2);
      V v_t_247 = heff_arrayKeepsAs_lent(v_xs_242, v_y_246, 0);
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_m_243);
        heff_drop(v_t_247);
        v_t_248 = (g_heff_2eelab_2erules_2esumFormation_24map0(MK_INT(1LL), heff_arraySet(v_xs_242, MK_INT(0LL), v_y_246)));
      } else {
        heff_drop(v_t_247);
        v_t_248 = ({ V a_0 = v_xs_242; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_243, v_y_246); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_242); r_; });
      }
    }
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), v_t_248);
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24map1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2esumFormation_24map1(a[0], a[1]);
}
V g_heff_2eelab_2erules_2esumFormation_24map1_lam0(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_24map1_lam1(V self, V *args) {
  V v_u_244 = args[0];
  heff_drop(v_u_244);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTags_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_lam0, 2, 0};
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTags_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_lam1, 2, 0};
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args); static Clo g_heff_2eelab_2erules_2erecordTags_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_lam2, 2, 0};
V g_heff_2eelab_2erules_2erecordTags_lam4(V self, V *args);
V g_heff_2eelab_2erules_2erecordTags_lam3(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordTags_entry, 4, 0};

V g_heff_2eelab_2erules_2erecordTags(V v_e_240, V v_a_241, V v_vs_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_a_241);
    heff_drop(v_vs_242);
    return ((V)&g_heff_2eelab_2erules_2erecordTags_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_246)) {
    case TAG_MkPair: {
      V v_x_248 = heff_field(v_x41_246, 0);
      V v_tsp_249 = heff_field(v_x41_246, 1);
      V v_e_2410 = heff_dup(v_e_240);
      V v_a_2411 = heff_dup(v_a_241);
      V v_vs_2412 = heff_dup(v_vs_242);
      V v_byName_2413 = heff_take_field(v_vs_2412, 1);
      V v_values_2414 = heff_get_n(v_vs_2412, 2, 3);
      V v_x_2415 = heff_dup(v_x_248);
      V v_tsp_2416 = heff_dup(v_tsp_249);
      HeffT2 v_t_2417 = ({ V a_0 = v_byName_2413; V a_1 = v_x_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_2413); r_; });
      V v_c_2427;
      {
        V v_field_2419 = v_t_2417.f[1];
        int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
        if ((v_tag_2418 == ((int64_t)0ULL))) {
          V v_i_2420 = v_field_2419;
          V v_xs_2421 = v_values_2414;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2420, 1) && heff_intLt_c(heff_dup(v_i_2420), heff_arrayLength_lent(v_xs_2421, 0)))) {
            V v_x_2422 = heff_arrayIndex(v_xs_2421, v_i_2420);
            heff_drop(v_x_2422);
            v_c_2427 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2erecordName_clo), 5, (V[]){v_e_2410, heff_dup(v_a_2411), v_x_2415, v_tsp_2416, v_a_2411}));
          } else {
            heff_drop(v_e_2410);
            heff_drop(v_a_2411);
            heff_drop(v_x_2415);
            heff_drop(v_tsp_2416);
            heff_drop(v_i_2420);
            heff_drop(v_xs_2421);
            v_c_2427 = ((V)&g_heff_2eelab_2erules_2erecordTags_lam1_clo);
          }
        } else {
          heff_drop(v_e_2410);
          heff_drop(v_a_2411);
          heff_drop(v_values_2414);
          heff_drop(v_x_2415);
          heff_drop(v_tsp_2416);
          heff_drop(v_field_2419);
          v_c_2427 = ((V)&g_heff_2eelab_2erules_2erecordTags_lam2_clo);
        }
      }
      return heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam3, 2, 5, (V[]){v_c_2427, v_e_240, v_a_241, v_vs_242, heff_dup(v_rest_247)});
    }
    default: return heff_nomatch(v_x41_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2erecordTags(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2erecordTags_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam1(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2erecordTags_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_a_241 = heff_env(self)[1];
  V v_vs_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2428 = heff_env(self)[4];
  V v_k_2429 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2430);
  V v_t_2431 = ({ V a_0 = v_e_240; V a_1 = v_a_241; V a_2 = v_vs_242; V a_3 = v_rest_247; V r_ = (g_heff_2eelab_2erules_2erecordTags(a_0, a_1, a_2, a_3)); heff_drop(v_rest_247); r_; });
  V f_ = v_t_2431;
  heff_room[0] = v_hd_2428;
  heff_room[1] = v_k_2429;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2erecordTags_lam3(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_a_241 = heff_env(self)[2];
  V v_vs_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2427;
  args[0] = heff_dup(v_hd_2428);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2erecordTags_lam4, 1, 6, (V[]){v_e_240, v_a_241, v_vs_242, v_rest_247, v_hd_2428, v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2elazySyn_str0, 12, "builtin.Lazy");
V g_heff_2eelab_2erules_2elazySyn_lam3(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam5(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam9(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam8(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam7(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam11(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam13(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam12(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam14(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam10(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam6(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam4(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2elazySyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elazySyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elazySyn_entry, 2, 0};

V g_heff_2eelab_2erules_2elazySyn(V v_sp_240, V v_s_241) {
top: ;
  return heff_tag_n(TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam0, 1, 2, (V[]){heff_dup(v_s_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2elazySyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2elazySyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2elazySyn_lam3(V self, V *args) {
  V v_c_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_y_2410 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 2ULL, 2);
    v_t_2411 = v_y_2410;
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_t_2411; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2elazySyn_lam5(V self, V *args) {
  V v_e2_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_e2_2418);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elazySyn_lam9(V self, V *args) {
  V v_u_2442 = args[0];
  V v_t_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  V v_t_2462;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_VU: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VDecode: {
    V v_a_2448 = heff_field(v_t_2432, 4);
    heff_take_n(v_t_2432, 16ULL, 5);
    v_t_2462 = heff_tr(heff_call(v_a_2448, 1, (V[]){NTAG(TAG_MkUnit)}));
    break;
  }
  case TAG_VFunction: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VRecord: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VSum: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VPrimInt: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VPrimString: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VPrimRune: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VPrimArray: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  case TAG_VFixed: {
    v_t_2462 = heff_tag_n(TAG_VCode, 1, (V[]){v_t_2432});
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  return heff_tag_n(TAG_Nom, 1, (V[]){v_t_2462});
}
V g_heff_2eelab_2erules_2elazySyn_lam8(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_t_2439 = heff_env(self)[0];
  V v_t_2432 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2440);
  V v_t_2463 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_SCode, 1, (V[]){v_t_2439}), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam9, 1, 1, (V[]){v_t_2432})});
  V f_ = v_k_2441;
  args[0] = v_t_2463;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elazySyn_lam7(V self, V *args) {
  V v_e_2436 = args[0];
  V v_a_2437 = args[1];
  V v_t_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_a_2437);
  V v_t_2438 = heff_get_n(heff_get_n(v_e_2436, 0, 6), 0, 5);
  V v_t_2439 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2438, heff_dup(v_t_2432)));
  return heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam8, 2, 2, (V[]){v_t_2439, v_t_2432});
}
V g_heff_2eelab_2erules_2elazySyn_lam11(V self, V *args) {
  V v_u_2478 = args[0];
  V v_a_2465 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2478);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_a_2465});
}
V g_heff_2eelab_2erules_2elazySyn_lam13(V self, V *args) {
  V v_u2_2485 = args[0];
  V v_val_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u2_2485);
  V v_x1_2486 = heff_tr(heff_call(v_val_2481, 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2486)) {
  case TAG_Nom: {
    V v_x_2487 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    return v_x_2487;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2486, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2489 = heff_field(v_x1_2486, 0);
    heff_take_n(v_x1_2486, 1ULL, 1);
    return v_x_2489;
  }
  default: return heff_nomatch(v_x1_2486);
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam12(V self, V *args) {
  V v_u_2483 = args[0];
  V v_val_2471 = heff_env(self)[0];
  V v_val_2481 = heff_env(self)[1];
  V v_c_2474 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_u_2483);
  V v_t_2484 = heff_tr(heff_call(v_val_2471, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_x_2490 = heff_tag_n(TAG_VLam, 2, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam13, 1, 1, (V[]){v_val_2481}), heff_tag_n(TAG_CloConst, 1, (V[]){v_t_2484})});
  switch (heff_tag_of(v_c_2474)) {
  case TAG_N: {
    return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2490});
  }
  case TAG_De: {
    return heff_tag_n(TAG_Describe, 1, (V[]){v_x_2490});
  }
  default: return heff_nomatch(v_c_2474);
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam14(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_x_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2492);
  V f_ = v_k_2493;
  args[0] = v_x_2491;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2elazySyn_lam10(V self, V *args) {
  V v_e_2464 = args[0];
  V v_a_2465 = args[1];
  V v_m_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_elabFor_2466 = heff_take_field(v_e_2464, 2);
  V v_globals_2467 = heff_take_field(v_e_2464, 1);
  V v_scope_2468 = heff_get_n(v_e_2464, 0, 6);
  V v_lit_2469 = v_m_2435;
  V v_stx_2470 = heff_take_field(v_lit_2469, 0);
  V v_val_2471 = heff_get_n(v_lit_2469, 1, 2);
  V v_c_2474;
  switch (heff_tag_of(v_elabFor_2466)) {
  case TAG_ForNominative: {
    v_c_2474 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_elabFor_2466, 0ULL, 2);
    v_c_2474 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_elabFor_2466);
  }
  V v_g_2475 = v_globals_2467;
  heff_drop(v_g_2475);
  V v_vs_2476 = heff_take_field(v_scope_2468, 2);
  heff_drop(v_vs_2476);
  V v_t_2477 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_get_n(v_scope_2468, 0, 5), heff_dup(v_a_2465)));
  V v_gdom_2479 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2477, heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam11, 1, 1, (V[]){v_a_2465})});
  V v_stx_2480 = heff_take_field(v_gdom_2479, 0);
  V v_val_2481 = heff_get_n(v_gdom_2479, 1, 2);
  V v_t_2482 = heff_tag_n(TAG_SLam, 2, (V[]){v_stx_2480, heff_tag_n(TAG_AbsConst, 1, (V[]){v_stx_2470})});
  V v_x_2491 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2482, heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam12, 1, 3, (V[]){v_val_2471, v_val_2481, v_c_2474})});
  return heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam14, 2, 1, (V[]){v_x_2491});
}
V g_heff_2eelab_2erules_2elazySyn_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2432;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_y_2431 = heff_dup(heff_field(v_x_2429, 1));
    v_t_2432 = v_y_2431;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  V v_m_2435;
  switch (heff_tag_of(v_x_2429)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x_2429, 0);
    heff_take_n(v_x_2429, 1ULL, 2);
    v_m_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_x_2429);
  }
  HeffT1 v_t_2494 = ({ V a_0 = v_sp_240; V b_1 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam7, 2, 1, (V[]){v_t_2432})}); V a_2 = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam10, 2, 1, (V[]){v_m_2435})}); HeffT1 r_ = (g_heff_2eelab_2erules_2edelayAt_24cpr(a_0, b_1, a_2)); heff_drop(b_1); r_; });
  {
    V v_field_2495 = v_t_2494.f[0];
    V v_f_2496 = v_field_2495;
    V f_ = v_f_2496;
    heff_room[0] = v_e_242;
    heff_room[1] = v_hd_245;
    heff_room[2] = v_k_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_x_247 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2416 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2415)));
  switch (heff_tag_of(v_t_2416)) {
  case TAG_LikeU: {
    V v_ru_24t_2416_24LikeU = heff_take_reuse_n(v_t_2416, 0ULL, 1);
    heff_drop(v_x_2415);
    V v_c_2421 = ({ V a_0 = heff_dup(v_sp_240); V b_1 = heff_tag_at_n(v_ru_24t_2416_24LikeU, TAG_MkSyn, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam5, 3, 1, (V[]){v_x_247})}); V r_ = (g_heff_2eelab_2erules_2eapply(a_0, b_1)); heff_drop(b_1); r_; });
    V v_callee_2422 = (g_heff_2eelab_2erules_2efindPrim(heff_dup(v_sp_240), ((V)&g_heff_2eelab_2erules_2elazySyn_str0)));
    HeffT1 v_t_2423 = ({ V b_0 = NTAG(TAG_False); V b_1 = NTAG(TAG_False); V a_2 = v_sp_240; V a_3 = v_callee_2422; V a_4 = v_c_2421; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionElimC_24cpr(b_0, b_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(b_1); heff_drop(v_callee_2422); r_; });
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_f_2425 = v_field_2424;
      V f_ = v_f_2425;
      heff_room[0] = v_e_242;
      heff_room[1] = v_hd_245;
      heff_room[2] = v_k_246;
      if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
    }
  }
  default: {
    heff_drop(v_t_2416);
    V v_t_2428;
    switch (heff_tag_of(v_x_247)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x_247, 0);
      heff_take_n(v_x_247, 1ULL, 2);
      v_t_2428 = v_x_2426;
      break;
    }
    default: heff_nomatch(v_x_247);
    }
    return (g_heff_2eelab_2erules_2einsertImplicits(heff_dup(v_e_242), heff_dup(v_sp_240), v_t_2428, v_x_2415, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam6, 1, 4, (V[]){v_sp_240, v_e_242, v_hd_245, v_k_246})));
  }
  }
}
V g_heff_2eelab_2erules_2elazySyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_k_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam3, 1, 1, (V[]){heff_dup(v_x_247)})})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam4, 1, 5, (V[]){v_sp_240, v_x_247, v_e_242, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2elazySyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam2, 1, 4, (V[]){v_hd_245, v_sp_240, v_e_242, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2elazySyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_s_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_s_241, 0);
    heff_take_n(v_s_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_s_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2elazySyn_lam1, 2, 3, (V[]){v_c_244, v_sp_240, v_e_242});
}
HEFF_LIT(g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_str0, 7, "literal");
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr(V v_lit_240, V v_sp_241) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam0, 4, 2, (V[]){v_lit_240, v_sp_241})}});
}
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 9); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam3(V self, V *args) {
  V v_chk_2435 = args[0];
  V v_hd_2436 = args[1];
  V v_k2_2437 = args[2];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2438 = heff_tr(heff_call(v_chk_2435, 2, (V[]){heff_dup(v_hd_2436), heff_dup(heff_rfield(v_hd_2436, 0))}));
  V v_t_2439 = heff_tag_n(TAG_Delay, 3, (V[]){v_x_2410, v_t_2438, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){v_t_2440}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2441;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2433;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_VU: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VDecode: {
    V v_t1_2412 = heff_dup(heff_field(v_x_2410, 0));
    switch (heff_tag_of(v_t1_2412)) {
    case TAG_HLocal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      heff_take_n(v_t1_2412, 0ULL, 1);
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_HError: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t1_2412);
    }
    break;
  }
  case TAG_VFunction: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VRecord: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VSum: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimString: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  case TAG_VFixed: {
    v_t_2433 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
    heff_drop(v_t_2433);
    V v_c_2434 = (g_heff_2eelab_2erules_2enumLitWait_24s315224137x274005583(v_lit_240, MK_INT(1LL), heff_dup(v_sp_241)));
    return ({ V a_0 = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam3, 3, 1, (V[]){heff_dup(v_x_2410)}); V a_1 = v_e_242; V a_2 = v_sp_241; V a_3 = ((V)&g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_str0); V a_4 = v_c_2434; V a_5 = v_x_2410; V a_6 = v_hd_244; V a_7 = v_k_245; V r_ = (g_heff_2eelab_2erules_2edelayChkBy(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_c_2434); r_; });
  } else {
    heff_drop(v_t_2433);
    return (g_heff_2eelab_2erules_2enumLitAt_24s1334625166x645179365(v_lit_240, v_sp_241, v_e_242, v_x_2410, v_hd_244, v_k_245));
  }
}
V g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_lit_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2enumLitChk_24s1057141542x1131347206_24cpr_lam2, 1, 5, (V[]){v_lit_240, v_sp_241, v_e_242, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}