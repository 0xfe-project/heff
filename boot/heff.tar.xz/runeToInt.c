// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
static V prim_runeToInt_entry(V self, V *a) { (void)self; return heff_runeToInt(a[0]); }
static Clo prim_runeToInt_clo = {{0x80000000u, K_CLO, 0}, prim_runeToInt_entry, 1, 0};
V g_runeToInt_get(void);

static V g_runeToInt_val;
static int g_runeToInt_st;
static V g_runeToInt_init(void) {
  return ((V)&prim_runeToInt_clo);
}
V g_runeToInt_get(void) {
  if (g_runeToInt_st == 2) return g_runeToInt_val;
  if (g_runeToInt_st == 1) heff_fail("defined by itself");
  g_runeToInt_st = 1;
  g_runeToInt_val = heff_tr(g_runeToInt_init());
  g_runeToInt_st = 2;
  return g_runeToInt_val;
}