// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_App 13485
#define TAG_Case 4415
#define TAG_DEqn 7245
#define TAG_DSig 20444
#define TAG_DType 23752
#define TAG_DWatch 43386
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAssign 4102
#define TAG_EWith 38507
#define TAG_Get 18914
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkSep 6724
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Put 28059
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_arm 306390
#define LBL_atom 9500184
#define LBL_bind 9519364
#define LBL_blockArg 80527375
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_expr 9623228
#define LBL_head 9693863
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_patAtom 1586746071
#define LBL_pattern 1588251091
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stack 311115426
#define LBL_start 311115900
#define LBL_stmt 10036367
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_top 324559
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__i__top__stack__start[] = {LBL_toks, LBL_i, LBL_top, LBL_stack, LBL_start};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2efixed_2eallFixed_get(void);
V g_heff_2esyntax_2ecst_2eappF_24s769181331x1491704293(V, V);
V g_heff_2esyntax_2ecst_2eappF_24s769181331x1491704293_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s769181331x1491704293_clo;
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_clo;
V g_heff_2esyntax_2ecst_2earmF(V, V, V);
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2earmF_clo;
V g_heff_2esyntax_2ecst_2eatBoundary(V, V);
V g_heff_2esyntax_2ecst_2eatBoundary_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatBoundary_clo;
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(V, V);
V g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175_clo;
V g_heff_2esyntax_2ecst_2eblock(V, V, V);
V g_heff_2esyntax_2ecst_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblock_clo;
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V, V, V, V);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo;
V g_heff_2esyntax_2ecst_2ecaseStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2ecaseStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecaseStmtF_clo;
V g_heff_2esyntax_2ecst_2econdF(V, V, V);
V g_heff_2esyntax_2ecst_2econdF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econdF_clo;
V g_heff_2esyntax_2ecst_2econtinuesBlock(V, V);
V g_heff_2esyntax_2ecst_2econtinuesBlock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2econtinuesBlock_clo;
V g_heff_2esyntax_2ecst_2ecur(V);
V g_heff_2esyntax_2ecst_2ecur_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ecur_clo;
V g_heff_2esyntax_2ecst_2edeclAt(V, V, V, V);
V g_heff_2esyntax_2ecst_2edeclAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclAt_clo;
V g_heff_2esyntax_2ecst_2edeclNameLen(V, V, V);
V g_heff_2esyntax_2ecst_2edeclNameLen_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclNameLen_clo;
V g_heff_2esyntax_2ecst_2edeclStep(V);
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edeclStep_clo;
V g_heff_2esyntax_2ecst_2edefaultedF(V, V, V);
V g_heff_2esyntax_2ecst_2edefaultedF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2edefaultedF_clo;
V g_heff_2esyntax_2ecst_2eexpectAs(V, V);
V g_heff_2esyntax_2ecst_2eexpectAs_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectAs_clo;
V g_heff_2esyntax_2ecst_2eexpectKind(V, V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKind_clo;
V g_heff_2esyntax_2ecst_2eexpectKw(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectKw_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectKw_clo;
V g_heff_2esyntax_2ecst_2eexpectSym(V, V, V);
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexpectSym_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218_clo;
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(V, V);
V g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318_clo;
V g_heff_2esyntax_2ecst_2egram_get(void);
V g_heff_2esyntax_2ecst_2eifStmtF(V, V, V);
V g_heff_2esyntax_2ecst_2eifStmtF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eifStmtF_clo;
V g_heff_2esyntax_2ecst_2eisSpecTok(V);
V g_heff_2esyntax_2ecst_2eisSpecTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eisSpecTok_clo;
V g_heff_2esyntax_2ecst_2elamBinderF(V, V, V);
V g_heff_2esyntax_2ecst_2elamBinderF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinderF_clo;
V g_heff_2esyntax_2ecst_2elamBinders(V, V, V, V);
V g_heff_2esyntax_2ecst_2elamBinders_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elamBinders_clo;
V g_heff_2esyntax_2ecst_2elambdaF(V, V, V);
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elambdaF_clo;
V g_heff_2esyntax_2ecst_2elocalDecl(V, V);
V g_heff_2esyntax_2ecst_2elocalDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elocalDecl_clo;
V g_heff_2esyntax_2ecst_2emanyGo(V, V, V, V);
V g_heff_2esyntax_2ecst_2emanyGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyGo_clo;
V g_heff_2esyntax_2ecst_2emanyParams(V, V, V);
V g_heff_2esyntax_2ecst_2emanyParams_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emanyParams_clo;
V g_heff_2esyntax_2ecst_2emutualDecl(V, V);
V g_heff_2esyntax_2ecst_2emutualDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2emutualDecl_clo;
V g_heff_2esyntax_2ecst_2enext(V, V);
V g_heff_2esyntax_2ecst_2enext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enext_clo;
V g_heff_2esyntax_2ecst_2enextN(V, V, V);
V g_heff_2esyntax_2ecst_2enextN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2enextN_clo;
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581_clo;
HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V, V);
V g_heff_2esyntax_2ecst_2ereadH_get(void);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(V, V, V);
V g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353_clo;
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(V, V);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo;
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(V, V, V, V, V, V);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn(V, V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo;
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(V, V, V);
V g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617_clo;
V g_heff_2esyntax_2ecst_2especToksGo(V, V, V);
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2especToksGo_clo;
V g_heff_2esyntax_2ecst_2estartsAtom(V);
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2estartsAtom_clo;
V g_heff_2esyntax_2ecst_2etokAt(V, V);
V g_heff_2esyntax_2ecst_2etokAt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etokAt_clo;
V g_heff_2esyntax_2ecst_2etryF(V, V, V);
V g_heff_2esyntax_2ecst_2etryF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etryF_clo;
V g_heff_2esyntax_2ecst_2etypeDecl(V, V, V);
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2etypeDecl_clo;
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(V, V);
V g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213_clo;
V g_heff_2esyntax_2ecst_2ewithF(V, V, V);
V g_heff_2esyntax_2ecst_2ewithF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2ewithF_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
HeffT2 g_list_2efind_24s1236173780x2048419812_24cpr(V, V, V, V, V, V, V, V, V, V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str0, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str1, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str2, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str3, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str5, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str6, 10, "expected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str7, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str8, 26, "the end of the declaration");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str11, 7, "`, not ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eexpectSym_str12, 10, "expected `");
V g_heff_2esyntax_2ecst_2eexpectSym_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eexpectSym_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eexpectSym_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eexpectSym(V v_x_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2eexpectSym_lam0, 1, 3, (V[]){v_x_240, v_hd_241, v_k_242})});
}
V g_heff_2esyntax_2ecst_2eexpectSym_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eexpectSym(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eexpectSym_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str0))) {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), heff_dup(v_x_240))) {
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_x_240);
      return (g_heff_2esyntax_2ecst_2enext(v_hd_241, v_k_242));
    } else {
      V v_t_2410;
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str1))) {
        v_t_2410 = ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str2);
      } else {
        V v_t_249 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str3));
        v_t_2410 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str4), v_t_249);
      }
      V v_t_2411 = heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str5), v_t_2410));
      V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
      V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str6), v_t_2411), v_t_2412, NTAG(TAG_Nothing)});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2414}));
      V f_ = heff_get_n(v_hd_241, 1, 3);
      heff_room[0] = v_t_2415;
      heff_room[1] = v_k_242;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  } else {
    V v_t_2418;
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str7))) {
      v_t_2418 = ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str8);
    } else {
      V v_t_2417 = heff_strAppend(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2eexpectSym_str9));
      v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str10), v_t_2417);
    }
    V v_t_2419 = heff_strAppend(v_x_240, heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str11), v_t_2418));
    V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_245, 3), heff_get_n(v_x_245, 4, 9)});
    V v_t_2421 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eexpectSym_str12), v_t_2419), v_t_2420, NTAG(TAG_Nothing)});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){v_t_2422}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2423;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str0, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str1, 3, "str");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str2, 4, "rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str3, 3, "int");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str4, 5, "float");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str5, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str6, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str7, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str8, 7, "abandon");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str9, 5, "Array");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str10, 4, "data");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str11, 6, "String");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str12, 4, "Rune");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str13, 3, "Int");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str14, 7, "Float64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str15, 4, "Type");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str16, 4, "Int8");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str17, 5, "Int16");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str18, 5, "Int32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str19, 5, "Int64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str20, 5, "UInt8");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str21, 6, "UInt16");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str22, 6, "UInt32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str23, 6, "UInt64");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str24, 7, "Float32");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str25, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str26, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str27, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str28, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str29, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str30, 5, "punct");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str31, 1, "(");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str32, 1, "{");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str33, 1, "[");
HEFF_LIT(g_heff_2esyntax_2ecst_2estartsAtom_str34, 2, "b[");
Clo g_heff_2esyntax_2ecst_2estartsAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2estartsAtom_entry, 1, 0};

V g_heff_2esyntax_2ecst_2estartsAtom(V v_t_240) {
top: ;
  V v_t_241 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 0))}));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str0), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str2), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str4), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str6), v_t_244})});
  V v_t_246 = ({ V a_0 = v_t_241; V a_1 = v_t_245; V r_ = (g_list_2eany(a_0, a_1)); heff_drop_tag(v_t_245, 2); r_; });
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 9);
    heff_drop(v_t_246);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_246);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str7))) {
      V v_t_248 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str8), NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str10), v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str12), v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str13), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str14), v_t_2411})});
      V v_t_2413 = ({ V a_0 = v_t_248; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2estartsAtom_str15), v_t_2412}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_240, 9);
        heff_drop(v_t_2413);
        return NTAG(TAG_True);
      } else {
        heff_drop(v_t_2413);
        HeffT2 v_t_2414 = (g_list_2efind_24s1236173780x2048419812_24cpr(((V)&g_heff_2esyntax_2ecst_2estartsAtom_str16), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str17), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str18), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str19), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str20), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str21), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str22), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str23), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str24), heff_rfield(v_t_240, 1), heff_dup(g_heff_2eelab_2efixed_2eallFixed_get())));
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          V v_ret_24bool = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) ? ({ V v_x_2418 = heff_dup(v_field_2416); int c_ = 1; heff_drop(v_x_2418); c_; }) : (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str25)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str26)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str27)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str28)) || heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str29))))))));
          heff_drop_rec(v_t_240, 9);
          heff_drop(v_field_2416);
          return v_ret_24bool;
        }
      }
    } else {
      V v_ret_24bool = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 0)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str30)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str31)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str32)) || (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str33)) || heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2ecst_2estartsAtom_str34)))))));
      heff_drop_rec(v_t_240, 9);
      return v_ret_24bool;
    }
  }
}
V g_heff_2esyntax_2ecst_2estartsAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2estartsAtom(a[0]);
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry, 6, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(V v_lit_240, V v_sep_241, V v_items_242, V v_seps_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam0, 1, 6, (V[]){heff_dup(v_sep_241), v_hd_244, v_lit_240, v_items_242, v_seps_243, v_k_245})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_sep_241 = heff_env(self)[1];
  V v_items_242 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_lit_240; V a_1 = v_sep_241; V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_items_242}); V a_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_seps_243}); V a_4 = v_hd_244; V a_5 = v_k_245; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_sep_241); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_sep_241 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2edefaultedF(heff_dup(v_lit_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam2, 1, 7, (V[]){v_lit_240, v_sep_241, v_items_242, v_x_2410, v_seps_243, v_hd_244, v_k_245})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_sep_241 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_items_242 = heff_env(self)[3];
  V v_seps_243 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_248, 1, 9), heff_dup(v_sep_241))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_244), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s969225128x209992031_lam1, 1, 6, (V[]){v_lit_240, v_hd_244, v_sep_241, v_items_242, v_seps_243, v_k_245})));
  } else {
    heff_drop(v_sep_241);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_lit_240);
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_242));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_243));
    V v_x_2414 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2412, v_t_2413});
    V f_ = v_k_245;
    args[0] = v_x_2414;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2especToksGo_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2especToksGo_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2especToksGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2especToksGo_entry, 3, 0};

V g_heff_2esyntax_2ecst_2especToksGo(V v_acc_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2especToksGo_lam0, 1, 3, (V[]){v_hd_241, v_acc_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2especToksGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2especToksGo(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2especToksGo_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_acc_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2especToksGo(heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_acc_240}), v_hd_241, v_k_242));
}
V g_heff_2esyntax_2ecst_2especToksGo_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = (g_heff_2esyntax_2ecst_2eisSpecTok(v_x_245));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2especToksGo_lam1, 1, 3, (V[]){v_acc_240, v_hd_241, v_k_242})));
  } else {
    heff_drop_rec(v_hd_241, 3);
    heff_drop(v_t_246);
    V v_x_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    V f_ = v_k_242;
    args[0] = v_x_248;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2elambdaF_str0, 2, "->");
V g_heff_2esyntax_2ecst_2elambdaF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2elambdaF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2elambdaF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2elambdaF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2elambdaF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2elambdaF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2elambdaF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_x_246 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_tag_n(TAG_Lam, 4, (V[]){v_x_243, heff_tag_n(TAG_Cons, 2, (V[]){v_x_244, v_x_245}), v_x_246, v_x_247});
  V f_ = v_k_242;
  args[0] = v_t_248;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2elambdaF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_k_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam4, 1, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2elambdaF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2elambdaF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam3, 1, 6, (V[]){v_g_240, v_hd_241, v_x_243, v_x_244, v_x_245, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2elamBinders(heff_dup(v_g_240), NTAG(TAG_Nil), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_x_243, v_x_244, v_k_242})));
}
V g_heff_2esyntax_2ecst_2elambdaF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2elamBinderF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2elambdaF_lam1, 1, 4, (V[]){v_g_240, v_hd_241, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtF_str0, 4, "then");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtF_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eifStmtF_str2, 4, "else");
V g_heff_2esyntax_2ecst_2eifStmtF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eifStmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eifStmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eifStmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2eifStmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2eifStmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eifStmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam7(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_If, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_2413, v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam6(V self, V *args) {
  V v_x_2413 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = heff_get_n(v_g_240, 15, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam7, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam5(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_x_246 = heff_env(self)[5];
  V v_hd_241 = heff_env(self)[6];
  V v_g_240 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_249, 0)), ((V)&g_heff_2esyntax_2ecst_2eifStmtF_str1))) {
    if (heff_strEq_c(heff_get_n(v_x_249, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eifStmtF_str2))) {
      if ((heff_dup(v_x_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_2410);
        heff_drop_rec(v_hd_241, 3);
        heff_drop_rec(v_g_240, 17);
        V f_ = v_k_242;
        args[0] = heff_tag_n(TAG_IfThen, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x_2410);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam6, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246})));
      }
    } else {
      heff_drop(v_x_2410);
      heff_drop_rec(v_hd_241, 3);
      heff_drop_rec(v_g_240, 17);
      V f_ = v_k_242;
      args[0] = heff_tag_n(TAG_IfThen, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_249, 9);
    heff_drop_rec(v_hd_241, 3);
    heff_drop_rec(v_g_240, 17);
    V f_ = v_k_242;
    args[0] = heff_tag_n(TAG_IfThen, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_246});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam4(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_x_246 = heff_env(self)[5];
  V v_g_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam5, 1, 8, (V[]){v_x_249, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_hd_241, v_g_240})));
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_g_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_247}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_248;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam4, 1, 7, (V[]){v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = heff_dup(heff_rfield(v_g_240, 15));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam3, 1, 6, (V[]){v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_g_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2eifStmtF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2eifStmtF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2econdF(heff_dup(v_g_240), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2eifStmtF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ecaseStmtF_str0, 2, "of");
HEFF_LIT(g_heff_2esyntax_2ecst_2ecaseStmtF_str1, 2, "->");
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ecaseStmtF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ecaseStmtF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ecaseStmtF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ecaseStmtF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam6(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_EAlt, 3, (V[]){v_x_248, v_x_249, v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam5(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_x_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 15, 17);
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam6, 1, 3, (V[]){v_k_247, v_x_248, v_x_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam4(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2ecaseStmtF_str1), heff_dup(v_hd_246), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam5, 1, 4, (V[]){v_g_240, v_hd_246, v_k_247, v_x_248})));
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam3(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_dup(heff_rfield(v_g_240, 5));
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam4, 1, 3, (V[]){v_hd_246, v_g_240, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam7(V self, V *args) {
  V v_x_2411 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_Case, 4, (V[]){v_x_243, v_x_244, v_x_245, v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eblock(heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam3, 2, 1, (V[]){v_g_240}), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam7, 1, 4, (V[]){v_k_242, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2ecaseStmtF_str0), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam2, 1, 5, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2ecaseStmtF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 0));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ecaseStmtF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str0, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str1, 33, "the name of what the `with` holds");
HEFF_LIT(g_heff_2esyntax_2ecst_2ewithF_str2, 2, "do");
V g_heff_2esyntax_2ecst_2ewithF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2ewithF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2ewithF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2ewithF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2ewithF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam0, 1, 3, (V[]){v_g_240, v_hd_241, v_k_242})));
}
V g_heff_2esyntax_2ecst_2ewithF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2ewithF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2ewithF_lam5(V self, V *args) {
  V v_x_248 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  V v_x_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EWith, 6, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247, v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2ewithF_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  V v_x_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2esyntax_2ecst_2eblock(heff_get_n(v_g_240, 14, 17), v_hd_241, heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam5, 1, 6, (V[]){v_k_242, v_x_243, v_x_244, v_x_245, v_x_246, v_x_247})));
}
V g_heff_2esyntax_2ecst_2ewithF_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_x_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2esyntax_2ecst_2eexpectKw(((V)&g_heff_2esyntax_2ecst_2ewithF_str2), heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam4, 1, 7, (V[]){v_g_240, v_hd_241, v_k_242, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2ewithF_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2ewithF_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2ewithF_str1); V a_2 = heff_dup(v_hd_241); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam3, 1, 6, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244, v_x_245}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
V g_heff_2esyntax_2ecst_2ewithF_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectAs(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam2, 1, 5, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2ewithF_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = heff_dup(heff_rfield(v_g_240, 13));
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2ewithF_lam1, 1, 4, (V[]){v_hd_241, v_g_240, v_k_242, v_x_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str1, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str3, 4, "case");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str5, 3, "try");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str6, 3, "var");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str7, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str8, 2, ":=");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str9, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str10, 4, "with");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str11, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str12, 4, "with");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str13, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2earmF_str14, 4, "with");
V g_heff_2esyntax_2ecst_2earmF_lam1(V self, V *args); static Clo g_heff_2esyntax_2ecst_2earmF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_lam1, 1, 0};
V g_heff_2esyntax_2ecst_2earmF_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2earmF_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2earmF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2earmF_entry, 3, 0};

V g_heff_2esyntax_2ecst_2earmF(V v_g_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_243}));
  return heff_tail(heff_dup(heff_rfield(v_hd_241, 1)), 2, (V[]){v_t_244, heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam0, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})});
}
V g_heff_2esyntax_2ecst_2earmF_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2earmF(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2earmF_lam1(V self, V *args) {
  V v_s_246 = args[0];
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_s_246, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_246, v_t_247));
}
V g_heff_2esyntax_2ecst_2earmF_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_242;
  args[0] = heff_tag_n(TAG_EAssign, 3, (V[]){v_x_2420, v_x_2421, v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2earmF_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = heff_get_n(v_g_240, 0, 17);
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam5, 1, 3, (V[]){v_k_242, v_x_2420, v_x_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2earmF_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam4, 1, 4, (V[]){v_g_240, v_hd_241, v_k_242, v_x_2420})));
}
V g_heff_2esyntax_2ecst_2earmF_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2earmF_str1))));
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2410, 9);
    heff_drop_rec(v_x_245, 9);
    heff_drop(v_t_2412);
    return (g_heff_2esyntax_2ecst_2eifStmtF(v_g_240, v_hd_241, v_k_242));
  } else {
    heff_drop(v_t_2412);
    V v_t_2414 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str2)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2earmF_str3))));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2410, 9);
      heff_drop_rec(v_x_245, 9);
      heff_drop(v_t_2414);
      return (g_heff_2esyntax_2ecst_2ecaseStmtF(v_g_240, v_hd_241, v_k_242));
    } else {
      heff_drop(v_t_2414);
      V v_t_2416 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_x_245, 1)), ((V)&g_heff_2esyntax_2ecst_2earmF_str5))));
      if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_x_245, 9);
        heff_drop(v_t_2416);
        return (g_heff_2esyntax_2ecst_2etryF(v_g_240, v_hd_241, v_k_242));
      } else {
        heff_drop(v_t_2416);
        if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str6))) {
          if (heff_strEq_c(heff_dup(heff_rfield(v_x_2410, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str7))) {
            if (heff_strEq_c(heff_get_n(v_x_2410, 1, 9), ((V)&g_heff_2esyntax_2ecst_2earmF_str8))) {
              heff_drop_rec(v_x_245, 9);
              return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_241), heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam3, 1, 3, (V[]){v_hd_241, v_g_240, v_k_242})));
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str9))) {
                if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2earmF_str10))) {
                  return (g_heff_2esyntax_2ecst_2ewithF(v_g_240, v_hd_241, v_k_242));
                } else {
                  V f_ = heff_get_n(v_g_240, 0, 17);
                  heff_room[0] = v_hd_241;
                  heff_room[1] = v_k_242;
                  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                }
              } else {
                heff_drop_rec(v_x_245, 9);
                V f_ = heff_get_n(v_g_240, 0, 17);
                heff_room[0] = v_hd_241;
                heff_room[1] = v_k_242;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            }
          } else {
            heff_drop_rec(v_x_2410, 9);
            if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str11))) {
              if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2earmF_str12))) {
                return (g_heff_2esyntax_2ecst_2ewithF(v_g_240, v_hd_241, v_k_242));
              } else {
                V f_ = heff_get_n(v_g_240, 0, 17);
                heff_room[0] = v_hd_241;
                heff_room[1] = v_k_242;
                if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
              }
            } else {
              heff_drop_rec(v_x_245, 9);
              V f_ = heff_get_n(v_g_240, 0, 17);
              heff_room[0] = v_hd_241;
              heff_room[1] = v_k_242;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          }
        } else {
          heff_drop_rec(v_x_2410, 9);
          if (heff_strEq_c(heff_dup(heff_rfield(v_x_245, 0)), ((V)&g_heff_2esyntax_2ecst_2earmF_str13))) {
            if (heff_strEq_c(heff_get_n(v_x_245, 1, 9), ((V)&g_heff_2esyntax_2ecst_2earmF_str14))) {
              return (g_heff_2esyntax_2ecst_2ewithF(v_g_240, v_hd_241, v_k_242));
            } else {
              V f_ = heff_get_n(v_g_240, 0, 17);
              heff_room[0] = v_hd_241;
              heff_room[1] = v_k_242;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          } else {
            heff_drop_rec(v_x_245, 9);
            V f_ = heff_get_n(v_g_240, 0, 17);
            heff_room[0] = v_hd_241;
            heff_room[1] = v_k_242;
            if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
            return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2earmF_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2earmF_lam1_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2earmF_lam2, 1, 4, (V[]){v_x_245, v_g_240, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry, 5, 0};

V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(V v_sep_240, V v_items_241, V v_seps_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam0, 1, 5, (V[]){heff_dup(v_sep_240), v_hd_243, v_items_241, v_seps_242, v_k_244})});
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_items_241 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_hd_243 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return ({ V a_0 = v_sep_240; V a_1 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_items_241}); V a_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_249, v_seps_242}); V a_3 = v_hd_243; V a_4 = v_k_244; V r_ = (g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_240); r_; });
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_sep_240 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eupdateSettingF_24s1667964347x889365213(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam2, 1, 6, (V[]){v_sep_240, v_items_241, v_x_249, v_seps_242, v_hd_243, v_k_244})));
}
V g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_sep_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_items_241 = heff_env(self)[2];
  V v_seps_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (heff_strEq_c(heff_get_n(v_x_247, 1, 9), heff_dup(v_sep_240))) {
    return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_243), heff_clo_n(g_heff_2esyntax_2ecst_2esepGo_24s852119717x1280416660_lam1, 1, 5, (V[]){v_hd_243, v_sep_240, v_items_241, v_seps_242, v_k_244})));
  } else {
    heff_drop(v_sep_240);
    heff_drop_rec(v_hd_243, 3);
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_241));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_seps_242));
    V v_x_2413 = heff_tag_n(TAG_MkSep, 2, (V[]){v_t_2411, v_t_2412});
    V f_ = v_k_244;
    args[0] = v_x_2413;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str1, 2, "do");
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry, 8, 0};

V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_lit_245, V v_lit_246, V v_hd_247) {
top: ;
  return (g_heff_2esyntax_2ecst_2eatomF_24s1316312090x1966012175(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam0, 1, 8, (V[]){v_hd_247, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Do, 2, (V[]){v_x_2421, v_x_2422}), NTAG(TAG_Nil)});
  V v_t_2424 = (g_prelude_2e_2b_2b(v_x_249, v_t_2423));
  V v_x_2425 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_t_2424});
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_x_2425}), v_lit_245});
  return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2426, v_lit_246));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2esyntax_2ecst_2eblock(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 14)), v_hd_247, heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam5, 1, 10, (V[]){v_x_2421, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  V v_hd_247 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2414 = heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 16));
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_2412, 0)), ((V)&g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str0))) {
      if (heff_strEq_c(heff_get_n(v_x_2412, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_str1))) {
        if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
          heff_drop(v_x_2413);
          heff_drop_rec(v_hd_247, 3);
          V v_t_2419;
          switch (heff_tag_of(v_x_249)) {
          case TAG_Nil: {
            v_t_2419 = v_x_248;
            break;
          }
          case TAG_Cons: {
            v_t_2419 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_x_249});
            break;
          }
          default: heff_nomatch(v_x_249);
          }
          V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_t_2419}), v_lit_245});
          return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2420, v_lit_246));
        } else {
          heff_drop(v_x_2413);
          return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam4, 1, 10, (V[]){v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
        }
      } else {
        heff_drop(v_x_2413);
        heff_drop_rec(v_hd_247, 3);
        V v_t_2429;
        switch (heff_tag_of(v_x_249)) {
        case TAG_Nil: {
          v_t_2429 = v_x_248;
          break;
        }
        case TAG_Cons: {
          v_t_2429 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_x_249});
          break;
        }
        default: heff_nomatch(v_x_249);
        }
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_t_2429}), v_lit_245});
        return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2430, v_lit_246));
      }
    } else {
      heff_drop(v_x_2413);
      heff_drop_rec(v_x_2412, 9);
      heff_drop_rec(v_hd_247, 3);
      V v_t_2433;
      switch (heff_tag_of(v_x_249)) {
      case TAG_Nil: {
        v_t_2433 = v_x_248;
        break;
      }
      case TAG_Cons: {
        v_t_2433 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_x_249});
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_t_2433}), v_lit_245});
      return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2434, v_lit_246));
    }
  } else {
    heff_drop(v_x_2413);
    heff_drop_rec(v_x_2412, 9);
    heff_drop_rec(v_hd_247, 3);
    heff_drop(v_t_2414);
    V v_t_2437;
    switch (heff_tag_of(v_x_249)) {
    case TAG_Nil: {
      v_t_2437 = v_x_248;
      break;
    }
    case TAG_Cons: {
      v_t_2437 = heff_tag_n(TAG_App, 2, (V[]){v_x_248, v_x_249});
      break;
    }
    default: heff_nomatch(v_x_249);
    }
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_OpRhs, 2, (V[]){v_lit_244, v_t_2437}), v_lit_245});
    return (g_heff_2esyntax_2ecst_2eoperandsF_24s593312011x228321581(v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_t_2438, v_lit_246));
  }
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_248 = heff_env(self)[2];
  V v_lit_244 = heff_env(self)[3];
  V v_lit_245 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_lit_241 = heff_env(self)[6];
  V v_lit_242 = heff_env(self)[7];
  V v_lit_243 = heff_env(self)[8];
  V v_lit_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2esyntax_2ecst_2eatBoundary(heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam3, 1, 11, (V[]){v_x_2412, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246, v_hd_247})));
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_lit_244 = heff_env(self)[2];
  V v_lit_245 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_lit_242 = heff_env(self)[6];
  V v_lit_243 = heff_env(self)[7];
  V v_lit_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_247, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_247, 1));
  heff_room[0] = v_t_2411;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam2, 1, 10, (V[]){v_hd_247, v_x_249, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_lit_244 = heff_env(self)[1];
  V v_lit_245 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_lit_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 4)), NTAG(TAG_Nil), heff_dup(v_hd_247), heff_clo_n(g_heff_2esyntax_2ecst_2eappF_24s928609566x270434852_lam1, 1, 9, (V[]){v_hd_247, v_x_248, v_lit_244, v_lit_245, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_246})));
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str0, 1, "\\");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str1, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str2, 3, "let");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str3, 2, "if");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str4, 2, "do");
HEFF_LIT(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str5, 4, "case");
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_entry, 2, 0};

V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_Nil: {
    v_t_2415 = v_x_2411;
    break;
  }
  case TAG_Cons: {
    v_t_2415 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2411, v_x_2412});
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V f_ = v_k_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam2, 1, 2, (V[]){v_x_2411, v_k_241})));
}
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Nil: {
    v_t_2420 = v_x_2416;
    break;
  }
  case TAG_Cons: {
    v_t_2420 = heff_tag_n(TAG_Ops, 2, (V[]){v_x_2416, v_x_2417});
    break;
  }
  default: heff_nomatch(v_x_2417);
  }
  V f_ = v_k_241;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2esegOperandsF_24s788167958x933439353(NTAG(TAG_Nil), v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam4, 1, 2, (V[]){v_x_2416, v_k_241})));
}
V g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str0))) {
    heff_drop_rec(v_x_244, 9);
    return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, v_k_241));
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str1))) {
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_x_244, 1, 9)}));
      V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str2), NTAG(TAG_Nil)});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str4), v_t_248})});
      V v_t_2410 = ({ V a_0 = v_t_247; V b_1 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_str5), v_t_249}); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2eexprF_24s1609445100x971489318(v_hd_240, v_k_241));
      } else {
        heff_drop(v_t_2410);
        return (g_heff_2esyntax_2ecst_2eappF_24s769181331x1491704293(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
      }
    } else {
      heff_drop_rec(v_x_244, 9);
      return (g_heff_2esyntax_2ecst_2eappF_24s769181331x1491704293(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2esegValueF_24s457889238x1239814650_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
    }
  }
}
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str1, 18, "the name of a type");
HEFF_LIT(g_heff_2esyntax_2ecst_2etypeDecl_str2, 1, "=");
V g_heff_2esyntax_2ecst_2etypeDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2etypeDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2etypeDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2etypeDecl_entry, 3, 0};

V g_heff_2esyntax_2ecst_2etypeDecl(V v_hd_240, V v_k_241, V v_z_242) {
top: ;
  V v_t_248 = heff_tr(g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})));
  return heff_tail(v_t_248, 1, (V[]){v_z_242});
}
V g_heff_2esyntax_2ecst_2etypeDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2etypeDecl(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam4(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_x_245 = heff_env(self)[3];
  V v_x_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DType, 5, (V[]){v_x_243, v_x_244, v_x_245, v_x_246, v_x_247});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam3(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam4, 1, 5, (V[]){v_k_241, v_x_243, v_x_244, v_x_245, v_x_246})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam2(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2etypeDecl_str2), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam3, 1, 5, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244, v_x_245})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyParams(NTAG(TAG_Nil), heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam2, 1, 4, (V[]){v_hd_240, v_k_241, v_x_243, v_x_244})));
}
V g_heff_2esyntax_2ecst_2etypeDecl_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = ((V)&g_heff_2esyntax_2ecst_2etypeDecl_str0); V a_1 = ((V)&g_heff_2esyntax_2ecst_2etypeDecl_str1); V a_2 = heff_dup(v_hd_240); V a_3 = heff_clo_n(g_heff_2esyntax_2ecst_2etypeDecl_lam1, 1, 3, (V[]){v_hd_240, v_k_241, v_x_243}); V r_ = (g_heff_2esyntax_2ecst_2eexpectKind(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
}
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str1, 33, "a declaration cannot start with `");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str2, 1, ":");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str3, 1, "=");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str4, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2esigOrEqn_str5, 5, "where");
V g_heff_2esyntax_2ecst_2esigOrEqn_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam2(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam2, 1, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam8(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam7(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam6(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam16(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam15(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam14(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam17(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam17, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam18(V self, V *args); static Clo g_heff_2esyntax_2ecst_2esigOrEqn_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_lam18, 2, 0};
V g_heff_2esyntax_2ecst_2esigOrEqn_lam19(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam13(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam12(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam11(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam10(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam9(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam5(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2esigOrEqn_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2esigOrEqn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2esigOrEqn_entry, 4, 0};

V g_heff_2esyntax_2ecst_2esigOrEqn(V v_item_240, V v_t_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam0_clo)})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam1, 1, 4, (V[]){v_hd_242, v_t_241, v_k_243, v_item_240})});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2esigOrEqn(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam0(V self, V *args) {
  V v_s_244 = args[0];
  V v_t_245 = heff_intAdd(heff_dup(heff_rfield(v_s_244, 1)), MK_INT(1LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_244, v_t_245));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam2(V self, V *args) {
  V v_s_249 = args[0];
  V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_s_249, 1)), MK_INT(2LL));
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_249, v_t_2410));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam4(V self, V *args) {
  V v_s_2422 = args[0];
  V v_k_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_intAdd(heff_dup(heff_rfield(v_s_2422, 1)), v_k_2421);
  return (g_heff_2esyntax_2ecst_2etokAt(v_s_2422, v_t_2423));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_DSig, 3, (V[]){v_x_2429, v_x_2430, v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam7(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_242, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam8, 1, 3, (V[]){v_k_243, v_x_2429, v_x_2430})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam6(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam7, 1, 3, (V[]){v_hd_242, v_k_243, v_x_2429})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam16(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_k_2443 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2444, v_x_2445})});
  V f_ = v_k_2443;
  args[0] = v_t_2446;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam15(V self, V *args) {
  V v_x_2444 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_2442 = heff_env(self)[1];
  V v_k_2443 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2eblock(v_item_240, v_hd_2442, heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam16, 1, 2, (V[]){v_x_2444, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam14(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k_2443 = args[1];
  V v_item_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_2442), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam15, 1, 3, (V[]){v_item_240, v_hd_2442, v_k_2443})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam17(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  heff_drop(v_hd_2447);
  V f_ = v_k_2448;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam18(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k_2450 = args[1];
  heff_drop(v_hd_2449);
  V f_ = v_k_2450;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam19(V self, V *args) {
  V v_x_2452 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_2433 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_243;
  args[0] = heff_tag_n(TAG_DEqn, 5, (V[]){v_x_2433, v_x_2434, v_x_2435, v_x_2436, v_x_2452});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam13(V self, V *args) {
  V v_x_2439 = args[0];
  V v_item_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  V v_x_2436 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2451;
  if (heff_strEq_c(heff_dup(heff_rfield(v_x_2439, 0)), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str4))) {
    if (heff_strEq_c(heff_get_n(v_x_2439, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str5))) {
      v_t_2451 = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam14, 2, 1, (V[]){v_item_240});
    } else {
      heff_drop(v_item_240);
      v_t_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam17_clo);
    }
  } else {
    heff_drop_rec(v_x_2439, 9);
    heff_drop(v_item_240);
    v_t_2451 = ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam18_clo);
  }
  V f_ = v_t_2451;
  heff_room[0] = v_hd_242;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam19, 1, 5, (V[]){v_k_243, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam12(V self, V *args) {
  V v_x_2436 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  V v_x_2435 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2438 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2437}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2438;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam13, 1, 7, (V[]){v_item_240, v_hd_242, v_k_243, v_x_2433, v_x_2434, v_x_2435, v_x_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam11(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  V v_x_2434 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam12, 1, 6, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2433, v_x_2434, v_x_2435})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_x_2433 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2esyntax_2ecst_2eexpectSym(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str3), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam11, 1, 5, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2433, v_x_2434})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam9(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_item_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2esyntax_2ecst_2emanyGo(heff_dup(heff_rfield(g_heff_2esyntax_2ecst_2egram_get(), 7)), NTAG(TAG_Nil), heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam10, 1, 4, (V[]){v_hd_242, v_item_240, v_k_243, v_x_2433})));
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  V v_item_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  if (heff_strEq_c(heff_get_n(v_x_2426, 1, 9), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str2))) {
    heff_drop(v_item_240);
    V v_t_2428 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2428, heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam6, 1, 2, (V[]){v_hd_242, v_k_243})));
  } else {
    V v_t_2432 = (g_heff_2esyntax_2ecst_2edeclNameLen(v_t_241, v_x_248, v_x_2413));
    return (g_heff_2esyntax_2ecst_2enextN(v_t_2432, heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam9, 1, 3, (V[]){v_hd_242, v_item_240, v_k_243})));
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_item_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
  if (heff_intEq_c(v_t_2414, MK_INT(0LL))) {
    heff_drop(v_x_2413);
    heff_drop(v_x_248);
    heff_drop(v_item_240);
    V v_t_2416 = heff_strAppend(heff_take_field(v_t_241, 1), ((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str0));
    V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
    V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2esigOrEqn_str1), v_t_2416), v_t_2417, NTAG(TAG_Nothing)});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_2419}));
    V f_ = heff_get_n(v_hd_242, 1, 3);
    heff_room[0] = v_t_2420;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    V v_k_2421 = (g_heff_2esyntax_2ecst_2edeclNameLen(heff_dup(v_t_241), heff_dup(v_x_248), heff_dup(v_x_2413)));
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam4, 1, 1, (V[]){v_k_2421})})});
    V v_t_2425 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2424}));
    V f_ = heff_dup(heff_rfield(v_hd_242, 1));
    heff_room[0] = v_t_2425;
    heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam5, 1, 6, (V[]){v_t_241, v_x_248, v_x_2413, v_hd_242, v_k_243, v_item_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2esyntax_2ecst_2esigOrEqn_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_item_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2esigOrEqn_lam2_clo)})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2411}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2412;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2esigOrEqn_lam3, 1, 5, (V[]){v_t_241, v_x_248, v_hd_242, v_k_243, v_item_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0, 1, 0};
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1(V self, V *args);
Clo g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry, 4, 0};

V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(V v_col_240, V v_acc_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0_clo)})});
  V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_245}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_246, heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(a[0], a[1], a[2], a[3]);
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return ({ V rv_4 = heff_dup(heff_rfield(v_s_244, 1)); V rr_ = heff_rec_reuse_nf(v_s_244, 15ULL, 5, shape_toks__i__top__stack__start, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4(V self, V *args) {
  V v_x_2414 = args[0];
  V v_col_240 = heff_env(self)[0];
  V v_x_2411 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = (g_heff_2esyntax_2ecst_2econtinuesBlock(v_x_2414, heff_dup(v_col_240)));
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    return (g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922(v_col_240, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241}), v_hd_242, v_k_243));
  } else {
    heff_drop(v_col_240);
    heff_drop_rec(v_hd_242, 3);
    heff_drop(v_t_2415);
    V v_x_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_acc_241})));
    V f_ = v_k_243;
    args[0] = v_x_2416;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam4, 1, 5, (V[]){v_col_240, v_x_2411, v_acc_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  return (g_heff_2esyntax_2ecst_2elocalDecl(heff_dup(v_hd_242), heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam3, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243})));
}
V g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_col_240 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_Put, 2, (V[]){v_x_247, NTAG(TAG_MkUnit)});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})}));
  V f_ = heff_dup(heff_rfield(v_hd_242, 1));
  heff_room[0] = v_t_249;
  heff_room[1] = heff_clo_n(g_heff_2esyntax_2ecst_2eblockGo_24s916034746x945877922_lam2, 1, 4, (V[]){v_hd_242, v_col_240, v_acc_241, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2emutualDecl_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2ecst_2emutualDecl_str1, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2ecst_2emutualDecl_str2, 65, "an instance is declared at the top level, not in a `mutual` block");
HEFF_LIT(g_heff_2esyntax_2ecst_2emutualDecl_str3, 5, "watch");
HEFF_LIT(g_heff_2esyntax_2ecst_2emutualDecl_str4, 7, "doctest");
V g_heff_2esyntax_2ecst_2emutualDecl_lam2(V self, V *args);
V g_heff_2esyntax_2ecst_2emutualDecl_lam1(V self, V *args);
V g_heff_2esyntax_2ecst_2emutualDecl_lam4(V self, V *args);
V g_heff_2esyntax_2ecst_2emutualDecl_lam3(V self, V *args);
V g_heff_2esyntax_2ecst_2emutualDecl_lam0(V self, V *args);
Clo g_heff_2esyntax_2ecst_2emutualDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2emutualDecl_entry, 2, 0};

V g_heff_2esyntax_2ecst_2emutualDecl(V v_hd_240, V v_k_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2esyntax_2ecst_2ecur_clo)})});
  V v_t_243 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_242}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_243, heff_clo_n(g_heff_2esyntax_2ecst_2emutualDecl_lam0, 1, 2, (V[]){v_hd_240, v_k_241})});
}
V g_heff_2esyntax_2ecst_2emutualDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2emutualDecl(a[0], a[1]);
}
V g_heff_2esyntax_2ecst_2emutualDecl_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2emutualDecl_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2emutualDecl_lam2, 1, 2, (V[]){v_k_241, v_x_2412})));
}
V g_heff_2esyntax_2ecst_2emutualDecl_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_241;
  args[0] = heff_tag_n(TAG_DWatch, 2, (V[]){v_x_2415, v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2esyntax_2ecst_2emutualDecl_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2esyntax_2ecst_2eexprF_24s1302261643x1624868218(v_hd_240, heff_clo_n(g_heff_2esyntax_2ecst_2emutualDecl_lam4, 1, 2, (V[]){v_k_241, v_x_2415})));
}
V g_heff_2esyntax_2ecst_2emutualDecl_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2emutualDecl_str0)) && heff_strEq_c(heff_dup(heff_rfield(v_x_244, 1)), ((V)&g_heff_2esyntax_2ecst_2emutualDecl_str1))));
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_244, 3), heff_get_n(v_x_244, 4, 9)});
    V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2ecst_2emutualDecl_str2), v_t_247, NTAG(TAG_Nothing)});
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_249}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2410;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_t_246);
    if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2emutualDecl_str3))) {
      heff_drop_rec(v_x_244, 9);
      return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2emutualDecl_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_244, 0)), ((V)&g_heff_2esyntax_2ecst_2emutualDecl_str4))) {
        heff_drop_rec(v_x_244, 9);
        return (g_heff_2esyntax_2ecst_2enext(heff_dup(v_hd_240), heff_clo_n(g_heff_2esyntax_2ecst_2emutualDecl_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
      } else {
        return (g_heff_2esyntax_2ecst_2esigOrEqn_24s1086103037x1146034617(v_x_244, v_hd_240, v_k_241));
      }
    }
  }
}
V g_heff_2esyntax_2ecst_2edeclStep_lam0(V self, V *args); static Clo g_heff_2esyntax_2ecst_2edeclStep_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclStep_lam0, 2, 0};
Clo g_heff_2esyntax_2ecst_2edeclStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2ecst_2edeclStep_entry, 1, 0};

V g_heff_2esyntax_2ecst_2edeclStep(V v_s_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_st_242 = ({ V rv_2 = heff_dup(heff_rfield(v_s_240, 1)); V rv_3 = v_t_241; V rv_4 = heff_dup(heff_rfield(v_s_240, 1)); V rr_ = heff_rec_reuse_nf(v_s_240, 3ULL, 5, shape_toks__i__top__stack__start, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_243 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_st_242), heff_dup(heff_rfield(v_st_242, 1))));
  return (g_heff_2esyntax_2ecst_2edeclAt(v_t_243, heff_dup(g_heff_2esyntax_2ecst_2ereadH_get()), ((V)&g_heff_2esyntax_2ecst_2edeclStep_lam0_clo), v_st_242));
}
V g_heff_2esyntax_2ecst_2edeclStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2ecst_2edeclStep(a[0]);
}
V g_heff_2esyntax_2ecst_2edeclStep_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_st_245 = args[1];
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_244}), v_st_245});
}
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str1, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str2, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str3, 35, "the file does not parse (at offset ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str4, 3, "eof");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str5, 1, "`");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str6, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str7, 2, ": ");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str8, 1, ")");
HEFF_LIT(g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str9, 35, "the file does not parse (at offset ");

HeffT2 g_heff_2esyntax_2ecst_2eprogramGo_24cpr(V v_s_240, V v_acc_241) {
top: ;
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
  V v_t_243 = heff_rec_n(5, shape_toks__i__top__stack__start, (V[]){heff_dup(heff_rfield(v_s_240, 0)), heff_dup(heff_rfield(v_s_240, 1)), heff_dup(heff_rfield(v_s_240, 1)), v_t_242, heff_dup(heff_rfield(v_s_240, 1))});
  V v_t_244 = (g_heff_2esyntax_2ecst_2etokAt(v_t_243, heff_dup(heff_rfield(v_s_240, 1))));
  if (heff_strEq_c(heff_get_n(v_t_244, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str0))) {
    heff_drop_rec(v_s_240, 5);
    V v_f_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_246}});
  } else {
    V v_it_247 = heff_tr(g_heff_2esyntax_2ecst_2edeclStep(v_s_240));
    switch (heff_tag_of(v_it_247)) {
    case TAG_MkPair: {
      V v_it1_248 = heff_field(v_it_247, 0);
      V v_s2_249 = heff_field(v_it_247, 1);
      V v_ru_24it_247_24MkPair = heff_take_reuse_n(v_it_247, 3ULL, 2);
      switch (heff_tag_of(v_it1_248)) {
      case TAG_Left: {
        V v_d_2410 = heff_field(v_it1_248, 0);
        heff_take_n(v_it1_248, 1ULL, 1);
        heff_drop(v_acc_241);
        heff_drop_rec(v_s2_249, 5);
        heff_drop_cell(v_ru_24it_247_24MkPair, 2);
        V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_d_2410, 3)), 0, 2);
        V v_t_2412 = heff_strAppend(heff_get_n(v_d_2410, 2, 5), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str1));
        V v_t_2413 = heff_strAppend(heff_intShow(v_t_2411), heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str2), v_t_2412));
        V v_f_2414 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str3), v_t_2413);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
      }
      case TAG_Right: {
        V v_d_2415 = heff_field(v_it1_248, 0);
        heff_take_n(v_it1_248, 1ULL, 1);
        V v_t_2416 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_249), heff_dup(heff_rfield(v_s2_249, 1))));
        if (heff_strEq_c(heff_get_n(v_t_2416, 0, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str4))) {
          V t_0 = v_s2_249;
          V t_1 = heff_tag_at_n(v_ru_24it_247_24MkPair, TAG_Cons, 2, (V[]){v_d_2415, v_acc_241});
          v_s_240 = t_0;
          v_acc_241 = t_1;
          goto top;
        } else {
          heff_drop(v_acc_241);
          heff_drop_cell(v_ru_24it_247_24MkPair, 2);
          heff_drop(v_d_2415);
          V v_t_2418 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_249), heff_dup(heff_rfield(v_s2_249, 1))));
          V v_t_2419 = (g_heff_2esyntax_2ecst_2etokAt(heff_dup(v_s2_249), heff_get_n(v_s2_249, 1, 5)));
          V v_t_2420 = heff_strAppend(heff_get_n(v_t_2419, 1, 9), ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str5));
          V v_msg_2421 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str6), v_t_2420);
          V v_t_2422 = heff_intShow(heff_get_n(v_t_2418, 3, 9));
          V v_t_2423 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str7), heff_strAppend(v_msg_2421, ((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str8)));
          V v_f_2424 = heff_strAppend(((V)&g_heff_2esyntax_2ecst_2eprogramGo_24cpr_str9), heff_strAppend(v_t_2422, v_t_2423));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it_247)}});
    }
  }
}