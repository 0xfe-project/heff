// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadVariant 54613
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkTF 48839
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Passes 47566
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SetPath 11095
#define TAG_Sum 30935
#define TAG_TagVariant 25174
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_id 10114
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_e__pat__decl[] = {LBL_e, LBL_pat, LBL_decl};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
V g_heff_2esyntax_2efixity_2efindG(V, V);
V g_heff_2esyntax_2efixity_2efindG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2efindG_clo;
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
V g_heff_2esyntax_2esurface_2eassembleOne(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleOne_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleOne_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_clo;
V g_heff_2esyntax_2esurface_2edeclL(V, V, V);
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387_clo;
V g_heff_2esyntax_2esurface_2eedgesOf(V, V);
V g_heff_2esyntax_2esurface_2eedgesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eedgesOf_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo;
V g_heff_2esyntax_2esurface_2egroupOfDecl(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo;
V g_heff_2esyntax_2esurface_2einitialSt(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2einitialSt_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2epatL(V, V, V);
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatL_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
V g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839(V, V);
V g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewholeDefines(V);
V g_heff_2esyntax_2esurface_2ewholeDefines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewholeDefines_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s1443337551x1015803594(V, V, V, V);
V g_list_2efilter_24s1443337551x1015803594_entry(V self, V *a);
extern Clo g_list_2efilter_24s1443337551x1015803594_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1006818869x590968200(V);
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisVarE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str0, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str1, 34, "`), or import the module that does");
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str2, 1, "`");
V g_heff_2esyntax_2esurface_2echeckFixOf_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2echeckFixOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckFixOf_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2echeckFixOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2echeckFixOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckFixOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2echeckFixOf(V v_fix_240, V v_lenient_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_fix_240, 2);
    return ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2410 = (g_heff_2esyntax_2efixity_2efindG(heff_clo_n(g_heff_2esyntax_2esurface_2echeckFixOf_lam1, 1, 1, (V[]){heff_dup(v_r_245)}), heff_rfield(v_fix_240, 0)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nothing: {
      if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
        heff_drop_rec(v_r_245, 2);
        V t_0 = v_fix_240;
        V t_1 = v_lenient_241;
        V t_2 = v_rest_246;
        v_fix_240 = t_0;
        v_lenient_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop_rec(v_fix_240, 2);
        heff_drop(v_rest_246);
        V v_t_2411 = heff_dup(heff_rfield(v_r_245, 0));
        return heff_clo_n(g_heff_2esyntax_2esurface_2echeckFixOf_lam2, 1, 2, (V[]){v_r_245, v_t_2411});
      }
    }
    case TAG_Just: {
      heff_take_n(v_t_2410, 0ULL, 1);
      heff_drop_rec(v_r_245, 2);
      V t_0 = v_fix_240;
      V t_1 = v_lenient_241;
      V t_2 = v_rest_246;
      v_fix_240 = t_0;
      v_lenient_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2echeckFixOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_st_243});
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam1(V self, V *args) {
  V v_g_247 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_get_n(heff_get_n(v_r_245, 0, 2), 1, 9);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_248}));
  return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_g_247, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam2(V self, V *args) {
  V v_st_2412 = args[0];
  V v_r_245 = heff_env(self)[0];
  V v_t_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_r_245, 0)), 1, 9);
  V v_t_2414 = heff_get_n(heff_get_n(v_r_245, 0, 2), 1, 9);
  V v_t_2415 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str0), heff_strAppend(v_t_2414, ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str1)));
  V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str2), heff_strAppend(v_t_2413, v_t_2415));
  V v_t_2417 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2411, 3), heff_get_n(v_t_2411, 4, 9)});
  V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2416, v_t_2417, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2418}), v_st_2412});
}
Clo g_heff_2esyntax_2esurface_2eassembleGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eassembleGo_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eassembleGo(V v_broken_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_it_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_245 = (g_heff_2esyntax_2esurface_2eassembleOne(v_broken_240, heff_dup(v_rest_244), v_it_243));
    V v_t_247;
    switch (heff_tag_of(v_x1_245)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      v_t_247 = v_acc_242;
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x1_245, 0);
      heff_take_n(v_x1_245, 1ULL, 1);
      v_t_247 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_acc_242});
      break;
    }
    default: heff_nomatch(v_x1_245);
    }
    V t_0 = v_broken_240;
    V t_1 = v_rest_244;
    V t_2 = v_t_247;
    v_broken_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eassembleGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str1, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str3, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str5, 18, "` is defined twice");
Clo g_heff_2esyntax_2esurface_2ewholeDefines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewholeDefines_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ewholeDefines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      return NTAG(TAG_Passes);
    }
    case TAG_DeclDefine: {
      V v_x_248 = heff_field(v_x11_241, 0);
      V v_xsp_249 = heff_field(v_x11_241, 1);
      V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str0), heff_strAppend(heff_dup(v_x_248), ((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str1)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_x_248), heff_dup(v_xsp_249), NTAG(TAG_Nothing), v_t_2413, NTAG(TAG_False)});
    }
    case TAG_DeclTheory: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_xsp_2415 = heff_field(v_x11_241, 1);
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str2), heff_strAppend(heff_dup(v_x_2414), ((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str3)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_x_2414), heff_dup(v_xsp_2415), NTAG(TAG_Nothing), v_t_2418, NTAG(TAG_False)});
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_241, 0);
      V v_xsp_2420 = heff_field(v_x11_241, 1);
      V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str4), heff_strAppend(heff_dup(v_x_2419), ((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str5)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_x_2419), heff_dup(v_xsp_2420), NTAG(TAG_Nothing), v_t_2422, NTAG(TAG_True)});
    }
    case TAG_DeclTest: {
      return NTAG(TAG_Passes);
    }
    case TAG_DeclWatch: {
      return NTAG(TAG_Passes);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ewholeDefines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ewholeDefines(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ekwAtom_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2ekwAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ekwAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ekwAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_fs_241)) {
  case TAG_Nil: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_f_243 = heff_dup(heff_field(v_fs_241, 0));
    V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ekwAtom_str0), heff_get_n(v_f_243, 1, 9));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), v_t_245);
    v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_242, 2)), 1, (V[]){v_t_246}));
    break;
  }
  default: heff_nomatch(v_fs_241);
  }
  V v_x1_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_247}), v_st_242});
  switch (heff_tag_of(v_x1_248)) {
  case TAG_MkPair: {
    V v_x11_249 = heff_field(v_x1_248, 0);
    V v_st_2410 = heff_field(v_x1_248, 1);
    V v_ru_24x1_248_24MkPair = heff_take_reuse_n(v_x1_248, 3ULL, 2);
    switch (heff_tag_of(v_x11_249)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x11_249, 0);
      heff_take_n(v_x11_249, 1ULL, 1);
      heff_drop_rec(v_t_240, 9);
      heff_drop(v_fs_241);
      return heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2411}), v_st_2410});
    }
    case TAG_Right: {
      V v_x_2412 = heff_field(v_x11_249, 0);
      V v_ru_24x11_249_24Right = heff_take_reuse_n(v_x11_249, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_2410, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
      V v_x1_2414 = heff_tag_at_n(v_ru_24x1_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_st_2410});
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          heff_take_n(v_x11_2415, 1ULL, 1);
          heff_drop_rec(v_t_240, 9);
          heff_drop(v_fs_241);
          heff_drop(v_x_2412);
          return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_249_24Right, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          V v_x_2424;
          if ((heff_dup(v_x_2412) == NTAG(TAG_True))) {
            heff_drop(v_x_2412);
            heff_drop_cell(v_ru_24x11_249_24Right, 1);
            heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
            heff_drop(v_x_2418);
            v_x_2424 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_240, v_fs_241));
          } else {
            heff_drop(v_x_2412);
            if ((heff_dup(v_x_2418) == NTAG(TAG_True))) {
              heff_drop(v_x_2418);
              V v_t_2419 = heff_tag_at_n(v_ru_24x11_249_24Right, TAG_EVar, 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))});
              V v_t_2420 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2421 = (g_list_2emap_24s513201124x806973253(v_fs_241));
              v_x_2424 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_At, 2, (V[]){v_t_2419, v_t_2420}), v_t_2421));
            } else {
              heff_drop_cell(v_ru_24x11_249_24Right, 1);
              heff_drop_cell(v_ru_24x1_2414_24MkPair, 2);
              heff_drop(v_x_2418);
              V v_e_2422 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
              V v_t_2423 = (g_list_2emap_24s513201124x806973253(v_fs_241));
              v_x_2424 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2422, v_t_2423));
            }
          }
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){v_x_2424}), v_st_2416});
        }
        default: return heff_nomatch(v_x11_2415);
        }
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x11_249);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ekwAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eupdateSettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eupdateSettingL(V v_r_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam1, 1, 1, (V[]){v_m_2418});
  }
  case TAG_Named: {
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam2, 1, 1, (V[]){v_m_2435});
  }
  case TAG_Tup: {
    V v_m_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam3, 1, 1, (V[]){v_m_2451});
  }
  case TAG_Braces: {
    V v_m_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam4, 1, 1, (V[]){v_m_2467});
  }
  case TAG_Update: {
    V v_m_2485 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam5, 1, 1, (V[]){v_m_2485});
  }
  case TAG_EUSet: {
    V v_path_2497 = heff_field(v_e_241, 0);
    V v_e3_2499 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 5ULL, 3);
    V v_m_24100 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e3_2499}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam6, 1, 2, (V[]){v_m_24100, v_path_2497});
  }
  case TAG_InstB: {
    V v_m_24119 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam7, 1, 1, (V[]){v_m_24119});
  }
  case TAG_EFSet: {
    V v_m_24134 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam8, 1, 1, (V[]){v_m_24134});
  }
  case TAG_EFDefault: {
    V v_m_24149 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam9, 1, 1, (V[]){v_m_24149});
  }
  case TAG_Sum: {
    V v_m_24166 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam10, 1, 1, (V[]){v_m_24166});
  }
  case TAG_ECon: {
    V v_m_24180 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam11, 1, 1, (V[]){v_m_24180});
  }
  case TAG_EField: {
    V v_m_24194 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam12, 1, 1, (V[]){v_m_24194});
  }
  case TAG_ENeg: {
    V v_m_24208 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam13, 1, 1, (V[]){v_m_24208});
  }
  case TAG_App: {
    V v_m_24222 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam14, 1, 1, (V[]){v_m_24222});
  }
  case TAG_Op: {
    V v_m_24237 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam15, 1, 1, (V[]){v_m_24237});
  }
  case TAG_Ops: {
    V v_m_24251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam16, 1, 1, (V[]){v_m_24251});
  }
  case TAG_OpRhs: {
    V v_m_24265 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam17, 1, 1, (V[]){v_m_24265});
  }
  case TAG_Ann: {
    V v_m_24280 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam18, 1, 1, (V[]){v_m_24280});
  }
  case TAG_BVar: {
    V v_m_24293 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam19, 1, 1, (V[]){v_m_24293});
  }
  case TAG_BImp: {
    V v_m_24308 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam20, 1, 1, (V[]){v_m_24308});
  }
  case TAG_BAnn: {
    V v_m_24325 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam21, 1, 1, (V[]){v_m_24325});
  }
  case TAG_Lam: {
    V v_m_24341 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam22, 1, 1, (V[]){v_m_24341});
  }
  case TAG_Case: {
    V v_m_24357 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam23, 1, 1, (V[]){v_m_24357});
  }
  case TAG_EAlt: {
    V v_m_24372 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam24, 1, 1, (V[]){v_m_24372});
  }
  case TAG_If: {
    V v_m_24390 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam25, 1, 1, (V[]){v_m_24390});
  }
  case TAG_Do: {
    V v_m_24404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam26, 1, 1, (V[]){v_m_24404});
  }
  case TAG_ESBind: {
    V v_m_24419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam27, 1, 1, (V[]){v_m_24419});
  }
  case TAG_ELet: {
    V v_m_24437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam28, 1, 1, (V[]){v_m_24437});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eupdateSettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_249)});
      V v_t_2413;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_x_2414 = heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2413});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){v_x_2414}), v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam1(V self, V *args) {
  V v_st_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_st_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_MkPair: {
    V v_x11_2421 = heff_field(v_x1_2420, 0);
    V v_st_2422 = heff_field(v_x1_2420, 1);
    V v_ru_24x1_2420_24MkPair = heff_take_reuse_n(v_x1_2420, 3ULL, 2);
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Right = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      V v_t_2425 = heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2424)});
      V v_t_2428;
      switch (heff_tag_of(v_x_2424)) {
      case TAG_At: {
        V v_s_2427 = heff_field(v_x_2424, 1);
        heff_take_n(v_x_2424, 2ULL, 2);
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_x_2424);
      }
      V v_x_2429 = heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2428});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2421_24Right, TAG_Right, 1, (V[]){v_x_2429}), v_st_2422});
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_st_2436}));
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_MkPair: {
    V v_x11_2438 = heff_field(v_x1_2437, 0);
    V v_st_2439 = heff_field(v_x1_2437, 1);
    V v_ru_24x1_2437_24MkPair = heff_take_reuse_n(v_x1_2437, 3ULL, 2);
    switch (heff_tag_of(v_x11_2438)) {
    case TAG_Left: {
      V v_e_2440 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
    }
    case TAG_Right: {
      V v_x_2441 = heff_field(v_x11_2438, 0);
      V v_ru_24x11_2438_24Right = heff_take_reuse_n(v_x11_2438, 1ULL, 1);
      V v_t_2442 = heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2441)});
      V v_t_2445;
      switch (heff_tag_of(v_x_2441)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2445 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_x_2441);
      }
      V v_x_2446 = heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2445});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2438_24Right, TAG_Right, 1, (V[]){v_x_2446}), v_st_2439});
    }
    default: return heff_nomatch(v_x11_2438);
    }
  }
  default: return heff_nomatch(v_x1_2437);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam3(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
      V v_t_2458 = heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2457)});
      V v_t_2461;
      switch (heff_tag_of(v_x_2457)) {
      case TAG_At: {
        V v_s_2460 = heff_field(v_x_2457, 1);
        heff_take_n(v_x_2457, 2ULL, 2);
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_x_2457);
      }
      V v_x_2462 = heff_tag_n(TAG_At, 2, (V[]){v_t_2458, v_t_2461});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_Right, 1, (V[]){v_x_2462}), v_st_2455});
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam4(V self, V *args) {
  V v_st_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_st_2468}));
  switch (heff_tag_of(v_x1_2469)) {
  case TAG_MkPair: {
    V v_x11_2470 = heff_field(v_x1_2469, 0);
    V v_st_2471 = heff_field(v_x1_2469, 1);
    V v_ru_24x1_2469_24MkPair = heff_take_reuse_n(v_x1_2469, 3ULL, 2);
    switch (heff_tag_of(v_x11_2470)) {
    case TAG_Left: {
      V v_e_2472 = heff_field(v_x11_2470, 0);
      heff_take_n(v_x11_2470, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2472}), v_st_2471});
    }
    case TAG_Right: {
      V v_x_2473 = heff_field(v_x11_2470, 0);
      V v_ru_24x11_2470_24Right = heff_take_reuse_n(v_x11_2470, 1ULL, 1);
      V v_t_2474 = heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2473)});
      V v_t_2477;
      switch (heff_tag_of(v_x_2473)) {
      case TAG_At: {
        V v_s_2476 = heff_field(v_x_2473, 1);
        heff_take_n(v_x_2473, 2ULL, 2);
        v_t_2477 = v_s_2476;
        break;
      }
      default: heff_nomatch(v_x_2473);
      }
      V v_x_2478 = heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2477});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2470_24Right, TAG_Right, 1, (V[]){v_x_2478}), v_st_2471});
    }
    default: return heff_nomatch(v_x11_2470);
    }
  }
  default: return heff_nomatch(v_x1_2469);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam5(V self, V *args) {
  V v_st_2486 = args[0];
  V v_m_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2487 = heff_tr(heff_call(v_m_2485, 1, (V[]){v_st_2486}));
  switch (heff_tag_of(v_x1_2487)) {
  case TAG_MkPair: {
    V v_x11_2488 = heff_field(v_x1_2487, 0);
    V v_st_2489 = heff_field(v_x1_2487, 1);
    V v_ru_24x1_2487_24MkPair = heff_take_reuse_n(v_x1_2487, 3ULL, 2);
    switch (heff_tag_of(v_x11_2488)) {
    case TAG_Left: {
      V v_e_2490 = heff_field(v_x11_2488, 0);
      heff_take_n(v_x11_2488, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2490}), v_st_2489});
    }
    case TAG_Right: {
      V v_x_2491 = heff_field(v_x11_2488, 0);
      V v_ru_24x11_2488_24Right = heff_take_reuse_n(v_x11_2488, 1ULL, 1);
      V v_t_2492 = heff_tag_at_n(v_ru_24x1_2487_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2491)});
      V v_t_2495;
      switch (heff_tag_of(v_x_2491)) {
      case TAG_At: {
        V v_s_2494 = heff_field(v_x_2491, 1);
        heff_take_n(v_x_2491, 2ULL, 2);
        v_t_2495 = v_s_2494;
        break;
      }
      default: heff_nomatch(v_x_2491);
      }
      V v_x_2496 = heff_tag_n(TAG_At, 2, (V[]){v_t_2492, v_t_2495});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2488_24Right, TAG_Right, 1, (V[]){v_x_2496}), v_st_2489});
    }
    default: return heff_nomatch(v_x11_2488);
    }
  }
  default: return heff_nomatch(v_x1_2487);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam6(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  V v_path_2497 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      heff_drop(v_path_2497);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      V v_ru_24x11_24103_24Right = heff_take_reuse_n(v_x11_24103, 1ULL, 1);
      V v_t_24107 = (g_heff_2esyntax_2esurface_2epathOf(heff_dup(v_path_2497), NTAG(TAG_Nil)));
      V v_t_24108 = ({ V a_0 = v_path_2497; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_path_2497); r_; });
      V v_b_24111;
      switch (heff_tag_of(v_x_24106)) {
      case TAG_At: {
        V v_s_24110 = heff_dup(heff_field(v_x_24106, 1));
        v_b_24111 = v_s_24110;
        break;
      }
      default: heff_nomatch(v_x_24106);
      }
      V v_t_24112 = ({ V rv_0 = heff_get_n(v_t_24108, 3, 9); V rr_ = heff_rec_reuse_nf(v_b_24111, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_24113 = heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_t_24107, v_x_24106}), v_t_24112});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24103_24Right, TAG_Right, 1, (V[]){v_x_24113}), v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam7(V self, V *args) {
  V v_st_24120 = args[0];
  V v_m_24119 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24121 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_st_24120}));
  switch (heff_tag_of(v_x1_24121)) {
  case TAG_MkPair: {
    V v_x11_24122 = heff_field(v_x1_24121, 0);
    V v_st_24123 = heff_field(v_x1_24121, 1);
    V v_ru_24x1_24121_24MkPair = heff_take_reuse_n(v_x1_24121, 3ULL, 2);
    switch (heff_tag_of(v_x11_24122)) {
    case TAG_Left: {
      V v_e_24124 = heff_field(v_x11_24122, 0);
      heff_take_n(v_x11_24122, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24121_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24124}), v_st_24123});
    }
    case TAG_Right: {
      V v_x_24125 = heff_field(v_x11_24122, 0);
      V v_ru_24x11_24122_24Right = heff_take_reuse_n(v_x11_24122, 1ULL, 1);
      V v_t_24126 = heff_tag_at_n(v_ru_24x1_24121_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24125)});
      V v_t_24129;
      switch (heff_tag_of(v_x_24125)) {
      case TAG_At: {
        V v_s_24128 = heff_field(v_x_24125, 1);
        heff_take_n(v_x_24125, 2ULL, 2);
        v_t_24129 = v_s_24128;
        break;
      }
      default: heff_nomatch(v_x_24125);
      }
      V v_x_24130 = heff_tag_n(TAG_At, 2, (V[]){v_t_24126, v_t_24129});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24122_24Right, TAG_Right, 1, (V[]){v_x_24130}), v_st_24123});
    }
    default: return heff_nomatch(v_x11_24122);
    }
  }
  default: return heff_nomatch(v_x1_24121);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam8(V self, V *args) {
  V v_st_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_st_24135}));
  switch (heff_tag_of(v_x1_24136)) {
  case TAG_MkPair: {
    V v_x11_24137 = heff_field(v_x1_24136, 0);
    V v_st_24138 = heff_field(v_x1_24136, 1);
    V v_ru_24x1_24136_24MkPair = heff_take_reuse_n(v_x1_24136, 3ULL, 2);
    switch (heff_tag_of(v_x11_24137)) {
    case TAG_Left: {
      V v_e_24139 = heff_field(v_x11_24137, 0);
      heff_take_n(v_x11_24137, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24139}), v_st_24138});
    }
    case TAG_Right: {
      V v_x_24140 = heff_field(v_x11_24137, 0);
      V v_ru_24x11_24137_24Right = heff_take_reuse_n(v_x11_24137, 1ULL, 1);
      V v_t_24141 = heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24140)});
      V v_t_24144;
      switch (heff_tag_of(v_x_24140)) {
      case TAG_At: {
        V v_s_24143 = heff_field(v_x_24140, 1);
        heff_take_n(v_x_24140, 2ULL, 2);
        v_t_24144 = v_s_24143;
        break;
      }
      default: heff_nomatch(v_x_24140);
      }
      V v_x_24145 = heff_tag_n(TAG_At, 2, (V[]){v_t_24141, v_t_24144});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24137_24Right, TAG_Right, 1, (V[]){v_x_24145}), v_st_24138});
    }
    default: return heff_nomatch(v_x11_24137);
    }
  }
  default: return heff_nomatch(v_x1_24136);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam9(V self, V *args) {
  V v_st_24150 = args[0];
  V v_m_24149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24151 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_st_24150}));
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_MkPair: {
    V v_x11_24152 = heff_field(v_x1_24151, 0);
    V v_st_24153 = heff_field(v_x1_24151, 1);
    V v_ru_24x1_24151_24MkPair = heff_take_reuse_n(v_x1_24151, 3ULL, 2);
    switch (heff_tag_of(v_x11_24152)) {
    case TAG_Left: {
      V v_e_24154 = heff_field(v_x11_24152, 0);
      heff_take_n(v_x11_24152, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24154}), v_st_24153});
    }
    case TAG_Right: {
      V v_x_24155 = heff_field(v_x11_24152, 0);
      V v_ru_24x11_24152_24Right = heff_take_reuse_n(v_x11_24152, 1ULL, 1);
      V v_t_24156 = heff_tag_at_n(v_ru_24x1_24151_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24155)});
      V v_t_24159;
      switch (heff_tag_of(v_x_24155)) {
      case TAG_At: {
        V v_s_24158 = heff_field(v_x_24155, 1);
        heff_take_n(v_x_24155, 2ULL, 2);
        v_t_24159 = v_s_24158;
        break;
      }
      default: heff_nomatch(v_x_24155);
      }
      V v_x_24160 = heff_tag_n(TAG_At, 2, (V[]){v_t_24156, v_t_24159});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24152_24Right, TAG_Right, 1, (V[]){v_x_24160}), v_st_24153});
    }
    default: return heff_nomatch(v_x11_24152);
    }
  }
  default: return heff_nomatch(v_x1_24151);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam10(V self, V *args) {
  V v_st_24167 = args[0];
  V v_m_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24168 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_st_24167}));
  switch (heff_tag_of(v_x1_24168)) {
  case TAG_MkPair: {
    V v_x11_24169 = heff_field(v_x1_24168, 0);
    V v_st_24170 = heff_field(v_x1_24168, 1);
    V v_ru_24x1_24168_24MkPair = heff_take_reuse_n(v_x1_24168, 3ULL, 2);
    switch (heff_tag_of(v_x11_24169)) {
    case TAG_Left: {
      V v_e_24171 = heff_field(v_x11_24169, 0);
      heff_take_n(v_x11_24169, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24168_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24171}), v_st_24170});
    }
    case TAG_Right: {
      V v_x_24172 = heff_field(v_x11_24169, 0);
      V v_ru_24x11_24169_24Right = heff_take_reuse_n(v_x11_24169, 1ULL, 1);
      V v_t_24173 = heff_tag_at_n(v_ru_24x1_24168_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24172)});
      V v_t_24176;
      switch (heff_tag_of(v_x_24172)) {
      case TAG_At: {
        V v_s_24175 = heff_field(v_x_24172, 1);
        heff_take_n(v_x_24172, 2ULL, 2);
        v_t_24176 = v_s_24175;
        break;
      }
      default: heff_nomatch(v_x_24172);
      }
      V v_x_24177 = heff_tag_n(TAG_At, 2, (V[]){v_t_24173, v_t_24176});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24169_24Right, TAG_Right, 1, (V[]){v_x_24177}), v_st_24170});
    }
    default: return heff_nomatch(v_x11_24169);
    }
  }
  default: return heff_nomatch(v_x1_24168);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam11(V self, V *args) {
  V v_st_24181 = args[0];
  V v_m_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24182 = heff_tr(heff_call(v_m_24180, 1, (V[]){v_st_24181}));
  switch (heff_tag_of(v_x1_24182)) {
  case TAG_MkPair: {
    V v_x11_24183 = heff_field(v_x1_24182, 0);
    V v_st_24184 = heff_field(v_x1_24182, 1);
    V v_ru_24x1_24182_24MkPair = heff_take_reuse_n(v_x1_24182, 3ULL, 2);
    switch (heff_tag_of(v_x11_24183)) {
    case TAG_Left: {
      V v_e_24185 = heff_field(v_x11_24183, 0);
      heff_take_n(v_x11_24183, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24185}), v_st_24184});
    }
    case TAG_Right: {
      V v_x_24186 = heff_field(v_x11_24183, 0);
      V v_ru_24x11_24183_24Right = heff_take_reuse_n(v_x11_24183, 1ULL, 1);
      V v_t_24187 = heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24186)});
      V v_t_24190;
      switch (heff_tag_of(v_x_24186)) {
      case TAG_At: {
        V v_s_24189 = heff_field(v_x_24186, 1);
        heff_take_n(v_x_24186, 2ULL, 2);
        v_t_24190 = v_s_24189;
        break;
      }
      default: heff_nomatch(v_x_24186);
      }
      V v_x_24191 = heff_tag_n(TAG_At, 2, (V[]){v_t_24187, v_t_24190});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24183_24Right, TAG_Right, 1, (V[]){v_x_24191}), v_st_24184});
    }
    default: return heff_nomatch(v_x11_24183);
    }
  }
  default: return heff_nomatch(v_x1_24182);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam12(V self, V *args) {
  V v_st_24195 = args[0];
  V v_m_24194 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24196 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_st_24195}));
  switch (heff_tag_of(v_x1_24196)) {
  case TAG_MkPair: {
    V v_x11_24197 = heff_field(v_x1_24196, 0);
    V v_st_24198 = heff_field(v_x1_24196, 1);
    V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
    switch (heff_tag_of(v_x11_24197)) {
    case TAG_Left: {
      V v_e_24199 = heff_field(v_x11_24197, 0);
      heff_take_n(v_x11_24197, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
    }
    case TAG_Right: {
      V v_x_24200 = heff_field(v_x11_24197, 0);
      V v_ru_24x11_24197_24Right = heff_take_reuse_n(v_x11_24197, 1ULL, 1);
      V v_t_24201 = heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24200)});
      V v_t_24204;
      switch (heff_tag_of(v_x_24200)) {
      case TAG_At: {
        V v_s_24203 = heff_field(v_x_24200, 1);
        heff_take_n(v_x_24200, 2ULL, 2);
        v_t_24204 = v_s_24203;
        break;
      }
      default: heff_nomatch(v_x_24200);
      }
      V v_x_24205 = heff_tag_n(TAG_At, 2, (V[]){v_t_24201, v_t_24204});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24197_24Right, TAG_Right, 1, (V[]){v_x_24205}), v_st_24198});
    }
    default: return heff_nomatch(v_x11_24197);
    }
  }
  default: return heff_nomatch(v_x1_24196);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam13(V self, V *args) {
  V v_st_24209 = args[0];
  V v_m_24208 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24210 = heff_tr(heff_call(v_m_24208, 1, (V[]){v_st_24209}));
  switch (heff_tag_of(v_x1_24210)) {
  case TAG_MkPair: {
    V v_x11_24211 = heff_field(v_x1_24210, 0);
    V v_st_24212 = heff_field(v_x1_24210, 1);
    V v_ru_24x1_24210_24MkPair = heff_take_reuse_n(v_x1_24210, 3ULL, 2);
    switch (heff_tag_of(v_x11_24211)) {
    case TAG_Left: {
      V v_e_24213 = heff_field(v_x11_24211, 0);
      heff_take_n(v_x11_24211, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24213}), v_st_24212});
    }
    case TAG_Right: {
      V v_x_24214 = heff_field(v_x11_24211, 0);
      V v_ru_24x11_24211_24Right = heff_take_reuse_n(v_x11_24211, 1ULL, 1);
      V v_t_24215 = heff_tag_at_n(v_ru_24x1_24210_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24214)});
      V v_t_24218;
      switch (heff_tag_of(v_x_24214)) {
      case TAG_At: {
        V v_s_24217 = heff_field(v_x_24214, 1);
        heff_take_n(v_x_24214, 2ULL, 2);
        v_t_24218 = v_s_24217;
        break;
      }
      default: heff_nomatch(v_x_24214);
      }
      V v_x_24219 = heff_tag_n(TAG_At, 2, (V[]){v_t_24215, v_t_24218});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24211_24Right, TAG_Right, 1, (V[]){v_x_24219}), v_st_24212});
    }
    default: return heff_nomatch(v_x11_24211);
    }
  }
  default: return heff_nomatch(v_x1_24210);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam14(V self, V *args) {
  V v_st_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24224 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_st_24223}));
  switch (heff_tag_of(v_x1_24224)) {
  case TAG_MkPair: {
    V v_x11_24225 = heff_field(v_x1_24224, 0);
    V v_st_24226 = heff_field(v_x1_24224, 1);
    V v_ru_24x1_24224_24MkPair = heff_take_reuse_n(v_x1_24224, 3ULL, 2);
    switch (heff_tag_of(v_x11_24225)) {
    case TAG_Left: {
      V v_e_24227 = heff_field(v_x11_24225, 0);
      heff_take_n(v_x11_24225, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24224_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24227}), v_st_24226});
    }
    case TAG_Right: {
      V v_x_24228 = heff_field(v_x11_24225, 0);
      V v_ru_24x11_24225_24Right = heff_take_reuse_n(v_x11_24225, 1ULL, 1);
      V v_t_24229 = heff_tag_at_n(v_ru_24x1_24224_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24228)});
      V v_t_24232;
      switch (heff_tag_of(v_x_24228)) {
      case TAG_At: {
        V v_s_24231 = heff_field(v_x_24228, 1);
        heff_take_n(v_x_24228, 2ULL, 2);
        v_t_24232 = v_s_24231;
        break;
      }
      default: heff_nomatch(v_x_24228);
      }
      V v_x_24233 = heff_tag_n(TAG_At, 2, (V[]){v_t_24229, v_t_24232});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24225_24Right, TAG_Right, 1, (V[]){v_x_24233}), v_st_24226});
    }
    default: return heff_nomatch(v_x11_24225);
    }
  }
  default: return heff_nomatch(v_x1_24224);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam15(V self, V *args) {
  V v_st_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_st_24238}));
  switch (heff_tag_of(v_x1_24239)) {
  case TAG_MkPair: {
    V v_x11_24240 = heff_field(v_x1_24239, 0);
    V v_st_24241 = heff_field(v_x1_24239, 1);
    V v_ru_24x1_24239_24MkPair = heff_take_reuse_n(v_x1_24239, 3ULL, 2);
    switch (heff_tag_of(v_x11_24240)) {
    case TAG_Left: {
      V v_e_24242 = heff_field(v_x11_24240, 0);
      heff_take_n(v_x11_24240, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24242}), v_st_24241});
    }
    case TAG_Right: {
      V v_x_24243 = heff_field(v_x11_24240, 0);
      V v_ru_24x11_24240_24Right = heff_take_reuse_n(v_x11_24240, 1ULL, 1);
      V v_t_24244 = heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24243)});
      V v_t_24247;
      switch (heff_tag_of(v_x_24243)) {
      case TAG_At: {
        V v_s_24246 = heff_field(v_x_24243, 1);
        heff_take_n(v_x_24243, 2ULL, 2);
        v_t_24247 = v_s_24246;
        break;
      }
      default: heff_nomatch(v_x_24243);
      }
      V v_x_24248 = heff_tag_n(TAG_At, 2, (V[]){v_t_24244, v_t_24247});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24240_24Right, TAG_Right, 1, (V[]){v_x_24248}), v_st_24241});
    }
    default: return heff_nomatch(v_x11_24240);
    }
  }
  default: return heff_nomatch(v_x1_24239);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam16(V self, V *args) {
  V v_st_24252 = args[0];
  V v_m_24251 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24253 = heff_tr(heff_call(v_m_24251, 1, (V[]){v_st_24252}));
  switch (heff_tag_of(v_x1_24253)) {
  case TAG_MkPair: {
    V v_x11_24254 = heff_field(v_x1_24253, 0);
    V v_st_24255 = heff_field(v_x1_24253, 1);
    V v_ru_24x1_24253_24MkPair = heff_take_reuse_n(v_x1_24253, 3ULL, 2);
    switch (heff_tag_of(v_x11_24254)) {
    case TAG_Left: {
      V v_e_24256 = heff_field(v_x11_24254, 0);
      heff_take_n(v_x11_24254, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24253_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24256}), v_st_24255});
    }
    case TAG_Right: {
      V v_x_24257 = heff_field(v_x11_24254, 0);
      V v_ru_24x11_24254_24Right = heff_take_reuse_n(v_x11_24254, 1ULL, 1);
      V v_t_24258 = heff_tag_at_n(v_ru_24x1_24253_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24257)});
      V v_t_24261;
      switch (heff_tag_of(v_x_24257)) {
      case TAG_At: {
        V v_s_24260 = heff_field(v_x_24257, 1);
        heff_take_n(v_x_24257, 2ULL, 2);
        v_t_24261 = v_s_24260;
        break;
      }
      default: heff_nomatch(v_x_24257);
      }
      V v_x_24262 = heff_tag_n(TAG_At, 2, (V[]){v_t_24258, v_t_24261});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24254_24Right, TAG_Right, 1, (V[]){v_x_24262}), v_st_24255});
    }
    default: return heff_nomatch(v_x11_24254);
    }
  }
  default: return heff_nomatch(v_x1_24253);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam17(V self, V *args) {
  V v_st_24266 = args[0];
  V v_m_24265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24267 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_st_24266}));
  switch (heff_tag_of(v_x1_24267)) {
  case TAG_MkPair: {
    V v_x11_24268 = heff_field(v_x1_24267, 0);
    V v_st_24269 = heff_field(v_x1_24267, 1);
    V v_ru_24x1_24267_24MkPair = heff_take_reuse_n(v_x1_24267, 3ULL, 2);
    switch (heff_tag_of(v_x11_24268)) {
    case TAG_Left: {
      V v_e_24270 = heff_field(v_x11_24268, 0);
      heff_take_n(v_x11_24268, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24270}), v_st_24269});
    }
    case TAG_Right: {
      V v_x_24271 = heff_field(v_x11_24268, 0);
      V v_ru_24x11_24268_24Right = heff_take_reuse_n(v_x11_24268, 1ULL, 1);
      V v_t_24272 = heff_tag_at_n(v_ru_24x1_24267_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24271)});
      V v_t_24275;
      switch (heff_tag_of(v_x_24271)) {
      case TAG_At: {
        V v_s_24274 = heff_field(v_x_24271, 1);
        heff_take_n(v_x_24271, 2ULL, 2);
        v_t_24275 = v_s_24274;
        break;
      }
      default: heff_nomatch(v_x_24271);
      }
      V v_x_24276 = heff_tag_n(TAG_At, 2, (V[]){v_t_24272, v_t_24275});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24268_24Right, TAG_Right, 1, (V[]){v_x_24276}), v_st_24269});
    }
    default: return heff_nomatch(v_x11_24268);
    }
  }
  default: return heff_nomatch(v_x1_24267);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam18(V self, V *args) {
  V v_st_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24282 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_st_24281}));
  switch (heff_tag_of(v_x1_24282)) {
  case TAG_MkPair: {
    V v_x11_24283 = heff_field(v_x1_24282, 0);
    V v_st_24284 = heff_field(v_x1_24282, 1);
    V v_ru_24x1_24282_24MkPair = heff_take_reuse_n(v_x1_24282, 3ULL, 2);
    switch (heff_tag_of(v_x11_24283)) {
    case TAG_Left: {
      V v_e_24285 = heff_field(v_x11_24283, 0);
      heff_take_n(v_x11_24283, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24285}), v_st_24284});
    }
    case TAG_Right: {
      V v_x_24286 = heff_field(v_x11_24283, 0);
      V v_ru_24x11_24283_24Right = heff_take_reuse_n(v_x11_24283, 1ULL, 1);
      V v_t_24287 = heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24286)});
      V v_t_24290;
      switch (heff_tag_of(v_x_24286)) {
      case TAG_At: {
        V v_s_24289 = heff_field(v_x_24286, 1);
        heff_take_n(v_x_24286, 2ULL, 2);
        v_t_24290 = v_s_24289;
        break;
      }
      default: heff_nomatch(v_x_24286);
      }
      V v_x_24291 = heff_tag_n(TAG_At, 2, (V[]){v_t_24287, v_t_24290});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24283_24Right, TAG_Right, 1, (V[]){v_x_24291}), v_st_24284});
    }
    default: return heff_nomatch(v_x11_24283);
    }
  }
  default: return heff_nomatch(v_x1_24282);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam19(V self, V *args) {
  V v_st_24294 = args[0];
  V v_m_24293 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24295 = heff_tr(heff_call(v_m_24293, 1, (V[]){v_st_24294}));
  switch (heff_tag_of(v_x1_24295)) {
  case TAG_MkPair: {
    V v_x11_24296 = heff_field(v_x1_24295, 0);
    V v_st_24297 = heff_field(v_x1_24295, 1);
    V v_ru_24x1_24295_24MkPair = heff_take_reuse_n(v_x1_24295, 3ULL, 2);
    switch (heff_tag_of(v_x11_24296)) {
    case TAG_Left: {
      V v_e_24298 = heff_field(v_x11_24296, 0);
      heff_take_n(v_x11_24296, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24295_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24298}), v_st_24297});
    }
    case TAG_Right: {
      V v_x_24299 = heff_field(v_x11_24296, 0);
      V v_ru_24x11_24296_24Right = heff_take_reuse_n(v_x11_24296, 1ULL, 1);
      V v_t_24300 = heff_tag_at_n(v_ru_24x1_24295_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24299)});
      V v_t_24303;
      switch (heff_tag_of(v_x_24299)) {
      case TAG_At: {
        V v_s_24302 = heff_field(v_x_24299, 1);
        heff_take_n(v_x_24299, 2ULL, 2);
        v_t_24303 = v_s_24302;
        break;
      }
      default: heff_nomatch(v_x_24299);
      }
      V v_x_24304 = heff_tag_n(TAG_At, 2, (V[]){v_t_24300, v_t_24303});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24296_24Right, TAG_Right, 1, (V[]){v_x_24304}), v_st_24297});
    }
    default: return heff_nomatch(v_x11_24296);
    }
  }
  default: return heff_nomatch(v_x1_24295);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam20(V self, V *args) {
  V v_st_24309 = args[0];
  V v_m_24308 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24310 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_st_24309}));
  switch (heff_tag_of(v_x1_24310)) {
  case TAG_MkPair: {
    V v_x11_24311 = heff_field(v_x1_24310, 0);
    V v_st_24312 = heff_field(v_x1_24310, 1);
    V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
    switch (heff_tag_of(v_x11_24311)) {
    case TAG_Left: {
      V v_e_24313 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
    }
    case TAG_Right: {
      V v_x_24314 = heff_field(v_x11_24311, 0);
      V v_ru_24x11_24311_24Right = heff_take_reuse_n(v_x11_24311, 1ULL, 1);
      V v_t_24315 = heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24314)});
      V v_t_24318;
      switch (heff_tag_of(v_x_24314)) {
      case TAG_At: {
        V v_s_24317 = heff_field(v_x_24314, 1);
        heff_take_n(v_x_24314, 2ULL, 2);
        v_t_24318 = v_s_24317;
        break;
      }
      default: heff_nomatch(v_x_24314);
      }
      V v_x_24319 = heff_tag_n(TAG_At, 2, (V[]){v_t_24315, v_t_24318});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24311_24Right, TAG_Right, 1, (V[]){v_x_24319}), v_st_24312});
    }
    default: return heff_nomatch(v_x11_24311);
    }
  }
  default: return heff_nomatch(v_x1_24310);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam21(V self, V *args) {
  V v_st_24326 = args[0];
  V v_m_24325 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24327 = heff_tr(heff_call(v_m_24325, 1, (V[]){v_st_24326}));
  switch (heff_tag_of(v_x1_24327)) {
  case TAG_MkPair: {
    V v_x11_24328 = heff_field(v_x1_24327, 0);
    V v_st_24329 = heff_field(v_x1_24327, 1);
    V v_ru_24x1_24327_24MkPair = heff_take_reuse_n(v_x1_24327, 3ULL, 2);
    switch (heff_tag_of(v_x11_24328)) {
    case TAG_Left: {
      V v_e_24330 = heff_field(v_x11_24328, 0);
      heff_take_n(v_x11_24328, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24327_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24330}), v_st_24329});
    }
    case TAG_Right: {
      V v_x_24331 = heff_field(v_x11_24328, 0);
      V v_ru_24x11_24328_24Right = heff_take_reuse_n(v_x11_24328, 1ULL, 1);
      V v_t_24332 = heff_tag_at_n(v_ru_24x1_24327_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24331)});
      V v_t_24335;
      switch (heff_tag_of(v_x_24331)) {
      case TAG_At: {
        V v_s_24334 = heff_field(v_x_24331, 1);
        heff_take_n(v_x_24331, 2ULL, 2);
        v_t_24335 = v_s_24334;
        break;
      }
      default: heff_nomatch(v_x_24331);
      }
      V v_x_24336 = heff_tag_n(TAG_At, 2, (V[]){v_t_24332, v_t_24335});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24328_24Right, TAG_Right, 1, (V[]){v_x_24336}), v_st_24329});
    }
    default: return heff_nomatch(v_x11_24328);
    }
  }
  default: return heff_nomatch(v_x1_24327);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam22(V self, V *args) {
  V v_st_24342 = args[0];
  V v_m_24341 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24343 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_st_24342}));
  switch (heff_tag_of(v_x1_24343)) {
  case TAG_MkPair: {
    V v_x11_24344 = heff_field(v_x1_24343, 0);
    V v_st_24345 = heff_field(v_x1_24343, 1);
    V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
    switch (heff_tag_of(v_x11_24344)) {
    case TAG_Left: {
      V v_e_24346 = heff_field(v_x11_24344, 0);
      heff_take_n(v_x11_24344, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
    }
    case TAG_Right: {
      V v_x_24347 = heff_field(v_x11_24344, 0);
      V v_ru_24x11_24344_24Right = heff_take_reuse_n(v_x11_24344, 1ULL, 1);
      V v_t_24348 = heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24347)});
      V v_t_24351;
      switch (heff_tag_of(v_x_24347)) {
      case TAG_At: {
        V v_s_24350 = heff_field(v_x_24347, 1);
        heff_take_n(v_x_24347, 2ULL, 2);
        v_t_24351 = v_s_24350;
        break;
      }
      default: heff_nomatch(v_x_24347);
      }
      V v_x_24352 = heff_tag_n(TAG_At, 2, (V[]){v_t_24348, v_t_24351});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24344_24Right, TAG_Right, 1, (V[]){v_x_24352}), v_st_24345});
    }
    default: return heff_nomatch(v_x11_24344);
    }
  }
  default: return heff_nomatch(v_x1_24343);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam23(V self, V *args) {
  V v_st_24358 = args[0];
  V v_m_24357 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24359 = heff_tr(heff_call(v_m_24357, 1, (V[]){v_st_24358}));
  switch (heff_tag_of(v_x1_24359)) {
  case TAG_MkPair: {
    V v_x11_24360 = heff_field(v_x1_24359, 0);
    V v_st_24361 = heff_field(v_x1_24359, 1);
    V v_ru_24x1_24359_24MkPair = heff_take_reuse_n(v_x1_24359, 3ULL, 2);
    switch (heff_tag_of(v_x11_24360)) {
    case TAG_Left: {
      V v_e_24362 = heff_field(v_x11_24360, 0);
      heff_take_n(v_x11_24360, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24359_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24362}), v_st_24361});
    }
    case TAG_Right: {
      V v_x_24363 = heff_field(v_x11_24360, 0);
      V v_ru_24x11_24360_24Right = heff_take_reuse_n(v_x11_24360, 1ULL, 1);
      V v_t_24364 = heff_tag_at_n(v_ru_24x1_24359_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24363)});
      V v_t_24367;
      switch (heff_tag_of(v_x_24363)) {
      case TAG_At: {
        V v_s_24366 = heff_field(v_x_24363, 1);
        heff_take_n(v_x_24363, 2ULL, 2);
        v_t_24367 = v_s_24366;
        break;
      }
      default: heff_nomatch(v_x_24363);
      }
      V v_x_24368 = heff_tag_n(TAG_At, 2, (V[]){v_t_24364, v_t_24367});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24360_24Right, TAG_Right, 1, (V[]){v_x_24368}), v_st_24361});
    }
    default: return heff_nomatch(v_x11_24360);
    }
  }
  default: return heff_nomatch(v_x1_24359);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam24(V self, V *args) {
  V v_st_24373 = args[0];
  V v_m_24372 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24374 = heff_tr(heff_call(v_m_24372, 1, (V[]){v_st_24373}));
  switch (heff_tag_of(v_x1_24374)) {
  case TAG_MkPair: {
    V v_x11_24375 = heff_field(v_x1_24374, 0);
    V v_st_24376 = heff_field(v_x1_24374, 1);
    V v_ru_24x1_24374_24MkPair = heff_take_reuse_n(v_x1_24374, 3ULL, 2);
    switch (heff_tag_of(v_x11_24375)) {
    case TAG_Left: {
      V v_e_24377 = heff_field(v_x11_24375, 0);
      heff_take_n(v_x11_24375, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24377}), v_st_24376});
    }
    case TAG_Right: {
      V v_x_24378 = heff_field(v_x11_24375, 0);
      V v_ru_24x11_24375_24Right = heff_take_reuse_n(v_x11_24375, 1ULL, 1);
      V v_t_24379 = heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24378)});
      V v_t_24382;
      switch (heff_tag_of(v_x_24378)) {
      case TAG_At: {
        V v_s_24381 = heff_field(v_x_24378, 1);
        heff_take_n(v_x_24378, 2ULL, 2);
        v_t_24382 = v_s_24381;
        break;
      }
      default: heff_nomatch(v_x_24378);
      }
      V v_x_24383 = heff_tag_n(TAG_At, 2, (V[]){v_t_24379, v_t_24382});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24375_24Right, TAG_Right, 1, (V[]){v_x_24383}), v_st_24376});
    }
    default: return heff_nomatch(v_x11_24375);
    }
  }
  default: return heff_nomatch(v_x1_24374);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam25(V self, V *args) {
  V v_st_24391 = args[0];
  V v_m_24390 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24392 = heff_tr(heff_call(v_m_24390, 1, (V[]){v_st_24391}));
  switch (heff_tag_of(v_x1_24392)) {
  case TAG_MkPair: {
    V v_x11_24393 = heff_field(v_x1_24392, 0);
    V v_st_24394 = heff_field(v_x1_24392, 1);
    V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
    switch (heff_tag_of(v_x11_24393)) {
    case TAG_Left: {
      V v_e_24395 = heff_field(v_x11_24393, 0);
      heff_take_n(v_x11_24393, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
    }
    case TAG_Right: {
      V v_x_24396 = heff_field(v_x11_24393, 0);
      V v_ru_24x11_24393_24Right = heff_take_reuse_n(v_x11_24393, 1ULL, 1);
      V v_t_24397 = heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24396)});
      V v_t_24400;
      switch (heff_tag_of(v_x_24396)) {
      case TAG_At: {
        V v_s_24399 = heff_field(v_x_24396, 1);
        heff_take_n(v_x_24396, 2ULL, 2);
        v_t_24400 = v_s_24399;
        break;
      }
      default: heff_nomatch(v_x_24396);
      }
      V v_x_24401 = heff_tag_n(TAG_At, 2, (V[]){v_t_24397, v_t_24400});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24393_24Right, TAG_Right, 1, (V[]){v_x_24401}), v_st_24394});
    }
    default: return heff_nomatch(v_x11_24393);
    }
  }
  default: return heff_nomatch(v_x1_24392);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam26(V self, V *args) {
  V v_st_24405 = args[0];
  V v_m_24404 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24406 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_st_24405}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_MkPair: {
    V v_x11_24407 = heff_field(v_x1_24406, 0);
    V v_st_24408 = heff_field(v_x1_24406, 1);
    V v_ru_24x1_24406_24MkPair = heff_take_reuse_n(v_x1_24406, 3ULL, 2);
    switch (heff_tag_of(v_x11_24407)) {
    case TAG_Left: {
      V v_e_24409 = heff_field(v_x11_24407, 0);
      heff_take_n(v_x11_24407, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24409}), v_st_24408});
    }
    case TAG_Right: {
      V v_x_24410 = heff_field(v_x11_24407, 0);
      V v_ru_24x11_24407_24Right = heff_take_reuse_n(v_x11_24407, 1ULL, 1);
      V v_t_24411 = heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24410)});
      V v_t_24414;
      switch (heff_tag_of(v_x_24410)) {
      case TAG_At: {
        V v_s_24413 = heff_field(v_x_24410, 1);
        heff_take_n(v_x_24410, 2ULL, 2);
        v_t_24414 = v_s_24413;
        break;
      }
      default: heff_nomatch(v_x_24410);
      }
      V v_x_24415 = heff_tag_n(TAG_At, 2, (V[]){v_t_24411, v_t_24414});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24407_24Right, TAG_Right, 1, (V[]){v_x_24415}), v_st_24408});
    }
    default: return heff_nomatch(v_x11_24407);
    }
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam27(V self, V *args) {
  V v_st_24420 = args[0];
  V v_m_24419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24421 = heff_tr(heff_call(v_m_24419, 1, (V[]){v_st_24420}));
  switch (heff_tag_of(v_x1_24421)) {
  case TAG_MkPair: {
    V v_x11_24422 = heff_field(v_x1_24421, 0);
    V v_st_24423 = heff_field(v_x1_24421, 1);
    V v_ru_24x1_24421_24MkPair = heff_take_reuse_n(v_x1_24421, 3ULL, 2);
    switch (heff_tag_of(v_x11_24422)) {
    case TAG_Left: {
      V v_e_24424 = heff_field(v_x11_24422, 0);
      heff_take_n(v_x11_24422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24424}), v_st_24423});
    }
    case TAG_Right: {
      V v_x_24425 = heff_field(v_x11_24422, 0);
      V v_ru_24x11_24422_24Right = heff_take_reuse_n(v_x11_24422, 1ULL, 1);
      V v_t_24426 = heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24425)});
      V v_t_24429;
      switch (heff_tag_of(v_x_24425)) {
      case TAG_At: {
        V v_s_24428 = heff_field(v_x_24425, 1);
        heff_take_n(v_x_24425, 2ULL, 2);
        v_t_24429 = v_s_24428;
        break;
      }
      default: heff_nomatch(v_x_24425);
      }
      V v_x_24430 = heff_tag_n(TAG_At, 2, (V[]){v_t_24426, v_t_24429});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24422_24Right, TAG_Right, 1, (V[]){v_x_24430}), v_st_24423});
    }
    default: return heff_nomatch(v_x11_24422);
    }
  }
  default: return heff_nomatch(v_x1_24421);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam28(V self, V *args) {
  V v_st_24438 = args[0];
  V v_m_24437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24439 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_st_24438}));
  switch (heff_tag_of(v_x1_24439)) {
  case TAG_MkPair: {
    V v_x11_24440 = heff_field(v_x1_24439, 0);
    V v_st_24441 = heff_field(v_x1_24439, 1);
    V v_ru_24x1_24439_24MkPair = heff_take_reuse_n(v_x1_24439, 3ULL, 2);
    switch (heff_tag_of(v_x11_24440)) {
    case TAG_Left: {
      V v_e_24442 = heff_field(v_x11_24440, 0);
      heff_take_n(v_x11_24440, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24442}), v_st_24441});
    }
    case TAG_Right: {
      V v_x_24443 = heff_field(v_x11_24440, 0);
      V v_ru_24x11_24440_24Right = heff_take_reuse_n(v_x11_24440, 1ULL, 1);
      V v_t_24444 = heff_tag_at_n(v_ru_24x1_24439_24MkPair, TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24443)});
      V v_t_24447;
      switch (heff_tag_of(v_x_24443)) {
      case TAG_At: {
        V v_s_24446 = heff_field(v_x_24443, 1);
        heff_take_n(v_x_24443, 2ULL, 2);
        v_t_24447 = v_s_24446;
        break;
      }
      default: heff_nomatch(v_x_24443);
      }
      V v_x_24448 = heff_tag_n(TAG_At, 2, (V[]){v_t_24444, v_t_24447});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24440_24Right, TAG_Right, 1, (V[]){v_x_24448}), v_st_24441});
    }
    default: return heff_nomatch(v_x11_24440);
    }
  }
  default: return heff_nomatch(v_x1_24439);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam28(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ebracedL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracedL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebracedL(V v_r_240, V v_f_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_Atom: {
    V v_m_244 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam0, 1, 2, (V[]){v_m_244, v_sp_242});
  }
  case TAG_EParen: {
    V v_m_2415 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam1, 1, 2, (V[]){v_m_2415, v_sp_242});
  }
  case TAG_Named: {
    V v_m_2428 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam2, 1, 2, (V[]){v_m_2428, v_sp_242});
  }
  case TAG_Tup: {
    V v_m_2440 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam3, 1, 2, (V[]){v_m_2440, v_sp_242});
  }
  case TAG_Braces: {
    V v_m_2452 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam4, 1, 2, (V[]){v_m_2452, v_sp_242});
  }
  case TAG_Update: {
    V v_m_2466 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam5, 1, 2, (V[]){v_m_2466, v_sp_242});
  }
  case TAG_EUSet: {
    V v_m_2477 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam6, 1, 2, (V[]){v_m_2477, v_sp_242});
  }
  case TAG_InstB: {
    V v_m_2490 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam7, 1, 2, (V[]){v_m_2490, v_sp_242});
  }
  case TAG_EFSet: {
    V v_m_24101 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam8, 1, 2, (V[]){v_m_24101, v_sp_242});
  }
  case TAG_EFDefault: {
    V v_e_24109 = heff_field(v_f_241, 0);
    V v_d_24111 = heff_field(v_f_241, 2);
    heff_take_n(v_f_241, 5ULL, 3);
    V v_m_24112 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_d_24111}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam9, 1, 4, (V[]){v_m_24112, v_r_240, v_e_24109, v_sp_242});
  }
  case TAG_Sum: {
    V v_m_24131 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam10, 1, 2, (V[]){v_m_24131, v_sp_242});
  }
  case TAG_ECon: {
    V v_m_24141 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam11, 1, 2, (V[]){v_m_24141, v_sp_242});
  }
  case TAG_EField: {
    V v_m_24151 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam12, 1, 2, (V[]){v_m_24151, v_sp_242});
  }
  case TAG_ENeg: {
    V v_m_24161 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam13, 1, 2, (V[]){v_m_24161, v_sp_242});
  }
  case TAG_App: {
    V v_m_24171 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam14, 1, 2, (V[]){v_m_24171, v_sp_242});
  }
  case TAG_Op: {
    V v_m_24182 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam15, 1, 2, (V[]){v_m_24182, v_sp_242});
  }
  case TAG_Ops: {
    V v_m_24192 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam16, 1, 2, (V[]){v_m_24192, v_sp_242});
  }
  case TAG_OpRhs: {
    V v_m_24202 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam17, 1, 2, (V[]){v_m_24202, v_sp_242});
  }
  case TAG_Ann: {
    V v_m_24213 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam18, 1, 2, (V[]){v_m_24213, v_sp_242});
  }
  case TAG_BVar: {
    V v_m_24222 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam19, 1, 2, (V[]){v_m_24222, v_sp_242});
  }
  case TAG_BImp: {
    V v_m_24233 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam20, 1, 2, (V[]){v_m_24233, v_sp_242});
  }
  case TAG_BAnn: {
    V v_m_24246 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam21, 1, 2, (V[]){v_m_24246, v_sp_242});
  }
  case TAG_Lam: {
    V v_m_24258 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam22, 1, 2, (V[]){v_m_24258, v_sp_242});
  }
  case TAG_Case: {
    V v_m_24270 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam23, 1, 2, (V[]){v_m_24270, v_sp_242});
  }
  case TAG_EAlt: {
    V v_m_24281 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam24, 1, 2, (V[]){v_m_24281, v_sp_242});
  }
  case TAG_If: {
    V v_m_24295 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam25, 1, 2, (V[]){v_m_24295, v_sp_242});
  }
  case TAG_Do: {
    V v_m_24305 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam26, 1, 2, (V[]){v_m_24305, v_sp_242});
  }
  case TAG_ESBind: {
    V v_m_24316 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam27, 1, 2, (V[]){v_m_24316, v_sp_242});
  }
  case TAG_ELet: {
    V v_m_24330 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam28, 1, 2, (V[]){v_m_24330, v_sp_242});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebracedL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2ebracedL_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2410, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_st_248});
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam1(V self, V *args) {
  V v_st_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2416}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 1);
      V v_t_2422 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2421, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2422}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_st_2429}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_MkPair: {
    V v_x11_2431 = heff_field(v_x1_2430, 0);
    V v_st_2432 = heff_field(v_x1_2430, 1);
    V v_ru_24x1_2430_24MkPair = heff_take_reuse_n(v_x1_2430, 3ULL, 2);
    switch (heff_tag_of(v_x11_2431)) {
    case TAG_Left: {
      V v_e_2433 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2433}), v_st_2432});
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      V v_t_2435 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2434, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2435}), v_st_2432});
    }
    default: return heff_nomatch(v_x11_2431);
    }
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam3(V self, V *args) {
  V v_st_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_st_2441}));
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_MkPair: {
    V v_x11_2443 = heff_field(v_x1_2442, 0);
    V v_st_2444 = heff_field(v_x1_2442, 1);
    V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
    switch (heff_tag_of(v_x11_2443)) {
    case TAG_Left: {
      V v_e_2445 = heff_field(v_x11_2443, 0);
      heff_take_n(v_x11_2443, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
    }
    case TAG_Right: {
      V v_x_2446 = heff_field(v_x11_2443, 0);
      heff_take_n(v_x11_2443, 1ULL, 1);
      V v_t_2447 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2446, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2447}), v_st_2444});
    }
    default: return heff_nomatch(v_x11_2443);
    }
  }
  default: return heff_nomatch(v_x1_2442);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam4(V self, V *args) {
  V v_st_2453 = args[0];
  V v_m_2452 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2454 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_st_2453}));
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_MkPair: {
    V v_x11_2455 = heff_field(v_x1_2454, 0);
    V v_st_2456 = heff_field(v_x1_2454, 1);
    V v_ru_24x1_2454_24MkPair = heff_take_reuse_n(v_x1_2454, 3ULL, 2);
    switch (heff_tag_of(v_x11_2455)) {
    case TAG_Left: {
      V v_e_2457 = heff_field(v_x11_2455, 0);
      heff_take_n(v_x11_2455, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2457}), v_st_2456});
    }
    case TAG_Right: {
      V v_x_2458 = heff_field(v_x11_2455, 0);
      heff_take_n(v_x11_2455, 1ULL, 1);
      V v_t_2459 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2458, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2459}), v_st_2456});
    }
    default: return heff_nomatch(v_x11_2455);
    }
  }
  default: return heff_nomatch(v_x1_2454);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam5(V self, V *args) {
  V v_st_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_st_2467}));
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_MkPair: {
    V v_x11_2469 = heff_field(v_x1_2468, 0);
    V v_st_2470 = heff_field(v_x1_2468, 1);
    V v_ru_24x1_2468_24MkPair = heff_take_reuse_n(v_x1_2468, 3ULL, 2);
    switch (heff_tag_of(v_x11_2469)) {
    case TAG_Left: {
      V v_e_2471 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2471}), v_st_2470});
    }
    case TAG_Right: {
      V v_x_2472 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      V v_t_2473 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2472, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2473}), v_st_2470});
    }
    default: return heff_nomatch(v_x11_2469);
    }
  }
  default: return heff_nomatch(v_x1_2468);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam6(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      V v_t_2484 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2483, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2484}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam7(V self, V *args) {
  V v_st_2491 = args[0];
  V v_m_2490 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2492 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_st_2491}));
  switch (heff_tag_of(v_x1_2492)) {
  case TAG_MkPair: {
    V v_x11_2493 = heff_field(v_x1_2492, 0);
    V v_st_2494 = heff_field(v_x1_2492, 1);
    V v_ru_24x1_2492_24MkPair = heff_take_reuse_n(v_x1_2492, 3ULL, 2);
    switch (heff_tag_of(v_x11_2493)) {
    case TAG_Left: {
      V v_e_2495 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2495}), v_st_2494});
    }
    case TAG_Right: {
      V v_x_2496 = heff_field(v_x11_2493, 0);
      heff_take_n(v_x11_2493, 1ULL, 1);
      V v_t_2497 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2496, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2492_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2497}), v_st_2494});
    }
    default: return heff_nomatch(v_x11_2493);
    }
  }
  default: return heff_nomatch(v_x1_2492);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam8(V self, V *args) {
  V v_st_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24103 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_st_24102}));
  switch (heff_tag_of(v_x1_24103)) {
  case TAG_MkPair: {
    V v_x11_24104 = heff_field(v_x1_24103, 0);
    V v_st_24105 = heff_field(v_x1_24103, 1);
    V v_ru_24x1_24103_24MkPair = heff_take_reuse_n(v_x1_24103, 3ULL, 2);
    switch (heff_tag_of(v_x11_24104)) {
    case TAG_Left: {
      V v_e_24106 = heff_field(v_x11_24104, 0);
      heff_take_n(v_x11_24104, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24106}), v_st_24105});
    }
    case TAG_Right: {
      V v_x_24107 = heff_field(v_x11_24104, 0);
      heff_take_n(v_x11_24104, 1ULL, 1);
      V v_t_24108 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24107, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24108}), v_st_24105});
    }
    default: return heff_nomatch(v_x11_24104);
    }
  }
  default: return heff_nomatch(v_x1_24103);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam9(V self, V *args) {
  V v_st_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_e_24109 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_st_24113}));
  switch (heff_tag_of(v_x1_24114)) {
  case TAG_MkPair: {
    V v_x11_24115 = heff_field(v_x1_24114, 0);
    V v_st_24116 = heff_field(v_x1_24114, 1);
    V v_ru_24x1_24114_24MkPair = heff_take_reuse_n(v_x1_24114, 3ULL, 2);
    switch (heff_tag_of(v_x11_24115)) {
    case TAG_Left: {
      V v_e_24117 = heff_field(v_x11_24115, 0);
      heff_take_n(v_x11_24115, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e_24109);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24117}), v_st_24116});
    }
    case TAG_Right: {
      V v_x_24118 = heff_field(v_x11_24115, 0);
      V v_ru_24x11_24115_24Right = heff_take_reuse_n(v_x11_24115, 1ULL, 1);
      V v_m_24119 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_24109));
      V v_x1_24120 = heff_tr(heff_call(v_m_24119, 1, (V[]){v_st_24116}));
      switch (heff_tag_of(v_x1_24120)) {
      case TAG_MkPair: {
        V v_x11_24121 = heff_field(v_x1_24120, 0);
        V v_st_24122 = heff_field(v_x1_24120, 1);
        heff_take_n(v_x1_24120, 3ULL, 2);
        switch (heff_tag_of(v_x11_24121)) {
        case TAG_Left: {
          V v_e_24123 = heff_field(v_x11_24121, 0);
          heff_take_n(v_x11_24121, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_x_24118);
          heff_drop_cell(v_ru_24x11_24115_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24123}), v_st_24122});
        }
        case TAG_Right: {
          V v_x_24124 = heff_field(v_x11_24121, 0);
          heff_take_n(v_x11_24121, 1ULL, 1);
          V v_t_24125 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24124, heff_tag_at_n(v_ru_24x11_24115_24Right, TAG_Just, 1, (V[]){v_x_24118}), v_sp_242});
          return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24125}), v_st_24122});
        }
        default: return heff_nomatch(v_x11_24121);
        }
      }
      default: return heff_nomatch(v_x1_24120);
      }
    }
    default: return heff_nomatch(v_x11_24115);
    }
  }
  default: return heff_nomatch(v_x1_24114);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam10(V self, V *args) {
  V v_st_24132 = args[0];
  V v_m_24131 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24133 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_st_24132}));
  switch (heff_tag_of(v_x1_24133)) {
  case TAG_MkPair: {
    V v_x11_24134 = heff_field(v_x1_24133, 0);
    V v_st_24135 = heff_field(v_x1_24133, 1);
    V v_ru_24x1_24133_24MkPair = heff_take_reuse_n(v_x1_24133, 3ULL, 2);
    switch (heff_tag_of(v_x11_24134)) {
    case TAG_Left: {
      V v_e_24136 = heff_field(v_x11_24134, 0);
      heff_take_n(v_x11_24134, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24136}), v_st_24135});
    }
    case TAG_Right: {
      V v_x_24137 = heff_field(v_x11_24134, 0);
      heff_take_n(v_x11_24134, 1ULL, 1);
      V v_t_24138 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24137, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24133_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24138}), v_st_24135});
    }
    default: return heff_nomatch(v_x11_24134);
    }
  }
  default: return heff_nomatch(v_x1_24133);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam11(V self, V *args) {
  V v_st_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_st_24142}));
  switch (heff_tag_of(v_x1_24143)) {
  case TAG_MkPair: {
    V v_x11_24144 = heff_field(v_x1_24143, 0);
    V v_st_24145 = heff_field(v_x1_24143, 1);
    V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
    switch (heff_tag_of(v_x11_24144)) {
    case TAG_Left: {
      V v_e_24146 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
    }
    case TAG_Right: {
      V v_x_24147 = heff_field(v_x11_24144, 0);
      heff_take_n(v_x11_24144, 1ULL, 1);
      V v_t_24148 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24147, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24145});
    }
    default: return heff_nomatch(v_x11_24144);
    }
  }
  default: return heff_nomatch(v_x1_24143);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam12(V self, V *args) {
  V v_st_24152 = args[0];
  V v_m_24151 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24153 = heff_tr(heff_call(v_m_24151, 1, (V[]){v_st_24152}));
  switch (heff_tag_of(v_x1_24153)) {
  case TAG_MkPair: {
    V v_x11_24154 = heff_field(v_x1_24153, 0);
    V v_st_24155 = heff_field(v_x1_24153, 1);
    V v_ru_24x1_24153_24MkPair = heff_take_reuse_n(v_x1_24153, 3ULL, 2);
    switch (heff_tag_of(v_x11_24154)) {
    case TAG_Left: {
      V v_e_24156 = heff_field(v_x11_24154, 0);
      heff_take_n(v_x11_24154, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24156}), v_st_24155});
    }
    case TAG_Right: {
      V v_x_24157 = heff_field(v_x11_24154, 0);
      heff_take_n(v_x11_24154, 1ULL, 1);
      V v_t_24158 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24157, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24158}), v_st_24155});
    }
    default: return heff_nomatch(v_x11_24154);
    }
  }
  default: return heff_nomatch(v_x1_24153);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam13(V self, V *args) {
  V v_st_24162 = args[0];
  V v_m_24161 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24163 = heff_tr(heff_call(v_m_24161, 1, (V[]){v_st_24162}));
  switch (heff_tag_of(v_x1_24163)) {
  case TAG_MkPair: {
    V v_x11_24164 = heff_field(v_x1_24163, 0);
    V v_st_24165 = heff_field(v_x1_24163, 1);
    V v_ru_24x1_24163_24MkPair = heff_take_reuse_n(v_x1_24163, 3ULL, 2);
    switch (heff_tag_of(v_x11_24164)) {
    case TAG_Left: {
      V v_e_24166 = heff_field(v_x11_24164, 0);
      heff_take_n(v_x11_24164, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24166}), v_st_24165});
    }
    case TAG_Right: {
      V v_x_24167 = heff_field(v_x11_24164, 0);
      heff_take_n(v_x11_24164, 1ULL, 1);
      V v_t_24168 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24167, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24168}), v_st_24165});
    }
    default: return heff_nomatch(v_x11_24164);
    }
  }
  default: return heff_nomatch(v_x1_24163);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam14(V self, V *args) {
  V v_st_24172 = args[0];
  V v_m_24171 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24173 = heff_tr(heff_call(v_m_24171, 1, (V[]){v_st_24172}));
  switch (heff_tag_of(v_x1_24173)) {
  case TAG_MkPair: {
    V v_x11_24174 = heff_field(v_x1_24173, 0);
    V v_st_24175 = heff_field(v_x1_24173, 1);
    V v_ru_24x1_24173_24MkPair = heff_take_reuse_n(v_x1_24173, 3ULL, 2);
    switch (heff_tag_of(v_x11_24174)) {
    case TAG_Left: {
      V v_e_24176 = heff_field(v_x11_24174, 0);
      heff_take_n(v_x11_24174, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24176}), v_st_24175});
    }
    case TAG_Right: {
      V v_x_24177 = heff_field(v_x11_24174, 0);
      heff_take_n(v_x11_24174, 1ULL, 1);
      V v_t_24178 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24177, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24173_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24178}), v_st_24175});
    }
    default: return heff_nomatch(v_x11_24174);
    }
  }
  default: return heff_nomatch(v_x1_24173);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam15(V self, V *args) {
  V v_st_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_st_24183}));
  switch (heff_tag_of(v_x1_24184)) {
  case TAG_MkPair: {
    V v_x11_24185 = heff_field(v_x1_24184, 0);
    V v_st_24186 = heff_field(v_x1_24184, 1);
    V v_ru_24x1_24184_24MkPair = heff_take_reuse_n(v_x1_24184, 3ULL, 2);
    switch (heff_tag_of(v_x11_24185)) {
    case TAG_Left: {
      V v_e_24187 = heff_field(v_x11_24185, 0);
      heff_take_n(v_x11_24185, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24187}), v_st_24186});
    }
    case TAG_Right: {
      V v_x_24188 = heff_field(v_x11_24185, 0);
      heff_take_n(v_x11_24185, 1ULL, 1);
      V v_t_24189 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24188, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24189}), v_st_24186});
    }
    default: return heff_nomatch(v_x11_24185);
    }
  }
  default: return heff_nomatch(v_x1_24184);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam16(V self, V *args) {
  V v_st_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_st_24193}));
  switch (heff_tag_of(v_x1_24194)) {
  case TAG_MkPair: {
    V v_x11_24195 = heff_field(v_x1_24194, 0);
    V v_st_24196 = heff_field(v_x1_24194, 1);
    V v_ru_24x1_24194_24MkPair = heff_take_reuse_n(v_x1_24194, 3ULL, 2);
    switch (heff_tag_of(v_x11_24195)) {
    case TAG_Left: {
      V v_e_24197 = heff_field(v_x11_24195, 0);
      heff_take_n(v_x11_24195, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24197}), v_st_24196});
    }
    case TAG_Right: {
      V v_x_24198 = heff_field(v_x11_24195, 0);
      heff_take_n(v_x11_24195, 1ULL, 1);
      V v_t_24199 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24198, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24199}), v_st_24196});
    }
    default: return heff_nomatch(v_x11_24195);
    }
  }
  default: return heff_nomatch(v_x1_24194);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam17(V self, V *args) {
  V v_st_24203 = args[0];
  V v_m_24202 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24204 = heff_tr(heff_call(v_m_24202, 1, (V[]){v_st_24203}));
  switch (heff_tag_of(v_x1_24204)) {
  case TAG_MkPair: {
    V v_x11_24205 = heff_field(v_x1_24204, 0);
    V v_st_24206 = heff_field(v_x1_24204, 1);
    V v_ru_24x1_24204_24MkPair = heff_take_reuse_n(v_x1_24204, 3ULL, 2);
    switch (heff_tag_of(v_x11_24205)) {
    case TAG_Left: {
      V v_e_24207 = heff_field(v_x11_24205, 0);
      heff_take_n(v_x11_24205, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24204_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24207}), v_st_24206});
    }
    case TAG_Right: {
      V v_x_24208 = heff_field(v_x11_24205, 0);
      heff_take_n(v_x11_24205, 1ULL, 1);
      V v_t_24209 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24208, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24204_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24209}), v_st_24206});
    }
    default: return heff_nomatch(v_x11_24205);
    }
  }
  default: return heff_nomatch(v_x1_24204);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam18(V self, V *args) {
  V v_st_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24215 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_st_24214}));
  switch (heff_tag_of(v_x1_24215)) {
  case TAG_MkPair: {
    V v_x11_24216 = heff_field(v_x1_24215, 0);
    V v_st_24217 = heff_field(v_x1_24215, 1);
    V v_ru_24x1_24215_24MkPair = heff_take_reuse_n(v_x1_24215, 3ULL, 2);
    switch (heff_tag_of(v_x11_24216)) {
    case TAG_Left: {
      V v_e_24218 = heff_field(v_x11_24216, 0);
      heff_take_n(v_x11_24216, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24215_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24218}), v_st_24217});
    }
    case TAG_Right: {
      V v_x_24219 = heff_field(v_x11_24216, 0);
      heff_take_n(v_x11_24216, 1ULL, 1);
      V v_t_24220 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24219, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24215_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24220}), v_st_24217});
    }
    default: return heff_nomatch(v_x11_24216);
    }
  }
  default: return heff_nomatch(v_x1_24215);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam19(V self, V *args) {
  V v_st_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24224 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_st_24223}));
  switch (heff_tag_of(v_x1_24224)) {
  case TAG_MkPair: {
    V v_x11_24225 = heff_field(v_x1_24224, 0);
    V v_st_24226 = heff_field(v_x1_24224, 1);
    V v_ru_24x1_24224_24MkPair = heff_take_reuse_n(v_x1_24224, 3ULL, 2);
    switch (heff_tag_of(v_x11_24225)) {
    case TAG_Left: {
      V v_e_24227 = heff_field(v_x11_24225, 0);
      heff_take_n(v_x11_24225, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24224_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24227}), v_st_24226});
    }
    case TAG_Right: {
      V v_x_24228 = heff_field(v_x11_24225, 0);
      heff_take_n(v_x11_24225, 1ULL, 1);
      V v_t_24229 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24228, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24224_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24229}), v_st_24226});
    }
    default: return heff_nomatch(v_x11_24225);
    }
  }
  default: return heff_nomatch(v_x1_24224);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam20(V self, V *args) {
  V v_st_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_st_24234}));
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_MkPair: {
    V v_x11_24236 = heff_field(v_x1_24235, 0);
    V v_st_24237 = heff_field(v_x1_24235, 1);
    V v_ru_24x1_24235_24MkPair = heff_take_reuse_n(v_x1_24235, 3ULL, 2);
    switch (heff_tag_of(v_x11_24236)) {
    case TAG_Left: {
      V v_e_24238 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24238}), v_st_24237});
    }
    case TAG_Right: {
      V v_x_24239 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      V v_t_24240 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24239, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24240}), v_st_24237});
    }
    default: return heff_nomatch(v_x11_24236);
    }
  }
  default: return heff_nomatch(v_x1_24235);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam21(V self, V *args) {
  V v_st_24247 = args[0];
  V v_m_24246 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24248 = heff_tr(heff_call(v_m_24246, 1, (V[]){v_st_24247}));
  switch (heff_tag_of(v_x1_24248)) {
  case TAG_MkPair: {
    V v_x11_24249 = heff_field(v_x1_24248, 0);
    V v_st_24250 = heff_field(v_x1_24248, 1);
    V v_ru_24x1_24248_24MkPair = heff_take_reuse_n(v_x1_24248, 3ULL, 2);
    switch (heff_tag_of(v_x11_24249)) {
    case TAG_Left: {
      V v_e_24251 = heff_field(v_x11_24249, 0);
      heff_take_n(v_x11_24249, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24251}), v_st_24250});
    }
    case TAG_Right: {
      V v_x_24252 = heff_field(v_x11_24249, 0);
      heff_take_n(v_x11_24249, 1ULL, 1);
      V v_t_24253 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24252, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24253}), v_st_24250});
    }
    default: return heff_nomatch(v_x11_24249);
    }
  }
  default: return heff_nomatch(v_x1_24248);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam22(V self, V *args) {
  V v_st_24259 = args[0];
  V v_m_24258 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24260 = heff_tr(heff_call(v_m_24258, 1, (V[]){v_st_24259}));
  switch (heff_tag_of(v_x1_24260)) {
  case TAG_MkPair: {
    V v_x11_24261 = heff_field(v_x1_24260, 0);
    V v_st_24262 = heff_field(v_x1_24260, 1);
    V v_ru_24x1_24260_24MkPair = heff_take_reuse_n(v_x1_24260, 3ULL, 2);
    switch (heff_tag_of(v_x11_24261)) {
    case TAG_Left: {
      V v_e_24263 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24263}), v_st_24262});
    }
    case TAG_Right: {
      V v_x_24264 = heff_field(v_x11_24261, 0);
      heff_take_n(v_x11_24261, 1ULL, 1);
      V v_t_24265 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24264, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24260_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24265}), v_st_24262});
    }
    default: return heff_nomatch(v_x11_24261);
    }
  }
  default: return heff_nomatch(v_x1_24260);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam23(V self, V *args) {
  V v_st_24271 = args[0];
  V v_m_24270 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24272 = heff_tr(heff_call(v_m_24270, 1, (V[]){v_st_24271}));
  switch (heff_tag_of(v_x1_24272)) {
  case TAG_MkPair: {
    V v_x11_24273 = heff_field(v_x1_24272, 0);
    V v_st_24274 = heff_field(v_x1_24272, 1);
    V v_ru_24x1_24272_24MkPair = heff_take_reuse_n(v_x1_24272, 3ULL, 2);
    switch (heff_tag_of(v_x11_24273)) {
    case TAG_Left: {
      V v_e_24275 = heff_field(v_x11_24273, 0);
      heff_take_n(v_x11_24273, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24275}), v_st_24274});
    }
    case TAG_Right: {
      V v_x_24276 = heff_field(v_x11_24273, 0);
      heff_take_n(v_x11_24273, 1ULL, 1);
      V v_t_24277 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24276, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24277}), v_st_24274});
    }
    default: return heff_nomatch(v_x11_24273);
    }
  }
  default: return heff_nomatch(v_x1_24272);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam24(V self, V *args) {
  V v_st_24282 = args[0];
  V v_m_24281 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24283 = heff_tr(heff_call(v_m_24281, 1, (V[]){v_st_24282}));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_MkPair: {
    V v_x11_24284 = heff_field(v_x1_24283, 0);
    V v_st_24285 = heff_field(v_x1_24283, 1);
    V v_ru_24x1_24283_24MkPair = heff_take_reuse_n(v_x1_24283, 3ULL, 2);
    switch (heff_tag_of(v_x11_24284)) {
    case TAG_Left: {
      V v_e_24286 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24286}), v_st_24285});
    }
    case TAG_Right: {
      V v_x_24287 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      V v_t_24288 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24287, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24288}), v_st_24285});
    }
    default: return heff_nomatch(v_x11_24284);
    }
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam25(V self, V *args) {
  V v_st_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_st_24296}));
  switch (heff_tag_of(v_x1_24297)) {
  case TAG_MkPair: {
    V v_x11_24298 = heff_field(v_x1_24297, 0);
    V v_st_24299 = heff_field(v_x1_24297, 1);
    V v_ru_24x1_24297_24MkPair = heff_take_reuse_n(v_x1_24297, 3ULL, 2);
    switch (heff_tag_of(v_x11_24298)) {
    case TAG_Left: {
      V v_e_24300 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24300}), v_st_24299});
    }
    case TAG_Right: {
      V v_x_24301 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      V v_t_24302 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24301, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24302}), v_st_24299});
    }
    default: return heff_nomatch(v_x11_24298);
    }
  }
  default: return heff_nomatch(v_x1_24297);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam26(V self, V *args) {
  V v_st_24306 = args[0];
  V v_m_24305 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24307 = heff_tr(heff_call(v_m_24305, 1, (V[]){v_st_24306}));
  switch (heff_tag_of(v_x1_24307)) {
  case TAG_MkPair: {
    V v_x11_24308 = heff_field(v_x1_24307, 0);
    V v_st_24309 = heff_field(v_x1_24307, 1);
    V v_ru_24x1_24307_24MkPair = heff_take_reuse_n(v_x1_24307, 3ULL, 2);
    switch (heff_tag_of(v_x11_24308)) {
    case TAG_Left: {
      V v_e_24310 = heff_field(v_x11_24308, 0);
      heff_take_n(v_x11_24308, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24307_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24310}), v_st_24309});
    }
    case TAG_Right: {
      V v_x_24311 = heff_field(v_x11_24308, 0);
      heff_take_n(v_x11_24308, 1ULL, 1);
      V v_t_24312 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24311, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24307_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24312}), v_st_24309});
    }
    default: return heff_nomatch(v_x11_24308);
    }
  }
  default: return heff_nomatch(v_x1_24307);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam27(V self, V *args) {
  V v_st_24317 = args[0];
  V v_m_24316 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24318 = heff_tr(heff_call(v_m_24316, 1, (V[]){v_st_24317}));
  switch (heff_tag_of(v_x1_24318)) {
  case TAG_MkPair: {
    V v_x11_24319 = heff_field(v_x1_24318, 0);
    V v_st_24320 = heff_field(v_x1_24318, 1);
    V v_ru_24x1_24318_24MkPair = heff_take_reuse_n(v_x1_24318, 3ULL, 2);
    switch (heff_tag_of(v_x11_24319)) {
    case TAG_Left: {
      V v_e_24321 = heff_field(v_x11_24319, 0);
      heff_take_n(v_x11_24319, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24318_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24321}), v_st_24320});
    }
    case TAG_Right: {
      V v_x_24322 = heff_field(v_x11_24319, 0);
      heff_take_n(v_x11_24319, 1ULL, 1);
      V v_t_24323 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24322, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24318_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24323}), v_st_24320});
    }
    default: return heff_nomatch(v_x11_24319);
    }
  }
  default: return heff_nomatch(v_x1_24318);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam28(V self, V *args) {
  V v_st_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_st_24331}));
  switch (heff_tag_of(v_x1_24332)) {
  case TAG_MkPair: {
    V v_x11_24333 = heff_field(v_x1_24332, 0);
    V v_st_24334 = heff_field(v_x1_24332, 1);
    V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
    switch (heff_tag_of(v_x11_24333)) {
    case TAG_Left: {
      V v_e_24335 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
    }
    case TAG_Right: {
      V v_x_24336 = heff_field(v_x11_24333, 0);
      heff_take_n(v_x11_24333, 1ULL, 1);
      V v_t_24337 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24336, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24337}), v_st_24334});
    }
    default: return heff_nomatch(v_x11_24333);
    }
  }
  default: return heff_nomatch(v_x1_24332);
  }
}
Clo g_heff_2esyntax_2esurface_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantOf(V v_e_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_e_240)));
  V v_it_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_it_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_it_242, 0);
    V v_tsp_244 = heff_field(v_it_242, 1);
    V v_ru_24it_242_24At = heff_take_reuse_n(v_it_242, 3ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_EVar: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_248;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_247 = heff_dup(heff_field(v_e_240, 1));
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_248});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2412;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_e_240, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2412});
    }
    case TAG_ETag: {
      V v_t_2413 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_e_240)));
      V v_t_2415 = heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_2413, v_tsp_244, heff_get_n(v_t_2414, 1, 2)});
      V v_t_2418;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){v_t_2415, v_t_2418});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2422;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_e_240, 1));
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2422});
    }
    case TAG_EFloat: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2426;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_e_240, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2426});
    }
    case TAG_EString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2430;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2429 = heff_dup(heff_field(v_e_240, 1));
        v_t_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2430});
    }
    case TAG_EBytes: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2434;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2433 = heff_dup(heff_field(v_e_240, 1));
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2434});
    }
    case TAG_ERune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2438;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2437 = heff_dup(heff_field(v_e_240, 1));
        v_t_2438 = v_s_2437;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2438});
    }
    case TAG_EWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2442;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_e_240, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2442});
    }
    case TAG_EApp: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2447;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2446 = heff_dup(heff_field(v_e_240, 1));
        v_t_2447 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2447});
    }
    case TAG_EProject: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2451;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2450 = heff_dup(heff_field(v_e_240, 1));
        v_t_2451 = v_s_2450;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2451});
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2456;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2455 = heff_dup(heff_field(v_e_240, 1));
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2456});
    }
    case TAG_EPi: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2461;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2460 = heff_dup(heff_field(v_e_240, 1));
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2461});
    }
    case TAG_ELam: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2466;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2465 = heff_dup(heff_field(v_e_240, 1));
        v_t_2466 = v_s_2465;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2466});
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2471;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_e_240, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2471});
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_243, 0ULL, 4);
      heff_drop(v_tsp_244);
      V v_t_2478;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2477 = heff_dup(heff_field(v_e_240, 1));
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2478});
    }
    case TAG_ESig: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2482;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2481 = heff_dup(heff_field(v_e_240, 1));
        v_t_2482 = v_s_2481;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2482});
    }
    case TAG_ESum: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2486;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_e_240, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2486});
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2490;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2489 = heff_dup(heff_field(v_e_240, 1));
        v_t_2490 = v_s_2489;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2490});
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2495;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2494 = heff_dup(heff_field(v_e_240, 1));
        v_t_2495 = v_s_2494;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2495});
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24100;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2499 = heff_dup(heff_field(v_e_240, 1));
        v_t_24100 = v_s_2499;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24100});
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24105;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24104 = heff_dup(heff_field(v_e_240, 1));
        v_t_24105 = v_s_24104;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24105});
    }
    case TAG_EDo: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24109;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24108 = heff_dup(heff_field(v_e_240, 1));
        v_t_24109 = v_s_24108;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24109});
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24114;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24113 = heff_dup(heff_field(v_e_240, 1));
        v_t_24114 = v_s_24113;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24114});
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24118;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24117 = heff_dup(heff_field(v_e_240, 1));
        v_t_24118 = v_s_24117;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24it_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24118});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantOf(a[0]);
}
V g_heff_2esyntax_2esurface_2elw_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam0, 2, 0};
V g_heff_2esyntax_2esurface_2elw_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam1, 2, 0};
V g_heff_2esyntax_2esurface_2elw_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam2, 2, 0};

static V g_heff_2esyntax_2esurface_2elw_val;
static HEFF_ONCE g_heff_2esyntax_2esurface_2elw_st;
static V g_heff_2esyntax_2esurface_2elw_init(void) {
  return heff_rec_n(3, shape_e__pat__decl, (V[]){((V)&g_heff_2esyntax_2esurface_2elw_lam0_clo), ((V)&g_heff_2esyntax_2esurface_2elw_lam1_clo), ((V)&g_heff_2esyntax_2esurface_2elw_lam2_clo)});
}
V g_heff_2esyntax_2esurface_2elw_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurface_2elw_st)) return g_heff_2esyntax_2esurface_2elw_val;
  return heff_global(&g_heff_2esyntax_2esurface_2elw_val, &g_heff_2esyntax_2esurface_2elw_st, g_heff_2esyntax_2esurface_2elw_init);
}
V g_heff_2esyntax_2esurface_2elw_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_st_241 = args[1];
  return (g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_241));
}
V g_heff_2esyntax_2esurface_2elw_lam1(V self, V *args) {
  V v_p_242 = args[0];
  V v_st_243 = args[1];
  return (g_heff_2esyntax_2esurface_2epatL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_p_242, v_st_243));
}
V g_heff_2esyntax_2esurface_2elw_lam2(V self, V *args) {
  V v_d_244 = args[0];
  V v_st_245 = args[1];
  return (g_heff_2esyntax_2esurface_2edeclL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_244, v_st_245));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_24dps_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_u_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_242, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_24dps_str0))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_u_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_u_242, 7);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2egroupOfDecl_entry, 2, 0};

V g_heff_2esyntax_2esurface_2egroupOfDecl(V v_place_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 1));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop(v_place_240);
    heff_drop_rec(v_d_241, 8);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_op_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_245 = (g_list_2emap_24s1006818869x590968200(heff_take_field(v_d_241, 1)));
    V v_t_249;
    if (heff_strEq_c(heff_dup(v_place_240), ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str0))) {
      heff_drop(v_place_240);
      v_t_249 = ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str1);
    } else {
      V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_d_241, 7)), MK_INT(1LL));
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str2), heff_intShow(v_t_247));
      v_t_249 = heff_strAppend(v_place_240, v_t_248);
    }
    V v_t_2410 = heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){heff_get_n(v_op_243, 1, 7), heff_take_field(v_d_241, 0), v_t_245, heff_get_n(v_d_241, 4, 8), v_t_249});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2egroupOfDecl(a[0], a[1]);
}
Clo g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_MkTF: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_ty_244 = heff_field(v_x2_240, 2);
    V v_d_245 = heff_field(v_x2_240, 3);
    V v_ru_24x2_240_24MkTF = heff_take_reuse_n(v_x2_240, 13ULL, 4);
    V v_x1_246 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_ty_244, v_p_241));
    switch (heff_tag_of(v_x1_246)) {
    case TAG_MkPair: {
      V v_x11_247 = heff_field(v_x1_246, 0);
      V v_st_248 = heff_field(v_x1_246, 1);
      V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
      switch (heff_tag_of(v_x11_247)) {
      case TAG_Left: {
        V v_e_249 = heff_field(v_x11_247, 0);
        heff_take_n(v_x11_247, 1ULL, 1);
        heff_drop_rec(v_x_242, 9);
        heff_drop(v_d_245);
        heff_drop_cell(v_ru_24x2_240_24MkTF, 4);
        return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
      }
      case TAG_Right: {
        V v_x_2410 = heff_field(v_x11_247, 0);
        V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
        V v_x1_2411 = (g_heff_2esyntax_2esurface_2edefaultL_24s31490894x413080387(v_d_245, v_st_248));
        switch (heff_tag_of(v_x1_2411)) {
        case TAG_MkPair: {
          V v_x11_2412 = heff_field(v_x1_2411, 0);
          V v_st_2413 = heff_field(v_x1_2411, 1);
          V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
          switch (heff_tag_of(v_x11_2412)) {
          case TAG_Left: {
            V v_e_2414 = heff_field(v_x11_2412, 0);
            heff_take_n(v_x11_2412, 1ULL, 1);
            heff_drop_rec(v_x_242, 9);
            heff_drop_cell(v_ru_24x2_240_24MkTF, 4);
            heff_drop(v_x_2410);
            heff_drop_cell(v_ru_24x11_247_24Right, 1);
            heff_drop_cell(v_ru_24x1_2411_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
          }
          case TAG_Right: {
            V v_x_2415 = heff_field(v_x11_2412, 0);
            heff_take_n(v_x11_2412, 1ULL, 1);
            V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_242, 3)), heff_take_field(v_x_242, 4)});
            V v_t_2417 = heff_tag_at_n(v_ru_24x2_240_24MkTF, TAG_DeclareField, 4, (V[]){heff_dup(heff_rfield(v_x_242, 1)), v_t_2416, heff_dup(v_x_2410), heff_dup(v_x_2415)});
            V v_x1_2419;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_Nothing: {
              v_x1_2419 = v_x_2410;
              break;
            }
            case TAG_Just: {
              V v_x_2418 = heff_field(v_x_2415, 0);
              heff_take_n(v_x_2415, 1ULL, 1);
              heff_drop(v_x_2410);
              v_x1_2419 = v_x_2418;
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            V v_b_2422;
            switch (heff_tag_of(v_x1_2419)) {
            case TAG_At: {
              V v_s_2421 = heff_field(v_x1_2419, 1);
              heff_take_n(v_x1_2419, 2ULL, 2);
              v_b_2422 = v_s_2421;
              break;
            }
            default: heff_nomatch(v_x1_2419);
            }
            V v_t_2423 = ({ V rv_0 = heff_take_field(v_x_242, 3); V rr_ = heff_rec_reuse_nf(v_b_2422, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            V v_x_2424 = heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_At, 2, (V[]){v_t_2417, v_t_2423});
            V v_t_2425 = heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_Cons, 2, (V[]){heff_get_n(v_x_242, 1, 9), heff_dup(heff_rfield(v_st_2413, 1))});
            V v_t_2426 = ({ V rv_1 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_st_2413, 253ULL, 8, shape_toks__scope__known__binders__patVars__fix__lenient__at, 65523u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2424}), v_t_2426});
          }
          default: return heff_nomatch(v_x11_2412);
          }
        }
        default: return heff_nomatch(v_x1_2411);
        }
      }
      default: return heff_nomatch(v_x11_247);
      }
    }
    default: return heff_nomatch(v_x1_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etheoryFieldL_24s1727677130x1801694839(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2einitialSt_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2einitialSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2einitialSt_entry, 5, 0};

V g_heff_2esyntax_2esurface_2einitialSt(V v_o_240, V v_at_241, V v_toks_242, V v_declared_243, V v_own_244) {
top: ;
  V v_declared_245 = (g_heff_2esyntax_2esurface_2enameSet(v_declared_243));
  V v_a_246 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_a_246, 0), heff_take_field(v_own_244, 0)));
  V v_t_248 = (g_heff_2esyntax_2efixity_2enubByG(v_t_247));
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_a_246, 1, 2), heff_get_n(v_own_244, 1, 2)));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByE(v_t_249));
  V v_fix_2411 = heff_rec_n(2, shape_groups__above, (V[]){v_t_248, v_t_2410});
  return heff_rec_n(8, shape_toks__scope__known__binders__patVars__fix__lenient__at, (V[]){v_toks_242, NTAG(TAG_Nil), heff_clo_n(g_heff_2esyntax_2esurface_2einitialSt_lam0, 1, 2, (V[]){heff_dup(v_o_240), v_declared_245}), heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), v_fix_2411, heff_get_n(v_o_240, 2, 5), v_at_241});
}
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2einitialSt(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurface_2einitialSt_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_o_240 = heff_env(self)[0];
  V v_declared_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(heff_get_n(v_o_240, 0, 5), 1, (V[]){heff_dup(v_x_2412)}));
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    heff_drop(v_declared_245);
    heff_drop(v_t_2413);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2413);
    V v_x3_2414 = ({ V a_0 = v_x_2412; V a_1 = v_declared_245; V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, a_1)); heff_drop(v_declared_245); r_; });
    switch (heff_tag_of(v_x3_2414)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2414, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_2414);
    }
  }
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V v_place_240, V v_decls_241) {
top: ;
  V v_t_242 = (g_list_2efilter_24s1443337551x1015803594(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(v_decls_241)));
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0, 1, 1, (V[]){v_place_240}), v_t_242));
  V v_groups_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_245)));
  V v_t_247 = (g_heff_2esyntax_2efixity_2enubByG(v_t_246));
  V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByE(v_t_248));
  V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eedgesOf_clo), 1, (V[]){heff_rec_n(2, shape_groups__above, (V[]){v_t_247, v_t_249})}));
  V v_t_2411 = (g_heff_2esyntax_2esurface_2econcatMapS(v_t_2410, v_decls_241));
  return ({ V a_0 = v_decls_241; V a_1 = v_groups_245; V a_2 = v_t_2411; V r_ = (g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(a_0, a_1, a_2)); heff_drop(v_decls_241); r_; });
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_place_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2egroupOfDecl(v_place_240, v_d_243));
}