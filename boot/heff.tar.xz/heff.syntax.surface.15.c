// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_BadVariant 54613
#define TAG_Braced 8190
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESBind 62182
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWord 44207
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Passes 47566
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SetPath 11095
#define TAG_Sum 30935
#define TAG_TagVariant 25174
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_above 293969847
#define LBL_args 9498020
#define LBL_assoc 294479919
#define LBL_at 9882
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_decl 9574769
#define LBL_e 319
#define LBL_end 310101
#define LBL_fix 310927
#define LBL_fixities 357800079
#define LBL_groups 709681407
#define LBL_head 9693863
#define LBL_id 10114
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_line 9817275
#define LBL_loosest 581880769
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_e__pat__decl[] = {LBL_e, LBL_pat, LBL_decl};
static uint32_t shape_groups__above[] = {LBL_groups, LBL_above};
static uint32_t shape_id__assoc__ops__loosest__at[] = {LBL_id, LBL_assoc, LBL_ops, LBL_loosest, LBL_at};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eappendF(V, V);
V g_heff_2esyntax_2efixity_2eappendF_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2eappendF_clo;
HeffT2 g_heff_2esyntax_2efixity_2efindG_24cpr(V, V);
V g_heff_2esyntax_2efixity_2enubByE(V);
V g_heff_2esyntax_2efixity_2enubByE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByE_clo;
V g_heff_2esyntax_2efixity_2enubByG(V);
V g_heff_2esyntax_2efixity_2enubByG_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2enubByG_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2espineOf(V);
V g_heff_2esyntax_2epresyntax_2espineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2espineOf_clo;
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V);
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo;
V g_heff_2esyntax_2esurface_2earrowAfter(V, V);
V g_heff_2esyntax_2esurface_2earrowAfter_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2earrowAfter_clo;
HeffT2 g_heff_2esyntax_2esurface_2easBinderOn_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eassembleGo(V, V, V);
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eassembleGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2eassembleOne_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebracedL(V, V, V);
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracedL_clo;
V g_heff_2esyntax_2esurface_2ecatMaybesS(V);
V g_heff_2esyntax_2esurface_2ecatMaybesS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatMaybesS_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(V, V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159_clo;
V g_heff_2esyntax_2esurface_2edeclL(V, V, V);
V g_heff_2esyntax_2esurface_2edeclL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(V, V, V);
V g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383_clo;
V g_heff_2esyntax_2esurface_2egroupOfDecl(V, V);
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo;
V g_heff_2esyntax_2esurface_2einitialSt(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2einitialSt_clo;
V g_heff_2esyntax_2esurface_2eisVarE(V);
V g_heff_2esyntax_2esurface_2eisVarE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eisVarE_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
HeffT2 g_heff_2esyntax_2esurface_2eparenL_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2epatL(V, V, V);
V g_heff_2esyntax_2esurface_2epatL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epatL_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2equalifiedE(V, V);
V g_heff_2esyntax_2esurface_2equalifiedE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2equalifiedE_clo;
HeffT2 g_heff_2esyntax_2esurface_2esymAtom_24cpr(V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V, V);
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewholeDefines(V);
V g_heff_2esyntax_2esurface_2ewholeDefines_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewholeDefines_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter_24s1330420811x172858565(V, V, V, V);
V g_list_2efilter_24s1330420811x172858565_entry(V self, V *a);
extern Clo g_list_2efilter_24s1330420811x172858565_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1006818869x590968200(V);
V g_list_2emap_24s1006818869x590968200_entry(V self, V *a);
extern Clo g_list_2emap_24s1006818869x590968200_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_std_2emap_2eempty_get(void);
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry, 1, 0};

V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2eisVarE(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eallS_24s486063565x1240139940(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str0, 37, "` has no fixity: declare it (`infixl ");
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str1, 34, "`), or import the module that does");
HEFF_LIT(g_heff_2esyntax_2esurface_2echeckFixOf_str2, 1, "`");
V g_heff_2esyntax_2esurface_2echeckFixOf_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2echeckFixOf_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckFixOf_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2echeckFixOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2echeckFixOf_lam2(V self, V *args);
Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2echeckFixOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2echeckFixOf(V v_fix_240, V v_lenient_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_fix_240, 2);
    return ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_2410 = (g_heff_2esyntax_2efixity_2efindG_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2echeckFixOf_lam1, 1, 1, (V[]){heff_dup(v_r_245)}), heff_dup(heff_rfield(v_fix_240, 0))));
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        heff_drop_rec(v_r_245, 2);
        V v_x_2414 = v_field_2412;
        heff_drop(v_x_2414);
        V t_0 = v_fix_240;
        V t_1 = v_lenient_241;
        V t_2 = v_rest_246;
        v_fix_240 = t_0;
        v_lenient_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_2412);
        if ((heff_dup(v_lenient_241) == NTAG(TAG_True))) {
          heff_drop_rec(v_r_245, 2);
          V t_0 = v_fix_240;
          V t_1 = v_lenient_241;
          V t_2 = v_rest_246;
          v_fix_240 = t_0;
          v_lenient_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        } else {
          heff_drop_rec(v_fix_240, 2);
          heff_drop(v_rest_246);
          V v_t_2415 = heff_dup(heff_rfield(v_r_245, 0));
          return heff_clo_n(g_heff_2esyntax_2esurface_2echeckFixOf_lam2, 1, 2, (V[]){v_r_245, v_t_2415});
        }
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2echeckFixOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam0(V self, V *args) {
  V v_st_243 = args[0];
  V v_t_244 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_244, v_st_243});
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam1(V self, V *args) {
  V v_g_247 = args[0];
  V v_r_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_get_n(heff_get_n(v_r_245, 0, 2), 1, 9);
  V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_t_248}));
  return ({ V a_0 = v_t_249; V b_1 = heff_get_n(v_g_247, 2, 5); V r_ = (g_list_2eany(a_0, b_1)); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2echeckFixOf_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_r_245 = heff_env(self)[0];
  V v_t_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_get_n(heff_dup(heff_rfield(v_r_245, 0)), 1, 9);
  V v_t_2418 = heff_get_n(heff_get_n(v_r_245, 0, 2), 1, 9);
  V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str0), heff_strAppend(v_t_2418, ((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str1)));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2echeckFixOf_str2), heff_strAppend(v_t_2417, v_t_2419));
  V v_t_2421 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2415, 3), heff_get_n(v_t_2415, 4, 9)});
  V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2420, v_t_2421, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2422}), v_st_2416});
}
Clo g_heff_2esyntax_2esurface_2eassembleGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eassembleGo_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eassembleGo(V v_broken_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  }
  case TAG_Cons: {
    V v_it_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2eassembleOne_24cpr(v_broken_240, heff_dup(v_rest_244), v_it_243));
    V v_t_2410;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_x_249 = v_field_247;
        v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_249, v_acc_242});
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_247);
        v_t_2410 = v_acc_242;
      }
    }
    V t_0 = v_broken_240;
    V t_1 = v_rest_244;
    V t_2 = v_t_2410;
    v_broken_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eassembleGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eassembleGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str1, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str3, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2ewholeDefines_str5, 18, "` is defined twice");
Clo g_heff_2esyntax_2esurface_2ewholeDefines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ewholeDefines_entry, 1, 0};

V g_heff_2esyntax_2esurface_2ewholeDefines(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_DeclEquations: {
      return NTAG(TAG_Passes);
    }
    case TAG_DeclDefine: {
      V v_x_248 = heff_field(v_x11_241, 0);
      V v_xsp_249 = heff_field(v_x11_241, 1);
      V v_t_2413 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str0), heff_strAppend(heff_dup(v_x_248), ((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str1)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_x_248), heff_dup(v_xsp_249), NTAG(TAG_Nothing), v_t_2413, NTAG(TAG_False)});
    }
    case TAG_DeclTheory: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_xsp_2415 = heff_field(v_x11_241, 1);
      V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str2), heff_strAppend(heff_dup(v_x_2414), ((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str3)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_x_2414), heff_dup(v_xsp_2415), NTAG(TAG_Nothing), v_t_2418, NTAG(TAG_False)});
    }
    case TAG_DeclPrimitive: {
      V v_x_2419 = heff_field(v_x11_241, 0);
      V v_xsp_2420 = heff_field(v_x11_241, 1);
      V v_t_2422 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str4), heff_strAppend(heff_dup(v_x_2419), ((V)&g_heff_2esyntax_2esurface_2ewholeDefines_str5)));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_x_2419), heff_dup(v_xsp_2420), NTAG(TAG_Nothing), v_t_2422, NTAG(TAG_True)});
    }
    case TAG_DeclTest: {
      return NTAG(TAG_Passes);
    }
    case TAG_DeclWatch: {
      return NTAG(TAG_Passes);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2ewholeDefines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ewholeDefines(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ekwAtom_str0, 1, ".");
Clo g_heff_2esyntax_2esurface_2ekwAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ekwAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ekwAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_fs_241)) {
  case TAG_Nil: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_f_243 = heff_dup(heff_field(v_fs_241, 0));
    V v_t_245 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ekwAtom_str0), heff_get_n(v_f_243, 1, 9));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_t_240, 1)), v_t_245);
    v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_242, 2)), 1, (V[]){v_t_246}));
    break;
  }
  default: heff_nomatch(v_fs_241);
  }
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_st_242, 2)), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  V v_x_2414;
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    heff_drop(v_t_248);
    v_x_2414 = (g_heff_2esyntax_2esurface_2equalifiedE(v_t_240, v_fs_241));
  } else {
    heff_drop(v_t_247);
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_249 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_240, 1)});
      V v_t_2410 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_2411 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2414 = (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_t_2410}), v_t_2411));
    } else {
      heff_drop(v_t_248);
      V v_e_2412 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
      V v_t_2413 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2414 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2412, v_t_2413));
    }
  }
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2414}), v_st_242});
}
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ekwAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam37(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eupdateSettingL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2eupdateSettingL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Atom: {
    V v_m_243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam0, 1, 1, (V[]){v_m_243});
  }
  case TAG_EParen: {
    V v_m_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam1, 1, 1, (V[]){v_m_2418});
  }
  case TAG_Named: {
    V v_m_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam2, 1, 1, (V[]){v_m_2435});
  }
  case TAG_Tup: {
    V v_m_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam3, 1, 1, (V[]){v_m_2451});
  }
  case TAG_Seg: {
    V v_m_2466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam4, 1, 1, (V[]){v_m_2466});
  }
  case TAG_Braces: {
    V v_m_2482 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam5, 1, 1, (V[]){v_m_2482});
  }
  case TAG_Update: {
    V v_m_24100 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam6, 1, 1, (V[]){v_m_24100});
  }
  case TAG_EUSet: {
    V v_path_24112 = heff_field(v_x2_241, 0);
    V v_e_24114 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 5ULL, 3);
    V v_m_24115 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24114}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam7, 1, 2, (V[]){v_m_24115, v_path_24112});
  }
  case TAG_InstB: {
    V v_m_24134 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam8, 1, 1, (V[]){v_m_24134});
  }
  case TAG_EFSet: {
    V v_m_24149 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam9, 1, 1, (V[]){v_m_24149});
  }
  case TAG_EFDefault: {
    V v_m_24164 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam10, 1, 1, (V[]){v_m_24164});
  }
  case TAG_Sum: {
    V v_m_24181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam11, 1, 1, (V[]){v_m_24181});
  }
  case TAG_ECon: {
    V v_m_24195 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam12, 1, 1, (V[]){v_m_24195});
  }
  case TAG_EField: {
    V v_m_24209 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam13, 1, 1, (V[]){v_m_24209});
  }
  case TAG_ENeg: {
    V v_m_24223 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam14, 1, 1, (V[]){v_m_24223});
  }
  case TAG_App: {
    V v_m_24237 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam15, 1, 1, (V[]){v_m_24237});
  }
  case TAG_Op: {
    V v_m_24252 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam16, 1, 1, (V[]){v_m_24252});
  }
  case TAG_Ops: {
    V v_m_24266 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam17, 1, 1, (V[]){v_m_24266});
  }
  case TAG_OpRhs: {
    V v_m_24280 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam18, 1, 1, (V[]){v_m_24280});
  }
  case TAG_Ann: {
    V v_m_24295 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam19, 1, 1, (V[]){v_m_24295});
  }
  case TAG_BVar: {
    V v_m_24308 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam20, 1, 1, (V[]){v_m_24308});
  }
  case TAG_BImp: {
    V v_m_24323 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam21, 1, 1, (V[]){v_m_24323});
  }
  case TAG_BAnn: {
    V v_m_24340 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam22, 1, 1, (V[]){v_m_24340});
  }
  case TAG_Lam: {
    V v_m_24356 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam23, 1, 1, (V[]){v_m_24356});
  }
  case TAG_Case: {
    V v_m_24372 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam24, 1, 1, (V[]){v_m_24372});
  }
  case TAG_EAlt: {
    V v_m_24387 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam25, 1, 1, (V[]){v_m_24387});
  }
  case TAG_If: {
    V v_m_24405 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam26, 1, 1, (V[]){v_m_24405});
  }
  case TAG_Do: {
    V v_m_24419 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam27, 1, 1, (V[]){v_m_24419});
  }
  case TAG_ESBind: {
    V v_m_24434 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam28, 1, 1, (V[]){v_m_24434});
  }
  case TAG_ELet: {
    V v_m_24452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam29, 1, 1, (V[]){v_m_24452});
  }
  case TAG_ELetMut: {
    V v_m_24470 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam30, 1, 1, (V[]){v_m_24470});
  }
  case TAG_EAssign: {
    V v_m_24485 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam31, 1, 1, (V[]){v_m_24485});
  }
  case TAG_EWhile: {
    V v_m_24501 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam32, 1, 1, (V[]){v_m_24501});
  }
  case TAG_EFor: {
    V v_m_24519 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam33, 1, 1, (V[]){v_m_24519});
  }
  case TAG_EJump: {
    V v_m_24532 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam34, 1, 1, (V[]){v_m_24532});
  }
  case TAG_EReturn: {
    V v_m_24546 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam35, 1, 1, (V[]){v_m_24546});
  }
  case TAG_ENest: {
    V v_m_24562 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam36, 1, 1, (V[]){v_m_24562});
  }
  case TAG_IfThen: {
    V v_m_24578 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eupdateSettingL_lam37, 1, 1, (V[]){v_m_24578});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eupdateSettingL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_st_244}));
  switch (heff_tag_of(v_x1_245)) {
  case TAG_MkPair: {
    V v_x11_246 = heff_field(v_x1_245, 0);
    V v_st_247 = heff_field(v_x1_245, 1);
    V v_ru_24x1_245_24MkPair = heff_take_reuse_n(v_x1_245, 3ULL, 2);
    switch (heff_tag_of(v_x11_246)) {
    case TAG_Left: {
      V v_e_248 = heff_field(v_x11_246, 0);
      heff_take_n(v_x11_246, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_248}), v_st_247});
    }
    case TAG_Right: {
      V v_x_249 = heff_field(v_x11_246, 0);
      V v_ru_24x11_246_24Right = heff_take_reuse_n(v_x11_246, 1ULL, 1);
      V v_t_2410 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_249)});
      V v_t_2413;
      switch (heff_tag_of(v_x_249)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_x_249, 1);
        heff_take_n(v_x_249, 2ULL, 2);
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_x_249);
      }
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_246_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2413})});
      return heff_tag_at_n(v_ru_24x1_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_247});
    }
    default: return heff_nomatch(v_x11_246);
    }
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam1(V self, V *args) {
  V v_st_2419 = args[0];
  V v_m_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2420 = heff_tr(heff_call(v_m_2418, 1, (V[]){v_st_2419}));
  switch (heff_tag_of(v_x1_2420)) {
  case TAG_MkPair: {
    V v_x11_2421 = heff_field(v_x1_2420, 0);
    V v_st_2422 = heff_field(v_x1_2420, 1);
    V v_ru_24x1_2420_24MkPair = heff_take_reuse_n(v_x1_2420, 3ULL, 2);
    switch (heff_tag_of(v_x11_2421)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x11_2421, 0);
      heff_take_n(v_x11_2421, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2423}), v_st_2422});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x11_2421, 0);
      V v_ru_24x11_2421_24Right = heff_take_reuse_n(v_x11_2421, 1ULL, 1);
      V v_t_2425 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2424)});
      V v_t_2428;
      switch (heff_tag_of(v_x_2424)) {
      case TAG_At: {
        V v_s_2427 = heff_field(v_x_2424, 1);
        heff_take_n(v_x_2424, 2ULL, 2);
        v_t_2428 = v_s_2427;
        break;
      }
      default: heff_nomatch(v_x_2424);
      }
      V v_t_2429 = heff_tag_at_n(v_ru_24x11_2421_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_t_2428})});
      return heff_tag_at_n(v_ru_24x1_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, v_st_2422});
    }
    default: return heff_nomatch(v_x11_2421);
    }
  }
  default: return heff_nomatch(v_x1_2420);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam2(V self, V *args) {
  V v_st_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2437 = heff_tr(heff_call(v_m_2435, 1, (V[]){v_st_2436}));
  switch (heff_tag_of(v_x1_2437)) {
  case TAG_MkPair: {
    V v_x11_2438 = heff_field(v_x1_2437, 0);
    V v_st_2439 = heff_field(v_x1_2437, 1);
    V v_ru_24x1_2437_24MkPair = heff_take_reuse_n(v_x1_2437, 3ULL, 2);
    switch (heff_tag_of(v_x11_2438)) {
    case TAG_Left: {
      V v_e_2440 = heff_field(v_x11_2438, 0);
      heff_take_n(v_x11_2438, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
    }
    case TAG_Right: {
      V v_x_2441 = heff_field(v_x11_2438, 0);
      V v_ru_24x11_2438_24Right = heff_take_reuse_n(v_x11_2438, 1ULL, 1);
      V v_t_2442 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2441)});
      V v_t_2445;
      switch (heff_tag_of(v_x_2441)) {
      case TAG_At: {
        V v_s_2444 = heff_field(v_x_2441, 1);
        heff_take_n(v_x_2441, 2ULL, 2);
        v_t_2445 = v_s_2444;
        break;
      }
      default: heff_nomatch(v_x_2441);
      }
      V v_t_2446 = heff_tag_at_n(v_ru_24x11_2438_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2442, v_t_2445})});
      return heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_MkPair, 2, (V[]){v_t_2446, v_st_2439});
    }
    default: return heff_nomatch(v_x11_2438);
    }
  }
  default: return heff_nomatch(v_x1_2437);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam3(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
      V v_t_2458 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2457)});
      V v_t_2461;
      switch (heff_tag_of(v_x_2457)) {
      case TAG_At: {
        V v_s_2460 = heff_field(v_x_2457, 1);
        heff_take_n(v_x_2457, 2ULL, 2);
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_x_2457);
      }
      V v_t_2462 = heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2458, v_t_2461})});
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){v_t_2462, v_st_2455});
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam4(V self, V *args) {
  V v_st_2467 = args[0];
  V v_m_2466 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2468 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_st_2467}));
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_MkPair: {
    V v_x11_2469 = heff_field(v_x1_2468, 0);
    V v_st_2470 = heff_field(v_x1_2468, 1);
    V v_ru_24x1_2468_24MkPair = heff_take_reuse_n(v_x1_2468, 3ULL, 2);
    switch (heff_tag_of(v_x11_2469)) {
    case TAG_Left: {
      V v_e_2471 = heff_field(v_x11_2469, 0);
      heff_take_n(v_x11_2469, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2471}), v_st_2470});
    }
    case TAG_Right: {
      V v_x_2472 = heff_field(v_x11_2469, 0);
      V v_ru_24x11_2469_24Right = heff_take_reuse_n(v_x11_2469, 1ULL, 1);
      V v_t_2473 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2472)});
      V v_t_2476;
      switch (heff_tag_of(v_x_2472)) {
      case TAG_At: {
        V v_s_2475 = heff_field(v_x_2472, 1);
        heff_take_n(v_x_2472, 2ULL, 2);
        v_t_2476 = v_s_2475;
        break;
      }
      default: heff_nomatch(v_x_2472);
      }
      V v_t_2477 = heff_tag_at_n(v_ru_24x11_2469_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2473, v_t_2476})});
      return heff_tag_at_n(v_ru_24x1_2468_24MkPair, TAG_MkPair, 2, (V[]){v_t_2477, v_st_2470});
    }
    default: return heff_nomatch(v_x11_2469);
    }
  }
  default: return heff_nomatch(v_x1_2468);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam5(V self, V *args) {
  V v_st_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_st_2483}));
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_MkPair: {
    V v_x11_2485 = heff_field(v_x1_2484, 0);
    V v_st_2486 = heff_field(v_x1_2484, 1);
    V v_ru_24x1_2484_24MkPair = heff_take_reuse_n(v_x1_2484, 3ULL, 2);
    switch (heff_tag_of(v_x11_2485)) {
    case TAG_Left: {
      V v_e_2487 = heff_field(v_x11_2485, 0);
      heff_take_n(v_x11_2485, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2487}), v_st_2486});
    }
    case TAG_Right: {
      V v_x_2488 = heff_field(v_x11_2485, 0);
      V v_ru_24x11_2485_24Right = heff_take_reuse_n(v_x11_2485, 1ULL, 1);
      V v_t_2489 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_2488)});
      V v_t_2492;
      switch (heff_tag_of(v_x_2488)) {
      case TAG_At: {
        V v_s_2491 = heff_field(v_x_2488, 1);
        heff_take_n(v_x_2488, 2ULL, 2);
        v_t_2492 = v_s_2491;
        break;
      }
      default: heff_nomatch(v_x_2488);
      }
      V v_t_2493 = heff_tag_at_n(v_ru_24x11_2485_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2489, v_t_2492})});
      return heff_tag_at_n(v_ru_24x1_2484_24MkPair, TAG_MkPair, 2, (V[]){v_t_2493, v_st_2486});
    }
    default: return heff_nomatch(v_x11_2485);
    }
  }
  default: return heff_nomatch(v_x1_2484);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam6(V self, V *args) {
  V v_st_24101 = args[0];
  V v_m_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24102 = heff_tr(heff_call(v_m_24100, 1, (V[]){v_st_24101}));
  switch (heff_tag_of(v_x1_24102)) {
  case TAG_MkPair: {
    V v_x11_24103 = heff_field(v_x1_24102, 0);
    V v_st_24104 = heff_field(v_x1_24102, 1);
    V v_ru_24x1_24102_24MkPair = heff_take_reuse_n(v_x1_24102, 3ULL, 2);
    switch (heff_tag_of(v_x11_24103)) {
    case TAG_Left: {
      V v_e_24105 = heff_field(v_x11_24103, 0);
      heff_take_n(v_x11_24103, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24105}), v_st_24104});
    }
    case TAG_Right: {
      V v_x_24106 = heff_field(v_x11_24103, 0);
      V v_ru_24x11_24103_24Right = heff_take_reuse_n(v_x11_24103, 1ULL, 1);
      V v_t_24107 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24106)});
      V v_t_24110;
      switch (heff_tag_of(v_x_24106)) {
      case TAG_At: {
        V v_s_24109 = heff_field(v_x_24106, 1);
        heff_take_n(v_x_24106, 2ULL, 2);
        v_t_24110 = v_s_24109;
        break;
      }
      default: heff_nomatch(v_x_24106);
      }
      V v_t_24111 = heff_tag_at_n(v_ru_24x11_24103_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24107, v_t_24110})});
      return heff_tag_at_n(v_ru_24x1_24102_24MkPair, TAG_MkPair, 2, (V[]){v_t_24111, v_st_24104});
    }
    default: return heff_nomatch(v_x11_24103);
    }
  }
  default: return heff_nomatch(v_x1_24102);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam7(V self, V *args) {
  V v_st_24116 = args[0];
  V v_m_24115 = heff_env(self)[0];
  V v_path_24112 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24117 = heff_tr(heff_call(v_m_24115, 1, (V[]){v_st_24116}));
  switch (heff_tag_of(v_x1_24117)) {
  case TAG_MkPair: {
    V v_x11_24118 = heff_field(v_x1_24117, 0);
    V v_st_24119 = heff_field(v_x1_24117, 1);
    V v_ru_24x1_24117_24MkPair = heff_take_reuse_n(v_x1_24117, 3ULL, 2);
    switch (heff_tag_of(v_x11_24118)) {
    case TAG_Left: {
      V v_e_24120 = heff_field(v_x11_24118, 0);
      heff_take_n(v_x11_24118, 1ULL, 1);
      heff_drop(v_path_24112);
      return heff_tag_at_n(v_ru_24x1_24117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24120}), v_st_24119});
    }
    case TAG_Right: {
      V v_x_24121 = heff_field(v_x11_24118, 0);
      heff_take_n(v_x11_24118, 1ULL, 1);
      V v_t_24122 = (g_heff_2esyntax_2esurface_2epathOf(heff_dup(v_path_24112), NTAG(TAG_Nil)));
      V v_t_24123 = ({ V a_0 = v_path_24112; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_path_24112); r_; });
      V v_t_24126;
      switch (heff_tag_of(v_x_24121)) {
      case TAG_At: {
        V v_s_24125 = heff_dup(heff_field(v_x_24121, 1));
        v_t_24126 = v_s_24125;
        break;
      }
      default: heff_nomatch(v_x_24121);
      }
      V v_t_24127 = ({ V rv_0 = heff_get_n(v_t_24123, 3, 9); V rr_ = heff_rec_reuse_nf(v_t_24126, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_24128 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_t_24122, v_x_24121}), v_t_24127});
      return heff_tag_at_n(v_ru_24x1_24117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24128}), v_st_24119});
    }
    default: return heff_nomatch(v_x11_24118);
    }
  }
  default: return heff_nomatch(v_x1_24117);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam8(V self, V *args) {
  V v_st_24135 = args[0];
  V v_m_24134 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24136 = heff_tr(heff_call(v_m_24134, 1, (V[]){v_st_24135}));
  switch (heff_tag_of(v_x1_24136)) {
  case TAG_MkPair: {
    V v_x11_24137 = heff_field(v_x1_24136, 0);
    V v_st_24138 = heff_field(v_x1_24136, 1);
    V v_ru_24x1_24136_24MkPair = heff_take_reuse_n(v_x1_24136, 3ULL, 2);
    switch (heff_tag_of(v_x11_24137)) {
    case TAG_Left: {
      V v_e_24139 = heff_field(v_x11_24137, 0);
      heff_take_n(v_x11_24137, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24139}), v_st_24138});
    }
    case TAG_Right: {
      V v_x_24140 = heff_field(v_x11_24137, 0);
      V v_ru_24x11_24137_24Right = heff_take_reuse_n(v_x11_24137, 1ULL, 1);
      V v_t_24141 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24140)});
      V v_t_24144;
      switch (heff_tag_of(v_x_24140)) {
      case TAG_At: {
        V v_s_24143 = heff_field(v_x_24140, 1);
        heff_take_n(v_x_24140, 2ULL, 2);
        v_t_24144 = v_s_24143;
        break;
      }
      default: heff_nomatch(v_x_24140);
      }
      V v_t_24145 = heff_tag_at_n(v_ru_24x11_24137_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24141, v_t_24144})});
      return heff_tag_at_n(v_ru_24x1_24136_24MkPair, TAG_MkPair, 2, (V[]){v_t_24145, v_st_24138});
    }
    default: return heff_nomatch(v_x11_24137);
    }
  }
  default: return heff_nomatch(v_x1_24136);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam9(V self, V *args) {
  V v_st_24150 = args[0];
  V v_m_24149 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24151 = heff_tr(heff_call(v_m_24149, 1, (V[]){v_st_24150}));
  switch (heff_tag_of(v_x1_24151)) {
  case TAG_MkPair: {
    V v_x11_24152 = heff_field(v_x1_24151, 0);
    V v_st_24153 = heff_field(v_x1_24151, 1);
    V v_ru_24x1_24151_24MkPair = heff_take_reuse_n(v_x1_24151, 3ULL, 2);
    switch (heff_tag_of(v_x11_24152)) {
    case TAG_Left: {
      V v_e_24154 = heff_field(v_x11_24152, 0);
      heff_take_n(v_x11_24152, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24151_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24154}), v_st_24153});
    }
    case TAG_Right: {
      V v_x_24155 = heff_field(v_x11_24152, 0);
      V v_ru_24x11_24152_24Right = heff_take_reuse_n(v_x11_24152, 1ULL, 1);
      V v_t_24156 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24155)});
      V v_t_24159;
      switch (heff_tag_of(v_x_24155)) {
      case TAG_At: {
        V v_s_24158 = heff_field(v_x_24155, 1);
        heff_take_n(v_x_24155, 2ULL, 2);
        v_t_24159 = v_s_24158;
        break;
      }
      default: heff_nomatch(v_x_24155);
      }
      V v_t_24160 = heff_tag_at_n(v_ru_24x11_24152_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24156, v_t_24159})});
      return heff_tag_at_n(v_ru_24x1_24151_24MkPair, TAG_MkPair, 2, (V[]){v_t_24160, v_st_24153});
    }
    default: return heff_nomatch(v_x11_24152);
    }
  }
  default: return heff_nomatch(v_x1_24151);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam10(V self, V *args) {
  V v_st_24165 = args[0];
  V v_m_24164 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24166 = heff_tr(heff_call(v_m_24164, 1, (V[]){v_st_24165}));
  switch (heff_tag_of(v_x1_24166)) {
  case TAG_MkPair: {
    V v_x11_24167 = heff_field(v_x1_24166, 0);
    V v_st_24168 = heff_field(v_x1_24166, 1);
    V v_ru_24x1_24166_24MkPair = heff_take_reuse_n(v_x1_24166, 3ULL, 2);
    switch (heff_tag_of(v_x11_24167)) {
    case TAG_Left: {
      V v_e_24169 = heff_field(v_x11_24167, 0);
      heff_take_n(v_x11_24167, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24169}), v_st_24168});
    }
    case TAG_Right: {
      V v_x_24170 = heff_field(v_x11_24167, 0);
      V v_ru_24x11_24167_24Right = heff_take_reuse_n(v_x11_24167, 1ULL, 1);
      V v_t_24171 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24170)});
      V v_t_24174;
      switch (heff_tag_of(v_x_24170)) {
      case TAG_At: {
        V v_s_24173 = heff_field(v_x_24170, 1);
        heff_take_n(v_x_24170, 2ULL, 2);
        v_t_24174 = v_s_24173;
        break;
      }
      default: heff_nomatch(v_x_24170);
      }
      V v_t_24175 = heff_tag_at_n(v_ru_24x11_24167_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24171, v_t_24174})});
      return heff_tag_at_n(v_ru_24x1_24166_24MkPair, TAG_MkPair, 2, (V[]){v_t_24175, v_st_24168});
    }
    default: return heff_nomatch(v_x11_24167);
    }
  }
  default: return heff_nomatch(v_x1_24166);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam11(V self, V *args) {
  V v_st_24182 = args[0];
  V v_m_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24183 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_st_24182}));
  switch (heff_tag_of(v_x1_24183)) {
  case TAG_MkPair: {
    V v_x11_24184 = heff_field(v_x1_24183, 0);
    V v_st_24185 = heff_field(v_x1_24183, 1);
    V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
    switch (heff_tag_of(v_x11_24184)) {
    case TAG_Left: {
      V v_e_24186 = heff_field(v_x11_24184, 0);
      heff_take_n(v_x11_24184, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
    }
    case TAG_Right: {
      V v_x_24187 = heff_field(v_x11_24184, 0);
      V v_ru_24x11_24184_24Right = heff_take_reuse_n(v_x11_24184, 1ULL, 1);
      V v_t_24188 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24187)});
      V v_t_24191;
      switch (heff_tag_of(v_x_24187)) {
      case TAG_At: {
        V v_s_24190 = heff_field(v_x_24187, 1);
        heff_take_n(v_x_24187, 2ULL, 2);
        v_t_24191 = v_s_24190;
        break;
      }
      default: heff_nomatch(v_x_24187);
      }
      V v_t_24192 = heff_tag_at_n(v_ru_24x11_24184_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24188, v_t_24191})});
      return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){v_t_24192, v_st_24185});
    }
    default: return heff_nomatch(v_x11_24184);
    }
  }
  default: return heff_nomatch(v_x1_24183);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam12(V self, V *args) {
  V v_st_24196 = args[0];
  V v_m_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24197 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_st_24196}));
  switch (heff_tag_of(v_x1_24197)) {
  case TAG_MkPair: {
    V v_x11_24198 = heff_field(v_x1_24197, 0);
    V v_st_24199 = heff_field(v_x1_24197, 1);
    V v_ru_24x1_24197_24MkPair = heff_take_reuse_n(v_x1_24197, 3ULL, 2);
    switch (heff_tag_of(v_x11_24198)) {
    case TAG_Left: {
      V v_e_24200 = heff_field(v_x11_24198, 0);
      heff_take_n(v_x11_24198, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24200}), v_st_24199});
    }
    case TAG_Right: {
      V v_x_24201 = heff_field(v_x11_24198, 0);
      V v_ru_24x11_24198_24Right = heff_take_reuse_n(v_x11_24198, 1ULL, 1);
      V v_t_24202 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24201)});
      V v_t_24205;
      switch (heff_tag_of(v_x_24201)) {
      case TAG_At: {
        V v_s_24204 = heff_field(v_x_24201, 1);
        heff_take_n(v_x_24201, 2ULL, 2);
        v_t_24205 = v_s_24204;
        break;
      }
      default: heff_nomatch(v_x_24201);
      }
      V v_t_24206 = heff_tag_at_n(v_ru_24x11_24198_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24202, v_t_24205})});
      return heff_tag_at_n(v_ru_24x1_24197_24MkPair, TAG_MkPair, 2, (V[]){v_t_24206, v_st_24199});
    }
    default: return heff_nomatch(v_x11_24198);
    }
  }
  default: return heff_nomatch(v_x1_24197);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam13(V self, V *args) {
  V v_st_24210 = args[0];
  V v_m_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24211 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_st_24210}));
  switch (heff_tag_of(v_x1_24211)) {
  case TAG_MkPair: {
    V v_x11_24212 = heff_field(v_x1_24211, 0);
    V v_st_24213 = heff_field(v_x1_24211, 1);
    V v_ru_24x1_24211_24MkPair = heff_take_reuse_n(v_x1_24211, 3ULL, 2);
    switch (heff_tag_of(v_x11_24212)) {
    case TAG_Left: {
      V v_e_24214 = heff_field(v_x11_24212, 0);
      heff_take_n(v_x11_24212, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24214}), v_st_24213});
    }
    case TAG_Right: {
      V v_x_24215 = heff_field(v_x11_24212, 0);
      V v_ru_24x11_24212_24Right = heff_take_reuse_n(v_x11_24212, 1ULL, 1);
      V v_t_24216 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24215)});
      V v_t_24219;
      switch (heff_tag_of(v_x_24215)) {
      case TAG_At: {
        V v_s_24218 = heff_field(v_x_24215, 1);
        heff_take_n(v_x_24215, 2ULL, 2);
        v_t_24219 = v_s_24218;
        break;
      }
      default: heff_nomatch(v_x_24215);
      }
      V v_t_24220 = heff_tag_at_n(v_ru_24x11_24212_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24216, v_t_24219})});
      return heff_tag_at_n(v_ru_24x1_24211_24MkPair, TAG_MkPair, 2, (V[]){v_t_24220, v_st_24213});
    }
    default: return heff_nomatch(v_x11_24212);
    }
  }
  default: return heff_nomatch(v_x1_24211);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam14(V self, V *args) {
  V v_st_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24225 = heff_tr(heff_call(v_m_24223, 1, (V[]){v_st_24224}));
  switch (heff_tag_of(v_x1_24225)) {
  case TAG_MkPair: {
    V v_x11_24226 = heff_field(v_x1_24225, 0);
    V v_st_24227 = heff_field(v_x1_24225, 1);
    V v_ru_24x1_24225_24MkPair = heff_take_reuse_n(v_x1_24225, 3ULL, 2);
    switch (heff_tag_of(v_x11_24226)) {
    case TAG_Left: {
      V v_e_24228 = heff_field(v_x11_24226, 0);
      heff_take_n(v_x11_24226, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24228}), v_st_24227});
    }
    case TAG_Right: {
      V v_x_24229 = heff_field(v_x11_24226, 0);
      V v_ru_24x11_24226_24Right = heff_take_reuse_n(v_x11_24226, 1ULL, 1);
      V v_t_24230 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24229)});
      V v_t_24233;
      switch (heff_tag_of(v_x_24229)) {
      case TAG_At: {
        V v_s_24232 = heff_field(v_x_24229, 1);
        heff_take_n(v_x_24229, 2ULL, 2);
        v_t_24233 = v_s_24232;
        break;
      }
      default: heff_nomatch(v_x_24229);
      }
      V v_t_24234 = heff_tag_at_n(v_ru_24x11_24226_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24230, v_t_24233})});
      return heff_tag_at_n(v_ru_24x1_24225_24MkPair, TAG_MkPair, 2, (V[]){v_t_24234, v_st_24227});
    }
    default: return heff_nomatch(v_x11_24226);
    }
  }
  default: return heff_nomatch(v_x1_24225);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam15(V self, V *args) {
  V v_st_24238 = args[0];
  V v_m_24237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24239 = heff_tr(heff_call(v_m_24237, 1, (V[]){v_st_24238}));
  switch (heff_tag_of(v_x1_24239)) {
  case TAG_MkPair: {
    V v_x11_24240 = heff_field(v_x1_24239, 0);
    V v_st_24241 = heff_field(v_x1_24239, 1);
    V v_ru_24x1_24239_24MkPair = heff_take_reuse_n(v_x1_24239, 3ULL, 2);
    switch (heff_tag_of(v_x11_24240)) {
    case TAG_Left: {
      V v_e_24242 = heff_field(v_x11_24240, 0);
      heff_take_n(v_x11_24240, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24242}), v_st_24241});
    }
    case TAG_Right: {
      V v_x_24243 = heff_field(v_x11_24240, 0);
      V v_ru_24x11_24240_24Right = heff_take_reuse_n(v_x11_24240, 1ULL, 1);
      V v_t_24244 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24243)});
      V v_t_24247;
      switch (heff_tag_of(v_x_24243)) {
      case TAG_At: {
        V v_s_24246 = heff_field(v_x_24243, 1);
        heff_take_n(v_x_24243, 2ULL, 2);
        v_t_24247 = v_s_24246;
        break;
      }
      default: heff_nomatch(v_x_24243);
      }
      V v_t_24248 = heff_tag_at_n(v_ru_24x11_24240_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24244, v_t_24247})});
      return heff_tag_at_n(v_ru_24x1_24239_24MkPair, TAG_MkPair, 2, (V[]){v_t_24248, v_st_24241});
    }
    default: return heff_nomatch(v_x11_24240);
    }
  }
  default: return heff_nomatch(v_x1_24239);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam16(V self, V *args) {
  V v_st_24253 = args[0];
  V v_m_24252 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24254 = heff_tr(heff_call(v_m_24252, 1, (V[]){v_st_24253}));
  switch (heff_tag_of(v_x1_24254)) {
  case TAG_MkPair: {
    V v_x11_24255 = heff_field(v_x1_24254, 0);
    V v_st_24256 = heff_field(v_x1_24254, 1);
    V v_ru_24x1_24254_24MkPair = heff_take_reuse_n(v_x1_24254, 3ULL, 2);
    switch (heff_tag_of(v_x11_24255)) {
    case TAG_Left: {
      V v_e_24257 = heff_field(v_x11_24255, 0);
      heff_take_n(v_x11_24255, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24257}), v_st_24256});
    }
    case TAG_Right: {
      V v_x_24258 = heff_field(v_x11_24255, 0);
      V v_ru_24x11_24255_24Right = heff_take_reuse_n(v_x11_24255, 1ULL, 1);
      V v_t_24259 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24258)});
      V v_t_24262;
      switch (heff_tag_of(v_x_24258)) {
      case TAG_At: {
        V v_s_24261 = heff_field(v_x_24258, 1);
        heff_take_n(v_x_24258, 2ULL, 2);
        v_t_24262 = v_s_24261;
        break;
      }
      default: heff_nomatch(v_x_24258);
      }
      V v_t_24263 = heff_tag_at_n(v_ru_24x11_24255_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24259, v_t_24262})});
      return heff_tag_at_n(v_ru_24x1_24254_24MkPair, TAG_MkPair, 2, (V[]){v_t_24263, v_st_24256});
    }
    default: return heff_nomatch(v_x11_24255);
    }
  }
  default: return heff_nomatch(v_x1_24254);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam17(V self, V *args) {
  V v_st_24267 = args[0];
  V v_m_24266 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24268 = heff_tr(heff_call(v_m_24266, 1, (V[]){v_st_24267}));
  switch (heff_tag_of(v_x1_24268)) {
  case TAG_MkPair: {
    V v_x11_24269 = heff_field(v_x1_24268, 0);
    V v_st_24270 = heff_field(v_x1_24268, 1);
    V v_ru_24x1_24268_24MkPair = heff_take_reuse_n(v_x1_24268, 3ULL, 2);
    switch (heff_tag_of(v_x11_24269)) {
    case TAG_Left: {
      V v_e_24271 = heff_field(v_x11_24269, 0);
      heff_take_n(v_x11_24269, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
    }
    case TAG_Right: {
      V v_x_24272 = heff_field(v_x11_24269, 0);
      V v_ru_24x11_24269_24Right = heff_take_reuse_n(v_x11_24269, 1ULL, 1);
      V v_t_24273 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24272)});
      V v_t_24276;
      switch (heff_tag_of(v_x_24272)) {
      case TAG_At: {
        V v_s_24275 = heff_field(v_x_24272, 1);
        heff_take_n(v_x_24272, 2ULL, 2);
        v_t_24276 = v_s_24275;
        break;
      }
      default: heff_nomatch(v_x_24272);
      }
      V v_t_24277 = heff_tag_at_n(v_ru_24x11_24269_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24273, v_t_24276})});
      return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){v_t_24277, v_st_24270});
    }
    default: return heff_nomatch(v_x11_24269);
    }
  }
  default: return heff_nomatch(v_x1_24268);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam18(V self, V *args) {
  V v_st_24281 = args[0];
  V v_m_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24282 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_st_24281}));
  switch (heff_tag_of(v_x1_24282)) {
  case TAG_MkPair: {
    V v_x11_24283 = heff_field(v_x1_24282, 0);
    V v_st_24284 = heff_field(v_x1_24282, 1);
    V v_ru_24x1_24282_24MkPair = heff_take_reuse_n(v_x1_24282, 3ULL, 2);
    switch (heff_tag_of(v_x11_24283)) {
    case TAG_Left: {
      V v_e_24285 = heff_field(v_x11_24283, 0);
      heff_take_n(v_x11_24283, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24285}), v_st_24284});
    }
    case TAG_Right: {
      V v_x_24286 = heff_field(v_x11_24283, 0);
      V v_ru_24x11_24283_24Right = heff_take_reuse_n(v_x11_24283, 1ULL, 1);
      V v_t_24287 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24286)});
      V v_t_24290;
      switch (heff_tag_of(v_x_24286)) {
      case TAG_At: {
        V v_s_24289 = heff_field(v_x_24286, 1);
        heff_take_n(v_x_24286, 2ULL, 2);
        v_t_24290 = v_s_24289;
        break;
      }
      default: heff_nomatch(v_x_24286);
      }
      V v_t_24291 = heff_tag_at_n(v_ru_24x11_24283_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24287, v_t_24290})});
      return heff_tag_at_n(v_ru_24x1_24282_24MkPair, TAG_MkPair, 2, (V[]){v_t_24291, v_st_24284});
    }
    default: return heff_nomatch(v_x11_24283);
    }
  }
  default: return heff_nomatch(v_x1_24282);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam19(V self, V *args) {
  V v_st_24296 = args[0];
  V v_m_24295 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24297 = heff_tr(heff_call(v_m_24295, 1, (V[]){v_st_24296}));
  switch (heff_tag_of(v_x1_24297)) {
  case TAG_MkPair: {
    V v_x11_24298 = heff_field(v_x1_24297, 0);
    V v_st_24299 = heff_field(v_x1_24297, 1);
    V v_ru_24x1_24297_24MkPair = heff_take_reuse_n(v_x1_24297, 3ULL, 2);
    switch (heff_tag_of(v_x11_24298)) {
    case TAG_Left: {
      V v_e_24300 = heff_field(v_x11_24298, 0);
      heff_take_n(v_x11_24298, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24300}), v_st_24299});
    }
    case TAG_Right: {
      V v_x_24301 = heff_field(v_x11_24298, 0);
      V v_ru_24x11_24298_24Right = heff_take_reuse_n(v_x11_24298, 1ULL, 1);
      V v_t_24302 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24301)});
      V v_t_24305;
      switch (heff_tag_of(v_x_24301)) {
      case TAG_At: {
        V v_s_24304 = heff_field(v_x_24301, 1);
        heff_take_n(v_x_24301, 2ULL, 2);
        v_t_24305 = v_s_24304;
        break;
      }
      default: heff_nomatch(v_x_24301);
      }
      V v_t_24306 = heff_tag_at_n(v_ru_24x11_24298_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24302, v_t_24305})});
      return heff_tag_at_n(v_ru_24x1_24297_24MkPair, TAG_MkPair, 2, (V[]){v_t_24306, v_st_24299});
    }
    default: return heff_nomatch(v_x11_24298);
    }
  }
  default: return heff_nomatch(v_x1_24297);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam20(V self, V *args) {
  V v_st_24309 = args[0];
  V v_m_24308 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24310 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_st_24309}));
  switch (heff_tag_of(v_x1_24310)) {
  case TAG_MkPair: {
    V v_x11_24311 = heff_field(v_x1_24310, 0);
    V v_st_24312 = heff_field(v_x1_24310, 1);
    V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
    switch (heff_tag_of(v_x11_24311)) {
    case TAG_Left: {
      V v_e_24313 = heff_field(v_x11_24311, 0);
      heff_take_n(v_x11_24311, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
    }
    case TAG_Right: {
      V v_x_24314 = heff_field(v_x11_24311, 0);
      V v_ru_24x11_24311_24Right = heff_take_reuse_n(v_x11_24311, 1ULL, 1);
      V v_t_24315 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24314)});
      V v_t_24318;
      switch (heff_tag_of(v_x_24314)) {
      case TAG_At: {
        V v_s_24317 = heff_field(v_x_24314, 1);
        heff_take_n(v_x_24314, 2ULL, 2);
        v_t_24318 = v_s_24317;
        break;
      }
      default: heff_nomatch(v_x_24314);
      }
      V v_t_24319 = heff_tag_at_n(v_ru_24x11_24311_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24315, v_t_24318})});
      return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){v_t_24319, v_st_24312});
    }
    default: return heff_nomatch(v_x11_24311);
    }
  }
  default: return heff_nomatch(v_x1_24310);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam21(V self, V *args) {
  V v_st_24324 = args[0];
  V v_m_24323 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24325 = heff_tr(heff_call(v_m_24323, 1, (V[]){v_st_24324}));
  switch (heff_tag_of(v_x1_24325)) {
  case TAG_MkPair: {
    V v_x11_24326 = heff_field(v_x1_24325, 0);
    V v_st_24327 = heff_field(v_x1_24325, 1);
    V v_ru_24x1_24325_24MkPair = heff_take_reuse_n(v_x1_24325, 3ULL, 2);
    switch (heff_tag_of(v_x11_24326)) {
    case TAG_Left: {
      V v_e_24328 = heff_field(v_x11_24326, 0);
      heff_take_n(v_x11_24326, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24325_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24328}), v_st_24327});
    }
    case TAG_Right: {
      V v_x_24329 = heff_field(v_x11_24326, 0);
      V v_ru_24x11_24326_24Right = heff_take_reuse_n(v_x11_24326, 1ULL, 1);
      V v_t_24330 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24329)});
      V v_t_24333;
      switch (heff_tag_of(v_x_24329)) {
      case TAG_At: {
        V v_s_24332 = heff_field(v_x_24329, 1);
        heff_take_n(v_x_24329, 2ULL, 2);
        v_t_24333 = v_s_24332;
        break;
      }
      default: heff_nomatch(v_x_24329);
      }
      V v_t_24334 = heff_tag_at_n(v_ru_24x11_24326_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24330, v_t_24333})});
      return heff_tag_at_n(v_ru_24x1_24325_24MkPair, TAG_MkPair, 2, (V[]){v_t_24334, v_st_24327});
    }
    default: return heff_nomatch(v_x11_24326);
    }
  }
  default: return heff_nomatch(v_x1_24325);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam22(V self, V *args) {
  V v_st_24341 = args[0];
  V v_m_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24342 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_st_24341}));
  switch (heff_tag_of(v_x1_24342)) {
  case TAG_MkPair: {
    V v_x11_24343 = heff_field(v_x1_24342, 0);
    V v_st_24344 = heff_field(v_x1_24342, 1);
    V v_ru_24x1_24342_24MkPair = heff_take_reuse_n(v_x1_24342, 3ULL, 2);
    switch (heff_tag_of(v_x11_24343)) {
    case TAG_Left: {
      V v_e_24345 = heff_field(v_x11_24343, 0);
      heff_take_n(v_x11_24343, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24345}), v_st_24344});
    }
    case TAG_Right: {
      V v_x_24346 = heff_field(v_x11_24343, 0);
      V v_ru_24x11_24343_24Right = heff_take_reuse_n(v_x11_24343, 1ULL, 1);
      V v_t_24347 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24346)});
      V v_t_24350;
      switch (heff_tag_of(v_x_24346)) {
      case TAG_At: {
        V v_s_24349 = heff_field(v_x_24346, 1);
        heff_take_n(v_x_24346, 2ULL, 2);
        v_t_24350 = v_s_24349;
        break;
      }
      default: heff_nomatch(v_x_24346);
      }
      V v_t_24351 = heff_tag_at_n(v_ru_24x11_24343_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24347, v_t_24350})});
      return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){v_t_24351, v_st_24344});
    }
    default: return heff_nomatch(v_x11_24343);
    }
  }
  default: return heff_nomatch(v_x1_24342);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam23(V self, V *args) {
  V v_st_24357 = args[0];
  V v_m_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24358 = heff_tr(heff_call(v_m_24356, 1, (V[]){v_st_24357}));
  switch (heff_tag_of(v_x1_24358)) {
  case TAG_MkPair: {
    V v_x11_24359 = heff_field(v_x1_24358, 0);
    V v_st_24360 = heff_field(v_x1_24358, 1);
    V v_ru_24x1_24358_24MkPair = heff_take_reuse_n(v_x1_24358, 3ULL, 2);
    switch (heff_tag_of(v_x11_24359)) {
    case TAG_Left: {
      V v_e_24361 = heff_field(v_x11_24359, 0);
      heff_take_n(v_x11_24359, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24361}), v_st_24360});
    }
    case TAG_Right: {
      V v_x_24362 = heff_field(v_x11_24359, 0);
      V v_ru_24x11_24359_24Right = heff_take_reuse_n(v_x11_24359, 1ULL, 1);
      V v_t_24363 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24362)});
      V v_t_24366;
      switch (heff_tag_of(v_x_24362)) {
      case TAG_At: {
        V v_s_24365 = heff_field(v_x_24362, 1);
        heff_take_n(v_x_24362, 2ULL, 2);
        v_t_24366 = v_s_24365;
        break;
      }
      default: heff_nomatch(v_x_24362);
      }
      V v_t_24367 = heff_tag_at_n(v_ru_24x11_24359_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24363, v_t_24366})});
      return heff_tag_at_n(v_ru_24x1_24358_24MkPair, TAG_MkPair, 2, (V[]){v_t_24367, v_st_24360});
    }
    default: return heff_nomatch(v_x11_24359);
    }
  }
  default: return heff_nomatch(v_x1_24358);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam24(V self, V *args) {
  V v_st_24373 = args[0];
  V v_m_24372 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24374 = heff_tr(heff_call(v_m_24372, 1, (V[]){v_st_24373}));
  switch (heff_tag_of(v_x1_24374)) {
  case TAG_MkPair: {
    V v_x11_24375 = heff_field(v_x1_24374, 0);
    V v_st_24376 = heff_field(v_x1_24374, 1);
    V v_ru_24x1_24374_24MkPair = heff_take_reuse_n(v_x1_24374, 3ULL, 2);
    switch (heff_tag_of(v_x11_24375)) {
    case TAG_Left: {
      V v_e_24377 = heff_field(v_x11_24375, 0);
      heff_take_n(v_x11_24375, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24377}), v_st_24376});
    }
    case TAG_Right: {
      V v_x_24378 = heff_field(v_x11_24375, 0);
      V v_ru_24x11_24375_24Right = heff_take_reuse_n(v_x11_24375, 1ULL, 1);
      V v_t_24379 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24378)});
      V v_t_24382;
      switch (heff_tag_of(v_x_24378)) {
      case TAG_At: {
        V v_s_24381 = heff_field(v_x_24378, 1);
        heff_take_n(v_x_24378, 2ULL, 2);
        v_t_24382 = v_s_24381;
        break;
      }
      default: heff_nomatch(v_x_24378);
      }
      V v_t_24383 = heff_tag_at_n(v_ru_24x11_24375_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24379, v_t_24382})});
      return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){v_t_24383, v_st_24376});
    }
    default: return heff_nomatch(v_x11_24375);
    }
  }
  default: return heff_nomatch(v_x1_24374);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam25(V self, V *args) {
  V v_st_24388 = args[0];
  V v_m_24387 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24389 = heff_tr(heff_call(v_m_24387, 1, (V[]){v_st_24388}));
  switch (heff_tag_of(v_x1_24389)) {
  case TAG_MkPair: {
    V v_x11_24390 = heff_field(v_x1_24389, 0);
    V v_st_24391 = heff_field(v_x1_24389, 1);
    V v_ru_24x1_24389_24MkPair = heff_take_reuse_n(v_x1_24389, 3ULL, 2);
    switch (heff_tag_of(v_x11_24390)) {
    case TAG_Left: {
      V v_e_24392 = heff_field(v_x11_24390, 0);
      heff_take_n(v_x11_24390, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24389_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24392}), v_st_24391});
    }
    case TAG_Right: {
      V v_x_24393 = heff_field(v_x11_24390, 0);
      V v_ru_24x11_24390_24Right = heff_take_reuse_n(v_x11_24390, 1ULL, 1);
      V v_t_24394 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24393)});
      V v_t_24397;
      switch (heff_tag_of(v_x_24393)) {
      case TAG_At: {
        V v_s_24396 = heff_field(v_x_24393, 1);
        heff_take_n(v_x_24393, 2ULL, 2);
        v_t_24397 = v_s_24396;
        break;
      }
      default: heff_nomatch(v_x_24393);
      }
      V v_t_24398 = heff_tag_at_n(v_ru_24x11_24390_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24394, v_t_24397})});
      return heff_tag_at_n(v_ru_24x1_24389_24MkPair, TAG_MkPair, 2, (V[]){v_t_24398, v_st_24391});
    }
    default: return heff_nomatch(v_x11_24390);
    }
  }
  default: return heff_nomatch(v_x1_24389);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam26(V self, V *args) {
  V v_st_24406 = args[0];
  V v_m_24405 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24407 = heff_tr(heff_call(v_m_24405, 1, (V[]){v_st_24406}));
  switch (heff_tag_of(v_x1_24407)) {
  case TAG_MkPair: {
    V v_x11_24408 = heff_field(v_x1_24407, 0);
    V v_st_24409 = heff_field(v_x1_24407, 1);
    V v_ru_24x1_24407_24MkPair = heff_take_reuse_n(v_x1_24407, 3ULL, 2);
    switch (heff_tag_of(v_x11_24408)) {
    case TAG_Left: {
      V v_e_24410 = heff_field(v_x11_24408, 0);
      heff_take_n(v_x11_24408, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24410}), v_st_24409});
    }
    case TAG_Right: {
      V v_x_24411 = heff_field(v_x11_24408, 0);
      V v_ru_24x11_24408_24Right = heff_take_reuse_n(v_x11_24408, 1ULL, 1);
      V v_t_24412 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24411)});
      V v_t_24415;
      switch (heff_tag_of(v_x_24411)) {
      case TAG_At: {
        V v_s_24414 = heff_field(v_x_24411, 1);
        heff_take_n(v_x_24411, 2ULL, 2);
        v_t_24415 = v_s_24414;
        break;
      }
      default: heff_nomatch(v_x_24411);
      }
      V v_t_24416 = heff_tag_at_n(v_ru_24x11_24408_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24412, v_t_24415})});
      return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){v_t_24416, v_st_24409});
    }
    default: return heff_nomatch(v_x11_24408);
    }
  }
  default: return heff_nomatch(v_x1_24407);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam27(V self, V *args) {
  V v_st_24420 = args[0];
  V v_m_24419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24421 = heff_tr(heff_call(v_m_24419, 1, (V[]){v_st_24420}));
  switch (heff_tag_of(v_x1_24421)) {
  case TAG_MkPair: {
    V v_x11_24422 = heff_field(v_x1_24421, 0);
    V v_st_24423 = heff_field(v_x1_24421, 1);
    V v_ru_24x1_24421_24MkPair = heff_take_reuse_n(v_x1_24421, 3ULL, 2);
    switch (heff_tag_of(v_x11_24422)) {
    case TAG_Left: {
      V v_e_24424 = heff_field(v_x11_24422, 0);
      heff_take_n(v_x11_24422, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24424}), v_st_24423});
    }
    case TAG_Right: {
      V v_x_24425 = heff_field(v_x11_24422, 0);
      V v_ru_24x11_24422_24Right = heff_take_reuse_n(v_x11_24422, 1ULL, 1);
      V v_t_24426 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24425)});
      V v_t_24429;
      switch (heff_tag_of(v_x_24425)) {
      case TAG_At: {
        V v_s_24428 = heff_field(v_x_24425, 1);
        heff_take_n(v_x_24425, 2ULL, 2);
        v_t_24429 = v_s_24428;
        break;
      }
      default: heff_nomatch(v_x_24425);
      }
      V v_t_24430 = heff_tag_at_n(v_ru_24x11_24422_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24426, v_t_24429})});
      return heff_tag_at_n(v_ru_24x1_24421_24MkPair, TAG_MkPair, 2, (V[]){v_t_24430, v_st_24423});
    }
    default: return heff_nomatch(v_x11_24422);
    }
  }
  default: return heff_nomatch(v_x1_24421);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam28(V self, V *args) {
  V v_st_24435 = args[0];
  V v_m_24434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24436 = heff_tr(heff_call(v_m_24434, 1, (V[]){v_st_24435}));
  switch (heff_tag_of(v_x1_24436)) {
  case TAG_MkPair: {
    V v_x11_24437 = heff_field(v_x1_24436, 0);
    V v_st_24438 = heff_field(v_x1_24436, 1);
    V v_ru_24x1_24436_24MkPair = heff_take_reuse_n(v_x1_24436, 3ULL, 2);
    switch (heff_tag_of(v_x11_24437)) {
    case TAG_Left: {
      V v_e_24439 = heff_field(v_x11_24437, 0);
      heff_take_n(v_x11_24437, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24439}), v_st_24438});
    }
    case TAG_Right: {
      V v_x_24440 = heff_field(v_x11_24437, 0);
      V v_ru_24x11_24437_24Right = heff_take_reuse_n(v_x11_24437, 1ULL, 1);
      V v_t_24441 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24440)});
      V v_t_24444;
      switch (heff_tag_of(v_x_24440)) {
      case TAG_At: {
        V v_s_24443 = heff_field(v_x_24440, 1);
        heff_take_n(v_x_24440, 2ULL, 2);
        v_t_24444 = v_s_24443;
        break;
      }
      default: heff_nomatch(v_x_24440);
      }
      V v_t_24445 = heff_tag_at_n(v_ru_24x11_24437_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24441, v_t_24444})});
      return heff_tag_at_n(v_ru_24x1_24436_24MkPair, TAG_MkPair, 2, (V[]){v_t_24445, v_st_24438});
    }
    default: return heff_nomatch(v_x11_24437);
    }
  }
  default: return heff_nomatch(v_x1_24436);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam29(V self, V *args) {
  V v_st_24453 = args[0];
  V v_m_24452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24454 = heff_tr(heff_call(v_m_24452, 1, (V[]){v_st_24453}));
  switch (heff_tag_of(v_x1_24454)) {
  case TAG_MkPair: {
    V v_x11_24455 = heff_field(v_x1_24454, 0);
    V v_st_24456 = heff_field(v_x1_24454, 1);
    V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
    switch (heff_tag_of(v_x11_24455)) {
    case TAG_Left: {
      V v_e_24457 = heff_field(v_x11_24455, 0);
      heff_take_n(v_x11_24455, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
    }
    case TAG_Right: {
      V v_x_24458 = heff_field(v_x11_24455, 0);
      V v_ru_24x11_24455_24Right = heff_take_reuse_n(v_x11_24455, 1ULL, 1);
      V v_t_24459 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24458)});
      V v_t_24462;
      switch (heff_tag_of(v_x_24458)) {
      case TAG_At: {
        V v_s_24461 = heff_field(v_x_24458, 1);
        heff_take_n(v_x_24458, 2ULL, 2);
        v_t_24462 = v_s_24461;
        break;
      }
      default: heff_nomatch(v_x_24458);
      }
      V v_t_24463 = heff_tag_at_n(v_ru_24x11_24455_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24459, v_t_24462})});
      return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){v_t_24463, v_st_24456});
    }
    default: return heff_nomatch(v_x11_24455);
    }
  }
  default: return heff_nomatch(v_x1_24454);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam30(V self, V *args) {
  V v_st_24471 = args[0];
  V v_m_24470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24472 = heff_tr(heff_call(v_m_24470, 1, (V[]){v_st_24471}));
  switch (heff_tag_of(v_x1_24472)) {
  case TAG_MkPair: {
    V v_x11_24473 = heff_field(v_x1_24472, 0);
    V v_st_24474 = heff_field(v_x1_24472, 1);
    V v_ru_24x1_24472_24MkPair = heff_take_reuse_n(v_x1_24472, 3ULL, 2);
    switch (heff_tag_of(v_x11_24473)) {
    case TAG_Left: {
      V v_e_24475 = heff_field(v_x11_24473, 0);
      heff_take_n(v_x11_24473, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24475}), v_st_24474});
    }
    case TAG_Right: {
      V v_x_24476 = heff_field(v_x11_24473, 0);
      V v_ru_24x11_24473_24Right = heff_take_reuse_n(v_x11_24473, 1ULL, 1);
      V v_t_24477 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24476)});
      V v_t_24480;
      switch (heff_tag_of(v_x_24476)) {
      case TAG_At: {
        V v_s_24479 = heff_field(v_x_24476, 1);
        heff_take_n(v_x_24476, 2ULL, 2);
        v_t_24480 = v_s_24479;
        break;
      }
      default: heff_nomatch(v_x_24476);
      }
      V v_t_24481 = heff_tag_at_n(v_ru_24x11_24473_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24477, v_t_24480})});
      return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){v_t_24481, v_st_24474});
    }
    default: return heff_nomatch(v_x11_24473);
    }
  }
  default: return heff_nomatch(v_x1_24472);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam31(V self, V *args) {
  V v_st_24486 = args[0];
  V v_m_24485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24487 = heff_tr(heff_call(v_m_24485, 1, (V[]){v_st_24486}));
  switch (heff_tag_of(v_x1_24487)) {
  case TAG_MkPair: {
    V v_x11_24488 = heff_field(v_x1_24487, 0);
    V v_st_24489 = heff_field(v_x1_24487, 1);
    V v_ru_24x1_24487_24MkPair = heff_take_reuse_n(v_x1_24487, 3ULL, 2);
    switch (heff_tag_of(v_x11_24488)) {
    case TAG_Left: {
      V v_e_24490 = heff_field(v_x11_24488, 0);
      heff_take_n(v_x11_24488, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24487_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24490}), v_st_24489});
    }
    case TAG_Right: {
      V v_x_24491 = heff_field(v_x11_24488, 0);
      V v_ru_24x11_24488_24Right = heff_take_reuse_n(v_x11_24488, 1ULL, 1);
      V v_t_24492 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24491)});
      V v_t_24495;
      switch (heff_tag_of(v_x_24491)) {
      case TAG_At: {
        V v_s_24494 = heff_field(v_x_24491, 1);
        heff_take_n(v_x_24491, 2ULL, 2);
        v_t_24495 = v_s_24494;
        break;
      }
      default: heff_nomatch(v_x_24491);
      }
      V v_t_24496 = heff_tag_at_n(v_ru_24x11_24488_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24492, v_t_24495})});
      return heff_tag_at_n(v_ru_24x1_24487_24MkPair, TAG_MkPair, 2, (V[]){v_t_24496, v_st_24489});
    }
    default: return heff_nomatch(v_x11_24488);
    }
  }
  default: return heff_nomatch(v_x1_24487);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam32(V self, V *args) {
  V v_st_24502 = args[0];
  V v_m_24501 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24503 = heff_tr(heff_call(v_m_24501, 1, (V[]){v_st_24502}));
  switch (heff_tag_of(v_x1_24503)) {
  case TAG_MkPair: {
    V v_x11_24504 = heff_field(v_x1_24503, 0);
    V v_st_24505 = heff_field(v_x1_24503, 1);
    V v_ru_24x1_24503_24MkPair = heff_take_reuse_n(v_x1_24503, 3ULL, 2);
    switch (heff_tag_of(v_x11_24504)) {
    case TAG_Left: {
      V v_e_24506 = heff_field(v_x11_24504, 0);
      heff_take_n(v_x11_24504, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24503_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24506}), v_st_24505});
    }
    case TAG_Right: {
      V v_x_24507 = heff_field(v_x11_24504, 0);
      V v_ru_24x11_24504_24Right = heff_take_reuse_n(v_x11_24504, 1ULL, 1);
      V v_t_24508 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24507)});
      V v_t_24511;
      switch (heff_tag_of(v_x_24507)) {
      case TAG_At: {
        V v_s_24510 = heff_field(v_x_24507, 1);
        heff_take_n(v_x_24507, 2ULL, 2);
        v_t_24511 = v_s_24510;
        break;
      }
      default: heff_nomatch(v_x_24507);
      }
      V v_t_24512 = heff_tag_at_n(v_ru_24x11_24504_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24508, v_t_24511})});
      return heff_tag_at_n(v_ru_24x1_24503_24MkPair, TAG_MkPair, 2, (V[]){v_t_24512, v_st_24505});
    }
    default: return heff_nomatch(v_x11_24504);
    }
  }
  default: return heff_nomatch(v_x1_24503);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam33(V self, V *args) {
  V v_st_24520 = args[0];
  V v_m_24519 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24521 = heff_tr(heff_call(v_m_24519, 1, (V[]){v_st_24520}));
  switch (heff_tag_of(v_x1_24521)) {
  case TAG_MkPair: {
    V v_x11_24522 = heff_field(v_x1_24521, 0);
    V v_st_24523 = heff_field(v_x1_24521, 1);
    V v_ru_24x1_24521_24MkPair = heff_take_reuse_n(v_x1_24521, 3ULL, 2);
    switch (heff_tag_of(v_x11_24522)) {
    case TAG_Left: {
      V v_e_24524 = heff_field(v_x11_24522, 0);
      heff_take_n(v_x11_24522, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24521_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24524}), v_st_24523});
    }
    case TAG_Right: {
      V v_x_24525 = heff_field(v_x11_24522, 0);
      V v_ru_24x11_24522_24Right = heff_take_reuse_n(v_x11_24522, 1ULL, 1);
      V v_t_24526 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24525)});
      V v_t_24529;
      switch (heff_tag_of(v_x_24525)) {
      case TAG_At: {
        V v_s_24528 = heff_field(v_x_24525, 1);
        heff_take_n(v_x_24525, 2ULL, 2);
        v_t_24529 = v_s_24528;
        break;
      }
      default: heff_nomatch(v_x_24525);
      }
      V v_t_24530 = heff_tag_at_n(v_ru_24x11_24522_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24526, v_t_24529})});
      return heff_tag_at_n(v_ru_24x1_24521_24MkPair, TAG_MkPair, 2, (V[]){v_t_24530, v_st_24523});
    }
    default: return heff_nomatch(v_x11_24522);
    }
  }
  default: return heff_nomatch(v_x1_24521);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam34(V self, V *args) {
  V v_st_24533 = args[0];
  V v_m_24532 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24534 = heff_tr(heff_call(v_m_24532, 1, (V[]){v_st_24533}));
  switch (heff_tag_of(v_x1_24534)) {
  case TAG_MkPair: {
    V v_x11_24535 = heff_field(v_x1_24534, 0);
    V v_st_24536 = heff_field(v_x1_24534, 1);
    V v_ru_24x1_24534_24MkPair = heff_take_reuse_n(v_x1_24534, 3ULL, 2);
    switch (heff_tag_of(v_x11_24535)) {
    case TAG_Left: {
      V v_e_24537 = heff_field(v_x11_24535, 0);
      heff_take_n(v_x11_24535, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24534_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24537}), v_st_24536});
    }
    case TAG_Right: {
      V v_x_24538 = heff_field(v_x11_24535, 0);
      V v_ru_24x11_24535_24Right = heff_take_reuse_n(v_x11_24535, 1ULL, 1);
      V v_t_24539 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24538)});
      V v_t_24542;
      switch (heff_tag_of(v_x_24538)) {
      case TAG_At: {
        V v_s_24541 = heff_field(v_x_24538, 1);
        heff_take_n(v_x_24538, 2ULL, 2);
        v_t_24542 = v_s_24541;
        break;
      }
      default: heff_nomatch(v_x_24538);
      }
      V v_t_24543 = heff_tag_at_n(v_ru_24x11_24535_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24539, v_t_24542})});
      return heff_tag_at_n(v_ru_24x1_24534_24MkPair, TAG_MkPair, 2, (V[]){v_t_24543, v_st_24536});
    }
    default: return heff_nomatch(v_x11_24535);
    }
  }
  default: return heff_nomatch(v_x1_24534);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam35(V self, V *args) {
  V v_st_24547 = args[0];
  V v_m_24546 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24548 = heff_tr(heff_call(v_m_24546, 1, (V[]){v_st_24547}));
  switch (heff_tag_of(v_x1_24548)) {
  case TAG_MkPair: {
    V v_x11_24549 = heff_field(v_x1_24548, 0);
    V v_st_24550 = heff_field(v_x1_24548, 1);
    V v_ru_24x1_24548_24MkPair = heff_take_reuse_n(v_x1_24548, 3ULL, 2);
    switch (heff_tag_of(v_x11_24549)) {
    case TAG_Left: {
      V v_e_24551 = heff_field(v_x11_24549, 0);
      heff_take_n(v_x11_24549, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24548_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24551}), v_st_24550});
    }
    case TAG_Right: {
      V v_x_24552 = heff_field(v_x11_24549, 0);
      V v_ru_24x11_24549_24Right = heff_take_reuse_n(v_x11_24549, 1ULL, 1);
      V v_t_24553 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24552)});
      V v_t_24556;
      switch (heff_tag_of(v_x_24552)) {
      case TAG_At: {
        V v_s_24555 = heff_field(v_x_24552, 1);
        heff_take_n(v_x_24552, 2ULL, 2);
        v_t_24556 = v_s_24555;
        break;
      }
      default: heff_nomatch(v_x_24552);
      }
      V v_t_24557 = heff_tag_at_n(v_ru_24x11_24549_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24553, v_t_24556})});
      return heff_tag_at_n(v_ru_24x1_24548_24MkPair, TAG_MkPair, 2, (V[]){v_t_24557, v_st_24550});
    }
    default: return heff_nomatch(v_x11_24549);
    }
  }
  default: return heff_nomatch(v_x1_24548);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam36(V self, V *args) {
  V v_st_24563 = args[0];
  V v_m_24562 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24564 = heff_tr(heff_call(v_m_24562, 1, (V[]){v_st_24563}));
  switch (heff_tag_of(v_x1_24564)) {
  case TAG_MkPair: {
    V v_x11_24565 = heff_field(v_x1_24564, 0);
    V v_st_24566 = heff_field(v_x1_24564, 1);
    V v_ru_24x1_24564_24MkPair = heff_take_reuse_n(v_x1_24564, 3ULL, 2);
    switch (heff_tag_of(v_x11_24565)) {
    case TAG_Left: {
      V v_e_24567 = heff_field(v_x11_24565, 0);
      heff_take_n(v_x11_24565, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24564_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24567}), v_st_24566});
    }
    case TAG_Right: {
      V v_x_24568 = heff_field(v_x11_24565, 0);
      V v_ru_24x11_24565_24Right = heff_take_reuse_n(v_x11_24565, 1ULL, 1);
      V v_t_24569 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24568)});
      V v_t_24572;
      switch (heff_tag_of(v_x_24568)) {
      case TAG_At: {
        V v_s_24571 = heff_field(v_x_24568, 1);
        heff_take_n(v_x_24568, 2ULL, 2);
        v_t_24572 = v_s_24571;
        break;
      }
      default: heff_nomatch(v_x_24568);
      }
      V v_t_24573 = heff_tag_at_n(v_ru_24x11_24565_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24569, v_t_24572})});
      return heff_tag_at_n(v_ru_24x1_24564_24MkPair, TAG_MkPair, 2, (V[]){v_t_24573, v_st_24566});
    }
    default: return heff_nomatch(v_x11_24565);
    }
  }
  default: return heff_nomatch(v_x1_24564);
  }
}
V g_heff_2esyntax_2esurface_2eupdateSettingL_lam37(V self, V *args) {
  V v_st_24579 = args[0];
  V v_m_24578 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24580 = heff_tr(heff_call(v_m_24578, 1, (V[]){v_st_24579}));
  switch (heff_tag_of(v_x1_24580)) {
  case TAG_MkPair: {
    V v_x11_24581 = heff_field(v_x1_24580, 0);
    V v_st_24582 = heff_field(v_x1_24580, 1);
    V v_ru_24x1_24580_24MkPair = heff_take_reuse_n(v_x1_24580, 3ULL, 2);
    switch (heff_tag_of(v_x11_24581)) {
    case TAG_Left: {
      V v_e_24583 = heff_field(v_x11_24581, 0);
      heff_take_n(v_x11_24581, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24580_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24583}), v_st_24582});
    }
    case TAG_Right: {
      V v_x_24584 = heff_field(v_x11_24581, 0);
      V v_ru_24x11_24581_24Right = heff_take_reuse_n(v_x11_24581, 1ULL, 1);
      V v_t_24585 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24584)});
      V v_t_24588;
      switch (heff_tag_of(v_x_24584)) {
      case TAG_At: {
        V v_s_24587 = heff_field(v_x_24584, 1);
        heff_take_n(v_x_24584, 2ULL, 2);
        v_t_24588 = v_s_24587;
        break;
      }
      default: heff_nomatch(v_x_24584);
      }
      V v_t_24589 = heff_tag_at_n(v_ru_24x11_24581_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24585, v_t_24588})});
      return heff_tag_at_n(v_ru_24x1_24580_24MkPair, TAG_MkPair, 2, (V[]){v_t_24589, v_st_24582});
    }
    default: return heff_nomatch(v_x11_24581);
    }
  }
  default: return heff_nomatch(v_x1_24580);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2ebracedL_lam37(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ebracedL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebracedL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebracedL(V v_r_240, V v_f_241, V v_sp_242) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_Atom: {
    V v_m_244 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam0, 1, 2, (V[]){v_m_244, v_sp_242});
  }
  case TAG_EParen: {
    V v_m_2415 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam1, 1, 2, (V[]){v_m_2415, v_sp_242});
  }
  case TAG_Named: {
    V v_m_2428 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam2, 1, 2, (V[]){v_m_2428, v_sp_242});
  }
  case TAG_Tup: {
    V v_m_2440 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam3, 1, 2, (V[]){v_m_2440, v_sp_242});
  }
  case TAG_Seg: {
    V v_m_2451 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam4, 1, 2, (V[]){v_m_2451, v_sp_242});
  }
  case TAG_Braces: {
    V v_m_2463 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam5, 1, 2, (V[]){v_m_2463, v_sp_242});
  }
  case TAG_Update: {
    V v_m_2477 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam6, 1, 2, (V[]){v_m_2477, v_sp_242});
  }
  case TAG_EUSet: {
    V v_m_2488 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam7, 1, 2, (V[]){v_m_2488, v_sp_242});
  }
  case TAG_InstB: {
    V v_m_24101 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam8, 1, 2, (V[]){v_m_24101, v_sp_242});
  }
  case TAG_EFSet: {
    V v_m_24112 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam9, 1, 2, (V[]){v_m_24112, v_sp_242});
  }
  case TAG_EFDefault: {
    V v_e_24120 = heff_field(v_f_241, 0);
    V v_d_24122 = heff_field(v_f_241, 2);
    heff_take_n(v_f_241, 5ULL, 3);
    V v_m_24123 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_d_24122}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam10, 1, 4, (V[]){v_m_24123, v_r_240, v_e_24120, v_sp_242});
  }
  case TAG_Sum: {
    V v_m_24142 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam11, 1, 2, (V[]){v_m_24142, v_sp_242});
  }
  case TAG_ECon: {
    V v_m_24152 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam12, 1, 2, (V[]){v_m_24152, v_sp_242});
  }
  case TAG_EField: {
    V v_m_24162 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam13, 1, 2, (V[]){v_m_24162, v_sp_242});
  }
  case TAG_ENeg: {
    V v_m_24172 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam14, 1, 2, (V[]){v_m_24172, v_sp_242});
  }
  case TAG_App: {
    V v_m_24182 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam15, 1, 2, (V[]){v_m_24182, v_sp_242});
  }
  case TAG_Op: {
    V v_m_24193 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam16, 1, 2, (V[]){v_m_24193, v_sp_242});
  }
  case TAG_Ops: {
    V v_m_24203 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam17, 1, 2, (V[]){v_m_24203, v_sp_242});
  }
  case TAG_OpRhs: {
    V v_m_24213 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam18, 1, 2, (V[]){v_m_24213, v_sp_242});
  }
  case TAG_Ann: {
    V v_m_24224 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam19, 1, 2, (V[]){v_m_24224, v_sp_242});
  }
  case TAG_BVar: {
    V v_m_24233 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam20, 1, 2, (V[]){v_m_24233, v_sp_242});
  }
  case TAG_BImp: {
    V v_m_24244 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam21, 1, 2, (V[]){v_m_24244, v_sp_242});
  }
  case TAG_BAnn: {
    V v_m_24257 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam22, 1, 2, (V[]){v_m_24257, v_sp_242});
  }
  case TAG_Lam: {
    V v_m_24269 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam23, 1, 2, (V[]){v_m_24269, v_sp_242});
  }
  case TAG_Case: {
    V v_m_24281 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam24, 1, 2, (V[]){v_m_24281, v_sp_242});
  }
  case TAG_EAlt: {
    V v_m_24292 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam25, 1, 2, (V[]){v_m_24292, v_sp_242});
  }
  case TAG_If: {
    V v_m_24306 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam26, 1, 2, (V[]){v_m_24306, v_sp_242});
  }
  case TAG_Do: {
    V v_m_24316 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam27, 1, 2, (V[]){v_m_24316, v_sp_242});
  }
  case TAG_ESBind: {
    V v_m_24327 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam28, 1, 2, (V[]){v_m_24327, v_sp_242});
  }
  case TAG_ELet: {
    V v_m_24341 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam29, 1, 2, (V[]){v_m_24341, v_sp_242});
  }
  case TAG_ELetMut: {
    V v_m_24355 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam30, 1, 2, (V[]){v_m_24355, v_sp_242});
  }
  case TAG_EAssign: {
    V v_m_24366 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam31, 1, 2, (V[]){v_m_24366, v_sp_242});
  }
  case TAG_EWhile: {
    V v_m_24378 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam32, 1, 2, (V[]){v_m_24378, v_sp_242});
  }
  case TAG_EFor: {
    V v_m_24392 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam33, 1, 2, (V[]){v_m_24392, v_sp_242});
  }
  case TAG_EJump: {
    V v_m_24401 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam34, 1, 2, (V[]){v_m_24401, v_sp_242});
  }
  case TAG_EReturn: {
    V v_m_24411 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam35, 1, 2, (V[]){v_m_24411, v_sp_242});
  }
  case TAG_ENest: {
    V v_m_24423 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam36, 1, 2, (V[]){v_m_24423, v_sp_242});
  }
  case TAG_IfThen: {
    V v_m_24435 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_f_241));
    return heff_clo_n(g_heff_2esyntax_2esurface_2ebracedL_lam37, 1, 2, (V[]){v_m_24435, v_sp_242});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebracedL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2ebracedL_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2410, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_st_248});
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam1(V self, V *args) {
  V v_st_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_st_2416}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_MkPair: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_st_2419 = heff_field(v_x1_2417, 1);
    V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_Left: {
      V v_e_2420 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
    }
    case TAG_Right: {
      V v_x_2421 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 1);
      V v_t_2422 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2421, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2422}), v_st_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam2(V self, V *args) {
  V v_st_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_st_2429}));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_MkPair: {
    V v_x11_2431 = heff_field(v_x1_2430, 0);
    V v_st_2432 = heff_field(v_x1_2430, 1);
    V v_ru_24x1_2430_24MkPair = heff_take_reuse_n(v_x1_2430, 3ULL, 2);
    switch (heff_tag_of(v_x11_2431)) {
    case TAG_Left: {
      V v_e_2433 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2433}), v_st_2432});
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 1);
      V v_t_2435 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2434, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2435}), v_st_2432});
    }
    default: return heff_nomatch(v_x11_2431);
    }
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam3(V self, V *args) {
  V v_st_2441 = args[0];
  V v_m_2440 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2442 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_st_2441}));
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_MkPair: {
    V v_x11_2443 = heff_field(v_x1_2442, 0);
    V v_st_2444 = heff_field(v_x1_2442, 1);
    V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
    switch (heff_tag_of(v_x11_2443)) {
    case TAG_Left: {
      V v_e_2445 = heff_field(v_x11_2443, 0);
      heff_take_n(v_x11_2443, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
    }
    case TAG_Right: {
      V v_x_2446 = heff_field(v_x11_2443, 0);
      heff_take_n(v_x11_2443, 1ULL, 1);
      V v_t_2447 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2446, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2447}), v_st_2444});
    }
    default: return heff_nomatch(v_x11_2443);
    }
  }
  default: return heff_nomatch(v_x1_2442);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam4(V self, V *args) {
  V v_st_2452 = args[0];
  V v_m_2451 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2453 = heff_tr(heff_call(v_m_2451, 1, (V[]){v_st_2452}));
  switch (heff_tag_of(v_x1_2453)) {
  case TAG_MkPair: {
    V v_x11_2454 = heff_field(v_x1_2453, 0);
    V v_st_2455 = heff_field(v_x1_2453, 1);
    V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
    switch (heff_tag_of(v_x11_2454)) {
    case TAG_Left: {
      V v_e_2456 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
    }
    case TAG_Right: {
      V v_x_2457 = heff_field(v_x11_2454, 0);
      heff_take_n(v_x11_2454, 1ULL, 1);
      V v_t_2458 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2457, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_st_2455});
    }
    default: return heff_nomatch(v_x11_2454);
    }
  }
  default: return heff_nomatch(v_x1_2453);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam5(V self, V *args) {
  V v_st_2464 = args[0];
  V v_m_2463 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2465 = heff_tr(heff_call(v_m_2463, 1, (V[]){v_st_2464}));
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_MkPair: {
    V v_x11_2466 = heff_field(v_x1_2465, 0);
    V v_st_2467 = heff_field(v_x1_2465, 1);
    V v_ru_24x1_2465_24MkPair = heff_take_reuse_n(v_x1_2465, 3ULL, 2);
    switch (heff_tag_of(v_x11_2466)) {
    case TAG_Left: {
      V v_e_2468 = heff_field(v_x11_2466, 0);
      heff_take_n(v_x11_2466, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2468}), v_st_2467});
    }
    case TAG_Right: {
      V v_x_2469 = heff_field(v_x11_2466, 0);
      heff_take_n(v_x11_2466, 1ULL, 1);
      V v_t_2470 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2469, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2465_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2470}), v_st_2467});
    }
    default: return heff_nomatch(v_x11_2466);
    }
  }
  default: return heff_nomatch(v_x1_2465);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam6(V self, V *args) {
  V v_st_2478 = args[0];
  V v_m_2477 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2479 = heff_tr(heff_call(v_m_2477, 1, (V[]){v_st_2478}));
  switch (heff_tag_of(v_x1_2479)) {
  case TAG_MkPair: {
    V v_x11_2480 = heff_field(v_x1_2479, 0);
    V v_st_2481 = heff_field(v_x1_2479, 1);
    V v_ru_24x1_2479_24MkPair = heff_take_reuse_n(v_x1_2479, 3ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_Left: {
      V v_e_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2482}), v_st_2481});
    }
    case TAG_Right: {
      V v_x_2483 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 1);
      V v_t_2484 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2483, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2479_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2484}), v_st_2481});
    }
    default: return heff_nomatch(v_x11_2480);
    }
  }
  default: return heff_nomatch(v_x1_2479);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam7(V self, V *args) {
  V v_st_2489 = args[0];
  V v_m_2488 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2490 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_st_2489}));
  switch (heff_tag_of(v_x1_2490)) {
  case TAG_MkPair: {
    V v_x11_2491 = heff_field(v_x1_2490, 0);
    V v_st_2492 = heff_field(v_x1_2490, 1);
    V v_ru_24x1_2490_24MkPair = heff_take_reuse_n(v_x1_2490, 3ULL, 2);
    switch (heff_tag_of(v_x11_2491)) {
    case TAG_Left: {
      V v_e_2493 = heff_field(v_x11_2491, 0);
      heff_take_n(v_x11_2491, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2493}), v_st_2492});
    }
    case TAG_Right: {
      V v_x_2494 = heff_field(v_x11_2491, 0);
      heff_take_n(v_x11_2491, 1ULL, 1);
      V v_t_2495 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_2494, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_2490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2495}), v_st_2492});
    }
    default: return heff_nomatch(v_x11_2491);
    }
  }
  default: return heff_nomatch(v_x1_2490);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam8(V self, V *args) {
  V v_st_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24103 = heff_tr(heff_call(v_m_24101, 1, (V[]){v_st_24102}));
  switch (heff_tag_of(v_x1_24103)) {
  case TAG_MkPair: {
    V v_x11_24104 = heff_field(v_x1_24103, 0);
    V v_st_24105 = heff_field(v_x1_24103, 1);
    V v_ru_24x1_24103_24MkPair = heff_take_reuse_n(v_x1_24103, 3ULL, 2);
    switch (heff_tag_of(v_x11_24104)) {
    case TAG_Left: {
      V v_e_24106 = heff_field(v_x11_24104, 0);
      heff_take_n(v_x11_24104, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24106}), v_st_24105});
    }
    case TAG_Right: {
      V v_x_24107 = heff_field(v_x11_24104, 0);
      heff_take_n(v_x11_24104, 1ULL, 1);
      V v_t_24108 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24107, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24103_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24108}), v_st_24105});
    }
    default: return heff_nomatch(v_x11_24104);
    }
  }
  default: return heff_nomatch(v_x1_24103);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam9(V self, V *args) {
  V v_st_24113 = args[0];
  V v_m_24112 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24114 = heff_tr(heff_call(v_m_24112, 1, (V[]){v_st_24113}));
  switch (heff_tag_of(v_x1_24114)) {
  case TAG_MkPair: {
    V v_x11_24115 = heff_field(v_x1_24114, 0);
    V v_st_24116 = heff_field(v_x1_24114, 1);
    V v_ru_24x1_24114_24MkPair = heff_take_reuse_n(v_x1_24114, 3ULL, 2);
    switch (heff_tag_of(v_x11_24115)) {
    case TAG_Left: {
      V v_e_24117 = heff_field(v_x11_24115, 0);
      heff_take_n(v_x11_24115, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24117}), v_st_24116});
    }
    case TAG_Right: {
      V v_x_24118 = heff_field(v_x11_24115, 0);
      heff_take_n(v_x11_24115, 1ULL, 1);
      V v_t_24119 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24118, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24114_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24119}), v_st_24116});
    }
    default: return heff_nomatch(v_x11_24115);
    }
  }
  default: return heff_nomatch(v_x1_24114);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam10(V self, V *args) {
  V v_st_24124 = args[0];
  V v_m_24123 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  V v_e_24120 = heff_env(self)[2];
  V v_sp_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24125 = heff_tr(heff_call(v_m_24123, 1, (V[]){v_st_24124}));
  switch (heff_tag_of(v_x1_24125)) {
  case TAG_MkPair: {
    V v_x11_24126 = heff_field(v_x1_24125, 0);
    V v_st_24127 = heff_field(v_x1_24125, 1);
    V v_ru_24x1_24125_24MkPair = heff_take_reuse_n(v_x1_24125, 3ULL, 2);
    switch (heff_tag_of(v_x11_24126)) {
    case TAG_Left: {
      V v_e_24128 = heff_field(v_x11_24126, 0);
      heff_take_n(v_x11_24126, 1ULL, 1);
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e_24120);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24128}), v_st_24127});
    }
    case TAG_Right: {
      V v_x_24129 = heff_field(v_x11_24126, 0);
      V v_ru_24x11_24126_24Right = heff_take_reuse_n(v_x11_24126, 1ULL, 1);
      V v_m_24130 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_e_24120));
      V v_x1_24131 = heff_tr(heff_call(v_m_24130, 1, (V[]){v_st_24127}));
      switch (heff_tag_of(v_x1_24131)) {
      case TAG_MkPair: {
        V v_x11_24132 = heff_field(v_x1_24131, 0);
        V v_st_24133 = heff_field(v_x1_24131, 1);
        heff_take_n(v_x1_24131, 3ULL, 2);
        switch (heff_tag_of(v_x11_24132)) {
        case TAG_Left: {
          V v_e_24134 = heff_field(v_x11_24132, 0);
          heff_take_n(v_x11_24132, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_x_24129);
          heff_drop_cell(v_ru_24x11_24126_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24134}), v_st_24133});
        }
        case TAG_Right: {
          V v_x_24135 = heff_field(v_x11_24132, 0);
          heff_take_n(v_x11_24132, 1ULL, 1);
          V v_t_24136 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24135, heff_tag_at_n(v_ru_24x11_24126_24Right, TAG_Just, 1, (V[]){v_x_24129}), v_sp_242});
          return heff_tag_at_n(v_ru_24x1_24125_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24136}), v_st_24133});
        }
        default: return heff_nomatch(v_x11_24132);
        }
      }
      default: return heff_nomatch(v_x1_24131);
      }
    }
    default: return heff_nomatch(v_x11_24126);
    }
  }
  default: return heff_nomatch(v_x1_24125);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam11(V self, V *args) {
  V v_st_24143 = args[0];
  V v_m_24142 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24144 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_st_24143}));
  switch (heff_tag_of(v_x1_24144)) {
  case TAG_MkPair: {
    V v_x11_24145 = heff_field(v_x1_24144, 0);
    V v_st_24146 = heff_field(v_x1_24144, 1);
    V v_ru_24x1_24144_24MkPair = heff_take_reuse_n(v_x1_24144, 3ULL, 2);
    switch (heff_tag_of(v_x11_24145)) {
    case TAG_Left: {
      V v_e_24147 = heff_field(v_x11_24145, 0);
      heff_take_n(v_x11_24145, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24147}), v_st_24146});
    }
    case TAG_Right: {
      V v_x_24148 = heff_field(v_x11_24145, 0);
      heff_take_n(v_x11_24145, 1ULL, 1);
      V v_t_24149 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24148, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24149}), v_st_24146});
    }
    default: return heff_nomatch(v_x11_24145);
    }
  }
  default: return heff_nomatch(v_x1_24144);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam12(V self, V *args) {
  V v_st_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24154 = heff_tr(heff_call(v_m_24152, 1, (V[]){v_st_24153}));
  switch (heff_tag_of(v_x1_24154)) {
  case TAG_MkPair: {
    V v_x11_24155 = heff_field(v_x1_24154, 0);
    V v_st_24156 = heff_field(v_x1_24154, 1);
    V v_ru_24x1_24154_24MkPair = heff_take_reuse_n(v_x1_24154, 3ULL, 2);
    switch (heff_tag_of(v_x11_24155)) {
    case TAG_Left: {
      V v_e_24157 = heff_field(v_x11_24155, 0);
      heff_take_n(v_x11_24155, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24157}), v_st_24156});
    }
    case TAG_Right: {
      V v_x_24158 = heff_field(v_x11_24155, 0);
      heff_take_n(v_x11_24155, 1ULL, 1);
      V v_t_24159 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24158, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24154_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24159}), v_st_24156});
    }
    default: return heff_nomatch(v_x11_24155);
    }
  }
  default: return heff_nomatch(v_x1_24154);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam13(V self, V *args) {
  V v_st_24163 = args[0];
  V v_m_24162 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24164 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_st_24163}));
  switch (heff_tag_of(v_x1_24164)) {
  case TAG_MkPair: {
    V v_x11_24165 = heff_field(v_x1_24164, 0);
    V v_st_24166 = heff_field(v_x1_24164, 1);
    V v_ru_24x1_24164_24MkPair = heff_take_reuse_n(v_x1_24164, 3ULL, 2);
    switch (heff_tag_of(v_x11_24165)) {
    case TAG_Left: {
      V v_e_24167 = heff_field(v_x11_24165, 0);
      heff_take_n(v_x11_24165, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24164_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24167}), v_st_24166});
    }
    case TAG_Right: {
      V v_x_24168 = heff_field(v_x11_24165, 0);
      heff_take_n(v_x11_24165, 1ULL, 1);
      V v_t_24169 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24168, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24164_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24169}), v_st_24166});
    }
    default: return heff_nomatch(v_x11_24165);
    }
  }
  default: return heff_nomatch(v_x1_24164);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam14(V self, V *args) {
  V v_st_24173 = args[0];
  V v_m_24172 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24174 = heff_tr(heff_call(v_m_24172, 1, (V[]){v_st_24173}));
  switch (heff_tag_of(v_x1_24174)) {
  case TAG_MkPair: {
    V v_x11_24175 = heff_field(v_x1_24174, 0);
    V v_st_24176 = heff_field(v_x1_24174, 1);
    V v_ru_24x1_24174_24MkPair = heff_take_reuse_n(v_x1_24174, 3ULL, 2);
    switch (heff_tag_of(v_x11_24175)) {
    case TAG_Left: {
      V v_e_24177 = heff_field(v_x11_24175, 0);
      heff_take_n(v_x11_24175, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24174_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24177}), v_st_24176});
    }
    case TAG_Right: {
      V v_x_24178 = heff_field(v_x11_24175, 0);
      heff_take_n(v_x11_24175, 1ULL, 1);
      V v_t_24179 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24178, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24174_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24179}), v_st_24176});
    }
    default: return heff_nomatch(v_x11_24175);
    }
  }
  default: return heff_nomatch(v_x1_24174);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam15(V self, V *args) {
  V v_st_24183 = args[0];
  V v_m_24182 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24184 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_st_24183}));
  switch (heff_tag_of(v_x1_24184)) {
  case TAG_MkPair: {
    V v_x11_24185 = heff_field(v_x1_24184, 0);
    V v_st_24186 = heff_field(v_x1_24184, 1);
    V v_ru_24x1_24184_24MkPair = heff_take_reuse_n(v_x1_24184, 3ULL, 2);
    switch (heff_tag_of(v_x11_24185)) {
    case TAG_Left: {
      V v_e_24187 = heff_field(v_x11_24185, 0);
      heff_take_n(v_x11_24185, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24187}), v_st_24186});
    }
    case TAG_Right: {
      V v_x_24188 = heff_field(v_x11_24185, 0);
      heff_take_n(v_x11_24185, 1ULL, 1);
      V v_t_24189 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24188, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24189}), v_st_24186});
    }
    default: return heff_nomatch(v_x11_24185);
    }
  }
  default: return heff_nomatch(v_x1_24184);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam16(V self, V *args) {
  V v_st_24194 = args[0];
  V v_m_24193 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24195 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_st_24194}));
  switch (heff_tag_of(v_x1_24195)) {
  case TAG_MkPair: {
    V v_x11_24196 = heff_field(v_x1_24195, 0);
    V v_st_24197 = heff_field(v_x1_24195, 1);
    V v_ru_24x1_24195_24MkPair = heff_take_reuse_n(v_x1_24195, 3ULL, 2);
    switch (heff_tag_of(v_x11_24196)) {
    case TAG_Left: {
      V v_e_24198 = heff_field(v_x11_24196, 0);
      heff_take_n(v_x11_24196, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24198}), v_st_24197});
    }
    case TAG_Right: {
      V v_x_24199 = heff_field(v_x11_24196, 0);
      heff_take_n(v_x11_24196, 1ULL, 1);
      V v_t_24200 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24199, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24200}), v_st_24197});
    }
    default: return heff_nomatch(v_x11_24196);
    }
  }
  default: return heff_nomatch(v_x1_24195);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam17(V self, V *args) {
  V v_st_24204 = args[0];
  V v_m_24203 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24205 = heff_tr(heff_call(v_m_24203, 1, (V[]){v_st_24204}));
  switch (heff_tag_of(v_x1_24205)) {
  case TAG_MkPair: {
    V v_x11_24206 = heff_field(v_x1_24205, 0);
    V v_st_24207 = heff_field(v_x1_24205, 1);
    V v_ru_24x1_24205_24MkPair = heff_take_reuse_n(v_x1_24205, 3ULL, 2);
    switch (heff_tag_of(v_x11_24206)) {
    case TAG_Left: {
      V v_e_24208 = heff_field(v_x11_24206, 0);
      heff_take_n(v_x11_24206, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24208}), v_st_24207});
    }
    case TAG_Right: {
      V v_x_24209 = heff_field(v_x11_24206, 0);
      heff_take_n(v_x11_24206, 1ULL, 1);
      V v_t_24210 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24209, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24210}), v_st_24207});
    }
    default: return heff_nomatch(v_x11_24206);
    }
  }
  default: return heff_nomatch(v_x1_24205);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam18(V self, V *args) {
  V v_st_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24215 = heff_tr(heff_call(v_m_24213, 1, (V[]){v_st_24214}));
  switch (heff_tag_of(v_x1_24215)) {
  case TAG_MkPair: {
    V v_x11_24216 = heff_field(v_x1_24215, 0);
    V v_st_24217 = heff_field(v_x1_24215, 1);
    V v_ru_24x1_24215_24MkPair = heff_take_reuse_n(v_x1_24215, 3ULL, 2);
    switch (heff_tag_of(v_x11_24216)) {
    case TAG_Left: {
      V v_e_24218 = heff_field(v_x11_24216, 0);
      heff_take_n(v_x11_24216, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24215_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24218}), v_st_24217});
    }
    case TAG_Right: {
      V v_x_24219 = heff_field(v_x11_24216, 0);
      heff_take_n(v_x11_24216, 1ULL, 1);
      V v_t_24220 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24219, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24215_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24220}), v_st_24217});
    }
    default: return heff_nomatch(v_x11_24216);
    }
  }
  default: return heff_nomatch(v_x1_24215);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam19(V self, V *args) {
  V v_st_24225 = args[0];
  V v_m_24224 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24226 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_st_24225}));
  switch (heff_tag_of(v_x1_24226)) {
  case TAG_MkPair: {
    V v_x11_24227 = heff_field(v_x1_24226, 0);
    V v_st_24228 = heff_field(v_x1_24226, 1);
    V v_ru_24x1_24226_24MkPair = heff_take_reuse_n(v_x1_24226, 3ULL, 2);
    switch (heff_tag_of(v_x11_24227)) {
    case TAG_Left: {
      V v_e_24229 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24229}), v_st_24228});
    }
    case TAG_Right: {
      V v_x_24230 = heff_field(v_x11_24227, 0);
      heff_take_n(v_x11_24227, 1ULL, 1);
      V v_t_24231 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24230, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24231}), v_st_24228});
    }
    default: return heff_nomatch(v_x11_24227);
    }
  }
  default: return heff_nomatch(v_x1_24226);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam20(V self, V *args) {
  V v_st_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24235 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_st_24234}));
  switch (heff_tag_of(v_x1_24235)) {
  case TAG_MkPair: {
    V v_x11_24236 = heff_field(v_x1_24235, 0);
    V v_st_24237 = heff_field(v_x1_24235, 1);
    V v_ru_24x1_24235_24MkPair = heff_take_reuse_n(v_x1_24235, 3ULL, 2);
    switch (heff_tag_of(v_x11_24236)) {
    case TAG_Left: {
      V v_e_24238 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24238}), v_st_24237});
    }
    case TAG_Right: {
      V v_x_24239 = heff_field(v_x11_24236, 0);
      heff_take_n(v_x11_24236, 1ULL, 1);
      V v_t_24240 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24239, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24235_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24240}), v_st_24237});
    }
    default: return heff_nomatch(v_x11_24236);
    }
  }
  default: return heff_nomatch(v_x1_24235);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam21(V self, V *args) {
  V v_st_24245 = args[0];
  V v_m_24244 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24246 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_st_24245}));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_MkPair: {
    V v_x11_24247 = heff_field(v_x1_24246, 0);
    V v_st_24248 = heff_field(v_x1_24246, 1);
    V v_ru_24x1_24246_24MkPair = heff_take_reuse_n(v_x1_24246, 3ULL, 2);
    switch (heff_tag_of(v_x11_24247)) {
    case TAG_Left: {
      V v_e_24249 = heff_field(v_x11_24247, 0);
      heff_take_n(v_x11_24247, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24249}), v_st_24248});
    }
    case TAG_Right: {
      V v_x_24250 = heff_field(v_x11_24247, 0);
      heff_take_n(v_x11_24247, 1ULL, 1);
      V v_t_24251 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24250, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24251}), v_st_24248});
    }
    default: return heff_nomatch(v_x11_24247);
    }
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam22(V self, V *args) {
  V v_st_24258 = args[0];
  V v_m_24257 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24259 = heff_tr(heff_call(v_m_24257, 1, (V[]){v_st_24258}));
  switch (heff_tag_of(v_x1_24259)) {
  case TAG_MkPair: {
    V v_x11_24260 = heff_field(v_x1_24259, 0);
    V v_st_24261 = heff_field(v_x1_24259, 1);
    V v_ru_24x1_24259_24MkPair = heff_take_reuse_n(v_x1_24259, 3ULL, 2);
    switch (heff_tag_of(v_x11_24260)) {
    case TAG_Left: {
      V v_e_24262 = heff_field(v_x11_24260, 0);
      heff_take_n(v_x11_24260, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24259_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24262}), v_st_24261});
    }
    case TAG_Right: {
      V v_x_24263 = heff_field(v_x11_24260, 0);
      heff_take_n(v_x11_24260, 1ULL, 1);
      V v_t_24264 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24263, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24259_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24264}), v_st_24261});
    }
    default: return heff_nomatch(v_x11_24260);
    }
  }
  default: return heff_nomatch(v_x1_24259);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam23(V self, V *args) {
  V v_st_24270 = args[0];
  V v_m_24269 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24271 = heff_tr(heff_call(v_m_24269, 1, (V[]){v_st_24270}));
  switch (heff_tag_of(v_x1_24271)) {
  case TAG_MkPair: {
    V v_x11_24272 = heff_field(v_x1_24271, 0);
    V v_st_24273 = heff_field(v_x1_24271, 1);
    V v_ru_24x1_24271_24MkPair = heff_take_reuse_n(v_x1_24271, 3ULL, 2);
    switch (heff_tag_of(v_x11_24272)) {
    case TAG_Left: {
      V v_e_24274 = heff_field(v_x11_24272, 0);
      heff_take_n(v_x11_24272, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24271_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24274}), v_st_24273});
    }
    case TAG_Right: {
      V v_x_24275 = heff_field(v_x11_24272, 0);
      heff_take_n(v_x11_24272, 1ULL, 1);
      V v_t_24276 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24275, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24271_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24276}), v_st_24273});
    }
    default: return heff_nomatch(v_x11_24272);
    }
  }
  default: return heff_nomatch(v_x1_24271);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam24(V self, V *args) {
  V v_st_24282 = args[0];
  V v_m_24281 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24283 = heff_tr(heff_call(v_m_24281, 1, (V[]){v_st_24282}));
  switch (heff_tag_of(v_x1_24283)) {
  case TAG_MkPair: {
    V v_x11_24284 = heff_field(v_x1_24283, 0);
    V v_st_24285 = heff_field(v_x1_24283, 1);
    V v_ru_24x1_24283_24MkPair = heff_take_reuse_n(v_x1_24283, 3ULL, 2);
    switch (heff_tag_of(v_x11_24284)) {
    case TAG_Left: {
      V v_e_24286 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24286}), v_st_24285});
    }
    case TAG_Right: {
      V v_x_24287 = heff_field(v_x11_24284, 0);
      heff_take_n(v_x11_24284, 1ULL, 1);
      V v_t_24288 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24287, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24288}), v_st_24285});
    }
    default: return heff_nomatch(v_x11_24284);
    }
  }
  default: return heff_nomatch(v_x1_24283);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam25(V self, V *args) {
  V v_st_24293 = args[0];
  V v_m_24292 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24294 = heff_tr(heff_call(v_m_24292, 1, (V[]){v_st_24293}));
  switch (heff_tag_of(v_x1_24294)) {
  case TAG_MkPair: {
    V v_x11_24295 = heff_field(v_x1_24294, 0);
    V v_st_24296 = heff_field(v_x1_24294, 1);
    V v_ru_24x1_24294_24MkPair = heff_take_reuse_n(v_x1_24294, 3ULL, 2);
    switch (heff_tag_of(v_x11_24295)) {
    case TAG_Left: {
      V v_e_24297 = heff_field(v_x11_24295, 0);
      heff_take_n(v_x11_24295, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24294_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24297}), v_st_24296});
    }
    case TAG_Right: {
      V v_x_24298 = heff_field(v_x11_24295, 0);
      heff_take_n(v_x11_24295, 1ULL, 1);
      V v_t_24299 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24298, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24294_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24299}), v_st_24296});
    }
    default: return heff_nomatch(v_x11_24295);
    }
  }
  default: return heff_nomatch(v_x1_24294);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam26(V self, V *args) {
  V v_st_24307 = args[0];
  V v_m_24306 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24308 = heff_tr(heff_call(v_m_24306, 1, (V[]){v_st_24307}));
  switch (heff_tag_of(v_x1_24308)) {
  case TAG_MkPair: {
    V v_x11_24309 = heff_field(v_x1_24308, 0);
    V v_st_24310 = heff_field(v_x1_24308, 1);
    V v_ru_24x1_24308_24MkPair = heff_take_reuse_n(v_x1_24308, 3ULL, 2);
    switch (heff_tag_of(v_x11_24309)) {
    case TAG_Left: {
      V v_e_24311 = heff_field(v_x11_24309, 0);
      heff_take_n(v_x11_24309, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24311}), v_st_24310});
    }
    case TAG_Right: {
      V v_x_24312 = heff_field(v_x11_24309, 0);
      heff_take_n(v_x11_24309, 1ULL, 1);
      V v_t_24313 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24312, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24313}), v_st_24310});
    }
    default: return heff_nomatch(v_x11_24309);
    }
  }
  default: return heff_nomatch(v_x1_24308);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam27(V self, V *args) {
  V v_st_24317 = args[0];
  V v_m_24316 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24318 = heff_tr(heff_call(v_m_24316, 1, (V[]){v_st_24317}));
  switch (heff_tag_of(v_x1_24318)) {
  case TAG_MkPair: {
    V v_x11_24319 = heff_field(v_x1_24318, 0);
    V v_st_24320 = heff_field(v_x1_24318, 1);
    V v_ru_24x1_24318_24MkPair = heff_take_reuse_n(v_x1_24318, 3ULL, 2);
    switch (heff_tag_of(v_x11_24319)) {
    case TAG_Left: {
      V v_e_24321 = heff_field(v_x11_24319, 0);
      heff_take_n(v_x11_24319, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24318_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24321}), v_st_24320});
    }
    case TAG_Right: {
      V v_x_24322 = heff_field(v_x11_24319, 0);
      heff_take_n(v_x11_24319, 1ULL, 1);
      V v_t_24323 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24322, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24318_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24323}), v_st_24320});
    }
    default: return heff_nomatch(v_x11_24319);
    }
  }
  default: return heff_nomatch(v_x1_24318);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam28(V self, V *args) {
  V v_st_24328 = args[0];
  V v_m_24327 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24329 = heff_tr(heff_call(v_m_24327, 1, (V[]){v_st_24328}));
  switch (heff_tag_of(v_x1_24329)) {
  case TAG_MkPair: {
    V v_x11_24330 = heff_field(v_x1_24329, 0);
    V v_st_24331 = heff_field(v_x1_24329, 1);
    V v_ru_24x1_24329_24MkPair = heff_take_reuse_n(v_x1_24329, 3ULL, 2);
    switch (heff_tag_of(v_x11_24330)) {
    case TAG_Left: {
      V v_e_24332 = heff_field(v_x11_24330, 0);
      heff_take_n(v_x11_24330, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24329_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24332}), v_st_24331});
    }
    case TAG_Right: {
      V v_x_24333 = heff_field(v_x11_24330, 0);
      heff_take_n(v_x11_24330, 1ULL, 1);
      V v_t_24334 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24333, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24329_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24334}), v_st_24331});
    }
    default: return heff_nomatch(v_x11_24330);
    }
  }
  default: return heff_nomatch(v_x1_24329);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam29(V self, V *args) {
  V v_st_24342 = args[0];
  V v_m_24341 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24343 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_st_24342}));
  switch (heff_tag_of(v_x1_24343)) {
  case TAG_MkPair: {
    V v_x11_24344 = heff_field(v_x1_24343, 0);
    V v_st_24345 = heff_field(v_x1_24343, 1);
    V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
    switch (heff_tag_of(v_x11_24344)) {
    case TAG_Left: {
      V v_e_24346 = heff_field(v_x11_24344, 0);
      heff_take_n(v_x11_24344, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
    }
    case TAG_Right: {
      V v_x_24347 = heff_field(v_x11_24344, 0);
      heff_take_n(v_x11_24344, 1ULL, 1);
      V v_t_24348 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24347, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24348}), v_st_24345});
    }
    default: return heff_nomatch(v_x11_24344);
    }
  }
  default: return heff_nomatch(v_x1_24343);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam30(V self, V *args) {
  V v_st_24356 = args[0];
  V v_m_24355 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24357 = heff_tr(heff_call(v_m_24355, 1, (V[]){v_st_24356}));
  switch (heff_tag_of(v_x1_24357)) {
  case TAG_MkPair: {
    V v_x11_24358 = heff_field(v_x1_24357, 0);
    V v_st_24359 = heff_field(v_x1_24357, 1);
    V v_ru_24x1_24357_24MkPair = heff_take_reuse_n(v_x1_24357, 3ULL, 2);
    switch (heff_tag_of(v_x11_24358)) {
    case TAG_Left: {
      V v_e_24360 = heff_field(v_x11_24358, 0);
      heff_take_n(v_x11_24358, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24360}), v_st_24359});
    }
    case TAG_Right: {
      V v_x_24361 = heff_field(v_x11_24358, 0);
      heff_take_n(v_x11_24358, 1ULL, 1);
      V v_t_24362 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24361, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24362}), v_st_24359});
    }
    default: return heff_nomatch(v_x11_24358);
    }
  }
  default: return heff_nomatch(v_x1_24357);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam31(V self, V *args) {
  V v_st_24367 = args[0];
  V v_m_24366 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24368 = heff_tr(heff_call(v_m_24366, 1, (V[]){v_st_24367}));
  switch (heff_tag_of(v_x1_24368)) {
  case TAG_MkPair: {
    V v_x11_24369 = heff_field(v_x1_24368, 0);
    V v_st_24370 = heff_field(v_x1_24368, 1);
    V v_ru_24x1_24368_24MkPair = heff_take_reuse_n(v_x1_24368, 3ULL, 2);
    switch (heff_tag_of(v_x11_24369)) {
    case TAG_Left: {
      V v_e_24371 = heff_field(v_x11_24369, 0);
      heff_take_n(v_x11_24369, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24368_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24371}), v_st_24370});
    }
    case TAG_Right: {
      V v_x_24372 = heff_field(v_x11_24369, 0);
      heff_take_n(v_x11_24369, 1ULL, 1);
      V v_t_24373 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24372, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24368_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24373}), v_st_24370});
    }
    default: return heff_nomatch(v_x11_24369);
    }
  }
  default: return heff_nomatch(v_x1_24368);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam32(V self, V *args) {
  V v_st_24379 = args[0];
  V v_m_24378 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24380 = heff_tr(heff_call(v_m_24378, 1, (V[]){v_st_24379}));
  switch (heff_tag_of(v_x1_24380)) {
  case TAG_MkPair: {
    V v_x11_24381 = heff_field(v_x1_24380, 0);
    V v_st_24382 = heff_field(v_x1_24380, 1);
    V v_ru_24x1_24380_24MkPair = heff_take_reuse_n(v_x1_24380, 3ULL, 2);
    switch (heff_tag_of(v_x11_24381)) {
    case TAG_Left: {
      V v_e_24383 = heff_field(v_x11_24381, 0);
      heff_take_n(v_x11_24381, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24380_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24383}), v_st_24382});
    }
    case TAG_Right: {
      V v_x_24384 = heff_field(v_x11_24381, 0);
      heff_take_n(v_x11_24381, 1ULL, 1);
      V v_t_24385 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24384, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24380_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24385}), v_st_24382});
    }
    default: return heff_nomatch(v_x11_24381);
    }
  }
  default: return heff_nomatch(v_x1_24380);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam33(V self, V *args) {
  V v_st_24393 = args[0];
  V v_m_24392 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24394 = heff_tr(heff_call(v_m_24392, 1, (V[]){v_st_24393}));
  switch (heff_tag_of(v_x1_24394)) {
  case TAG_MkPair: {
    V v_x11_24395 = heff_field(v_x1_24394, 0);
    V v_st_24396 = heff_field(v_x1_24394, 1);
    V v_ru_24x1_24394_24MkPair = heff_take_reuse_n(v_x1_24394, 3ULL, 2);
    switch (heff_tag_of(v_x11_24395)) {
    case TAG_Left: {
      V v_e_24397 = heff_field(v_x11_24395, 0);
      heff_take_n(v_x11_24395, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24397}), v_st_24396});
    }
    case TAG_Right: {
      V v_x_24398 = heff_field(v_x11_24395, 0);
      heff_take_n(v_x11_24395, 1ULL, 1);
      V v_t_24399 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24398, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24399}), v_st_24396});
    }
    default: return heff_nomatch(v_x11_24395);
    }
  }
  default: return heff_nomatch(v_x1_24394);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam34(V self, V *args) {
  V v_st_24402 = args[0];
  V v_m_24401 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24403 = heff_tr(heff_call(v_m_24401, 1, (V[]){v_st_24402}));
  switch (heff_tag_of(v_x1_24403)) {
  case TAG_MkPair: {
    V v_x11_24404 = heff_field(v_x1_24403, 0);
    V v_st_24405 = heff_field(v_x1_24403, 1);
    V v_ru_24x1_24403_24MkPair = heff_take_reuse_n(v_x1_24403, 3ULL, 2);
    switch (heff_tag_of(v_x11_24404)) {
    case TAG_Left: {
      V v_e_24406 = heff_field(v_x11_24404, 0);
      heff_take_n(v_x11_24404, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24403_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24406}), v_st_24405});
    }
    case TAG_Right: {
      V v_x_24407 = heff_field(v_x11_24404, 0);
      heff_take_n(v_x11_24404, 1ULL, 1);
      V v_t_24408 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24407, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24403_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24408}), v_st_24405});
    }
    default: return heff_nomatch(v_x11_24404);
    }
  }
  default: return heff_nomatch(v_x1_24403);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam35(V self, V *args) {
  V v_st_24412 = args[0];
  V v_m_24411 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24413 = heff_tr(heff_call(v_m_24411, 1, (V[]){v_st_24412}));
  switch (heff_tag_of(v_x1_24413)) {
  case TAG_MkPair: {
    V v_x11_24414 = heff_field(v_x1_24413, 0);
    V v_st_24415 = heff_field(v_x1_24413, 1);
    V v_ru_24x1_24413_24MkPair = heff_take_reuse_n(v_x1_24413, 3ULL, 2);
    switch (heff_tag_of(v_x11_24414)) {
    case TAG_Left: {
      V v_e_24416 = heff_field(v_x11_24414, 0);
      heff_take_n(v_x11_24414, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24416}), v_st_24415});
    }
    case TAG_Right: {
      V v_x_24417 = heff_field(v_x11_24414, 0);
      heff_take_n(v_x11_24414, 1ULL, 1);
      V v_t_24418 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24417, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24418}), v_st_24415});
    }
    default: return heff_nomatch(v_x11_24414);
    }
  }
  default: return heff_nomatch(v_x1_24413);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam36(V self, V *args) {
  V v_st_24424 = args[0];
  V v_m_24423 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24425 = heff_tr(heff_call(v_m_24423, 1, (V[]){v_st_24424}));
  switch (heff_tag_of(v_x1_24425)) {
  case TAG_MkPair: {
    V v_x11_24426 = heff_field(v_x1_24425, 0);
    V v_st_24427 = heff_field(v_x1_24425, 1);
    V v_ru_24x1_24425_24MkPair = heff_take_reuse_n(v_x1_24425, 3ULL, 2);
    switch (heff_tag_of(v_x11_24426)) {
    case TAG_Left: {
      V v_e_24428 = heff_field(v_x11_24426, 0);
      heff_take_n(v_x11_24426, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24428}), v_st_24427});
    }
    case TAG_Right: {
      V v_x_24429 = heff_field(v_x11_24426, 0);
      heff_take_n(v_x11_24426, 1ULL, 1);
      V v_t_24430 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24429, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24430}), v_st_24427});
    }
    default: return heff_nomatch(v_x11_24426);
    }
  }
  default: return heff_nomatch(v_x1_24425);
  }
}
V g_heff_2esyntax_2esurface_2ebracedL_lam37(V self, V *args) {
  V v_st_24436 = args[0];
  V v_m_24435 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24437 = heff_tr(heff_call(v_m_24435, 1, (V[]){v_st_24436}));
  switch (heff_tag_of(v_x1_24437)) {
  case TAG_MkPair: {
    V v_x11_24438 = heff_field(v_x1_24437, 0);
    V v_st_24439 = heff_field(v_x1_24437, 1);
    V v_ru_24x1_24437_24MkPair = heff_take_reuse_n(v_x1_24437, 3ULL, 2);
    switch (heff_tag_of(v_x11_24438)) {
    case TAG_Left: {
      V v_e_24440 = heff_field(v_x11_24438, 0);
      heff_take_n(v_x11_24438, 1ULL, 1);
      heff_drop(v_sp_242);
      return heff_tag_at_n(v_ru_24x1_24437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24440}), v_st_24439});
    }
    case TAG_Right: {
      V v_x_24441 = heff_field(v_x11_24438, 0);
      heff_take_n(v_x11_24438, 1ULL, 1);
      V v_t_24442 = heff_tag_n(TAG_Braced, 3, (V[]){v_x_24441, NTAG(TAG_Nothing), v_sp_242});
      return heff_tag_at_n(v_ru_24x1_24437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24442}), v_st_24439});
    }
    default: return heff_nomatch(v_x11_24438);
    }
  }
  default: return heff_nomatch(v_x1_24437);
  }
}
Clo g_heff_2esyntax_2esurface_2evariantOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2evariantOf(V v_e_240) {
top: ;
  V v_t_241 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_e_240)));
  V v_t_242 = heff_get_n(v_t_241, 0, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_At: {
    V v_it1_243 = heff_field(v_t_242, 0);
    V v_tsp_244 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24At = heff_take_reuse_n(v_t_242, 3ULL, 2);
    switch (heff_tag_of(v_it1_243)) {
    case TAG_EVar: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_248;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_247 = heff_dup(heff_field(v_e_240, 1));
        v_t_248 = v_s_247;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_248});
    }
    case TAG_EImplicitVar: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2412;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_e_240, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2412});
    }
    case TAG_ETag: {
      V v_t_2413 = heff_field(v_it1_243, 0);
      heff_take_n(v_it1_243, 1ULL, 1);
      V v_t_2414 = (g_heff_2esyntax_2epresyntax_2espineOf(heff_dup(v_e_240)));
      V v_t_2415 = heff_tag_n(TAG_TagVariant, 3, (V[]){v_t_2413, v_tsp_244, heff_get_n(v_t_2414, 1, 2)});
      V v_t_2418;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_e_240, 1);
        heff_take_n(v_e_240, 2ULL, 2);
        v_t_2418 = v_s_2417;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){v_t_2415, v_t_2418});
    }
    case TAG_EInt: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2422;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2421 = heff_dup(heff_field(v_e_240, 1));
        v_t_2422 = v_s_2421;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2422});
    }
    case TAG_EFloat: {
      heff_take_na(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2426;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2425 = heff_dup(heff_field(v_e_240, 1));
        v_t_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2426});
    }
    case TAG_EString: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2430;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2429 = heff_dup(heff_field(v_e_240, 1));
        v_t_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2430});
    }
    case TAG_EBinary: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2434;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2433 = heff_dup(heff_field(v_e_240, 1));
        v_t_2434 = v_s_2433;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2434});
    }
    case TAG_ERune: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2438;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2437 = heff_dup(heff_field(v_e_240, 1));
        v_t_2438 = v_s_2437;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2438});
    }
    case TAG_EWord: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2442;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2441 = heff_dup(heff_field(v_e_240, 1));
        v_t_2442 = v_s_2441;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2442});
    }
    case TAG_EApp: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2447;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2446 = heff_dup(heff_field(v_e_240, 1));
        v_t_2447 = v_s_2446;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2447});
    }
    case TAG_EProject: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2451;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2450 = heff_dup(heff_field(v_e_240, 1));
        v_t_2451 = v_s_2450;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2451});
    }
    case TAG_ENamed: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2456;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2455 = heff_dup(heff_field(v_e_240, 1));
        v_t_2456 = v_s_2455;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2456});
    }
    case TAG_EPi: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2461;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2460 = heff_dup(heff_field(v_e_240, 1));
        v_t_2461 = v_s_2460;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2461});
    }
    case TAG_ELam: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2466;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2465 = heff_dup(heff_field(v_e_240, 1));
        v_t_2466 = v_s_2465;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2466});
    }
    case TAG_EAnn: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2471;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2470 = heff_dup(heff_field(v_e_240, 1));
        v_t_2471 = v_s_2470;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2471});
    }
    case TAG_ESpec: {
      heff_take_n(v_it1_243, 0ULL, 4);
      heff_drop(v_tsp_244);
      V v_t_2478;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2477 = heff_dup(heff_field(v_e_240, 1));
        v_t_2478 = v_s_2477;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2478});
    }
    case TAG_ESig: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2482;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2481 = heff_dup(heff_field(v_e_240, 1));
        v_t_2482 = v_s_2481;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2482});
    }
    case TAG_ESum: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2486;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2485 = heff_dup(heff_field(v_e_240, 1));
        v_t_2486 = v_s_2485;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2486});
    }
    case TAG_EStruct: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_2490;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2489 = heff_dup(heff_field(v_e_240, 1));
        v_t_2490 = v_s_2489;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2490});
    }
    case TAG_EUpdate: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_2495;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2494 = heff_dup(heff_field(v_e_240, 1));
        v_t_2495 = v_s_2494;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_2495});
    }
    case TAG_EMatch: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24100;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_2499 = heff_dup(heff_field(v_e_240, 1));
        v_t_24100 = v_s_2499;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24100});
    }
    case TAG_ELetIn: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24105;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24104 = heff_dup(heff_field(v_e_240, 1));
        v_t_24105 = v_s_24104;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24105});
    }
    case TAG_EDo: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24109;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24108 = heff_dup(heff_field(v_e_240, 1));
        v_t_24109 = v_s_24108;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24109});
    }
    case TAG_ELocal: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24114;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24113 = heff_dup(heff_field(v_e_240, 1));
        v_t_24114 = v_s_24113;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24114});
    }
    case TAG_EInvalid: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24118;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24117 = heff_dup(heff_field(v_e_240, 1));
        v_t_24118 = v_s_24117;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24118});
    }
    case TAG_EAssign: {
      heff_take_n(v_it1_243, 0ULL, 3);
      heff_drop(v_tsp_244);
      V v_t_24124;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24123 = heff_dup(heff_field(v_e_240, 1));
        v_t_24124 = v_s_24123;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24124});
    }
    case TAG_EWhile: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24129;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24128 = heff_dup(heff_field(v_e_240, 1));
        v_t_24129 = v_s_24128;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24129});
    }
    case TAG_EFor: {
      heff_take_n(v_it1_243, 0ULL, 3);
      heff_drop(v_tsp_244);
      V v_t_24135;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24134 = heff_dup(heff_field(v_e_240, 1));
        v_t_24135 = v_s_24134;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24135});
    }
    case TAG_EIfThen: {
      heff_take_n(v_it1_243, 0ULL, 2);
      heff_drop(v_tsp_244);
      V v_t_24140;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24139 = heff_dup(heff_field(v_e_240, 1));
        v_t_24140 = v_s_24139;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24140});
    }
    case TAG_EBreak: {
      heff_drop(v_tsp_244);
      V v_t_24143;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24142 = heff_dup(heff_field(v_e_240, 1));
        v_t_24143 = v_s_24142;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24143});
    }
    case TAG_EContinue: {
      heff_drop(v_tsp_244);
      V v_t_24146;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24145 = heff_dup(heff_field(v_e_240, 1));
        v_t_24146 = v_s_24145;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24146});
    }
    case TAG_EReturn: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24150;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24149 = heff_dup(heff_field(v_e_240, 1));
        v_t_24150 = v_s_24149;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24150});
    }
    case TAG_ENest: {
      heff_take_n(v_it1_243, 0ULL, 1);
      heff_drop(v_tsp_244);
      V v_t_24154;
      switch (heff_tag_of(v_e_240)) {
      case TAG_At: {
        V v_s_24153 = heff_dup(heff_field(v_e_240, 1));
        v_t_24154 = v_s_24153;
        break;
      }
      default: heff_nomatch(v_e_240);
      }
      return heff_tag_at_n(v_ru_24t_242_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_e_240}), v_t_24154});
    }
    default: return heff_nomatch(v_it1_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantOf(a[0]);
}

HeffT2 g_heff_2esyntax_2esurface_2eparenL_24cpr(V v_r_240, V v_o_241, V v_e_242, V v_c_243, V v_z_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2esyntax_2esurface_2esymAtom_24cpr(heff_dup(v_e_242)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop_rec(v_r_240, 3);
      heff_drop(v_e_242);
      heff_drop(v_c_243);
      V v_t_249 = v_field_247;
      V v_t_2410 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_t_249, 1)});
      V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_249, 3), heff_get_n(v_t_249, 4, 9)});
      V v_f_2412 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_t_2411})});
      return ((HeffT2){{v_f_2412, v_z_244}});
    } else {
      heff_drop(v_field_247);
      V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_242}));
      V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_z_244}));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_MkPair: {
        V v_x11_2415 = heff_field(v_x1_2414, 0);
        V v_st_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 3ULL, 2);
        switch (heff_tag_of(v_x11_2415)) {
        case TAG_Left: {
          V v_e_2417 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          heff_drop(v_c_243);
          return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416}});
        }
        case TAG_Right: {
          V v_x_2418 = heff_field(v_x11_2415, 0);
          V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
          V v_t_2419 = (g_heff_2esyntax_2esurface_2earrowAfter(heff_dup(v_st_2416), v_c_243));
          if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
            heff_drop_cell(v_ru_24x11_2415_24Right, 1);
            heff_drop(v_t_2419);
            V v_t_2420 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_2418));
            return (g_heff_2esyntax_2esurface_2easBinderOn_24cpr(v_t_2420, v_st_2416));
          } else {
            heff_drop(v_t_2419);
            return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){v_x_2418}), v_st_2416}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x11_2415)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2414)}});
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2elw_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam0, 2, 0};
V g_heff_2esyntax_2esurface_2elw_lam1(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam1, 2, 0};
V g_heff_2esyntax_2esurface_2elw_lam2(V self, V *args); static Clo g_heff_2esyntax_2esurface_2elw_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elw_lam2, 2, 0};

static V g_heff_2esyntax_2esurface_2elw_val;
static HEFF_ONCE g_heff_2esyntax_2esurface_2elw_st;
static V g_heff_2esyntax_2esurface_2elw_init(void) {
  return heff_rec_n(3, shape_e__pat__decl, (V[]){((V)&g_heff_2esyntax_2esurface_2elw_lam0_clo), ((V)&g_heff_2esyntax_2esurface_2elw_lam1_clo), ((V)&g_heff_2esyntax_2esurface_2elw_lam2_clo)});
}
V g_heff_2esyntax_2esurface_2elw_get(void) {
  if (HEFF_DONE(g_heff_2esyntax_2esurface_2elw_st)) return g_heff_2esyntax_2esurface_2elw_val;
  return heff_global(&g_heff_2esyntax_2esurface_2elw_val, &g_heff_2esyntax_2esurface_2elw_st, g_heff_2esyntax_2esurface_2elw_init);
}
V g_heff_2esyntax_2esurface_2elw_lam0(V self, V *args) {
  V v_e_240 = args[0];
  V v_st_241 = args[1];
  return (g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_e_240, v_st_241));
}
V g_heff_2esyntax_2esurface_2elw_lam1(V self, V *args) {
  V v_p_242 = args[0];
  V v_st_243 = args[1];
  return (g_heff_2esyntax_2esurface_2epatL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_p_242, v_st_243));
}
V g_heff_2esyntax_2esurface_2elw_lam2(V self, V *args) {
  V v_d_244 = args[0];
  V v_st_245 = args[1];
  return (g_heff_2esyntax_2esurface_2edeclL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_d_244, v_st_245));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etakeSyms_24dps_str0, 3, "sym");
Clo g_heff_2esyntax_2esurface_2etakeSyms_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etakeSyms_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_u_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_u_242, 0)), ((V)&g_heff_2esyntax_2esurface_2etakeSyms_24dps_str0))) {
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_u_242, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    } else {
      heff_drop_rec(v_u_242, 7);
      heff_drop(v_rest_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2etakeSyms_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etakeSyms_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str0, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2egroupOfDecl_str2, 1, ":");
Clo g_heff_2esyntax_2esurface_2egroupOfDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2egroupOfDecl_entry, 2, 0};

V g_heff_2esyntax_2esurface_2egroupOfDecl(V v_place_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 1));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    heff_drop(v_place_240);
    heff_drop_rec(v_d_241, 8);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_op_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 2);
    V v_t_245 = (g_list_2emap_24s1006818869x590968200(heff_take_field(v_d_241, 1)));
    V v_t_249;
    if (heff_strEq_c_lent(v_place_240, ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str0), 2)) {
      heff_drop(v_place_240);
      v_t_249 = ((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str1);
    } else {
      V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_d_241, 7)), MK_INT(1LL));
      V v_t_248 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2egroupOfDecl_str2), heff_intShow(v_t_247));
      v_t_249 = heff_strAppend(v_place_240, v_t_248);
    }
    V v_t_2410 = heff_rec_n(5, shape_id__assoc__ops__loosest__at, (V[]){heff_get_n(v_op_243, 1, 7), heff_take_field(v_d_241, 0), v_t_245, heff_get_n(v_d_241, 4, 8), v_t_249});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2410});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2esyntax_2esurface_2egroupOfDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2egroupOfDecl(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr(V v_kw_240, V v_name_241, V v_params_242, V v_body_243, V v_z_244) {
top: ;
  V v_m_245 = (g_prelude_2etraverse_24s518454301x170091462(v_params_242));
  V v_x1_246 = heff_tr(heff_call(v_m_245, 1, (V[]){v_z_244}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    heff_take_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      heff_drop_rec(v_kw_240, 9);
      heff_drop_rec(v_name_241, 9);
      heff_drop(v_body_243);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248}});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      heff_take_n(v_x11_247, 1ULL, 1);
      V v_t_2411 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2410)));
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2411, heff_clo_n(g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr_lam0, 1, 4, (V[]){v_body_243, v_name_241, v_kw_240, v_x_2410}), v_st_248));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_246)}});
  }
}
V g_heff_2esyntax_2esurface_2etypeL_24s230432856x1611115970_24cpr_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_body_243 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  V v_kw_240 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2413 = heff_tr(g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), heff_dup(v_body_243), v_st_2412));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop(v_body_243);
      heff_drop_rec(v_name_241, 9);
      heff_drop_rec(v_kw_240, 9);
      heff_drop(v_x_2410);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      V v_t_2418 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_name_241, 3), heff_take_field(v_name_241, 4)});
      V v_t_2419 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
      V v_t_2420 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_body_243)));
      V v_e_2421 = heff_get_n(v_t_2420, 4, 9);
      V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_240, 3)), v_e_2421});
      V v_t_2423 = heff_tag_n(TAG_DeclDefine, 5, (V[]){heff_get_n(v_name_241, 1, 9), v_t_2418, v_x_2410, heff_tag_n(TAG_At, 2, (V[]){v_t_2419, v_t_2422}), v_x_2417});
      V v_t_2424 = (g_heff_2esyntax_2ecst_2elastE(v_body_243));
      V v_e_2425 = heff_get_n(v_t_2424, 4, 9);
      V v_t_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_240, 3, 9), v_e_2425});
      V v_t_2427 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2426})});
      V v_x_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2428}), v_st_2415});
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
V g_heff_2esyntax_2esurface_2einitialSt_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2einitialSt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2einitialSt_entry, 5, 0};

V g_heff_2esyntax_2esurface_2einitialSt(V v_o_240, V v_at_241, V v_toks_242, V v_declared_243, V v_own_244) {
top: ;
  V v_declared_245 = (g_heff_2esyntax_2esurface_2enameSet(v_declared_243));
  V v_a_246 = heff_dup(heff_rfield(v_o_240, 1));
  V v_t_247 = (g_heff_2esyntax_2efixity_2eappendF(heff_take_field(v_a_246, 0), heff_take_field(v_own_244, 0)));
  V v_t_248 = (g_heff_2esyntax_2efixity_2enubByG(v_t_247));
  V v_t_249 = (g_heff_2esyntax_2efixity_2eappendF(heff_get_n(v_a_246, 1, 2), heff_get_n(v_own_244, 1, 2)));
  V v_t_2410 = (g_heff_2esyntax_2efixity_2enubByE(v_t_249));
  V v_fix_2411 = heff_rec_n(2, shape_groups__above, (V[]){v_t_248, v_t_2410});
  return heff_rec_n(8, shape_toks__scope__known__binders__patVars__fix__lenient__at, (V[]){v_toks_242, NTAG(TAG_Nil), heff_clo_n(g_heff_2esyntax_2esurface_2einitialSt_lam0, 1, 2, (V[]){heff_dup(v_o_240), v_declared_245}), heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), v_fix_2411, heff_get_n(v_o_240, 2, 5), v_at_241});
}
V g_heff_2esyntax_2esurface_2einitialSt_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2einitialSt(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2esyntax_2esurface_2einitialSt_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_o_240 = heff_env(self)[0];
  V v_declared_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_tr(heff_call(heff_get_n(v_o_240, 0, 5), 1, (V[]){heff_dup(v_x_2412)}));
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    heff_drop(v_declared_245);
    heff_drop(v_t_2413);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_2413);
    HeffT2 v_t_2414 = ({ V a_0 = v_declared_245; V a_1 = v_x_2412; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_declared_245); heff_drop(v_x_2412); r_; });
    {
      V v_field_2416 = v_t_2414.f[1];
      int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2415 == ((int64_t)0ULL)) && ({ V v_x_2418 = heff_dup(v_field_2416); int c_ = 1; heff_drop(v_x_2418); c_; })));
      heff_drop(v_field_2416);
      return v_ret_24bool;
    }
  }
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry, 2, 0};

V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V v_place_240, V v_decls_241) {
top: ;
  V v_t_242 = (g_list_2efilter_24s1330420811x172858565(MK_INT(1LL), MK_INT(0LL), MK_INT(0LL), heff_dup(v_decls_241)));
  V v_t_244 = (g_list_2emap(heff_clo_n(g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0, 1, 1, (V[]){v_place_240}), v_t_242));
  V v_groups_245 = (g_heff_2esyntax_2esurface_2ecatMaybesS(v_t_244));
  V v_t_246 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), heff_dup(v_groups_245)));
  V v_t_247 = (g_heff_2esyntax_2efixity_2enubByG(v_t_246));
  V v_t_248 = (g_heff_2esyntax_2efixity_2eappendF(NTAG(TAG_Nil), NTAG(TAG_Nil)));
  V v_t_249 = (g_heff_2esyntax_2efixity_2enubByE(v_t_248));
  V v_t_2410 = heff_rec_n(2, shape_groups__above, (V[]){v_t_247, v_t_249});
  V v_t_2411 = (g_heff_2esyntax_2esurface_2econcatMapS_24s988929746x1013329159(v_t_2410, v_decls_241));
  return ({ V a_0 = v_decls_241; V a_1 = v_groups_245; V a_2 = v_t_2411; V r_ = (g_heff_2esyntax_2esurface_2efixityOut_24s1239866465x1449849383(a_0, a_1, a_2)); heff_drop(v_decls_241); r_; });
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_lam0(V self, V *args) {
  V v_d_243 = args[0];
  V v_place_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2egroupOfDecl(v_place_240, v_d_243));
}