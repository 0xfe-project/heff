// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_HLocal 25864
#define TAG_I32 19220
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkArm 55352
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define TAG_VFixed 12623
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define LBL_aliases 1464806715
#define LBL_body 9524841
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_supply 1056026650
#define LBL_syntax 1059664654
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_vars 10107635
#define LBL_vs 10532
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_vs__out[] = {LBL_vs, LBL_out};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2eargTysOf(V, V);
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eargTysOf_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V, V, V);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo;
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo;
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_clo;
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V, V);
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo;
V g_heff_2ecompile_2eerase_2eeraseOne(V, V, V);
V g_heff_2ecompile_2eerase_2eeraseOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseOne_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2eerase_2eextend(V, V, V);
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eextend_clo;
V g_heff_2ecompile_2eerase_2efieldTyOr(V, V, V, V);
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2ekeptOf(V, V, V);
V g_heff_2ecompile_2eerase_2ekeptOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ekeptOf_clo;
V g_heff_2ecompile_2eerase_2ematchVariants(V);
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ematchVariants_clo;
V g_heff_2ecompile_2eerase_2enthLocal(V, V);
V g_heff_2ecompile_2eerase_2enthLocal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2enthLocal_clo;
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2eprojWith(V, V, V);
V g_heff_2ecompile_2eerase_2eprojWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojWith_clo;
V g_heff_2ecompile_2eerase_2eshapeWith(V, V, V);
V g_heff_2ecompile_2eerase_2eshapeWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eshapeWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2etraverseM(V, V);
V g_heff_2ecompile_2eerase_2etraverseM_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2etraverseM_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2evalue_2eapp(V, V);
V g_heff_2eelab_2evalue_2eapp_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eapp_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(V);
V g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eproj(V, V);
V g_heff_2eelab_2evalue_2eproj_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eproj_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eextend_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_ir_241, heff_dup(v_ty_242)}), heff_take_field(v_c_240, 0)});
  V v_t_244 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
  V v_v_246 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_244, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam0, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_240, 1), heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam1, 1, 1, (V[]){v_v_246})});
  V v_t_249 = heff_intAdd(heff_take_field(v_c_240, 2), MK_INT(1LL));
  return ({ V rv_0 = v_t_243; V rv_1 = v_t_248; V rv_2 = v_t_249; V rr_ = heff_rec_reuse_n(v_c_240, 8ULL, 4, shape_locals__env__len__globals); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eextend(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_ty_242;
}
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_246;
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eisType_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_apply(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_245;
}
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str0, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str1, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str2, 14, "the type of `.");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str3, 36, "` depends on fields not in hand here");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str4, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str5, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str6, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str7, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str8, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str9, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str10, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str11, 54, "projecting from something that is not of a record type");
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2ecompile_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eprojTyWith(heff_dup(v_t_241), v_fs_242, heff_dup(v_l_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_LikeU: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam0_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_245, 0ULL, 4);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2414 = heff_field(v_t_245, 1);
      V v_fieldTypes_2415 = heff_field(v_t_245, 2);
      heff_take_n(v_t_245, 6ULL, 3);
      V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_l_243), heff_rfield(v_fieldTypes_2415, 1)));
      V v_t_2418;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Just: {
        V v_i_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        v_t_2418 = v_i_2417;
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_t_2419 = (g_heff_2eelab_2erules_2efieldTyAt(v_len_240, v_capture_2414, v_fieldTypes_2415, v_t_2418, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam2, 1, 1, (V[]){v_l_243});
      }
      case TAG_Just: {
        V v_ty_2422 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop(v_l_243);
        return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2422});
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam4_clo);
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo);
    }
    case TAG_LikeRune: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_ty_2435 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    heff_drop(v_l_243);
    return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam12, 1, 1, (V[]){v_ty_2435});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eprojTyInWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2420);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str2), heff_strAppend(v_l_243, ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str3)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2423 = args[0];
  V v_ty_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2422, v_n_2423})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  heff_drop(v_n_2425);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2426 = args[0];
  heff_drop(v_n_2426);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  heff_drop(v_n_2427);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2428 = args[0];
  heff_drop(v_n_2428);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2429 = args[0];
  heff_drop(v_n_2429);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2431 = args[0];
  heff_drop(v_n_2431);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2433 = args[0];
  heff_drop(v_n_2433);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str10)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args) {
  V v_n_2434 = args[0];
  heff_drop(v_n_2434);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str11)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args) {
  V v_n_2436 = args[0];
  V v_ty_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2435, v_n_2436})});
}
Clo g_heff_2ecompile_2eerase_2eprojWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojWith_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eprojWith(V v_x1_240, V v_v_241, V v_l_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2evalue_2eproj(v_v_241, v_l_242));
  }
  case TAG_Just: {
    V v_fs_243 = heff_field(v_x1_240, 0);
    heff_drop(v_v_241);
    V v_t_244 = (g_map_2elookup_24s1546226666x2146984184(v_l_242, heff_rfield(v_fs_243, 1)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      return heff_abandon();
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_xs_246 = heff_dup(heff_rfield(v_fs_243, 2));
      if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_245))) {
        if (heff_intLt_c(heff_dup(v_i_245), heff_arrayLength(heff_dup(v_xs_246)))) {
          V v_v_249 = heff_arrayIndex(v_xs_246, v_i_245);
          return v_v_249;
        } else {
          heff_drop(v_i_245);
          heff_drop(v_xs_246);
          return heff_abandon();
        }
      } else {
        heff_drop(v_i_245);
        heff_drop(v_xs_246);
        return heff_abandon();
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2eprojWith_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eerase_2eprojWith(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2efieldTyOr_entry, 4, 0};

V g_heff_2ecompile_2eerase_2efieldTyOr(V v_len_240, V v_t_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_x3_244 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_LikeU: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_x3_244, 0ULL, 4);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeRecord: {
      V v_capture_2411 = heff_field(v_x3_244, 1);
      V v_fieldTypes_2412 = heff_field(v_x3_244, 2);
      heff_take_n(v_x3_244, 6ULL, 3);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(v_k_242, heff_rfield(v_fieldTypes_2412, 1)));
      V v_t_2415;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        v_t_2415 = heff_abandon();
        break;
      }
      case TAG_Just: {
        V v_i_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        v_t_2415 = v_i_2414;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      return (g_heff_2eelab_2erules_2efieldTyAt(v_len_240, v_capture_2411, v_fieldTypes_2412, v_t_2415, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
    }
    case TAG_LikeSum: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeRune: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeArray: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_Just: {
    V v_ty_2419 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_ty_2419});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2efieldTyOr(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eerase_2ekeptOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ekeptOf_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ekeptOf(V v_len_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_len_240);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_k_245 = heff_field(v_x31_243, 0);
      V v_x312_246 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      switch (heff_tag_of(v_x312_246)) {
      case TAG_Nothing: {
        heff_drop(v_len_240);
        heff_drop(v_acc_241);
        heff_drop(v_rest_244);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        heff_drop(v_k_245);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_ty_247 = heff_field(v_x312_246, 0);
        heff_take_n(v_x312_246, 1ULL, 1);
        V v_t_248 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(v_len_240), v_ty_247));
        V v_t_249;
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop_cell(v_ru_24x3_242_24Cons, 2);
          heff_drop(v_k_245);
          v_t_249 = v_acc_241;
          break;
        }
        case TAG_False: {
          v_t_249 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_k_245, v_acc_241});
          break;
        }
        default: heff_nomatch(v_t_248);
        }
        V t_0 = v_len_240;
        V t_1 = v_t_249;
        V t_2 = v_rest_244;
        v_len_240 = t_0;
        v_acc_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x312_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eerase_2ekeptOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ekeptOf(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eshapeWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eshapeWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eshapeWith_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eshapeWith(V v_len_240, V v_t_241, V v_fs_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_t_241)));
  V v_t_2415;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_LikeU: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeFunction: {
    heff_take_n(v_x1_243, 0ULL, 4);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeRecord: {
    V v_fieldTypes_2411 = heff_field(v_x1_243, 2);
    heff_take_n(v_x1_243, 4ULL, 3);
    v_t_2415 = heff_arrayToList(heff_get_n(v_fieldTypes_2411, 0, 3));
    break;
  }
  case TAG_LikeSum: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeInt: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeFloat: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeString: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeRune: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeArray: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_LikeFixed: {
    heff_take_n(v_x1_243, 0ULL, 1);
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_NoRules: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_t_2418 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eerase_2eshapeWith_lam0, 1, 3, (V[]){v_t_241, v_fs_242, heff_dup(v_len_240)}), v_t_2415));
  HEFF_LAST return g_heff_2ecompile_2eerase_2ekeptOf(v_len_240, NTAG(TAG_Nil), v_t_2418);
}
V g_heff_2ecompile_2eerase_2eshapeWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eshapeWith(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eshapeWith_lam0(V self, V *args) {
  V v_k_2416 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_fs_242 = heff_env(self)[1];
  V v_len_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = (g_heff_2eelab_2evalue_2eprojTyWith(heff_dup(v_t_241), v_fs_242, heff_dup(v_k_2416)));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_k_2416), (g_heff_2ecompile_2eerase_2efieldTyOr(v_len_240, v_t_241, v_k_2416, v_t_2417))});
}
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str0, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str1, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str2, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str3, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str4, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str5, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str6, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str7, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str8, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2ematchVariants_str9, 47, "matching on something that is not of a sum type");
V g_heff_2ecompile_2eerase_2ematchVariants_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2ematchVariants_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2ematchVariants_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2ematchVariants_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_lam10, 1, 0};
Clo g_heff_2ecompile_2eerase_2ematchVariants_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ematchVariants_entry, 1, 0};

V g_heff_2ecompile_2eerase_2ematchVariants(V v_sty_240) {
top: ;
  V v_t_241 = (g_heff_2eelab_2evalue_2ebehavior(v_sty_240));
  switch (heff_tag_of(v_t_241)) {
  case TAG_LikeU: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam0_clo);
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_241, 0ULL, 4);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam1_clo);
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_241, 0ULL, 3);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam2_clo);
  }
  case TAG_LikeSum: {
    V v_vs_2413 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    return heff_clo_n(g_heff_2ecompile_2eerase_2ematchVariants_lam3, 1, 1, (V[]){v_vs_2413});
  }
  case TAG_LikeInt: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam4_clo);
  }
  case TAG_LikeFloat: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam5_clo);
  }
  case TAG_LikeString: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam6_clo);
  }
  case TAG_LikeRune: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam7_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam8_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_241, 0ULL, 1);
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam9_clo);
  }
  case TAG_NoRules: {
    return ((V)&g_heff_2ecompile_2eerase_2ematchVariants_lam10_clo);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ematchVariants(a[0]);
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str0)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam1(V self, V *args) {
  V v_n_248 = args[0];
  heff_drop(v_n_248);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str1)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam2(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str2)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam3(V self, V *args) {
  V v_n_2414 = args[0];
  V v_vs_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_vs_2413, v_n_2414})});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam4(V self, V *args) {
  V v_n_2415 = args[0];
  heff_drop(v_n_2415);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str3)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam5(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str4)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam6(V self, V *args) {
  V v_n_2417 = args[0];
  heff_drop(v_n_2417);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str5)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam7(V self, V *args) {
  V v_n_2418 = args[0];
  heff_drop(v_n_2418);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str6)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam8(V self, V *args) {
  V v_n_2420 = args[0];
  heff_drop(v_n_2420);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str7)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam9(V self, V *args) {
  V v_n_2422 = args[0];
  heff_drop(v_n_2422);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str8)});
}
V g_heff_2ecompile_2eerase_2ematchVariants_lam10(V self, V *args) {
  V v_n_2423 = args[0];
  heff_drop(v_n_2423);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2ematchVariants_str9)});
}
Clo g_heff_2ecompile_2eerase_2eargTysOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eargTysOf_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eargTysOf(V v_vs_240, V v_tag_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(v_tag_241, heff_rfield(v_vs_240, 1)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_vs_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_i_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_xs_244 = heff_get_n(v_vs_240, 2, 3);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_243))) {
      if (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_244)))) {
        V v_ts_247 = heff_arrayIndex(v_xs_244, v_i_243);
        return (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_247)));
      } else {
        heff_drop(v_i_243);
        heff_drop(v_xs_244);
        return NTAG(TAG_Nil);
      }
    } else {
      heff_drop(v_i_243);
      heff_drop(v_xs_244);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eargTysOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2ecompile_2eerase_2ezipE(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str1, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str3, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str4, 1, "$");
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2ecompile_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_x_243 = ({ V rv_1 = v_t_242; V rr_ = heff_rec_reuse_n(v_acc_240, 1ULL, 2, shape_c__vars); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x21_245, 0);
      V v_aty_248 = heff_field(v_x21_245, 1);
      heff_take_n(v_x21_245, 3ULL, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 2, 4);
      V v_t_2410 = (g_heff_2ecompile_2eerase_2eisType(v_t_249, heff_dup(v_aty_248)));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_True: {
        heff_drop(v_x_247);
        V v_t_2411 = (g_heff_2ecompile_2eerase_2eextend(heff_take_field(v_acc_240, 0), NTAG(TAG_Nothing), v_aty_248));
        V v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_n(v_acc_240, 2ULL, 2, shape_c__vars); heff_rfield(rr_, 0) = rv_0; rr_; });
        V t_0 = v_t_2412;
        V t_1 = v_rest_246;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam1, 1, 4, (V[]){v_x_247, v_acc_240, v_aty_248, v_rest_246});
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_n_244})});
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_aty_248 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_base_2416;
  if (heff_strEq_c(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str0))) {
    heff_drop(v_x_247);
    v_base_2416 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str1);
  } else {
    if (heff_strEq_c(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str2))) {
      heff_drop(v_x_247);
      v_base_2416 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str3);
    } else {
      v_base_2416 = v_x_247;
    }
  }
  V v_t_2417 = heff_strAppend(v_base_2416, heff_strAppend(((V)&g_heff_2ecompile_2eerase_2earmBindGo_str4), heff_intShow(heff_dup(v_n_2413))));
  V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2417, heff_intAdd(v_n_2413, MK_INT(1LL))});
  V v_x2_2419 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2418});
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Left: {
    V v_e_2420 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Left = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    heff_drop_rec(v_acc_240, 2);
    heff_drop(v_aty_248);
    heff_drop(v_rest_246);
    return heff_tag_at_n(v_ru_24x2_2419_24Left, TAG_Left, 1, (V[]){v_e_2420});
  }
  case TAG_Right: {
    V v_x21_2421 = heff_field(v_x2_2419, 0);
    V v_ru_24x2_2419_24Right = heff_take_reuse_n(v_x2_2419, 1ULL, 1);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x21_2421, 0);
      V v_n_2423 = heff_field(v_x21_2421, 1);
      V v_ru_24x21_2421_24MkPair = heff_take_reuse_n(v_x21_2421, 3ULL, 2);
      V v_t_2424 = heff_tag_at_n(v_ru_24x2_2419_24Right, TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2422)})});
      V v_t_2425 = (g_heff_2ecompile_2eerase_2eextend(heff_take_field(v_acc_240, 0), v_t_2424, v_aty_248));
      V v_t_2426 = heff_tag_at_n(v_ru_24x21_2421_24MkPair, TAG_Cons, 2, (V[]){v_x_2422, heff_get_n(v_acc_240, 1, 2)});
      V v_t_2427 = (g_heff_2ecompile_2eerase_2earmBindGo(heff_rec_n(2, shape_c__vars, (V[]){v_t_2425, v_t_2426}), v_rest_246));
      V f_ = v_t_2427;
      args[0] = v_n_2423;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
Clo g_heff_2ecompile_2eerase_2enthLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2enthLocal_entry, 2, 0};

V g_heff_2ecompile_2eerase_2enthLocal(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_l_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_rest_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2enthLocal_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2eerase_2enthLocal(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2ecompile_2eerase_2etraverseM_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2etraverseM_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2etraverseM_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2etraverseM_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2etraverseM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2etraverseM_entry, 2, 0};

V g_heff_2ecompile_2eerase_2etraverseM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eerase_2etraverseM_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_246 = heff_tr(heff_apply(heff_dup(v_f_240), 1, (V[]){v_x_244}));
    return heff_clo_n(g_heff_2ecompile_2eerase_2etraverseM_lam1, 1, 3, (V[]){v_m_246, v_f_240, v_xs_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eerase_2etraverseM_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2etraverseM(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2etraverseM_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_243});
}
V g_heff_2ecompile_2eerase_2etraverseM_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_xs_245);
    return heff_tag_at_n(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_m_2413 = (g_heff_2ecompile_2eerase_2etraverseM(v_f_240, v_xs_245));
      V v_x2_2414 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_n_2412}));
      switch (heff_tag_of(v_x2_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        heff_drop(v_x_2411);
        heff_drop_cell(v_ru_24x21_2410_24MkPair, 2);
        return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x21_2416 = heff_field(v_x2_2414, 0);
        heff_take_n(v_x2_2414, 1ULL, 1);
        switch (heff_tag_of(v_x21_2416)) {
        case TAG_MkPair: {
          V v_x_2417 = heff_field(v_x21_2416, 0);
          V v_n_2418 = heff_field(v_x21_2416, 1);
          heff_take_n(v_x21_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2411, v_x_2417}), v_n_2418});
          return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){v_t_2419});
        }
        default: return heff_nomatch(v_x21_2416);
        }
      }
      default: return heff_nomatch(v_x2_2414);
      }
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_entry, 1, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2ecompile_2eerase_2ecatMaybesE(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ecatMaybesE(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0, 27, "this needs an expected type");
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry, 3, 0};

V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V v_c_240, V v_vs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    return ((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        V v_t_2410 = heff_rec_n(2, shape_c__vars, (V[]){heff_dup(v_c_240), NTAG(TAG_Nil)});
        V v_t_2411 = (g_heff_2ecompile_2eerase_2eargTysOf(heff_dup(v_vs_241), v_tag_246));
        V v_t_2412 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_xs_248), v_t_2411));
        V v_m_2413 = (g_heff_2ecompile_2eerase_2earmBindGo(v_t_2410, v_t_2412));
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1, 1, 5, (V[]){v_m_2413, v_body_249, v_c_240, v_vs_241, v_tail_245});
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0)});
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam2(V self, V *args) {
  V v_n_2421 = args[0];
  V v_m_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2422 = heff_tr(heff_apply(v_m_2420, 1, (V[]){heff_dup(v_n_2421)}));
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_Left: {
    V v_ru_24x2_2422_24Left = heff_take_reuse_n(v_x2_2422, 0ULL, 1);
    V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2421});
    return heff_tag_at_n(v_ru_24x2_2422_24Left, TAG_Right, 1, (V[]){v_t_2424});
  }
  case TAG_Right: {
    V v_x21_2425 = heff_field(v_x2_2422, 0);
    V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
    heff_drop(v_n_2421);
    switch (heff_tag_of(v_x21_2425)) {
    case TAG_MkPair: {
      V v_x_2426 = heff_field(v_x21_2425, 0);
      V v_n_27_2427 = heff_field(v_x21_2425, 1);
      V v_ru_24x21_2425_24MkPair = heff_take_reuse_n(v_x21_2425, 3ULL, 2);
      V v_t_2428 = heff_tag_at_n(v_ru_24x21_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2422_24Right, TAG_Just, 1, (V[]){v_x_2426}), v_n_27_2427});
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2428});
    }
    default: return heff_nomatch(v_x21_2425);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_body_249 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_tail_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2415 = heff_tr(heff_apply(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Left = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    heff_drop(v_body_249);
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_tail_245);
    return heff_tag_at_n(v_ru_24x2_2415_24Left, TAG_Left, 1, (V[]){v_e_2416});
  }
  case TAG_Right: {
    V v_x21_2417 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Right = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x21_2417, 0);
      V v_n_2419 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      V v_m_2420 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_get_n(v_x_2418, 0, 2), v_body_249));
      V v_m_2429 = heff_clo_n(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam2, 1, 1, (V[]){v_m_2420});
      V v_x2_2430 = heff_tr(heff_apply(v_m_2429, 1, (V[]){v_n_2419}));
      switch (heff_tag_of(v_x2_2430)) {
      case TAG_Left: {
        V v_e_2431 = heff_field(v_x2_2430, 0);
        heff_take_n(v_x2_2430, 1ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_vs_241);
        heff_drop(v_tail_245);
        return heff_tag_at_n(v_ru_24x2_2415_24Right, TAG_Left, 1, (V[]){v_e_2431});
      }
      case TAG_Right: {
        V v_x21_2432 = heff_field(v_x2_2430, 0);
        heff_take_n(v_x2_2430, 1ULL, 1);
        switch (heff_tag_of(v_x21_2432)) {
        case TAG_MkPair: {
          V v_x_2433 = heff_field(v_x21_2432, 0);
          V v_n_2434 = heff_field(v_x21_2432, 1);
          heff_take_n(v_x21_2432, 3ULL, 2);
          switch (heff_tag_of(v_x_2433)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_2415_24Right, 1);
            V v_t_2435 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(v_c_240, v_vs_241, v_tail_245));
            V f_ = v_t_2435;
            args[0] = v_n_2434;
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          }
          case TAG_Just: {
            V v_it1_2436 = heff_field(v_x_2433, 0);
            heff_take_n(v_x_2433, 1ULL, 1);
            heff_drop(v_c_240);
            heff_drop(v_vs_241);
            heff_drop(v_tail_245);
            switch (heff_tag_of(v_it1_2436)) {
            case TAG_MkPair: {
              V v_ty_2438 = heff_field(v_it1_2436, 1);
              heff_take_n(v_it1_2436, 2ULL, 2);
              return heff_tag_at_n(v_ru_24x2_2415_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2438, v_n_2434})});
            }
            default: return heff_nomatch(v_it1_2436);
            }
          }
          default: return heff_nomatch(v_x_2433);
          }
        }
        default: return heff_nomatch(v_x21_2432);
        }
      }
      default: return heff_nomatch(v_x2_2430);
      }
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry, 4, 0};

V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V v_c_240, V v_vs_241, V v_ty_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_MkPair: {
    V v_tag_244 = heff_field(v_x5_243, 0);
    V v_x52_245 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    switch (heff_tag_of(v_x52_245)) {
    case TAG_MkPair: {
      V v_xs_246 = heff_field(v_x52_245, 0);
      V v_body_247 = heff_field(v_x52_245, 1);
      heff_take_n(v_x52_245, 3ULL, 2);
      V v_t_248 = heff_rec_n(2, shape_c__vars, (V[]){v_c_240, NTAG(TAG_Nil)});
      V v_t_249 = (g_heff_2ecompile_2eerase_2eargTysOf(v_vs_241, heff_dup(v_tag_244)));
      V v_t_2410 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_xs_246), v_t_249));
      V v_m_2411 = (g_heff_2ecompile_2eerase_2earmBindGo(v_t_248, v_t_2410));
      return heff_clo_n(g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0, 1, 4, (V[]){v_m_2411, v_body_247, v_ty_242, v_tag_244});
    }
    default: return heff_nomatch(v_x52_245);
    }
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_lam0(V self, V *args) {
  V v_n_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_body_247 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  V v_tag_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2413 = heff_tr(heff_apply(v_m_2411, 1, (V[]){v_n_2412}));
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Left: {
    V v_e_2414 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Left = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    heff_drop(v_body_247);
    heff_drop(v_ty_242);
    heff_drop(v_tag_244);
    return heff_tag_at_n(v_ru_24x2_2413_24Left, TAG_Left, 1, (V[]){v_e_2414});
  }
  case TAG_Right: {
    V v_x21_2415 = heff_field(v_x2_2413, 0);
    V v_ru_24x2_2413_24Right = heff_take_reuse_n(v_x2_2413, 1ULL, 1);
    switch (heff_tag_of(v_x21_2415)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x21_2415, 0);
      V v_n_2417 = heff_field(v_x21_2415, 1);
      heff_take_n(v_x21_2415, 3ULL, 2);
      V v_m_2418 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_take_field(v_x_2416, 0), v_body_247, v_ty_242));
      V v_x2_2419 = heff_tr(heff_apply(v_m_2418, 1, (V[]){v_n_2417}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Left: {
        V v_e_2420 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        heff_drop(v_tag_244);
        heff_drop_rec(v_x_2416, 2);
        return heff_tag_at_n(v_ru_24x2_2413_24Right, TAG_Left, 1, (V[]){v_e_2420});
      }
      case TAG_Right: {
        V v_x21_2421 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        switch (heff_tag_of(v_x21_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x21_2421, 0);
          V v_n_2423 = heff_field(v_x21_2421, 1);
          heff_take_n(v_x21_2421, 3ULL, 2);
          V v_t_2424 = heff_tag_n(TAG_MkArm, 3, (V[]){v_tag_244, heff_get_n(v_x_2416, 1, 2), v_x_2422});
          return heff_tag_at_n(v_ru_24x2_2413_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_n_2423})});
        }
        default: return heff_nomatch(v_x21_2421);
        }
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    default: return heff_nomatch(v_x21_2415);
    }
  }
  default: return heff_nomatch(v_x2_2413);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str0, 16, "an unbound local");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str1, 22, "a type used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str2, 10, "no global ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str3, 10, "no global ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str4, 9, "the type ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str5, 16, " used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str6, 9, "the type ");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str7, 16, " used as a value");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str8, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str9, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str10, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str11, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str12, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str13, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str14, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str15, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str16, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str17, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str18, 41, "applying something that is not a function");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str19, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str20, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str21, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str22, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str23, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str24, 27, "this needs an expected type");
HEFF_LIT(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str25, 27, "this needs an expected type");
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29(V self, V *args);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30(V self, V *args);
Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry, 2, 0};

V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V v_c_240, V v_t_241) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    V v_i_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_243 = ({ V b_0 = heff_get_n(v_c_240, 0, 4); V a_1 = v_i_242; V r_ = (g_heff_2ecompile_2eerase_2enthLocal(b_0, a_1)); heff_drop(b_0); r_; });
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0_clo);
    }
    case TAG_Just: {
      V v_l_245 = heff_field(v_t_243, 0);
      heff_take_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_dup(heff_rfield(v_l_245, 0));
      switch (heff_tag_of(v_t_246)) {
      case TAG_Nothing: {
        heff_drop_rec(v_l_245, 2);
        return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1_clo);
      }
      case TAG_Just: {
        V v_x_248 = heff_field(v_t_246, 0);
        heff_take_n(v_t_246, 1ULL, 1);
        return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2, 1, 2, (V[]){v_x_248, v_l_245});
      }
      default: return heff_nomatch(v_t_246);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_SGlobal: {
    V v_x_2411 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_g_2412 = heff_get_n(v_c_240, 3, 4);
    V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2411), heff_rfield(v_g_2412, 1)));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      V v_t_2414 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2411), heff_rfield(v_g_2412, 2)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        heff_drop_rec(v_g_2412, 6);
        return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3, 1, 1, (V[]){v_x_2411});
      }
      case TAG_Just: {
        V v_k2_2416 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        V v_t_2417 = ({ V a_0 = v_k2_2416; V b_1 = heff_get_n(v_g_2412, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_t_2417)) {
        case TAG_Nothing: {
          return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4, 1, 1, (V[]){v_x_2411});
        }
        case TAG_Just: {
          V v_e_2419 = heff_field(v_t_2417, 0);
          heff_take_n(v_t_2417, 1ULL, 1);
          V v_t_2420 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2419, 3))));
          switch (heff_tag_of(v_t_2420)) {
          case TAG_True: {
            heff_drop_rec(v_e_2419, 4);
            return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5, 1, 1, (V[]){v_x_2411});
          }
          case TAG_False: {
            return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6, 1, 2, (V[]){v_x_2411, v_e_2419});
          }
          default: return heff_nomatch(v_t_2420);
          }
        }
        default: return heff_nomatch(v_t_2417);
        }
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    case TAG_Just: {
      V v_e_2425 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      heff_drop_rec(v_g_2412, 6);
      V v_t_2426 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2425, 3))));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_True: {
        heff_drop_rec(v_e_2425, 4);
        return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7, 1, 1, (V[]){v_x_2411});
      }
      case TAG_False: {
        return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8, 1, 2, (V[]){v_x_2411, v_e_2425});
      }
      default: return heff_nomatch(v_t_2426);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9_clo);
  }
  case TAG_SApp: {
    V v_f_2433 = heff_field(v_t_241, 0);
    V v_a_2434 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_2435 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_f_2433));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10, 1, 3, (V[]){v_m_2435, v_c_240, v_a_2434});
  }
  case TAG_SLam: {
    V v_ty_2494 = heff_field(v_t_241, 0);
    V v_abs_2495 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SLam = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_x1_2496 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_ty_2494), heff_dup(heff_rfield(v_c_240, 1))));
    V v_ty_24100;
    switch (heff_tag_of(v_x1_2496)) {
    case TAG_Nom: {
      V v_x_2497 = heff_field(v_x1_2496, 0);
      heff_take_n(v_x1_2496, 1ULL, 1);
      v_ty_24100 = v_x_2497;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2496, 0ULL, 1);
      v_ty_24100 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2499 = heff_field(v_x1_2496, 0);
      heff_take_n(v_x1_2496, 1ULL, 1);
      v_ty_24100 = v_x_2499;
      break;
    }
    default: heff_nomatch(v_x1_2496);
    }
    V v_m_24101 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_tag_at_n(v_ru_24t_241_24SLam, TAG_SLam, 2, (V[]){heff_dup(v_ty_2494), v_abs_2495}), v_ty_24100));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13, 1, 3, (V[]){v_m_24101, v_c_240, v_ty_2494});
  }
  case TAG_SCons: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14_clo);
  }
  case TAG_SProj: {
    V v_e_24116 = heff_field(v_t_241, 0);
    V v_l_24117 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24118 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), heff_dup(v_e_24116)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15, 1, 4, (V[]){v_m_24118, v_c_240, v_e_24116, v_l_24117});
  }
  case TAG_STag: {
    heff_take_n(v_t_241, 0ULL, 2);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16_clo);
  }
  case TAG_SMatch: {
    V v_scrut_24150 = heff_field(v_t_241, 0);
    V v_cases_24151 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24152 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_scrut_24150));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17, 1, 3, (V[]){v_m_24152, v_cases_24151, v_c_240});
  }
  case TAG_SSpecialize: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19_clo);
  }
  case TAG_SIs: {
    V v_t2_24191 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24191;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20_clo);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21_clo);
  }
  case TAG_SRec: {
    V v_t2_24194 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t2_24194;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SFix: {
    V v_ty_24195 = heff_field(v_t_241, 0);
    V v_abs_24196 = heff_field(v_t_241, 1);
    V v_ru_24t_241_24SFix = heff_take_reuse_n(v_t_241, 3ULL, 2);
    V v_x1_24197 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_ty_24195), heff_dup(heff_rfield(v_c_240, 1))));
    V v_ty_24201;
    switch (heff_tag_of(v_x1_24197)) {
    case TAG_Nom: {
      V v_x_24198 = heff_field(v_x1_24197, 0);
      heff_take_n(v_x1_24197, 1ULL, 1);
      v_ty_24201 = v_x_24198;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24197, 0ULL, 1);
      v_ty_24201 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24200 = heff_field(v_x1_24197, 0);
      heff_take_n(v_x1_24197, 1ULL, 1);
      v_ty_24201 = v_x_24200;
      break;
    }
    default: heff_nomatch(v_x1_24197);
    }
    V v_m_24202 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_tag_at_n(v_ru_24t_241_24SFix, TAG_SFix, 2, (V[]){heff_dup(v_ty_24195), v_abs_24196}), v_ty_24201));
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22, 1, 3, (V[]){v_m_24202, v_c_240, v_ty_24195});
  }
  case TAG_SImplicit: {
    V v_t2_24216 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t2_24216;
    v_c_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_SPrim: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23_clo);
  }
  case TAG_SMetaApp: {
    heff_take_n(v_t_241, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    return ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24_clo);
  }
  case TAG_SLitInt: {
    V v_i_24223 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25, 1, 1, (V[]){v_i_24223});
  }
  case TAG_SLitFloat: {
    V v_x_24226 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26, 1, 1, (V[]){v_x_24226});
  }
  case TAG_SLitString: {
    V v_s_24229 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27, 1, 1, (V[]){v_s_24229});
  }
  case TAG_SLitRune: {
    V v_n_24232 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28, 1, 1, (V[]){v_n_24232});
  }
  case TAG_SLitFixed: {
    V v_w_24236 = heff_field(v_t_241, 0);
    V v_n_24237 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29, 1, 2, (V[]){v_w_24236, v_n_24237});
  }
  case TAG_SLitFloat32: {
    V v_x_24240 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    return heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30, 1, 1, (V[]){v_x_24240});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam0(V self, V *args) {
  V v_n_244 = args[0];
  heff_drop(v_n_244);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str0)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam1(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str1)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_l_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_248, heff_get_n(v_l_245, 1, 2)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_n_249})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2415);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str2), v_x_2411)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam4(V self, V *args) {
  V v_n_2418 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2418);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str3), v_x_2411)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam5(V self, V *args) {
  V v_n_2421 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2421);
  V v_t_2422 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str4), heff_strAppend(v_x_2411, ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str5)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2422});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam6(V self, V *args) {
  V v_n_2423 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_e_2419 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2411}), heff_get_n(v_e_2419, 3, 4)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_n_2423})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam7(V self, V *args) {
  V v_n_2427 = args[0];
  V v_x_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2427);
  V v_t_2428 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str6), heff_strAppend(v_x_2411, ((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str7)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2428});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam8(V self, V *args) {
  V v_n_2429 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_e_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){v_x_2411}), heff_get_n(v_e_2425, 3, 4)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2430, v_n_2429})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam9(V self, V *args) {
  V v_n_2432 = args[0];
  heff_drop(v_n_2432);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str8)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11(V self, V *args) {
  V v_u_2454 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2454);
  V v_x1_2455 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_take_field(v_c_240, 3), NTAG(TAG_N), v_a_2434, heff_get_n(v_c_240, 1, 4)));
  switch (heff_tag_of(v_x1_2455)) {
  case TAG_Nom: {
    V v_x_2456 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2456;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2455, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2458 = heff_field(v_x1_2455, 0);
    heff_take_n(v_x1_2455, 1ULL, 1);
    return v_x_2458;
  }
  default: return heff_nomatch(v_x1_2455);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12(V self, V *args) {
  V v_u_2476 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2434 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2476);
  V v_x1_2477 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_take_field(v_c_240, 3), NTAG(TAG_N), v_a_2434, heff_get_n(v_c_240, 1, 4)));
  switch (heff_tag_of(v_x1_2477)) {
  case TAG_Nom: {
    V v_x_2478 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    return v_x_2478;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2477, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2480 = heff_field(v_x1_2477, 0);
    heff_take_n(v_x1_2477, 1ULL, 1);
    return v_x_2480;
  }
  default: return heff_nomatch(v_x1_2477);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam10(V self, V *args) {
  V v_n_2436 = args[0];
  V v_m_2435 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_a_2434 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2437 = heff_tr(heff_apply(v_m_2435, 1, (V[]){v_n_2436}));
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_Left: {
    V v_e_2438 = heff_field(v_x2_2437, 0);
    V v_ru_24x2_2437_24Left = heff_take_reuse_n(v_x2_2437, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_a_2434);
    return heff_tag_at_n(v_ru_24x2_2437_24Left, TAG_Left, 1, (V[]){v_e_2438});
  }
  case TAG_Right: {
    V v_x21_2439 = heff_field(v_x2_2437, 0);
    V v_ru_24x2_2437_24Right = heff_take_reuse_n(v_x2_2437, 1ULL, 1);
    switch (heff_tag_of(v_x21_2439)) {
    case TAG_MkPair: {
      V v_x_2440 = heff_field(v_x21_2439, 0);
      V v_n_2441 = heff_field(v_x21_2439, 1);
      V v_ru_24x21_2439_24MkPair = heff_take_reuse_n(v_x21_2439, 3ULL, 2);
      switch (heff_tag_of(v_x_2440)) {
      case TAG_MkPair: {
        V v_f_27_2442 = heff_field(v_x_2440, 0);
        V v_fty_2443 = heff_field(v_x_2440, 1);
        V v_ru_24x_2440_24MkPair = heff_take_reuse_n(v_x_2440, 3ULL, 2);
        V v_t_2444 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2443));
        switch (heff_tag_of(v_t_2444)) {
        case TAG_LikeU: {
          heff_take_n(v_t_2444, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str9)});
        }
        case TAG_LikeFunction: {
          V v_dom_2447 = heff_field(v_t_2444, 1);
          V v_cod_2448 = heff_field(v_t_2444, 2);
          heff_take_n(v_t_2444, 6ULL, 4);
          V v_t_2450 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_2447)));
          switch (heff_tag_of(v_t_2450)) {
          case TAG_True: {
            heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
            heff_drop(v_dom_2447);
            V v_x1_2460;
            switch (heff_tag_of(v_cod_2448)) {
            case TAG_MkClo: {
              V v_vs_2452 = heff_field(v_cod_2448, 1);
              V v_body_2453 = heff_field(v_cod_2448, 2);
              heff_take_n(v_cod_2448, 6ULL, 3);
              v_x1_2460 = heff_tr(heff_apply(v_body_2453, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2452, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam11, 1, 2, (V[]){v_c_240, v_a_2434})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2459 = heff_field(v_cod_2448, 0);
              heff_take_n(v_cod_2448, 1ULL, 1);
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_a_2434);
              v_x1_2460 = v_body_2459;
              break;
            }
            default: heff_nomatch(v_cod_2448);
            }
            V v_t_2464;
            switch (heff_tag_of(v_x1_2460)) {
            case TAG_Nom: {
              V v_x_2461 = heff_field(v_x1_2460, 0);
              heff_take_n(v_x1_2460, 1ULL, 1);
              v_t_2464 = v_x_2461;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2460, 0ULL, 1);
              v_t_2464 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2463 = heff_field(v_x1_2460, 0);
              heff_take_n(v_x1_2460, 1ULL, 1);
              v_t_2464 = v_x_2463;
              break;
            }
            default: heff_nomatch(v_x1_2460);
            }
            V v_x_2465 = heff_tag_at_n(v_ru_24x21_2439_24MkPair, TAG_MkPair, 2, (V[]){v_f_27_2442, v_t_2464});
            return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2465, v_n_2441})});
          }
          case TAG_False: {
            V v_m_2466 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_a_2434), v_dom_2447));
            V v_x2_2467 = heff_tr(heff_apply(v_m_2466, 1, (V[]){v_n_2441}));
            switch (heff_tag_of(v_x2_2467)) {
            case TAG_Left: {
              V v_e_2468 = heff_field(v_x2_2467, 0);
              heff_take_n(v_x2_2467, 1ULL, 1);
              heff_drop_rec(v_c_240, 4);
              heff_drop(v_a_2434);
              heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
              heff_drop(v_f_27_2442);
              heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
              heff_drop(v_cod_2448);
              return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){v_e_2468});
            }
            case TAG_Right: {
              V v_x21_2469 = heff_field(v_x2_2467, 0);
              heff_take_n(v_x2_2467, 1ULL, 1);
              switch (heff_tag_of(v_x21_2469)) {
              case TAG_MkPair: {
                V v_x_2470 = heff_field(v_x21_2469, 0);
                V v_n_2471 = heff_field(v_x21_2469, 1);
                heff_take_n(v_x21_2469, 3ULL, 2);
                V v_t_2472 = heff_tag_at_n(v_ru_24x21_2439_24MkPair, TAG_Cons, 2, (V[]){v_x_2470, NTAG(TAG_Nil)});
                V v_x1_2482;
                switch (heff_tag_of(v_cod_2448)) {
                case TAG_MkClo: {
                  V v_vs_2474 = heff_field(v_cod_2448, 1);
                  V v_body_2475 = heff_field(v_cod_2448, 2);
                  heff_take_n(v_cod_2448, 6ULL, 3);
                  v_x1_2482 = heff_tr(heff_apply(v_body_2475, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2474, heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam12, 1, 2, (V[]){v_c_240, v_a_2434})})}));
                  break;
                }
                case TAG_CloConst: {
                  V v_body_2481 = heff_field(v_cod_2448, 0);
                  heff_take_n(v_cod_2448, 1ULL, 1);
                  heff_drop_rec(v_c_240, 4);
                  heff_drop(v_a_2434);
                  v_x1_2482 = v_body_2481;
                  break;
                }
                default: heff_nomatch(v_cod_2448);
                }
                V v_t_2486;
                switch (heff_tag_of(v_x1_2482)) {
                case TAG_Nom: {
                  V v_x_2483 = heff_field(v_x1_2482, 0);
                  heff_take_n(v_x1_2482, 1ULL, 1);
                  v_t_2486 = v_x_2483;
                  break;
                }
                case TAG_Describe: {
                  heff_take_n(v_x1_2482, 0ULL, 1);
                  v_t_2486 = heff_abandon();
                  break;
                }
                case TAG_Become: {
                  V v_x_2485 = heff_field(v_x1_2482, 0);
                  heff_take_n(v_x1_2482, 1ULL, 1);
                  v_t_2486 = v_x_2485;
                  break;
                }
                default: heff_nomatch(v_x1_2482);
                }
                V v_x_2487 = heff_tag_at_n(v_ru_24x_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_27_2442, v_t_2472}), v_t_2486});
                return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2487, v_n_2471})});
              }
              default: return heff_nomatch(v_x21_2469);
              }
            }
            default: return heff_nomatch(v_x2_2467);
            }
          }
          default: return heff_nomatch(v_t_2450);
          }
        }
        case TAG_LikeRecord: {
          heff_take_n(v_t_2444, 0ULL, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str10)});
        }
        case TAG_LikeSum: {
          heff_take_n(v_t_2444, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str11)});
        }
        case TAG_LikeInt: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str12)});
        }
        case TAG_LikeFloat: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str13)});
        }
        case TAG_LikeString: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str14)});
        }
        case TAG_LikeRune: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str15)});
        }
        case TAG_LikeArray: {
          heff_take_n(v_t_2444, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str16)});
        }
        case TAG_LikeFixed: {
          heff_take_n(v_t_2444, 0ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str17)});
        }
        case TAG_NoRules: {
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_a_2434);
          heff_drop(v_n_2441);
          heff_drop_cell(v_ru_24x21_2439_24MkPair, 2);
          heff_drop(v_f_27_2442);
          heff_drop_cell(v_ru_24x_2440_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_2437_24Right, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str18)});
        }
        default: return heff_nomatch(v_t_2444);
        }
      }
      default: return heff_nomatch(v_x_2440);
      }
    }
    default: return heff_nomatch(v_x21_2439);
    }
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam13(V self, V *args) {
  V v_n_24102 = args[0];
  V v_m_24101 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_2494 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24103 = heff_tr(heff_apply(v_m_24101, 1, (V[]){v_n_24102}));
  switch (heff_tag_of(v_x2_24103)) {
  case TAG_Left: {
    V v_e_24104 = heff_field(v_x2_24103, 0);
    V v_ru_24x2_24103_24Left = heff_take_reuse_n(v_x2_24103, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_2494);
    return heff_tag_at_n(v_ru_24x2_24103_24Left, TAG_Left, 1, (V[]){v_e_24104});
  }
  case TAG_Right: {
    V v_x21_24105 = heff_field(v_x2_24103, 0);
    V v_ru_24x2_24103_24Right = heff_take_reuse_n(v_x2_24103, 1ULL, 1);
    switch (heff_tag_of(v_x21_24105)) {
    case TAG_MkPair: {
      V v_x_24106 = heff_field(v_x21_24105, 0);
      V v_n_24107 = heff_field(v_x21_24105, 1);
      V v_ru_24x21_24105_24MkPair = heff_take_reuse_n(v_x21_24105, 3ULL, 2);
      V v_x1_24108 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_ty_2494, heff_get_n(v_c_240, 1, 4)));
      V v_t_24112;
      switch (heff_tag_of(v_x1_24108)) {
      case TAG_Nom: {
        V v_x_24109 = heff_field(v_x1_24108, 0);
        heff_take_n(v_x1_24108, 1ULL, 1);
        v_t_24112 = v_x_24109;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24108, 0ULL, 1);
        v_t_24112 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24111 = heff_field(v_x1_24108, 0);
        heff_take_n(v_x1_24108, 1ULL, 1);
        v_t_24112 = v_x_24111;
        break;
      }
      default: heff_nomatch(v_x1_24108);
      }
      V v_x_24113 = heff_tag_at_n(v_ru_24x21_24105_24MkPair, TAG_MkPair, 2, (V[]){v_x_24106, v_t_24112});
      return heff_tag_at_n(v_ru_24x2_24103_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24113, v_n_24107})});
    }
    default: return heff_nomatch(v_x21_24105);
    }
  }
  default: return heff_nomatch(v_x2_24103);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam14(V self, V *args) {
  V v_n_24115 = args[0];
  heff_drop(v_n_24115);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str19)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam15(V self, V *args) {
  V v_n_24119 = args[0];
  V v_m_24118 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_e_24116 = heff_env(self)[2];
  V v_l_24117 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24120 = heff_tr(heff_apply(v_m_24118, 1, (V[]){v_n_24119}));
  switch (heff_tag_of(v_x2_24120)) {
  case TAG_Left: {
    V v_e_24121 = heff_field(v_x2_24120, 0);
    V v_ru_24x2_24120_24Left = heff_take_reuse_n(v_x2_24120, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_e_24116);
    heff_drop(v_l_24117);
    return heff_tag_at_n(v_ru_24x2_24120_24Left, TAG_Left, 1, (V[]){v_e_24121});
  }
  case TAG_Right: {
    V v_x21_24122 = heff_field(v_x2_24120, 0);
    V v_ru_24x2_24120_24Right = heff_take_reuse_n(v_x2_24120, 1ULL, 1);
    switch (heff_tag_of(v_x21_24122)) {
    case TAG_MkPair: {
      V v_x_24123 = heff_field(v_x21_24122, 0);
      V v_n_24124 = heff_field(v_x21_24122, 1);
      V v_ru_24x21_24122_24MkPair = heff_take_reuse_n(v_x21_24122, 3ULL, 2);
      switch (heff_tag_of(v_x_24123)) {
      case TAG_MkPair: {
        V v_e_27_24125 = heff_field(v_x_24123, 0);
        V v_ety_24126 = heff_field(v_x_24123, 1);
        heff_take_n(v_x_24123, 3ULL, 2);
        V v_x1_24127 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), heff_dup(v_e_24116), heff_dup(heff_rfield(v_c_240, 1))));
        V v_v_24131;
        switch (heff_tag_of(v_x1_24127)) {
        case TAG_Nom: {
          V v_x_24128 = heff_field(v_x1_24127, 0);
          heff_take_n(v_x1_24127, 1ULL, 1);
          v_v_24131 = v_x_24128;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_24127, 0ULL, 1);
          v_v_24131 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_24130 = heff_field(v_x1_24127, 0);
          heff_take_n(v_x1_24127, 1ULL, 1);
          v_v_24131 = v_x_24130;
          break;
        }
        default: heff_nomatch(v_x1_24127);
        }
        V v_t_24132 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24131));
        V v_m_24133 = (g_heff_2ecompile_2eerase_2eprojTyInWith(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_ety_24126), v_t_24132, heff_dup(v_l_24117)));
        V v_x2_24134 = heff_tr(heff_apply(v_m_24133, 1, (V[]){v_n_24124}));
        switch (heff_tag_of(v_x2_24134)) {
        case TAG_Left: {
          V v_e_24135 = heff_field(v_x2_24134, 0);
          heff_take_n(v_x2_24134, 1ULL, 1);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_e_24116);
          heff_drop(v_l_24117);
          heff_drop_cell(v_ru_24x21_24122_24MkPair, 2);
          heff_drop(v_e_27_24125);
          heff_drop(v_ety_24126);
          return heff_tag_at_n(v_ru_24x2_24120_24Right, TAG_Left, 1, (V[]){v_e_24135});
        }
        case TAG_Right: {
          V v_x21_24136 = heff_field(v_x2_24134, 0);
          heff_take_n(v_x2_24134, 1ULL, 1);
          switch (heff_tag_of(v_x21_24136)) {
          case TAG_MkPair: {
            V v_x_24137 = heff_field(v_x21_24136, 0);
            V v_n_24138 = heff_field(v_x21_24136, 1);
            heff_take_n(v_x21_24136, 3ULL, 2);
            V v_x1_24139 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_take_field(v_c_240, 3), NTAG(TAG_N), v_e_24116, heff_take_field(v_c_240, 1)));
            V v_v_24143;
            switch (heff_tag_of(v_x1_24139)) {
            case TAG_Nom: {
              V v_x_24140 = heff_field(v_x1_24139, 0);
              heff_take_n(v_x1_24139, 1ULL, 1);
              v_v_24143 = v_x_24140;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_24139, 0ULL, 1);
              v_v_24143 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_24142 = heff_field(v_x1_24139, 0);
              heff_take_n(v_x1_24139, 1ULL, 1);
              v_v_24143 = v_x_24142;
              break;
            }
            default: heff_nomatch(v_x1_24139);
            }
            V v_t_24144 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(v_v_24143));
            V v_t_24145 = (g_heff_2ecompile_2eerase_2eshapeWith(heff_get_n(v_c_240, 2, 4), v_ety_24126, v_t_24144));
            V v_x_24146 = heff_tag_at_n(v_ru_24x21_24122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 3, (V[]){v_e_27_24125, v_l_24117, v_t_24145}), v_x_24137});
            return heff_tag_at_n(v_ru_24x2_24120_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24146, v_n_24138})});
          }
          default: return heff_nomatch(v_x21_24136);
          }
        }
        default: return heff_nomatch(v_x2_24134);
        }
      }
      default: return heff_nomatch(v_x_24123);
      }
    }
    default: return heff_nomatch(v_x21_24122);
    }
  }
  default: return heff_nomatch(v_x2_24120);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam16(V self, V *args) {
  V v_n_24149 = args[0];
  heff_drop(v_n_24149);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str20)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18(V self, V *args) {
  V v_p_24179 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24165 = heff_env(self)[1];
  V v_x_24174 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_240, v_x_24165, v_x_24174, v_p_24179));
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam17(V self, V *args) {
  V v_n_24153 = args[0];
  V v_m_24152 = heff_env(self)[0];
  V v_cases_24151 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24154 = heff_tr(heff_apply(v_m_24152, 1, (V[]){v_n_24153}));
  switch (heff_tag_of(v_x2_24154)) {
  case TAG_Left: {
    V v_e_24155 = heff_field(v_x2_24154, 0);
    V v_ru_24x2_24154_24Left = heff_take_reuse_n(v_x2_24154, 1ULL, 1);
    heff_drop_rec(v_cases_24151, 3);
    heff_drop_rec(v_c_240, 4);
    return heff_tag_at_n(v_ru_24x2_24154_24Left, TAG_Left, 1, (V[]){v_e_24155});
  }
  case TAG_Right: {
    V v_x21_24156 = heff_field(v_x2_24154, 0);
    V v_ru_24x2_24154_24Right = heff_take_reuse_n(v_x2_24154, 1ULL, 1);
    switch (heff_tag_of(v_x21_24156)) {
    case TAG_MkPair: {
      V v_x_24157 = heff_field(v_x21_24156, 0);
      V v_n_24158 = heff_field(v_x21_24156, 1);
      V v_ru_24x21_24156_24MkPair = heff_take_reuse_n(v_x21_24156, 3ULL, 2);
      switch (heff_tag_of(v_x_24157)) {
      case TAG_MkPair: {
        V v_s_27_24159 = heff_field(v_x_24157, 0);
        V v_sty_24160 = heff_field(v_x_24157, 1);
        heff_take_n(v_x_24157, 3ULL, 2);
        V v_m_24161 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24160));
        V v_x2_24162 = heff_tr(heff_apply(v_m_24161, 1, (V[]){v_n_24158}));
        switch (heff_tag_of(v_x2_24162)) {
        case TAG_Left: {
          V v_e_24163 = heff_field(v_x2_24162, 0);
          heff_take_n(v_x2_24162, 1ULL, 1);
          heff_drop_rec(v_cases_24151, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop_cell(v_ru_24x21_24156_24MkPair, 2);
          heff_drop(v_s_27_24159);
          return heff_tag_at_n(v_ru_24x2_24154_24Right, TAG_Left, 1, (V[]){v_e_24163});
        }
        case TAG_Right: {
          V v_x21_24164 = heff_field(v_x2_24162, 0);
          heff_take_n(v_x2_24162, 1ULL, 1);
          switch (heff_tag_of(v_x21_24164)) {
          case TAG_MkPair: {
            V v_x_24165 = heff_field(v_x21_24164, 0);
            V v_n_24166 = heff_field(v_x21_24164, 1);
            heff_take_n(v_x21_24164, 3ULL, 2);
            V v_t_24167 = heff_arrayToList(heff_dup(heff_rfield(v_cases_24151, 0)));
            V v_t_24168 = heff_arrayToList(heff_dup(heff_rfield(v_cases_24151, 2)));
            V v_t_24169 = (g_heff_2eutil_2edict_2ezipKV(v_t_24167, v_t_24168));
            V v_m_24170 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(heff_dup(v_c_240), heff_dup(v_x_24165), v_t_24169));
            V v_x2_24171 = heff_tr(heff_apply(v_m_24170, 1, (V[]){v_n_24166}));
            switch (heff_tag_of(v_x2_24171)) {
            case TAG_Left: {
              V v_e_24172 = heff_field(v_x2_24171, 0);
              heff_take_n(v_x2_24171, 1ULL, 1);
              heff_drop_rec(v_cases_24151, 3);
              heff_drop_rec(v_c_240, 4);
              heff_drop_cell(v_ru_24x21_24156_24MkPair, 2);
              heff_drop(v_s_27_24159);
              heff_drop(v_x_24165);
              return heff_tag_at_n(v_ru_24x2_24154_24Right, TAG_Left, 1, (V[]){v_e_24172});
            }
            case TAG_Right: {
              V v_x21_24173 = heff_field(v_x2_24171, 0);
              heff_take_n(v_x2_24171, 1ULL, 1);
              switch (heff_tag_of(v_x21_24173)) {
              case TAG_MkPair: {
                V v_x_24174 = heff_field(v_x21_24173, 0);
                V v_n_24175 = heff_field(v_x21_24173, 1);
                heff_take_n(v_x21_24173, 3ULL, 2);
                V v_t_24176 = heff_arrayToList(heff_take_field(v_cases_24151, 0));
                V v_t_24177 = heff_arrayToList(heff_get_n(v_cases_24151, 2, 3));
                V v_t_24178 = (g_heff_2eutil_2edict_2ezipKV(v_t_24176, v_t_24177));
                V v_m_24180 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam18, 1, 3, (V[]){v_c_240, v_x_24165, heff_dup(v_x_24174)}), v_t_24178));
                V v_x2_24181 = heff_tr(heff_apply(v_m_24180, 1, (V[]){v_n_24175}));
                switch (heff_tag_of(v_x2_24181)) {
                case TAG_Left: {
                  V v_e_24182 = heff_field(v_x2_24181, 0);
                  heff_take_n(v_x2_24181, 1ULL, 1);
                  heff_drop_cell(v_ru_24x21_24156_24MkPair, 2);
                  heff_drop(v_s_27_24159);
                  heff_drop(v_x_24174);
                  return heff_tag_at_n(v_ru_24x2_24154_24Right, TAG_Left, 1, (V[]){v_e_24182});
                }
                case TAG_Right: {
                  V v_x21_24183 = heff_field(v_x2_24181, 0);
                  heff_take_n(v_x2_24181, 1ULL, 1);
                  switch (heff_tag_of(v_x21_24183)) {
                  case TAG_MkPair: {
                    V v_x_24184 = heff_field(v_x21_24183, 0);
                    V v_n_24185 = heff_field(v_x21_24183, 1);
                    heff_take_n(v_x21_24183, 3ULL, 2);
                    V v_t_24186 = heff_tag_at_n(v_ru_24x21_24156_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_24159, v_x_24184}), v_x_24174});
                    return heff_tag_at_n(v_ru_24x2_24154_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24186, v_n_24185})});
                  }
                  default: return heff_nomatch(v_x21_24183);
                  }
                }
                default: return heff_nomatch(v_x2_24181);
                }
              }
              default: return heff_nomatch(v_x21_24173);
              }
            }
            default: return heff_nomatch(v_x2_24171);
            }
          }
          default: return heff_nomatch(v_x21_24164);
          }
        }
        default: return heff_nomatch(v_x2_24162);
        }
      }
      default: return heff_nomatch(v_x_24157);
      }
    }
    default: return heff_nomatch(v_x21_24156);
    }
  }
  default: return heff_nomatch(v_x2_24154);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam19(V self, V *args) {
  V v_n_24190 = args[0];
  heff_drop(v_n_24190);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str21)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam20(V self, V *args) {
  V v_n_24192 = args[0];
  heff_drop(v_n_24192);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str22)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam21(V self, V *args) {
  V v_n_24193 = args[0];
  heff_drop(v_n_24193);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str23)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam22(V self, V *args) {
  V v_n_24203 = args[0];
  V v_m_24202 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_ty_24195 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_24204 = heff_tr(heff_apply(v_m_24202, 1, (V[]){v_n_24203}));
  switch (heff_tag_of(v_x2_24204)) {
  case TAG_Left: {
    V v_e_24205 = heff_field(v_x2_24204, 0);
    V v_ru_24x2_24204_24Left = heff_take_reuse_n(v_x2_24204, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_24195);
    return heff_tag_at_n(v_ru_24x2_24204_24Left, TAG_Left, 1, (V[]){v_e_24205});
  }
  case TAG_Right: {
    V v_x21_24206 = heff_field(v_x2_24204, 0);
    V v_ru_24x2_24204_24Right = heff_take_reuse_n(v_x2_24204, 1ULL, 1);
    switch (heff_tag_of(v_x21_24206)) {
    case TAG_MkPair: {
      V v_x_24207 = heff_field(v_x21_24206, 0);
      V v_n_24208 = heff_field(v_x21_24206, 1);
      V v_ru_24x21_24206_24MkPair = heff_take_reuse_n(v_x21_24206, 3ULL, 2);
      V v_x1_24209 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980(heff_take_field(v_c_240, 3), NTAG(TAG_N), v_ty_24195, heff_get_n(v_c_240, 1, 4)));
      V v_t_24213;
      switch (heff_tag_of(v_x1_24209)) {
      case TAG_Nom: {
        V v_x_24210 = heff_field(v_x1_24209, 0);
        heff_take_n(v_x1_24209, 1ULL, 1);
        v_t_24213 = v_x_24210;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_24209, 0ULL, 1);
        v_t_24213 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_24212 = heff_field(v_x1_24209, 0);
        heff_take_n(v_x1_24209, 1ULL, 1);
        v_t_24213 = v_x_24212;
        break;
      }
      default: heff_nomatch(v_x1_24209);
      }
      V v_x_24214 = heff_tag_at_n(v_ru_24x21_24206_24MkPair, TAG_MkPair, 2, (V[]){v_x_24207, v_t_24213});
      return heff_tag_at_n(v_ru_24x2_24204_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24214, v_n_24208})});
    }
    default: return heff_nomatch(v_x21_24206);
    }
  }
  default: return heff_nomatch(v_x2_24204);
  }
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam23(V self, V *args) {
  V v_n_24218 = args[0];
  heff_drop(v_n_24218);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str24)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam24(V self, V *args) {
  V v_n_24222 = args[0];
  heff_drop(v_n_24222);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_str25)});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam25(V self, V *args) {
  V v_n_24224 = args[0];
  V v_i_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24225 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_i_24223}), NTAG(TAG_VPrimInt)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24225, v_n_24224})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam26(V self, V *args) {
  V v_n_24227 = args[0];
  V v_x_24226 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24228 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFloat, 1, (V[]){v_x_24226}), NTAG(TAG_VPrimFloat)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24228, v_n_24227})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam27(V self, V *args) {
  V v_n_24230 = args[0];
  V v_s_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24231 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_s_24229}), NTAG(TAG_VPrimString)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24231, v_n_24230})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam28(V self, V *args) {
  V v_n_24233 = args[0];
  V v_n_24232 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24234 = heff_tag_n(TAG_EFixed, 2, (V[]){NTAG(TAG_I32), v_n_24232});
  V v_t_24235 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24234, NTAG(TAG_VPrimRune)});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24235, v_n_24233})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam29(V self, V *args) {
  V v_n_24238 = args[0];
  V v_w_24236 = heff_env(self)[0];
  V v_n_24237 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24239 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFixed, 2, (V[]){heff_dup(v_w_24236), v_n_24237}), heff_tag_n(TAG_VFixed, 1, (V[]){v_w_24236})});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24239, v_n_24238})});
}
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_lam30(V self, V *args) {
  V v_n_24241 = args[0];
  V v_x_24240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24242 = heff_tag_n(TAG_VFixed, 1, (V[]){NTAG(TAG_F32)});
  V v_t_24243 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFloat32, 1, (V[]){v_x_24240}), v_t_24242});
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24243, v_n_24241})});
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str0, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str3, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str4, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str5, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str6, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str7, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str8, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str9, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str10, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str11, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str12, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str13, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str14, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str15, 46, "a function checked against a non-function type");
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam9(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam12, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam13(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam13, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam15(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam15, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam18(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam18, 1, 0};
Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(V v_c_240, V v_abs_241, V v_ty_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_242));
  switch (heff_tag_of(v_t_243)) {
  case TAG_LikeU: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam0_clo);
  }
  case TAG_LikeFunction: {
    V v_dom_247 = heff_field(v_t_243, 1);
    V v_cod_248 = heff_field(v_t_243, 2);
    heff_take_n(v_t_243, 6ULL, 4);
    V v_it_2415;
    switch (heff_tag_of(v_abs_241)) {
    case TAG_MkAbs: {
      V v_n_2410 = heff_field(v_abs_241, 0);
      V v_b_2411 = heff_field(v_abs_241, 1);
      V v_ru_24abs_241_24MkAbs = heff_take_reuse_n(v_abs_241, 3ULL, 2);
      V v_t_2412 = heff_tag_at_n(v_ru_24abs_241_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2410, NTAG(TAG_True)});
      v_it_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_b_2411});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2413 = heff_field(v_abs_241, 0);
      heff_take_n(v_abs_241, 1ULL, 1);
      V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str1), NTAG(TAG_False)});
      v_it_2415 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2414, v_b_2413});
      break;
    }
    default: heff_nomatch(v_abs_241);
    }
    switch (heff_tag_of(v_it_2415)) {
    case TAG_MkPair: {
      V v_it1_2416 = heff_field(v_it_2415, 0);
      V v_body_2417 = heff_field(v_it_2415, 1);
      V v_ru_24it_2415_24MkPair = heff_take_reuse_n(v_it_2415, 3ULL, 2);
      switch (heff_tag_of(v_it1_2416)) {
      case TAG_MkPair: {
        V v_hint_2418 = heff_field(v_it1_2416, 0);
        V v_bound_2419 = heff_field(v_it1_2416, 1);
        V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
        V v_t_2420 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_247)));
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          heff_drop(v_hint_2418);
          V v_c_2429;
          switch (heff_tag_of(v_bound_2419)) {
          case TAG_True: {
            V v_t_2421 = heff_rec_n(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_247)});
            V v_t_2422 = heff_tag_at_n(v_ru_24it_2415_24MkPair, TAG_Cons, 2, (V[]){v_t_2421, heff_dup(heff_rfield(v_c_240, 0))});
            V v_t_2423 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
            V v_v_2425 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2423, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam1, 1, 1, (V[]){heff_dup(v_dom_247)}), NTAG(TAG_Nothing)));
            V v_t_2427 = heff_tag_at_n(v_ru_24it1_2416_24MkPair, TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam2, 1, 1, (V[]){v_v_2425})});
            V v_t_2428 = heff_intAdd(heff_dup(heff_rfield(v_c_240, 2)), MK_INT(1LL));
            v_c_2429 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2422, v_t_2427, v_t_2428, heff_dup(heff_rfield(v_c_240, 3))});
            break;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_2415_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2416_24MkPair, 2);
            v_c_2429 = heff_dup(v_c_240);
            break;
          }
          default: heff_nomatch(v_bound_2419);
          }
          V v_x1_2437;
          switch (heff_tag_of(v_cod_248)) {
          case TAG_MkClo: {
            V v_vs_2431 = heff_field(v_cod_248, 1);
            V v_body_2432 = heff_field(v_cod_248, 2);
            heff_take_n(v_cod_248, 6ULL, 3);
            v_x1_2437 = heff_tr(heff_apply(v_body_2432, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2431, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam3, 1, 2, (V[]){v_c_240, v_dom_247})})}));
            break;
          }
          case TAG_CloConst: {
            V v_body_2436 = heff_field(v_cod_248, 0);
            heff_take_n(v_cod_248, 1ULL, 1);
            heff_drop_rec(v_c_240, 4);
            heff_drop(v_dom_247);
            v_x1_2437 = v_body_2436;
            break;
          }
          default: heff_nomatch(v_cod_248);
          }
          V v_ty_2441;
          switch (heff_tag_of(v_x1_2437)) {
          case TAG_Nom: {
            V v_x_2438 = heff_field(v_x1_2437, 0);
            heff_take_n(v_x1_2437, 1ULL, 1);
            v_ty_2441 = v_x_2438;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2437, 0ULL, 1);
            v_ty_2441 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2440 = heff_field(v_x1_2437, 0);
            heff_take_n(v_x1_2437, 1ULL, 1);
            v_ty_2441 = v_x_2440;
            break;
          }
          default: heff_nomatch(v_x1_2437);
          }
          HEFF_LAST return g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_2429, v_body_2417, v_ty_2441);
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24it_2415_24MkPair, 2);
          heff_drop_cell(v_ru_24it1_2416_24MkPair, 2);
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam5, 1, 6, (V[]){v_hint_2418, v_bound_2419, v_dom_247, v_c_240, v_cod_248, v_body_2417});
        }
        default: return heff_nomatch(v_t_2420);
        }
      }
      default: return heff_nomatch(v_it1_2416);
      }
    }
    default: return heff_nomatch(v_it_2415);
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_243, 0ULL, 3);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam10_clo);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam11_clo);
  }
  case TAG_LikeInt: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam12_clo);
  }
  case TAG_LikeFloat: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam13_clo);
  }
  case TAG_LikeString: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam14_clo);
  }
  case TAG_LikeRune: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam15_clo);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam16_clo);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam17_clo);
  }
  case TAG_NoRules: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_abs_241);
    return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam18_clo);
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam0(V self, V *args) {
  V v_n_245 = args[0];
  heff_drop(v_n_245);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str0)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2424);
  return v_dom_247;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam2(V self, V *args) {
  V v_u_2426 = args[0];
  V v_v_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2426);
  return v_v_2425;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam4(V self, V *args) {
  V v_u_2435 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2435);
  return v_dom_247;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam3(V self, V *args) {
  V v_u_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2433);
  V v_t_2434 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2434, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam4, 1, 1, (V[]){v_dom_247}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam6(V self, V *args) {
  V v_u_2456 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  return v_dom_247;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam7(V self, V *args) {
  V v_u_2458 = args[0];
  V v_v_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2458);
  return v_v_2457;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam9(V self, V *args) {
  V v_u_2467 = args[0];
  V v_dom_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2467);
  return v_dom_247;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam8(V self, V *args) {
  V v_u_2465 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2465);
  V v_t_2466 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2466, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam9, 1, 1, (V[]){v_dom_247}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam5(V self, V *args) {
  V v_n_2442 = args[0];
  V v_hint_2418 = heff_env(self)[0];
  V v_bound_2419 = heff_env(self)[1];
  V v_dom_247 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_248 = heff_env(self)[4];
  V v_body_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_base_2445;
  if (heff_strEq_c(heff_dup(v_hint_2418), ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str2))) {
    heff_drop(v_hint_2418);
    v_base_2445 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str3);
  } else {
    if (heff_strEq_c(heff_dup(v_hint_2418), ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str4))) {
      heff_drop(v_hint_2418);
      v_base_2445 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str5);
    } else {
      v_base_2445 = v_hint_2418;
    }
  }
  V v_t_2446 = heff_strAppend(v_base_2445, heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str6), heff_intShow(heff_dup(v_n_2442))));
  V v_t_2447 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, heff_intAdd(v_n_2442, MK_INT(1LL))});
  V v_x2_2448 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2447});
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_Left: {
    V v_e_2449 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Left = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    heff_drop(v_bound_2419);
    heff_drop(v_dom_247);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_cod_248);
    heff_drop(v_body_2417);
    return heff_tag_at_n(v_ru_24x2_2448_24Left, TAG_Left, 1, (V[]){v_e_2449});
  }
  case TAG_Right: {
    V v_x21_2450 = heff_field(v_x2_2448, 0);
    V v_ru_24x2_2448_24Right = heff_take_reuse_n(v_x2_2448, 1ULL, 1);
    switch (heff_tag_of(v_x21_2450)) {
    case TAG_MkPair: {
      V v_x_2451 = heff_field(v_x21_2450, 0);
      V v_n_2452 = heff_field(v_x21_2450, 1);
      V v_ru_24x21_2450_24MkPair = heff_take_reuse_n(v_x21_2450, 3ULL, 2);
      V v_c_2461;
      switch (heff_tag_of(v_bound_2419)) {
      case TAG_True: {
        V v_t_2453 = heff_tag_at_n(v_ru_24x2_2448_24Right, TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2451)})});
        V v_t_2454 = heff_tag_at_n(v_ru_24x21_2450_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2453, heff_dup(v_dom_247)}), heff_dup(heff_rfield(v_c_240, 0))});
        V v_t_2455 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
        V v_v_2457 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2455, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam6, 1, 1, (V[]){heff_dup(v_dom_247)}), NTAG(TAG_Nothing)));
        V v_t_2459 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam7, 1, 1, (V[]){v_v_2457})});
        V v_t_2460 = heff_intAdd(heff_dup(heff_rfield(v_c_240, 2)), MK_INT(1LL));
        v_c_2461 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2454, v_t_2459, v_t_2460, heff_dup(heff_rfield(v_c_240, 3))});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_2448_24Right, 1);
        heff_drop_cell(v_ru_24x21_2450_24MkPair, 2);
        v_c_2461 = heff_dup(v_c_240);
        break;
      }
      default: heff_nomatch(v_bound_2419);
      }
      V v_x1_2469;
      switch (heff_tag_of(v_cod_248)) {
      case TAG_MkClo: {
        V v_vs_2463 = heff_field(v_cod_248, 1);
        V v_body_2464 = heff_field(v_cod_248, 2);
        heff_take_n(v_cod_248, 6ULL, 3);
        v_x1_2469 = heff_tr(heff_apply(v_body_2464, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2463, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam8, 1, 2, (V[]){v_c_240, v_dom_247})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2468 = heff_field(v_cod_248, 0);
        heff_take_n(v_cod_248, 1ULL, 1);
        heff_drop(v_dom_247);
        heff_drop_rec(v_c_240, 4);
        v_x1_2469 = v_body_2468;
        break;
      }
      default: heff_nomatch(v_cod_248);
      }
      V v_ty_2473;
      switch (heff_tag_of(v_x1_2469)) {
      case TAG_Nom: {
        V v_x_2470 = heff_field(v_x1_2469, 0);
        heff_take_n(v_x1_2469, 1ULL, 1);
        v_ty_2473 = v_x_2470;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2469, 0ULL, 1);
        v_ty_2473 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2472 = heff_field(v_x1_2469, 0);
        heff_take_n(v_x1_2469, 1ULL, 1);
        v_ty_2473 = v_x_2472;
        break;
      }
      default: heff_nomatch(v_x1_2469);
      }
      V v_m_2474 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_2461, v_body_2417, v_ty_2473));
      V v_x2_2475 = heff_tr(heff_apply(v_m_2474, 1, (V[]){v_n_2452}));
      switch (heff_tag_of(v_x2_2475)) {
      case TAG_Left: {
        V v_e_2476 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Left = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        heff_drop(v_x_2451);
        return heff_tag_at_n(v_ru_24x2_2475_24Left, TAG_Left, 1, (V[]){v_e_2476});
      }
      case TAG_Right: {
        V v_x21_2477 = heff_field(v_x2_2475, 0);
        V v_ru_24x2_2475_24Right = heff_take_reuse_n(v_x2_2475, 1ULL, 1);
        switch (heff_tag_of(v_x21_2477)) {
        case TAG_MkPair: {
          V v_x_2478 = heff_field(v_x21_2477, 0);
          V v_n_2479 = heff_field(v_x21_2477, 1);
          V v_ru_24x21_2477_24MkPair = heff_take_reuse_n(v_x21_2477, 3ULL, 2);
          V v_t_2480 = heff_tag_at_n(v_ru_24x21_2477_24MkPair, TAG_Cons, 2, (V[]){v_x_2451, NTAG(TAG_Nil)});
          V v_t_2481 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2480, v_x_2478}), v_n_2479});
          return heff_tag_at_n(v_ru_24x2_2475_24Right, TAG_Right, 1, (V[]){v_t_2481});
        }
        default: return heff_nomatch(v_x21_2477);
        }
      }
      default: return heff_nomatch(v_x2_2475);
      }
    }
    default: return heff_nomatch(v_x21_2450);
    }
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam10(V self, V *args) {
  V v_n_2485 = args[0];
  heff_drop(v_n_2485);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str7)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam11(V self, V *args) {
  V v_n_2487 = args[0];
  heff_drop(v_n_2487);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str8)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam12(V self, V *args) {
  V v_n_2488 = args[0];
  heff_drop(v_n_2488);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str9)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam13(V self, V *args) {
  V v_n_2489 = args[0];
  heff_drop(v_n_2489);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str10)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam14(V self, V *args) {
  V v_n_2490 = args[0];
  heff_drop(v_n_2490);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str11)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam15(V self, V *args) {
  V v_n_2491 = args[0];
  heff_drop(v_n_2491);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str12)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam16(V self, V *args) {
  V v_n_2493 = args[0];
  heff_drop(v_n_2493);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str13)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam17(V self, V *args) {
  V v_n_2495 = args[0];
  heff_drop(v_n_2495);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str14)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_lam18(V self, V *args) {
  V v_n_2496 = args[0];
  heff_drop(v_n_2496);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_str15)});
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    V v_x_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_243, 1, 2)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0, 1, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_x61_247 = heff_field(v_x6_244, 0);
    V v_tail_248 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_247)) {
    case TAG_MkPair: {
      V v_l_249 = heff_field(v_x61_247, 0);
      V v_fe_2410 = heff_field(v_x61_247, 1);
      heff_take_n(v_x61_247, 3ULL, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_acc_243, 0))));
      V v_t_2412 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_242, 0)), heff_dup(heff_rfield(v_fieldTypes_242, 1)), heff_arrayFromList(v_t_2411)});
      V v_t_2413 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), heff_dup(v_l_249), v_t_2412));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_MkField: {
        V v_fty_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 2);
        V v_t_2416 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_fty_2414)));
        switch (heff_tag_of(v_t_2416)) {
        case TAG_True: {
          heff_drop(v_l_249);
          heff_drop(v_fty_2414);
          V v_x1_2417 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2410, heff_dup(heff_rfield(v_c_240, 1))));
          V v_t_2421;
          switch (heff_tag_of(v_x1_2417)) {
          case TAG_Nom: {
            V v_x_2418 = heff_field(v_x1_2417, 0);
            heff_take_n(v_x1_2417, 1ULL, 1);
            v_t_2421 = v_x_2418;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2417, 0ULL, 1);
            v_t_2421 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2420 = heff_field(v_x1_2417, 0);
            heff_take_n(v_x1_2417, 1ULL, 1);
            v_t_2421 = v_x_2420;
            break;
          }
          default: heff_nomatch(v_x1_2417);
          }
          V v_t_2422 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2421, heff_dup(heff_rfield(v_acc_243, 0))});
          V v_t_2423 = ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_n(v_acc_243, 2ULL, 2, shape_vs__out); heff_rfield(rr_, 0) = rv_0; rr_; });
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2423;
          V t_4 = v_tail_248;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        }
        case TAG_False: {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          V v_m_2424 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_fe_2410), v_fty_2414));
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1, 1, 8, (V[]){v_m_2424, v_c_240, v_fe_2410, v_acc_243, v_l_249, v_capture_241, v_fieldTypes_242, v_tail_248});
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    default: return heff_nomatch(v_x61_247);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_n_246})});
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args) {
  V v_n_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2410 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_l_249 = heff_env(self)[4];
  V v_capture_241 = heff_env(self)[5];
  V v_fieldTypes_242 = heff_env(self)[6];
  V v_tail_248 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x2_2426 = heff_tr(heff_apply(v_m_2424, 1, (V[]){v_n_2425}));
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_Left: {
    V v_e_2427 = heff_field(v_x2_2426, 0);
    V v_ru_24x2_2426_24Left = heff_take_reuse_n(v_x2_2426, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fe_2410);
    heff_drop_rec(v_acc_243, 2);
    heff_drop(v_l_249);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    heff_drop(v_tail_248);
    return heff_tag_at_n(v_ru_24x2_2426_24Left, TAG_Left, 1, (V[]){v_e_2427});
  }
  case TAG_Right: {
    V v_x21_2428 = heff_field(v_x2_2426, 0);
    heff_take_n(v_x2_2426, 1ULL, 1);
    switch (heff_tag_of(v_x21_2428)) {
    case TAG_MkPair: {
      V v_x_2429 = heff_field(v_x21_2428, 0);
      V v_n_2430 = heff_field(v_x21_2428, 1);
      V v_ru_24x21_2428_24MkPair = heff_take_reuse_n(v_x21_2428, 3ULL, 2);
      V v_x1_2431 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2410, heff_dup(heff_rfield(v_c_240, 1))));
      V v_t_2435;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Nom: {
        V v_x_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_t_2435 = v_x_2432;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2431, 0ULL, 1);
        v_t_2435 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2434 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_t_2435 = v_x_2434;
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      V v_t_2436 = heff_tag_at_n(v_ru_24x21_2428_24MkPair, TAG_Cons, 2, (V[]){v_t_2435, heff_dup(heff_rfield(v_acc_243, 0))});
      V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_249, v_x_2429}), heff_get_n(v_acc_243, 1, 2)});
      V v_t_2438 = (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_241, v_fieldTypes_242, heff_rec_n(2, shape_vs__out, (V[]){v_t_2436, v_t_2437}), v_tail_248));
      V f_ = v_t_2438;
      args[0] = v_n_2430;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2428);
    }
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry, 2, 0};

V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V v_c_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkPair: {
    V v_a_242 = heff_field(v_x3_241, 0);
    V v_aty_243 = heff_field(v_x3_241, 1);
    heff_take_n(v_x3_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_aty_243)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_a_242);
      heff_drop(v_aty_243);
      return ((V)&g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0_clo);
    }
    case TAG_False: {
      V v_m_247 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_a_242, v_aty_243));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_t_246 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_245});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_246});
}
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_lam1(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Just, 1, (V[]){v_x_2412}), v_n_2413});
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2414});
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0, 26, "a type in a value position");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str3, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str4, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str5, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str6, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str7, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str8, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str9, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str10, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str11, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str12, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str13, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str14, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str15, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str16, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str17, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str18, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str19, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str20, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str21, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str22, 14, "an opaque term");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str24, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str25, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str26, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str27, 1, "$");
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam19(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam20(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam30(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam29(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam35(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam36(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam34(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam37(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam38(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam39(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam40(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam41(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam42(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam43(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam44(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_ty_242);
    V v_m_244 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam0, 1, 1, (V[]){v_m_244});
  }
  case TAG_SGlobal: {
    heff_drop(v_ty_242);
    V v_m_2414 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2_clo);
  }
  case TAG_SApp: {
    heff_drop(v_ty_242);
    V v_m_2427 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam3, 1, 1, (V[]){v_m_2427});
  }
  case TAG_SLam: {
    V v_abs_2437 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(v_c_240, v_abs_2437, v_ty_242);
  }
  case TAG_SCons: {
    V v_d_2438 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_2439 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2439, 0ULL, 4);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2448 = heff_field(v_t_2439, 1);
      V v_fieldTypes_2449 = heff_field(v_t_2439, 2);
      heff_take_n(v_t_2439, 6ULL, 3);
      V v_t_2450 = heff_rec_n(2, shape_vs__out, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2451 = heff_arrayToList(heff_take_field(v_d_2438, 0));
      V v_t_2452 = heff_arrayToList(heff_get_n(v_d_2438, 2, 3));
      V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
      V v_m_2454 = (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_2448, v_fieldTypes_2449, v_t_2450, v_t_2453));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6, 1, 1, (V[]){v_m_2454});
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7_clo);
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14_clo);
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_SProj: {
    heff_drop(v_ty_242);
    V v_m_2475 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15, 1, 1, (V[]){v_m_2475});
  }
  case TAG_STag: {
    V v_x_2484 = heff_field(v_t_241, 0);
    V v_args_2485 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_2486 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2486)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2486, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2486, 0ULL, 4);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17_clo);
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2486, 0ULL, 3);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18_clo);
    }
    case TAG_LikeSum: {
      V v_vs_2498 = heff_field(v_t_2486, 0);
      V v_ru_24t_2486_24LikeSum = heff_take_reuse_n(v_t_2486, 1ULL, 1);
      V v_t_2499 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2484), heff_rfield(v_vs_2498, 1)));
      V v_t_24105;
      switch (heff_tag_of(v_t_2499)) {
      case TAG_Nothing: {
        heff_drop_rec(v_vs_2498, 3);
        heff_drop_cell(v_ru_24t_2486_24LikeSum, 1);
        v_t_24105 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_24100 = heff_field(v_t_2499, 0);
        heff_take_n(v_t_2499, 1ULL, 1);
        V v_xs_24101 = heff_get_n(v_vs_2498, 2, 3);
        if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_24100))) {
          if (heff_intLt_c(heff_dup(v_i_24100), heff_arrayLength(heff_dup(v_xs_24101)))) {
            V v_t_24104 = heff_arrayIndex(v_xs_24101, v_i_24100);
            v_t_24105 = heff_tag_at_n(v_ru_24t_2486_24LikeSum, TAG_Just, 1, (V[]){v_t_24104});
          } else {
            heff_drop_cell(v_ru_24t_2486_24LikeSum, 1);
            heff_drop(v_i_24100);
            heff_drop(v_xs_24101);
            v_t_24105 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24t_2486_24LikeSum, 1);
          heff_drop(v_i_24100);
          heff_drop(v_xs_24101);
          v_t_24105 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_t_2499);
      }
      switch (heff_tag_of(v_t_24105)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_240, 4);
        heff_drop(v_args_2485);
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam19, 1, 1, (V[]){v_x_2484});
      }
      case TAG_Just: {
        V v_ts_24107 = heff_field(v_t_24105, 0);
        heff_take_n(v_t_24105, 1ULL, 1);
        V v_t_24108 = (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_24107)));
        V v_t_24109 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_args_2485), v_t_24108));
        V v_m_24111 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam20, 1, 1, (V[]){v_c_240}), v_t_24109));
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21, 1, 2, (V[]){v_m_24111, v_x_2484});
      }
      default: return heff_nomatch(v_t_24105);
      }
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2486, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2486, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2484);
      heff_drop(v_args_2485);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28_clo);
    }
    default: return heff_nomatch(v_t_2486);
    }
  }
  case TAG_SMatch: {
    V v_scrut_24128 = heff_field(v_t_241, 0);
    V v_cases_24129 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24130 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_scrut_24128));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam29, 1, 4, (V[]){v_m_24130, v_cases_24129, v_c_240, v_ty_242});
  }
  case TAG_SSpecialize: {
    heff_drop(v_ty_242);
    V v_m_24159 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31, 1, 1, (V[]){v_m_24159});
  }
  case TAG_SIs: {
    V v_t_27_24168 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24168;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32_clo);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33_clo);
  }
  case TAG_SRec: {
    V v_t_27_24172 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24172;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_t2_27_24174 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    switch (heff_tag_of(v_t2_27_24174)) {
    case TAG_MkAbs: {
      V v_x_24175 = heff_field(v_t2_27_24174, 0);
      V v_body_24176 = heff_field(v_t2_27_24174, 1);
      heff_take_n(v_t2_27_24174, 3ULL, 2);
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam34, 1, 4, (V[]){v_x_24175, v_ty_242, v_c_240, v_body_24176});
    }
    case TAG_AbsConst: {
      V v_body_24204 = heff_field(v_t2_27_24174, 0);
      heff_take_n(v_t2_27_24174, 1ULL, 1);
      V t_0 = v_c_240;
      V t_1 = v_body_24204;
      V t_2 = v_ty_242;
      v_c_240 = t_0;
      v_t_241 = t_1;
      v_ty_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t2_27_24174);
    }
  }
  case TAG_SImplicit: {
    V v_t_27_24206 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24206;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_24207 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam37, 1, 1, (V[]){v_x_24207});
  }
  case TAG_SMetaApp: {
    heff_drop(v_ty_242);
    V v_m_24213 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam38, 1, 1, (V[]){v_m_24213});
  }
  case TAG_SLitInt: {
    heff_drop(v_ty_242);
    V v_m_24223 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam39, 1, 1, (V[]){v_m_24223});
  }
  case TAG_SLitFloat: {
    heff_drop(v_ty_242);
    V v_m_24233 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam40, 1, 1, (V[]){v_m_24233});
  }
  case TAG_SLitString: {
    heff_drop(v_ty_242);
    V v_m_24243 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam41, 1, 1, (V[]){v_m_24243});
  }
  case TAG_SLitRune: {
    heff_drop(v_ty_242);
    V v_m_24253 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam42, 1, 1, (V[]){v_m_24253});
  }
  case TAG_SLitFixed: {
    heff_drop(v_ty_242);
    V v_m_24264 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam43, 1, 1, (V[]){v_m_24264});
  }
  case TAG_SLitFloat32: {
    heff_drop(v_ty_242);
    V v_m_24274 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam44, 1, 1, (V[]){v_m_24274});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_apply(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Left: {
    V v_e_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Left = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_246_24Left, TAG_Left, 1, (V[]){v_e_247});
  }
  case TAG_Right: {
    V v_x21_248 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Right = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x21_248, 0);
      V v_n_2410 = heff_field(v_x21_248, 1);
      heff_take_n(v_x21_248, 3ULL, 2);
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_t_27_2411 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_246_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2411, v_n_2410})});
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2416 = heff_tr(heff_apply(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Left: {
    V v_e_2417 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Left = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2416_24Left, TAG_Left, 1, (V[]){v_e_2417});
  }
  case TAG_Right: {
    V v_x21_2418 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Right = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x21_2418, 0);
      V v_n_2420 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 2);
      switch (heff_tag_of(v_x_2419)) {
      case TAG_MkPair: {
        V v_t_27_2421 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2416_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2421, v_n_2420})});
      }
      default: return heff_nomatch(v_x_2419);
      }
    }
    default: return heff_nomatch(v_x21_2418);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  heff_drop(v_n_2424);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2429 = heff_tr(heff_apply(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Left: {
    V v_e_2430 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Left = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2429_24Left, TAG_Left, 1, (V[]){v_e_2430});
  }
  case TAG_Right: {
    V v_x21_2431 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Right = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x21_2431, 0);
      V v_n_2433 = heff_field(v_x21_2431, 1);
      heff_take_n(v_x21_2431, 3ULL, 2);
      switch (heff_tag_of(v_x_2432)) {
      case TAG_MkPair: {
        V v_t_27_2434 = heff_field(v_x_2432, 0);
        heff_take_n(v_x_2432, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2429_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2434, v_n_2433})});
      }
      default: return heff_nomatch(v_x_2432);
      }
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4(V self, V *args) {
  V v_n_2441 = args[0];
  heff_drop(v_n_2441);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  heff_drop(v_n_2446);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  V v_m_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2456 = heff_tr(heff_apply(v_m_2454, 1, (V[]){v_n_2455}));
  switch (heff_tag_of(v_x2_2456)) {
  case TAG_Left: {
    V v_e_2457 = heff_field(v_x2_2456, 0);
    V v_ru_24x2_2456_24Left = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2456_24Left, TAG_Left, 1, (V[]){v_e_2457});
  }
  case TAG_Right: {
    V v_x21_2458 = heff_field(v_x2_2456, 0);
    V v_ru_24x2_2456_24Right = heff_take_reuse_n(v_x2_2456, 1ULL, 1);
    switch (heff_tag_of(v_x21_2458)) {
    case TAG_MkPair: {
      V v_x_2459 = heff_field(v_x21_2458, 0);
      V v_n_2460 = heff_field(v_x21_2458, 1);
      V v_ru_24x21_2458_24MkPair = heff_take_reuse_n(v_x21_2458, 3ULL, 2);
      V v_t_2461 = heff_tag_at_n(v_ru_24x21_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x2_2456_24Right, TAG_ERecord, 1, (V[]){v_x_2459}), v_n_2460});
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2461});
    }
    default: return heff_nomatch(v_x21_2458);
    }
  }
  default: return heff_nomatch(v_x2_2456);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7(V self, V *args) {
  V v_n_2463 = args[0];
  heff_drop(v_n_2463);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str3)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8(V self, V *args) {
  V v_n_2464 = args[0];
  heff_drop(v_n_2464);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str4)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9(V self, V *args) {
  V v_n_2465 = args[0];
  heff_drop(v_n_2465);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str5)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10(V self, V *args) {
  V v_n_2466 = args[0];
  heff_drop(v_n_2466);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str6)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11(V self, V *args) {
  V v_n_2467 = args[0];
  heff_drop(v_n_2467);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str7)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12(V self, V *args) {
  V v_n_2469 = args[0];
  heff_drop(v_n_2469);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str8)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13(V self, V *args) {
  V v_n_2471 = args[0];
  heff_drop(v_n_2471);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str9)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14(V self, V *args) {
  V v_n_2472 = args[0];
  heff_drop(v_n_2472);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str10)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15(V self, V *args) {
  V v_n_2476 = args[0];
  V v_m_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2477 = heff_tr(heff_apply(v_m_2475, 1, (V[]){v_n_2476}));
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_Left: {
    V v_e_2478 = heff_field(v_x2_2477, 0);
    V v_ru_24x2_2477_24Left = heff_take_reuse_n(v_x2_2477, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2477_24Left, TAG_Left, 1, (V[]){v_e_2478});
  }
  case TAG_Right: {
    V v_x21_2479 = heff_field(v_x2_2477, 0);
    V v_ru_24x2_2477_24Right = heff_take_reuse_n(v_x2_2477, 1ULL, 1);
    switch (heff_tag_of(v_x21_2479)) {
    case TAG_MkPair: {
      V v_x_2480 = heff_field(v_x21_2479, 0);
      V v_n_2481 = heff_field(v_x21_2479, 1);
      heff_take_n(v_x21_2479, 3ULL, 2);
      switch (heff_tag_of(v_x_2480)) {
      case TAG_MkPair: {
        V v_t_27_2482 = heff_field(v_x_2480, 0);
        heff_take_n(v_x_2480, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2477_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2482, v_n_2481})});
      }
      default: return heff_nomatch(v_x_2480);
      }
    }
    default: return heff_nomatch(v_x21_2479);
    }
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16(V self, V *args) {
  V v_n_2488 = args[0];
  heff_drop(v_n_2488);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str11)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17(V self, V *args) {
  V v_n_2493 = args[0];
  heff_drop(v_n_2493);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str12)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18(V self, V *args) {
  V v_n_2497 = args[0];
  heff_drop(v_n_2497);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str13)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam19(V self, V *args) {
  V v_n_24106 = args[0];
  V v_x_2484 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24106);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str14), v_x_2484)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam20(V self, V *args) {
  V v_p_24110 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(v_c_240, v_p_24110));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21(V self, V *args) {
  V v_n_24112 = args[0];
  V v_m_24111 = heff_env(self)[0];
  V v_x_2484 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24113 = heff_tr(heff_apply(v_m_24111, 1, (V[]){v_n_24112}));
  switch (heff_tag_of(v_x2_24113)) {
  case TAG_Left: {
    V v_e_24114 = heff_field(v_x2_24113, 0);
    V v_ru_24x2_24113_24Left = heff_take_reuse_n(v_x2_24113, 1ULL, 1);
    heff_drop(v_x_2484);
    return heff_tag_at_n(v_ru_24x2_24113_24Left, TAG_Left, 1, (V[]){v_e_24114});
  }
  case TAG_Right: {
    V v_x21_24115 = heff_field(v_x2_24113, 0);
    V v_ru_24x2_24113_24Right = heff_take_reuse_n(v_x2_24113, 1ULL, 1);
    switch (heff_tag_of(v_x21_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x21_24115, 0);
      V v_n_24117 = heff_field(v_x21_24115, 1);
      V v_ru_24x21_24115_24MkPair = heff_take_reuse_n(v_x21_24115, 3ULL, 2);
      V v_x_24118 = heff_tag_at_n(v_ru_24x21_24115_24MkPair, TAG_ETag, 2, (V[]){v_x_2484, (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_24116))});
      return heff_tag_at_n(v_ru_24x2_24113_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24118, v_n_24117})});
    }
    default: return heff_nomatch(v_x21_24115);
    }
  }
  default: return heff_nomatch(v_x2_24113);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22(V self, V *args) {
  V v_n_24119 = args[0];
  heff_drop(v_n_24119);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str15)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23(V self, V *args) {
  V v_n_24120 = args[0];
  heff_drop(v_n_24120);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str16)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24(V self, V *args) {
  V v_n_24121 = args[0];
  heff_drop(v_n_24121);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str17)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25(V self, V *args) {
  V v_n_24122 = args[0];
  heff_drop(v_n_24122);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str18)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26(V self, V *args) {
  V v_n_24124 = args[0];
  heff_drop(v_n_24124);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str19)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27(V self, V *args) {
  V v_n_24126 = args[0];
  heff_drop(v_n_24126);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str20)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28(V self, V *args) {
  V v_n_24127 = args[0];
  heff_drop(v_n_24127);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str21)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam30(V self, V *args) {
  V v_p_24148 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24143 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_240, v_x_24143, v_ty_242, v_p_24148));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam29(V self, V *args) {
  V v_n_24131 = args[0];
  V v_m_24130 = heff_env(self)[0];
  V v_cases_24129 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24132 = heff_tr(heff_apply(v_m_24130, 1, (V[]){v_n_24131}));
  switch (heff_tag_of(v_x2_24132)) {
  case TAG_Left: {
    V v_e_24133 = heff_field(v_x2_24132, 0);
    V v_ru_24x2_24132_24Left = heff_take_reuse_n(v_x2_24132, 1ULL, 1);
    heff_drop_rec(v_cases_24129, 3);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return heff_tag_at_n(v_ru_24x2_24132_24Left, TAG_Left, 1, (V[]){v_e_24133});
  }
  case TAG_Right: {
    V v_x21_24134 = heff_field(v_x2_24132, 0);
    V v_ru_24x2_24132_24Right = heff_take_reuse_n(v_x2_24132, 1ULL, 1);
    switch (heff_tag_of(v_x21_24134)) {
    case TAG_MkPair: {
      V v_x_24135 = heff_field(v_x21_24134, 0);
      V v_n_24136 = heff_field(v_x21_24134, 1);
      V v_ru_24x21_24134_24MkPair = heff_take_reuse_n(v_x21_24134, 3ULL, 2);
      switch (heff_tag_of(v_x_24135)) {
      case TAG_MkPair: {
        V v_s_27_24137 = heff_field(v_x_24135, 0);
        V v_sty_24138 = heff_field(v_x_24135, 1);
        heff_take_n(v_x_24135, 3ULL, 2);
        V v_m_24139 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24138));
        V v_x2_24140 = heff_tr(heff_apply(v_m_24139, 1, (V[]){v_n_24136}));
        switch (heff_tag_of(v_x2_24140)) {
        case TAG_Left: {
          V v_e_24141 = heff_field(v_x2_24140, 0);
          heff_take_n(v_x2_24140, 1ULL, 1);
          heff_drop_rec(v_cases_24129, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_ty_242);
          heff_drop_cell(v_ru_24x21_24134_24MkPair, 2);
          heff_drop(v_s_27_24137);
          return heff_tag_at_n(v_ru_24x2_24132_24Right, TAG_Left, 1, (V[]){v_e_24141});
        }
        case TAG_Right: {
          V v_x21_24142 = heff_field(v_x2_24140, 0);
          heff_take_n(v_x2_24140, 1ULL, 1);
          switch (heff_tag_of(v_x21_24142)) {
          case TAG_MkPair: {
            V v_x_24143 = heff_field(v_x21_24142, 0);
            V v_n_24144 = heff_field(v_x21_24142, 1);
            heff_take_n(v_x21_24142, 3ULL, 2);
            V v_t_24145 = heff_arrayToList(heff_take_field(v_cases_24129, 0));
            V v_t_24146 = heff_arrayToList(heff_get_n(v_cases_24129, 2, 3));
            V v_t_24147 = (g_heff_2eutil_2edict_2ezipKV(v_t_24145, v_t_24146));
            V v_m_24149 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam30, 1, 3, (V[]){v_c_240, v_x_24143, v_ty_242}), v_t_24147));
            V v_x2_24150 = heff_tr(heff_apply(v_m_24149, 1, (V[]){v_n_24144}));
            switch (heff_tag_of(v_x2_24150)) {
            case TAG_Left: {
              V v_e_24151 = heff_field(v_x2_24150, 0);
              heff_take_n(v_x2_24150, 1ULL, 1);
              heff_drop_cell(v_ru_24x21_24134_24MkPair, 2);
              heff_drop(v_s_27_24137);
              return heff_tag_at_n(v_ru_24x2_24132_24Right, TAG_Left, 1, (V[]){v_e_24151});
            }
            case TAG_Right: {
              V v_x21_24152 = heff_field(v_x2_24150, 0);
              heff_take_n(v_x2_24150, 1ULL, 1);
              switch (heff_tag_of(v_x21_24152)) {
              case TAG_MkPair: {
                V v_x_24153 = heff_field(v_x21_24152, 0);
                V v_n_24154 = heff_field(v_x21_24152, 1);
                heff_take_n(v_x21_24152, 3ULL, 2);
                V v_t_24155 = heff_tag_at_n(v_ru_24x21_24134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_24137, v_x_24153}), v_n_24154});
                return heff_tag_at_n(v_ru_24x2_24132_24Right, TAG_Right, 1, (V[]){v_t_24155});
              }
              default: return heff_nomatch(v_x21_24152);
              }
            }
            default: return heff_nomatch(v_x2_24150);
            }
          }
          default: return heff_nomatch(v_x21_24142);
          }
        }
        default: return heff_nomatch(v_x2_24140);
        }
      }
      default: return heff_nomatch(v_x_24135);
      }
    }
    default: return heff_nomatch(v_x21_24134);
    }
  }
  default: return heff_nomatch(v_x2_24132);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31(V self, V *args) {
  V v_n_24160 = args[0];
  V v_m_24159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24161 = heff_tr(heff_apply(v_m_24159, 1, (V[]){v_n_24160}));
  switch (heff_tag_of(v_x2_24161)) {
  case TAG_Left: {
    V v_e_24162 = heff_field(v_x2_24161, 0);
    V v_ru_24x2_24161_24Left = heff_take_reuse_n(v_x2_24161, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24161_24Left, TAG_Left, 1, (V[]){v_e_24162});
  }
  case TAG_Right: {
    V v_x21_24163 = heff_field(v_x2_24161, 0);
    V v_ru_24x2_24161_24Right = heff_take_reuse_n(v_x2_24161, 1ULL, 1);
    switch (heff_tag_of(v_x21_24163)) {
    case TAG_MkPair: {
      V v_x_24164 = heff_field(v_x21_24163, 0);
      V v_n_24165 = heff_field(v_x21_24163, 1);
      heff_take_n(v_x21_24163, 3ULL, 2);
      switch (heff_tag_of(v_x_24164)) {
      case TAG_MkPair: {
        V v_t_27_24166 = heff_field(v_x_24164, 0);
        heff_take_n(v_x_24164, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24161_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24166, v_n_24165})});
      }
      default: return heff_nomatch(v_x_24164);
      }
    }
    default: return heff_nomatch(v_x21_24163);
    }
  }
  default: return heff_nomatch(v_x2_24161);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32(V self, V *args) {
  V v_n_24169 = args[0];
  heff_drop(v_n_24169);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str22)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33(V self, V *args) {
  V v_n_24170 = args[0];
  V v_t_24171 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24170});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24171});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam35(V self, V *args) {
  V v_u_24191 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24191);
  return v_ty_242;
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam36(V self, V *args) {
  V v_u_24193 = args[0];
  V v_v_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24193);
  return v_v_24192;
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam34(V self, V *args) {
  V v_n_24177 = args[0];
  V v_x_24175 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_body_24176 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_base_24180;
  if (heff_strEq_c(heff_dup(v_x_24175), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str23))) {
    heff_drop(v_x_24175);
    v_base_24180 = ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str24);
  } else {
    if (heff_strEq_c(heff_dup(v_x_24175), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str25))) {
      heff_drop(v_x_24175);
      v_base_24180 = ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str26);
    } else {
      v_base_24180 = v_x_24175;
    }
  }
  V v_t_24181 = heff_strAppend(v_base_24180, heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str27), heff_intShow(heff_dup(v_n_24177))));
  V v_t_24182 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24181, heff_intAdd(v_n_24177, MK_INT(1LL))});
  V v_x2_24183 = heff_tag_n(TAG_Right, 1, (V[]){v_t_24182});
  switch (heff_tag_of(v_x2_24183)) {
  case TAG_Left: {
    V v_e_24184 = heff_field(v_x2_24183, 0);
    V v_ru_24x2_24183_24Left = heff_take_reuse_n(v_x2_24183, 1ULL, 1);
    heff_drop(v_ty_242);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_body_24176);
    return heff_tag_at_n(v_ru_24x2_24183_24Left, TAG_Left, 1, (V[]){v_e_24184});
  }
  case TAG_Right: {
    V v_x21_24185 = heff_field(v_x2_24183, 0);
    V v_ru_24x2_24183_24Right = heff_take_reuse_n(v_x2_24183, 1ULL, 1);
    switch (heff_tag_of(v_x21_24185)) {
    case TAG_MkPair: {
      V v_x_24186 = heff_field(v_x21_24185, 0);
      V v_n_24187 = heff_field(v_x21_24185, 1);
      V v_ru_24x21_24185_24MkPair = heff_take_reuse_n(v_x21_24185, 3ULL, 2);
      V v_t_24188 = heff_tag_at_n(v_ru_24x2_24183_24Right, TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24186)})});
      V v_t_24189 = heff_tag_at_n(v_ru_24x21_24185_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_24188, heff_dup(v_ty_242)}), heff_dup(heff_rfield(v_c_240, 0))});
      V v_t_24190 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
      V v_v_24192 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24190, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam35, 1, 1, (V[]){heff_dup(v_ty_242)}), NTAG(TAG_Nothing)));
      V v_t_24194 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_240, 1), heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam36, 1, 1, (V[]){v_v_24192})});
      V v_t_24195 = heff_intAdd(heff_take_field(v_c_240, 2), MK_INT(1LL));
      V v_c_24196 = ({ V rv_0 = v_t_24189; V rv_1 = v_t_24194; V rv_2 = v_t_24195; V rr_ = heff_rec_reuse_n(v_c_240, 8ULL, 4, shape_locals__env__len__globals); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_m_24197 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_24196, v_body_24176, v_ty_242));
      V v_x2_24198 = heff_tr(heff_apply(v_m_24197, 1, (V[]){v_n_24187}));
      switch (heff_tag_of(v_x2_24198)) {
      case TAG_Left: {
        V v_e_24199 = heff_field(v_x2_24198, 0);
        V v_ru_24x2_24198_24Left = heff_take_reuse_n(v_x2_24198, 1ULL, 1);
        heff_drop(v_x_24186);
        return heff_tag_at_n(v_ru_24x2_24198_24Left, TAG_Left, 1, (V[]){v_e_24199});
      }
      case TAG_Right: {
        V v_x21_24200 = heff_field(v_x2_24198, 0);
        V v_ru_24x2_24198_24Right = heff_take_reuse_n(v_x2_24198, 1ULL, 1);
        switch (heff_tag_of(v_x21_24200)) {
        case TAG_MkPair: {
          V v_x_24201 = heff_field(v_x21_24200, 0);
          V v_n_24202 = heff_field(v_x21_24200, 1);
          V v_ru_24x21_24200_24MkPair = heff_take_reuse_n(v_x21_24200, 3ULL, 2);
          V v_t_24203 = heff_tag_at_n(v_ru_24x21_24200_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24186, v_x_24201}), v_n_24202});
          return heff_tag_at_n(v_ru_24x2_24198_24Right, TAG_Right, 1, (V[]){v_t_24203});
        }
        default: return heff_nomatch(v_x21_24200);
        }
      }
      default: return heff_nomatch(v_x2_24198);
      }
    }
    default: return heff_nomatch(v_x21_24185);
    }
  }
  default: return heff_nomatch(v_x2_24183);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam37(V self, V *args) {
  V v_n_24208 = args[0];
  V v_x_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24209 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24207}), v_n_24208});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24209});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam38(V self, V *args) {
  V v_n_24214 = args[0];
  V v_m_24213 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24215 = heff_tr(heff_apply(v_m_24213, 1, (V[]){v_n_24214}));
  switch (heff_tag_of(v_x2_24215)) {
  case TAG_Left: {
    V v_e_24216 = heff_field(v_x2_24215, 0);
    V v_ru_24x2_24215_24Left = heff_take_reuse_n(v_x2_24215, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24215_24Left, TAG_Left, 1, (V[]){v_e_24216});
  }
  case TAG_Right: {
    V v_x21_24217 = heff_field(v_x2_24215, 0);
    V v_ru_24x2_24215_24Right = heff_take_reuse_n(v_x2_24215, 1ULL, 1);
    switch (heff_tag_of(v_x21_24217)) {
    case TAG_MkPair: {
      V v_x_24218 = heff_field(v_x21_24217, 0);
      V v_n_24219 = heff_field(v_x21_24217, 1);
      heff_take_n(v_x21_24217, 3ULL, 2);
      switch (heff_tag_of(v_x_24218)) {
      case TAG_MkPair: {
        V v_t_27_24220 = heff_field(v_x_24218, 0);
        heff_take_n(v_x_24218, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24215_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24220, v_n_24219})});
      }
      default: return heff_nomatch(v_x_24218);
      }
    }
    default: return heff_nomatch(v_x21_24217);
    }
  }
  default: return heff_nomatch(v_x2_24215);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam39(V self, V *args) {
  V v_n_24224 = args[0];
  V v_m_24223 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24225 = heff_tr(heff_apply(v_m_24223, 1, (V[]){v_n_24224}));
  switch (heff_tag_of(v_x2_24225)) {
  case TAG_Left: {
    V v_e_24226 = heff_field(v_x2_24225, 0);
    V v_ru_24x2_24225_24Left = heff_take_reuse_n(v_x2_24225, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24225_24Left, TAG_Left, 1, (V[]){v_e_24226});
  }
  case TAG_Right: {
    V v_x21_24227 = heff_field(v_x2_24225, 0);
    V v_ru_24x2_24225_24Right = heff_take_reuse_n(v_x2_24225, 1ULL, 1);
    switch (heff_tag_of(v_x21_24227)) {
    case TAG_MkPair: {
      V v_x_24228 = heff_field(v_x21_24227, 0);
      V v_n_24229 = heff_field(v_x21_24227, 1);
      heff_take_n(v_x21_24227, 3ULL, 2);
      switch (heff_tag_of(v_x_24228)) {
      case TAG_MkPair: {
        V v_t_27_24230 = heff_field(v_x_24228, 0);
        heff_take_n(v_x_24228, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24225_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24230, v_n_24229})});
      }
      default: return heff_nomatch(v_x_24228);
      }
    }
    default: return heff_nomatch(v_x21_24227);
    }
  }
  default: return heff_nomatch(v_x2_24225);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam40(V self, V *args) {
  V v_n_24234 = args[0];
  V v_m_24233 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24235 = heff_tr(heff_apply(v_m_24233, 1, (V[]){v_n_24234}));
  switch (heff_tag_of(v_x2_24235)) {
  case TAG_Left: {
    V v_e_24236 = heff_field(v_x2_24235, 0);
    V v_ru_24x2_24235_24Left = heff_take_reuse_n(v_x2_24235, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24235_24Left, TAG_Left, 1, (V[]){v_e_24236});
  }
  case TAG_Right: {
    V v_x21_24237 = heff_field(v_x2_24235, 0);
    V v_ru_24x2_24235_24Right = heff_take_reuse_n(v_x2_24235, 1ULL, 1);
    switch (heff_tag_of(v_x21_24237)) {
    case TAG_MkPair: {
      V v_x_24238 = heff_field(v_x21_24237, 0);
      V v_n_24239 = heff_field(v_x21_24237, 1);
      heff_take_n(v_x21_24237, 3ULL, 2);
      switch (heff_tag_of(v_x_24238)) {
      case TAG_MkPair: {
        V v_t_27_24240 = heff_field(v_x_24238, 0);
        heff_take_n(v_x_24238, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24235_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24240, v_n_24239})});
      }
      default: return heff_nomatch(v_x_24238);
      }
    }
    default: return heff_nomatch(v_x21_24237);
    }
  }
  default: return heff_nomatch(v_x2_24235);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam41(V self, V *args) {
  V v_n_24244 = args[0];
  V v_m_24243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24245 = heff_tr(heff_apply(v_m_24243, 1, (V[]){v_n_24244}));
  switch (heff_tag_of(v_x2_24245)) {
  case TAG_Left: {
    V v_e_24246 = heff_field(v_x2_24245, 0);
    V v_ru_24x2_24245_24Left = heff_take_reuse_n(v_x2_24245, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24245_24Left, TAG_Left, 1, (V[]){v_e_24246});
  }
  case TAG_Right: {
    V v_x21_24247 = heff_field(v_x2_24245, 0);
    V v_ru_24x2_24245_24Right = heff_take_reuse_n(v_x2_24245, 1ULL, 1);
    switch (heff_tag_of(v_x21_24247)) {
    case TAG_MkPair: {
      V v_x_24248 = heff_field(v_x21_24247, 0);
      V v_n_24249 = heff_field(v_x21_24247, 1);
      heff_take_n(v_x21_24247, 3ULL, 2);
      switch (heff_tag_of(v_x_24248)) {
      case TAG_MkPair: {
        V v_t_27_24250 = heff_field(v_x_24248, 0);
        heff_take_n(v_x_24248, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24245_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24250, v_n_24249})});
      }
      default: return heff_nomatch(v_x_24248);
      }
    }
    default: return heff_nomatch(v_x21_24247);
    }
  }
  default: return heff_nomatch(v_x2_24245);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam42(V self, V *args) {
  V v_n_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24255 = heff_tr(heff_apply(v_m_24253, 1, (V[]){v_n_24254}));
  switch (heff_tag_of(v_x2_24255)) {
  case TAG_Left: {
    V v_e_24256 = heff_field(v_x2_24255, 0);
    V v_ru_24x2_24255_24Left = heff_take_reuse_n(v_x2_24255, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24255_24Left, TAG_Left, 1, (V[]){v_e_24256});
  }
  case TAG_Right: {
    V v_x21_24257 = heff_field(v_x2_24255, 0);
    V v_ru_24x2_24255_24Right = heff_take_reuse_n(v_x2_24255, 1ULL, 1);
    switch (heff_tag_of(v_x21_24257)) {
    case TAG_MkPair: {
      V v_x_24258 = heff_field(v_x21_24257, 0);
      V v_n_24259 = heff_field(v_x21_24257, 1);
      heff_take_n(v_x21_24257, 3ULL, 2);
      switch (heff_tag_of(v_x_24258)) {
      case TAG_MkPair: {
        V v_t_27_24260 = heff_field(v_x_24258, 0);
        heff_take_n(v_x_24258, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24255_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24260, v_n_24259})});
      }
      default: return heff_nomatch(v_x_24258);
      }
    }
    default: return heff_nomatch(v_x21_24257);
    }
  }
  default: return heff_nomatch(v_x2_24255);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam43(V self, V *args) {
  V v_n_24265 = args[0];
  V v_m_24264 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24266 = heff_tr(heff_apply(v_m_24264, 1, (V[]){v_n_24265}));
  switch (heff_tag_of(v_x2_24266)) {
  case TAG_Left: {
    V v_e_24267 = heff_field(v_x2_24266, 0);
    V v_ru_24x2_24266_24Left = heff_take_reuse_n(v_x2_24266, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24266_24Left, TAG_Left, 1, (V[]){v_e_24267});
  }
  case TAG_Right: {
    V v_x21_24268 = heff_field(v_x2_24266, 0);
    V v_ru_24x2_24266_24Right = heff_take_reuse_n(v_x2_24266, 1ULL, 1);
    switch (heff_tag_of(v_x21_24268)) {
    case TAG_MkPair: {
      V v_x_24269 = heff_field(v_x21_24268, 0);
      V v_n_24270 = heff_field(v_x21_24268, 1);
      heff_take_n(v_x21_24268, 3ULL, 2);
      switch (heff_tag_of(v_x_24269)) {
      case TAG_MkPair: {
        V v_t_27_24271 = heff_field(v_x_24269, 0);
        heff_take_n(v_x_24269, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24266_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24271, v_n_24270})});
      }
      default: return heff_nomatch(v_x_24269);
      }
    }
    default: return heff_nomatch(v_x21_24268);
    }
  }
  default: return heff_nomatch(v_x2_24266);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam44(V self, V *args) {
  V v_n_24275 = args[0];
  V v_m_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24276 = heff_tr(heff_apply(v_m_24274, 1, (V[]){v_n_24275}));
  switch (heff_tag_of(v_x2_24276)) {
  case TAG_Left: {
    V v_e_24277 = heff_field(v_x2_24276, 0);
    V v_ru_24x2_24276_24Left = heff_take_reuse_n(v_x2_24276, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24276_24Left, TAG_Left, 1, (V[]){v_e_24277});
  }
  case TAG_Right: {
    V v_x21_24278 = heff_field(v_x2_24276, 0);
    V v_ru_24x2_24276_24Right = heff_take_reuse_n(v_x2_24276, 1ULL, 1);
    switch (heff_tag_of(v_x21_24278)) {
    case TAG_MkPair: {
      V v_x_24279 = heff_field(v_x21_24278, 0);
      V v_n_24280 = heff_field(v_x21_24278, 1);
      heff_take_n(v_x21_24278, 3ULL, 2);
      switch (heff_tag_of(v_x_24279)) {
      case TAG_MkPair: {
        V v_t_27_24281 = heff_field(v_x_24279, 0);
        heff_take_n(v_x_24279, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24276_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24281, v_n_24280})});
      }
      default: return heff_nomatch(v_x_24279);
      }
    }
    default: return heff_nomatch(v_x21_24278);
    }
  }
  default: return heff_nomatch(v_x2_24276);
  }
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V v_c_240, V v_ty_241, V v_v_242, V v_fs_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkPair: {
    V v_l_245 = heff_field(v_x6_244, 0);
    V v_fe_246 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    V v_m_247 = (g_heff_2ecompile_2eerase_2eprojTyInWith(heff_dup(heff_rfield(v_c_240, 2)), v_ty_241, heff_dup(v_fs_243), heff_dup(v_l_245)));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0, 1, 6, (V[]){v_m_247, v_c_240, v_fs_243, v_v_242, v_l_245, v_fe_246});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fs_243 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_l_245 = heff_env(self)[4];
  V v_fe_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x2_249 = heff_tr(heff_apply(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Left = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fs_243);
    heff_drop(v_v_242);
    heff_drop(v_l_245);
    heff_drop(v_fe_246);
    return heff_tag_at_n(v_ru_24x2_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24Right = heff_take_reuse_n(v_x2_249, 1ULL, 1);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x21_2411, 0);
      V v_n_2413 = heff_field(v_x21_2411, 1);
      V v_ru_24x21_2411_24MkPair = heff_take_reuse_n(v_x21_2411, 3ULL, 2);
      V v_t_2414 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_x_2412)));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        heff_drop_rec(v_c_240, 4);
        heff_drop(v_fs_243);
        heff_drop(v_v_242);
        heff_drop(v_l_245);
        heff_drop(v_fe_246);
        heff_drop(v_x_2412);
        V v_t_2415 = heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_2413});
        return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Right, 1, (V[]){v_t_2415});
      }
      case TAG_False: {
        V v_x1_2416 = ({ V a_0 = v_fs_243; V a_1 = v_v_242; V a_2 = heff_dup(v_l_245); V r_ = (g_heff_2ecompile_2eerase_2eprojWith(a_0, a_1, a_2)); heff_drop(v_fs_243); r_; });
        V v_v_2420;
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nom: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2417;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2416, 0ULL, 1);
          v_v_2420 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2419 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 1);
          v_v_2420 = v_x_2419;
          break;
        }
        default: heff_nomatch(v_x1_2416);
        }
        V v_m_2421 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(v_c_240, v_fe_246, v_x_2412, v_v_2420));
        V v_x2_2422 = heff_tr(heff_apply(v_m_2421, 1, (V[]){v_n_2413}));
        switch (heff_tag_of(v_x2_2422)) {
        case TAG_Left: {
          V v_e_2423 = heff_field(v_x2_2422, 0);
          heff_take_n(v_x2_2422, 1ULL, 1);
          heff_drop(v_l_245);
          heff_drop_cell(v_ru_24x21_2411_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Left, 1, (V[]){v_e_2423});
        }
        case TAG_Right: {
          V v_x21_2424 = heff_field(v_x2_2422, 0);
          V v_ru_24x2_2422_24Right = heff_take_reuse_n(v_x2_2422, 1ULL, 1);
          switch (heff_tag_of(v_x21_2424)) {
          case TAG_MkPair: {
            V v_x_2425 = heff_field(v_x21_2424, 0);
            V v_n_2426 = heff_field(v_x21_2424, 1);
            heff_take_n(v_x21_2424, 3ULL, 2);
            V v_t_2427 = heff_tag_at_n(v_ru_24x2_249_24Right, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_x_2425})});
            return heff_tag_at_n(v_ru_24x2_2422_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x21_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2427, v_n_2426})});
          }
          default: return heff_nomatch(v_x21_2424);
          }
        }
        default: return heff_nomatch(v_x2_2422);
        }
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244) {
top: ;
  V v_m_246 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0, 1, 4, (V[]){v_c_240, v_ty_241, v_v_242, v_fs_244}), v_ps_243));
  return heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1, 1, 1, (V[]){v_m_246});
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ty_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_fs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(v_c_240, v_ty_241, v_v_242, v_fs_244, v_p_245));
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_apply(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_x_2413 = heff_tag_at_n(v_ru_24x2_248_24Right, TAG_ERecord, 1, (V[]){(g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_2411))});
      return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_MkPair, 2, (V[]){v_x_2413, v_n_2412})});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str0, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str2, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str3, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str4, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str5, 1, "$");
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam12(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam11(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry, 4, 0};

V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(V v_c_240, V v_t_241, V v_ty_242, V v_v_243) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SGlobal: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SCode: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SApp: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLam: {
    V v_abs_2410 = heff_dup(heff_field(v_t_241, 1));
    V v_t_2411 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      V v_dom_2414 = heff_field(v_t_2411, 1);
      V v_cod_2415 = heff_field(v_t_2411, 2);
      heff_take_n(v_t_2411, 6ULL, 4);
      heff_drop_tag(v_t_241, 2);
      heff_drop(v_ty_242);
      V v_it_2422;
      switch (heff_tag_of(v_abs_2410)) {
      case TAG_MkAbs: {
        V v_n_2417 = heff_field(v_abs_2410, 0);
        V v_b_2418 = heff_field(v_abs_2410, 1);
        V v_ru_24abs_2410_24MkAbs = heff_take_reuse_n(v_abs_2410, 3ULL, 2);
        V v_t_2419 = heff_tag_at_n(v_ru_24abs_2410_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2417, NTAG(TAG_True)});
        v_it_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2419, v_b_2418});
        break;
      }
      case TAG_AbsConst: {
        V v_b_2420 = heff_field(v_abs_2410, 0);
        heff_take_n(v_abs_2410, 1ULL, 1);
        V v_t_2421 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str0), NTAG(TAG_False)});
        v_it_2422 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2421, v_b_2420});
        break;
      }
      default: heff_nomatch(v_abs_2410);
      }
      switch (heff_tag_of(v_it_2422)) {
      case TAG_MkPair: {
        V v_it1_2423 = heff_field(v_it_2422, 0);
        V v_body_2424 = heff_field(v_it_2422, 1);
        V v_ru_24it_2422_24MkPair = heff_take_reuse_n(v_it_2422, 3ULL, 2);
        switch (heff_tag_of(v_it1_2423)) {
        case TAG_MkPair: {
          V v_hint_2425 = heff_field(v_it1_2423, 0);
          V v_bound_2426 = heff_field(v_it1_2423, 1);
          V v_ru_24it1_2423_24MkPair = heff_take_reuse_n(v_it1_2423, 3ULL, 2);
          V v_t_2427 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_dom_2414)));
          switch (heff_tag_of(v_t_2427)) {
          case TAG_True: {
            heff_drop(v_hint_2425);
            V v_c_2436;
            switch (heff_tag_of(v_bound_2426)) {
            case TAG_True: {
              V v_t_2428 = heff_rec_n(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_2414)});
              V v_t_2429 = heff_tag_at_n(v_ru_24it_2422_24MkPair, TAG_Cons, 2, (V[]){v_t_2428, heff_dup(heff_rfield(v_c_240, 0))});
              V v_t_2430 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
              V v_v_2432 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2430, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
              V v_t_2434 = heff_tag_at_n(v_ru_24it1_2423_24MkPair, TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1, 1, 1, (V[]){v_v_2432})});
              V v_t_2435 = heff_intAdd(heff_dup(heff_rfield(v_c_240, 2)), MK_INT(1LL));
              v_c_2436 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2429, v_t_2434, v_t_2435, heff_dup(heff_rfield(v_c_240, 3))});
              break;
            }
            case TAG_False: {
              heff_drop_cell(v_ru_24it_2422_24MkPair, 2);
              heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
              v_c_2436 = heff_dup(v_c_240);
              break;
            }
            default: heff_nomatch(v_bound_2426);
            }
            V v_x1_2444;
            switch (heff_tag_of(v_cod_2415)) {
            case TAG_MkClo: {
              V v_vs_2438 = heff_field(v_cod_2415, 1);
              V v_body_2439 = heff_field(v_cod_2415, 2);
              heff_take_n(v_cod_2415, 6ULL, 3);
              v_x1_2444 = heff_tr(heff_apply(v_body_2439, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2438, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2443 = heff_field(v_cod_2415, 0);
              heff_take_n(v_cod_2415, 1ULL, 1);
              v_x1_2444 = v_body_2443;
              break;
            }
            default: heff_nomatch(v_cod_2415);
            }
            V v_ty_2448;
            switch (heff_tag_of(v_x1_2444)) {
            case TAG_Nom: {
              V v_x_2445 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2445;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2444, 0ULL, 1);
              v_ty_2448 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2447 = heff_field(v_x1_2444, 0);
              heff_take_n(v_x1_2444, 1ULL, 1);
              v_ty_2448 = v_x_2447;
              break;
            }
            default: heff_nomatch(v_x1_2444);
            }
            V v_x1_2452 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_v_243, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4, 1, 2, (V[]){v_c_240, v_dom_2414})));
            V v_v_2456;
            switch (heff_tag_of(v_x1_2452)) {
            case TAG_Nom: {
              V v_x_2453 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2453;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2452, 0ULL, 1);
              v_v_2456 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2455 = heff_field(v_x1_2452, 0);
              heff_take_n(v_x1_2452, 1ULL, 1);
              v_v_2456 = v_x_2455;
              break;
            }
            default: heff_nomatch(v_x1_2452);
            }
            V t_0 = v_c_2436;
            V t_1 = v_body_2424;
            V t_2 = v_ty_2448;
            V t_3 = v_v_2456;
            v_c_240 = t_0;
            v_t_241 = t_1;
            v_ty_242 = t_2;
            v_v_243 = t_3;
            goto top;
          }
          case TAG_False: {
            heff_drop_cell(v_ru_24it_2422_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2423_24MkPair, 2);
            return heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6, 1, 7, (V[]){v_hint_2425, v_bound_2426, v_dom_2414, v_c_240, v_cod_2415, v_v_243, v_body_2424});
          }
          default: return heff_nomatch(v_t_2427);
          }
        }
        default: return heff_nomatch(v_it1_2423);
        }
      }
      default: return heff_nomatch(v_it_2422);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2411, 0ULL, 3);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRune: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2411, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop(v_abs_2410);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_SCons: {
    V v_d_24111 = heff_dup(heff_field(v_t_241, 0));
    V v_t_24112 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_ty_242)));
    switch (heff_tag_of(v_t_24112)) {
    case TAG_LikeU: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_24112, 0ULL, 4);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_24112, 0ULL, 3);
      heff_drop_tag(v_t_241, 1);
      V v_t_24121 = heff_arrayToList(heff_take_field(v_d_24111, 0));
      V v_t_24122 = heff_arrayToList(heff_get_n(v_d_24111, 2, 3));
      V v_t_24123 = (g_heff_2eutil_2edict_2ezipKV(v_t_24121, v_t_24122));
      V v_t_24124 = (g_heff_2eelab_2evalue_2ecoerceToFieldsMaybe(heff_dup(v_v_243)));
      return (g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(v_c_240, v_ty_242, v_v_243, v_t_24123, v_t_24124));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeInt: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFloat: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeString: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeRune: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_24112, 0ULL, 1);
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    case TAG_NoRules: {
      heff_drop(v_v_243);
      heff_drop_rec(v_d_24111, 3);
      return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
    }
    default: return heff_nomatch(v_t_24112);
    }
  }
  case TAG_SProj: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_STag: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMatch: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SSpecialize: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SIs: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SOpaque: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SAbandon: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SRec: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SFix: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SImplicit: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SPrim: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SMetaApp: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitInt: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitString: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitRune: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFixed: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  case TAG_SLitFloat32: {
    heff_drop(v_v_243);
    return (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_240, v_t_241, v_ty_242));
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam0(V self, V *args) {
  V v_u_2431 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2431);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  V v_v_2432 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2433);
  return v_v_2432;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3(V self, V *args) {
  V v_u_2442 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2442);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2440);
  V v_t_2441 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2441, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam3, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5(V self, V *args) {
  V v_u_2451 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2451);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam4(V self, V *args) {
  V v_u_2449 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2449);
  V v_t_2450 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2450, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam5, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7(V self, V *args) {
  V v_u_2471 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2471);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8(V self, V *args) {
  V v_u_2473 = args[0];
  V v_v_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2473);
  return v_v_2472;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10(V self, V *args) {
  V v_u_2482 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2482);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9(V self, V *args) {
  V v_u_2480 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2480);
  V v_t_2481 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2481, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam10, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam12(V self, V *args) {
  V v_u_2491 = args[0];
  V v_dom_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2491);
  return v_dom_2414;
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam11(V self, V *args) {
  V v_u_2489 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_dom_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2489);
  V v_t_2490 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_240, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2490, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam12, 1, 1, (V[]){v_dom_2414}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam6(V self, V *args) {
  V v_n_2457 = args[0];
  V v_hint_2425 = heff_env(self)[0];
  V v_bound_2426 = heff_env(self)[1];
  V v_dom_2414 = heff_env(self)[2];
  V v_c_240 = heff_env(self)[3];
  V v_cod_2415 = heff_env(self)[4];
  V v_v_243 = heff_env(self)[5];
  V v_body_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_base_2460;
  if (heff_strEq_c(heff_dup(v_hint_2425), ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str1))) {
    heff_drop(v_hint_2425);
    v_base_2460 = ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str2);
  } else {
    if (heff_strEq_c(heff_dup(v_hint_2425), ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str3))) {
      heff_drop(v_hint_2425);
      v_base_2460 = ((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str4);
    } else {
      v_base_2460 = v_hint_2425;
    }
  }
  V v_t_2461 = heff_strAppend(v_base_2460, heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_str5), heff_intShow(heff_dup(v_n_2457))));
  V v_t_2462 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2461, heff_intAdd(v_n_2457, MK_INT(1LL))});
  V v_x2_2463 = heff_tag_n(TAG_Right, 1, (V[]){v_t_2462});
  switch (heff_tag_of(v_x2_2463)) {
  case TAG_Left: {
    V v_e_2464 = heff_field(v_x2_2463, 0);
    V v_ru_24x2_2463_24Left = heff_take_reuse_n(v_x2_2463, 1ULL, 1);
    heff_drop(v_bound_2426);
    heff_drop(v_dom_2414);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_cod_2415);
    heff_drop(v_v_243);
    heff_drop(v_body_2424);
    return heff_tag_at_n(v_ru_24x2_2463_24Left, TAG_Left, 1, (V[]){v_e_2464});
  }
  case TAG_Right: {
    V v_x21_2465 = heff_field(v_x2_2463, 0);
    V v_ru_24x2_2463_24Right = heff_take_reuse_n(v_x2_2463, 1ULL, 1);
    switch (heff_tag_of(v_x21_2465)) {
    case TAG_MkPair: {
      V v_x_2466 = heff_field(v_x21_2465, 0);
      V v_n_2467 = heff_field(v_x21_2465, 1);
      V v_ru_24x21_2465_24MkPair = heff_take_reuse_n(v_x21_2465, 3ULL, 2);
      V v_c_2476;
      switch (heff_tag_of(v_bound_2426)) {
      case TAG_True: {
        V v_t_2468 = heff_tag_at_n(v_ru_24x2_2463_24Right, TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2466)})});
        V v_t_2469 = heff_tag_at_n(v_ru_24x21_2465_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2468, heff_dup(v_dom_2414)}), heff_dup(heff_rfield(v_c_240, 0))});
        V v_t_2470 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
        V v_v_2472 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2470, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam7, 1, 1, (V[]){heff_dup(v_dom_2414)}), NTAG(TAG_Nothing)));
        V v_t_2474 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_240, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam8, 1, 1, (V[]){v_v_2472})});
        V v_t_2475 = heff_intAdd(heff_dup(heff_rfield(v_c_240, 2)), MK_INT(1LL));
        v_c_2476 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2469, v_t_2474, v_t_2475, heff_dup(heff_rfield(v_c_240, 3))});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x2_2463_24Right, 1);
        heff_drop_cell(v_ru_24x21_2465_24MkPair, 2);
        v_c_2476 = heff_dup(v_c_240);
        break;
      }
      default: heff_nomatch(v_bound_2426);
      }
      V v_x1_2484;
      switch (heff_tag_of(v_cod_2415)) {
      case TAG_MkClo: {
        V v_vs_2478 = heff_field(v_cod_2415, 1);
        V v_body_2479 = heff_field(v_cod_2415, 2);
        heff_take_n(v_cod_2415, 6ULL, 3);
        v_x1_2484 = heff_tr(heff_apply(v_body_2479, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2478, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam9, 1, 2, (V[]){heff_dup(v_c_240), heff_dup(v_dom_2414)})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2483 = heff_field(v_cod_2415, 0);
        heff_take_n(v_cod_2415, 1ULL, 1);
        v_x1_2484 = v_body_2483;
        break;
      }
      default: heff_nomatch(v_cod_2415);
      }
      V v_ty_2488;
      switch (heff_tag_of(v_x1_2484)) {
      case TAG_Nom: {
        V v_x_2485 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        v_ty_2488 = v_x_2485;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2484, 0ULL, 1);
        v_ty_2488 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2487 = heff_field(v_x1_2484, 0);
        heff_take_n(v_x1_2484, 1ULL, 1);
        v_ty_2488 = v_x_2487;
        break;
      }
      default: heff_nomatch(v_x1_2484);
      }
      V v_x1_2492 = heff_tr(g_heff_2eelab_2evalue_2eapp(v_v_243, heff_clo_n(g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835_lam11, 1, 2, (V[]){v_c_240, v_dom_2414})));
      V v_v_2496;
      switch (heff_tag_of(v_x1_2492)) {
      case TAG_Nom: {
        V v_x_2493 = heff_field(v_x1_2492, 0);
        heff_take_n(v_x1_2492, 1ULL, 1);
        v_v_2496 = v_x_2493;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2492, 0ULL, 1);
        v_v_2496 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2495 = heff_field(v_x1_2492, 0);
        heff_take_n(v_x1_2492, 1ULL, 1);
        v_v_2496 = v_x_2495;
        break;
      }
      default: heff_nomatch(v_x1_2492);
      }
      V v_m_2497 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(v_c_2476, v_body_2424, v_ty_2488, v_v_2496));
      V v_x2_2498 = heff_tr(heff_apply(v_m_2497, 1, (V[]){v_n_2467}));
      switch (heff_tag_of(v_x2_2498)) {
      case TAG_Left: {
        V v_e_2499 = heff_field(v_x2_2498, 0);
        V v_ru_24x2_2498_24Left = heff_take_reuse_n(v_x2_2498, 1ULL, 1);
        heff_drop(v_x_2466);
        return heff_tag_at_n(v_ru_24x2_2498_24Left, TAG_Left, 1, (V[]){v_e_2499});
      }
      case TAG_Right: {
        V v_x21_24100 = heff_field(v_x2_2498, 0);
        V v_ru_24x2_2498_24Right = heff_take_reuse_n(v_x2_2498, 1ULL, 1);
        switch (heff_tag_of(v_x21_24100)) {
        case TAG_MkPair: {
          V v_x_24101 = heff_field(v_x21_24100, 0);
          V v_n_24102 = heff_field(v_x21_24100, 1);
          V v_ru_24x21_24100_24MkPair = heff_take_reuse_n(v_x21_24100, 3ULL, 2);
          V v_t_24103 = heff_tag_at_n(v_ru_24x21_24100_24MkPair, TAG_Cons, 2, (V[]){v_x_2466, NTAG(TAG_Nil)});
          V v_t_24104 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_24103, v_x_24101}), v_n_24102});
          return heff_tag_at_n(v_ru_24x2_2498_24Right, TAG_Right, 1, (V[]){v_t_24104});
        }
        default: return heff_nomatch(v_x21_24100);
        }
      }
      default: return heff_nomatch(v_x2_2498);
      }
    }
    default: return heff_nomatch(v_x21_2465);
    }
  }
  default: return heff_nomatch(v_x2_2463);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eeraseOne_str0, 2, ": ");
V g_heff_2ecompile_2eerase_2eeraseOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eeraseOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eeraseOne_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eeraseOne(V v_g_240, V v_acc_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_key_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_244, 3))));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_g_240);
      heff_drop(v_key_243);
      heff_drop_rec(v_e_244, 4);
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      return v_acc_241;
    }
    case TAG_False: {
      V v_t_246 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EGlobal, 1, (V[]){heff_dup(v_key_243)})});
      V v_t_247 = heff_rec_n(2, shape_ir__ty, (V[]){v_t_246, heff_dup(heff_rfield(v_e_244, 3))});
      V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
      V v_t_2410 = heff_tag_n(TAG_LSnoc, 2, (V[]){NTAG(TAG_LNil), heff_clo_n(g_heff_2ecompile_2eerase_2eeraseOne_lam0, 1, 1, (V[]){heff_dup(v_e_244)})});
      V v_t_2411 = (g_heff_2ecompile_2eerase_2echkDF_24s135535636x524183835(heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_248, v_t_2410, MK_INT(1LL), v_g_240}), heff_take_field(v_e_244, 0), heff_take_field(v_e_244, 3), heff_get_n(v_e_244, 2, 4)));
      V v_it_2412 = heff_tr(heff_apply(v_t_2411, 1, (V[]){heff_dup(heff_rfield(v_acc_241, 2))}));
      switch (heff_tag_of(v_it_2412)) {
      case TAG_Left: {
        V v_err_2413 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        V v_t_2414 = heff_strAppend(v_key_243, heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eeraseOne_str0), v_err_2413));
        V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_acc_241, 1)});
        return ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_n(v_acc_241, 5ULL, 3, shape_defs__errors__supply); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_Right: {
        V v_it1_2416 = heff_field(v_it_2412, 0);
        heff_take_n(v_it_2412, 1ULL, 1);
        switch (heff_tag_of(v_it1_2416)) {
        case TAG_MkPair: {
          V v_body_2417 = heff_field(v_it1_2416, 0);
          V v_n_2418 = heff_field(v_it1_2416, 1);
          V v_ru_24it1_2416_24MkPair = heff_take_reuse_n(v_it1_2416, 3ULL, 2);
          V v_t_2419 = heff_tag_at_n(v_ru_24it1_2416_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_243), v_key_243, v_body_2417}), heff_dup(heff_rfield(v_acc_241, 0))});
          return ({ V rv_0 = v_t_2419; V rv_2 = v_n_2418; V rr_ = heff_rec_reuse_n(v_acc_241, 2ULL, 3, shape_defs__errors__supply); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_it1_2416);
        }
      }
      default: return heff_nomatch(v_it_2412);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eerase_2eeraseOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eeraseOne(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eeraseOne_lam0(V self, V *args) {
  V v_u_249 = args[0];
  V v_e_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  return heff_get_n(v_e_244, 2, 4);
}
V g_heff_2ecompile_2eerase_2eeraseProgram_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eeraseProgram_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eeraseProgram_entry, 1, 0};

V g_heff_2ecompile_2eerase_2eeraseProgram(V v_g_240) {
top: ;
  V v_t_241 = heff_rec_n(3, shape_defs__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_246 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
  V v_acc_249 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_lam1, 2, 1, (V[]){v_g_240}); V a_1 = v_t_241; V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_249, 0)));
  V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_249, 1)));
  return ({ V rv_0 = v_t_2410; V rv_1 = v_t_2411; V rr_ = heff_rec_reuse_n(v_acc_249, 4ULL, 3, shape_defs__errors__supply); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
}
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eeraseProgram(a[0]);
}
V g_heff_2ecompile_2eerase_2eeraseProgram_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get_n(v_g_240, 1, 6); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_lam1(V self, V *args) {
  V v_acc_247 = args[0];
  V v_p_248 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2eeraseOne(v_g_240, v_acc_247, v_p_248));
}