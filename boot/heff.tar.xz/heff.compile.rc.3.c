// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ASts 62476
#define TAG_ATail 47533
#define TAG_CIf 14188
#define TAG_CLet 49341
#define TAG_CSwitch 58071
#define TAG_CondBool 38021
#define TAG_CondFalse 62555
#define TAG_CondIf 43756
#define TAG_CondLet 48585
#define TAG_CondNot 50817
#define TAG_CondTrue 53113
#define TAG_DFun 8330
#define TAG_DVal 23084
#define TAG_Given 9359
#define TAG_GivenU 27811
#define TAG_IOp 20150
#define TAG_LentValue 25634
#define TAG_LentVar 46882
#define TAG_PBool 10446
#define TAG_PFalse 59568
#define TAG_PIf 26681
#define TAG_PLet 43468
#define TAG_PNot 45700
#define TAG_PRel 49226
#define TAG_PTrue 25538
#define TAG_RDupE 22574
#define TAG_RField 17425
#define TAG_RFieldU 15753
#define TAG_RFieldV 15755
#define TAG_RGetLabel 32676
#define TAG_RGetN 31178
#define TAG_RGetNU 48940
#define TAG_RGetRaw 14078
#define TAG_RLocal 34280
#define TAG_RPeek 36757
#define TAG_RTakeField 8926
#define TAG_RUnbox 59387
#define TAG_RepF64 57686
#define TAG_RepFix 59335
#define TAG_RepV 61860
#define TAG_SBytes 19273
#define TAG_SFixed 29756
#define TAG_SFloat 44846
#define TAG_SFloat32 38487
#define TAG_SGlobal 8650
#define TAG_SInt 64711
#define TAG_SLam 1658
#define TAG_SPrim 55533
#define TAG_SPrimFn 21761
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SStr 8979
#define TAG_STag 9340
#define TAG_SVar 11273
#define TAG_TCase 51528
#define TAG_TIf 30525
#define TAG_TLoop 5358
#define TAG_TReturn 24484
#define TAG_TSeq 38304
#define LBL_after 294093302
#define LBL_body 9524841
#define LBL_bor 307263
#define LBL_borrowed 695465691
#define LBL_bounce 563936691
#define LBL_entry 298026124
#define LBL_funs 9650075
#define LBL_key 315609
#define LBL_known 303562589
#define LBL_lam 316434
#define LBL_lent 9813446
#define LBL_owned 307523263
#define LBL_params 951713969
#define LBL_reprs 309759928
#define LBL_result 1012715336
#define LBL_ret 322331
#define LBL_self 10021907
#define LBL_sigs 10025609
#define LBL_takes 311482598
#define LBL_wrapper 1827365593
static uint32_t shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret[] = {LBL_funs, LBL_bounce, LBL_self, LBL_lam, LBL_owned, LBL_after, LBL_borrowed, LBL_bor, LBL_known, LBL_takes, LBL_reprs, LBL_sigs, LBL_ret};
static uint32_t shape_key__params[] = {LBL_key, LBL_params};
static uint32_t shape_key__params__lent__entry__body__reprs__ret__wrapper[] = {LBL_key, LBL_params, LBL_lent, LBL_entry, LBL_body, LBL_reprs, LBL_ret, LBL_wrapper};
V g_heff_2ecompile_2eborrow_2eelemI(V, V);
V g_heff_2ecompile_2eborrow_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eborrow_2eelemI_clo;
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(V, V);
V g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174_clo;
V g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863_clo;
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272(V, V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_clo;
V g_heff_2ecompile_2erc_2eboolName_get(void);
V g_heff_2ecompile_2erc_2ecoerce(V, V, V);
V g_heff_2ecompile_2erc_2ecoerce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecoerce_clo;
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(V, V, V, V);
V g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500_clo;
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(V, V);
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_clo;
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(V, V);
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_clo;
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps(V, V, V, V);
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_clo;
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_clo;
V g_heff_2ecompile_2erc_2edropOf(V, V);
V g_heff_2ecompile_2erc_2edropOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2edropOf_clo;
V g_heff_2ecompile_2erc_2edropsOf(V, V);
V g_heff_2ecompile_2erc_2edropsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2edropsOf_clo;
V g_heff_2ecompile_2erc_2eelemI(V, V);
V g_heff_2ecompile_2erc_2eelemI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemI_clo;
V g_heff_2ecompile_2erc_2eelemS(V, V);
V g_heff_2ecompile_2erc_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eelemS_clo;
V g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112_clo;
V g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_clo;
V g_heff_2ecompile_2erc_2efieldLentOf(V, V, V, V);
V g_heff_2ecompile_2erc_2efieldLentOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldLentOf_clo;
V g_heff_2ecompile_2erc_2efieldMask(V, V, V);
V g_heff_2ecompile_2erc_2efieldMask_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldMask_clo;
V g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129_clo;
V g_heff_2ecompile_2erc_2efreeGo(V, V, V, V);
V g_heff_2ecompile_2erc_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efreeGo_clo;
V g_heff_2ecompile_2erc_2efunWith(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2efunWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efunWith_clo;
V g_heff_2ecompile_2erc_2efvOp(V);
V g_heff_2ecompile_2erc_2efvOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvOp_clo;
V g_heff_2ecompile_2erc_2efvSts(V);
V g_heff_2ecompile_2erc_2efvSts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvSts_clo;
V g_heff_2ecompile_2erc_2efvTl(V);
V g_heff_2ecompile_2erc_2efvTl_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvTl_clo;
V g_heff_2ecompile_2erc_2efvW(V, V, V);
V g_heff_2ecompile_2erc_2efvW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2efvW_clo;
V g_heff_2ecompile_2erc_2eindexIn(V, V, V);
V g_heff_2ecompile_2erc_2eindexIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eindexIn_clo;
V g_heff_2ecompile_2erc_2ejustsOf_24dps(V, V);
V g_heff_2ecompile_2erc_2ejustsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ejustsOf_24dps_clo;
V g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237(V, V);
V g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_clo;
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938(V, V, V, V);
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_clo;
V g_heff_2ecompile_2erc_2elentField(V, V, V);
V g_heff_2ecompile_2erc_2elentField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentField_clo;
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566_clo;
V g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903(V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_clo;
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004(V, V, V, V);
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_clo;
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_clo;
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps(V, V, V, V, V);
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps_clo;
V g_heff_2ecompile_2erc_2epow2(V);
V g_heff_2ecompile_2erc_2epow2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2epow2_clo;
V g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130(V, V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_clo;
V g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_clo;
V g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(V, V, V, V);
V g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698_clo;
V g_heff_2ecompile_2erc_2ereuseArgs(V, V);
V g_heff_2ecompile_2erc_2ereuseArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseArgs_clo;
V g_heff_2ecompile_2erc_2ereuseOp(V, V, V);
V g_heff_2ecompile_2erc_2ereuseOp_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseOp_clo;
V g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(V, V, V);
V g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609_clo;
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(V, V, V);
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_clo;
V g_heff_2ecompile_2erc_2ereuseV(V, V, V);
V g_heff_2ecompile_2erc_2ereuseV_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ereuseV_clo;
V g_heff_2ecompile_2erc_2eroomFor_get(void);
V g_heff_2ecompile_2erc_2esameAs(V, V, V);
V g_heff_2ecompile_2erc_2esameAs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esameAs_clo;
V g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178(V, V);
V g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178_clo;
V g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_clo;
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_clo;
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(V, V, V);
V g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518_clo;
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(V, V);
V g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315_clo;
V g_heff_2ecompile_2erc_2etakeVarIn(V, V, V, V, V);
V g_heff_2ecompile_2erc_2etakeVarIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etakeVarIn_clo;
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074(V, V, V);
V g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074_clo;
V g_heff_2ecompile_2erc_2eunboxParam(V, V, V);
V g_heff_2ecompile_2erc_2eunboxParam_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eunboxParam_clo;
V g_heff_2ecompile_2erc_2eunboxParams(V, V, V, V);
V g_heff_2ecompile_2erc_2eunboxParams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2eunboxParams_clo;
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(V, V, V, V);
V g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462_clo;
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(V, V, V);
V g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031_clo;
V g_heff_2ecompile_2erc_2evalRc(V, V, V);
V g_heff_2ecompile_2erc_2evalRc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2evalRc_clo;
V g_heff_2ecompile_2erc_2ewithBorrowed(V, V);
V g_heff_2ecompile_2erc_2ewithBorrowed_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewithBorrowed_clo;
V g_heff_2ecompile_2erc_2ewithFrame(V, V, V);
V g_heff_2ecompile_2erc_2ewithFrame_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewithFrame_clo;
V g_heff_2ecompile_2erc_2ewithKnown(V, V, V);
V g_heff_2ecompile_2erc_2ewithKnown_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewithKnown_clo;
V g_heff_2ecompile_2erc_2ewrapperOf(V, V, V, V, V);
V g_heff_2ecompile_2erc_2ewrapperOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erc_2ewrapperOf_clo;
V g_heff_2ecompile_2erepr_2emayBeFlat(V);
V g_heff_2ecompile_2erepr_2emayBeFlat_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2emayBeFlat_clo;
V g_heff_2ecompile_2erepr_2ereprEq(V, V);
V g_heff_2ecompile_2erepr_2ereprEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprEq_clo;
V g_heff_2ecompile_2erepr_2ereprsEq(V, V);
V g_heff_2ecompile_2erepr_2ereprsEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2erepr_2ereprsEq_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f421425463x1941958307(V, V, V);
V g_list_2efoldl_24f421425463x1941958307_entry(V self, V *a);
extern Clo g_list_2efoldl_24f421425463x1941958307_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1775266936x445289663(V, V);
V g_list_2efoldl_24s1775266936x445289663_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1775266936x445289663_clo;
V g_list_2efoldl_24s1790904629x1122008408(V, V);
V g_list_2efoldl_24s1790904629x1122008408_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1790904629x1122008408_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2efoldl_24s940218420x833897355(V, V, V, V);
V g_list_2efoldl_24s940218420x833897355_entry(V self, V *a);
extern Clo g_list_2efoldl_24s940218420x833897355_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1548644028x2098102081(V, V);
V g_list_2emap_24f1548644028x2098102081_entry(V self, V *a);
extern Clo g_list_2emap_24f1548644028x2098102081_clo;
V g_list_2emap_24s1796125103x644876049(V);
V g_list_2emap_24s1796125103x644876049_entry(V self, V *a);
extern Clo g_list_2emap_24s1796125103x644876049_clo;
V g_list_2emap_24s1901363476x1479927424(V);
V g_list_2emap_24s1901363476x1479927424_entry(V self, V *a);
extern Clo g_list_2emap_24s1901363476x1479927424_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_map_2eempty_get(void);
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
Clo g_heff_2ecompile_2erc_2ewithBorrowed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ewithBorrowed_entry, 2, 0};

V g_heff_2ecompile_2erc_2ewithBorrowed(V v_bs_240, V v_ce_241) {
top: ;
  return ({ V rv_6 = v_bs_240; V rr_ = heff_rec_reuse_nf(v_ce_241, 8127ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67096575u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2ecompile_2erc_2ewithBorrowed_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ewithBorrowed(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2efvOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efvOp_entry, 1, 0};

V g_heff_2ecompile_2erc_2efvOp(V v_o_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_IOp, 1, (V[]){v_o_240}), NTAG(TAG_Nil)});
  V v_x2_242 = (g_heff_2ecompile_2erc_2efvW(NTAG(TAG_Nil), NTAG(TAG_Nil), v_t_241));
  switch (heff_tag_of(v_x2_242)) {
  case TAG_MkPair: {
    V v_bs_243 = heff_field(v_x2_242, 0);
    V v_ms_244 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_bs_245 = (g_prelude_2e_2b_2b(NTAG(TAG_Nil), v_bs_243));
    V v_ms_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ms_244));
    V v_t_247 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_bs_245; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop(v_bs_245); r_; });
    return ({ V a_0 = v_t_247; V a_1 = heff_dup(g_map_2eempty_get()); V a_2 = v_ms_246; V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2erc_2efreeGo(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ecompile_2erc_2efvOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efvOp(a[0]);
}
V g_heff_2ecompile_2erc_2edropsOf_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2edropsOf_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2edropsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2edropsOf_entry, 2, 0};

V g_heff_2ecompile_2erc_2edropsOf(V v_ce_240, V v_xs_241) {
top: ;
  V v_t_246 = (g_list_2efoldl_24f421425463x1941958307(NTAG(TAG_Nil), heff_clo_n(g_heff_2ecompile_2erc_2edropsOf_lam0, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_241));
  return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erc_2edropsOf_lam1, 2, 1, (V[]){v_ce_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
}
V g_heff_2ecompile_2erc_2edropsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2edropsOf(a[0], a[1]);
}
V g_heff_2ecompile_2erc_2edropsOf_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_243 = ({ V a_0 = v_x_242; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_245;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_x1_245 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_243, 0ULL, 1);
    v_x1_245 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2edropsOf_lam1(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = ({ V a_0 = heff_dup(v_x_248); V b_1 = heff_get_n(v_ce_240, 8, 13); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2410 = (g_heff_2ecompile_2erc_2edropOf(v_x_248, v_t_249));
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_247));
}
Clo g_heff_2ecompile_2erc_2elentField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2elentField_entry, 3, 0};

V g_heff_2ecompile_2erc_2elentField(V v_ce_240, V v_after_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SVar: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SGlobal: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SInt: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFloat: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SStr: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SBytes: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFixed: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SFloat32: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SPrimFn: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SLam: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_STag: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SRec: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_SProj: {
    V v_e_2419 = heff_field(v_x3_242, 0);
    V v_l_2420 = heff_field(v_x3_242, 1);
    V v_sh_2421 = heff_field(v_x3_242, 2);
    V v_t_2422 = heff_field(v_x3_242, 3);
    V v_t_2423 = (g_heff_2ecompile_2erepr_2emayBeFlat(heff_dup(v_t_2422)));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_ce_240);
      heff_drop(v_t_2423);
      return NTAG(TAG_Nothing);
    } else {
      heff_drop(v_t_2423);
      V v_t_2446;
      switch (heff_tag_of(v_e_2419)) {
      case TAG_SVar: {
        V v_x_2424 = heff_field(v_e_2419, 0);
        v_t_2446 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2424)});
        break;
      }
      case TAG_SGlobal: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2446 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_2419);
      }
      V v_t_2447 = (g_heff_2ecompile_2erc_2eindexIn(heff_dup(v_l_2420), MK_INT(0LL), v_sh_2421));
      return (g_heff_2ecompile_2erc_2efieldLentOf(v_ce_240, v_after_241, v_t_2446, v_t_2447));
    }
  }
  case TAG_SPrim: {
    heff_drop(v_ce_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2elentField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2erc_2elentField(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2erc_2eunboxParam_str0, 4, "box$");
Clo g_heff_2ecompile_2erc_2eunboxParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eunboxParam_entry, 3, 0};

V g_heff_2ecompile_2erc_2eunboxParam(V v_ce_240, V v_lent_241, V v_x_242) {
top: ;
  V v_x3_243 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_x_242), heff_rfield(v_ce_240, 10)));
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_x_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 0ULL, 1);
    V v_x2_245 = ({ V a_0 = heff_dup(v_x_242); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    V v_rp_247;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nothing: {
      v_rp_247 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_x_246 = heff_field(v_x2_245, 0);
      heff_take_n(v_x2_245, 1ULL, 1);
      v_rp_247 = v_x_246;
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_v_248 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_RLocal, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2erc_2eunboxParam_str0), heff_dup(v_x_242))});
    V v_t_249;
    if ((heff_dup(v_lent_241) == NTAG(TAG_True))) {
      v_t_249 = heff_tag_n(TAG_RPeek, 2, (V[]){v_rp_247, v_v_248});
    } else {
      v_t_249 = heff_tag_n(TAG_RUnbox, 2, (V[]){v_rp_247, v_v_248});
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CLet, 2, (V[]){v_x_242, v_t_249}), NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ecompile_2erc_2eunboxParam_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2eunboxParam(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2etakeVarIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2etakeVarIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2etakeVarIn_entry, 5, 0};

V g_heff_2ecompile_2erc_2etakeVarIn(V v_ts_240, V v_live_241, V v_x3_242, V v_l_243, V v_i_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_l_243);
    heff_drop(v_i_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x_245 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_246 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_245), v_live_241));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_2415 = (g_list_2eany(heff_clo_n(g_heff_2ecompile_2erc_2etakeVarIn_lam0, 1, 2, (V[]){heff_dup(v_x_245), v_l_243}), v_ts_240));
      if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
        heff_drop(v_t_2415);
        return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_RTakeField, 2, (V[]){v_x_245, v_i_244})});
      } else {
        heff_drop(v_i_244);
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_t_2415);
        return NTAG(TAG_Nothing);
      }
    } else {
      heff_drop(v_l_243);
      heff_drop(v_i_244);
      heff_drop(v_x_245);
      heff_drop_cell(v_ru_24x3_242_24Just, 1);
      heff_drop(v_t_246);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2etakeVarIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2erc_2etakeVarIn(a0, a1, a[2], a[3], a[4]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2etakeVarIn_lam0(V self, V *args) {
  V v_p_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_l_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410;
  switch (heff_tag_of(v_p_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_dup(heff_field(v_p_247, 0));
    v_t_2410 = v_x_248;
    break;
  }
  default: heff_nomatch(v_p_247);
  }
  if (heff_strEq_c(v_t_2410, v_x_245)) {
    V v_t_2414;
    switch (heff_tag_of(v_p_247)) {
    case TAG_MkPair: {
      V v_y_2413 = heff_field(v_p_247, 1);
      heff_take_n(v_p_247, 2ULL, 2);
      v_t_2414 = v_y_2413;
      break;
    }
    default: heff_nomatch(v_p_247);
    }
    return heff_strEq(v_t_2414, v_l_243);
  } else {
    heff_drop(v_p_247);
    heff_drop(v_l_243);
    return NTAG(TAG_False);
  }
}
Clo g_heff_2ecompile_2erc_2ejustsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ejustsOf_24dps_entry, 2, 0};

V g_heff_2ecompile_2erc_2ejustsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2erc_2ejustsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ejustsOf_24dps(a[0], a[1]);
}
Clo g_heff_2ecompile_2erc_2esameAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2esameAs_entry, 3, 0};

V g_heff_2ecompile_2erc_2esameAs(V v_ce_240, V v_x2_241, V v_g_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ce_240, 13);
    heff_drop(v_g_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x2_241, 0);
    V v_a_244 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(heff_rfield(v_s_243, 0)), heff_rfield(v_ce_240, 11)));
    V v_b_245 = ({ V a_0 = v_g_242; V b_1 = heff_get_n(v_ce_240, 11, 13); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_a_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_b_245)) {
      case TAG_Nothing: {
        return NTAG(TAG_True);
      }
      case TAG_Just: {
        heff_take_n(v_b_245, 0ULL, 1);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_b_245);
      }
    }
    case TAG_Just: {
      V v_a1_247 = heff_field(v_a_244, 0);
      heff_take_n(v_a_244, 1ULL, 1);
      switch (heff_tag_of(v_b_245)) {
      case TAG_Nothing: {
        heff_drop_rec(v_a1_247, 2);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b1_248 = heff_field(v_b_245, 0);
        heff_take_n(v_b_245, 1ULL, 1);
        V v_t_249 = (g_heff_2ecompile_2erepr_2ereprsEq(heff_rfield(v_a1_247, 0), heff_rfield(v_b1_248, 0)));
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          return ({ V b_0 = heff_get_n(v_a1_247, 1, 2); V b_1 = heff_get_n(v_b1_248, 1, 2); V r_ = (g_heff_2ecompile_2erepr_2ereprEq(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
        } else {
          heff_drop_rec(v_a1_247, 2);
          heff_drop_rec(v_b1_248, 2);
          heff_drop(v_t_249);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_b_245);
      }
    }
    default: return heff_nomatch(v_a_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2esameAs_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2esameAs(a[0], a1, a[2]); heff_drop(a1); return r;
}

static V g_heff_2ecompile_2erc_2eroomFor_val;
static HEFF_ONCE g_heff_2ecompile_2erc_2eroomFor_st;
static V g_heff_2ecompile_2erc_2eroomFor_init(void) {
  return MK_INT(4LL);
}
V g_heff_2ecompile_2erc_2eroomFor_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erc_2eroomFor_st)) return g_heff_2ecompile_2erc_2eroomFor_val;
  return heff_global(&g_heff_2ecompile_2erc_2eroomFor_val, &g_heff_2ecompile_2erc_2eroomFor_st, g_heff_2ecompile_2erc_2eroomFor_init);
}
Clo g_heff_2ecompile_2erc_2efieldMask_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efieldMask_entry, 3, 0};

V g_heff_2ecompile_2erc_2efieldMask(V v_used_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x3_242, 0);
    V v_vs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_v_243), v_used_240));
    V v_t_246;
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      v_t_246 = (g_heff_2ecompile_2erc_2epow2(heff_dup(v_i_241)));
    } else {
      heff_drop(v_t_245);
      v_t_246 = MK_INT(0LL);
    }
    V v_t_247 = (g_heff_2ecompile_2erc_2efieldMask(v_used_240, heff_intAdd(v_i_241, MK_INT(1LL)), v_vs_244));
    return heff_intAdd(v_t_246, v_t_247);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2erc_2efieldMask_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ecompile_2erc_2efieldMask(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_entry, 3, 0};

V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(V v_ru_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_TSeq: {
    V v_ss_243 = heff_field(v_x4_242, 0);
    V v_t_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TSeq = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_it_245 = (g_heff_2ecompile_2erc_2ereuseSts_24s1600130214x404131609(heff_dup(v_ru_240), heff_dup(v_n_241), heff_dup(v_ss_243)));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_ss2_247 = heff_field(v_it_245, 1);
      heff_take_n(v_it_245, 3ULL, 2);
      if ((heff_dup(v_it1_246) == NTAG(TAG_True))) {
        heff_drop(v_ru_240);
        heff_drop(v_n_241);
        heff_drop(v_ss_243);
        heff_drop(v_it1_246);
        return heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_MkPair, 2, (V[]){NTAG(TAG_True), heff_tag_n(TAG_TSeq, 2, (V[]){v_ss2_247, v_t_244})});
      } else {
        heff_drop(v_it1_246);
        heff_drop(v_ss2_247);
        V v_t_248 = (g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(v_ru_240, v_n_241, v_t_244));
        switch (heff_tag_of(v_t_248)) {
        case TAG_MkPair: {
          V v_b_249 = heff_field(v_t_248, 0);
          V v_t2_2410 = heff_field(v_t_248, 1);
          heff_take_n(v_t_248, 3ULL, 2);
          return heff_tag_at_n(v_ru_24x4_242_24TSeq, TAG_MkPair, 2, (V[]){v_b_249, heff_tag_n(TAG_TSeq, 2, (V[]){v_ss_243, v_t2_2410})});
        }
        default: return heff_nomatch(v_t_248);
        }
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_TReturn: {
    V v_o_2411 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TReturn = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2412 = (g_heff_2ecompile_2erc_2ereuseOp(v_ru_240, v_n_241, v_o_2411));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_MkPair: {
      V v_b_2413 = heff_field(v_t_2412, 0);
      V v_o2_2414 = heff_field(v_t_2412, 1);
      V v_ru_24t_2412_24MkPair = heff_take_reuse_n(v_t_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2412_24MkPair, TAG_MkPair, 2, (V[]){v_b_2413, heff_tag_at_n(v_ru_24x4_242_24TReturn, TAG_TReturn, 1, (V[]){v_o2_2414})});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_TLoop: {
    V v_vs_2415 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24TLoop = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_lam0, 1, 2, (V[]){v_ru_240, v_n_241}); V a_1 = v_vs_2415; V r_ = (g_heff_2ecompile_2erc_2ereuseArgs(a_0, a_1)); heff_drop(v_vs_2415); r_; });
    switch (heff_tag_of(v_t_2417)) {
    case TAG_MkPair: {
      V v_b_2418 = heff_field(v_t_2417, 0);
      V v_vs2_2419 = heff_field(v_t_2417, 1);
      V v_ru_24t_2417_24MkPair = heff_take_reuse_n(v_t_2417, 3ULL, 2);
      return heff_tag_at_n(v_ru_24t_2417_24MkPair, TAG_MkPair, 2, (V[]){v_b_2418, heff_tag_at_n(v_ru_24x4_242_24TLoop, TAG_TLoop, 1, (V[]){v_vs2_2419})});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_TIf: {
    V v_c_2420 = heff_field(v_x4_242, 0);
    V v_t_2421 = heff_field(v_x4_242, 1);
    V v_e_2422 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24TIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(heff_dup(v_ru_240), heff_dup(v_n_241), v_t_2421));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_MkPair: {
      V v_bt_2424 = heff_field(v_t_2423, 0);
      V v_t2_2425 = heff_field(v_t_2423, 1);
      V v_ru_24t_2423_24MkPair = heff_take_reuse_n(v_t_2423, 3ULL, 2);
      V v_t_2426 = (g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(v_ru_240, v_n_241, v_e_2422));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_MkPair: {
        V v_be_2427 = heff_field(v_t_2426, 0);
        V v_e2_2428 = heff_field(v_t_2426, 1);
        heff_take_n(v_t_2426, 3ULL, 2);
        V v_t_2429;
        if ((heff_dup(v_bt_2424) == NTAG(TAG_True))) {
          heff_drop(v_bt_2424);
          heff_drop(v_be_2427);
          v_t_2429 = NTAG(TAG_True);
        } else {
          heff_drop(v_bt_2424);
          v_t_2429 = v_be_2427;
        }
        return heff_tag_at_n(v_ru_24t_2423_24MkPair, TAG_MkPair, 2, (V[]){v_t_2429, heff_tag_at_n(v_ru_24x4_242_24TIf, TAG_TIf, 3, (V[]){v_c_2420, v_t2_2425, v_e2_2428})});
      }
      default: return heff_nomatch(v_t_2426);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_TCase: {
    V v_v_2430 = heff_field(v_x4_242, 0);
    V v_arms_2431 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24TCase = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_2432 = (g_heff_2ecompile_2erc_2etlArms_24s671077875x1325843074(v_ru_240, v_n_241, v_arms_2431));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_MkPair: {
      V v_b_2433 = heff_field(v_t_2432, 0);
      V v_as2_2434 = heff_field(v_t_2432, 1);
      heff_take_n(v_t_2432, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x4_242_24TCase, TAG_MkPair, 2, (V[]){v_b_2433, heff_tag_n(TAG_TCase, 2, (V[]){v_v_2430, v_as2_2434})});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2erc_2ereuseTl_24s1842111759x2113176432_lam0(V self, V *args) {
  V v_v_2416 = args[0];
  V v_ru_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ecompile_2erc_2ereuseV(v_ru_240, v_n_241, v_v_2416));
}
HEFF_LIT(g_heff_2ecompile_2erc_2eboolName_str0, 8, "ret$bool");

static V g_heff_2ecompile_2erc_2eboolName_val;
static HEFF_ONCE g_heff_2ecompile_2erc_2eboolName_st;
static V g_heff_2ecompile_2erc_2eboolName_init(void) {
  return ((V)&g_heff_2ecompile_2erc_2eboolName_str0);
}
V g_heff_2ecompile_2erc_2eboolName_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2erc_2eboolName_st)) return g_heff_2ecompile_2erc_2eboolName_val;
  return heff_global(&g_heff_2ecompile_2erc_2eboolName_val, &g_heff_2ecompile_2erc_2eboolName_st, g_heff_2ecompile_2erc_2eboolName_init);
}
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam3(V self, V *args);
Clo g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_entry, 9, 0};

V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272(V v_ce_240, V v_x_241, V v_fa_242, V v_binding_243, V v_known_244, V v_takes_245, V v_rest_246, V v_after_247, V v_wb_248) {
top: ;
  V v_wanted_249 = (g_prelude_2e_2b_2b(heff_dup(v_fa_242), heff_dup(v_wb_248)));
  V v_xs_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam0, 1, 1, (V[]){v_wanted_249}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2413 = (g_heff_2ecompile_2erc_2edropsOf(heff_dup(v_ce_240), v_xs_2412));
  V v_t_2414 = (g_list_2emap_24s1796125103x644876049(v_t_2413));
  V v_wanted_2415 = (g_prelude_2e_2b_2b(v_fa_242, heff_dup(v_wb_248)));
  V v_owned_2417 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam1, 1, 1, (V[]){v_wanted_2415}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_ce_2418 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), v_owned_2417, heff_dup(v_wb_248), heff_dup(heff_rfield(v_ce_240, 6)), heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
  V v_t_2419 = ({ V rv_9 = v_takes_245; V rr_ = heff_rec_reuse_nf(v_ce_2418, 7679ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 66322431u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
  V v_t_2420 = heff_tr(heff_call(v_binding_243, 1, (V[]){v_t_2419}));
  V v_t_2421 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_241), v_wb_248));
  V v_t_2426;
  if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
    heff_drop(v_t_2421);
    v_t_2426 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_t_2421);
    V v_ce_2423;
    switch (heff_tag_of(v_known_244)) {
    case TAG_Nothing: {
      v_ce_2423 = heff_dup(v_ce_240);
      break;
    }
    case TAG_Just: {
      V v_k_2422 = heff_field(v_known_244, 0);
      v_ce_2423 = (g_heff_2ecompile_2erc_2ewithKnown(heff_dup(v_x_241), heff_dup(v_k_2422), heff_dup(v_ce_240)));
      break;
    }
    default: heff_nomatch(v_known_244);
    }
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_2425 = (g_heff_2ecompile_2erc_2edropsOf(v_ce_2423, v_t_2424));
    v_t_2426 = (g_list_2emap_24s1796125103x644876049(v_t_2425));
  }
  V v_t_2428 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam2, 1, 1, (V[]){heff_dup(v_wb_248)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2429 = ({ V a_0 = heff_dup(v_x_241); V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wb_248); r_; });
  V v_t_2435;
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    v_t_2435 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam3, 1, 1, (V[]){heff_dup(v_ce_240)}), v_t_2430));
  } else {
    heff_drop(v_t_2429);
    v_t_2435 = NTAG(TAG_Nil);
  }
  V v_owned_2436 = (g_prelude_2e_2b_2b(v_t_2428, v_t_2435));
  V v_ce_2438;
  switch (heff_tag_of(v_known_244)) {
  case TAG_Nothing: {
    heff_drop(v_x_241);
    v_ce_2438 = heff_dup(v_ce_240);
    break;
  }
  case TAG_Just: {
    V v_k_2437 = heff_field(v_known_244, 0);
    v_ce_2438 = (g_heff_2ecompile_2erc_2ewithKnown(v_x_241, heff_dup(v_k_2437), heff_dup(v_ce_240)));
    break;
  }
  default: heff_nomatch(v_known_244);
  }
  V v_ce_2439 = ({ V rv_9 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_ce_2438, 7679ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 66322431u, 0u); heff_rfield(rr_, 9) = rv_9; rr_; });
  V v_t_2440 = ({ V rv_4 = v_owned_2436; V rv_5 = heff_get_n(v_ce_240, 5, 13); V rr_ = heff_rec_reuse_nf(v_ce_2439, 8143ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67105023u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_2441 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_t_2440, v_rest_246, v_after_247));
  V v_t_2442 = (g_prelude_2e_2b_2b(v_t_2426, v_t_2441));
  V v_t_2443 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2442));
  return (g_prelude_2e_2b_2b(v_t_2414, v_t_2443));
}
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8]); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam0(V self, V *args) {
  V v_v_2410 = args[0];
  V v_wanted_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2411 = ({ V a_0 = v_v_2410; V a_1 = v_wanted_249; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_249); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam1(V self, V *args) {
  V v_v_2416 = args[0];
  V v_wanted_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2416; V a_1 = v_wanted_2415; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2415); r_; });
}
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam2(V self, V *args) {
  V v_v_2427 = args[0];
  V v_wb_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2427; V a_1 = v_wb_248; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wb_248); r_; });
}
V g_heff_2ecompile_2erc_2ebindWith_24s1200260009x355890272_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2432 = ({ V a_0 = v_x_2431; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2434;
  switch (heff_tag_of(v_x3_2432)) {
  case TAG_Nothing: {
    v_x1_2434 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2432, 0ULL, 1);
    v_x1_2434 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2432);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2434) == NTAG(TAG_True)));
  heff_drop(v_x1_2434);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_entry, 4, 0};

V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938(V v_ce_240, V v_xs_241, V v_t_242, V v_fv_243) {
top: ;
  V v_owned_244 = (g_prelude_2e_2b_2b(heff_dup(v_xs_241), v_fv_243));
  V v_wanted_245 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_242)));
  V v_xs_247 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_lam0, 1, 1, (V[]){v_wanted_245}), v_owned_244));
  V v_owned_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_lam1, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_247));
  V v_n_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_241; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_241); r_; });
  V v_ce_2414 = ({ V rv_2 = NTAG(TAG_Nothing); V rv_3 = v_n_2413; V rv_9 = NTAG(TAG_Nil); V rv_12 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_ce_240, 3571ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 15990543u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 12) = rv_12; rr_; });
  V v_ce_2415 = ({ V rv_6 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_ce_2414, 8127ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67096575u, 0u); heff_rfield(rr_, 6) = rv_6; rr_; });
  V v_t_2416 = ({ V rv_4 = v_owned_2412; V rv_5 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_ce_2415, 8143ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67105023u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  return (g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(v_t_2416, v_t_242));
}
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
}
V g_heff_2ecompile_2erc_2elamBody_24s760294942x1033012938_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_249 = ({ V a_0 = v_x_248; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2411;
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    v_x1_2411 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_249, 0ULL, 1);
    v_x1_2411 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_249);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2411) == NTAG(TAG_True)));
  heff_drop(v_x1_2411);
  return v_ret_24bool;
}
Clo g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_entry, 4, 0};

V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(V v_ce_240, V v_live_241, V v_x4_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_x5_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_rp_244 = heff_field(v_x4_242, 0);
    V v_rps_245 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x5_243)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_rp_244);
      heff_drop(v_rps_245);
      heff_drop_cell(v_ru_24x4_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_e_246 = heff_field(v_x5_243, 0);
      V v_es_247 = heff_field(v_x5_243, 1);
      heff_take_n(v_x5_243, 3ULL, 2);
      V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_247)));
      V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_248); r_; });
      V v_live_2410 = (g_prelude_2e_2b_2b(v_t_249, heff_dup(v_live_241)));
      V v_t_2411 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(heff_dup(v_ce_240), v_live_2410, v_rp_244, v_e_246));
      V v_cell_2412 = heff_tag_at_n(v_ru_24x4_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
      V v_u_2413 = (g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_24dps(v_ce_240, v_live_241, v_rps_245, v_es_247, heff_dup(v_cell_2412)));
      heff_drop(v_u_2413);
      return v_cell_2412;
    }
    default: return heff_nomatch(v_x5_243);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eoperandsAs_24s1511860541x301150829(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_entry, 8, 0};

V g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533(V v_ce_240, V v_live_241, V v_e_242, V v_i_243, V v_n_244, V v_may_245, V v_x8_246, V v_g_247) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_g_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
      return heff_tag_n(TAG_RGetN, 3, (V[]){v_t_248, v_i_243, v_n_244});
    }
    case TAG_Just: {
      V v_g1_249 = heff_field(v_g_247, 0);
      V v_ru_24g_247_24Just = heff_take_reuse_n(v_g_247, 1ULL, 1);
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_244);
      if ((heff_dup(v_may_245) == NTAG(TAG_True))) {
        return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24g_247_24Just, TAG_RGetRaw, 1, (V[]){v_g1_249}), v_i_243});
      } else {
        V v_t_2410 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24g_247_24Just, TAG_RGetRaw, 1, (V[]){v_g1_249}), v_i_243});
        return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_2410});
      }
    }
    default: return heff_nomatch(v_g_247);
    }
  }
  case TAG_Just: {
    V v_x_2411 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_g_247);
    V v_t_2412 = ({ V a_0 = heff_dup(v_x_2411); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_n_244);
      heff_drop(v_t_2412);
      if ((heff_dup(v_may_245) == NTAG(TAG_True))) {
        return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
      } else {
        V v_t_2413 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
        return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_2413});
      }
    } else {
      heff_drop(v_t_2412);
      V v_t_2414 = ({ V a_0 = heff_dup(v_x_2411); V b_1 = heff_get_n(v_ce_240, 6, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
        heff_drop(v_n_244);
        heff_drop(v_t_2414);
        if ((heff_dup(v_may_245) == NTAG(TAG_True))) {
          return heff_tag_n(TAG_RFieldV, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
        } else {
          V v_t_2415 = heff_tag_n(TAG_RField, 2, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243});
          return heff_tag_n(TAG_RDupE, 1, (V[]){v_t_2415});
        }
      } else {
        heff_drop(v_t_2414);
        return heff_tag_n(TAG_RGetN, 3, (V[]){heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2411}), v_i_243, v_n_244});
      }
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ecompile_2erc_2efieldIn_24s1314747270x2082163533(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
Clo g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_entry, 7, 0};

V g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636(V v_ce_240, V v_live_241, V v_e_242, V v_l_243, V v_t_244, V v_n_245, V v_x8_246) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_t_244);
    heff_drop(v_n_245);
    V v_t_247 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
    return heff_tag_n(TAG_RGetLabel, 2, (V[]){v_t_247, v_l_243});
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    V v_may_249 = (g_heff_2ecompile_2erepr_2emayBeFlat(v_t_244));
    V v_t_2432;
    switch (heff_tag_of(v_e_242)) {
    case TAG_SVar: {
      V v_x_2410 = heff_dup(heff_field(v_e_242, 0));
      v_t_2432 = heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Just, 1, (V[]){v_x_2410});
      break;
    }
    case TAG_SGlobal: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SInt: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SStr: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SBytes: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFixed: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SFloat32: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrimFn: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SLam: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_STag: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SRec: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SProj: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_SPrim: {
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      v_t_2432 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_242);
    }
    V v_x8_2433 = (g_heff_2ecompile_2erc_2etakeVarIn(heff_rfield(v_ce_240, 9), v_live_241, v_t_2432, v_l_243, heff_dup(v_i_248)));
    switch (heff_tag_of(v_x8_2433)) {
    case TAG_Nothing: {
      return ({ V a_0 = v_ce_240; V a_1 = v_live_241; V a_2 = v_e_242; V a_3 = v_i_248; V a_4 = v_n_245; V a_5 = v_may_249; V r_ = (g_heff_2ecompile_2erc_2efieldAt_24s813586599x1777756112(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_may_249); r_; });
    }
    case TAG_Just: {
      V v_t_2434 = heff_field(v_x8_2433, 0);
      heff_take_n(v_x8_2433, 1ULL, 1);
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_245);
      heff_drop(v_i_248);
      heff_drop(v_may_249);
      return v_t_2434;
    }
    default: return heff_nomatch(v_x8_2433);
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eprojAt_24s1221411341x666232636(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
Clo g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129_entry, 8, 0};

V g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129(V v_ce_240, V v_live_241, V v_e_242, V v_rp_243, V v_i_244, V v_n_245, V v_x8_246, V v_g_247) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_g_247)) {
    case TAG_Nothing: {
      V v_t_248 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_242));
      return heff_tag_n(TAG_RGetNU, 4, (V[]){v_rp_243, v_t_248, v_i_244, v_n_245});
    }
    case TAG_Just: {
      V v_g1_249 = heff_field(v_g_247, 0);
      V v_ru_24g_247_24Just = heff_take_reuse_n(v_g_247, 1ULL, 1);
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_live_241);
      heff_drop(v_e_242);
      heff_drop(v_n_245);
      return heff_tag_n(TAG_RFieldU, 3, (V[]){v_rp_243, heff_tag_at_n(v_ru_24g_247_24Just, TAG_RGetRaw, 1, (V[]){v_g1_249}), v_i_244});
    }
    default: return heff_nomatch(v_g_247);
    }
  }
  case TAG_Just: {
    V v_x_2410 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_g_247);
    V v_t_2411 = ({ V a_0 = heff_dup(v_x_2410); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop_rec(v_ce_240, 13);
      heff_drop(v_n_245);
      heff_drop(v_t_2411);
      return heff_tag_n(TAG_RFieldU, 3, (V[]){v_rp_243, heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2410}), v_i_244});
    } else {
      heff_drop(v_t_2411);
      V v_t_2412 = ({ V a_0 = heff_dup(v_x_2410); V b_1 = heff_get_n(v_ce_240, 6, 13); V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, b_1)); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_n_245);
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_RFieldU, 3, (V[]){v_rp_243, heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2410}), v_i_244});
      } else {
        heff_drop(v_t_2412);
        return heff_tag_n(TAG_RGetNU, 4, (V[]){v_rp_243, heff_tag_at_n(v_ru_24x8_246_24Just, TAG_RLocal, 1, (V[]){v_x_2410}), v_i_244, v_n_245});
      }
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_entry, 8, 0};

V g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130(V v_ce_240, V v_live_241, V v_want_242, V v_v_243, V v_e_244, V v_n_245, V v_x8_246, V v_rp_247) {
top: ;
  switch (heff_tag_of(v_x8_246)) {
  case TAG_Nothing: {
    heff_drop(v_e_244);
    heff_drop(v_n_245);
    heff_drop(v_rp_247);
    V v_t_248 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
    return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_248));
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_x8_246, 0);
    V v_ru_24x8_246_24Just = heff_take_reuse_n(v_x8_246, 1ULL, 1);
    V v_t_2413;
    switch (heff_tag_of(v_rp_247)) {
    case TAG_RepV: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_RepFix: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    case TAG_RepF64: {
      switch (heff_tag_of(v_want_242)) {
      case TAG_RepV: {
        v_t_2413 = NTAG(TAG_True);
        break;
      }
      case TAG_RepFix: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      case TAG_RepF64: {
        v_t_2413 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_want_242);
      }
      break;
    }
    default: heff_nomatch(v_rp_247);
    }
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_n_245);
      heff_drop(v_rp_247);
      heff_drop(v_i_249);
      heff_drop_cell(v_ru_24x8_246_24Just, 1);
      heff_drop(v_t_2413);
      V v_t_2414 = (g_heff_2ecompile_2erc_2evalF_24s1269393270x171552031(v_ce_240, v_live_241, v_v_243));
      return (g_heff_2ecompile_2erc_2ecoerce(NTAG(TAG_RepV), v_want_242, v_t_2414));
    } else {
      heff_drop(v_v_243);
      heff_drop(v_t_2413);
      V v_t_2437;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        V v_x_2415 = heff_dup(heff_field(v_e_244, 0));
        v_t_2437 = heff_tag_at_n(v_ru_24x8_246_24Just, TAG_Just, 1, (V[]){v_x_2415});
        break;
      }
      case TAG_SGlobal: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        heff_drop_cell(v_ru_24x8_246_24Just, 1);
        v_t_2437 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2460;
      switch (heff_tag_of(v_e_244)) {
      case TAG_SVar: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SGlobal: {
        V v_g_2439 = heff_dup(heff_field(v_e_244, 0));
        v_t_2460 = heff_tag_n(TAG_Just, 1, (V[]){v_g_2439});
        break;
      }
      case TAG_SInt: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2460 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_e_244);
      }
      V v_t_2461 = (g_heff_2ecompile_2erc_2efieldNum_24s53258100x1012955129(v_ce_240, v_live_241, v_e_244, heff_dup(v_rp_247), v_i_249, v_n_245, v_t_2437, v_t_2460));
      return (g_heff_2ecompile_2erc_2ecoerce(v_rp_247, v_want_242, v_t_2461));
    }
  }
  default: return heff_nomatch(v_x8_246);
  }
}
V g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2eprojAs_24s160424683x25193130(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
Clo g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_entry, 6, 0};

V g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_e_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    V v_t_246 = (g_heff_2ecompile_2erc_2eelemI(v_i_243, v_bi_242));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_244));
      return heff_tag_n(TAG_LentValue, 1, (V[]){v_t_247});
    } else {
      heff_drop(v_t_246);
      V v_t_248 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_244));
      return heff_tag_n(TAG_Given, 1, (V[]){v_t_248});
    }
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x7_245, 0);
    V v_ru_24x7_245_24Just = heff_take_reuse_n(v_x7_245, 1ULL, 1);
    V v_t_2410 = (g_heff_2ecompile_2erc_2eelemI(v_i_243, v_bi_242));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_e_244);
      heff_drop(v_t_2410);
      V v_t_2411 = ({ V a_0 = heff_dup(v_x_249); V a_1 = v_live_241; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_live_241); r_; });
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop_rec(v_ce_240, 13);
        heff_drop(v_t_2411);
        return heff_tag_at_n(v_ru_24x7_245_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_249})});
      } else {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_249), heff_rfield(v_ce_240, 6)));
        if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
          heff_drop_rec(v_ce_240, 13);
          heff_drop(v_t_2412);
          return heff_tag_at_n(v_ru_24x7_245_24Just, TAG_Given, 1, (V[]){heff_tag_n(TAG_RLocal, 1, (V[]){v_x_249})});
        } else {
          heff_drop_cell(v_ru_24x7_245_24Just, 1);
          heff_drop(v_t_2412);
          V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_249), NTAG(TAG_Nil)});
          V v_t_2414 = (g_heff_2ecompile_2erc_2edropsOf(v_ce_240, v_t_2413));
          return heff_tag_n(TAG_LentVar, 2, (V[]){v_x_249, v_t_2414});
        }
      }
    } else {
      heff_drop(v_x_249);
      heff_drop(v_t_2410);
      V v_t_2415 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_241, NTAG(TAG_RepV), v_e_244));
      return heff_tag_at_n(v_ru_24x7_245_24Just, TAG_Given, 1, (V[]){v_t_2415});
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2elentVarOr_24s1782234147x1370755903(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_entry, 7, 0};

V g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766(V v_ce_240, V v_after_241, V v_live_242, V v_bi_243, V v_i_244, V v_rp_245, V v_e_246) {
top: ;
  switch (heff_tag_of(v_rp_245)) {
  case TAG_RepV: {
    V v_t_247 = (g_heff_2ecompile_2erc_2eelemI(heff_dup(v_i_244), v_bi_243));
    V v_t_248;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_t_248 = (g_heff_2ecompile_2erc_2elentField(heff_dup(v_ce_240), v_after_241, v_e_246));
    } else {
      heff_drop(v_t_247);
      v_t_248 = NTAG(TAG_Nothing);
    }
    return (g_heff_2ecompile_2erc_2elentOr_24s1810949213x1891197566(v_ce_240, v_live_242, v_bi_243, v_i_244, v_e_246, v_t_248));
  }
  case TAG_RepFix: {
    heff_drop(v_i_244);
    V v_t_2410 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_242, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2410});
  }
  case TAG_RepF64: {
    heff_drop(v_i_244);
    V v_t_2411 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, v_live_242, heff_dup(v_rp_245), v_e_246));
    return heff_tag_n(TAG_GivenU, 2, (V[]){v_rp_245, v_t_2411});
  }
  default: return heff_nomatch(v_rp_245);
  }
}
V g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766(a[0], a1, a[2], a3, a[4], a[5], a[6]); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_entry, 7, 0};

V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps(V v_ce_240, V v_live_241, V v_bi_242, V v_i_243, V v_x6_244, V v_x7_245, V v_d_246) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop(v_ce_240);
    heff_drop(v_live_241);
    heff_drop(v_i_243);
    heff_drop(v_x7_245);
    return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_rp_247 = heff_field(v_x6_244, 0);
    V v_rps_248 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x7_245)) {
    case TAG_Nil: {
      heff_drop(v_ce_240);
      heff_drop(v_live_241);
      heff_drop(v_i_243);
      heff_drop(v_rp_247);
      heff_drop(v_rps_248);
      heff_drop_cell(v_ru_24x6_244_24Cons, 2);
      return heff_setField(v_d_246, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_e_249 = heff_field(v_x7_245, 0);
      V v_es_2410 = heff_field(v_x7_245, 1);
      heff_take_n(v_x7_245, 3ULL, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_es_2410)));
      V v_t_2412 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2411; V r_ = (g_list_2efoldl_24s1790904629x1122008408(a_0, a_1)); heff_drop(v_t_2411); r_; });
      V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, heff_dup(v_live_241)));
      V v_t_2414 = (g_heff_2ecompile_2erc_2esigOne_24s1734869740x1408036766(heff_dup(v_ce_240), v_live_241, v_t_2413, v_bi_242, heff_dup(v_i_243), v_rp_247, v_e_249));
      V v_cell_2415 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2414, heff_hole()});
      V v_u_2416 = heff_setField(v_d_246, MK_INT(1LL), heff_dup(v_cell_2415));
      heff_drop(v_u_2416);
      V t_0 = v_ce_240;
      V t_1 = v_live_241;
      V t_2 = v_bi_242;
      V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
      V t_4 = v_rps_248;
      V t_5 = v_es_2410;
      V t_6 = v_cell_2415;
      v_ce_240 = t_0;
      v_live_241 = t_1;
      v_bi_242 = t_2;
      v_i_243 = t_3;
      v_x6_244 = t_4;
      v_x7_245 = t_5;
      v_d_246 = t_6;
      goto top;
    }
    default: return heff_nomatch(v_x7_245);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2erc_2esigOperands_24s1253179267x140650414_24dps(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_entry, 4, 0};

V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps(V v_ce_240, V v_x3_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_PTrue: {
    heff_drop_rec(v_ce_240, 13);
    return heff_setField(v_d_242, v_i_243, NTAG(TAG_CondTrue));
  }
  case TAG_PFalse: {
    heff_drop_rec(v_ce_240, 13);
    return heff_setField(v_d_242, v_i_243, NTAG(TAG_CondFalse));
  }
  case TAG_PRel: {
    V v_p_244 = heff_field(v_x3_241, 0);
    V v_a_245 = heff_field(v_x3_241, 1);
    V v_b_246 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_246, NTAG(TAG_Nil)});
    V v_t_248 = (g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(v_ce_240, NTAG(TAG_Nil), v_p_244, heff_tag_n(TAG_Cons, 2, (V[]){v_a_245, v_t_247})));
    return heff_setField(v_d_242, v_i_243, v_t_248);
  }
  case TAG_PBool: {
    V v_v_249 = heff_field(v_x3_241, 0);
    heff_take_n(v_x3_241, 1ULL, 1);
    V v_t_2410 = (g_heff_2ecompile_2erc_2evalAsF_24s1405521958x549333462(v_ce_240, NTAG(TAG_Nil), NTAG(TAG_RepV), v_v_249));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondBool, 1, (V[]){v_t_2410}));
  }
  case TAG_PNot: {
    V v_c_2411 = heff_field(v_x3_241, 0);
    V v_ru_24x3_241_24PNot = heff_take_reuse_n(v_x3_241, 1ULL, 1);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x3_241_24PNot, TAG_CondNot, 1, (V[]){heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_ce_240;
    V t_1 = v_c_2411;
    V t_2 = v_cell_2412;
    V t_3 = MK_INT(0LL);
    v_ce_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2414 = heff_field(v_x3_241, 0);
    V v_b_2415 = heff_field(v_x3_241, 1);
    V v_c_2416 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24PIf = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_t_2417 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(heff_dup(v_ce_240), v_a_2414));
    V v_t_2418 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(heff_dup(v_ce_240), v_b_2415));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x3_241_24PIf, TAG_CondIf, 3, (V[]){v_t_2417, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_ce_240;
    V t_1 = v_c_2416;
    V t_2 = v_cell_2419;
    V t_3 = MK_INT(2LL);
    v_ce_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_PLet: {
    V v_x_2421 = heff_field(v_x3_241, 0);
    V v_o_2422 = heff_field(v_x3_241, 1);
    V v_c_2423 = heff_field(v_x3_241, 2);
    heff_take_n(v_x3_241, 7ULL, 3);
    V v_x2_2424 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2421), heff_rfield(v_ce_240, 10)));
    V v_want_2426;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nothing: {
      v_want_2426 = NTAG(TAG_RepV);
      break;
    }
    case TAG_Just: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      heff_take_n(v_x2_2424, 1ULL, 1);
      v_want_2426 = v_x_2425;
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2427 = (g_heff_2ecompile_2erc_2ecompF_24s632373949x1992688500(heff_dup(v_ce_240), NTAG(TAG_Nil), v_want_2426, v_o_2422));
    V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2421), heff_dup(heff_rfield(v_ce_240, 6))});
    V v_t_2429 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), heff_dup(heff_rfield(v_ce_240, 4)), heff_dup(heff_rfield(v_ce_240, 5)), v_t_2428, heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
    V v_t_2430 = (g_heff_2ecompile_2erc_2econdF_24s874044303x263379189(v_t_2429, v_c_2423));
    V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2421), NTAG(TAG_Nil)});
    V v_t_2436 = (g_list_2emap_24f1548644028x2098102081(heff_clo_n(g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_lam0, 1, 1, (V[]){v_ce_240}), v_t_2431));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CondLet, 4, (V[]){v_x_2421, v_t_2427, v_t_2430, v_t_2436}));
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erc_2econdF_24s874044303x263379189_24dps_lam0(V self, V *args) {
  V v_x_2432 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2433 = ({ V a_0 = v_x_2432; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2435;
  switch (heff_tag_of(v_x3_2433)) {
  case TAG_Nothing: {
    v_x1_2435 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2433, 0ULL, 1);
    v_x1_2435 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2433);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2435) == NTAG(TAG_True)));
  heff_drop(v_x1_2435);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_lam1(V self, V *args);
Clo g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_entry, 2, 0};

V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(V v_ce_240, V v_b_241) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_242 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_242)));
    break;
  }
  case TAG_ASts: {
    V v_ss_243 = heff_field(v_b_241, 0);
    v_t_244 = (g_heff_2ecompile_2erc_2efvSts(heff_dup(v_ss_243)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_245 = (g_prelude_2e_2b_2b(v_t_244, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_xs_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_lam0, 1, 1, (V[]){v_wanted_245}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_249 = (g_heff_2ecompile_2erc_2edropsOf(heff_dup(v_ce_240), v_xs_248));
  V v_t_2410 = (g_list_2emap_24s1796125103x644876049(v_t_249));
  V v_t_2413;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2411 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_t_2411)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2412 = heff_field(v_b_241, 0);
    v_t_2413 = (g_heff_2ecompile_2erc_2efvSts(heff_dup(v_ss_2412)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  V v_wanted_2414 = (g_prelude_2e_2b_2b(v_t_2413, heff_dup(heff_rfield(v_ce_240, 5))));
  V v_owned_2416 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_lam1, 1, 1, (V[]){v_wanted_2414}), heff_take_field(v_ce_240, 4)));
  V v_ce_2417 = ({ V rv_4 = v_owned_2416; V rr_ = heff_rec_reuse_nf(v_ce_240, 8175ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67108095u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_2420;
  switch (heff_tag_of(v_b_241)) {
  case TAG_ATail: {
    V v_t_2418 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(v_ce_2417, heff_dup(v_t_2418)));
    break;
  }
  case TAG_ASts: {
    V v_ss_2419 = heff_field(v_b_241, 0);
    v_t_2420 = (g_heff_2ecompile_2erc_2estmtsF_24s421930463x1334877518(v_ce_2417, heff_dup(v_ss_2419), NTAG(TAG_Nothing)));
    break;
  }
  default: heff_nomatch(v_b_241);
  }
  HEFF_LAST return g_prelude_2e_2b_2b(v_t_2410, v_t_2420);
}
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_wanted_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_247 = ({ V a_0 = v_v_246; V a_1 = v_wanted_245; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_245); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836_lam1(V self, V *args) {
  V v_v_2415 = args[0];
  V v_wanted_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2415; V a_1 = v_wanted_2414; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2414); r_; });
}
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam3(V self, V *args);
Clo g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_entry, 7, 0};

V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390(V v_ce_240, V v_p_241, V v_args_242, V v_yes_243, V v_no_244, V v_fa_245, V v_wb_246) {
top: ;
  V v_wanted_247 = (g_prelude_2e_2b_2b(heff_dup(v_fa_245), heff_dup(v_wb_246)));
  V v_xs_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam0, 1, 1, (V[]){v_wanted_247}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2411 = (g_heff_2ecompile_2erc_2edropsOf(heff_dup(v_ce_240), v_xs_2410));
  V v_t_2412 = (g_list_2emap_24s1796125103x644876049(v_t_2411));
  V v_wanted_2413 = (g_prelude_2e_2b_2b(v_fa_245, heff_dup(v_wb_246)));
  V v_owned_2415 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam1, 1, 1, (V[]){v_wanted_2413}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2416 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), v_owned_2415, heff_dup(v_wb_246), heff_dup(heff_rfield(v_ce_240, 6)), heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
  V v_t_2417 = (g_heff_2ecompile_2erc_2erelTest_24s79554594x384851698(v_t_2416, heff_dup(v_wb_246), v_p_241, v_args_242));
  V v_owned_2419 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam2, 1, 1, (V[]){heff_dup(v_wb_246)}), heff_dup(heff_rfield(v_ce_240, 4))));
  V v_t_2420 = heff_rec_n(13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, (V[]){heff_dup(heff_rfield(v_ce_240, 0)), heff_dup(heff_rfield(v_ce_240, 1)), heff_dup(heff_rfield(v_ce_240, 2)), heff_dup(heff_rfield(v_ce_240, 3)), v_owned_2419, heff_dup(heff_rfield(v_ce_240, 5)), heff_dup(heff_rfield(v_ce_240, 6)), heff_dup(heff_rfield(v_ce_240, 7)), heff_dup(heff_rfield(v_ce_240, 8)), heff_dup(heff_rfield(v_ce_240, 9)), heff_dup(heff_rfield(v_ce_240, 10)), heff_dup(heff_rfield(v_ce_240, 11)), heff_dup(heff_rfield(v_ce_240, 12))});
  V v_t_2421 = (g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(v_t_2420, v_yes_243));
  V v_owned_2423 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam3, 1, 1, (V[]){v_wb_246}), heff_take_field(v_ce_240, 4)));
  V v_t_2424 = ({ V rv_4 = v_owned_2423; V rr_ = heff_rec_reuse_nf(v_ce_240, 8175ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67108095u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
  V v_t_2425 = (g_heff_2ecompile_2erc_2econdArm_24s931287908x724185836(v_t_2424, v_no_244));
  V v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_t_2417, v_t_2421, v_t_2425}), NTAG(TAG_Nil)});
  return (g_prelude_2e_2b_2b(v_t_2412, v_t_2426));
}
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V a4 = a[4]; V r = g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390(a[0], a[1], a[2], a3, a4, a[5], a[6]); heff_drop(a3); heff_drop(a4); return r;
}
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam0(V self, V *args) {
  V v_v_248 = args[0];
  V v_wanted_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = ({ V a_0 = v_v_248; V a_1 = v_wanted_247; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_247); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam1(V self, V *args) {
  V v_v_2414 = args[0];
  V v_wanted_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2414; V a_1 = v_wanted_2413; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2413); r_; });
}
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam2(V self, V *args) {
  V v_v_2418 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2418; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erc_2econdWith_24s1505217281x435164390_lam3(V self, V *args) {
  V v_v_2422 = args[0];
  V v_wb_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2422; V a_1 = v_wb_246; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wb_246); r_; });
}
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_lam0(V self, V *args);
Clo g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_entry, 4, 0};

V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004(V v_ce_240, V v_returns_241, V v_v_242, V v_arms_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2erc_2escrutF_24s732712652x1862716178(heff_dup(v_ce_240), heff_dup(v_v_242)));
  V v_t_2457 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_lam0, 1, 2, (V[]){v_v_242, v_ce_240}), v_arms_243));
  return heff_tag_n(TAG_CSwitch, 3, (V[]){v_t_244, v_t_2457, v_returns_241});
}
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2erc_2ematchOf_24s1675530326x1501557004_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_v_242 = heff_env(self)[0];
  V v_ce_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_it1_246 = heff_field(v_p_245, 0);
    V v_b_247 = heff_field(v_p_245, 1);
    heff_take_n(v_p_245, 3ULL, 2);
    switch (heff_tag_of(v_it1_246)) {
    case TAG_MkPair: {
      V v_t_248 = heff_field(v_it1_246, 0);
      V v_vs_249 = heff_field(v_it1_246, 1);
      heff_take_n(v_it1_246, 3ULL, 2);
      V v_t_2433;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2410 = heff_dup(heff_field(v_v_242, 0));
        V v_t_2411 = (g_heff_2ecompile_2erc_2eelemS(heff_dup(v_x_2410), heff_rfield(v_ce_240, 4)));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2410});
        } else {
          heff_drop(v_x_2410);
          heff_drop(v_t_2411);
          v_t_2433 = NTAG(TAG_Nothing);
        }
        break;
      }
      case TAG_SGlobal: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SInt: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SStr: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SBytes: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFixed: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SFloat32: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrimFn: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SLam: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_STag: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SRec: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SProj: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_SPrim: {
        v_t_2433 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      V v_t_2456;
      switch (heff_tag_of(v_v_242)) {
      case TAG_SVar: {
        V v_x_2434 = heff_field(v_v_242, 0);
        heff_take_n(v_v_242, 1ULL, 1);
        v_t_2456 = (g_heff_2ecompile_2erc_2eelemS(v_x_2434, heff_rfield(v_ce_240, 6)));
        break;
      }
      case TAG_SGlobal: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SInt: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SStr: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SBytes: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SFixed: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SFloat32: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrimFn: {
        heff_take_n(v_v_242, 0ULL, 1);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SLam: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_STag: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SRec: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SProj: {
        heff_take_n(v_v_242, 0ULL, 4);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      case TAG_SPrim: {
        heff_take_n(v_v_242, 0ULL, 2);
        v_t_2456 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_v_242);
      }
      return ({ V a_0 = v_ce_240; V a_1 = v_t_2433; V a_2 = v_t_2456; V a_3 = v_t_248; V a_4 = v_vs_249; V a_5 = v_b_247; V r_ = (g_heff_2ecompile_2erc_2earmOf_24s150833151x1640468863(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2456); r_; });
    }
    default: return heff_nomatch(v_it1_246);
    }
  }
  default: return heff_nomatch(v_p_245);
  }
}
HEFF_LIT(g_heff_2ecompile_2erc_2efunWith_str0, 4, "box$");
V g_heff_2ecompile_2erc_2efunWith_lam0(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam1(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam2(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam3(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam4(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam5(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam6(V self, V *args);
V g_heff_2ecompile_2erc_2efunWith_lam7(V self, V *args);
Clo g_heff_2ecompile_2erc_2efunWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2efunWith_entry, 7, 0};

V g_heff_2ecompile_2erc_2efunWith(V v_ce_240, V v_key_241, V v_xs_242, V v_b_243, V v_bi_244, V v_rps_245, V v_sg_246) {
top: ;
  V v_t_2412 = (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam0, 2, 1, (V[]){heff_dup(v_ce_240)}), heff_dup(v_rps_245), heff_dup(v_xs_242)));
  V v_t_2413 = (g_heff_2ecompile_2erc_2eunboxParams(heff_dup(v_ce_240), v_bi_244, v_rps_245, heff_dup(v_xs_242)));
  V v_t_2414 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2415 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2414, MK_INT(1LL))));
  V v_t_2416 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2415));
  V v_t_2422 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam1, 1, 1, (V[]){heff_dup(v_bi_244)}), v_t_2416));
  V v_owned_2423 = (g_list_2emap_24s1937570095x2110149801(v_t_2422));
  V v_wanted_2424 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_b_243)));
  V v_xs_2427 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam2, 1, 1, (V[]){v_wanted_2424}), v_owned_2423));
  V v_t_2432 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam3, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2427));
  V v_t_2433 = (g_list_2emap_24s1901363476x1479927424(v_t_2432));
  V v_t_2434 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2435 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2434, MK_INT(1LL))));
  V v_t_2436 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2435));
  V v_t_2442 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam4, 1, 1, (V[]){heff_dup(v_bi_244)}), v_t_2436));
  V v_owned_2443 = (g_list_2emap_24s1937570095x2110149801(v_t_2442));
  V v_wanted_2444 = (g_heff_2ecompile_2erc_2efvTl(heff_dup(v_b_243)));
  V v_xs_2446 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam5, 1, 1, (V[]){v_wanted_2444}), v_owned_2443));
  V v_owned_2451 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam6, 1, 1, (V[]){heff_dup(v_ce_240)}), v_xs_2446));
  V v_t_2452 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_242));
  V v_t_2453 = (g_list_2erange(MK_INT(0LL), heff_intSub(v_t_2452, MK_INT(1LL))));
  V v_t_2454 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_242), v_t_2453));
  V v_t_2459 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2erc_2efunWith_lam7, 1, 1, (V[]){heff_dup(v_bi_244)}), v_t_2454));
  V v_t_2460 = (g_list_2emap_24s1937570095x2110149801(v_t_2459));
  V v_t_2461 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_key__params, (V[]){heff_dup(v_key_241), heff_dup(v_xs_242)})});
  V v_t_2462 = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(v_b_243, NTAG(TAG_Nil)));
  V v_t_2463 = (g_list_2efoldl_24s940218420x833897355(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_2462));
  V v_t_2464 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_2463; V r_ = (g_list_2efoldl_24s1775266936x445289663(a_0, a_1)); heff_drop(v_t_2463); r_; });
  V v_t_2465 = (g_heff_2ecompile_2erc_2ewithFrame(v_t_2461, MK_INT(0LL), v_t_2464));
  V v_ce_2466 = (g_heff_2ecompile_2erc_2ewithBorrowed(v_t_2460, v_t_2465));
  V v_t_2467 = ({ V rv_4 = v_owned_2451; V rv_5 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_ce_2466, 8143ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67105023u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_2468 = (g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(v_t_2467, v_b_243));
  V v_t_2469 = (g_prelude_2e_2b_2b(v_t_2433, v_t_2468));
  V v_x1_2470 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_key_241), heff_rfield(v_ce_240, 11)));
  V v_t_2472;
  switch (heff_tag_of(v_x1_2470)) {
  case TAG_Nothing: {
    v_t_2472 = NTAG(TAG_RepV);
    break;
  }
  case TAG_Just: {
    V v_s_2471 = heff_field(v_x1_2470, 0);
    heff_take_n(v_x1_2470, 1ULL, 1);
    v_t_2472 = heff_get_n(v_s_2471, 1, 2);
    break;
  }
  default: heff_nomatch(v_x1_2470);
  }
  V v_t_2475;
  switch (heff_tag_of(v_sg_246)) {
  case TAG_Nothing: {
    heff_drop(v_xs_242);
    v_t_2475 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x_2473 = heff_field(v_sg_246, 0);
    V v_ru_24sg_246_24Just = heff_take_reuse_n(v_sg_246, 1ULL, 1);
    V v_t_2474 = (g_heff_2ecompile_2erc_2ewrapperOf(heff_dup(v_ce_240), heff_dup(v_key_241), v_bi_244, v_x_2473, v_xs_242));
    v_t_2475 = heff_tag_at_n(v_ru_24sg_246_24Just, TAG_Just, 1, (V[]){v_t_2474});
    break;
  }
  default: heff_nomatch(v_sg_246);
  }
  V v_t_2476 = heff_rec_n(8, shape_key__params__lent__entry__body__reprs__ret__wrapper, (V[]){v_key_241, v_t_2412, v_bi_244, v_t_2413, v_t_2469, heff_get_n(v_ce_240, 10, 13), v_t_2472, v_t_2475});
  return heff_tag_n(TAG_DFun, 1, (V[]){v_t_2476});
}
V g_heff_2ecompile_2erc_2efunWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2efunWith(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2erc_2efunWith_lam0(V self, V *args) {
  V v_rp_247 = args[0];
  V v_x_248 = args[1];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_rp_247)) {
  case TAG_RepV: {
    V v_x3_249 = ({ V a_0 = heff_dup(v_x_248); V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      return v_x_248;
    }
    case TAG_Just: {
      heff_take_n(v_x3_249, 0ULL, 1);
      return heff_strAppend(((V)&g_heff_2ecompile_2erc_2efunWith_str0), v_x_248);
    }
    default: return heff_nomatch(v_x3_249);
    }
  }
  case TAG_RepFix: {
    heff_take_n(v_rp_247, 0ULL, 1);
    heff_drop_rec(v_ce_240, 13);
    return v_x_248;
  }
  case TAG_RepF64: {
    heff_drop_rec(v_ce_240, 13);
    return v_x_248;
  }
  default: return heff_nomatch(v_rp_247);
  }
}
V g_heff_2ecompile_2erc_2efunWith_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_bi_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2420;
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_y_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 2ULL, 2);
    v_t_2420 = v_y_2419;
    break;
  }
  default: heff_nomatch(v_p_2417);
  }
  V v_x1_2421 = ({ V a_0 = v_t_2420; V a_1 = v_bi_244; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_bi_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2421) == NTAG(TAG_True)));
  heff_drop(v_x1_2421);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2efunWith_lam2(V self, V *args) {
  V v_v_2425 = args[0];
  V v_wanted_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2426 = ({ V a_0 = v_v_2425; V a_1 = v_wanted_2424; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2424); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2426) == NTAG(TAG_True)));
  heff_drop(v_x1_2426);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2efunWith_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2429 = ({ V a_0 = v_x_2428; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2431;
  switch (heff_tag_of(v_x3_2429)) {
  case TAG_Nothing: {
    v_x1_2431 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2429, 0ULL, 1);
    v_x1_2431 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2429);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2431) == NTAG(TAG_True)));
  heff_drop(v_x1_2431);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2efunWith_lam4(V self, V *args) {
  V v_p_2437 = args[0];
  V v_bi_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440;
  switch (heff_tag_of(v_p_2437)) {
  case TAG_MkPair: {
    V v_y_2439 = heff_field(v_p_2437, 1);
    heff_take_n(v_p_2437, 2ULL, 2);
    v_t_2440 = v_y_2439;
    break;
  }
  default: heff_nomatch(v_p_2437);
  }
  V v_x1_2441 = ({ V a_0 = v_t_2440; V a_1 = v_bi_244; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_bi_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2441) == NTAG(TAG_True)));
  heff_drop(v_x1_2441);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2efunWith_lam5(V self, V *args) {
  V v_v_2445 = args[0];
  V v_wanted_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_v_2445; V a_1 = v_wanted_2444; V r_ = (g_heff_2ecompile_2erc_2eelemS(a_0, a_1)); heff_drop(v_wanted_2444); r_; });
}
V g_heff_2ecompile_2erc_2efunWith_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_ce_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_2448 = ({ V a_0 = v_x_2447; V b_1 = heff_get_n(v_ce_240, 10, 13); V r_ = (g_map_2elookup_24s659669741x1036301430(a_0, b_1)); heff_drop(b_1); r_; });
  V v_x1_2450;
  switch (heff_tag_of(v_x3_2448)) {
  case TAG_Nothing: {
    v_x1_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2448, 0ULL, 1);
    v_x1_2450 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2448);
  }
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2450) == NTAG(TAG_True)));
  heff_drop(v_x1_2450);
  return v_ret_24bool;
}
V g_heff_2ecompile_2erc_2efunWith_lam7(V self, V *args) {
  V v_p_2455 = args[0];
  V v_bi_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_p_2455)) {
  case TAG_MkPair: {
    V v_y_2457 = heff_field(v_p_2455, 1);
    heff_take_n(v_p_2455, 2ULL, 2);
    v_t_2458 = v_y_2457;
    break;
  }
  default: heff_nomatch(v_p_2455);
  }
  return ({ V a_0 = v_t_2458; V a_1 = v_bi_244; V r_ = (g_heff_2ecompile_2eborrow_2eelemI(a_0, a_1)); heff_drop(v_bi_244); r_; });
}
Clo g_heff_2ecompile_2erc_2evalRc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2evalRc_entry, 3, 0};

V g_heff_2ecompile_2erc_2evalRc(V v_ce_240, V v_key_241, V v_t_242) {
top: ;
  V v_t_243 = heff_tr(g_heff_2ecompile_2eimp_2epartsTl_24s73809606x896811174(v_t_242, NTAG(TAG_Nil)));
  V v_t_244 = (g_list_2efoldl_24s940218420x833897355(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_t_243));
  V v_ce_245 = ({ V a_0 = heff_dup(v_ce_240); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1775266936x445289663(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_ce_246 = ({ V rv_2 = NTAG(TAG_Nothing); V rv_3 = MK_INT(0LL); V rv_9 = NTAG(TAG_Nil); V rv_12 = NTAG(TAG_RepV); V rr_ = heff_rec_reuse_nf(v_ce_245, 3571ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 15990543u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 9) = rv_9; heff_rfield(rr_, 12) = rv_12; rr_; });
  V v_t_247 = ({ V rv_4 = NTAG(TAG_Nil); V rv_5 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_ce_246, 8143ULL, 13, shape_funs__bounce__self__lam__owned__after__borrowed__bor__known__takes__reprs__sigs__ret, 67105023u, 0u); heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; rr_; });
  V v_t_248 = (g_heff_2ecompile_2erc_2etailF_24s998403962x1850653315(v_t_247, v_t_242));
  return heff_tag_n(TAG_DVal, 3, (V[]){v_key_241, v_t_248, heff_get_n(v_ce_240, 10, 13)});
}
V g_heff_2ecompile_2erc_2evalRc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2erc_2evalRc(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_entry, 2, 0};

V g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245;
    if ((heff_dup(v_b_244) == NTAG(TAG_True))) {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(1LL);
    } else {
      heff_drop(v_b_244);
      v_t_245 = MK_INT(0LL);
    }
    V v_t_246 = (g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237(v_f_240, v_xs_243));
    return heff_intAdd(v_t_245, heff_intMul(MK_INT(2LL), v_t_246));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2erc_2ekeepBits_24f522593881x133349237(a[0], a1); heff_drop(a1); return r;
}