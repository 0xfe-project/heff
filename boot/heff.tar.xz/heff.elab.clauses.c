// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_BadVariant 54613
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_ExplicitParam 63083
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_Right 62770
#define TAG_SetField 47531
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define TAG_TagVariant 25174
#define LBL_anys 9494734
#define LBL_arity 294440695
#define LBL_arms 9498206
#define LBL_bad 306815
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_inf 313947
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_row 322644
#define LBL_rows 10002080
#define LBL_scrutinee 73860976
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_tag 324116
#define LBL_tree 10063973
#define LBL_typ 324869
#define LBL_v 336
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_inf__chk__typ__decl[] = {LBL_inf, LBL_chk, LBL_typ, LBL_decl};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_row__bad__rows[] = {LBL_row, LBL_bad, LBL_rows};
static uint32_t shape_scrutinee__tree[] = {LBL_scrutinee, LBL_tree};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_tag__arity__pats__span[] = {LBL_tag, LBL_arity, LBL_pats, LBL_span};
static uint32_t shape_x__v__inf__chk__typ[] = {LBL_x, LBL_v, LBL_inf, LBL_chk, LBL_typ};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eallC(V, V);
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eallC_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyIn(V, V, V);
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyIn_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2earmFields(V, V, V, V);
V g_heff_2eelab_2eclauses_2earmFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmFields_clo;
V g_heff_2eelab_2eclauses_2earmSubName(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSubName_clo;
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo;
V g_heff_2eelab_2eclauses_2ecaseTreeOf(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolName(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolName_clo;
V g_heff_2eelab_2eclauses_2ecolPick(V, V, V);
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolPick_clo;
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_clo;
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo;
V g_heff_2eelab_2eclauses_2econcatMapC(V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_clo;
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_clo;
V g_heff_2eelab_2eclauses_2edesugar(V, V, V, V);
V g_heff_2eelab_2eclauses_2edesugar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edesugar_clo;
V g_heff_2eelab_2eclauses_2edesugarCols(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2edesugarCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edesugarCols_clo;
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2efindTagLit(V, V);
V g_heff_2eelab_2eclauses_2efindTagLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efindTagLit_clo;
V g_heff_2eelab_2eclauses_2efoldr2(V, V, V);
V g_heff_2eelab_2eclauses_2efoldr2_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efoldr2_clo;
V g_heff_2eelab_2eclauses_2eforC(V, V);
V g_heff_2eelab_2eclauses_2eforC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eforC_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsDeclF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eletFields(V, V, V, V);
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eletFields_clo;
V g_heff_2eelab_2eclauses_2elitChecks(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitChecks_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitChecks_clo;
V g_heff_2eelab_2eclauses_2elitExpr(V);
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitExpr_clo;
V g_heff_2eelab_2eclauses_2elitNo(V, V, V);
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNo_clo;
V g_heff_2eelab_2eclauses_2elitNoOne(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitNoOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitNoOne_clo;
V g_heff_2eelab_2eclauses_2elitYes(V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYes_clo;
V g_heff_2eelab_2eclauses_2elitYesOne(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYesOne_clo;
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_clo;
V g_heff_2eelab_2eclauses_2elookupField(V, V);
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elookupField_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416_clo;
V g_heff_2eelab_2eclauses_2enoLitHere(V, V, V);
V g_heff_2eelab_2eclauses_2enoLitHere_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoLitHere_clo;
V g_heff_2eelab_2eclauses_2enoRecMix(V, V);
V g_heff_2eelab_2eclauses_2enoRecMix_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoRecMix_clo;
V g_heff_2eelab_2eclauses_2enthC(V, V);
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enthC_clo;
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2epat(V);
V g_heff_2eelab_2eclauses_2epat_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epat_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epeelAs(V, V, V);
V g_heff_2eelab_2eclauses_2epeelAs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelAs_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2epiIdents(V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_clo;
V g_heff_2eelab_2eclauses_2erecFieldVar(V, V, V);
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo;
V g_heff_2eelab_2eclauses_2erecSpecialize(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo;
V g_heff_2eelab_2eclauses_2erecSubName(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSubName_clo;
V g_heff_2eelab_2eclauses_2erecSubs(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSubs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSubs_clo;
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_clo;
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_clo;
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2eelab_2eclauses_2erenameChkF(V, V);
V g_heff_2eelab_2eclauses_2erenameChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameChkF_clo;
V g_heff_2eelab_2eclauses_2erenameDecl(V, V);
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameDecl_clo;
V g_heff_2eelab_2eclauses_2erenameEquation(V, V);
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameEquation_clo;
V g_heff_2eelab_2eclauses_2erenameField(V, V);
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameField_clo;
V g_heff_2eelab_2eclauses_2erenameInfF(V, V);
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameInfF_clo;
V g_heff_2eelab_2eclauses_2erenamePi(V, V);
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamePi_clo;
V g_heff_2eelab_2eclauses_2erenameSeq(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_clo;
V g_heff_2eelab_2eclauses_2erenameTypF(V, V);
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameTypF_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2esameLit(V, V);
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esameLit_clo;
V g_heff_2eelab_2eclauses_2etagArmStep(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagArmStep_clo;
V g_heff_2eelab_2eclauses_2etagColAt(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColAt_clo;
V g_heff_2eelab_2eclauses_2etagColGo(V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColGo_clo;
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etraverseC(V, V);
V g_heff_2eelab_2eclauses_2etraverseC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_clo;
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(V);
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2ezipC(V, V);
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1819302915x1539612842(V, V, V);
V g_list_2efoldl_24s1819302915x1539612842_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1819302915x1539612842_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s2103553821x564582624(V, V);
V g_list_2emap_24s2103553821x564582624_entry(V self, V *a);
extern Clo g_list_2emap_24s2103553821x564582624_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2emapValues(V, V);
V g_map_2emapValues_entry(V self, V *a);
extern Clo g_map_2emapValues_clo;
Clo g_heff_2eelab_2eclauses_2eappendC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2eclauses_2eappendC(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2econcatMapC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2eclauses_2econcatMapC(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2econcatMapC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecatMaybesC_entry, 1, 0};

V g_heff_2eelab_2eclauses_2ecatMaybesC(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eelab_2eclauses_2ecatMaybesC(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecatMaybesC(a[0]);
}
Clo g_heff_2eelab_2eclauses_2etraverseC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2etraverseC(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_242}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
    }
    case TAG_Right: {
      V v_x_246 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Right = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      V v_x1_247 = (g_heff_2eelab_2eclauses_2etraverseC(v_f_240, v_xs_243));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Left: {
        V v_e_248 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_x_246);
        return heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Left, 1, (V[]){v_e_248});
      }
      case TAG_Right: {
        V v_x_249 = heff_field(v_x1_247, 0);
        heff_take_n(v_x1_247, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_246, v_x_249})});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eforC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eforC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eforC(V v_x1_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_x1_244 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_x1_244)) {
    case TAG_Left: {
      V v_e_245 = heff_field(v_x1_244, 0);
      V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
      heff_drop(v_f_241);
      return heff_tag_at_n(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
    }
    case TAG_Right: {
      heff_take_n(v_x1_244, 0ULL, 1);
      V t_0 = v_xs_243;
      V t_1 = v_f_241;
      v_x1_240 = t_0;
      v_f_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x1_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eforC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2eforC(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enthC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enthC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enthC(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_xs_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enthC(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2ezipC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ezipC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2ezipC(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), (g_heff_2eelab_2eclauses_2ezipC(v_xs_243, v_ys_245))});
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ezipC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eanyC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_p_240);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2eallC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eallC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eallC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eallC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eallC(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2enubStr_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enubStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enubStr_entry, 1, 0};

V g_heff_2eelab_2eclauses_2enubStr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eclauses_2enubStr_lam0, 1, 1, (V[]){heff_dup(v_x_241)}), v_xs_242));
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, (g_heff_2eelab_2eclauses_2enubStr(v_t_245))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enubStr(a[0]);
}
V g_heff_2eelab_2eclauses_2enubStr_lam0(V self, V *args) {
  V v_y_243 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_y_243, v_x_241)) {
    return NTAG(TAG_False);
  } else {
    return NTAG(TAG_True);
  }
}
Clo g_heff_2eelab_2eclauses_2eupToGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eupToGo_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eupToGo(V v_i_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), heff_dup(v_i_240))) {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  } else {
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_240), (g_heff_2eelab_2eclauses_2eupToGo(heff_intAdd(v_i_240, MK_INT(1LL)), v_n_241))});
  }
}
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eupToGo(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropAt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropAt(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return v_xs_243;
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2eclauses_2edropAt(heff_intSub(v_i_240, MK_INT(1LL)), v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropAt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2etakeC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etakeC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2etakeC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return NTAG(TAG_Nil);
    } else {
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2eelab_2eclauses_2etakeC(heff_intSub(v_n_240, MK_INT(1LL)), v_xs_243))});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etakeC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2edropC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2edropC(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_xs_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2eelab_2eclauses_2epat(v_x_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_e_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_e_244});
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      V v_x1_246 = (g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(v_xs_242));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Left: {
        V v_e_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_e_247});
      }
      case TAG_Right: {
        V v_x_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(a[0]);
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_243 = heff_field(v_x_241, 0);
      V v_a_244 = heff_field(v_x_241, 1);
      heff_take_n(v_x_241, 3ULL, 2);
      V v_a_245 = (g_heff_2eelab_2eclauses_2epat(v_a_244));
      switch (heff_tag_of(v_a_245)) {
      case TAG_Left: {
        V v_a_246 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24Left = heff_take_reuse_n(v_a_245, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_a_243);
        v_x1_248 = heff_tag_at_n(v_ru_24a_245_24Left, TAG_Left, 1, (V[]){v_a_246});
        break;
      }
      case TAG_Right: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24Right = heff_take_reuse_n(v_a_245, 1ULL, 1);
        v_x1_248 = heff_tag_at_n(v_ru_24a_245_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_MkPair, 2, (V[]){v_a_243, v_a_247})});
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_248)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Left = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      heff_drop(v_xs_242);
      return heff_tag_at_n(v_ru_24x1_248_24Left, TAG_Left, 1, (V[]){v_e_249});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x1_248, 0);
      V v_ru_24x1_248_24Right = heff_take_reuse_n(v_x1_248, 1ULL, 1);
      V v_x1_2411 = (g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(v_xs_242));
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Left: {
        V v_e_2412 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        heff_drop(v_x_2410);
        return heff_tag_at_n(v_ru_24x1_248_24Right, TAG_Left, 1, (V[]){v_e_2412});
      }
      case TAG_Right: {
        V v_x_2413 = heff_field(v_x1_2411, 0);
        heff_take_n(v_x1_2411, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_x_2413})});
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    default: return heff_nomatch(v_x1_248);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(a[0]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_str0, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");
HEFF_LIT(g_heff_2eelab_2eclauses_2epat_str1, 86, "a pattern is a variable, a literal, a tag applied to patterns, or a record of patterns");
Clo g_heff_2eelab_2eclauses_2epat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epat_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epat(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_dup(heff_field(v_p_240, 0));
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      V v_ru_24p1_241_24PatVar = heff_take_reuse_n(v_p1_241, 1ULL, 1);
      heff_drop_tag(v_p_240, 2);
      return heff_tag_at_n(v_ru_24p1_241_24PatVar, TAG_Right, 1, (V[]){heff_tag_n(TAG_PVar, 1, (V[]){v_x_243})});
    }
    case TAG_PatTag: {
      V v_t_244 = heff_field(v_p1_241, 0);
      V v_tsp_245 = heff_field(v_p1_241, 1);
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_ru_24p1_241_24PatTag = heff_take_reuse_n(v_p1_241, 7ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_x1_247 = (g_heff_2eelab_2eclauses_2etraverseC_24s878738481x66815381(v_ps_246));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_Left: {
        V v_e_248 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        heff_drop(v_t_244);
        heff_drop(v_tsp_245);
        heff_drop_cell(v_ru_24p1_241_24PatTag, 3);
        return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
      }
      case TAG_Right: {
        V v_x_249 = heff_field(v_x1_247, 0);
        V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24p1_241_24PatTag, TAG_PTag, 3, (V[]){v_t_244, v_x_249, v_tsp_245})});
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
    case TAG_PatOp: {
      heff_take_n(v_p1_241, 0ULL, 3);
      V v_span_2415;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2414 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_span_2415 = v_s_2414;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2415, ((V)&g_heff_2eelab_2eclauses_2epat_str0)})});
    }
    case TAG_PatInt: {
      V v_ru_24p1_241_24PatInt = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatInt, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatFloat: {
      V v_ru_24p1_241_24PatFloat = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatFloat, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatString: {
      V v_ru_24p1_241_24PatString = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatString, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatRune: {
      V v_ru_24p1_241_24PatRune = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24p1_241_24PatRune, TAG_Right, 1, (V[]){heff_tag_n(TAG_PLit, 1, (V[]){v_p_240})});
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_241, 0);
      V v_ru_24p1_241_24PatRecord = heff_take_reuse_n(v_p1_241, 1ULL, 1);
      V v_x1_2421 = (g_heff_2eelab_2eclauses_2etraverseC_24s883877211x1541321027(v_fs_2420));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_Left: {
        V v_e_2422 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_tag(v_p_240, 2);
        return heff_tag_at_n(v_ru_24p1_241_24PatRecord, TAG_Left, 1, (V[]){v_e_2422});
      }
      case TAG_Right: {
        V v_x_2423 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        V v_t_2426;
        switch (heff_tag_of(v_p_240)) {
        case TAG_At: {
          V v_s_2425 = heff_field(v_p_240, 1);
          heff_take_n(v_p_240, 2ULL, 2);
          v_t_2426 = v_s_2425;
          break;
        }
        default: heff_nomatch(v_p_240);
        }
        return heff_tag_at_n(v_ru_24p1_241_24PatRecord, TAG_Right, 1, (V[]){heff_tag_n(TAG_PRec, 2, (V[]){v_x_2423, v_t_2426})});
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
    case TAG_PatWord: {
      V v_ru_24p1_241_24PatWord = heff_take_reuse_n(v_p1_241, 0ULL, 1);
      V v_span_2430;
      switch (heff_tag_of(v_p_240)) {
      case TAG_At: {
        V v_s_2429 = heff_field(v_p_240, 1);
        heff_take_n(v_p_240, 2ULL, 2);
        v_span_2430 = v_s_2429;
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      return heff_tag_at_n(v_ru_24p1_241_24PatWord, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2430, ((V)&g_heff_2eelab_2eclauses_2epat_str1)})});
    }
    case TAG_PatAs: {
      V v_x_2431 = heff_field(v_p1_241, 0);
      V v_q_2433 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      heff_drop_tag(v_p_240, 2);
      V v_x1_2434 = (g_heff_2eelab_2eclauses_2epat(v_q_2433));
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_Left: {
        V v_e_2435 = heff_field(v_x1_2434, 0);
        V v_ru_24x1_2434_24Left = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
        heff_drop(v_x_2431);
        return heff_tag_at_n(v_ru_24x1_2434_24Left, TAG_Left, 1, (V[]){v_e_2435});
      }
      case TAG_Right: {
        V v_x_2436 = heff_field(v_x1_2434, 0);
        V v_ru_24x1_2434_24Right = heff_take_reuse_n(v_x1_2434, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2434_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_PAs, 2, (V[]){v_x_2431, v_x_2436})});
      }
      default: return heff_nomatch(v_x1_2434);
      }
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epat(a[0]);
}
Clo g_heff_2eelab_2eclauses_2esameLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esameLit_entry, 2, 0};

V g_heff_2eelab_2eclauses_2esameLit(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      return NTAG(TAG_False);
    }
    case TAG_PatOp: {
      return NTAG(TAG_False);
    }
    case TAG_PatInt: {
      V v_x_2411 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2412 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          V v_y_2421 = heff_field(v_x21_2412, 0);
          return heff_intEq(heff_dup(v_x_2411), heff_dup(v_y_2421));
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2412);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatFloat: {
      V v_x_2430 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2431 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2431)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          V v_y_2441 = heff_field(v_x21_2431, 0);
          return heff_floatEq(heff_dup(v_x_2430), heff_dup(v_y_2441));
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2431);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatString: {
      V v_x_2449 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2450 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2450)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          V v_y_2461 = heff_field(v_x21_2450, 0);
          return heff_strEq(heff_dup(v_x_2449), heff_dup(v_y_2461));
        }
        case TAG_PatRune: {
          return NTAG(TAG_False);
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2450);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRune: {
      V v_x_2468 = heff_field(v_x11_242, 0);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_At: {
        V v_x21_2469 = heff_field(v_x2_241, 0);
        switch (heff_tag_of(v_x21_2469)) {
        case TAG_PatVar: {
          return NTAG(TAG_False);
        }
        case TAG_PatTag: {
          return NTAG(TAG_False);
        }
        case TAG_PatOp: {
          return NTAG(TAG_False);
        }
        case TAG_PatInt: {
          return NTAG(TAG_False);
        }
        case TAG_PatFloat: {
          return NTAG(TAG_False);
        }
        case TAG_PatString: {
          return NTAG(TAG_False);
        }
        case TAG_PatRune: {
          V v_y_2481 = heff_field(v_x21_2469, 0);
          return heff_intEq(heff_dup(v_x_2468), heff_dup(v_y_2481));
        }
        case TAG_PatRecord: {
          return NTAG(TAG_False);
        }
        case TAG_PatWord: {
          return NTAG(TAG_False);
        }
        case TAG_PatAs: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2469);
        }
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    case TAG_PatRecord: {
      return NTAG(TAG_False);
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2esameLit(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2elitExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitExpr_entry, 1, 0};

V g_heff_2eelab_2eclauses_2elitExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24At = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PatVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatTag: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatOp: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatInt: {
      V v_x_2410 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatInt = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_x_2410}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatInt, TAG_CInf, 1, (V[]){v_t_2411}), v_sp_242});
    }
    case TAG_PatFloat: {
      V v_x_2412 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatFloat = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2413 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IFloat, 1, (V[]){v_x_2412}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatFloat, TAG_CInf, 1, (V[]){v_t_2413}), v_sp_242});
    }
    case TAG_PatString: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatString = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2415 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IString, 1, (V[]){v_x_2414}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatString, TAG_CInf, 1, (V[]){v_t_2415}), v_sp_242});
    }
    case TAG_PatRune: {
      V v_x_2416 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24PatRune = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_t_2417 = heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_IRune, 1, (V[]){v_x_2416}), heff_dup(v_sp_242)});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241_24PatRune, TAG_CInf, 1, (V[]){v_t_2417}), v_sp_242});
    }
    case TAG_PatRecord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatWord: {
      heff_take_n(v_x11_241, 0ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    case TAG_PatAs: {
      heff_take_n(v_x11_241, 0ULL, 3);
      return heff_tag_at_n(v_ru_24x1_240_24At, TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2elitExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2elitExpr(a[0]);
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_243 = (g_heff_2eelab_2eclauses_2epat(v_x_241));
    switch (heff_tag_of(v_x1_243)) {
    case TAG_Left: {
      V v_e_244 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Left = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_243_24Left, TAG_Left, 1, (V[]){v_e_244});
    }
    case TAG_Right: {
      V v_x_245 = heff_field(v_x1_243, 0);
      V v_ru_24x1_243_24Right = heff_take_reuse_n(v_x1_243, 1ULL, 1);
      V v_x1_246 = (g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(v_xs_242));
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Left: {
        V v_e_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_245);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Left, 1, (V[]){v_e_247});
      }
      case TAG_Right: {
        V v_x_248 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_243_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_245, v_x_248})});
      }
      default: return heff_nomatch(v_x1_246);
      }
    }
    default: return heff_nomatch(v_x1_243);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(a[0]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatVars(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = heff_dup(v_a_244);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2epatVars(v_t_245));
    V v_t_247 = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_246, v_t_247));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatVars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatVars_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatVars(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_PVar: {
    V v_x_241 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
  }
  case TAG_PTag: {
    V v_ps_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    return ({ V a_0 = v_ps_243; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_243); r_; });
  }
  case TAG_PLit: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_PRec: {
    V v_fps_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 2);
    return ({ V a_0 = v_fps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_246); r_; });
  }
  case TAG_PAs: {
    V v_x_248 = heff_field(v_x1_240, 0);
    V v_p_249 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24PAs = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24PAs, TAG_Cons, 2, (V[]){v_x_248, (g_heff_2eelab_2eclauses_2epatVars(v_p_249))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatVars(a[0]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll(V v_f_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_acc_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){heff_dup(v_x_243), v_acc_242}));
    V t_0 = v_f_240;
    V t_1 = v_xs_244;
    V t_2 = v_t_245;
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2enamesOfAll(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      v_t_246 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, (g_heff_2eelab_2eclauses_2epatIdents(v_a_245, v_acc_241))});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_246;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epatIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epatIdents(V v_p_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_242 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      V v_x_244 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
    }
    case TAG_PatTag: {
      V v_ps_247 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_247; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_247); r_; });
    }
    case TAG_PatOp: {
      V v_x_248 = heff_field(v_p1_242, 0);
      V v_ps_2410 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_248, ({ V a_0 = v_ps_2410; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2410); r_; })});
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatRecord: {
      V v_fs_2415 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2415, v_acc_241);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return v_acc_241;
    }
    case TAG_PatAs: {
      V v_x_2417 = heff_field(v_p1_242, 0);
      V v_q_2419 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 5ULL, 3);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2417, (g_heff_2eelab_2eclauses_2epatIdents(v_q_2419, v_acc_241))});
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epiIdents_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epiIdents(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_t_245 = heff_field(v_x2_241, 2);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_245), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_t_246});
  }
  case TAG_PiImplicit: {
    V v_x_247 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_field(v_x2_241, 3);
    V v_d_2411 = heff_field(v_x2_241, 4);
    V v_t_2413;
    switch (heff_tag_of(v_d_2411)) {
    case TAG_Nothing: {
      v_t_2413 = v_acc_242;
      break;
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_d_2411, 0);
      v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_c_2412), v_acc_242}));
      break;
    }
    default: heff_nomatch(v_d_2411);
    }
    V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_2410), v_t_2413}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_247), v_t_2414});
  }
  case TAG_PiInstance: {
    V v_x_2415 = heff_field(v_x2_241, 0);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_t_2418), v_acc_242}));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2415), v_t_2419});
  }
  case TAG_PiAnon: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){heff_dup(v_d_2420), v_acc_242});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2epiIdents(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_x_242), v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_244;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    V v_ru_24n_241_24At = heff_take_reuse_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_IVar: {
      V v_x_245 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_245, v_acc_242});
    }
    case TAG_IInt: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IFloat: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IString: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_IApp: {
      V v_h_2410 = heff_field(v_n1_243, 0);
      V v_args_2411 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2421 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsInfF_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_args_2411; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2411); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_h_2410, v_t_2421});
    }
    case TAG_IAnn: {
      V v_c_2422 = heff_field(v_n1_243, 0);
      V v_t_2423 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2424 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 2, (V[]){v_t_2423, v_acc_242}));
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2422, v_t_2424});
    }
    case TAG_ISpec: {
      V v_a_2425 = heff_field(v_n1_243, 0);
      V v_v_2428 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 9ULL, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      V v_t_2429 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){v_v_2428, v_acc_242}));
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_a_2425, v_t_2429});
    }
    case TAG_IAnnLam: {
      V v_x_2430 = heff_field(v_n1_243, 0);
      V v_t_2432 = heff_field(v_n1_243, 2);
      V v_b_2433 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 13ULL, 4);
      V v_t_2434 = heff_tr(heff_call(heff_take_field(v_r_240, 0), 2, (V[]){v_b_2433, v_acc_242}));
      V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2432, v_t_2434}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2430, v_t_2435});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_243, 0ULL, 2);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return v_acc_242;
    }
    case TAG_INominal: {
      V v_i_2438 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24n_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2438, v_acc_242});
    }
    case TAG_ILitEq: {
      V v_x_2439 = heff_field(v_n1_243, 0);
      V v_eq_2441 = heff_field(v_n1_243, 2);
      V v_lit_2442 = heff_field(v_n1_243, 3);
      heff_take_n(v_n1_243, 13ULL, 4);
      V v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_lit_2442, v_acc_242}));
      return heff_tag_at_n(v_ru_24n_241_24At, TAG_Cons, 2, (V[]){v_x_2439, heff_tag_n(TAG_Cons, 2, (V[]){v_eq_2441, v_t_2443})});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsInfF_lam0(V self, V *args) {
  V v_x2_2412 = args[0];
  V v_acc_2413 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_At: {
    V v_x21_2414 = heff_field(v_x2_2412, 0);
    V v_ru_24x2_2412_24At = heff_take_reuse_n(v_x2_2412, 1ULL, 2);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_ArgExplicit: {
      V v_c_2416 = heff_field(v_x21_2414, 0);
      heff_take_n(v_x21_2414, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2412_24At, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      args[0] = v_c_2416;
      args[1] = v_acc_2413;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    case TAG_ArgProject: {
      heff_take_n(v_x21_2414, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24x2_2412_24At, 2);
      return v_acc_2413;
    }
    case TAG_ArgNamed: {
      V v_x_2418 = heff_field(v_x21_2414, 0);
      V v_c_2419 = heff_field(v_x21_2414, 1);
      heff_take_n(v_x21_2414, 3ULL, 2);
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2419, v_acc_2413}));
      return heff_tag_at_n(v_ru_24x2_2412_24At, TAG_Cons, 2, (V[]){v_x_2418, v_t_2420});
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsChkF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_CInf: {
      V v_i_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_245, v_acc_242});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_246, v_acc_242});
    }
    case TAG_CLam: {
      V v_x_247 = heff_field(v_x21_243, 0);
      V v_b_249 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_249, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_247, v_t_2410});
    }
    case TAG_CImplicitLam: {
      V v_x_2411 = heff_field(v_x21_243, 0);
      V v_b_2413 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2413, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2411, v_t_2414});
    }
    case TAG_CAnnLam: {
      V v_x_2415 = heff_field(v_x21_243, 0);
      V v_t_2417 = heff_field(v_x21_243, 2);
      V v_b_2418 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){v_b_2418, v_acc_242}));
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2417, v_t_2419}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2415, v_t_2420});
    }
    case TAG_CTag: {
      V v_args_2423 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = heff_get_n(v_r_240, 1, 4); V a_1 = v_args_2423; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2423); r_; });
    }
    case TAG_CStruct: {
      V v_fs_2424 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsChkF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_2424; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_2424); r_; });
    }
    case TAG_CMatch: {
      V v_s_2434 = heff_field(v_x21_243, 0);
      V v_alts_2435 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2443 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsChkF_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_alts_2435; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_alts_2435); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_s_2434, v_t_2443});
    }
    case TAG_CLetIn: {
      V v_rhs_2444 = heff_field(v_x21_243, 0);
      V v_a_2445 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2451;
      switch (heff_tag_of(v_a_2445)) {
      case TAG_At: {
        V v_x21_2446 = heff_field(v_a_2445, 0);
        heff_take_n(v_a_2445, 1ULL, 2);
        switch (heff_tag_of(v_x21_2446)) {
        case TAG_MkAlt: {
          V v_p_2448 = heff_field(v_x21_2446, 0);
          V v_b_2449 = heff_field(v_x21_2446, 1);
          heff_take_n(v_x21_2446, 3ULL, 2);
          V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_b_2449, v_acc_242}));
          v_t_2451 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2448, v_t_2450));
          break;
        }
        default: heff_nomatch(v_x21_2446);
        }
        break;
      }
      default: heff_nomatch(v_a_2445);
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_rhs_2444, v_t_2451});
    }
    case TAG_CLocal: {
      V v_body_2452 = heff_field(v_x21_243, 0);
      V v_ds_2453 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2454 = ({ V a_0 = heff_take_field(v_r_240, 3); V a_1 = v_ds_2453; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2453); r_; });
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_body_2452, v_t_2454});
    }
    case TAG_CAbandon: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return v_acc_242;
    }
    case TAG_CNominal: {
      V v_c_2455 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2455, v_acc_242});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_acc_2426 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_At: {
    V v_x21_2427 = heff_field(v_x2_2425, 0);
    V v_ru_24x2_2425_24At = heff_take_reuse_n(v_x2_2425, 1ULL, 2);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_SetField: {
      V v_x_2429 = heff_field(v_x21_2427, 0);
      V v_e_2431 = heff_field(v_x21_2427, 2);
      heff_take_n(v_x21_2427, 5ULL, 3);
      V v_t_2432 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2431, v_acc_2426}));
      return heff_tag_at_n(v_ru_24x2_2425_24At, TAG_Cons, 2, (V[]){v_x_2429, v_t_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2433 = heff_field(v_x21_2427, 0);
      heff_take_n(v_x21_2427, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2425_24At, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      args[0] = v_e_2433;
      args[1] = v_acc_2426;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam1(V self, V *args) {
  V v_a_2436 = args[0];
  V v_b_2437 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2436)) {
  case TAG_At: {
    V v_x21_2438 = heff_field(v_a_2436, 0);
    heff_take_n(v_a_2436, 1ULL, 2);
    switch (heff_tag_of(v_x21_2438)) {
    case TAG_MkAlt: {
      V v_p_2440 = heff_field(v_x21_2438, 0);
      V v_b_2441 = heff_field(v_x21_2438, 1);
      heff_take_n(v_x21_2438, 3ULL, 2);
      V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2441, v_b_2437}));
      return (g_heff_2eelab_2eclauses_2epatIdents(v_p_2440, v_t_2442));
    }
    default: return heff_nomatch(v_x21_2438);
    }
  }
  default: return heff_nomatch(v_a_2436);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF(V v_r_240, V v_n_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_243 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_n1_243)) {
    case TAG_TPi: {
      V v_b_245 = heff_field(v_n1_243, 0);
      V v_cod_246 = heff_field(v_n1_243, 1);
      heff_take_n(v_n1_243, 3ULL, 2);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){v_cod_246, v_acc_242}));
      return ({ V a_0 = v_r_240; V a_1 = v_b_245; V a_2 = v_t_247; V r_ = (g_heff_2eelab_2eclauses_2epiIdents(a_0, a_1, a_2)); heff_drop(v_b_245); r_; });
    }
    case TAG_TSig: {
      V v_fs_248 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_248; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_248); r_; });
    }
    case TAG_TSum: {
      V v_vs_2421 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsTypF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_vs_2421; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_vs_2421); r_; });
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TArray: {
      V v_a_2430 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_a_2430, v_acc_242});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_243, 0ULL, 1);
      heff_drop_rec(v_r_240, 4);
      return v_acc_242;
    }
    case TAG_TInf: {
      V v_i_2432 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_2432, v_acc_242});
    }
    case TAG_TChk: {
      V v_c_2433 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2433, v_acc_242});
    }
    case TAG_TNominal: {
      V v_t_2434 = heff_field(v_n1_243, 0);
      heff_take_n(v_n1_243, 1ULL, 1);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2434, v_acc_242});
    }
    default: return heff_nomatch(v_n1_243);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsTypF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam0(V self, V *args) {
  V v_x2_249 = args[0];
  V v_acc_2410 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_249)) {
  case TAG_At: {
    V v_x21_2411 = heff_field(v_x2_249, 0);
    V v_ru_24x2_249_24At = heff_take_reuse_n(v_x2_249, 1ULL, 2);
    switch (heff_tag_of(v_x21_2411)) {
    case TAG_DeclareField: {
      V v_x_2413 = heff_field(v_x21_2411, 0);
      V v_t_2415 = heff_field(v_x21_2411, 2);
      V v_d_2416 = heff_field(v_x21_2411, 3);
      heff_take_n(v_x21_2411, 13ULL, 4);
      V v_t_2418;
      switch (heff_tag_of(v_d_2416)) {
      case TAG_Nothing: {
        v_t_2418 = v_acc_2410;
        break;
      }
      case TAG_Just: {
        V v_c_2417 = heff_field(v_d_2416, 0);
        heff_take_n(v_d_2416, 1ULL, 1);
        v_t_2418 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_c_2417, v_acc_2410}));
        break;
      }
      default: heff_nomatch(v_d_2416);
      }
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2415, v_t_2418}));
      return heff_tag_at_n(v_ru_24x2_249_24At, TAG_Cons, 2, (V[]){v_x_2413, v_t_2419});
    }
    case TAG_BadFieldDecl: {
      V v_e_2420 = heff_field(v_x21_2411, 0);
      heff_take_n(v_x21_2411, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_249_24At, 2);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2420;
      args[1] = v_acc_2410;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2411);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_lam1(V self, V *args) {
  V v_x2_2422 = args[0];
  V v_acc_2423 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2422)) {
  case TAG_At: {
    V v_x21_2424 = heff_field(v_x2_2422, 0);
    heff_take_n(v_x2_2422, 1ULL, 2);
    switch (heff_tag_of(v_x21_2424)) {
    case TAG_TagVariant: {
      V v_args_2428 = heff_field(v_x21_2424, 2);
      heff_take_n(v_x21_2424, 4ULL, 3);
      return ({ V a_0 = heff_get_n(v_r_240, 2, 4); V a_1 = v_args_2428; V a_2 = v_acc_2423; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2428); r_; });
    }
    case TAG_BadVariant: {
      V v_e_2429 = heff_field(v_x21_2424, 0);
      heff_take_n(v_x21_2424, 1ULL, 1);
      V f_ = heff_get_n(v_r_240, 2, 4);
      args[0] = v_e_2429;
      args[1] = v_acc_2423;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2424);
    }
  }
  default: return heff_nomatch(v_x2_2422);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsDeclF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsDeclF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsDeclF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_DeclEquations: {
      V v_f_245 = heff_field(v_x21_243, 0);
      V v_ty_248 = heff_field(v_x21_243, 3);
      V v_eqs_249 = heff_field(v_x21_243, 4);
      heff_take_n(v_x21_243, 25ULL, 5);
      V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam0, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_eqs_249; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_eqs_249); r_; });
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_ty_248, v_t_2419}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_f_245, v_t_2420});
    }
    case TAG_DeclDefine: {
      V v_x_2421 = heff_field(v_x21_243, 0);
      V v_ps_2423 = heff_field(v_x21_243, 2);
      V v_u_2424 = heff_field(v_x21_243, 3);
      V v_body_2425 = heff_field(v_x21_243, 4);
      heff_take_n(v_x21_243, 29ULL, 5);
      V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_body_2425, v_acc_242}));
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 2, (V[]){v_u_2424, v_t_2426}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2421, ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam1, 2, 1, (V[]){v_r_240}); V a_1 = v_ps_2423; V a_2 = v_t_2427; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ps_2423); r_; })});
    }
    case TAG_DeclTheory: {
      V v_x_2440 = heff_field(v_x21_243, 0);
      V v_ps_2442 = heff_field(v_x21_243, 2);
      V v_body_2443 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      V v_t_2444 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_body_2443, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2440, ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsDeclF_lam2, 2, 1, (V[]){v_r_240}); V a_1 = v_ps_2442; V a_2 = v_t_2444; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ps_2442); r_; })});
    }
    case TAG_DeclPrimitive: {
      V v_x_2457 = heff_field(v_x21_243, 0);
      V v_t_2459 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2460 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2459, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2457, v_t_2460});
    }
    case TAG_DeclTest: {
      V v_x_2461 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 2);
      heff_drop_rec(v_r_240, 4);
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2461, v_acc_242});
    }
    case TAG_DeclWatch: {
      V v_e_2463 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2463, v_acc_242});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsDeclF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_a_2411 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2410)) {
  case TAG_At: {
    V v_x21_2412 = heff_field(v_m_2410, 0);
    V v_ru_24m_2410_24At = heff_take_reuse_n(v_m_2410, 1ULL, 2);
    switch (heff_tag_of(v_x21_2412)) {
    case TAG_MkEquation: {
      V v_f_2414 = heff_field(v_x21_2412, 0);
      V v_ps_2416 = heff_field(v_x21_2412, 2);
      V v_rhs_2417 = heff_field(v_x21_2412, 3);
      heff_take_n(v_x21_2412, 13ULL, 4);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_rhs_2417, v_a_2411}));
      return heff_tag_at_n(v_ru_24m_2410_24At, TAG_Cons, 2, (V[]){v_f_2414, ({ V a_0 = v_ps_2416; V a_1 = v_t_2418; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2051025357x705700905(a_0, a_1)); heff_drop(v_ps_2416); r_; })});
    }
    default: return heff_nomatch(v_x21_2412);
    }
  }
  default: return heff_nomatch(v_m_2410);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam1(V self, V *args) {
  V v_m_2428 = args[0];
  V v_a_2429 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2428)) {
  case TAG_At: {
    V v_x21_2430 = heff_field(v_m_2428, 0);
    V v_ru_24m_2428_24At = heff_take_reuse_n(v_m_2428, 1ULL, 2);
    switch (heff_tag_of(v_x21_2430)) {
    case TAG_ExplicitParam: {
      V v_x_2432 = heff_field(v_x21_2430, 0);
      V v_t_2434 = heff_field(v_x21_2430, 2);
      heff_take_n(v_x21_2430, 5ULL, 3);
      V v_t_2435 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2434, v_a_2429}));
      return heff_tag_at_n(v_ru_24m_2428_24At, TAG_Cons, 2, (V[]){v_x_2432, v_t_2435});
    }
    case TAG_ImplicitParam: {
      V v_x_2436 = heff_field(v_x21_2430, 0);
      V v_t_2438 = heff_field(v_x21_2430, 2);
      heff_take_n(v_x21_2430, 5ULL, 3);
      V v_t_2439 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2438, v_a_2429}));
      return heff_tag_at_n(v_ru_24m_2428_24At, TAG_Cons, 2, (V[]){v_x_2436, v_t_2439});
    }
    default: return heff_nomatch(v_x21_2430);
    }
  }
  default: return heff_nomatch(v_m_2428);
  }
}
V g_heff_2eelab_2eclauses_2eidentsDeclF_lam2(V self, V *args) {
  V v_m_2445 = args[0];
  V v_a_2446 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2445)) {
  case TAG_At: {
    V v_x21_2447 = heff_field(v_m_2445, 0);
    V v_ru_24m_2445_24At = heff_take_reuse_n(v_m_2445, 1ULL, 2);
    switch (heff_tag_of(v_x21_2447)) {
    case TAG_ExplicitParam: {
      V v_x_2449 = heff_field(v_x21_2447, 0);
      V v_t_2451 = heff_field(v_x21_2447, 2);
      heff_take_n(v_x21_2447, 5ULL, 3);
      V v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2451, v_a_2446}));
      return heff_tag_at_n(v_ru_24m_2445_24At, TAG_Cons, 2, (V[]){v_x_2449, v_t_2452});
    }
    case TAG_ImplicitParam: {
      V v_x_2453 = heff_field(v_x21_2447, 0);
      V v_t_2455 = heff_field(v_x21_2447, 2);
      heff_take_n(v_x21_2447, 5ULL, 3);
      V v_t_2456 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2455, v_a_2446}));
      return heff_tag_at_n(v_ru_24m_2445_24At, TAG_Cons, 2, (V[]){v_x_2453, v_t_2456});
    }
    default: return heff_nomatch(v_x21_2447);
    }
  }
  default: return heff_nomatch(v_m_2445);
  }
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam0, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam1, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam2, 2, 0};
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args); static Clo g_heff_2eelab_2eclauses_2eidents_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidents_lam3, 2, 0};

static V g_heff_2eelab_2eclauses_2eidents_val;
static HEFF_ONCE g_heff_2eelab_2eclauses_2eidents_st;
static V g_heff_2eelab_2eclauses_2eidents_init(void) {
  return heff_rec_n(4, shape_inf__chk__typ__decl, (V[]){((V)&g_heff_2eelab_2eclauses_2eidents_lam0_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam1_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam2_clo), ((V)&g_heff_2eelab_2eclauses_2eidents_lam3_clo)});
}
V g_heff_2eelab_2eclauses_2eidents_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eclauses_2eidents_st)) return g_heff_2eelab_2eclauses_2eidents_val;
  return heff_global(&g_heff_2eelab_2eclauses_2eidents_val, &g_heff_2eelab_2eclauses_2eidents_st, g_heff_2eelab_2eclauses_2eidents_init);
}
V g_heff_2eelab_2eclauses_2eidents_lam0(V self, V *args) {
  V v_n_240 = args[0];
  V v_acc_241 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsInfF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_240, v_acc_241));
}
V g_heff_2eelab_2eclauses_2eidents_lam1(V self, V *args) {
  V v_n_242 = args[0];
  V v_acc_243 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsChkF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_242, v_acc_243));
}
V g_heff_2eelab_2eclauses_2eidents_lam2(V self, V *args) {
  V v_n_244 = args[0];
  V v_acc_245 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsTypF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_n_244, v_acc_245));
}
V g_heff_2eelab_2eclauses_2eidents_lam3(V self, V *args) {
  V v_d_246 = args[0];
  V v_acc_247 = args[1];
  return (g_heff_2eelab_2eclauses_2eidentsDeclF(heff_dup(g_heff_2eelab_2eclauses_2eidents_get()), v_d_246, v_acc_247));
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_246, v_acc_241));
        break;
      }
      case TAG_ArgProject: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2410 = v_acc_241;
        break;
      }
      case TAG_ArgNamed: {
        V v_a_248 = heff_field(v_a_244, 0);
        V v_a_249 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_248, (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_249, v_acc_241))});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry, 2, 0};

V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_PiNamed: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_t_244 = heff_field(v_x2_240, 2);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_244, v_acc_241))});
  }
  case TAG_PiImplicit: {
    V v_x_245 = heff_field(v_x2_240, 0);
    V v_t_248 = heff_field(v_x2_240, 3);
    V v_d_249 = heff_field(v_x2_240, 4);
    V v_acc_2411;
    switch (heff_tag_of(v_d_249)) {
    case TAG_Nothing: {
      v_acc_2411 = v_acc_241;
      break;
    }
    case TAG_Just: {
      V v_c_2410 = heff_field(v_d_249, 0);
      v_acc_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_c_2410), v_acc_241));
      break;
    }
    default: heff_nomatch(v_d_249);
    }
    V v_t_2412 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_248, v_acc_2411));
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_245), v_t_2412});
  }
  case TAG_PiInstance: {
    V v_x_2413 = heff_field(v_x2_240, 0);
    V v_t_2416 = heff_field(v_x2_240, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2413), (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_t_2416, v_acc_241))});
  }
  case TAG_PiAnon: {
    V v_d_2417 = heff_field(v_x2_240, 0);
    HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_d_2417, v_acc_241);
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        heff_take_n(v_a_244, 13ULL, 4);
        V v_a_2411;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_a_2411 = v_acc_241;
          break;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          v_a_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_2410, v_acc_241));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        V v_t_2412 = ({ V a_0 = v_a_248; V a_1 = v_a_2411; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_a_248); r_; });
        v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_t_2412});
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2414 = ({ V a_0 = v_a_2413; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_a_2413); r_; });
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2414;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_TagVariant: {
        V v_a_248 = heff_field(v_a_244, 2);
        v_t_2410 = (g_heff_2eelab_2eclauses_2enamesOfAll(heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 2)), v_a_248, v_acc_241));
        break;
      }
      case TAG_BadVariant: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_a_249, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V v_n_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_242 = heff_field(v_n_240, 0);
    switch (heff_tag_of(v_n1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_n1_242, 0);
      V v_cod_245 = heff_field(v_n1_242, 1);
      V v_t_246 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_cod_245, v_acc_241));
      HEFF_LAST return g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(v_b_244, v_t_246);
    }
    case TAG_TSig: {
      V v_fs_247 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(heff_dup(v_fs_247), v_acc_241);
    }
    case TAG_TSum: {
      V v_vs_248 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s913976540x224039416(v_vs_248, v_acc_241);
    }
    case TAG_TType: {
      return v_acc_241;
    }
    case TAG_TInt: {
      return v_acc_241;
    }
    case TAG_TFloat: {
      return v_acc_241;
    }
    case TAG_TString: {
      return v_acc_241;
    }
    case TAG_TRune: {
      return v_acc_241;
    }
    case TAG_TArray: {
      V v_a_249 = heff_field(v_n1_242, 0);
      V t_0 = v_a_249;
      V t_1 = v_acc_241;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_TFixed: {
      return v_acc_241;
    }
    case TAG_TInf: {
      V v_i_2411 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(heff_dup(v_i_2411), v_acc_241);
    }
    case TAG_TChk: {
      V v_c_2412 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_c_2412), v_acc_241);
    }
    case TAG_TNominal: {
      V v_t_2413 = heff_field(v_n1_242, 0);
      V t_0 = v_t_2413;
      V t_1 = v_acc_241;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V v_n_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_242 = heff_field(v_n_240, 0);
    V v_ru_24n_240_24At = heff_take_reuse_n(v_n_240, 1ULL, 2);
    switch (heff_tag_of(v_n1_242)) {
    case TAG_IVar: {
      V v_x_244 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      return heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){v_x_244, v_acc_241});
    }
    case TAG_IInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IFloat: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_IApp: {
      V v_h_249 = heff_field(v_n1_242, 0);
      V v_args_2410 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2411 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(v_args_2410, v_acc_241));
      V t_0 = v_h_249;
      V t_1 = v_acc_2411;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_IAnn: {
      V v_c_2412 = heff_field(v_n1_242, 0);
      V v_t_2413 = heff_field(v_n1_242, 1);
      heff_take_n(v_n1_242, 3ULL, 2);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2414 = ({ V a_0 = v_t_2413; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2413); r_; });
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_c_2412, v_acc_2414);
    }
    case TAG_ISpec: {
      V v_a_2415 = heff_field(v_n1_242, 0);
      V v_v_2418 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 9ULL, 4);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V v_acc_2419 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_v_2418, v_acc_241));
      V t_0 = v_a_2415;
      V t_1 = v_acc_2419;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_IAnnLam: {
      V v_x_2420 = heff_field(v_n1_242, 0);
      V v_t_2422 = heff_field(v_n1_242, 2);
      V v_b_2423 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 13ULL, 4);
      V v_acc_2424 = (g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_b_2423, v_acc_241));
      V v_t_2425 = ({ V a_0 = v_t_2422; V a_1 = v_acc_2424; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2422); r_; });
      return heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){v_x_2420, v_t_2425});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_242, 0ULL, 2);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      return v_acc_241;
    }
    case TAG_INominal: {
      V v_i_2428 = heff_field(v_n1_242, 0);
      heff_take_n(v_n1_242, 1ULL, 1);
      heff_drop_cell(v_ru_24n_240_24At, 2);
      V t_0 = v_i_2428;
      V t_1 = v_acc_241;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_ILitEq: {
      V v_x_2429 = heff_field(v_n1_242, 0);
      V v_eq_2431 = heff_field(v_n1_242, 2);
      V v_lit_2432 = heff_field(v_n1_242, 3);
      heff_take_n(v_n1_242, 13ULL, 4);
      V v_t_2433 = heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){v_eq_2431, (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_lit_2432, v_acc_241))});
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, v_t_2433});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_SetField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        heff_take_n(v_a_244, 5ULL, 3);
        v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_248, v_acc_241))});
        break;
      }
      case TAG_BadFieldSet: {
        V v_a_249 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_249, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2410;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_249;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_MkAlt: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_247 = heff_field(v_a_244, 1);
        V v_t_248 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_247), v_acc_241));
        v_t_249 = (g_heff_2eelab_2eclauses_2epatIdents(heff_dup(v_a_246), v_t_248));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_249;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_CInf: {
      V v_i_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_i_244, v_acc_241);
    }
    case TAG_CType: {
      V v_t_245 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V a_0 = v_t_245; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_245); r_; });
    }
    case TAG_CLam: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_b_248 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_246, (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_248, v_acc_241))});
    }
    case TAG_CImplicitLam: {
      V v_x_249 = heff_field(v_x21_242, 0);
      V v_b_2411 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_249, (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2411, v_acc_241))});
    }
    case TAG_CAnnLam: {
      V v_x_2412 = heff_field(v_x21_242, 0);
      V v_t_2414 = heff_field(v_x21_242, 2);
      V v_b_2415 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_acc_2416 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2415, v_acc_241));
      V v_t_2417 = ({ V a_0 = v_t_2414; V a_1 = v_acc_2416; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2414); r_; });
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_2412, v_t_2417});
    }
    case TAG_CTag: {
      V v_args_2420 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_2420; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2420); r_; });
    }
    case TAG_CStruct: {
      V v_fs_2421 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_2421, v_acc_241);
    }
    case TAG_CMatch: {
      V v_s_2422 = heff_field(v_x21_242, 0);
      V v_alts_2423 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2424 = ({ V a_0 = v_alts_2423; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_2423); r_; });
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_s_2422, v_acc_2424);
    }
    case TAG_CLetIn: {
      V v_rhs_2425 = heff_field(v_x21_242, 0);
      V v_a_2426 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2432;
      switch (heff_tag_of(v_a_2426)) {
      case TAG_At: {
        V v_x21_2427 = heff_field(v_a_2426, 0);
        heff_take_n(v_a_2426, 1ULL, 2);
        switch (heff_tag_of(v_x21_2427)) {
        case TAG_MkAlt: {
          V v_p_2429 = heff_field(v_x21_2427, 0);
          V v_b_2430 = heff_field(v_x21_2427, 1);
          heff_take_n(v_x21_2427, 3ULL, 2);
          V v_t_2431 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2430, v_acc_241));
          v_acc_2432 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2429, v_t_2431));
          break;
        }
        default: heff_nomatch(v_x21_2427);
        }
        break;
      }
      default: heff_nomatch(v_a_2426);
      }
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_rhs_2425, v_acc_2432);
    }
    case TAG_CLocal: {
      V v_body_2433 = heff_field(v_x21_242, 0);
      V v_ds_2434 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2435 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_2434; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2434); r_; });
      V t_0 = v_body_2433;
      V t_1 = v_acc_2435;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return v_acc_241;
    }
    case TAG_CNominal: {
      V v_c_2436 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V t_0 = v_c_2436;
      V t_1 = v_acc_241;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2epatVars(heff_dup(v_x_242)));
    V v_t_245 = (g_heff_2eelab_2eclauses_2eappendC(v_t_244, v_acc_241));
    V t_0 = v_xs_243;
    V t_1 = v_t_245;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efresh_str0, 1, "'");
Clo g_heff_2eelab_2eclauses_2efresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efresh_entry, 2, 0};

V g_heff_2eelab_2eclauses_2efresh(V v_used_240, V v_x_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
  V v_t_243 = (g_list_2eany(v_t_242, v_used_240));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    V t_0 = v_used_240;
    V t_1 = heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2eclauses_2efresh_str0));
    v_used_240 = t_0;
    v_x_241 = t_1;
    goto top;
  }
  case TAG_False: {
    return v_x_241;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2efresh(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str0, 1, "'");
HEFF_LIT(g_heff_2eelab_2eclauses_2efreshIn_str1, 1, "'");
Clo g_heff_2eelab_2eclauses_2efreshIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efreshIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efreshIn(V v_used_240, V v_bound_241, V v_x_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
  V v_t_244 = (g_list_2eany(v_t_243, v_used_240));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V t_0 = v_used_240;
    V t_1 = v_bound_241;
    V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str0));
    v_used_240 = t_0;
    v_bound_241 = t_1;
    v_x_242 = t_2;
    goto top;
  }
  case TAG_False: {
    V v_t_245 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_246 = (g_list_2eany(v_t_245, v_bound_241));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V t_0 = v_used_240;
      V t_1 = v_bound_241;
      V t_2 = heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2eclauses_2efreshIn_str1));
      v_used_240 = t_0;
      v_bound_241 = t_1;
      v_x_242 = t_2;
      goto top;
    }
    case TAG_False: {
      return v_x_242;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2efreshIn(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2epatBinds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatBinds_entry, 1, 0};

V g_heff_2eelab_2eclauses_2epatBinds(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      V v_x_243 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_246); r_; });
    }
    case TAG_PatOp: {
      V v_ps_249 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_ps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1798074262x679590687(a_0)); heff_drop(v_ps_249); r_; });
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatRecord: {
      V v_fs_2414 = heff_field(v_p1_241, 0);
      heff_take_n(v_p1_241, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return ({ V a_0 = v_fs_2414; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a_0)); heff_drop(v_fs_2414); r_; });
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_241, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_PatAs: {
      V v_x_2416 = heff_field(v_p1_241, 0);
      V v_q_2418 = heff_field(v_p1_241, 2);
      heff_take_n(v_p1_241, 5ULL, 3);
      return heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2416, (g_heff_2eelab_2eclauses_2epatBinds(v_q_2418))});
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatBinds(a[0]);
}
Clo g_heff_2eelab_2eclauses_2erenameSeq_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameSeq_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erenameSeq(V v_f_240, V v_b_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    heff_drop(v_b_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_m_243)}));
    V v_t_246 = heff_tr(heff_call(heff_dup(v_b_241), 1, (V[]){v_m_243}));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_f_240);
      heff_drop(v_b_241);
      v_t_247 = v_rest_244;
      break;
    }
    case TAG_False: {
      v_t_247 = (g_heff_2eelab_2eclauses_2erenameSeq(v_f_240, v_b_241, v_rest_244));
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_247});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erenameSeq_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameSeq(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2erenameAlt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameAlt_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameAlt(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkAlt: {
      V v_p_244 = heff_field(v_x21_242, 0);
      V v_b_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_xs_246 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_p_244)));
      V v_t_247 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_take_field(v_r_240, 0)}));
      V v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_xs_246; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_246); r_; });
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 5);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_b_245}), v_sp_243});
      }
      case TAG_False: {
        V v_t_249 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_245}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_244, v_t_249}), v_sp_243});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameAlt(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2erenameField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameField(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclareField: {
      V v_y_244 = heff_field(v_x21_242, 0);
      V v_ysp_245 = heff_field(v_x21_242, 1);
      V v_t_246 = heff_field(v_x21_242, 2);
      V v_d_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_248 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_246}));
      V v_t_2411;
      switch (heff_tag_of(v_d_247)) {
      case TAG_Nothing: {
        heff_drop_rec(v_r_240, 5);
        v_t_2411 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_c_249 = heff_field(v_d_247, 0);
        V v_ru_24d_247_24Just = heff_take_reuse_n(v_d_247, 1ULL, 1);
        V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_249}));
        v_t_2411 = heff_tag_at_n(v_ru_24d_247_24Just, TAG_Just, 1, (V[]){v_t_2410});
        break;
      }
      default: heff_nomatch(v_d_247);
      }
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_DeclareField, 4, (V[]){v_y_244, v_ysp_245, v_t_248, v_t_2411}), v_sp_243});
    }
    case TAG_BadFieldDecl: {
      V v_e_2412 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2412}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldDecl, 1, (V[]){v_t_2413}), v_sp_243});
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameField_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameField(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameEquation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameEquation_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameEquation(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkEquation: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_ps_246 = heff_field(v_x21_242, 2);
      V v_rhs_247 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 15ULL, 4);
      V v_t_2411 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameEquation_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), v_ps_246));
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop_rec(v_r_240, 5);
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_rhs_247}), v_sp_243});
      }
      case TAG_False: {
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_rhs_247}));
        return heff_tag_at_n(v_ru_24x2_241_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_244, v_fsp_245, v_ps_246, v_t_2412}), v_sp_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameEquation_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameEquation(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameEquation_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_xs_249 = (g_heff_2eelab_2eclauses_2epatBinds(v_p_248));
  V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_get_n(v_r_240, 0, 5)}));
  return ({ V a_0 = v_t_2410; V a_1 = v_xs_249; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_xs_249); r_; });
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam2(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam3(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam4(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam5(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameDecl_lam6(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameDecl_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameDecl(V v_r_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_d_241)) {
  case TAG_At: {
    V v_d1_242 = heff_dup(heff_field(v_d_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_d_241, 1));
    switch (heff_tag_of(v_d1_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_d1_242, 0);
      V v_fsp_245 = heff_field(v_d1_242, 1);
      V v_declared_246 = heff_field(v_d1_242, 2);
      V v_ty_247 = heff_field(v_d1_242, 3);
      V v_eqs_248 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclEquations = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      heff_drop_tag(v_d_241, 2);
      V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_ty_247}));
      V v_t_2412;
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_f_244))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2412 = v_eqs_248;
      } else {
        V v_t_2411 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameEquation_clo), 1, (V[]){v_r_240}));
        v_t_2412 = (g_list_2emap(v_t_2411, v_eqs_248));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclEquations, TAG_DeclEquations, 5, (V[]){v_f_244, v_fsp_245, v_declared_246, v_t_249, v_t_2412}), v_sp_243});
    }
    case TAG_DeclDefine: {
      V v_y_2413 = heff_field(v_d1_242, 0);
      V v_ysp_2414 = heff_field(v_d1_242, 1);
      V v_ps_2415 = heff_field(v_d1_242, 2);
      V v_u_2416 = heff_field(v_d1_242, 3);
      V v_body_2417 = heff_field(v_d1_242, 4);
      V v_ru_24d1_242_24DeclDefine = heff_take_reuse_n(v_d1_242, 31ULL, 5);
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2413))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2413);
        heff_drop(v_ysp_2414);
        heff_drop(v_ps_2415);
        heff_drop(v_u_2416);
        heff_drop(v_body_2417);
        heff_drop_cell(v_ru_24d1_242_24DeclDefine, 5);
        return v_d_241;
      } else {
        heff_drop_tag(v_d_241, 2);
        V v_x_2419 = heff_dup(heff_rfield(v_r_240, 0));
        V v_t_2440 = (g_heff_2eelab_2eclauses_2erenameSeq(heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam1, 1, 1, (V[]){v_x_2419}), heff_dup(v_ps_2415)));
        V v_x_2441 = heff_dup(heff_rfield(v_r_240, 0));
        V v_t_2451 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam2, 1, 1, (V[]){v_x_2441}), v_ps_2415));
        V v_t_2452;
        switch (heff_tag_of(v_t_2451)) {
        case TAG_True: {
          v_t_2452 = v_u_2416;
          break;
        }
        case TAG_False: {
          v_t_2452 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 4)), 1, (V[]){v_u_2416}));
          break;
        }
        default: heff_nomatch(v_t_2451);
        }
        V v_x_2453 = heff_take_field(v_r_240, 0);
        V v_t_2463 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam3, 1, 1, (V[]){v_x_2453}); V a_1 = v_ps_2415; V r_ = (g_heff_2eelab_2eclauses_2eanyC(a_0, a_1)); heff_drop(v_ps_2415); r_; });
        V v_t_2464;
        switch (heff_tag_of(v_t_2463)) {
        case TAG_True: {
          heff_drop_rec(v_r_240, 5);
          v_t_2464 = v_body_2417;
          break;
        }
        case TAG_False: {
          v_t_2464 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2417}));
          break;
        }
        default: heff_nomatch(v_t_2463);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclDefine, TAG_DeclDefine, 5, (V[]){v_y_2413, v_ysp_2414, v_t_2440, v_t_2452, v_t_2464}), v_sp_243});
      }
    }
    case TAG_DeclTheory: {
      V v_y_2465 = heff_field(v_d1_242, 0);
      V v_ysp_2466 = heff_field(v_d1_242, 1);
      V v_ps_2467 = heff_field(v_d1_242, 2);
      V v_body_2468 = heff_field(v_d1_242, 3);
      V v_ru_24d1_242_24DeclTheory = heff_take_reuse_n(v_d1_242, 15ULL, 4);
      if (heff_strEq_c(heff_dup(heff_rfield(v_r_240, 0)), heff_dup(v_y_2465))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2465);
        heff_drop(v_ysp_2466);
        heff_drop(v_ps_2467);
        heff_drop(v_body_2468);
        heff_drop_cell(v_ru_24d1_242_24DeclTheory, 4);
        return v_d_241;
      } else {
        heff_drop_tag(v_d_241, 2);
        V v_x_2470 = heff_dup(heff_rfield(v_r_240, 0));
        V v_t_2491 = (g_heff_2eelab_2eclauses_2erenameSeq(heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam4, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam5, 1, 1, (V[]){v_x_2470}), heff_dup(v_ps_2467)));
        V v_x_2492 = heff_take_field(v_r_240, 0);
        V v_t_24102 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2erenameDecl_lam6, 1, 1, (V[]){v_x_2492}); V a_1 = v_ps_2467; V r_ = (g_heff_2eelab_2eclauses_2eanyC(a_0, a_1)); heff_drop(v_ps_2467); r_; });
        V v_t_24103;
        switch (heff_tag_of(v_t_24102)) {
        case TAG_True: {
          heff_drop_rec(v_r_240, 5);
          v_t_24103 = v_body_2468;
          break;
        }
        case TAG_False: {
          v_t_24103 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_body_2468}));
          break;
        }
        default: heff_nomatch(v_t_24102);
        }
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclTheory, TAG_DeclTheory, 4, (V[]){v_y_2465, v_ysp_2466, v_t_2491, v_t_24103}), v_sp_243});
      }
    }
    case TAG_DeclPrimitive: {
      V v_y_24104 = heff_field(v_d1_242, 0);
      V v_ysp_24105 = heff_field(v_d1_242, 1);
      V v_t_24106 = heff_field(v_d1_242, 2);
      V v_ru_24d1_242_24DeclPrimitive = heff_take_reuse_n(v_d1_242, 7ULL, 3);
      heff_drop_tag(v_d_241, 2);
      V v_t_24107 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_24106}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclPrimitive, TAG_DeclPrimitive, 3, (V[]){v_y_24104, v_ysp_24105, v_t_24107}), v_sp_243});
    }
    case TAG_DeclTest: {
      heff_take_n(v_d1_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_d_241;
    }
    case TAG_DeclWatch: {
      V v_e_24110 = heff_field(v_d1_242, 0);
      V v_ru_24d1_242_24DeclWatch = heff_take_reuse_n(v_d1_242, 1ULL, 1);
      heff_drop_tag(v_d_241, 2);
      V v_t_24111 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_24110}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24d1_242_24DeclWatch, TAG_DeclWatch, 1, (V[]){v_t_24111}), v_sp_243});
    }
    default: return heff_nomatch(v_d1_242);
    }
  }
  default: return heff_nomatch(v_d_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameDecl(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam0(V self, V *args) {
  V v_x2_2420 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_At: {
    V v_x21_2421 = heff_field(v_x2_2420, 0);
    V v_sp_2422 = heff_field(v_x2_2420, 1);
    V v_ru_24x2_2420_24At = heff_take_reuse_n(v_x2_2420, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_ExplicitParam: {
      V v_y_2423 = heff_field(v_x21_2421, 0);
      V v_ysp_2424 = heff_field(v_x21_2421, 1);
      V v_t_2425 = heff_field(v_x21_2421, 2);
      heff_take_n(v_x21_2421, 7ULL, 3);
      V v_t_2426 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2425}));
      return heff_tag_at_n(v_ru_24x2_2420_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_y_2423, v_ysp_2424, v_t_2426}), v_sp_2422});
    }
    case TAG_ImplicitParam: {
      V v_y_2427 = heff_field(v_x21_2421, 0);
      V v_ysp_2428 = heff_field(v_x21_2421, 1);
      V v_t_2429 = heff_field(v_x21_2421, 2);
      heff_take_n(v_x21_2421, 7ULL, 3);
      V v_t_2430 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2429}));
      return heff_tag_at_n(v_ru_24x2_2420_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_y_2427, v_ysp_2428, v_t_2430}), v_sp_2422});
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam1(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_At: {
    V v_x21_2432 = heff_field(v_x2_2431, 0);
    heff_take_n(v_x2_2431, 1ULL, 2);
    switch (heff_tag_of(v_x21_2432)) {
    case TAG_ExplicitParam: {
      V v_y_2434 = heff_field(v_x21_2432, 0);
      heff_take_n(v_x21_2432, 1ULL, 3);
      return heff_strEq(v_x_2419, v_y_2434);
    }
    case TAG_ImplicitParam: {
      V v_y_2437 = heff_field(v_x21_2432, 0);
      heff_take_n(v_x21_2432, 1ULL, 3);
      return heff_strEq(v_x_2419, v_y_2437);
    }
    default: return heff_nomatch(v_x21_2432);
    }
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam2(V self, V *args) {
  V v_x2_2442 = args[0];
  V v_x_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2442)) {
  case TAG_At: {
    V v_x21_2443 = heff_field(v_x2_2442, 0);
    heff_take_n(v_x2_2442, 1ULL, 2);
    switch (heff_tag_of(v_x21_2443)) {
    case TAG_ExplicitParam: {
      V v_y_2445 = heff_field(v_x21_2443, 0);
      heff_take_n(v_x21_2443, 1ULL, 3);
      return heff_strEq(v_x_2441, v_y_2445);
    }
    case TAG_ImplicitParam: {
      V v_y_2448 = heff_field(v_x21_2443, 0);
      heff_take_n(v_x21_2443, 1ULL, 3);
      return heff_strEq(v_x_2441, v_y_2448);
    }
    default: return heff_nomatch(v_x21_2443);
    }
  }
  default: return heff_nomatch(v_x2_2442);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam3(V self, V *args) {
  V v_x2_2454 = args[0];
  V v_x_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2454)) {
  case TAG_At: {
    V v_x21_2455 = heff_field(v_x2_2454, 0);
    heff_take_n(v_x2_2454, 1ULL, 2);
    switch (heff_tag_of(v_x21_2455)) {
    case TAG_ExplicitParam: {
      V v_y_2457 = heff_field(v_x21_2455, 0);
      heff_take_n(v_x21_2455, 1ULL, 3);
      return heff_strEq(v_x_2453, v_y_2457);
    }
    case TAG_ImplicitParam: {
      V v_y_2460 = heff_field(v_x21_2455, 0);
      heff_take_n(v_x21_2455, 1ULL, 3);
      return heff_strEq(v_x_2453, v_y_2460);
    }
    default: return heff_nomatch(v_x21_2455);
    }
  }
  default: return heff_nomatch(v_x2_2454);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam4(V self, V *args) {
  V v_x2_2471 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_At: {
    V v_x21_2472 = heff_field(v_x2_2471, 0);
    V v_sp_2473 = heff_field(v_x2_2471, 1);
    V v_ru_24x2_2471_24At = heff_take_reuse_n(v_x2_2471, 3ULL, 2);
    switch (heff_tag_of(v_x21_2472)) {
    case TAG_ExplicitParam: {
      V v_y_2474 = heff_field(v_x21_2472, 0);
      V v_ysp_2475 = heff_field(v_x21_2472, 1);
      V v_t_2476 = heff_field(v_x21_2472, 2);
      heff_take_n(v_x21_2472, 7ULL, 3);
      V v_t_2477 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2476}));
      return heff_tag_at_n(v_ru_24x2_2471_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_y_2474, v_ysp_2475, v_t_2477}), v_sp_2473});
    }
    case TAG_ImplicitParam: {
      V v_y_2478 = heff_field(v_x21_2472, 0);
      V v_ysp_2479 = heff_field(v_x21_2472, 1);
      V v_t_2480 = heff_field(v_x21_2472, 2);
      heff_take_n(v_x21_2472, 7ULL, 3);
      V v_t_2481 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2480}));
      return heff_tag_at_n(v_ru_24x2_2471_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_ImplicitParam, 3, (V[]){v_y_2478, v_ysp_2479, v_t_2481}), v_sp_2473});
    }
    default: return heff_nomatch(v_x21_2472);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam5(V self, V *args) {
  V v_x2_2482 = args[0];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2482)) {
  case TAG_At: {
    V v_x21_2483 = heff_field(v_x2_2482, 0);
    heff_take_n(v_x2_2482, 1ULL, 2);
    switch (heff_tag_of(v_x21_2483)) {
    case TAG_ExplicitParam: {
      V v_y_2485 = heff_field(v_x21_2483, 0);
      heff_take_n(v_x21_2483, 1ULL, 3);
      return heff_strEq(v_x_2470, v_y_2485);
    }
    case TAG_ImplicitParam: {
      V v_y_2488 = heff_field(v_x21_2483, 0);
      heff_take_n(v_x21_2483, 1ULL, 3);
      return heff_strEq(v_x_2470, v_y_2488);
    }
    default: return heff_nomatch(v_x21_2483);
    }
  }
  default: return heff_nomatch(v_x2_2482);
  }
}
V g_heff_2eelab_2eclauses_2erenameDecl_lam6(V self, V *args) {
  V v_x2_2493 = args[0];
  V v_x_2492 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2493)) {
  case TAG_At: {
    V v_x21_2494 = heff_field(v_x2_2493, 0);
    heff_take_n(v_x2_2493, 1ULL, 2);
    switch (heff_tag_of(v_x21_2494)) {
    case TAG_ExplicitParam: {
      V v_y_2496 = heff_field(v_x21_2494, 0);
      heff_take_n(v_x21_2494, 1ULL, 3);
      return heff_strEq(v_x_2492, v_y_2496);
    }
    case TAG_ImplicitParam: {
      V v_y_2499 = heff_field(v_x21_2494, 0);
      heff_take_n(v_x21_2494, 1ULL, 3);
      return heff_strEq(v_x_2492, v_y_2499);
    }
    default: return heff_nomatch(v_x21_2494);
    }
  }
  default: return heff_nomatch(v_x2_2493);
  }
}
Clo g_heff_2eelab_2eclauses_2erenamePi_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamePi_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamePi(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_PiNamed: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ysp_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24PiNamed = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_244}));
    return heff_tag_at_n(v_ru_24x2_241_24PiNamed, TAG_PiNamed, 3, (V[]){v_y_242, v_ysp_243, v_t_245});
  }
  case TAG_PiImplicit: {
    V v_y_246 = heff_field(v_x2_241, 0);
    V v_ysp_247 = heff_field(v_x2_241, 1);
    V v_bsp_248 = heff_field(v_x2_241, 2);
    V v_t_249 = heff_field(v_x2_241, 3);
    V v_d_2410 = heff_field(v_x2_241, 4);
    V v_ru_24x2_241_24PiImplicit = heff_take_reuse_n(v_x2_241, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_249}));
    V v_t_2414;
    switch (heff_tag_of(v_d_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_240, 5);
      v_t_2414 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_c_2412 = heff_field(v_d_2410, 0);
      V v_ru_24d_2410_24Just = heff_take_reuse_n(v_d_2410, 1ULL, 1);
      V v_t_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2412}));
      v_t_2414 = heff_tag_at_n(v_ru_24d_2410_24Just, TAG_Just, 1, (V[]){v_t_2413});
      break;
    }
    default: heff_nomatch(v_d_2410);
    }
    return heff_tag_at_n(v_ru_24x2_241_24PiImplicit, TAG_PiImplicit, 5, (V[]){v_y_246, v_ysp_247, v_bsp_248, v_t_2411, v_t_2414});
  }
  case TAG_PiInstance: {
    V v_y_2415 = heff_field(v_x2_241, 0);
    V v_ysp_2416 = heff_field(v_x2_241, 1);
    V v_bsp_2417 = heff_field(v_x2_241, 2);
    V v_t_2418 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24PiInstance = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_t_2419 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2418}));
    return heff_tag_at_n(v_ru_24x2_241_24PiInstance, TAG_PiInstance, 4, (V[]){v_y_2415, v_ysp_2416, v_bsp_2417, v_t_2419});
  }
  case TAG_PiAnon: {
    V v_d_2420 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24PiAnon = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2421 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_d_2420}));
    return heff_tag_at_n(v_ru_24x2_241_24PiAnon, TAG_PiAnon, 1, (V[]){v_t_2421});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2erenamePi_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamePi(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameInfF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameInfF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameInfF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_IVar: {
      V v_y_244 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24IVar = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      if (heff_strEq_c(v_y_244, heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_tag(v_n_241, 2);
        V v_t_246 = heff_tag_at_n(v_ru_24n1_242_24IVar, TAG_IVar, 1, (V[]){heff_get_n(v_r_240, 1, 5)});
        return heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_243});
      } else {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop_cell(v_ru_24n1_242_24IVar, 1);
        return v_n_241;
      }
    }
    case TAG_IInt: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IFloat: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IString: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IRune: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_IApp: {
      V v_h_2411 = heff_field(v_n1_242, 0);
      V v_args_2412 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IApp = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_h_2411}));
      V v_t_2423 = heff_tag_at_n(v_ru_24n1_242_24IApp, TAG_IApp, 2, (V[]){v_t_2413, (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameInfF_lam0, 1, 1, (V[]){v_r_240}), v_args_2412))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_sp_243});
    }
    case TAG_IAnn: {
      V v_c_2424 = heff_field(v_n1_242, 0);
      V v_t_2425 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24IAnn = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_r_240, 3), 1, (V[]){v_c_2424}));
      V v_t_2427 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2425}));
      return heff_tag_at_n(v_ru_24n1_242_24IAnn, TAG_At, 2, (V[]){heff_tag_n(TAG_IAnn, 2, (V[]){v_t_2426, v_t_2427}), v_sp_243});
    }
    case TAG_ISpec: {
      V v_a_2428 = heff_field(v_n1_242, 0);
      V v_f_2429 = heff_field(v_n1_242, 1);
      V v_fsp_2430 = heff_field(v_n1_242, 2);
      V v_val_2431 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24ISpec = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2432 = heff_tr(heff_call(heff_take_field(v_r_240, 2), 1, (V[]){v_a_2428}));
      V v_t_2433 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_val_2431}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24ISpec, TAG_ISpec, 4, (V[]){v_t_2432, v_f_2429, v_fsp_2430, v_t_2433}), v_sp_243});
    }
    case TAG_IAnnLam: {
      V v_y_2434 = heff_field(v_n1_242, 0);
      V v_ysp_2435 = heff_field(v_n1_242, 1);
      V v_t_2436 = heff_field(v_n1_242, 2);
      V v_b_2437 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24IAnnLam = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2438 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_2436}));
      V v_t_2440;
      if (heff_strEq_c(heff_dup(v_y_2434), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2440 = v_b_2437;
      } else {
        v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_b_2437}));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24IAnnLam, TAG_IAnnLam, 4, (V[]){v_y_2434, v_ysp_2435, v_t_2438, v_t_2440}), v_sp_243});
    }
    case TAG_IInvalid: {
      heff_take_n(v_n1_242, 0ULL, 2);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_INominal: {
      V v_i_2443 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24INominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2444 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2443}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24INominal, TAG_INominal, 1, (V[]){v_t_2444}), v_sp_243});
    }
    case TAG_ILitEq: {
      V v_y_2445 = heff_field(v_n1_242, 0);
      V v_ysp_2446 = heff_field(v_n1_242, 1);
      V v_eq_2447 = heff_field(v_n1_242, 2);
      V v_lit_2448 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24ILitEq = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2450;
      if (heff_strEq_c(heff_dup(v_y_2445), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop(v_y_2445);
        v_t_2450 = heff_dup(heff_rfield(v_r_240, 1));
      } else {
        v_t_2450 = v_y_2445;
      }
      V v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_lit_2448}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24ILitEq, TAG_ILitEq, 4, (V[]){v_t_2450, v_ysp_2446, v_eq_2447, v_t_2451}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameInfF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameInfF_lam0(V self, V *args) {
  V v_a_2414 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2414)) {
  case TAG_At: {
    V v_a1_2415 = heff_dup(heff_field(v_a_2414, 0));
    V v_sp_2416 = heff_dup(heff_field(v_a_2414, 1));
    switch (heff_tag_of(v_a1_2415)) {
    case TAG_ArgExplicit: {
      V v_c_2417 = heff_field(v_a1_2415, 0);
      V v_ru_24a1_2415_24ArgExplicit = heff_take_reuse_n(v_a1_2415, 1ULL, 1);
      heff_drop_tag(v_a_2414, 2);
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2417}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24a1_2415_24ArgExplicit, TAG_ArgExplicit, 1, (V[]){v_t_2418}), v_sp_2416});
    }
    case TAG_ArgProject: {
      heff_take_n(v_a1_2415, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_2416);
      return v_a_2414;
    }
    case TAG_ArgNamed: {
      V v_y_2420 = heff_field(v_a1_2415, 0);
      V v_c_2421 = heff_field(v_a1_2415, 1);
      V v_ru_24a1_2415_24ArgNamed = heff_take_reuse_n(v_a1_2415, 3ULL, 2);
      heff_drop_tag(v_a_2414, 2);
      V v_t_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2421}));
      return heff_tag_at_n(v_ru_24a1_2415_24ArgNamed, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgNamed, 2, (V[]){v_y_2420, v_t_2422}), v_sp_2416});
    }
    default: return heff_nomatch(v_a1_2415);
    }
  }
  default: return heff_nomatch(v_a_2414);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameChkF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameChkF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameChkF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameChkF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_CInf: {
      V v_i_244 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_244}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_243});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CType = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_246}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CType, TAG_CType, 1, (V[]){v_t_247}), v_sp_243});
    }
    case TAG_CLam: {
      V v_y_248 = heff_field(v_n1_242, 0);
      V v_ysp_249 = heff_field(v_n1_242, 1);
      V v_b_2410 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CLam = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_y_248), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_248);
        heff_drop(v_ysp_249);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24n1_242_24CLam, 3);
        return v_n_241;
      } else {
        heff_drop_tag(v_n_241, 2);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2410}));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CLam, TAG_CLam, 3, (V[]){v_y_248, v_ysp_249, v_t_2412}), v_sp_243});
      }
    }
    case TAG_CImplicitLam: {
      V v_y_2413 = heff_field(v_n1_242, 0);
      V v_ysp_2414 = heff_field(v_n1_242, 1);
      V v_b_2415 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CImplicitLam = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_y_2413), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2413);
        heff_drop(v_ysp_2414);
        heff_drop(v_b_2415);
        heff_drop_cell(v_ru_24n1_242_24CImplicitLam, 3);
        return v_n_241;
      } else {
        heff_drop_tag(v_n_241, 2);
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2415}));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_y_2413, v_ysp_2414, v_t_2417}), v_sp_243});
      }
    }
    case TAG_CAnnLam: {
      V v_y_2418 = heff_field(v_n1_242, 0);
      V v_ysp_2419 = heff_field(v_n1_242, 1);
      V v_t_2420 = heff_field(v_n1_242, 2);
      V v_b_2421 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24CAnnLam = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2422 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_2420}));
      V v_t_2424;
      if (heff_strEq_c(heff_dup(v_y_2418), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2424 = v_b_2421;
      } else {
        v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2421}));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_y_2418, v_ysp_2419, v_t_2422, v_t_2424}), v_sp_243});
    }
    case TAG_CTag: {
      V v_t_2425 = heff_field(v_n1_242, 0);
      V v_tsp_2426 = heff_field(v_n1_242, 1);
      V v_args_2427 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CTag = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      heff_drop_tag(v_n_241, 2);
      V v_t_2428 = heff_tag_at_n(v_ru_24n1_242_24CTag, TAG_CTag, 3, (V[]){v_t_2425, v_tsp_2426, (g_list_2emap(heff_get_n(v_r_240, 3, 5), v_args_2427))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2428, v_sp_243});
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CStruct = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2439 = heff_tag_at_n(v_ru_24n1_242_24CStruct, TAG_CStruct, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam0, 1, 1, (V[]){v_r_240}), v_fs_2429))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2439, v_sp_243});
    }
    case TAG_CMatch: {
      V v_s_2440 = heff_field(v_n1_242, 0);
      V v_alts_2441 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CMatch = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_s_2440}));
      V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameAlt_clo), 1, (V[]){v_r_240}));
      V v_t_2444 = heff_tag_at_n(v_ru_24n1_242_24CMatch, TAG_CMatch, 2, (V[]){v_t_2442, (g_list_2emap(v_t_2443, v_alts_2441))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_243});
    }
    case TAG_CLetIn: {
      V v_rhs_2445 = heff_field(v_n1_242, 0);
      V v_a_2446 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CLetIn = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_rhs_2445}));
      V v_t_2448 = heff_tag_at_n(v_ru_24n1_242_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2447, (g_heff_2eelab_2eclauses_2erenameAlt(v_r_240, v_a_2446))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_243});
    }
    case TAG_CLocal: {
      V v_body_2449 = heff_field(v_n1_242, 0);
      V v_ds_2450 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CLocal = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2476 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam1, 1, 1, (V[]){heff_dup(v_r_240)}), v_ds_2450));
      V v_t_2477;
      switch (heff_tag_of(v_t_2476)) {
      case TAG_True: {
        v_t_2477 = v_body_2449;
        break;
      }
      case TAG_False: {
        v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 3)), 1, (V[]){v_body_2449}));
        break;
      }
      default: heff_nomatch(v_t_2476);
      }
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameDecl_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_24104 = heff_tag_at_n(v_ru_24n1_242_24CLocal, TAG_CLocal, 2, (V[]){v_t_2477, (g_heff_2eelab_2eclauses_2erenameSeq(v_t_2478, heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam2, 1, 1, (V[]){v_r_240}), v_ds_2450))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_24104, v_sp_243});
    }
    case TAG_CAbandon: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_CNominal: {
      V v_c_24105 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_24106 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_24105}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CNominal, TAG_CNominal, 1, (V[]){v_t_24106}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameChkF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam0(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_At: {
    V v_x21_2431 = heff_field(v_x2_2430, 0);
    V v_sp_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24At = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_SetField: {
      V v_y_2433 = heff_field(v_x21_2431, 0);
      V v_ysp_2434 = heff_field(v_x21_2431, 1);
      V v_e_2435 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 7ULL, 3);
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2435}));
      return heff_tag_at_n(v_ru_24x2_2430_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_y_2433, v_ysp_2434, v_t_2436}), v_sp_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2437 = heff_field(v_x21_2431, 0);
      heff_take_n(v_x21_2431, 1ULL, 1);
      V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2437}));
      return heff_tag_at_n(v_ru_24x2_2430_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_t_2438}), v_sp_2432});
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam1(V self, V *args) {
  V v_d_2451 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474;
  switch (heff_tag_of(v_d_2451)) {
  case TAG_At: {
    V v_x11_2452 = heff_field(v_d_2451, 0);
    heff_take_n(v_d_2451, 1ULL, 2);
    switch (heff_tag_of(v_x11_2452)) {
    case TAG_DeclEquations: {
      V v_f_2454 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 5);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_f_2454});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2459 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 5);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2459});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2464 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 4);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2464});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2468 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 3);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2468});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2471 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 2);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2471});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2452, 0ULL, 1);
      v_t_2474 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2452);
    }
    break;
  }
  default: heff_nomatch(v_d_2451);
  }
  switch (heff_tag_of(v_t_2474)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_y_2475 = heff_field(v_t_2474, 0);
    heff_take_n(v_t_2474, 1ULL, 1);
    return heff_strEq(heff_get_n(v_r_240, 0, 5), v_y_2475);
  }
  default: return heff_nomatch(v_t_2474);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam2(V self, V *args) {
  V v_d_2479 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102;
  switch (heff_tag_of(v_d_2479)) {
  case TAG_At: {
    V v_x11_2480 = heff_field(v_d_2479, 0);
    heff_take_n(v_d_2479, 1ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_DeclEquations: {
      V v_f_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 5);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_f_2482});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2487 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 5);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2487});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2492 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 4);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2492});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2496 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 3);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2496});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2499 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 2);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2499});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2480, 0ULL, 1);
      v_t_24102 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2480);
    }
    break;
  }
  default: heff_nomatch(v_d_2479);
  }
  switch (heff_tag_of(v_t_24102)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_y_24103 = heff_field(v_t_24102, 0);
    heff_take_n(v_t_24102, 1ULL, 1);
    return heff_strEq(heff_get_n(v_r_240, 0, 5), v_y_24103);
  }
  default: return heff_nomatch(v_t_24102);
  }
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameTypF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameTypF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameTypF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameTypF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_n1_242, 0);
      V v_cod_245 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24TPi = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2erenamePi(heff_dup(v_r_240), heff_dup(v_b_244)));
      V v_x_247 = heff_take_field(v_r_240, 0);
      V v_t_2424;
      switch (heff_tag_of(v_b_244)) {
      case TAG_PiNamed: {
        V v_y_248 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 3);
        if (heff_strEq_c(v_x_247, v_y_248)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiImplicit: {
        V v_y_2412 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 5);
        if (heff_strEq_c(v_x_247, v_y_2412)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiInstance: {
        V v_y_2418 = heff_field(v_b_244, 0);
        heff_take_n(v_b_244, 1ULL, 4);
        if (heff_strEq_c(v_x_247, v_y_2418)) {
          heff_drop_rec(v_r_240, 5);
          v_t_2424 = v_cod_245;
        } else {
          v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        }
        break;
      }
      case TAG_PiAnon: {
        heff_take_n(v_b_244, 0ULL, 1);
        heff_drop(v_x_247);
        v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_cod_245}));
        break;
      }
      default: heff_nomatch(v_b_244);
      }
      return heff_tag_at_n(v_ru_24n1_242_24TPi, TAG_At, 2, (V[]){heff_tag_n(TAG_TPi, 2, (V[]){v_t_246, v_t_2424}), v_sp_243});
    }
    case TAG_TSig: {
      V v_fs_2425 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSig = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameField_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_2435 = heff_tag_at_n(v_ru_24n1_242_24TSig, TAG_TSig, 1, (V[]){(g_heff_2eelab_2eclauses_2erenameSeq(v_t_2426, heff_clo_n(g_heff_2eelab_2eclauses_2erenameTypF_lam0, 1, 1, (V[]){v_r_240}), v_fs_2425))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2435, v_sp_243});
    }
    case TAG_TSum: {
      V v_vs_2436 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TSum = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2446 = heff_tag_at_n(v_ru_24n1_242_24TSum, TAG_TSum, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameTypF_lam1, 1, 1, (V[]){v_r_240}), v_vs_2436))});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_sp_243});
    }
    case TAG_TType: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInt: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TFloat: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TString: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TRune: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TArray: {
      V v_a_2447 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TArray = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2448 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_a_2447}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TArray, TAG_TArray, 1, (V[]){v_t_2448}), v_sp_243});
    }
    case TAG_TFixed: {
      heff_take_n(v_n1_242, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_TInf: {
      V v_i_2450 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2451 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_2450}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TInf, TAG_TInf, 1, (V[]){v_t_2451}), v_sp_243});
    }
    case TAG_TChk: {
      V v_c_2452 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TChk = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2453 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2452}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TChk, TAG_TChk, 1, (V[]){v_t_2453}), v_sp_243});
    }
    case TAG_TNominal: {
      V v_t_2454 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24TNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2455 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_2454}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24TNominal, TAG_TNominal, 1, (V[]){v_t_2455}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameTypF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam0(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_At: {
    V v_x21_2428 = heff_field(v_x2_2427, 0);
    heff_take_n(v_x2_2427, 1ULL, 2);
    switch (heff_tag_of(v_x21_2428)) {
    case TAG_DeclareField: {
      V v_y_2430 = heff_field(v_x21_2428, 0);
      heff_take_n(v_x21_2428, 1ULL, 4);
      return heff_strEq(heff_get_n(v_r_240, 0, 5), v_y_2430);
    }
    case TAG_BadFieldDecl: {
      heff_take_n(v_x21_2428, 0ULL, 1);
      heff_drop_rec(v_r_240, 5);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_2428);
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2eelab_2eclauses_2erenameTypF_lam1(V self, V *args) {
  V v_x2_2437 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2437)) {
  case TAG_At: {
    V v_x21_2438 = heff_field(v_x2_2437, 0);
    V v_sp_2439 = heff_field(v_x2_2437, 1);
    V v_ru_24x2_2437_24At = heff_take_reuse_n(v_x2_2437, 3ULL, 2);
    switch (heff_tag_of(v_x21_2438)) {
    case TAG_TagVariant: {
      V v_t_2440 = heff_field(v_x21_2438, 0);
      V v_tsp_2441 = heff_field(v_x21_2438, 1);
      V v_args_2442 = heff_field(v_x21_2438, 2);
      V v_ru_24x21_2438_24TagVariant = heff_take_reuse_n(v_x21_2438, 7ULL, 3);
      V v_t_2443 = heff_tag_at_n(v_ru_24x21_2438_24TagVariant, TAG_TagVariant, 3, (V[]){v_t_2440, v_tsp_2441, (g_list_2emap(heff_get_n(v_r_240, 4, 5), v_args_2442))});
      return heff_tag_at_n(v_ru_24x2_2437_24At, TAG_At, 2, (V[]){v_t_2443, v_sp_2439});
    }
    case TAG_BadVariant: {
      V v_e_2444 = heff_field(v_x21_2438, 0);
      heff_take_n(v_x21_2438, 1ULL, 1);
      V v_t_2445 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_e_2444}));
      return heff_tag_at_n(v_ru_24x2_2437_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadVariant, 1, (V[]){v_t_2445}), v_sp_2439});
    }
    default: return heff_nomatch(v_x21_2438);
    }
  }
  default: return heff_nomatch(v_x2_2437);
  }
}
V g_heff_2eelab_2eclauses_2erenamer_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenamer_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenamer_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenamer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamer_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamer(V v_x_240, V v_v_241) {
top: ;
  return heff_rec_n(5, shape_x__v__inf__chk__typ, (V[]){heff_dup(v_x_240), heff_dup(v_v_241), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam0, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam1, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam2, 1, 2, (V[]){v_x_240, v_v_241})});
}
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamer(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenamer_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameInfF(v_t_243, v_n_242));
}
V g_heff_2eelab_2eclauses_2erenamer_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameChkF(v_t_245, v_n_244));
}
V g_heff_2eelab_2eclauses_2erenamer_lam2(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameTypF(v_t_247, v_n_246));
}
Clo g_heff_2eelab_2eclauses_2efindTagLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efindTagLit_entry, 2, 0};

V g_heff_2eelab_2eclauses_2efindTagLit(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_2413;
    switch (heff_tag_of(v_p_242)) {
    case TAG_PVar: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PTag: {
      v_t_2413 = NTAG(TAG_True);
      break;
    }
    case TAG_PLit: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PRec: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    case TAG_PAs: {
      v_t_2413 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    }
    case TAG_False: {
      switch (heff_tag_of(v_p_242)) {
      case TAG_PVar: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PTag: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PLit: {
        return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
      }
      case TAG_PRec: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      case TAG_PAs: {
        switch (heff_tag_of(v_p_242)) {
        case TAG_PVar: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PTag: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PLit: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        case TAG_PRec: {
          return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
        }
        case TAG_PAs: {
          V t_0 = v_rest_243;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          v_x1_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_p_242);
        }
      }
      default: return heff_nomatch(v_p_242);
      }
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2efindTagLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2efindTagLit(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmSubName_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2earmSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmSubName_entry, 5, 0};

V g_heff_2eelab_2eclauses_2earmSubName(V v_used_240, V v_bound_241, V v_v_242, V v_i_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_242, v_t_245)));
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x5_244, 0);
    if (heff_strEq_c(heff_dup(v_x_246), ((V)&g_heff_2eelab_2eclauses_2earmSubName_str0))) {
      V v_t_248 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_242, v_t_248)));
    } else {
      V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_246)}));
      V v_x1_2410 = (g_list_2eany(v_t_249, v_bound_241));
      switch (heff_tag_of(v_x1_2410)) {
      case TAG_True: {
        V v_t_2411 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_242, v_t_2411)));
      }
      case TAG_False: {
        heff_drop(v_v_242);
        heff_drop(v_i_243);
        return heff_dup(v_x_246);
      }
      default: return heff_nomatch(v_x1_2410);
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2earmSubName(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2earmFields_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2earmFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmFields_entry, 4, 0};

V g_heff_2eelab_2eclauses_2earmFields(V v_used_240, V v_bound_241, V v_t_242, V v_v_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), heff_dup(heff_rfield(v_t_242, 1))));
  return (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmFields_lam0, 1, 4, (V[]){v_t_242, heff_dup(v_used_240), heff_dup(v_bound_241), v_v_243}), v_t_244));
}
V g_heff_2eelab_2eclauses_2earmFields_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2earmFields(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2earmFields_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_t_242 = heff_env(self)[0];
  V v_used_240 = heff_env(self)[1];
  V v_bound_241 = heff_env(self)[2];
  V v_v_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = ({ V b_0 = heff_get_n(v_t_242, 2, 4); V a_1 = heff_dup(v_i_245); V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    V v_t_247 = heff_intShow(heff_intAdd(v_i_245, MK_INT(1LL)));
    return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = heff_strAppend(v_v_243, v_t_247); V r_ = (g_heff_2eelab_2eclauses_2efreshIn(a_0, a_1, a_2)); heff_drop(v_used_240); heff_drop(v_bound_241); r_; });
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    V v_t_2418;
    switch (heff_tag_of(v_p_248)) {
    case TAG_PVar: {
      V v_x_249 = heff_field(v_p_248, 0);
      heff_take_n(v_p_248, 1ULL, 1);
      v_t_2418 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_249});
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_p_248, 0ULL, 3);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_p_248, 0ULL, 1);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_p_248, 0ULL, 2);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      v_t_2418 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_PAs: {
      V v_x_2416 = heff_field(v_p_248, 0);
      heff_take_n(v_p_248, 1ULL, 2);
      v_t_2418 = heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_2416});
      break;
    }
    default: heff_nomatch(v_p_248);
    }
    return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_v_243; V a_3 = v_i_245; V a_4 = v_t_2418; V r_ = (g_heff_2eelab_2eclauses_2earmSubName(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_used_240); heff_drop(v_bound_241); heff_drop(v_t_2418); r_; });
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eanyIn_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2eanyIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyIn_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eanyIn(V v_c_240, V v_n_241, V v_a_242) {
top: ;
  V v_t_243 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), v_n_241));
  V v_ys_244 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2eanyIn_str0), v_t_243));
  V v_xs_245 = heff_take_field(v_a_242, 0);
  V v_t_246 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_245)));
  V v_t_247 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_245));
  V v_t_248 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_244, v_t_247));
  V v_pats_249 = (g_heff_2eelab_2eclauses_2eappendC(v_t_246, v_t_248));
  return ({ V rv_0 = v_pats_249; V rr_ = heff_rec_reuse_n(v_a_242, 2ULL, 2, shape_pats__rhs); heff_rfield(rr_, 0) = rv_0; rr_; });
}
V g_heff_2eelab_2eclauses_2eanyIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eanyIn(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2etagArmStep_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagArmStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagArmStep_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagArmStep(V v_c_240, V v_col_241, V v_t_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2etagArmStep_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_t_242)}), heff_dup(heff_rfield(v_col_241, 2))))});
    V v_t_247 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(v_t_242), NTAG(TAG_False), v_t_246});
    V v_t_248 = (g_map_2einsert_24s1341440536x470972936(heff_dup(heff_rfield(v_t_242, 0)), v_t_247, heff_take_field(v_col_241, 0)));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_take_field(v_col_241, 1)});
    return ({ V rv_0 = v_t_248; V rv_1 = v_t_249; V rr_ = heff_rec_reuse_n(v_col_241, 4ULL, 3, shape_arms__order__anys); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  case TAG_Just: {
    V v_arm_2410 = heff_field(v_x5_244, 0);
    heff_drop(v_c_240);
    V v_t_2411 = heff_dup(heff_rfield(v_arm_2410, 1));
    V v_t_2414;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      v_t_2414 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_t_2412 = heff_get_n(heff_dup(heff_rfield(v_arm_2410, 0)), 1, 4);
      if (heff_intEq_c(heff_dup(heff_rfield(v_t_242, 1)), v_t_2412)) {
        v_t_2414 = NTAG(TAG_False);
      } else {
        v_t_2414 = NTAG(TAG_True);
      }
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_dup(heff_rfield(v_arm_2410, 2))});
    V v_t_2416 = heff_rec_n(3, shape_row__bad__rows, (V[]){heff_dup(heff_rfield(v_arm_2410, 0)), v_t_2414, v_t_2415});
    V v_t_2417 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_t_242, 0, 4), v_t_2416, heff_take_field(v_col_241, 0)));
    return ({ V rv_0 = v_t_2417; V rr_ = heff_rec_reuse_n(v_col_241, 6ULL, 3, shape_arms__order__anys); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagArmStep_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagArmStep(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagArmStep_lam0(V self, V *args) {
  V v_a_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, heff_get_n(v_t_242, 1, 4), v_a_245));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColAt_str0, 1, "_");
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagColAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColAt_entry, 5, 0};

V g_heff_2eelab_2eclauses_2etagColAt(V v_c_240, V v_v_241, V v_col_242, V v_r_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_PVar: {
    V v_x_245 = heff_field(v_x5_244, 0);
    V v_e_246 = heff_take_field(v_r_243, 1);
    V v_rhs_2410;
    if (heff_strEq_c(heff_dup(v_x_245), ((V)&g_heff_2eelab_2eclauses_2etagColAt_str0))) {
      heff_drop(v_v_241);
      v_rhs_2410 = v_e_246;
    } else {
      if (heff_strEq_c(heff_dup(v_x_245), heff_dup(v_v_241))) {
        heff_drop(v_v_241);
        v_rhs_2410 = v_e_246;
      } else {
        V v_t_249 = (g_heff_2eelab_2eclauses_2erenamer(heff_dup(v_x_245), v_v_241));
        v_rhs_2410 = heff_tr(heff_call(heff_get_n(v_t_249, 3, 5), 1, (V[]){v_e_246}));
      }
    }
    V v_a_2411 = ({ V rv_1 = v_rhs_2410; V rr_ = heff_rec_reuse_n(v_r_243, 1ULL, 2, shape_pats__rhs); heff_rfield(rr_, 1) = rv_1; rr_; });
    V v_t_2416 = (g_map_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_a_2411)}), heff_take_field(v_col_242, 0)));
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2416; V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_n(v_col_242, 2ULL, 3, shape_arms__order__anys); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PTag: {
    V v_t_2418 = heff_field(v_x5_244, 0);
    V v_ps_2419 = heff_field(v_x5_244, 1);
    V v_sp_2420 = heff_field(v_x5_244, 2);
    heff_drop(v_v_241);
    V v_t_2421 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_ps_2419));
    V v_xs_2422 = heff_take_field(v_r_243, 0);
    V v_t_2423 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2422)));
    V v_t_2424 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2422));
    V v_t_2425 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ps_2419), v_t_2424));
    V v_pats_2426 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2423, v_t_2425));
    V v_t_2427 = ({ V rv_0 = v_pats_2426; V rr_ = heff_rec_reuse_n(v_r_243, 2ULL, 2, shape_pats__rhs); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2428 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_t_2418), heff_rfield(v_col_242, 0)));
    return ({ V a_0 = v_c_240; V a_1 = v_col_242; V a_2 = heff_rec_n(4, shape_tag__arity__pats__span, (V[]){heff_dup(v_t_2418), v_t_2421, heff_dup(v_ps_2419), heff_dup(v_sp_2420)}); V a_3 = v_t_2427; V a_4 = v_t_2428; V r_ = (g_heff_2eelab_2eclauses_2etagArmStep(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2428); r_; });
  }
  case TAG_PLit: {
    heff_drop(v_v_241);
    V v_t_2434 = (g_map_2emapValues(heff_clo_n(g_heff_2eelab_2eclauses_2etagColAt_lam1, 1, 2, (V[]){v_c_240, heff_dup(v_r_243)}), heff_take_field(v_col_242, 0)));
    V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_243, heff_take_field(v_col_242, 2)});
    return ({ V rv_0 = v_t_2434; V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_n(v_col_242, 2ULL, 3, shape_arms__order__anys); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
  case TAG_PRec: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  case TAG_PAs: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    heff_drop_rec(v_r_243, 2);
    return v_col_242;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2etagColAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2etagColAt(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2etagColAt_lam0(V self, V *args) {
  V v_arm_2412 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_a_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_arm_2412, 0)), 1, 4);
  V v_t_2414 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2413, v_a_2411));
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_take_field(v_arm_2412, 2)});
  return ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_n(v_arm_2412, 3ULL, 3, shape_row__bad__rows); heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2eelab_2eclauses_2etagColAt_lam1(V self, V *args) {
  V v_arm_2430 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_r_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = heff_get_n(heff_dup(heff_rfield(v_arm_2430, 0)), 1, 4);
  V v_t_2432 = (g_heff_2eelab_2eclauses_2eanyIn(v_c_240, v_t_2431, v_r_243));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, heff_take_field(v_arm_2430, 2)});
  return ({ V rv_2 = v_t_2433; V rr_ = heff_rec_reuse_n(v_arm_2430, 3ULL, 3, shape_row__bad__rows); heff_rfield(rr_, 2) = rv_2; rr_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagColGo_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2etagColGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagColGo_entry, 4, 0};

V g_heff_2eelab_2eclauses_2etagColGo(V v_c_240, V v_v_241, V v_col_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_241);
    return v_col_242;
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_244, 0), heff_dup(v_c_240)));
    V v_t_248;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      v_t_248 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2etagColGo_str0)});
      break;
    }
    case TAG_Just: {
      V v_p_247 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      v_t_248 = v_p_247;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_249 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_v_241); V a_2 = v_col_242; V a_3 = heff_dup(v_r_244); V a_4 = v_t_248; V r_ = (g_heff_2eelab_2eclauses_2etagColAt(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_248); r_; });
    V t_0 = v_c_240;
    V t_1 = v_v_241;
    V t_2 = v_t_249;
    V t_3 = v_rest_245;
    v_c_240 = t_0;
    v_v_241 = t_1;
    v_col_242 = t_2;
    v_x4_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2etagColGo(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitYesOne_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitYesOne_str1, 1, "_");
Clo g_heff_2eelab_2eclauses_2elitYesOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYesOne_entry, 5, 0};

V g_heff_2eelab_2eclauses_2elitYesOne(V v_c_240, V v_l_241, V v_v_242, V v_r_243, V v_acc_244) {
top: ;
  V v_t_245 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), heff_dup(v_c_240)));
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_247 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitYesOne_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_PVar: {
    V v_x_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_pats_249 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
    V v_e_2410 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2414;
    if (heff_strEq_c(heff_dup(v_x_248), ((V)&g_heff_2eelab_2eclauses_2elitYesOne_str1))) {
      heff_drop(v_v_242);
      heff_drop(v_x_248);
      v_rhs_2414 = v_e_2410;
    } else {
      if (heff_strEq_c(heff_dup(v_x_248), heff_dup(v_v_242))) {
        heff_drop(v_v_242);
        heff_drop(v_x_248);
        v_rhs_2414 = v_e_2410;
      } else {
        V v_t_2413 = (g_heff_2eelab_2eclauses_2erenamer(v_x_248, v_v_242));
        v_rhs_2414 = heff_tr(heff_call(heff_get_n(v_t_2413, 3, 5), 1, (V[]){v_e_2410}));
      }
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_249, v_rhs_2414}), v_acc_244});
  }
  case TAG_PTag: {
    heff_take_n(v_t_247, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop_rec(v_r_243, 2);
    return v_acc_244;
  }
  case TAG_PLit: {
    V v_l_27_2418 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_v_242);
    V v_t_2419 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2418; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2418); r_; });
    switch (heff_tag_of(v_t_2419)) {
    case TAG_True: {
      V v_pats_2420 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
      V v_t_2421 = ({ V rv_0 = v_pats_2420; V rr_ = heff_rec_reuse_n(v_r_243, 2ULL, 2, shape_pats__rhs); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_acc_244});
    }
    case TAG_False: {
      heff_drop(v_c_240);
      heff_drop_rec(v_r_243, 2);
      return v_acc_244;
    }
    default: return heff_nomatch(v_t_2419);
    }
  }
  case TAG_PRec: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop_rec(v_r_243, 2);
    return v_acc_244;
  }
  case TAG_PAs: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop_rec(v_r_243, 2);
    return v_acc_244;
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elitYesOne(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2elitYes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYes_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitYes(V v_c_240, V v_l_241, V v_v_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_244 = heff_field(v_x4_243, 0);
    V v_rest_245 = heff_field(v_x4_243, 1);
    V v_t_246 = (g_heff_2eelab_2eclauses_2elitYes(heff_dup(v_c_240), v_l_241, heff_dup(v_v_242), v_rest_245));
    return (g_heff_2eelab_2eclauses_2elitYesOne(v_c_240, v_l_241, v_v_242, heff_dup(v_r_244), v_t_246));
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2eclauses_2elitYes_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2elitYes(a[0], a1, a[2], a3); heff_drop(a1); heff_drop(a3); return r;
}
Clo g_heff_2eelab_2eclauses_2elitNoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNoOne_entry, 4, 0};

V g_heff_2eelab_2eclauses_2elitNoOne(V v_c_240, V v_l_241, V v_r_242, V v_acc_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_242, 0), v_c_240));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_p_245)) {
    case TAG_PVar: {
      heff_take_n(v_p_245, 0ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PTag: {
      heff_take_n(v_p_245, 0ULL, 3);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PLit: {
      V v_l_27_2410 = heff_field(v_p_245, 0);
      heff_take_n(v_p_245, 1ULL, 1);
      V v_t_2411 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2410; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2410); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        heff_drop_rec(v_r_242, 2);
        return v_acc_243;
      }
      case TAG_False: {
        return heff_tag_n(TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_PRec: {
      V v_ru_24p_245_24PRec = heff_take_reuse_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24p_245_24PRec, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    case TAG_PAs: {
      V v_ru_24p_245_24PAs = heff_take_reuse_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24p_245_24PAs, TAG_Cons, 2, (V[]){v_r_242, v_acc_243});
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2eclauses_2elitNoOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elitNoOne(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2elitNo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitNo_entry, 3, 0};

V g_heff_2eelab_2eclauses_2elitNo(V v_c_240, V v_l_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_r_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = (g_heff_2eelab_2eclauses_2elitNo(heff_dup(v_c_240), v_l_241, v_rest_244));
    return (g_heff_2eelab_2eclauses_2elitNoOne(v_c_240, v_l_241, heff_dup(v_r_243), v_t_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2elitNo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2elitNo(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str1, 43, "a literal and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitChecks_str3, 88, "literals are matched here: one of them must match every other value (a variable, or `_`)");
V g_heff_2eelab_2eclauses_2elitChecks_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2elitChecks_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2elitChecks_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitChecks_entry, 5, 0};

V g_heff_2eelab_2eclauses_2elitChecks(V v_sp_240, V v_vars_241, V v_rows_242, V v_c_243, V v_l_244) {
top: ;
  V v_t_2418 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_lam0, 1, 1, (V[]){heff_dup(v_c_243)}), v_rows_242));
  V v_x1_2422;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    V v_span_2421;
    switch (heff_tag_of(v_l_244)) {
    case TAG_At: {
      V v_s_2420 = heff_field(v_l_244, 1);
      v_span_2421 = heff_dup(v_s_2420);
      break;
    }
    default: heff_nomatch(v_l_244);
    }
    v_x1_2422 = heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2421, ((V)&g_heff_2eelab_2eclauses_2elitChecks_str1)})});
    break;
  }
  case TAG_False: {
    v_x1_2422 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Left: {
    V v_e_2423 = heff_field(v_x1_2422, 0);
    V v_ru_24x1_2422_24Left = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
    heff_drop(v_c_243);
    return heff_tag_at_n(v_ru_24x1_2422_24Left, TAG_Left, 1, (V[]){v_e_2423});
  }
  case TAG_Right: {
    V v_ru_24x1_2422_24Right = heff_take_reuse_n(v_x1_2422, 0ULL, 1);
    V v_t_2438 = (g_heff_2eelab_2eclauses_2eallC(heff_clo_n(g_heff_2eelab_2eclauses_2elitChecks_lam1, 1, 1, (V[]){v_c_243}), v_rows_242));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_True: {
      V v_span_2441;
      switch (heff_tag_of(v_l_244)) {
      case TAG_At: {
        V v_s_2440 = heff_field(v_l_244, 1);
        v_span_2441 = heff_dup(v_s_2440);
        break;
      }
      default: heff_nomatch(v_l_244);
      }
      return heff_tag_at_n(v_ru_24x1_2422_24Right, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2441, ((V)&g_heff_2eelab_2eclauses_2elitChecks_str3)})});
    }
    case TAG_False: {
      return heff_tag_at_n(v_ru_24x1_2422_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_x1_2422);
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2elitChecks(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2elitChecks_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get_n(v_row_245, 0, 2); V a_1 = v_c_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_248;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_x1_248 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    v_x1_248 = v_p_247;
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_x1_248)) {
  case TAG_PVar: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_248, 0ULL, 3);
    return NTAG(TAG_True);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_248, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_248, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2eclauses_2elitChecks_lam1(V self, V *args) {
  V v_row_2425 = args[0];
  V v_c_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = ({ V b_0 = heff_get_n(v_row_2425, 0, 2); V a_1 = v_c_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_2428;
  switch (heff_tag_of(v_t_2426)) {
  case TAG_Nothing: {
    v_x1_2428 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitChecks_str2)});
    break;
  }
  case TAG_Just: {
    V v_p_2427 = heff_field(v_t_2426, 0);
    heff_take_n(v_t_2426, 1ULL, 1);
    v_x1_2428 = v_p_2427;
    break;
  }
  default: heff_nomatch(v_t_2426);
  }
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_PVar: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_2428, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    return NTAG(TAG_True);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_2428, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_2428);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoLitHere_str0, 43, "a literal and a tag match the same argument");
V g_heff_2eelab_2eclauses_2enoLitHere_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enoLitHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enoLitHere_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enoLitHere(V v_sp_240, V v_c_241, V v_rows_242) {
top: ;
  return (g_heff_2eelab_2eclauses_2eforC(v_rows_242, heff_clo_n(g_heff_2eelab_2eclauses_2enoLitHere_lam0, 1, 1, (V[]){v_c_241})));
}
V g_heff_2eelab_2eclauses_2enoLitHere_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2enoLitHere(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2enoLitHere_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V b_0 = heff_get_n(v_row_243, 0, 2); V a_1 = v_c_241; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_p_245)) {
    case TAG_PVar: {
      heff_take_n(v_p_245, 0ULL, 1);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PTag: {
      heff_take_n(v_p_245, 0ULL, 3);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PLit: {
      V v_l_2410 = heff_field(v_p_245, 0);
      heff_take_n(v_p_245, 1ULL, 1);
      V v_span_2413;
      switch (heff_tag_of(v_l_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_l_2410, 1);
        heff_take_n(v_l_2410, 2ULL, 2);
        v_span_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_l_2410);
      }
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2413, ((V)&g_heff_2eelab_2eclauses_2enoLitHere_str0)})});
    }
    case TAG_PRec: {
      heff_take_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PAs: {
      heff_take_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
Clo g_heff_2eelab_2eclauses_2elookupField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elookupField_entry, 2, 0};

V g_heff_2eelab_2eclauses_2elookupField(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_g_244 = heff_field(v_x21_242, 0);
      V v_p_245 = heff_field(v_x21_242, 1);
      if (heff_strEq_c(heff_dup(v_f_240), heff_dup(v_g_244))) {
        heff_drop(v_f_240);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_p_245)});
      } else {
        V t_0 = v_f_240;
        V t_1 = v_rest_243;
        v_f_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elookupField(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_str1, 42, "a record and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoRecMix_str2, 46, "a record and a literal match the same argument");
V g_heff_2eelab_2eclauses_2enoRecMix_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2enoRecMix_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enoRecMix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enoRecMix_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enoRecMix(V v_rows_240, V v_c_241) {
top: ;
  V v_t_2415 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), v_rows_240));
  switch (heff_tag_of(v_t_2415)) {
  case TAG_True: {
    HEFF_LAST return g_heff_2eelab_2eclauses_2eforC(v_rows_240, heff_clo_n(g_heff_2eelab_2eclauses_2enoRecMix_lam1, 1, 1, (V[]){v_c_241}));
  }
  case TAG_False: {
    heff_drop(v_c_241);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  default: return heff_nomatch(v_t_2415);
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enoRecMix(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2enoRecMix_lam0(V self, V *args) {
  V v_row_242 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V b_0 = heff_get_n(v_row_242, 0, 2); V a_1 = v_c_241; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    v_x1_245 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2enoRecMix_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    v_x1_245 = v_p_244;
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_x1_245)) {
  case TAG_PVar: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PTag: {
    heff_take_n(v_x1_245, 0ULL, 3);
    return NTAG(TAG_False);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_245, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_PRec: {
    heff_take_n(v_x1_245, 0ULL, 2);
    return NTAG(TAG_True);
  }
  case TAG_PAs: {
    heff_take_n(v_x1_245, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_245);
  }
}
V g_heff_2eelab_2eclauses_2enoRecMix_lam1(V self, V *args) {
  V v_row_2416 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = ({ V b_0 = heff_get_n(v_row_2416, 0, 2); V a_1 = v_c_241; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_p_2418 = heff_field(v_t_2417, 0);
    V v_ru_24t_2417_24Just = heff_take_reuse_n(v_t_2417, 1ULL, 1);
    switch (heff_tag_of(v_p_2418)) {
    case TAG_PVar: {
      heff_take_n(v_p_2418, 0ULL, 1);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PTag: {
      V v_sp_2422 = heff_field(v_p_2418, 2);
      heff_take_n(v_p_2418, 4ULL, 3);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_sp_2422, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_str1)})});
    }
    case TAG_PLit: {
      V v_l_2423 = heff_field(v_p_2418, 0);
      heff_take_n(v_p_2418, 1ULL, 1);
      V v_span_2426;
      switch (heff_tag_of(v_l_2423)) {
      case TAG_At: {
        V v_s_2425 = heff_field(v_l_2423, 1);
        heff_take_n(v_l_2423, 2ULL, 2);
        v_span_2426 = v_s_2425;
        break;
      }
      default: heff_nomatch(v_l_2423);
      }
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2426, ((V)&g_heff_2eelab_2eclauses_2enoRecMix_str2)})});
    }
    case TAG_PRec: {
      heff_take_n(v_p_2418, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PAs: {
      heff_take_n(v_p_2418, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_2417_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_p_2418);
    }
  }
  default: return heff_nomatch(v_t_2417);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecFieldVar_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecFieldVar_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecFieldVar_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erecFieldVar(V v_c_240, V v_rows_241, V v_f_242) {
top: ;
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecFieldVar_lam0, 1, 2, (V[]){v_c_240, v_f_242}), v_rows_241));
  V v_t_2418 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2417));
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_2419 = heff_field(v_t_2418, 0);
    heff_take_n(v_t_2418, 1ULL, 2);
    switch (heff_tag_of(v_p_2419)) {
    case TAG_PVar: {
      V v_x_2421 = heff_field(v_p_2419, 0);
      V v_ru_24p_2419_24PVar = heff_take_reuse_n(v_p_2419, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_2419_24PVar, TAG_Just, 1, (V[]){v_x_2421});
    }
    case TAG_PTag: {
      heff_take_n(v_p_2419, 0ULL, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_2419, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_2419, 0ULL, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2428 = heff_field(v_p_2419, 0);
      heff_take_n(v_p_2419, 1ULL, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2428});
    }
    default: return heff_nomatch(v_p_2419);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecFieldVar(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2erecFieldVar_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = ({ V b_0 = heff_get_n(v_row_243, 0, 2); V a_1 = v_c_240; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_x1_246 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecFieldVar_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_x1_246 = v_p_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_PVar: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_246, 0ULL, 3);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2412 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 2);
    v_t_2416 = v_fps_2412;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_246, 0ULL, 2);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  return ({ V a_0 = v_f_242; V a_1 = v_t_2416; V r_ = (g_heff_2eelab_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_t_2416); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSubName_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2erecSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSubName_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSubName(V v_used_240, V v_bound_241, V v_x3_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_243));
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_x3_242, 0);
    if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2eelab_2eclauses_2erecSubName_str0))) {
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_243));
    } else {
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_244)}));
      V v_x1_247 = (g_list_2eany(v_t_246, v_bound_241));
      switch (heff_tag_of(v_x1_247)) {
      case TAG_True: {
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, v_f_243));
      }
      case TAG_False: {
        heff_drop(v_f_243);
        return heff_dup(v_x_244);
      }
      default: return heff_nomatch(v_x1_247);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erecSubName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2erecSubName(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSubs_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecSubs_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecSubs_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecSubs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSubs_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSubs(V v_used_240, V v_bound_241, V v_c_242, V v_rows_243) {
top: ;
  V v_t_2418 = (g_heff_2eelab_2eclauses_2econcatMapC(heff_clo_n(g_heff_2eelab_2eclauses_2erecSubs_lam0, 1, 1, (V[]){heff_dup(v_c_242)}), v_rows_243));
  V v_t_2419 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2418));
  return (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecSubs_lam1, 1, 4, (V[]){v_c_242, v_rows_243, heff_dup(v_used_240), heff_dup(v_bound_241)}), v_t_2419));
}
V g_heff_2eelab_2eclauses_2erecSubs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2erecSubs(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2erecSubs_lam0(V self, V *args) {
  V v_row_244 = args[0];
  V v_c_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_245 = ({ V b_0 = heff_get_n(v_row_244, 0, 2); V a_1 = v_c_242; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_x1_247 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSubs_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_x1_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2417;
  switch (heff_tag_of(v_x1_247)) {
  case TAG_PVar: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_247, 0ULL, 3);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_247, 0ULL, 1);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2413 = heff_field(v_x1_247, 0);
    heff_take_n(v_x1_247, 1ULL, 2);
    v_t_2417 = v_fps_2413;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_247, 0ULL, 2);
    v_t_2417 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_247);
  }
  return (g_list_2emap_24s1415906091x1371825187(v_t_2417));
}
V g_heff_2eelab_2eclauses_2erecSubs_lam1(V self, V *args) {
  V v_f_2420 = args[0];
  V v_c_242 = heff_env(self)[0];
  V v_rows_243 = heff_env(self)[1];
  V v_used_240 = heff_env(self)[2];
  V v_bound_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2421 = (g_heff_2eelab_2eclauses_2erecFieldVar(v_c_242, v_rows_243, heff_dup(v_f_2420)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_t_2421; V a_3 = v_f_2420; V r_ = (g_heff_2eelab_2eclauses_2erecSubName(a_0, a_1, a_2, a_3)); heff_drop(v_used_240); heff_drop(v_bound_241); heff_drop(v_t_2421); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str5, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str6, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str7, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str8, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str9, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str10, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str11, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str12, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecSpecialize_str13, 1, "_");
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecSpecialize_entry, 4, 0};

V g_heff_2eelab_2eclauses_2erecSpecialize(V v_c_240, V v_fs_241, V v_v_242, V v_r_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), heff_dup(v_c_240)));
  V v_t_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_t_246 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_t_246 = v_p_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  switch (heff_tag_of(v_t_246)) {
  case TAG_PVar: {
    V v_ru_24t_246_24PVar = heff_take_reuse_n(v_t_246, 0ULL, 1);
    V v_ys_248 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str1), v_fs_241));
    V v_xs_249 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2410 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_249)));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_249));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_248, v_t_2411));
    V v_pats_2413 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2410, v_t_2412));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_2416;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nothing: {
      v_x2_2416 = heff_tag_at_n(v_ru_24t_246_24PVar, TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str2)});
      break;
    }
    case TAG_Just: {
      V v_p_2415 = heff_field(v_t_2414, 0);
      heff_take_n(v_t_2414, 1ULL, 1);
      heff_drop_cell(v_ru_24t_246_24PVar, 1);
      v_x2_2416 = v_p_2415;
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_e_2417 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2430;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_PVar: {
      V v_x_2418 = heff_field(v_x2_2416, 0);
      heff_take_n(v_x2_2416, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_2418), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str3))) {
        heff_drop(v_v_242);
        heff_drop(v_x_2418);
        v_rhs_2430 = v_e_2417;
      } else {
        if (heff_strEq_c(heff_dup(v_x_2418), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_2418);
          v_rhs_2430 = v_e_2417;
        } else {
          V v_t_2421 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2418, v_v_242));
          v_rhs_2430 = heff_tr(heff_call(heff_get_n(v_t_2421, 3, 5), 1, (V[]){v_e_2417}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2416, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2416, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2416, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2416, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2430 = v_e_2417;
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2413, v_rhs_2430});
  }
  case TAG_PTag: {
    heff_take_n(v_t_246, 0ULL, 3);
    V v_ys_2434 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str4), v_fs_241));
    V v_xs_2435 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2436 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2435)));
    V v_t_2437 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2435));
    V v_t_2438 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2434, v_t_2437));
    V v_pats_2439 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2436, v_t_2438));
    V v_t_2440 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_2442;
    switch (heff_tag_of(v_t_2440)) {
    case TAG_Nothing: {
      v_x2_2442 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str5)});
      break;
    }
    case TAG_Just: {
      V v_p_2441 = heff_field(v_t_2440, 0);
      heff_take_n(v_t_2440, 1ULL, 1);
      v_x2_2442 = v_p_2441;
      break;
    }
    default: heff_nomatch(v_t_2440);
    }
    V v_e_2443 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2456;
    switch (heff_tag_of(v_x2_2442)) {
    case TAG_PVar: {
      V v_x_2444 = heff_field(v_x2_2442, 0);
      heff_take_n(v_x2_2442, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_2444), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str6))) {
        heff_drop(v_v_242);
        heff_drop(v_x_2444);
        v_rhs_2456 = v_e_2443;
      } else {
        if (heff_strEq_c(heff_dup(v_x_2444), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_2444);
          v_rhs_2456 = v_e_2443;
        } else {
          V v_t_2447 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2444, v_v_242));
          v_rhs_2456 = heff_tr(heff_call(heff_get_n(v_t_2447, 3, 5), 1, (V[]){v_e_2443}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2442, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2442, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2442, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2442, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2456 = v_e_2443;
      break;
    }
    default: heff_nomatch(v_x2_2442);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2439, v_rhs_2456});
  }
  case TAG_PLit: {
    V v_ru_24t_246_24PLit = heff_take_reuse_n(v_t_246, 0ULL, 1);
    V v_ys_2458 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str7), v_fs_241));
    V v_xs_2459 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2460 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2459)));
    V v_t_2461 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2459));
    V v_t_2462 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2458, v_t_2461));
    V v_pats_2463 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2460, v_t_2462));
    V v_t_2464 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_2466;
    switch (heff_tag_of(v_t_2464)) {
    case TAG_Nothing: {
      v_x2_2466 = heff_tag_at_n(v_ru_24t_246_24PLit, TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str8)});
      break;
    }
    case TAG_Just: {
      V v_p_2465 = heff_field(v_t_2464, 0);
      heff_take_n(v_t_2464, 1ULL, 1);
      heff_drop_cell(v_ru_24t_246_24PLit, 1);
      v_x2_2466 = v_p_2465;
      break;
    }
    default: heff_nomatch(v_t_2464);
    }
    V v_e_2467 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2480;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_PVar: {
      V v_x_2468 = heff_field(v_x2_2466, 0);
      heff_take_n(v_x2_2466, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_2468), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str9))) {
        heff_drop(v_v_242);
        heff_drop(v_x_2468);
        v_rhs_2480 = v_e_2467;
      } else {
        if (heff_strEq_c(heff_dup(v_x_2468), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_2468);
          v_rhs_2480 = v_e_2467;
        } else {
          V v_t_2471 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2468, v_v_242));
          v_rhs_2480 = heff_tr(heff_call(heff_get_n(v_t_2471, 3, 5), 1, (V[]){v_e_2467}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_2466, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_2466, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_2466, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_2466, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_2480 = v_e_2467;
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2463, v_rhs_2480});
  }
  case TAG_PRec: {
    V v_fps_2481 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 2);
    heff_drop(v_v_242);
    V v_ys_2486 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecSpecialize_lam0, 1, 1, (V[]){v_fps_2481}), v_fs_241));
    V v_xs_2487 = heff_take_field(v_r_243, 0);
    V v_t_2488 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2487)));
    V v_t_2489 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_240, MK_INT(1LL)), v_xs_2487));
    V v_t_2490 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2486, v_t_2489));
    V v_pats_2491 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2488, v_t_2490));
    return ({ V rv_0 = v_pats_2491; V rr_ = heff_rec_reuse_n(v_r_243, 2ULL, 2, shape_pats__rhs); heff_rfield(rr_, 0) = rv_0; rr_; });
  }
  case TAG_PAs: {
    heff_take_n(v_t_246, 0ULL, 2);
    V v_ys_2494 = (g_list_2emap_24s2103553821x564582624(((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str11), v_fs_241));
    V v_xs_2495 = heff_dup(heff_rfield(v_r_243, 0));
    V v_t_2496 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_240), heff_dup(v_xs_2495)));
    V v_t_2497 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_240), MK_INT(1LL)), v_xs_2495));
    V v_t_2498 = (g_heff_2eelab_2eclauses_2eappendC(v_ys_2494, v_t_2497));
    V v_pats_2499 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2496, v_t_2498));
    V v_t_24100 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), v_c_240));
    V v_x2_24102;
    switch (heff_tag_of(v_t_24100)) {
    case TAG_Nothing: {
      v_x2_24102 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str12)});
      break;
    }
    case TAG_Just: {
      V v_p_24101 = heff_field(v_t_24100, 0);
      heff_take_n(v_t_24100, 1ULL, 1);
      v_x2_24102 = v_p_24101;
      break;
    }
    default: heff_nomatch(v_t_24100);
    }
    V v_e_24103 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_24116;
    switch (heff_tag_of(v_x2_24102)) {
    case TAG_PVar: {
      V v_x_24104 = heff_field(v_x2_24102, 0);
      heff_take_n(v_x2_24102, 1ULL, 1);
      if (heff_strEq_c(heff_dup(v_x_24104), ((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str13))) {
        heff_drop(v_v_242);
        heff_drop(v_x_24104);
        v_rhs_24116 = v_e_24103;
      } else {
        if (heff_strEq_c(heff_dup(v_x_24104), heff_dup(v_v_242))) {
          heff_drop(v_v_242);
          heff_drop(v_x_24104);
          v_rhs_24116 = v_e_24103;
        } else {
          V v_t_24107 = (g_heff_2eelab_2eclauses_2erenamer(v_x_24104, v_v_242));
          v_rhs_24116 = heff_tr(heff_call(heff_get_n(v_t_24107, 3, 5), 1, (V[]){v_e_24103}));
        }
      }
      break;
    }
    case TAG_PTag: {
      heff_take_n(v_x2_24102, 0ULL, 3);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PLit: {
      heff_take_n(v_x2_24102, 0ULL, 1);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PRec: {
      heff_take_n(v_x2_24102, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    case TAG_PAs: {
      heff_take_n(v_x2_24102, 0ULL, 2);
      heff_drop(v_v_242);
      v_rhs_24116 = v_e_24103;
      break;
    }
    default: heff_nomatch(v_x2_24102);
    }
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2499, v_rhs_24116});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecSpecialize(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2erecSpecialize_lam0(V self, V *args) {
  V v_f_2483 = args[0];
  V v_fps_2481 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2484 = ({ V a_0 = v_f_2483; V a_1 = v_fps_2481; V r_ = (g_heff_2eelab_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_fps_2481); r_; });
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecSpecialize_str10)});
  }
  case TAG_Just: {
    V v_p_2485 = heff_field(v_x1_2484, 0);
    heff_take_n(v_x1_2484, 1ULL, 1);
    return v_p_2485;
  }
  default: return heff_nomatch(v_x1_2484);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eletFields_str0, 0, "");
Clo g_heff_2eelab_2eclauses_2eletFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eletFields_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eletFields(V v_sp_240, V v_v_241, V v_x3_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_sp_240, 2);
    heff_drop(v_v_241);
    return v_body_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x31_244, 0);
      V v_y_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(v_v_241)}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){heff_dup(v_f_246)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eletFields_str0)}), heff_dup(v_sp_240)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){v_f_246}), heff_dup(v_sp_240)});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_x1_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_t_2413, 2); r_; });
      V v_b_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 2ULL, 2);
        v_b_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2418 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_n(v_b_2417, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_2410}), v_t_2418});
      V v_e_2420 = (g_heff_2eelab_2eclauses_2eletFields(heff_dup(v_sp_240), v_v_241, v_rest_245, v_body_243));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_247}), heff_dup(v_sp_240)});
      V v_b_2424;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_e_2420, 1));
        v_b_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      V v_t_2425 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_n(v_b_2424, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2421, v_e_2420}), v_t_2425});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_2419, v_t_2426}), v_sp_240});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eletFields(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epeelAs_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2epeelAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epeelAs_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epeelAs(V v_v_240, V v_p_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_PVar: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PTag: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PLit: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PRec: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PAs: {
    V v_x_2410 = heff_field(v_p_241, 0);
    V v_p2_2411 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    V v_t_2415;
    if (heff_strEq_c(heff_dup(v_x_2410), ((V)&g_heff_2eelab_2eclauses_2epeelAs_str0))) {
      heff_drop(v_x_2410);
      v_t_2415 = v_e_242;
    } else {
      if (heff_strEq_c(heff_dup(v_x_2410), heff_dup(v_v_240))) {
        heff_drop(v_x_2410);
        v_t_2415 = v_e_242;
      } else {
        V v_t_2414 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2410, heff_dup(v_v_240)));
        v_t_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 3, 5), 1, (V[]){v_e_242}));
      }
    }
    V t_0 = v_v_240;
    V t_1 = v_p2_2411;
    V t_2 = v_t_2415;
    v_v_240 = t_0;
    v_p_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2eclauses_2epeelAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epeelAs(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2epeelCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epeelCols_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epeelCols(V v_x1_240, V v_ps_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_rec_n(2, shape_pats__rhs, (V[]){v_ps_241, v_e_242});
  }
  case TAG_Cons: {
    V v_v_243 = heff_field(v_x1_240, 0);
    V v_vs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_ps_241)) {
    case TAG_Nil: {
      heff_drop(v_v_243);
      heff_drop(v_vs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_rec_n(2, shape_pats__rhs, (V[]){v_ps_241, v_e_242});
    }
    case TAG_Cons: {
      V v_p_245 = heff_field(v_ps_241, 0);
      V v_ps2_246 = heff_field(v_ps_241, 1);
      heff_take_n(v_ps_241, 3ULL, 2);
      V v_t_247 = (g_heff_2eelab_2eclauses_2epeelAs(v_v_243, v_p_245, v_e_242));
      switch (heff_tag_of(v_t_247)) {
      case TAG_MkPair: {
        V v_p_27_248 = heff_field(v_t_247, 0);
        V v_e_27_249 = heff_field(v_t_247, 1);
        heff_take_n(v_t_247, 3ULL, 2);
        V v_r_2410 = (g_heff_2eelab_2eclauses_2epeelCols(v_vs_244, v_ps2_246, v_e_27_249));
        V v_t_2411 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_p_27_248, heff_dup(heff_rfield(v_r_2410, 0))});
        return ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_n(v_r_2410, 2ULL, 2, shape_pats__rhs); heff_rfield(rr_, 0) = rv_0; rr_; });
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_ps_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epeelCols(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str0, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str2, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str3, 1, "x");
Clo g_heff_2eelab_2eclauses_2ecolPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolPick_entry, 3, 0};

V g_heff_2eelab_2eclauses_2ecolPick(V v_used_240, V v_i_241, V v_xs_242) {
top: ;
  switch (heff_tag_of(v_xs_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
    return (g_heff_2eelab_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str0), v_t_243)));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_xs_242, 0);
    V v_xs2_245 = heff_field(v_xs_242, 1);
    switch (heff_tag_of(v_xs2_245)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2eelab_2eclauses_2ecolPick_str1))) {
        V v_t_247 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
        return (g_heff_2eelab_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str2), v_t_247)));
      } else {
        heff_drop(v_i_241);
        return heff_dup(v_x_244);
      }
    }
    case TAG_Cons: {
      V v_t_2410 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str3), v_t_2410)));
    }
    default: return heff_nomatch(v_xs2_245);
    }
  }
  default: return heff_nomatch(v_xs_242);
  }
}
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2ecolPick(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2ecolName_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecolName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolName_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecolName(V v_used_240, V v_params_241, V v_rows_242, V v_i_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2eclauses_2enthC(v_params_241, heff_dup(v_i_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecolName_lam0, 1, 1, (V[]){heff_dup(v_i_243)}), v_rows_242));
    V v_t_2418 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2417));
    V v_t_2419 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2418));
    return ({ V a_0 = v_used_240; V a_1 = v_i_243; V a_2 = v_t_2419; V r_ = (g_heff_2eelab_2eclauses_2ecolPick(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
  }
  case TAG_Just: {
    V v_p_2420 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_rows_242);
    heff_drop(v_i_243);
    return v_p_2420;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2eclauses_2ecolName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2ecolName(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2ecolName_lam0(V self, V *args) {
  V v_r_245 = args[0];
  V v_i_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = ({ V b_0 = heff_get_n(v_r_245, 0, 2); V a_1 = v_i_243; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_p_247 = heff_field(v_t_246, 0);
    V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 1ULL, 1);
    switch (heff_tag_of(v_p_247)) {
    case TAG_PVar: {
      V v_x_248 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_248});
    }
    case TAG_PTag: {
      heff_take_n(v_p_247, 0ULL, 3);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_247, 0ULL, 1);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_247, 0ULL, 2);
      heff_drop_cell(v_ru_24t_246_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2415 = heff_field(v_p_247, 0);
      heff_take_n(v_p_247, 1ULL, 2);
      return heff_tag_at_n(v_ru_24t_246_24Just, TAG_Just, 1, (V[]){v_x_2415});
    }
    default: return heff_nomatch(v_p_247);
    }
  }
  default: return heff_nomatch(v_t_246);
  }
}
Clo g_heff_2eelab_2eclauses_2efoldr2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efoldr2_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efoldr2(V v_f_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_tr(g_heff_2eelab_2eclauses_2efoldr2(heff_dup(v_f_240), v_z_241, v_xs_244));
    return heff_tail(v_f_240, 2, (V[]){heff_dup(v_x_243), v_t_245});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2efoldr2_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2efoldr2(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0, 44, " is used with different numbers of arguments");
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_c_244, V v_arm_245, V v_fs_246) {
top: ;
  V v_t_247 = heff_take_field(v_arm_245, 1);
  V v_e_2411;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 3, 4);
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 0, 4);
    V v_t_2410 = heff_rec_n(2, shape_span__msg, (V[]){v_t_248, heff_strAppend(v_t_249, ((V)&g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_str0))});
    v_e_2411 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2410});
    break;
  }
  case TAG_False: {
    v_e_2411 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_e_2411)) {
  case TAG_Left: {
    V v_e_2412 = heff_field(v_e_2411, 0);
    V v_ru_24e_2411_24Left = heff_take_reuse_n(v_e_2411, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_244);
    heff_drop_rec(v_arm_245, 3);
    heff_drop(v_fs_246);
    return heff_tag_at_n(v_ru_24e_2411_24Left, TAG_Left, 1, (V[]){v_e_2412});
  }
  case TAG_Right: {
    V v_ru_24e_2411_24Right = heff_take_reuse_n(v_e_2411, 0ULL, 1);
    V v_bound_2414 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_bound_241));
    V v_t_2415 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_244), heff_dup(v_vars_243)));
    V v_t_2416 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(v_c_244, MK_INT(1LL)), v_vars_243));
    V v_t_2417 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_fs_246), v_t_2416));
    V v_vars_2418 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2415, v_t_2417));
    V v_rows_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_arm_245, 2)));
    V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0, 1, 1, (V[]){heff_dup(v_vars_2418)}), v_rows_2419));
    V v_x1_2422 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_2414, heff_dup(v_sp_242), v_vars_2418, v_t_2421));
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x1_2422, 0);
      heff_take_n(v_x1_2422, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop_rec(v_arm_245, 3);
      heff_drop(v_fs_246);
      return heff_tag_at_n(v_ru_24e_2411_24Right, TAG_Left, 1, (V[]){v_e_2423});
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_x1_2422, 0);
      V v_ru_24x1_2422_24Right = heff_take_reuse_n(v_x1_2422, 1ULL, 1);
      V v_t_2425 = heff_get_n(heff_dup(heff_rfield(v_arm_245, 0)), 0, 4);
      V v_tsp_2426 = heff_get_n(heff_get_n(v_arm_245, 0, 3), 3, 4);
      V v_ps_2428 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam1, 1, 1, (V[]){v_sp_242}), v_fs_246));
      V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24e_2411_24Right, TAG_PatVar, 1, (V[]){heff_dup(v_t_2425)}), heff_dup(v_tsp_2426)});
      V v_x1_2430 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2429, v_ps_2428));
      V v_b_2433;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_At: {
        V v_s_2432 = heff_field(v_x1_2430, 1);
        heff_take_n(v_x1_2430, 2ULL, 2);
        v_b_2433 = v_s_2432;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V v_t_2434 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_2426, 0)); V rr_ = heff_rec_reuse_n(v_b_2433, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_p_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2425, v_tsp_2426, v_ps_2428}), v_t_2434});
      V v_a_2438;
      switch (heff_tag_of(v_p_2435)) {
      case TAG_At: {
        V v_s_2437 = heff_dup(heff_field(v_p_2435, 1));
        v_a_2438 = v_s_2437;
        break;
      }
      default: heff_nomatch(v_p_2435);
      }
      V v_b_2441;
      switch (heff_tag_of(v_x_2424)) {
      case TAG_At: {
        V v_s_2440 = heff_dup(heff_field(v_x_2424, 1));
        v_b_2441 = v_s_2440;
        break;
      }
      default: heff_nomatch(v_x_2424);
      }
      V v_t_2442 = ({ V rv_1 = heff_get_n(v_b_2441, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2438, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2435, v_x_2424}), v_t_2442});
      return heff_tag_at_n(v_ru_24x1_2422_24Right, TAG_Right, 1, (V[]){v_t_2443});
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  default: return heff_nomatch(v_e_2411);
  }
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam0(V self, V *args) {
  V v_row_2420 = args[0];
  V v_vars_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2418, heff_dup(heff_rfield(v_row_2420, 0)), heff_get_n(v_row_2420, 1, 2)));
}
V g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666_lam1(V self, V *args) {
  V v_y_2427 = args[0];
  V v_sp_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_2427}), v_sp_242});
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str3, 1, "_");
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry, 7, 0};

V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_rest_246) {
top: ;
  switch (heff_tag_of(v_rest_246)) {
  case TAG_Nil: {
    heff_drop(v_bound_241);
    heff_drop_rec(v_sp_242, 2);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_vars_249 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_rows_2432 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam0, 1, 2, (V[]){v_c_245, v_vars_243}), v_rest_246));
    V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam1, 1, 1, (V[]){heff_dup(v_vars_249)}), v_rows_2432));
    V v_x1_2435 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_241, heff_dup(v_sp_242), v_vars_249, v_t_2434));
    switch (heff_tag_of(v_x1_2435)) {
    case TAG_Left: {
      V v_e_2436 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Left = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
      heff_drop_rec(v_sp_242, 2);
      return heff_tag_at_n(v_ru_24x1_2435_24Left, TAG_Left, 1, (V[]){v_e_2436});
    }
    case TAG_Right: {
      V v_x_2437 = heff_field(v_x1_2435, 0);
      V v_ru_24x1_2435_24Right = heff_take_reuse_n(v_x1_2435, 1ULL, 1);
      V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2435_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str3)}), heff_dup(v_sp_242)});
      V v_b_2441;
      switch (heff_tag_of(v_x_2437)) {
      case TAG_At: {
        V v_s_2440 = heff_dup(heff_field(v_x_2437, 1));
        v_b_2441 = v_s_2440;
        break;
      }
      default: heff_nomatch(v_x_2437);
      }
      V v_t_2442 = ({ V rv_1 = heff_get_n(v_b_2441, 1, 2); V rr_ = heff_rec_reuse_n(v_sp_242, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2438, v_x_2437}), v_t_2442});
      V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2443, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_Right, 1, (V[]){v_t_2444});
    }
    default: return heff_nomatch(v_x1_2435);
    }
  }
  default: return heff_nomatch(v_rest_246);
  }
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(a0, a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a0); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam0(V self, V *args) {
  V v_row_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  V v_vars_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_pats_2411 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(heff_rfield(v_row_2410, 0))));
  V v_t_2412 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_v_2414;
  switch (heff_tag_of(v_t_2412)) {
  case TAG_Nothing: {
    v_v_2414 = ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2413 = heff_field(v_t_2412, 0);
    heff_take_n(v_t_2412, 1ULL, 1);
    v_v_2414 = v_v_2413;
    break;
  }
  default: heff_nomatch(v_t_2412);
  }
  V v_t_2415 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_row_2410, 0), v_c_245));
  V v_x2_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_x2_2417 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str1)});
    break;
  }
  case TAG_Just: {
    V v_p_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_x2_2417 = v_p_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_e_2418 = heff_get_n(v_row_2410, 1, 2);
  V v_rhs_2431;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_PVar: {
    V v_x_2419 = heff_field(v_x2_2417, 0);
    heff_take_n(v_x2_2417, 1ULL, 1);
    if (heff_strEq_c(heff_dup(v_x_2419), ((V)&g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_str2))) {
      heff_drop(v_v_2414);
      heff_drop(v_x_2419);
      v_rhs_2431 = v_e_2418;
    } else {
      if (heff_strEq_c(heff_dup(v_x_2419), heff_dup(v_v_2414))) {
        heff_drop(v_v_2414);
        heff_drop(v_x_2419);
        v_rhs_2431 = v_e_2418;
      } else {
        V v_t_2422 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2419, v_v_2414));
        v_rhs_2431 = heff_tr(heff_call(heff_get_n(v_t_2422, 3, 5), 1, (V[]){v_e_2418}));
      }
    }
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x2_2417, 0ULL, 3);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x2_2417, 0ULL, 1);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PRec: {
    heff_take_n(v_x2_2417, 0ULL, 2);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x2_2417, 0ULL, 2);
    heff_drop(v_v_2414);
    v_rhs_2431 = v_e_2418;
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  return heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2411, v_rhs_2431});
}
V g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860_lam1(V self, V *args) {
  V v_row_2433 = args[0];
  V v_vars_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_249, heff_dup(heff_rfield(v_row_2433, 0)), heff_get_n(v_row_2433, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_str0, 1, "_");
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_entry, 6, 0};

V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245) {
top: ;
  V v_t_2420 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), heff_dup(v_rows_244)));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_t_2420; V r_ = (g_heff_2eelab_2eclauses_2edefaultOf_24s1534527390x1178720860(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
}
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V b_0 = heff_get_n(v_row_246, 0, 2); V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_x1_249 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_x1_249 = v_p_248;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_x1_2419;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_PVar: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_249, 0ULL, 3);
    v_x1_2419 = NTAG(TAG_True);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PRec: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_x1_2419 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  switch (heff_tag_of(v_x1_2419)) {
  case TAG_True: {
    return NTAG(TAG_False);
  }
  case TAG_False: {
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x1_2419);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str1, 1, "_");
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry, 7, 0};

V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_col_246) {
top: ;
  V v_x1_247 = (g_heff_2eelab_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    heff_drop_rec(v_col_246, 3);
    return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 0ULL, 1);
    V v_x1_2410 = (g_heff_2eelab_2eclauses_2enoLitHere(v_sp_242, heff_dup(v_c_245), v_rows_244));
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Left: {
      V v_e_2411 = heff_field(v_x1_2410, 0);
      heff_take_n(v_x1_2410, 1ULL, 1);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop_rec(v_col_246, 3);
      return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2411});
    }
    case TAG_Right: {
      V v_ru_24x1_2410_24Right = heff_take_reuse_n(v_x1_2410, 0ULL, 1);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_col_246, 1))));
      V v_x1_2422 = (g_heff_2eelab_2eclauses_2etraverseC(heff_clo_n(g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam0, 1, 6, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), v_col_246, heff_dup(v_used_240), heff_dup(v_bound_241), heff_dup(v_sp_242)}), v_t_2413));
      switch (heff_tag_of(v_x1_2422)) {
      case TAG_Left: {
        V v_e_2423 = heff_field(v_x1_2422, 0);
        heff_take_n(v_x1_2422, 1ULL, 1);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_rows_244);
        heff_drop(v_c_245);
        heff_drop_cell(v_ru_24x1_2410_24Right, 1);
        return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2423});
      }
      case TAG_Right: {
        V v_x_2424 = heff_field(v_x1_2422, 0);
        heff_take_n(v_x1_2422, 1ULL, 1);
        V v_x1_2425 = (g_heff_2eelab_2eclauses_2edefaultArm_24s1107456745x299754151(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_rows_244, heff_dup(v_c_245)));
        switch (heff_tag_of(v_x1_2425)) {
        case TAG_Left: {
          V v_e_2426 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_vars_243);
          heff_drop(v_c_245);
          heff_drop_cell(v_ru_24x1_2410_24Right, 1);
          heff_drop(v_x_2424);
          return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2426});
        }
        case TAG_Right: {
          V v_x_2427 = heff_field(v_x1_2425, 0);
          heff_take_n(v_x1_2425, 1ULL, 1);
          V v_t_2428 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
          V v_t_2430;
          switch (heff_tag_of(v_t_2428)) {
          case TAG_Nothing: {
            v_t_2430 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str1);
            break;
          }
          case TAG_Just: {
            V v_v_2429 = heff_field(v_t_2428, 0);
            heff_take_n(v_t_2428, 1ULL, 1);
            v_t_2430 = v_v_2429;
            break;
          }
          default: heff_nomatch(v_t_2428);
          }
          V v_t_2431 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_247_24Right, TAG_IVar, 1, (V[]){v_t_2430}), heff_dup(v_sp_242)});
          V v_t_2432 = heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2431, (g_heff_2eelab_2eclauses_2eappendC(v_x_2424, v_x_2427))});
          return heff_tag_at_n(v_ru_24x1_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2432, v_sp_242})});
        }
        default: return heff_nomatch(v_x1_2425);
        }
      }
      default: return heff_nomatch(v_x1_2422);
      }
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_lam0(V self, V *args) {
  V v_t_2414 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_col_246 = heff_env(self)[2];
  V v_used_240 = heff_env(self)[3];
  V v_bound_241 = heff_env(self)[4];
  V v_sp_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
  V v_v_2417;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    v_v_2417 = ((V)&g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2416 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    v_v_2417 = v_v_2416;
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  V v_x2_2418 = ({ V a_0 = heff_dup(heff_rfield(v_t_2414, 0)); V b_1 = heff_get_n(v_col_246, 0, 3); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  V v_arm_2420;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nothing: {
    v_arm_2420 = heff_rec_n(3, shape_row__bad__rows, (V[]){v_t_2414, NTAG(TAG_False), NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_arm_2419 = heff_field(v_x2_2418, 0);
    heff_take_n(v_x2_2418, 1ULL, 1);
    heff_drop_rec(v_t_2414, 4);
    v_arm_2420 = v_arm_2419;
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2421 = (g_heff_2eelab_2eclauses_2earmFields(v_used_240, v_bound_241, heff_dup(heff_rfield(v_arm_2420, 0)), v_v_2417));
  return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_c_245; V a_5 = v_arm_2420; V a_6 = v_t_2421; V r_ = (g_heff_2eelab_2eclauses_2earmWith_24s1217737348x766777666(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_used_240); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str2, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str3, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str4, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str5, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str6, 7, "floatEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str7, 5, "strEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str8, 6, "runeEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str9, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str10, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str11, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str12, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str13, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str14, 5, "False");
HEFF_LIT(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str15, 5, "False");
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry, 7, 0};

V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_l_246) {
top: ;
  V v_x1_247 = (g_heff_2eelab_2eclauses_2elitChecks(v_sp_242, v_vars_243, v_rows_244, heff_dup(v_c_245), v_l_246));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_c_245);
    heff_drop(v_l_246);
    return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 0ULL, 1);
    V v_vars_2410 = (g_heff_2eelab_2eclauses_2edropAt(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_t_2413;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      v_t_2413 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str0);
      break;
    }
    case TAG_Just: {
      V v_v_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      v_t_2413 = v_v_2412;
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_rows_2414 = (g_heff_2eelab_2eclauses_2elitYes(heff_dup(v_c_245), v_l_246, v_t_2413, v_rows_244));
    V v_t_2416 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam0, 1, 1, (V[]){heff_dup(v_vars_2410)}), v_rows_2414));
    V v_x1_2417 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, heff_dup(v_bound_241), heff_dup(v_sp_242), v_vars_2410, v_t_2416));
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Left: {
      V v_e_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 1);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_l_246);
      return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2418});
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_x1_2417, 0);
      V v_ru_24x1_2417_24Right = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
      V v_rows_2420 = (g_heff_2eelab_2eclauses_2elitNo(heff_dup(v_c_245), v_l_246, v_rows_244));
      V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam1, 1, 1, (V[]){heff_dup(v_vars_243)}), v_rows_2420));
      V v_x1_2423 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_241, heff_dup(v_sp_242), heff_dup(v_vars_243), v_t_2422));
      switch (heff_tag_of(v_x1_2423)) {
      case TAG_Left: {
        V v_e_2424 = heff_field(v_x1_2423, 0);
        heff_take_n(v_x1_2423, 1ULL, 1);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_c_245);
        heff_drop(v_l_246);
        heff_drop(v_x_2419);
        heff_drop_cell(v_ru_24x1_2417_24Right, 1);
        return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Left, 1, (V[]){v_e_2424});
      }
      case TAG_Right: {
        V v_x_2425 = heff_field(v_x1_2423, 0);
        V v_ru_24x1_2423_24Right = heff_take_reuse_n(v_x1_2423, 1ULL, 1);
        V v_t_2426 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
        V v_t_2428;
        switch (heff_tag_of(v_t_2426)) {
        case TAG_Nothing: {
          v_t_2428 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str1);
          break;
        }
        case TAG_Just: {
          V v_v_2427 = heff_field(v_t_2426, 0);
          heff_take_n(v_t_2426, 1ULL, 1);
          v_t_2428 = v_v_2427;
          break;
        }
        default: heff_nomatch(v_t_2426);
        }
        V v_t_2447;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_x11_2429 = heff_dup(heff_field(v_l_246, 0));
          switch (heff_tag_of(v_x11_2429)) {
          case TAG_PatVar: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str2);
            break;
          }
          case TAG_PatTag: {
            heff_take_n(v_x11_2429, 0ULL, 3);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str3);
            break;
          }
          case TAG_PatOp: {
            heff_take_n(v_x11_2429, 0ULL, 3);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str4);
            break;
          }
          case TAG_PatInt: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str5);
            break;
          }
          case TAG_PatFloat: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str6);
            break;
          }
          case TAG_PatString: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str7);
            break;
          }
          case TAG_PatRune: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str8);
            break;
          }
          case TAG_PatRecord: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str9);
            break;
          }
          case TAG_PatWord: {
            heff_take_n(v_x11_2429, 0ULL, 1);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str10);
            break;
          }
          case TAG_PatAs: {
            heff_take_n(v_x11_2429, 0ULL, 3);
            v_t_2447 = ((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str11);
            break;
          }
          default: heff_nomatch(v_x11_2429);
          }
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2448 = heff_tag_n(TAG_ILitEq, 4, (V[]){v_t_2428, v_sp_242, v_t_2447, (g_heff_2eelab_2eclauses_2elitExpr(heff_dup(v_l_246)))});
        V v_t_2451;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2450 = heff_dup(heff_field(v_l_246, 1));
          v_t_2451 = v_s_2450;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_tsp_2454;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2453 = heff_dup(heff_field(v_l_246, 1));
          v_tsp_2454 = v_s_2453;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2455 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str12), heff_dup(v_tsp_2454), NTAG(TAG_Nil)});
        V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_247_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str13)}), heff_dup(v_tsp_2454)});
        V v_x1_2457 = ({ V a_0 = v_t_2456; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_b_2460;
        switch (heff_tag_of(v_x1_2457)) {
        case TAG_At: {
          V v_s_2459 = heff_field(v_x1_2457, 1);
          heff_take_n(v_x1_2457, 2ULL, 2);
          v_b_2460 = v_s_2459;
          break;
        }
        default: heff_nomatch(v_x1_2457);
        }
        V v_t_2461 = ({ V rv_1 = heff_get_n(v_b_2460, 1, 2); V rr_ = heff_rec_reuse_n(v_tsp_2454, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_p_2462 = heff_tag_n(TAG_At, 2, (V[]){v_t_2455, v_t_2461});
        V v_a_2465;
        switch (heff_tag_of(v_p_2462)) {
        case TAG_At: {
          V v_s_2464 = heff_dup(heff_field(v_p_2462, 1));
          v_a_2465 = v_s_2464;
          break;
        }
        default: heff_nomatch(v_p_2462);
        }
        V v_b_2468;
        switch (heff_tag_of(v_x_2419)) {
        case TAG_At: {
          V v_s_2467 = heff_dup(heff_field(v_x_2419, 1));
          v_b_2468 = v_s_2467;
          break;
        }
        default: heff_nomatch(v_x_2419);
        }
        V v_t_2469 = ({ V rv_1 = heff_get_n(v_b_2468, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2465, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2470 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2462, v_x_2419}), v_t_2469});
        V v_tsp_2473;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2472 = heff_dup(heff_field(v_l_246, 1));
          v_tsp_2473 = v_s_2472;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        V v_t_2474 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str14), heff_dup(v_tsp_2473), NTAG(TAG_Nil)});
        V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x1_2417_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_str15)}), heff_dup(v_tsp_2473)});
        V v_x1_2476 = ({ V a_0 = v_t_2475; V b_1 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, b_1)); heff_drop(b_1); r_; });
        V v_b_2479;
        switch (heff_tag_of(v_x1_2476)) {
        case TAG_At: {
          V v_s_2478 = heff_field(v_x1_2476, 1);
          heff_take_n(v_x1_2476, 2ULL, 2);
          v_b_2479 = v_s_2478;
          break;
        }
        default: heff_nomatch(v_x1_2476);
        }
        V v_t_2480 = ({ V rv_1 = heff_get_n(v_b_2479, 1, 2); V rr_ = heff_rec_reuse_n(v_tsp_2473, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_p_2481 = heff_tag_n(TAG_At, 2, (V[]){v_t_2474, v_t_2480});
        V v_a_2484;
        switch (heff_tag_of(v_p_2481)) {
        case TAG_At: {
          V v_s_2483 = heff_dup(heff_field(v_p_2481, 1));
          v_a_2484 = v_s_2483;
          break;
        }
        default: heff_nomatch(v_p_2481);
        }
        V v_b_2487;
        switch (heff_tag_of(v_x_2425)) {
        case TAG_At: {
          V v_s_2486 = heff_dup(heff_field(v_x_2425, 1));
          v_b_2487 = v_s_2486;
          break;
        }
        default: heff_nomatch(v_x_2425);
        }
        V v_t_2488 = ({ V rv_1 = heff_get_n(v_b_2487, 1, 2); V rr_ = heff_rec_reuse_n(v_a_2484, 1ULL, 2, shape_start__end); heff_rfield(rr_, 1) = rv_1; rr_; });
        V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2481, v_x_2425}), v_t_2488});
        V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
        V v_t_2491 = heff_tag_n(TAG_CMatch, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_t_2451}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2470, v_t_2490})});
        V v_t_2494;
        switch (heff_tag_of(v_l_246)) {
        case TAG_At: {
          V v_s_2493 = heff_field(v_l_246, 1);
          heff_take_n(v_l_246, 2ULL, 2);
          v_t_2494 = v_s_2493;
          break;
        }
        default: heff_nomatch(v_l_246);
        }
        return heff_tag_at_n(v_ru_24x1_2423_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2491, v_t_2494})});
      }
      default: return heff_nomatch(v_x1_2423);
      }
    }
    default: return heff_nomatch(v_x1_2417);
    }
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(a0, a[1], a[2], a[3], a4, a[5], a[6]); heff_drop(a0); heff_drop(a4); return r;
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam0(V self, V *args) {
  V v_row_2415 = args[0];
  V v_vars_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2410, heff_dup(heff_rfield(v_row_2415, 0)), heff_get_n(v_row_2415, 1, 2)));
}
V g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_lam1(V self, V *args) {
  V v_row_2421 = args[0];
  V v_vars_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_243, heff_dup(heff_rfield(v_row_2421, 0)), heff_get_n(v_row_2421, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str1, 1, "_");
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry, 8, 0};

V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_fs_246, V v_ys_247) {
top: ;
  V v_x1_248 = (g_heff_2eelab_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24Left = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    heff_drop(v_fs_246);
    heff_drop(v_ys_247);
    return heff_tag_at_n(v_ru_24x1_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_ru_24x1_248_24Right = heff_take_reuse_n(v_x1_248, 0ULL, 1);
    V v_bound_2411 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_247), v_bound_241));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2413 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_245), MK_INT(1LL)), heff_dup(v_vars_243)));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_247), v_t_2413));
    V v_vars_2415 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2412, v_t_2414));
    V v_rows_2420 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam0, 1, 3, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_fs_246)}), v_rows_244));
    V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam1, 1, 1, (V[]){heff_dup(v_vars_2415)}), v_rows_2420));
    V v_x1_2423 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_2411, heff_dup(v_sp_242), v_vars_2415, v_t_2422));
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Left: {
      V v_e_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_fs_246);
      heff_drop(v_ys_247);
      return heff_tag_at_n(v_ru_24x1_248_24Right, TAG_Left, 1, (V[]){v_e_2424});
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      V v_t_2426 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
      V v_t_2428;
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Nothing: {
        v_t_2428 = ((V)&g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str1);
        break;
      }
      case TAG_Just: {
        V v_v_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2428 = v_v_2427;
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      V v_t_2429 = (g_heff_2eelab_2eclauses_2ezipC(v_fs_246, v_ys_247));
      return heff_tag_at_n(v_ru_24x1_248_24Right, TAG_Right, 1, (V[]){(g_heff_2eelab_2eclauses_2eletFields(v_sp_242, v_t_2428, v_t_2429, v_x_2425))});
    }
    default: return heff_nomatch(v_x1_2423);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam0(V self, V *args) {
  V v_row_2416 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_fs_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    v_t_2419 = ((V)&g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    v_t_2419 = v_v_2418;
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  return (g_heff_2eelab_2eclauses_2erecSpecialize(v_c_245, v_fs_246, v_t_2419, v_row_2416));
}
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam1(V self, V *args) {
  V v_row_2421 = args[0];
  V v_vars_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2415, heff_dup(heff_rfield(v_row_2421, 0)), heff_get_n(v_row_2421, 1, 2)));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry, 6, 0};

V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245) {
top: ;
  V v_t_2420 = (g_heff_2eelab_2eclauses_2econcatMapC(heff_clo_n(g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), v_rows_244));
  V v_t_2421 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2420));
  V v_t_2422 = (g_heff_2eelab_2eclauses_2erecSubs(v_used_240, v_bound_241, heff_dup(v_c_245), heff_dup(v_rows_244)));
  return (g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2421, v_t_2422));
}
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(a0, a[1], a[2], a[3], a[4], a[5]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = ({ V b_0 = heff_get_n(v_row_246, 0, 2); V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    v_x1_249 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_x1_249 = v_p_248;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2419;
  switch (heff_tag_of(v_x1_249)) {
  case TAG_PVar: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_249, 0ULL, 3);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_249, 0ULL, 1);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2415 = heff_field(v_x1_249, 0);
    heff_take_n(v_x1_249, 1ULL, 2);
    v_t_2419 = v_fps_2415;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_249, 0ULL, 2);
    v_t_2419 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_249);
  }
  return (g_list_2emap_24s1415906091x1371825187(v_t_2419));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str2, 1, "_");
Clo g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry, 7, 0};

V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_p_246)) {
  case TAG_PVar: {
    heff_take_n(v_p_246, 0ULL, 1);
    V v_t_248 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_v_2410;
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      v_v_2410 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str0);
      break;
    }
    case TAG_Just: {
      V v_v_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      v_v_2410 = v_v_249;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_t_2411 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2412 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2410, v_t_2411, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2412);
  }
  case TAG_PTag: {
    heff_take_n(v_p_246, 0ULL, 3);
    V v_t_2416 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_v_2418;
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      v_v_2418 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str1);
      break;
    }
    case TAG_Just: {
      V v_v_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      v_v_2418 = v_v_2417;
      break;
    }
    default: heff_nomatch(v_t_2416);
    }
    V v_t_2419 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2420 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2418, v_t_2419, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2420);
  }
  case TAG_PLit: {
    V v_l_2421 = heff_field(v_p_246, 0);
    V v_ru_24p_246_24PLit = heff_take_reuse_n(v_p_246, 1ULL, 1);
    V v_x1_2422 = (g_heff_2eelab_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
    switch (heff_tag_of(v_x1_2422)) {
    case TAG_Left: {
      V v_e_2423 = heff_field(v_x1_2422, 0);
      heff_take_n(v_x1_2422, 1ULL, 1);
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_rows_244);
      heff_drop(v_c_245);
      heff_drop(v_l_2421);
      return heff_tag_at_n(v_ru_24p_246_24PLit, TAG_Left, 1, (V[]){v_e_2423});
    }
    case TAG_Right: {
      heff_take_n(v_x1_2422, 0ULL, 1);
      heff_drop_cell(v_ru_24p_246_24PLit, 1);
      return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = v_l_2421; V r_ = (g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
    }
    default: return heff_nomatch(v_x1_2422);
    }
  }
  case TAG_PRec: {
    heff_take_n(v_p_246, 0ULL, 2);
    return (g_heff_2eelab_2eclauses_2erecordOf_24s439989813x1445431886(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245));
  }
  case TAG_PAs: {
    heff_take_n(v_p_246, 0ULL, 2);
    V v_t_2429 = (g_heff_2eelab_2eclauses_2enthC(v_vars_243, heff_dup(v_c_245)));
    V v_v_2431;
    switch (heff_tag_of(v_t_2429)) {
    case TAG_Nothing: {
      v_v_2431 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_str2);
      break;
    }
    case TAG_Just: {
      V v_v_2430 = heff_field(v_t_2429, 0);
      heff_take_n(v_t_2429, 1ULL, 1);
      v_v_2431 = v_v_2430;
      break;
    }
    default: heff_nomatch(v_t_2429);
    }
    V v_t_2432 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_map_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2433 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2431, v_t_2432, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2433);
  }
  default: return heff_nomatch(v_p_246);
  }
}
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(a0, a[1], a[2], a[3], a[4], a[5], a[6]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str1, 1, "_");
Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry, 5, 0};

V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244) {
top: ;
  switch (heff_tag_of(v_rows_244)) {
  case TAG_Nil: {
    heff_drop(v_bound_241);
    heff_drop(v_vars_243);
    V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){NTAG(TAG_CAbandon), v_sp_242});
    return heff_tag_n(TAG_Right, 1, (V[]){v_t_245});
  }
  case TAG_Cons: {
    V v_row_246 = heff_dup(heff_field(v_rows_244, 0));
    V v_t_248 = (g_heff_2eelab_2eclauses_2efindTagLit(heff_rfield(v_row_246, 0), MK_INT(0LL)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Nothing: {
      heff_drop(v_bound_241);
      heff_drop(v_sp_242);
      heff_drop_tag(v_rows_244, 2);
      V v_t_249 = (g_heff_2eelab_2eclauses_2ezipC(v_vars_243, heff_take_field(v_row_246, 0)));
      return heff_tag_n(TAG_Right, 1, (V[]){({ V a_0 = ((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str0); V a_1 = heff_get_n(v_row_246, 1, 2); V a_2 = v_t_249; V r_ = (g_list_2efoldl_24s1819302915x1539612842(a_0, a_1, a_2)); heff_drop(v_t_249); r_; })});
    }
    case TAG_Just: {
      V v_c_2410 = heff_field(v_t_248, 0);
      V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
      V v_t_2411 = ({ V b_0 = heff_get_n(v_row_246, 0, 2); V a_1 = heff_dup(v_c_2410); V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
      V v_t_2413;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        v_t_2413 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_str1)});
        break;
      }
      case TAG_Just: {
        V v_p_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        v_t_2413 = v_p_2412;
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      return (g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_2410, v_t_2413));
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_rows_244);
  }
}
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2edesugarCols_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edesugarCols_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edesugarCols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edesugarCols_entry, 5, 0};

V g_heff_2eelab_2eclauses_2edesugarCols(V v_params_240, V v_sp_241, V v_rows_242, V v_used_243, V v_cols_244) {
top: ;
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edesugarCols_lam0, 1, 1, (V[]){heff_dup(v_cols_244)}), v_rows_242));
  V v_x1_247 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_243, heff_dup(v_cols_244), heff_dup(v_sp_241), heff_dup(v_cols_244), v_t_246));
  switch (heff_tag_of(v_x1_247)) {
  case TAG_Left: {
    V v_e_248 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Left = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    heff_drop_rec(v_sp_241, 2);
    heff_drop(v_cols_244);
    return heff_tag_at_n(v_ru_24x1_247_24Left, TAG_Left, 1, (V[]){v_e_248});
  }
  case TAG_Right: {
    V v_x_249 = heff_field(v_x1_247, 0);
    V v_ru_24x1_247_24Right = heff_take_reuse_n(v_x1_247, 1ULL, 1);
    V v_t_2410 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_params_240));
    V v_t_2411 = (g_heff_2eelab_2eclauses_2edropC(v_t_2410, v_cols_244));
    return heff_tag_at_n(v_ru_24x1_247_24Right, TAG_Right, 1, (V[]){({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2edesugarCols_lam1, 2, 1, (V[]){v_sp_241}); V a_1 = v_x_249; V a_2 = v_t_2411; V r_ = heff_tr(g_heff_2eelab_2eclauses_2efoldr2(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; })});
  }
  default: return heff_nomatch(v_x1_247);
  }
}
V g_heff_2eelab_2eclauses_2edesugarCols_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2eelab_2eclauses_2edesugarCols(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2eelab_2eclauses_2edesugarCols_lam0(V self, V *args) {
  V v_row_245 = args[0];
  V v_cols_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_cols_244, heff_dup(heff_rfield(v_row_245, 0)), heff_get_n(v_row_245, 1, 2)));
}
V g_heff_2eelab_2eclauses_2edesugarCols_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_b_2413 = args[1];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_b_2416;
  switch (heff_tag_of(v_b_2413)) {
  case TAG_At: {
    V v_s_2415 = heff_dup(heff_field(v_b_2413, 1));
    v_b_2416 = v_s_2415;
    break;
  }
  default: heff_nomatch(v_b_2413);
  }
  V v_t_2417 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_241, 0)); V rr_ = heff_rec_reuse_n(v_b_2416, 2ULL, 2, shape_start__end); heff_rfield(rr_, 0) = rv_0; rr_; });
  return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_2412, v_sp_241, v_b_2413}), v_t_2417});
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_2412;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkEquation: {
        V v_a_247 = heff_field(v_a_243, 2);
        V v_a_248 = heff_field(v_a_243, 3);
        heff_take_n(v_a_243, 12ULL, 4);
        V v_a_249 = (g_heff_2eelab_2eclauses_2etraverseC_24s1165186369x1597155776(v_a_247));
        switch (heff_tag_of(v_a_249)) {
        case TAG_Left: {
          V v_a_2410 = heff_field(v_a_249, 0);
          V v_ru_24a_249_24Left = heff_take_reuse_n(v_a_249, 1ULL, 1);
          heff_drop(v_a_248);
          v_x1_2412 = heff_tag_at_n(v_ru_24a_249_24Left, TAG_Left, 1, (V[]){v_a_2410});
          break;
        }
        case TAG_Right: {
          V v_a_2411 = heff_field(v_a_249, 0);
          V v_ru_24a_249_24Right = heff_take_reuse_n(v_a_249, 1ULL, 1);
          v_x1_2412 = heff_tag_at_n(v_ru_24a_249_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_a_2411, v_a_248})});
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2412)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Left = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      heff_drop(v_xs_242);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      return heff_tag_at_n(v_ru_24x1_2412_24Left, TAG_Left, 1, (V[]){v_e_2413});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x1_2412, 0);
      V v_ru_24x1_2412_24Right = heff_take_reuse_n(v_x1_2412, 1ULL, 1);
      V v_x1_2415 = (g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217(v_xs_242));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_Left: {
        V v_e_2416 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        heff_drop(v_x_2414);
        return heff_tag_at_n(v_ru_24x1_2412_24Right, TAG_Left, 1, (V[]){v_e_2416});
      }
      case TAG_Right: {
        V v_x_2417 = heff_field(v_x1_2415, 0);
        heff_take_n(v_x1_2415, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2412_24Right, TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_2414, v_x_2417})});
      }
      default: return heff_nomatch(v_x1_2415);
      }
    }
    default: return heff_nomatch(v_x1_2412);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217(a[0]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(heff_rfield(v_x_242, 1)), v_acc_241));
    V v_t_245 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s1211269178x968723598(heff_rfield(v_x_242, 0), v_t_244));
    V t_0 = v_xs_243;
    V t_1 = v_t_245;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str0, 43, "a definition by equations needs an equation");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str1, 19, "every equation of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str2, 6, "` has ");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str3, 11, " pattern(s)");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str4, 18, "the equations of `");
HEFF_LIT(g_heff_2eelab_2eclauses_2edesugar_str5, 37, "` match fewer arguments than it names");
V g_heff_2eelab_2eclauses_2edesugar_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2edesugar_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2edesugar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edesugar_entry, 4, 0};

V g_heff_2eelab_2eclauses_2edesugar(V v_f_240, V v_params_241, V v_eqNs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eelab_2eclauses_2etraverseC_24s496605790x1649023217(v_eqNs_242));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Left: {
    V v_e_245 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Left = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    heff_drop(v_f_240);
    heff_drop(v_params_241);
    heff_drop(v_sp_243);
    return heff_tag_at_n(v_ru_24x1_244_24Left, TAG_Left, 1, (V[]){v_e_245});
  }
  case TAG_Right: {
    V v_x_246 = heff_field(v_x1_244, 0);
    V v_ru_24x1_244_24Right = heff_take_reuse_n(v_x1_244, 1ULL, 1);
    V v_x1_249;
    switch (heff_tag_of(v_x_246)) {
    case TAG_Nil: {
      v_x1_249 = heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){heff_dup(v_sp_243), ((V)&g_heff_2eelab_2eclauses_2edesugar_str0)})});
      break;
    }
    case TAG_Cons: {
      V v_r_247 = heff_dup(heff_field(v_x_246, 0));
      v_x1_249 = heff_tag_at_n(v_ru_24x1_244_24Right, TAG_Right, 1, (V[]){({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_r_247, 0, 2); V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, b_2)); heff_drop(b_2); r_; })});
      break;
    }
    default: heff_nomatch(v_x_246);
    }
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Left: {
      V v_e_2410 = heff_field(v_x1_249, 0);
      V v_ru_24x1_249_24Left = heff_take_reuse_n(v_x1_249, 1ULL, 1);
      heff_drop(v_f_240);
      heff_drop(v_params_241);
      heff_drop(v_sp_243);
      heff_drop(v_x_246);
      return heff_tag_at_n(v_ru_24x1_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
    }
    case TAG_Right: {
      V v_x_2411 = heff_field(v_x1_249, 0);
      V v_ru_24x1_249_24Right = heff_take_reuse_n(v_x1_249, 1ULL, 1);
      V v_x1_2420 = (g_heff_2eelab_2eclauses_2eforC(v_x_246, heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_lam0, 1, 2, (V[]){heff_dup(v_x_2411), heff_dup(v_f_240)})));
      switch (heff_tag_of(v_x1_2420)) {
      case TAG_Left: {
        V v_e_2421 = heff_field(v_x1_2420, 0);
        heff_take_n(v_x1_2420, 1ULL, 1);
        heff_drop(v_f_240);
        heff_drop(v_params_241);
        heff_drop(v_sp_243);
        heff_drop(v_x_246);
        heff_drop(v_x_2411);
        return heff_tag_at_n(v_ru_24x1_249_24Right, TAG_Left, 1, (V[]){v_e_2421});
      }
      case TAG_Right: {
        V v_ru_24x1_2420_24Right = heff_take_reuse_n(v_x1_2420, 0ULL, 1);
        V v_t_2423 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_params_241));
        V v_e_2426;
        if (heff_intLt_c(heff_dup(v_x_2411), v_t_2423)) {
          V v_t_2425 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_str4), heff_strAppend(heff_dup(v_f_240), ((V)&g_heff_2eelab_2eclauses_2edesugar_str5)));
          v_e_2426 = heff_tag_at_n(v_ru_24x1_249_24Right, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){heff_dup(v_sp_243), v_t_2425})});
        } else {
          v_e_2426 = heff_tag_at_n(v_ru_24x1_249_24Right, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        switch (heff_tag_of(v_e_2426)) {
        case TAG_Left: {
          V v_e_2427 = heff_field(v_e_2426, 0);
          heff_take_n(v_e_2426, 1ULL, 1);
          heff_drop(v_f_240);
          heff_drop(v_params_241);
          heff_drop(v_sp_243);
          heff_drop(v_x_246);
          heff_drop(v_x_2411);
          return heff_tag_at_n(v_ru_24x1_2420_24Right, TAG_Left, 1, (V[]){v_e_2427});
        }
        case TAG_Right: {
          heff_take_n(v_e_2426, 0ULL, 1);
          heff_drop_cell(v_ru_24x1_2420_24Right, 1);
          V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_240, NTAG(TAG_Nil)});
          V v_t_2430 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_params_241), v_t_2429));
          V v_used_2431 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s161443325x1141805937(v_x_246, v_t_2430));
          V v_t_2432 = (g_heff_2eelab_2eclauses_2eupToGo(MK_INT(0LL), v_x_2411));
          V v_t_2434 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2edesugar_lam1, 1, 3, (V[]){heff_dup(v_used_2431), heff_dup(v_params_241), heff_dup(v_x_246)}), v_t_2432));
          return ({ V a_0 = v_params_241; V a_1 = v_sp_243; V a_2 = v_x_246; V a_3 = v_used_2431; V a_4 = v_t_2434; V r_ = (g_heff_2eelab_2eclauses_2edesugarCols(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_params_241); heff_drop(v_used_2431); r_; });
        }
        default: return heff_nomatch(v_e_2426);
        }
      }
      default: return heff_nomatch(v_x1_2420);
      }
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2eelab_2eclauses_2edesugar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edesugar(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2edesugar_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_r_2412, 0)));
  if (heff_intEq_c(v_t_2413, heff_dup(v_x_2411))) {
    heff_drop_rec(v_r_2412, 2);
    heff_drop(v_x_2411);
    heff_drop(v_f_240);
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  } else {
    V v_t_2415 = heff_get_n(v_r_2412, 1, 2);
    V v_span_2418;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_At: {
      V v_s_2417 = heff_field(v_t_2415, 1);
      heff_take_n(v_t_2415, 2ULL, 2);
      v_span_2418 = v_s_2417;
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    V v_t_2419 = heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_str1), heff_strAppend(v_f_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2edesugar_str2), heff_strAppend(heff_intShow(v_x_2411), ((V)&g_heff_2eelab_2eclauses_2edesugar_str3)))));
    return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2418, v_t_2419})});
  }
}
V g_heff_2eelab_2eclauses_2edesugar_lam1(V self, V *args) {
  V v_i_2433 = args[0];
  V v_used_2431 = heff_env(self)[0];
  V v_params_241 = heff_env(self)[1];
  V v_x_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_used_2431; V a_1 = v_params_241; V a_2 = v_x_246; V a_3 = v_i_2433; V r_ = (g_heff_2eelab_2eclauses_2ecolName(a_0, a_1, a_2, a_3)); heff_drop(v_used_2431); heff_drop(v_params_241); r_; });
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2ecaseTreeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecaseTreeOf_entry, 4, 0};

V g_heff_2eelab_2eclauses_2ecaseTreeOf(V v_sp_240, V v_rows_241, V v_used_242, V v_x_243) {
top: ;
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_248 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0, 1, 1, (V[]){heff_dup(v_x_243)}), v_rows_241));
  V v_x1_249 = ({ V b_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), v_used_242}); V a_1 = v_t_244; V a_2 = v_sp_240; V a_3 = v_t_245; V a_4 = v_t_248; V r_ = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x1_249)) {
  case TAG_Left: {
    V v_e_2410 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Left = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    heff_drop(v_x_243);
    return heff_tag_at_n(v_ru_24x1_249_24Left, TAG_Left, 1, (V[]){v_e_2410});
  }
  case TAG_Right: {
    V v_x_2411 = heff_field(v_x1_249, 0);
    V v_ru_24x1_249_24Right = heff_take_reuse_n(v_x1_249, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x1_249_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_scrutinee__tree, (V[]){v_x_243, v_x_2411})});
  }
  default: return heff_nomatch(v_x1_249);
  }
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ecaseTreeOf(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2eclauses_2ecaseTreeOf_lam0(V self, V *args) {
  V v_row_246 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
  return (g_heff_2eelab_2eclauses_2epeelCols(v_t_247, heff_dup(heff_rfield(v_row_246, 0)), heff_get_n(v_row_246, 1, 2)));
}
Clo g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_entry, 1, 0};

V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_x1_2411;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_a_243 = heff_field(v_x_241, 0);
      heff_take_n(v_x_241, 1ULL, 2);
      switch (heff_tag_of(v_a_243)) {
      case TAG_MkAlt: {
        V v_a_245 = heff_field(v_a_243, 0);
        V v_a_246 = heff_field(v_a_243, 1);
        heff_take_n(v_a_243, 3ULL, 2);
        V v_a_247 = (g_heff_2eelab_2eclauses_2epat(v_a_245));
        switch (heff_tag_of(v_a_247)) {
        case TAG_Left: {
          V v_a_248 = heff_field(v_a_247, 0);
          V v_ru_24a_247_24Left = heff_take_reuse_n(v_a_247, 1ULL, 1);
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_a_246);
          v_x1_2411 = heff_tag_at_n(v_ru_24a_247_24Left, TAG_Left, 1, (V[]){v_a_248});
          break;
        }
        case TAG_Right: {
          V v_a_249 = heff_field(v_a_247, 0);
          V v_ru_24a_247_24Right = heff_take_reuse_n(v_a_247, 1ULL, 1);
          V v_t_2410 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_249, NTAG(TAG_Nil)});
          v_x1_2411 = heff_tag_at_n(v_ru_24a_247_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_t_2410, v_a_246})});
          break;
        }
        default: heff_nomatch(v_a_247);
        }
        break;
      }
      default: heff_nomatch(v_a_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Left = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      heff_drop(v_xs_242);
      return heff_tag_at_n(v_ru_24x1_2411_24Left, TAG_Left, 1, (V[]){v_e_2412});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x1_2411, 0);
      V v_ru_24x1_2411_24Right = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
      V v_x1_2414 = (g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(v_xs_242));
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_Left: {
        V v_e_2415 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        heff_drop(v_x_2413);
        return heff_tag_at_n(v_ru_24x1_2411_24Right, TAG_Left, 1, (V[]){v_e_2415});
      }
      case TAG_Right: {
        V v_x_2416 = heff_field(v_x1_2414, 0);
        heff_take_n(v_x1_2414, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x1_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2416})});
      }
      default: return heff_nomatch(v_x1_2414);
      }
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etraverseC_24s1208919143x1208023355(a[0]);
}