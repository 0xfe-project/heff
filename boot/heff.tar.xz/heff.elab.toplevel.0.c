// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_AsDefinition 21504
#define TAG_AsInstance 47888
#define TAG_At 8900
#define TAG_Become 65038
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_HGlobal 55847
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_Inst 64617
#define TAG_IntNum 31256
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpId 35501
#define TAG_Throw 56084
#define LBL_aliases 1464806715
#define LBL_ambiguous 1121143746
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_broken 566525696
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_diags 296935042
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_hidden 729654485
#define LBL_implicit 319715269
#define LBL_infos 301706655
#define LBL_instances 1653559473
#define LBL_insts 301719303
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_level 304224158
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_nextMeta 21843381
#define LBL_note 9882809
#define LBL_order 307364712
#define LBL_places 961367927
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_prim 9944941
#define LBL_recovered 474271923
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_selfKey 62480824
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tests 311609915
#define LBL_tm 10464
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_typ 324869
#define LBL_type_5f 312202367
#define LBL_unexposed 2027212082
#define LBL_val 326043
#define LBL_value 313331083
#define LBL_values 1123329101
#define LBL_watches 1357821955
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_globals__diags__keys__broken__watches__tests__spans__infos__trace[] = {LBL_globals, LBL_diags, LBL_keys, LBL_broken, LBL_watches, LBL_tests, LBL_spans, LBL_infos, LBL_trace};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_key__module[] = {LBL_key, LBL_module};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_name__level[] = {LBL_name, LBL_level};
static uint32_t shape_name__ty__tm__prim[] = {LBL_name, LBL_ty, LBL_tm, LBL_prim};
static uint32_t shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances[] = {LBL_order, LBL_entries, LBL_aliases, LBL_broken, LBL_ambiguous, LBL_places, LBL_hidden, LBL_unexposed, LBL_instances};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s2023162438x1917167210(V, V, V);
V g_co_2ebind_24s2023162438x1917167210_entry(V self, V *a);
extern Clo g_co_2ebind_24s2023162438x1917167210_clo;
V g_co_2ebind_24s591410632x427349444(V, V, V);
V g_co_2ebind_24s591410632x427349444_entry(V self, V *a);
extern Clo g_co_2ebind_24s591410632x427349444_clo;
V g_heff_2ecompile_2eprims_2ebasicPrims_get(void);
HeffT2 g_heff_2eelab_2eclauses_2edesugar_24cpr(V, V, V, V);
V g_heff_2eelab_2eenvironment_2etryE(V, V, V);
V g_heff_2eelab_2eenvironment_2etryE_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2etryE_clo;
V g_heff_2eelab_2eglobals_2eaddEntry(V, V, V);
V g_heff_2eelab_2eglobals_2eaddEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eaddEntry_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V);
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V);
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eappendM(V, V);
V g_heff_2eelab_2etoplevel_2eappendM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendM_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24dps(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24dps_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo;
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps_clo;
V g_heff_2eelab_2etoplevel_2eargBinding(V);
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eargBinding_clo;
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void);
V g_heff_2eelab_2etoplevel_2ebodyPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ebodyPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyPhase_clo;
V g_heff_2eelab_2etoplevel_2echeckStuck(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2echeckStuck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckStuck_clo;
V g_heff_2eelab_2etoplevel_2echeckUnsolved(V, V, V);
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo;
V g_heff_2eelab_2etoplevel_2echecksOnly(V);
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkHeadOf(V, V);
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo;
HeffT1 g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2econcatMapM(V, V);
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2edoPat(V);
V g_heff_2eelab_2etoplevel_2edoPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoPat_clo;
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo;
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218_clo;
V g_heff_2eelab_2etoplevel_2eequationsBody(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsBody_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsBody_clo;
V g_heff_2eelab_2etoplevel_2eequationsD(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eequationsD_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames(V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo;
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(V, V);
V g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eexplicitNames_24dps_clo;
V g_heff_2eelab_2etoplevel_2eflatPat(V);
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eflatPat_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V, V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enominalTyp(V);
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
V g_heff_2eelab_2etoplevel_2epoisonedLeft(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_clo;
V g_heff_2eelab_2etoplevel_2eprimKnown(V, V);
V g_heff_2eelab_2etoplevel_2eprimKnown_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eprimKnown_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2erecoveringChk(V, V, V);
V g_heff_2eelab_2etoplevel_2erecoveringChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveringChk_clo;
V g_heff_2eelab_2etoplevel_2esearchedInstance(V, V, V, V);
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF(V, V, V, V);
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo;
HeffT2 g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(V);
V g_heff_2eelab_2etoplevel_2ethawDone(V);
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ethawDone_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2etoplevel_2ewatchEntry(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchEntry_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchEntry_clo;
V g_heff_2eelab_2etoplevel_2ewatchPhase(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo;
V g_heff_2eelab_2etoplevel_2ewithArgs(V, V);
V g_heff_2eelab_2etoplevel_2ewithArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithArgs_clo;
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V, V);
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_heff_2esyntax_2esurfaceprint_2eunIsTy(V);
V g_heff_2esyntax_2esurfaceprint_2eunIsTy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2eunIsTy_clo;
V g_list_2efilter_24s243175984x2038711596(V, V);
V g_list_2efilter_24s243175984x2038711596_entry(V self, V *a);
extern Clo g_list_2efilter_24s243175984x2038711596_clo;
V g_list_2efilter_24s716173495x680820632(V, V);
V g_list_2efilter_24s716173495x680820632_entry(V self, V *a);
extern Clo g_list_2efilter_24s716173495x680820632_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eselfTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eselfTypeF_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eselfTypeF(V v_r_240, V v_k_241, V v_d_242, V v_t_243) {
top: ;
  switch (heff_tag_of(v_t_243)) {
  case TAG_SU: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SDecode: {
    V v_e_245 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SDecode = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 2, (V[]){v_d_242, v_e_245}));
    return heff_tag_at_n(v_ru_24t_243_24SDecode, TAG_SDecode, 1, (V[]){v_t_246});
  }
  case TAG_SFunction: {
    V v_level_247 = heff_field(v_t_243, 0);
    V v_dom_248 = heff_field(v_t_243, 1);
    V v_t3_249 = heff_field(v_t_243, 2);
    V v_implicit_2410 = heff_field(v_t_243, 3);
    V v_dflt_2411 = heff_field(v_t_243, 4);
    V v_ru_24t_243_24SFunction = heff_take_reuse_n(v_t_243, 31ULL, 5);
    switch (heff_tag_of(v_t3_249)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_t3_249, 0);
      V v_b_2413 = heff_field(v_t3_249, 1);
      heff_take_n(v_t3_249, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){heff_intAdd(v_d_242, MK_INT(1LL)), v_b_2413}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2414, heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2415}), v_implicit_2410, v_dflt_2411});
    }
    case TAG_AbsConst: {
      V v_b_2416 = heff_field(v_t3_249, 0);
      heff_take_n(v_t3_249, 1ULL, 1);
      V v_t_2417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){heff_dup(v_d_242), v_dom_248}));
      V v_t_2418 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_b_2416}));
      return heff_tag_at_n(v_ru_24t_243_24SFunction, TAG_SFunction, 5, (V[]){v_level_247, v_t_2417, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2418}), v_implicit_2410, v_dflt_2411});
    }
    default: return heff_nomatch(v_t3_249);
    }
  }
  case TAG_SRecord: {
    V v_level_2419 = heff_field(v_t_243, 0);
    V v_ft_2420 = heff_field(v_t_243, 1);
    V v_ds_2421 = heff_field(v_t_243, 2);
    V v_ru_24t_243_24SRecord = heff_take_reuse_n(v_t_243, 7ULL, 3);
    V v_f_2422 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2423 = heff_take_field(v_ft_2420, 2);
    V v_t_2426 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2423, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam0, 1, 2, (V[]){v_xs_2423, v_f_2422}));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_ft_2420, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SRecord, TAG_SRecord, 3, (V[]){v_level_2419, v_t_2427, v_ds_2421});
  }
  case TAG_SSum: {
    V v_vs_2428 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SSum = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_f_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_d_242}));
    V v_xs_2430 = heff_take_field(v_vs_2428, 2);
    V v_t_2435 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2430, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam1, 1, 2, (V[]){v_xs_2430, v_f_2429}));
    V v_t_2436 = ({ V rv_2 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_vs_2428, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_243_24SSum, TAG_SSum, 1, (V[]){v_t_2436});
  }
  case TAG_SIsTy: {
    V v_a_2437 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SIsTy = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2437}));
    return heff_tag_at_n(v_ru_24t_243_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2438});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  case TAG_SPrimArray: {
    V v_a_2439 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24SPrimArray = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_2440 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 2, (V[]){v_d_242, v_a_2439}));
    return heff_tag_at_n(v_ru_24t_243_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2440});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_r_240, 2);
    heff_drop(v_d_242);
    return v_t_243;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eselfTypeF(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam0(V self, V *args) {
  V v_i_2424 = args[0];
  V v_xs_2423 = heff_env(self)[0];
  V v_f_2422 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_arrayIndex(v_xs_2423, v_i_2424);
  V f_ = v_f_2422;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam2(V self, V *args) {
  V v_i_2433 = args[0];
  V v_xs_2432 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = heff_arrayIndex(v_xs_2432, v_i_2433);
  V f_ = v_f_2429;
  args[0] = v_t_2434;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eselfTypeF_lam1(V self, V *args) {
  V v_i_2431 = args[0];
  V v_xs_2430 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2432 = heff_arrayIndex(v_xs_2430, v_i_2431);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2432, 0), heff_clo_n(g_heff_2eelab_2etoplevel_2eselfTypeF_lam2, 1, 2, (V[]){v_xs_2432, v_f_2429}));
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2enominalTyp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enominalTyp_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enominalTyp(V v_j_240) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam0, 1, 1, (V[]){heff_dup(v_j_240)})});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2enominalTyp(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam3(V self, V *args) {
  V v_u_249 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_249);
  V v_x1_2410 = heff_tr(heff_call(heff_get_n(v_x_247, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2414;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nom: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2411;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2410, 0ULL, 1);
    v_t_2414 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2413 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 1);
    v_t_2414 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  return heff_tag_n(TAG_Become, 1, (V[]){v_t_2414});
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_tag_n(TAG_SIsTy, 1, (V[]){heff_dup(heff_rfield(v_x_247, 0))});
  V f_ = v_k_246;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam3, 1, 1, (V[]){v_x_247})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_244;
  args[0] = v_hd_245;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam2, 1, 1, (V[]){v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2enominalTyp_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_j_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_244;
  switch (heff_tag_of(v_j_240)) {
  case TAG_MkTyp: {
    V v_f_242 = heff_field(v_j_240, 0);
    heff_take_n(v_j_240, 1ULL, 1);
    V v_t_243 = ({ V rv_2 = NTAG(TAG_ForNominative); V rr_ = heff_rec_reuse_nf(v_e_241, 59ULL, 6, shape_scope__globals__elabFor__lams__self__insts, 4047u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    v_c_244 = heff_tr(heff_call(v_f_242, 1, (V[]){v_t_243}));
    break;
  }
  default: heff_nomatch(v_j_240);
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2enominalTyp_lam1, 2, 1, (V[]){v_c_244});
}
Clo g_heff_2eelab_2etoplevel_2echecksOnly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echecksOnly_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echecksOnly(V v_c_240) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_At: {
    V v_c1_241 = heff_field(v_c_240, 0);
    switch (heff_tag_of(v_c1_241)) {
    case TAG_CInf: {
      V v_i_243 = heff_field(v_c1_241, 0);
      V v_t_244 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(heff_dup(v_i_243)));
      V v_t_245 = heff_get_n(v_t_244, 0, 2);
      V v_t_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_x_246 = heff_field(v_t_245, 0);
        heff_take_n(v_t_245, 1ULL, 2);
        v_t_248 = v_x_246;
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      switch (heff_tag_of(v_t_248)) {
      case TAG_IVar: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IInt: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IFloat: {
        heff_take_na(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IString: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IBytes: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IPrim: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IRune: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_IApp: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_IAnn: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_ISpec: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_False);
      }
      case TAG_IUpdate: {
        heff_take_n(v_t_248, 0ULL, 2);
        return NTAG(TAG_False);
      }
      case TAG_IAnnLam: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_True);
      }
      case TAG_IInvalid: {
        heff_take_n(v_t_248, 0ULL, 3);
        return NTAG(TAG_False);
      }
      case TAG_INominal: {
        heff_take_n(v_t_248, 0ULL, 1);
        return NTAG(TAG_False);
      }
      case TAG_ILitEq: {
        heff_take_n(v_t_248, 0ULL, 4);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    case TAG_CType: {
      return NTAG(TAG_False);
    }
    case TAG_CLam: {
      return NTAG(TAG_True);
    }
    case TAG_CImplicitLam: {
      return NTAG(TAG_True);
    }
    case TAG_CAnnLam: {
      return NTAG(TAG_True);
    }
    case TAG_CTag: {
      return NTAG(TAG_True);
    }
    case TAG_CStruct: {
      return NTAG(TAG_True);
    }
    case TAG_CMatch: {
      return NTAG(TAG_True);
    }
    case TAG_CLetIn: {
      return NTAG(TAG_True);
    }
    case TAG_CLocal: {
      return NTAG(TAG_True);
    }
    case TAG_CAbandon: {
      return NTAG(TAG_True);
    }
    case TAG_CNominal: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_c1_241);
    }
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eelab_2etoplevel_2echecksOnly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echecksOnly(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eannotatesData_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eannotatesData(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      return NTAG(TAG_False);
    }
    case TAG_IBytes: {
      return NTAG(TAG_False);
    }
    case TAG_IPrim: {
      return NTAG(TAG_False);
    }
    case TAG_IRune: {
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      V v_c_2412 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_c_2412)) {
      case TAG_At: {
        V v_c1_2414 = heff_field(v_c_2412, 0);
        switch (heff_tag_of(v_c1_2414)) {
        case TAG_CInf: {
          return NTAG(TAG_False);
        }
        case TAG_CType: {
          return NTAG(TAG_False);
        }
        case TAG_CLam: {
          return NTAG(TAG_False);
        }
        case TAG_CImplicitLam: {
          return NTAG(TAG_False);
        }
        case TAG_CAnnLam: {
          return NTAG(TAG_False);
        }
        case TAG_CTag: {
          return NTAG(TAG_True);
        }
        case TAG_CStruct: {
          return NTAG(TAG_True);
        }
        case TAG_CMatch: {
          return NTAG(TAG_False);
        }
        case TAG_CLetIn: {
          return NTAG(TAG_False);
        }
        case TAG_CLocal: {
          return NTAG(TAG_False);
        }
        case TAG_CAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_CNominal: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_c1_2414);
        }
      }
      default: return heff_nomatch(v_c_2412);
      }
    }
    case TAG_ISpec: {
      return NTAG(TAG_False);
    }
    case TAG_IUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      return NTAG(TAG_False);
    }
    case TAG_IInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      return NTAG(TAG_False);
    }
    case TAG_ILitEq: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eannotatesData(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eflatPat_str0, 1, "_");
Clo g_heff_2eelab_2etoplevel_2eflatPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eflatPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eflatPat(V v_gr_240) {
top: ;
  V v_t_241 = heff_take_field(v_gr_240, 0);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 2);
    v_t_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_PatVar: {
    V v_x_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2etoplevel_2eflatPat_str0), 2) && ({ V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_gr_240, 1))); int c_ = heff_intEq_c_lent(v_t_247, MK_INT(0LL), 2); heff_drop(v_t_247); c_; })));
    heff_drop_rec(v_gr_240, 2);
    heff_drop(v_x_245);
    return v_ret_24bool;
  }
  case TAG_PatTag: {
    heff_take_n(v_t_244, 0ULL, 3);
    return ({ V b_0 = heff_get_n(v_gr_240, 1, 2); V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(b_0)); heff_drop(b_0); r_; });
  }
  case TAG_PatOp: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_na(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatBinary: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRune: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eflatPat(a[0]);
}

HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SLocal: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SGlobal: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SCode: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SApp: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLam: {
    V v_x22_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    switch (heff_tag_of(v_x22_248)) {
    case TAG_MkAbs: {
      V v_b_2410 = heff_field(v_x22_248, 1);
      heff_take_n(v_x22_248, 2ULL, 2);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b_2410;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_AbsConst: {
      V v_b_2411 = heff_field(v_x22_248, 0);
      heff_take_n(v_x22_248, 1ULL, 1);
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_b_2411;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return ((HeffT2){{heff_nomatch(v_x22_248)}});
    }
  }
  case TAG_SCons: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SProj: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_STag: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SMatch: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SSpecialize: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SIs: {
    V v_b_2422 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V t_0 = v_n_240;
    V t_1 = v_b_2422;
    v_n_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_SOpaque: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SAbandon: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SRec: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SFix: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SImplicit: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SPrim: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SMetaApp: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitInt: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFloat: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitString: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitBytes: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitRune: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFixed: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  case TAG_SLitFloat32: {
    return ((HeffT2){{v_n_240, v_x2_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eparamsInOrder_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eparamsInOrder(V v_k_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return heff_intEq(v_i_241, v_k_240);
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_SLocal: {
      V v_j_245 = heff_field(v_x31_243, 0);
      V v_t_246 = heff_intSub(heff_intSub(heff_dup(v_k_240), MK_INT(1LL)), heff_dup(v_i_241));
      if (heff_intEq_c_lent(v_j_245, v_t_246, 2)) {
        V t_0 = v_k_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_k_240 = t_0;
        v_i_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      } else {
        heff_drop(v_k_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
    case TAG_SGlobal: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCode: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLam: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SCons: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SProj: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_STag: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMatch: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SSpecialize: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SIs: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SOpaque: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SAbandon: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SRec: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SFix: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SImplicit: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SPrim: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SMetaApp: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitInt: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitString: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitBytes: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitRune: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFixed: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    case TAG_SLitFloat32: {
      heff_drop(v_k_240);
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2eparamsInOrder(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ehasOpPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ehasOpPat(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_x1_247 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_ps_246));
      if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
        heff_drop(v_x1_247);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_x1_247);
        return NTAG(TAG_True);
      }
    }
    case TAG_PatOp: {
      return NTAG(TAG_True);
    }
    case TAG_PatInt: {
      return NTAG(TAG_False);
    }
    case TAG_PatFloat: {
      return NTAG(TAG_False);
    }
    case TAG_PatString: {
      return NTAG(TAG_False);
    }
    case TAG_PatBinary: {
      return NTAG(TAG_False);
    }
    case TAG_PatRune: {
      return NTAG(TAG_False);
    }
    case TAG_PatRecord: {
      V v_fs_2416 = heff_field(v_p1_241, 0);
      V v_x1_2417 = (g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(v_fs_2416));
      if ((heff_dup(v_x1_2417) == NTAG(TAG_True))) {
        heff_drop(v_x1_2417);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_x1_2417);
        return NTAG(TAG_True);
      }
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      V v_q_2421 = heff_field(v_p1_241, 2);
      V t_0 = v_q_2421;
      v_p_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ehasOpPat(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str0, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str1, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str2, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str3, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str4, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str5, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str6, 17, "no such operator ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str7, 9, " in scope");
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eopPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eopPat_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eopPat(V v_g_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_dup(heff_field(v_p_241, 0));
    V v_p2_243 = heff_dup(heff_field(v_p_241, 1));
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam0, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatTag: {
      V v_t_247 = heff_field(v_p1_242, 0);
      V v_tsp_248 = heff_field(v_p1_242, 1);
      V v_args_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_p2_243);
      V v_c_2411 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam1, 1, 1, (V[]){v_g_240}), v_args_249));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam2, 2, 3, (V[]){v_c_2411, v_t_247, v_tsp_248});
    }
    case TAG_PatOp: {
      V v_x_2422 = heff_field(v_p1_242, 0);
      V v_xsp_2423 = heff_field(v_p1_242, 1);
      V v_args_2424 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_p2_243);
      HeffT2 v_t_2425 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(heff_dup(v_g_240), heff_dup(v_x_2422)));
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_it1_2429 = v_field_2427;
          switch (heff_tag_of(v_it1_2429)) {
          case TAG_MkPair: {
            V v_ge_2431 = heff_field(v_it1_2429, 1);
            heff_take_n(v_it1_2429, 2ULL, 2);
            HeffT2 v_t_2432 = (g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(v_ge_2431));
            {
              V v_field_2434 = v_t_2432.f[1];
              int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
              if ((v_tag_2433 == ((int64_t)0ULL))) {
                V v_it1_2436 = v_field_2434;
                switch (heff_tag_of(v_it1_2436)) {
                case TAG_MkPair: {
                  V v_t_2437 = heff_field(v_it1_2436, 0);
                  V v_k_2438 = heff_field(v_it1_2436, 1);
                  heff_take_n(v_it1_2436, 3ULL, 2);
                  V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2424));
                  if (heff_intEq_c(v_k_2438, v_t_2439)) {
                    heff_drop(v_x_2422);
                    V v_c_2442 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam4, 1, 1, (V[]){v_g_240}), v_args_2424));
                    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam5, 2, 3, (V[]){v_c_2442, v_t_2437, v_xsp_2423});
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_args_2424);
                    heff_drop(v_t_2437);
                    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam7, 2, 2, (V[]){v_x_2422, v_xsp_2423});
                  }
                }
                default: return heff_nomatch(v_it1_2436);
                }
              } else {
                heff_drop(v_g_240);
                heff_drop(v_args_2424);
                heff_drop(v_field_2434);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam8, 2, 2, (V[]){v_x_2422, v_xsp_2423});
              }
            }
          }
          default: return heff_nomatch(v_it1_2429);
          }
        } else {
          heff_drop(v_g_240);
          heff_drop(v_args_2424);
          heff_drop(v_field_2427);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam9, 2, 2, (V[]){v_x_2422, v_xsp_2423});
        }
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam10, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam11, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam12, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam13, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam14, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRecord: {
      V v_fs_2491 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_tag(v_p_241, 2);
      V v_c_2499 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam15, 1, 1, (V[]){v_g_240}), v_fs_2491));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam18, 2, 2, (V[]){v_c_2499, v_p2_243});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam20, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatAs: {
      V v_x_24107 = heff_field(v_p1_242, 0);
      V v_xsp_24108 = heff_field(v_p1_242, 1);
      V v_q_24109 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      V v_c_24110 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_q_24109));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam21, 2, 4, (V[]){v_c_24110, v_x_24107, v_xsp_24108, v_p2_243});
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eopPat(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2410));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_tsp_248 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_247)}), heff_dup(v_tsp_248)});
  V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2415, v_x_2414));
  V v_t_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_t_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_248, 0)); V rr_ = heff_rec_reuse_nf(v_t_2419, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_247, v_tsp_248, v_x_2414}), v_t_2420});
  V f_ = v_k_2413;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_tsp_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam3, 1, 3, (V[]){v_t_247, v_tsp_248, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args) {
  V v_m_2441 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2441));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_t_2437 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  V v_k_2444 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2437)}), heff_dup(v_xsp_2423)});
  V v_x1_2447 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2446, v_x_2445));
  V v_t_2450;
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_x1_2447, 1);
    heff_take_n(v_x1_2447, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_x1_2447);
  }
  V v_t_2451 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2423, 0)); V rr_ = heff_rec_reuse_nf(v_t_2450, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2437, v_xsp_2423, v_x_2445}), v_t_2451});
  V f_ = v_k_2444;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  V v_xsp_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam6, 1, 3, (V[]){v_t_2437, v_xsp_2423, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str0), heff_strAppend(heff_dup(v_x_2422), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str1)));
  V v_t_2456 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str2), heff_strAppend(v_x_2422, v_t_2455));
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2456, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2459}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2460;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k2_2462 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str3), heff_strAppend(heff_dup(v_x_2422), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str4)));
  V v_t_2464 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str5), heff_strAppend(v_x_2422, v_t_2463));
  V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2464, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_2461, 2), 1, (V[]){v_t_2467}));
  V f_ = heff_get_n(v_hd_2461, 1, 3);
  args[0] = v_t_2468;
  args[1] = v_k2_2462;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str6), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str7)));
  V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2471, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){v_t_2474}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2475;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2477);
  V f_ = v_k_2478;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k_2481 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2480);
  V f_ = v_k_2481;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2483);
  V f_ = v_k_2484;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2489);
  V f_ = v_k_2490;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args) {
  V v_x_2498 = args[0];
  V v_k_2497 = heff_env(self)[0];
  V v_x_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2497;
  args[0] = heff_tag_n(TAG_MkFieldPat, 2, (V[]){v_x_2493, v_x_2498});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k_2497 = args[1];
  V v_c_2495 = heff_env(self)[0];
  V v_x_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2495;
  args[0] = v_hd_2496;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam17, 1, 2, (V[]){v_k_2497, v_x_2493});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args) {
  V v_m_2492 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2492)) {
  case TAG_MkFieldPat: {
    V v_x_2493 = heff_field(v_m_2492, 0);
    V v_p_2494 = heff_field(v_m_2492, 1);
    heff_take_n(v_m_2492, 3ULL, 2);
    V v_c_2495 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_p_2494));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam16, 2, 2, (V[]){v_c_2495, v_x_2493});
  }
  default: return heff_nomatch(v_m_2492);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args) {
  V v_x_24102 = args[0];
  V v_p2_243 = heff_env(self)[0];
  V v_k_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRecord, 1, (V[]){v_x_24102}), v_p2_243});
  V f_ = v_k_24101;
  args[0] = v_t_24103;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_c_2499 = heff_env(self)[0];
  V v_p2_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2499;
  args[0] = v_hd_24100;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam19, 1, 2, (V[]){v_p2_243, v_k_24101});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24105);
  V f_ = v_k_24106;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam22(V self, V *args) {
  V v_x_24113 = args[0];
  V v_x_24107 = heff_env(self)[0];
  V v_xsp_24108 = heff_env(self)[1];
  V v_p2_243 = heff_env(self)[2];
  V v_k_24112 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatAs, 3, (V[]){v_x_24107, v_xsp_24108, v_x_24113}), v_p2_243});
  V f_ = v_k_24112;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_c_24110 = heff_env(self)[0];
  V v_x_24107 = heff_env(self)[1];
  V v_xsp_24108 = heff_env(self)[2];
  V v_p2_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24110;
  args[0] = v_hd_24111;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam22, 1, 4, (V[]){v_x_24107, v_xsp_24108, v_p2_243, v_k_24112});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_245)));
        v_t_248 = (g_heff_2eelab_2etoplevel_2eflatPat(v_t_247));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkHeadOf_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2echkHeadOf(V v_n_240, V v_j_241) {
top: ;
  HeffT1 v_t_242 = (g_heff_2eelab_2etoplevel_2echkHeadOf_24cpr(v_n_240, v_j_241));
  {
    V v_field_243 = v_t_242.f[0];
    return heff_tag_n(TAG_MkChk, 1, (V[]){v_field_243});
  }
}
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2echkHeadOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V v_i_240) {
top: ;
  V v_t_2432;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_x11_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_241, 0ULL, 3);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    case TAG_INominal: {
      V v_i_2427 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      v_t_2432 = v_i_2427;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2432 = heff_dup(v_i_240);
      break;
    }
    default: heff_nomatch(v_x11_241);
    }
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2464;
  switch (heff_tag_of(v_t_2432)) {
  case TAG_At: {
    V v_x11_2433 = heff_field(v_t_2432, 0);
    heff_take_n(v_t_2432, 1ULL, 2);
    switch (heff_tag_of(v_x11_2433)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInt: {
      V v_k_2436 = heff_field(v_x11_2433, 0);
      V v_ru_24x11_2433_24IInt = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
      v_t_2464 = heff_tag_at_n(v_ru_24x11_2433_24IInt, TAG_Just, 1, (V[]){heff_tag_n(TAG_IntNum, 1, (V[]){v_k_2436})});
      break;
    }
    case TAG_IFloat: {
      double v_x_2437 = heff_tflat_f64(v_x11_2433, 0);
      V v_ru_24x11_2433_24IFloat = heff_take_reuse_na(v_x11_2433, 0ULL, 1);
      v_t_2464 = heff_tag_at_n(v_ru_24x11_2433_24IFloat, TAG_Just, 1, (V[]){heff_tag_nf(TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2437)})});
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2433, 0ULL, 2);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2433, 0ULL, 2);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2433, 0ULL, 4);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2433, 0ULL, 2);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2433, 0ULL, 4);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2433, 0ULL, 3);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2433, 0ULL, 1);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2433, 0ULL, 4);
      v_t_2464 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2433);
    }
    break;
  }
  default: heff_nomatch(v_t_2432);
  }
  switch (heff_tag_of(v_t_2464)) {
  case TAG_Nothing: {
    V v_c_2465 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_240)));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0, 2, 2, (V[]){v_c_2465, v_i_240});
  }
  case TAG_Just: {
    V v_lit_2471 = heff_field(v_t_2464, 0);
    heff_take_n(v_t_2464, 1ULL, 1);
    V v_t_24103;
    switch (heff_tag_of(v_i_240)) {
    case TAG_At: {
      V v_x11_2472 = heff_dup(heff_field(v_i_240, 0));
      switch (heff_tag_of(v_x11_2472)) {
      case TAG_IVar: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_na(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IBytes: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IPrim: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_x11_2472, 0ULL, 2);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_x11_2472, 0ULL, 2);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_x11_2472, 0ULL, 4);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IUpdate: {
        heff_take_n(v_x11_2472, 0ULL, 2);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_x11_2472, 0ULL, 4);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_x11_2472, 0ULL, 3);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_x11_2472, 0ULL, 1);
        v_t_24103 = NTAG(TAG_True);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_x11_2472, 0ULL, 4);
        v_t_24103 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2472);
      }
      break;
    }
    default: heff_nomatch(v_i_240);
    }
    V v_t_24111;
    if ((heff_dup(v_t_24103) == NTAG(TAG_True))) {
      heff_drop(v_t_24103);
      V v_t_24106;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_24105 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_24106 = v_s_24105;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      V v_t_24107 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24106, v_lit_2471));
      v_t_24111 = ({ V a_0 = v_t_24107; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_t_24107); r_; });
    } else {
      heff_drop(v_t_24103);
      V v_t_24110;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_24109 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_24110 = v_s_24109;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      v_t_24111 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24110, v_lit_2471));
    }
    V v_x_24112 = ({ V a_0 = v_t_24111; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_24111); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2, 2, 1, (V[]){v_x_24112});
  }
  default: return heff_nomatch(v_t_2464);
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args) {
  V v_x_2468 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_2467 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = ({ V a_0 = v_i_240; V a_1 = v_x_2468; V r_ = (g_heff_2eelab_2etoplevel_2echkHeadOf(a_0, a_1)); heff_drop(v_x_2468); r_; });
  V v_x_2470 = ({ V a_0 = v_t_2469; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2469); r_; });
  V f_ = v_k_2467;
  args[0] = v_x_2470;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_c_2465 = heff_env(self)[0];
  V v_i_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2465;
  args[0] = v_hd_2466;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1, 1, 2, (V[]){v_i_240, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k_24114 = args[1];
  V v_x_24112 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24113);
  V f_ = v_k_24114;
  args[0] = v_x_24112;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    heff_take_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkAlt: {
      V v_p_243 = heff_field(v_x21_241, 0);
      V v_body_244 = heff_field(v_x21_241, 1);
      heff_take_n(v_x21_241, 3ULL, 2);
      V v_c_245 = (g_heff_2eelab_2etoplevel_2edoPat(v_p_243));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0, 2, 2, (V[]){v_c_245, v_body_244});
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(a[0]);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_xs_2410 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_arrayFromList(v_xs_2410), v_x_2412});
  V f_ = v_k_247;
  args[0] = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_249, v_t_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_body_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x_248, 0);
    V v_xs_2410 = heff_field(v_x_248, 1);
    heff_take_n(v_x_248, 3ULL, 2);
    V v_t_2411 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_244));
    return (g_heff_2eelab_2etoplevel_2erecoveringChk(v_t_2411, v_hd_246, heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam2, 1, 3, (V[]){v_xs_2410, v_k_247, v_x_249})));
  }
  default: return heff_nomatch(v_x_248);
  }
}
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_body_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_lam1, 1, 3, (V[]){v_body_244, v_hd_246, v_k_247});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V v_f_240, V v_eqs_241, V v_sp_242) {
top: ;
  V v_x1_243 = (g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(v_eqs_241));
  if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_x1_243);
    HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_f_240, NTAG(TAG_Nil), v_eqs_241, v_sp_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_err_248 = v_field_246;
        return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0, 2, 1, (V[]){v_err_248});
      } else {
        V v_b_2415 = v_field_246;
        return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2415));
      }
    }
  } else {
    heff_drop(v_x1_243);
    return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242});
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k2_2410 = args[1];
  V v_err_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_248, 1), heff_get_n(v_err_248, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2413}));
  V f_ = heff_get_n(v_hd_249, 1, 3);
  args[0] = v_t_2414;
  args[1] = v_k2_2410;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4(V self, V *args) {
  V v_m_2427 = args[0];
  V v_e_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2418, 1, 6), v_m_2427));
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_f_2423 = heff_env(self)[0];
  V v_fsp_2424 = heff_env(self)[1];
  V v_rhs_2426 = heff_env(self)[2];
  V v_sp_2422 = heff_env(self)[3];
  V v_k_2430 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2423, v_fsp_2424, v_x_2431, v_rhs_2426}), v_sp_2422});
  V f_ = v_k_2430;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_c_2428 = heff_env(self)[0];
  V v_f_2423 = heff_env(self)[1];
  V v_fsp_2424 = heff_env(self)[2];
  V v_rhs_2426 = heff_env(self)[3];
  V v_sp_2422 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2428;
  args[0] = v_hd_2429;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam6, 1, 5, (V[]){v_f_2423, v_fsp_2424, v_rhs_2426, v_sp_2422, v_k_2430});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3(V self, V *args) {
  V v_m_2420 = args[0];
  V v_e_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2420)) {
  case TAG_At: {
    V v_x21_2421 = heff_field(v_m_2420, 0);
    V v_sp_2422 = heff_field(v_m_2420, 1);
    heff_take_n(v_m_2420, 3ULL, 2);
    switch (heff_tag_of(v_x21_2421)) {
    case TAG_MkEquation: {
      V v_f_2423 = heff_field(v_x21_2421, 0);
      V v_fsp_2424 = heff_field(v_x21_2421, 1);
      V v_ps_2425 = heff_field(v_x21_2421, 2);
      V v_rhs_2426 = heff_field(v_x21_2421, 3);
      heff_take_n(v_x21_2421, 15ULL, 4);
      V v_c_2428 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam4, 1, 1, (V[]){v_e_2418}), v_ps_2425));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam5, 2, 5, (V[]){v_c_2428, v_f_2423, v_fsp_2424, v_rhs_2426, v_sp_2422});
    }
    default: return heff_nomatch(v_x21_2421);
    }
  }
  default: return heff_nomatch(v_m_2420);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_err_2441 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(210LL), NTAG(TAG_SError), heff_take_field(v_err_2441, 1), heff_get_n(v_err_2441, 0, 2), NTAG(TAG_Nothing)});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2446}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2447;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_2418 = heff_env(self)[0];
  V v_a_2419 = heff_env(self)[1];
  V v_hd_2434 = heff_env(self)[2];
  V v_k_2435 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2450)) {
  case TAG_MkChk: {
    V v_f_2451 = heff_field(v_x_2450, 0);
    heff_take_n(v_x_2450, 1ULL, 1);
    V f_ = v_f_2451;
    heff_room[0] = v_e_2418;
    heff_room[1] = v_a_2419;
    heff_room[2] = v_hd_2434;
    heff_room[3] = v_k_2435;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2450);
  }
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_f_240 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_hd_2434 = heff_env(self)[2];
  V v_e_2418 = heff_env(self)[3];
  V v_a_2419 = heff_env(self)[4];
  V v_k_2435 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2437 = (g_heff_2eelab_2eclauses_2edesugar_24cpr(v_f_240, NTAG(TAG_Nil), v_x_2436, v_sp_242));
  V v_c_2449;
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_err_2441 = v_field_2439;
      v_c_2449 = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam9, 2, 1, (V[]){v_err_2441});
    } else {
      V v_b_2448 = v_field_2439;
      v_c_2449 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_b_2448));
    }
  }
  V f_ = v_c_2449;
  heff_room[0] = heff_dup(v_hd_2434);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam10, 1, 4, (V[]){v_e_2418, v_a_2419, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  V v_e_2418 = heff_env(self)[3];
  V v_a_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam8, 1, 6, (V[]){v_f_240, v_sp_242, v_hd_2434, v_e_2418, v_a_2419, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2(V self, V *args) {
  V v_e_2418 = args[0];
  V v_a_2419 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2433 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam3, 1, 1, (V[]){heff_dup(v_e_2418)}), v_eqs_241));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam7, 2, 5, (V[]){v_c_2433, v_f_240, v_sp_242, v_e_2418, v_a_2419});
}
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_eqs_241 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_sp_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_lam2, 2, 3, (V[]){v_eqs_241, v_f_240, v_sp_242})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4, 40, "unexpected notation for local definition");
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V v_x2_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_241));
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_240, 0);
    V v_ds_243 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_At: {
      V v_x_244 = heff_field(v_d_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_name_247 = heff_field(v_t_246, 0);
      V v_tyN_2410 = heff_field(v_t_246, 3);
      V v_eqs_2411 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 25ULL, 5);
      V v_c_2412 = ({ V a_0 = v_tyN_2410; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_tyN_2410); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0, 2, 6, (V[]){v_c_2412, heff_dup(v_d_242), v_name_247, v_eqs_2411, heff_dup(v_ds_243), v_body_241});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = ({ V a_0 = v_name_247; V a_1 = v_x_2415; V a_2 = v_x_2420; V a_3 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2elocalDef(a_0, a_1, a_2, a_3)); heff_drop(v_x_2415); heff_drop(v_x_2420); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2414;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ds_243 = heff_env(self)[0];
  V v_body_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_name_247 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2421 = ({ V a_0 = v_ds_243; V a_1 = v_body_241; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_ds_243); r_; });
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3, 1, 4, (V[]){v_name_247, v_x_2415, v_x_2420, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_eqs_2411 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_c_2419 = (g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(heff_dup(v_name_247), v_eqs_2411, v_t_2418));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2, 1, 6, (V[]){v_ds_243, v_body_241, v_hd_2413, v_name_247, v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_name_247 = heff_env(self)[2];
  V v_eqs_2411 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1, 1, 7, (V[]){v_d_242, v_name_247, v_eqs_2411, v_hd_2413, v_ds_243, v_body_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2432 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0), v_t_2433, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2445 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2446 = v_s_2445;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1), v_t_2446, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2457 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2458 = v_s_2457;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2), v_t_2458, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2468 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2469 = v_s_2468;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3), v_t_2469, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_call(heff_take_field(v_hd_2465, 2), 1, (V[]){v_t_2472}));
  V f_ = heff_get_n(v_hd_2465, 1, 3);
  args[0] = v_t_2473;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2478 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2479 = v_s_2478;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4), v_t_2479, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eargBinding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eargBinding_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eargBinding(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_t_245 = heff_field(v_x11_241, 2);
      V v_n_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_n_246 = heff_field(v_t_245, 0);
        V v_sp_247 = heff_field(v_t_245, 1);
        v_n_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_247), heff_dup(v_n_246)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      V v_c_249 = ({ V a_0 = v_n_248; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_248); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam0, 2, 3, (V[]){v_c_249, heff_dup(v_sp_242), heff_dup(v_x_243)});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_t_2416 = heff_field(v_x11_241, 2);
      V v_n_2419;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_At: {
        V v_n_2417 = heff_field(v_t_2416, 0);
        V v_sp_2418 = heff_field(v_t_2416, 1);
        v_n_2419 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2418), heff_dup(v_n_2417)));
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_c_2420 = ({ V a_0 = v_n_2419; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2419); r_; });
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam2, 2, 3, (V[]){v_c_2420, heff_dup(v_sp_242), heff_dup(v_x_2414)});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eargBinding(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_243, v_x_2412, NTAG(TAG_Expl)});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam1, 1, 3, (V[]){v_sp_242, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_2414, v_x_2423, NTAG(TAG_Impl)});
  V f_ = v_k_2422;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam3, 1, 3, (V[]){v_sp_242, v_x_2414, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eexplicitNames_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eexplicitNames_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eexplicitNames(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_ab_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = heff_take_field(v_ab_241, 3);
    switch (heff_tag_of(v_t_243)) {
    case TAG_Expl: {
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_get_n(v_ab_241, 1, 4), heff_hole()});
      V v_u_245 = (g_heff_2eelab_2etoplevel_2eexplicitNames_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_Impl: {
      heff_drop_rec(v_ab_241, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_rec(v_ab_241, 4);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eexplicitNames_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eexplicitNames(a[0]);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eequationsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eequationsD_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2eequationsD(V v_name_240, V v_tyN_241, V v_eqs_242, V v_sp_243) {
top: ;
  V v_x1_244 = (g_heff_2eelab_2etoplevel_2eallL_24s1883875513x844348604(v_eqs_242));
  V v_c_2429;
  if ((heff_dup(v_x1_244) == NTAG(TAG_True))) {
    heff_drop(v_x1_244);
    v_c_2429 = (g_heff_2eelab_2etoplevel_2eequationsBody(heff_dup(v_name_240), NTAG(TAG_Nil), v_eqs_242, v_sp_243));
  } else {
    heff_drop(v_x1_244);
    v_c_2429 = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam0, 2, 3, (V[]){v_eqs_242, heff_dup(v_name_240), v_sp_243});
  }
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam9, 2, 3, (V[]){v_c_2429, heff_dup(v_tyN_241), v_name_240});
}
V g_heff_2eelab_2etoplevel_2eequationsD_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eequationsD(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam3(V self, V *args) {
  V v_m_2416 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_247, 1, 6), v_m_2416));
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam5(V self, V *args) {
  V v_x_2420 = args[0];
  V v_f_2412 = heff_env(self)[0];
  V v_fsp_2413 = heff_env(self)[1];
  V v_rhs_2415 = heff_env(self)[2];
  V v_sp_2411 = heff_env(self)[3];
  V v_k_2419 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2412, v_fsp_2413, v_x_2420, v_rhs_2415}), v_sp_2411});
  V f_ = v_k_2419;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam4(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_f_2412 = heff_env(self)[1];
  V v_fsp_2413 = heff_env(self)[2];
  V v_rhs_2415 = heff_env(self)[3];
  V v_sp_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2417;
  args[0] = v_hd_2418;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam5, 1, 5, (V[]){v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411, v_k_2419});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam2(V self, V *args) {
  V v_m_249 = args[0];
  V v_e_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_249)) {
  case TAG_At: {
    V v_x21_2410 = heff_field(v_m_249, 0);
    V v_sp_2411 = heff_field(v_m_249, 1);
    heff_take_n(v_m_249, 3ULL, 2);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkEquation: {
      V v_f_2412 = heff_field(v_x21_2410, 0);
      V v_fsp_2413 = heff_field(v_x21_2410, 1);
      V v_ps_2414 = heff_field(v_x21_2410, 2);
      V v_rhs_2415 = heff_field(v_x21_2410, 3);
      heff_take_n(v_x21_2410, 15ULL, 4);
      V v_c_2417 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam3, 1, 1, (V[]){v_e_247}), v_ps_2414));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam4, 2, 5, (V[]){v_c_2417, v_f_2412, v_fsp_2413, v_rhs_2415, v_sp_2411});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_m_249);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_e_247 = heff_env(self)[0];
  V v_a_248 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_k_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2427)) {
  case TAG_MkChk: {
    V v_f_2428 = heff_field(v_x_2427, 0);
    heff_take_n(v_x_2427, 1ULL, 1);
    V f_ = v_f_2428;
    heff_room[0] = v_e_247;
    heff_room[1] = v_a_248;
    heff_room[2] = v_hd_2423;
    heff_room[3] = v_k_2424;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_name_240 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_hd_2423 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  V v_k_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2426 = (g_heff_2eelab_2etoplevel_2eequationsBody(v_name_240, NTAG(TAG_Nil), v_x_2425, v_sp_243));
  V f_ = v_c_2426;
  heff_room[0] = heff_dup(v_hd_2423);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam8, 1, 4, (V[]){v_e_247, v_a_248, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam6(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_e_247 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam7, 1, 6, (V[]){v_name_240, v_sp_243, v_hd_2423, v_e_247, v_a_248, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam1(V self, V *args) {
  V v_e_247 = args[0];
  V v_a_248 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2422 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam2, 1, 1, (V[]){heff_dup(v_e_247)}), v_eqs_242));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam6, 2, 5, (V[]){v_c_2422, v_name_240, v_sp_243, v_e_247, v_a_248});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_eqs_242 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam1, 2, 3, (V[]){v_eqs_242, v_name_240, v_sp_243})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam11(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2432 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_2431 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2438 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2437, v_x_2432}); V r_ = (g_heff_2eelab_2etoplevel_2ewithArgs(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_x2_2438)) {
  case TAG_MkPair: {
    V v_ty_2439 = heff_field(v_x2_2438, 0);
    V v_tm_2440 = heff_field(v_x2_2438, 1);
    heff_take_n(v_x2_2438, 3ULL, 2);
    V v_t_2441 = heff_rec_n(4, shape_name__ty__tm__prim, (V[]){v_name_240, v_ty_2439, v_tm_2440, NTAG(TAG_False)});
    V f_ = v_k_2431;
    args[0] = v_t_2441;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x2_2438);
  }
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam10(V self, V *args) {
  V v_x_2432 = args[0];
  V v_tyN_241 = heff_env(self)[0];
  V v_hd_2430 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_n_2435;
  switch (heff_tag_of(v_tyN_241)) {
  case TAG_At: {
    V v_n_2433 = heff_field(v_tyN_241, 0);
    V v_sp_2434 = heff_field(v_tyN_241, 1);
    heff_take_n(v_tyN_241, 3ULL, 2);
    v_n_2435 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(v_sp_2434, v_n_2433));
    break;
  }
  default: heff_nomatch(v_tyN_241);
  }
  V v_c_2436 = ({ V a_0 = v_n_2435; V r_ = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(a_0)); heff_drop(v_n_2435); r_; });
  V f_ = v_c_2436;
  heff_room[0] = v_hd_2430;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam11, 1, 3, (V[]){v_x_2432, v_name_240, v_k_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eequationsD_lam9(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_tyN_241 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eequationsD_lam10, 1, 4, (V[]){v_tyN_241, v_hd_2430, v_name_240, v_k_2431});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_str0, 21, "errors recovered from");
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1, 1, 2, (V[]){v_k_241, v_hd_240})});
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 1, 8);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
Clo g_heff_2eelab_2etoplevel_2econcatMapM_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapM_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2econcatMapM(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapM(v_f_240, v_xs_243));
    HEFF_LAST return g_heff_2eelab_2etoplevel_2eappendM(v_t_244, v_t_245);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapM_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2econcatMapM(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2etoplevel_2enubInt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enubInt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s243175984x2038711596(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2eelab_2etoplevel_2enubInt_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2echeckUnsolved_str0, 21, "`; give it as `{...}`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2echeckUnsolved_str1, 36, "cannot infer the implicit argument `");
Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckUnsolved_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2echeckUnsolved(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_240, 0);
    V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str0));
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str1), v_t_245), heff_dup(heff_rfield(v_u_243, 1)), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_248}));
    return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_249, v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echeckUnsolved(a0, a[1], a[2]); heff_drop(a0); return r;
}

static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
static HEFF_ONCE g_heff_2eelab_2etoplevel_2ebasicPrimNames_st;
static V g_heff_2eelab_2etoplevel_2ebasicPrimNames_init(void) {
  return (g_list_2emap_24s1415906091x1371825187(heff_dup(g_heff_2ecompile_2eprims_2ebasicPrims_get())));
}
V g_heff_2eelab_2etoplevel_2ebasicPrimNames_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2etoplevel_2ebasicPrimNames_st)) return g_heff_2eelab_2etoplevel_2ebasicPrimNames_val;
  return heff_global(&g_heff_2eelab_2etoplevel_2ebasicPrimNames_val, &g_heff_2eelab_2etoplevel_2ebasicPrimNames_st, g_heff_2eelab_2etoplevel_2ebasicPrimNames_init);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str0, 116, "an instance takes only implicit and instance arguments, `{x : A}` and `{{x : A}}`: a search gives it no explicit one");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str1, 192, "make it implicit, solved where the instance is found (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or declare a definition, no instance, and give it its arguments where it is used");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str2, 135, "the instance's implicit argument `_` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2esearchedInstance_str3, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2esearchedInstance_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2esearchedInstance_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2esearchedInstance(V v_sp_240, V v_implicits_241, V v_depth_242, V v_conclusion_243) {
top: ;
  switch (heff_tag_of(v_conclusion_243)) {
  case TAG_SU: {
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_245; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
  }
  case TAG_SDecode: {
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_247; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_247); r_; });
  }
  case TAG_SFunction: {
    V v_conclusion3_2410 = heff_field(v_conclusion_243, 2);
    V v_conclusion4_2411 = heff_field(v_conclusion_243, 3);
    heff_take_n(v_conclusion_243, 12ULL, 5);
    switch (heff_tag_of(v_conclusion4_2411)) {
    case TAG_Expl: {
      heff_drop(v_implicits_241);
      heff_drop(v_depth_242);
      heff_drop(v_conclusion3_2410);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2esearchedInstance_lam0, 2, 1, (V[]){v_sp_240});
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_conclusion3_2410)) {
      case TAG_MkAbs: {
        V v_x_2419 = heff_field(v_conclusion3_2410, 0);
        V v_cod_2420 = heff_field(v_conclusion3_2410, 1);
        V v_ru_24conclusion3_2410_24MkAbs = heff_take_reuse_n(v_conclusion3_2410, 3ULL, 2);
        V v_t_2421 = heff_tag_at_n(v_ru_24conclusion3_2410_24MkAbs, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__level, (V[]){v_x_2419, heff_dup(v_depth_242)}), v_implicits_241});
        V v_t_2422 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2420));
        V t_0 = v_sp_240;
        V t_1 = v_t_2421;
        V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
        V t_3 = v_t_2422;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        goto top;
      }
      case TAG_AbsConst: {
        heff_take_n(v_conclusion3_2410, 0ULL, 1);
        heff_drop(v_implicits_241);
        heff_drop(v_depth_242);
        return heff_clo_n(g_heff_2eelab_2etoplevel_2esearchedInstance_lam1, 2, 1, (V[]){v_sp_240});
      }
      default: return heff_nomatch(v_conclusion3_2410);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_conclusion3_2410)) {
      case TAG_MkAbs: {
        V v_cod_2431 = heff_field(v_conclusion3_2410, 1);
        heff_take_n(v_conclusion3_2410, 2ULL, 2);
        V v_t_2432 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2431));
        V t_0 = v_sp_240;
        V t_1 = v_implicits_241;
        V t_2 = heff_intAdd(v_depth_242, MK_INT(1LL));
        V t_3 = v_t_2432;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        goto top;
      }
      case TAG_AbsConst: {
        V v_cod_2433 = heff_field(v_conclusion3_2410, 0);
        heff_take_n(v_conclusion3_2410, 1ULL, 1);
        V v_t_2434 = (g_heff_2esyntax_2esurfaceprint_2eunIsTy(v_cod_2433));
        V t_0 = v_sp_240;
        V t_1 = v_implicits_241;
        V t_2 = v_depth_242;
        V t_3 = v_t_2434;
        v_sp_240 = t_0;
        v_implicits_241 = t_1;
        v_depth_242 = t_2;
        v_conclusion_243 = t_3;
        goto top;
      }
      default: return heff_nomatch(v_conclusion3_2410);
      }
    }
    default: return heff_nomatch(v_conclusion4_2411);
    }
  }
  case TAG_SRecord: {
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2438; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2438); r_; });
  }
  case TAG_SSum: {
    V v_t_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2440; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2440); r_; });
  }
  case TAG_SIsTy: {
    V v_t_2442 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2442; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2442); r_; });
  }
  case TAG_SPrimInt: {
    V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2443; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); r_; });
  }
  case TAG_SPrimFloat: {
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2444; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2444); r_; });
  }
  case TAG_SPrimString: {
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2445; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2445); r_; });
  }
  case TAG_SPrimRune: {
    V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2446; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2446); r_; });
  }
  case TAG_SPrimArray: {
    V v_t_2448 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2448; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
  }
  case TAG_SFixed: {
    V v_t_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_implicits_241));
    return ({ V a_0 = v_sp_240; V a_1 = v_depth_242; V a_2 = v_conclusion_243; V a_3 = v_t_2450; V r_ = (g_heff_2eelab_2etoplevel_2eeveryImplicitIn(a_0, a_1, a_2, a_3)); heff_drop(v_t_2450); r_; });
  }
  default: return heff_nomatch(v_conclusion_243);
  }
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2esearchedInstance(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k2_2414 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(348LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str0), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str1)})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2413, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2413, 1, 3);
  args[0] = v_t_2418;
  args[1] = v_k2_2414;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2esearchedInstance_lam1(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str2), v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2esearchedInstance_str3)})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2428}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2429;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ewatchPhase_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewatchPhase_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2ewatchPhase(V v_g_240, V v_sp_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_t_245 = heff_field(v_x3_242, 0);
    V v_ty_246 = heff_field(v_x3_242, 1);
    return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_g_240), MK_INT(0LL), heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam0, 1, 6, (V[]){v_p_243, v_g_240, v_sp_241, heff_dup(v_t_245), heff_dup(v_ty_246), v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2etoplevel_2ewatchPhase(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam6(V self, V *args) {
  V v_c_2415 = args[0];
  return heff_get_n(v_c_2415, 3, 8);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam7(V self, V *args) {
  V v_x_2419 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2420 = ({ V a_0 = v_g_240; V a_1 = v_x_2419; V a_2 = v_t_245; V a_3 = v_ty_246; V r_ = (g_heff_2eelab_2etoplevel_2ewatchEntry(a_0, a_1, a_2, a_3)); heff_drop(v_x_2419); r_; });
  V f_ = v_k_2413;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_t_245 = heff_env(self)[2];
  V v_ty_246 = heff_env(self)[3];
  V v_k_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2ewatchPhase_lam6_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){v_t_2417}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  heff_room[0] = v_t_2418;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam7, 1, 4, (V[]){v_g_240, v_t_245, v_ty_246, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam4(V self, V *args) {
  V v_unsolved_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_unsolved_2411; V a_1 = heff_dup(v_hd_2412); V a_2 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam5, 1, 5, (V[]){v_hd_2412, v_g_240, v_t_245, v_ty_246, v_k_2413}); V r_ = (g_heff_2eelab_2etoplevel_2echeckUnsolved(a_0, a_1, a_2)); heff_drop(v_unsolved_2411); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  return (g_co_2ebind_24s591410632x427349444(heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam4, 3, 3, (V[]){v_g_240, v_t_245, v_ty_246}), v_p_243, v_p_244));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_x_247 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  return ({ V a_0 = heff_dup(v_g_240); V a_1 = v_sp_241; V a_2 = v_x_247; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam3, 1, 5, (V[]){v_g_240, v_t_245, v_ty_246, v_p_243, v_p_244}); V r_ = (g_heff_2eelab_2etoplevel_2echeckStuck(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_x_247); r_; });
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_x_247 = heff_env(self)[3];
  V v_t_245 = heff_env(self)[4];
  V v_ty_246 = heff_env(self)[5];
  V v_p_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_248);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam2, 1, 7, (V[]){v_g_240, v_sp_241, v_x_247, v_p_243, v_t_245, v_ty_246, v_p_244})));
}
V g_heff_2eelab_2etoplevel_2ewatchPhase_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_t_245 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2etoplevel_2erecoveredCheck(heff_dup(v_p_243), heff_clo_n(g_heff_2eelab_2etoplevel_2ewatchPhase_lam1, 1, 7, (V[]){v_p_243, v_g_240, v_sp_241, v_x_247, v_t_245, v_ty_246, v_p_244})));
}
Clo g_heff_2eelab_2etoplevel_2eappendT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eappendT(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2etoplevel_2eappendT_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT(a[0], a[1]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24dps_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_241, 0)), MK_INT(-1LL))) {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_244 = NTAG(TAG_Nil);
    } else {
      v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_xs_242));
    return (g_heff_2eelab_2etoplevel_2eappendT(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0, 21, "errors recovered from");
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V v_k_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_245, 1, 8); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  if (heff_intEq_c(v_t_246, MK_INT(0LL))) {
    return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_241});
  } else {
    heff_drop(v_k_240);
    V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_248}), v_st_241});
  }
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_str0, 0, "");
Clo g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(V v_n_240, V v_g_241) {
top: ;
  V v_t_2424;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_x11_242 = heff_dup(heff_field(v_n_240, 0));
    switch (heff_tag_of(v_x11_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 5);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_f_244});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_249 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 5);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_249});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2414 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 4);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2414});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2418 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 3);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2418});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2421 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      v_t_2424 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2421});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_242, 0ULL, 1);
      v_t_2424 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_242);
    }
    break;
  }
  default: heff_nomatch(v_n_240);
  }
  switch (heff_tag_of(v_t_2424)) {
  case TAG_Nothing: {
    heff_drop(v_n_240);
    return v_g_241;
  }
  case TAG_Just: {
    V v_x_2425 = heff_field(v_t_2424, 0);
    heff_take_n(v_t_2424, 1ULL, 1);
    switch (heff_tag_of(v_n_240)) {
    case TAG_At: {
      V v_x11_2426 = heff_field(v_n_240, 0);
      V v_ru_24n_240_24At = heff_take_reuse_n(v_n_240, 1ULL, 2);
      switch (heff_tag_of(v_x11_2426)) {
      case TAG_DeclEquations: {
        V v_x113_2430 = heff_field(v_x11_2426, 2);
        heff_take_n(v_x11_2426, 4ULL, 5);
        switch (heff_tag_of(v_x113_2430)) {
        case TAG_AsDefinition: {
          heff_drop(v_x_2425);
          heff_drop_cell(v_ru_24n_240_24At, 2);
          return v_g_241;
        }
        case TAG_AsInstance: {
          V v_t_2435;
          if (heff_strEq_c_lent(v_x_2425, v_x_2425, 0)) {
            v_t_2435 = ((V)&g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_str0);
          } else {
            int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_x_2425, 0)) - heff_unbox_word(heff_strLength_lent(v_x_2425, 0)));
            v_t_2435 = heff_strSlice_lent(v_x_2425, MK_INT(0LL), heff_box_word((v_t_2434 - ((int64_t)1ULL))), 6);
          }
          V v_t_2436 = (g_list_2efilter_24s716173495x680820632(v_x_2425, heff_take_field(v_g_241, 8)));
          V v_t_2437 = heff_tag_at_n(v_ru_24n_240_24At, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_key__module, (V[]){v_x_2425, v_t_2435}), v_t_2436});
          return ({ V rv_8 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_g_241, 255ULL, 9, shape_order__entries__aliases__broken__ambiguous__places__hidden__unexposed__instances, 65535u, 0u); heff_rfield(rr_, 8) = rv_8; rr_; });
        }
        default: return heff_nomatch(v_x113_2430);
        }
      }
      case TAG_DeclDefine: {
        heff_take_n(v_x11_2426, 0ULL, 5);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclTheory: {
        heff_take_n(v_x11_2426, 0ULL, 4);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclPrimitive: {
        heff_take_n(v_x11_2426, 0ULL, 3);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_2426, 0ULL, 2);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2426, 0ULL, 1);
        heff_drop(v_x_2425);
        heff_drop_cell(v_ru_24n_240_24At, 2);
        return v_g_241;
      }
      default: return heff_nomatch(v_x11_2426);
      }
    }
    default: return heff_nomatch(v_n_240);
    }
  }
  default: return heff_nomatch(v_t_2424);
  }
}
V g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ewithBrokenInstance_24s473662565x979699720(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(V v_g_240, V v_n_241, V v_d_242, V v_a_243, V v_st_244) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_c_245 = heff_dup(heff_field(v_st_244, 0));
    v_c_248 = v_c_245;
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  V v_t_2411;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2410 = heff_field(v_n_241, 1);
    v_t_2411 = heff_dup(v_s_2410);
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2412 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2413;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2412);
    v_t_2413 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2414 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_t_2421 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HGlobal, 1, (V[]){v_t_2415}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), NTAG(TAG_Nothing)));
  V v_x1_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_t_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_t_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  V v_t_2427 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){NTAG(TAG_SOpaque), heff_dup(heff_rfield(v_a_243, 0)), v_t_2421, v_t_2426});
  V v_t_2428 = (g_heff_2eelab_2eglobals_2eaddEntry(v_t_2413, v_t_2427, heff_dup(v_g_240)));
  V v_t_2429 = heff_dup(heff_rfield(v_d_242, 3));
  V v_t_2430;
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    v_t_2430 = heff_dup(heff_rfield(v_d_242, 0));
  } else {
    heff_drop(v_t_2429);
    v_t_2430 = heff_dup(heff_rfield(v_d_242, 0));
  }
  V v_x1_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_a_243, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_t_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    v_t_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_t_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  V v_t_2436 = (g_heff_2eelab_2etoplevel_2ebodyPhase(v_t_2411, heff_dup(v_d_242), v_t_2428, v_t_2430, v_t_2435));
  V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2eelab_2eenvironment_2etryE_clo), 1, (V[]){v_t_2436}));
  V v_t_2444;
  switch (heff_tag_of(v_st_244)) {
  case TAG_MkSt: {
    V v_d_2439 = heff_field(v_st_244, 1);
    V v_w_2440 = heff_field(v_st_244, 2);
    V v_ru_24st_244_24MkSt = heff_take_reuse_n(v_st_244, 6ULL, 3);
    V v_t_2441 = heff_dup(heff_rfield(v_d_242, 3));
    V v_t_2442;
    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
      heff_drop(v_t_2441);
      v_t_2442 = heff_dup(heff_rfield(v_d_242, 0));
    } else {
      heff_drop(v_t_2441);
      v_t_2442 = heff_dup(heff_rfield(v_d_242, 0));
    }
    V v_t_2443 = ({ V rv_7 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2442}); V rr_ = heff_rec_reuse_nf(v_c_248, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
    v_t_2444 = heff_tag_at_n(v_ru_24st_244_24MkSt, TAG_MkSt, 3, (V[]){v_t_2443, v_d_2439, v_w_2440});
    break;
  }
  default: heff_nomatch(v_st_244);
  }
  return (g_co_2ebind_24s2023162438x1917167210(v_t_2437, heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1, 3, 4, (V[]){heff_dup(v_n_241), v_d_242, v_a_243, v_g_240}), v_t_2444));
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_x1_2417 = heff_tr(heff_call(heff_get_n(v_a_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nom: {
    V v_x_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2418;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2417, 0ULL, 1);
    return heff_abandon();
  }
  case TAG_Become: {
    V v_x_2420 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    return v_x_2420;
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2(V self, V *args) {
  V v_c_2448 = args[0];
  return ({ V rv_7 = NTAG(TAG_Nothing); V rr_ = heff_rec_reuse_nf(v_c_2448, 127ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 16383u, 0u); heff_rfield(rr_, 7) = rv_7; rr_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6(V self, V *args) {
  V v_c_2462 = args[0];
  return heff_get_n(v_c_2462, 3, 8);
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7(V self, V *args) {
  V v_x_2466 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_a_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_body_2445 = heff_env(self)[4];
  V v_hd_2446 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2489;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_x11_2467 = heff_field(v_n_241, 0);
    heff_take_n(v_n_241, 1ULL, 2);
    switch (heff_tag_of(v_x11_2467)) {
    case TAG_DeclEquations: {
      V v_x113_2471 = heff_field(v_x11_2467, 2);
      heff_take_n(v_x11_2467, 4ULL, 5);
      switch (heff_tag_of(v_x113_2471)) {
      case TAG_AsDefinition: {
        v_t_2489 = NTAG(TAG_False);
        break;
      }
      case TAG_AsInstance: {
        v_t_2489 = NTAG(TAG_True);
        break;
      }
      default: heff_nomatch(v_x113_2471);
      }
      break;
    }
    case TAG_DeclDefine: {
      heff_take_n(v_x11_2467, 0ULL, 5);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTheory: {
      heff_take_n(v_x11_2467, 0ULL, 4);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_x11_2467, 0ULL, 3);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclTest: {
      heff_take_n(v_x11_2467, 0ULL, 2);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2467, 0ULL, 1);
      v_t_2489 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x11_2467);
    }
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_t_2490 = (g_heff_2eelab_2eunify_2ezonker(v_x_2466));
  V v_t_2491 = heff_tr(heff_call(heff_get_n(v_t_2490, 1, 2), 1, (V[]){heff_get_n(v_a_243, 0, 2)}));
  return ({ V a_0 = v_g_240; V a_1 = v_d_242; V a_2 = v_t_2489; V a_3 = v_t_2491; V a_4 = v_x_2466; V a_5 = v_body_2445; V a_6 = v_hd_2446; V a_7 = v_k_2447; V r_ = (g_heff_2eelab_2etoplevel_2eelabOut_24s153043562x1340032218(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_x_2466); heff_drop_rec(v_hd_2446, 3); r_; });
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_2446 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_d_242 = heff_env(self)[4];
  V v_body_2445 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2461);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam6_clo)})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){v_t_2464}));
  V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
  heff_room[0] = v_t_2465;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam7, 1, 7, (V[]){v_n_241, v_a_243, v_g_240, v_d_242, v_body_2445, v_hd_2446, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4(V self, V *args) {
  V v_x_2456 = args[0];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_hd_2446 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2445 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2456);
  V v_t_2459;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2458 = heff_dup(heff_field(v_n_241, 1));
    v_t_2459 = v_s_2458;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_c_2460 = (g_heff_2eelab_2etoplevel_2eprimKnown(v_t_2459, heff_dup(v_d_242)));
  V f_ = v_c_2460;
  heff_room[0] = heff_dup(v_hd_2446);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam5, 1, 7, (V[]){v_hd_2446, v_n_241, v_a_243, v_g_240, v_d_242, v_body_2445, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2446 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_a_243 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_body_2445 = heff_env(self)[5];
  V v_k_2447 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2453 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2452, NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})}));
  V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
  heff_room[0] = v_t_2455;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam4, 1, 7, (V[]){v_n_241, v_d_242, v_hd_2446, v_a_243, v_g_240, v_body_2445, v_k_2447});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam1(V self, V *args) {
  V v_body_2445 = args[0];
  V v_hd_2446 = args[1];
  V v_k_2447 = args[2];
  V v_n_241 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_a_243 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam2_clo)})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2446, 2)), 1, (V[]){v_t_2450}));
  V f_ = heff_dup(heff_rfield(v_hd_2446, 1));
  args[0] = v_t_2451;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabBody_24s914274407x1769873193_lam3, 1, 7, (V[]){v_hd_2446, v_n_241, v_d_242, v_a_243, v_g_240, v_body_2445, v_k_2447});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2ethawDone_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ethawDone_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ethawDone(V v_acc_240) {
top: ;
  V v_keys_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 2)));
  V v_spans_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 6)));
  return ({ V rv_2 = v_keys_241; V rv_6 = v_spans_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 443ULL, 9, shape_globals__diags__keys__broken__watches__tests__spans__infos__trace, 249807u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 6) = rv_6; rr_; });
}
V g_heff_2eelab_2etoplevel_2ethawDone_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ethawDone(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(V v_ys_240, V v_f_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return v_ys_240;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_242, 0);
    V v_xs_244 = heff_field(v_x2_242, 1);
    V v_ru_24x2_242_24Cons = heff_take_reuse_n(v_x2_242, 3ULL, 2);
    V v_x_245 = heff_tr(heff_call(heff_dup(v_f_241), 1, (V[]){v_x_243}));
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_242_24Cons, TAG_Cons, 2, (V[]){v_x_245, heff_hole()});
    V v_u_247 = (g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_24dps(v_ys_240, v_f_241, v_xs_244, heff_dup(v_cell_246)));
    heff_drop(v_u_247);
    return v_cell_246;
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eappendT_24f547591793x43397221(a[0], a[1], a[2]);
}