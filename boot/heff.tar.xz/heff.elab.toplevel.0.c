// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009 47022
#define TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422 47314
#define TAG_Expl 20488
#define TAG_ExplicitParam 63083
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_Impl 63555
#define TAG_ImplicitParam 51130
#define TAG_IntNum 31256
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_end 310101
#define LBL_head 9693863
#define LBL_implicit 319715269
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_recovered 474271923
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_typ 324869
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_span__name__typ__implicit[] = {LBL_span, LBL_name, LBL_typ, LBL_implicit};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(V);
V g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(V);
V g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2eargBinding(V);
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eargBinding_clo;
V g_heff_2eelab_2etoplevel_2echeckUnsolved(V, V, V);
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkHeadOf(V, V);
V g_heff_2eelab_2etoplevel_2echkHeadOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkHeadOf_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2eflatPat(V);
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eflatPat_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(V, V, V);
V g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2esameDiag(V, V);
V g_heff_2eelab_2etoplevel_2esameDiag_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2esameDiag_clo;
HeffT2 g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(V);
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(V, V);
V g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s193123870x387721583(V, V);
V g_list_2ekeepIf_24s193123870x387721583_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s193123870x387721583_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eannotatesData_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eannotatesData(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      return NTAG(TAG_False);
    }
    case TAG_IBytes: {
      return NTAG(TAG_False);
    }
    case TAG_IPrim: {
      return NTAG(TAG_False);
    }
    case TAG_IRune: {
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      V v_c_2412 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_c_2412)) {
      case TAG_At: {
        V v_c1_2414 = heff_field(v_c_2412, 0);
        switch (heff_tag_of(v_c1_2414)) {
        case TAG_CInf: {
          return NTAG(TAG_False);
        }
        case TAG_CType: {
          return NTAG(TAG_False);
        }
        case TAG_CLam: {
          return NTAG(TAG_False);
        }
        case TAG_CImplicitLam: {
          return NTAG(TAG_False);
        }
        case TAG_CAnnLam: {
          return NTAG(TAG_False);
        }
        case TAG_CTag: {
          return NTAG(TAG_True);
        }
        case TAG_CStruct: {
          return NTAG(TAG_True);
        }
        case TAG_CMatch: {
          return NTAG(TAG_False);
        }
        case TAG_CLetIn: {
          return NTAG(TAG_False);
        }
        case TAG_CLocal: {
          return NTAG(TAG_False);
        }
        case TAG_CAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_CNominal: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_c1_2414);
        }
      }
      default: return heff_nomatch(v_c_2412);
      }
    }
    case TAG_ISpec: {
      return NTAG(TAG_False);
    }
    case TAG_IUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      return NTAG(TAG_False);
    }
    case TAG_IInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      return NTAG(TAG_False);
    }
    case TAG_ILitEq: {
      return NTAG(TAG_False);
    }
    case TAG_ILazy: {
      return NTAG(TAG_False);
    }
    case TAG_ITuple: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eannotatesData(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eflatPat_str0, 1, "_");
Clo g_heff_2eelab_2etoplevel_2eflatPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eflatPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eflatPat(V v_gr_240) {
top: ;
  V v_t_241 = heff_take_field(v_gr_240, 0);
  V v_t_244;
  switch (heff_tag_of(v_t_241)) {
  case TAG_At: {
    V v_x_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 2);
    v_t_244 = v_x_242;
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_PatVar: {
    V v_x_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_x_245, ((V)&g_heff_2eelab_2etoplevel_2eflatPat_str0), 2) && ({ V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), heff_rfield(v_gr_240, 1))); int c_ = heff_intEq_c_lent(v_t_247, MK_INT(0LL), 2); heff_drop(v_t_247); c_; })));
    heff_drop_rec(v_gr_240, 2);
    heff_drop(v_x_245);
    return v_ret_24bool;
  }
  case TAG_PatTag: {
    heff_take_n(v_t_244, 0ULL, 3);
    return ({ V b_0 = heff_get_n(v_gr_240, 1, 2); V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(b_0)); heff_drop(b_0); r_; });
  }
  case TAG_PatOp: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_na(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatBinary: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRune: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_gr_240, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eflatPat(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ehasOpPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ehasOpPat(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_x1_247 = (g_heff_2eelab_2etoplevel_2eallL_24s2097707662x1563184201(v_ps_246));
      if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
        heff_drop(v_x1_247);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_x1_247);
        return NTAG(TAG_True);
      }
    }
    case TAG_PatOp: {
      return NTAG(TAG_True);
    }
    case TAG_PatInt: {
      return NTAG(TAG_False);
    }
    case TAG_PatFloat: {
      return NTAG(TAG_False);
    }
    case TAG_PatString: {
      return NTAG(TAG_False);
    }
    case TAG_PatBinary: {
      return NTAG(TAG_False);
    }
    case TAG_PatRune: {
      return NTAG(TAG_False);
    }
    case TAG_PatRecord: {
      V v_fs_2416 = heff_field(v_p1_241, 0);
      V v_x1_2417 = (g_heff_2eelab_2etoplevel_2eallL_24s401148814x1352604411(v_fs_2416));
      if ((heff_dup(v_x1_2417) == NTAG(TAG_True))) {
        heff_drop(v_x1_2417);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_x1_2417);
        return NTAG(TAG_True);
      }
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      V v_q_2421 = heff_field(v_p1_241, 2);
      V t_0 = v_q_2421;
      v_p_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ehasOpPat(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str0, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str1, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str2, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str3, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str4, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str5, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str6, 17, "no such operator ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str7, 9, " in scope");
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eopPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eopPat_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eopPat(V v_g_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_dup(heff_field(v_p_241, 0));
    V v_p2_243 = heff_dup(heff_field(v_p_241, 1));
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam0, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatTag: {
      V v_t_247 = heff_field(v_p1_242, 0);
      V v_tsp_248 = heff_field(v_p1_242, 1);
      V v_args_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_p2_243);
      V v_c_2411 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam1, 1, 1, (V[]){v_g_240}), v_args_249));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam2, 2, 3, (V[]){v_c_2411, v_t_247, v_tsp_248});
    }
    case TAG_PatOp: {
      V v_x_2422 = heff_field(v_p1_242, 0);
      V v_xsp_2423 = heff_field(v_p1_242, 1);
      V v_args_2424 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      heff_drop(v_p2_243);
      HeffT2 v_t_2425 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(heff_dup(v_g_240), heff_dup(v_x_2422)));
      {
        V v_field_2427 = v_t_2425.f[1];
        int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
        if ((v_tag_2426 == ((int64_t)0ULL))) {
          V v_it1_2429 = v_field_2427;
          switch (heff_tag_of(v_it1_2429)) {
          case TAG_MkPair: {
            V v_ge_2431 = heff_field(v_it1_2429, 1);
            heff_take_n(v_it1_2429, 2ULL, 2);
            HeffT2 v_t_2432 = (g_heff_2eelab_2etoplevel_2etagSynonym_24cpr(v_ge_2431));
            {
              V v_field_2434 = v_t_2432.f[1];
              int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
              if ((v_tag_2433 == ((int64_t)0ULL))) {
                V v_it1_2436 = v_field_2434;
                switch (heff_tag_of(v_it1_2436)) {
                case TAG_MkPair: {
                  V v_t_2437 = heff_field(v_it1_2436, 0);
                  V v_k_2438 = heff_field(v_it1_2436, 1);
                  heff_take_n(v_it1_2436, 3ULL, 2);
                  V v_t_2439 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2424));
                  if (heff_intEq_c(v_k_2438, v_t_2439)) {
                    heff_drop(v_x_2422);
                    V v_c_2442 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam4, 1, 1, (V[]){v_g_240}), v_args_2424));
                    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam5, 2, 3, (V[]){v_c_2442, v_t_2437, v_xsp_2423});
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_args_2424);
                    heff_drop(v_t_2437);
                    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam7, 2, 2, (V[]){v_x_2422, v_xsp_2423});
                  }
                }
                default: return heff_nomatch(v_it1_2436);
                }
              } else {
                heff_drop(v_g_240);
                heff_drop(v_args_2424);
                heff_drop(v_field_2434);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam8, 2, 2, (V[]){v_x_2422, v_xsp_2423});
              }
            }
          }
          default: return heff_nomatch(v_it1_2429);
          }
        } else {
          heff_drop(v_g_240);
          heff_drop(v_args_2424);
          heff_drop(v_field_2427);
          return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam9, 2, 2, (V[]){v_x_2422, v_xsp_2423});
        }
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam10, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam11, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam12, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam13, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam14, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRecord: {
      V v_fs_2491 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      heff_drop_tag(v_p_241, 2);
      V v_c_2499 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam15, 1, 1, (V[]){v_g_240}), v_fs_2491));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam18, 2, 2, (V[]){v_c_2499, v_p2_243});
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop(v_g_240);
      heff_drop(v_p2_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam20, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatAs: {
      V v_x_24107 = heff_field(v_p1_242, 0);
      V v_xsp_24108 = heff_field(v_p1_242, 1);
      V v_q_24109 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      heff_drop_tag(v_p_241, 2);
      V v_c_24110 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_q_24109));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam21, 2, 4, (V[]){v_c_24110, v_x_24107, v_xsp_24108, v_p2_243});
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eopPat(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args) {
  V v_m_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2410));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_tsp_248 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_247)}), heff_dup(v_tsp_248)});
  V v_x1_2416 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2415, v_x_2414));
  V v_t_2419;
  switch (heff_tag_of(v_x1_2416)) {
  case TAG_At: {
    V v_s_2418 = heff_field(v_x1_2416, 1);
    heff_take_n(v_x1_2416, 2ULL, 2);
    v_t_2419 = v_s_2418;
    break;
  }
  default: heff_nomatch(v_x1_2416);
  }
  V v_t_2420 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_248, 0)); V rr_ = heff_rec_reuse_nf(v_t_2419, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_247, v_tsp_248, v_x_2414}), v_t_2420});
  V f_ = v_k_2413;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_tsp_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = v_hd_2412;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam3, 1, 3, (V[]){v_t_247, v_tsp_248, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args) {
  V v_m_2441 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2441));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args) {
  V v_x_2445 = args[0];
  V v_t_2437 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  V v_k_2444 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_2437)}), heff_dup(v_xsp_2423)});
  V v_x1_2447 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2446, v_x_2445));
  V v_t_2450;
  switch (heff_tag_of(v_x1_2447)) {
  case TAG_At: {
    V v_s_2449 = heff_field(v_x1_2447, 1);
    heff_take_n(v_x1_2447, 2ULL, 2);
    v_t_2450 = v_s_2449;
    break;
  }
  default: heff_nomatch(v_x1_2447);
  }
  V v_t_2451 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2423, 0)); V rr_ = heff_rec_reuse_nf(v_t_2450, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_2437, v_xsp_2423, v_x_2445}), v_t_2451});
  V f_ = v_k_2444;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k_2444 = args[1];
  V v_c_2442 = heff_env(self)[0];
  V v_t_2437 = heff_env(self)[1];
  V v_xsp_2423 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2442;
  args[0] = v_hd_2443;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam6, 1, 3, (V[]){v_t_2437, v_xsp_2423, v_k_2444});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k2_2454 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str0), heff_strAppend(heff_dup(v_x_2422), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str1)));
  V v_t_2456 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str2), heff_strAppend(v_x_2422, v_t_2455));
  V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2456, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tr(heff_call(heff_take_field(v_hd_2453, 2), 1, (V[]){v_t_2459}));
  V f_ = heff_get_n(v_hd_2453, 1, 3);
  args[0] = v_t_2460;
  args[1] = v_k2_2454;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k2_2462 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2463 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str3), heff_strAppend(heff_dup(v_x_2422), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str4)));
  V v_t_2464 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str5), heff_strAppend(v_x_2422, v_t_2463));
  V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2464, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2466 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_2461, 2), 1, (V[]){v_t_2467}));
  V f_ = heff_get_n(v_hd_2461, 1, 3);
  args[0] = v_t_2468;
  args[1] = v_k2_2462;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_x_2422 = heff_env(self)[0];
  V v_xsp_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2471 = heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str6), heff_strAppend(v_x_2422, ((V)&g_heff_2eelab_2etoplevel_2eopPat_str7)));
  V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_2471, v_xsp_2423, NTAG(TAG_Nothing)});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){v_t_2474}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2475;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args) {
  V v_hd_2477 = args[0];
  V v_k_2478 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2477);
  V f_ = v_k_2478;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args) {
  V v_hd_2480 = args[0];
  V v_k_2481 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2480);
  V f_ = v_k_2481;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2483);
  V f_ = v_k_2484;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args) {
  V v_hd_2486 = args[0];
  V v_k_2487 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2486);
  V f_ = v_k_2487;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args) {
  V v_hd_2489 = args[0];
  V v_k_2490 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2489);
  V f_ = v_k_2490;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args) {
  V v_x_2498 = args[0];
  V v_k_2497 = heff_env(self)[0];
  V v_x_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2497;
  args[0] = heff_tag_n(TAG_MkFieldPat, 2, (V[]){v_x_2493, v_x_2498});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args) {
  V v_hd_2496 = args[0];
  V v_k_2497 = args[1];
  V v_c_2495 = heff_env(self)[0];
  V v_x_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2495;
  args[0] = v_hd_2496;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam17, 1, 2, (V[]){v_k_2497, v_x_2493});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args) {
  V v_m_2492 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2492)) {
  case TAG_MkFieldPat: {
    V v_x_2493 = heff_field(v_m_2492, 0);
    V v_p_2494 = heff_field(v_m_2492, 1);
    heff_take_n(v_m_2492, 3ULL, 2);
    V v_c_2495 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_p_2494));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam16, 2, 2, (V[]){v_c_2495, v_x_2493});
  }
  default: return heff_nomatch(v_m_2492);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args) {
  V v_x_24102 = args[0];
  V v_p2_243 = heff_env(self)[0];
  V v_k_24101 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRecord, 1, (V[]){v_x_24102}), v_p2_243});
  V f_ = v_k_24101;
  args[0] = v_t_24103;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args) {
  V v_hd_24100 = args[0];
  V v_k_24101 = args[1];
  V v_c_2499 = heff_env(self)[0];
  V v_p2_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2499;
  args[0] = v_hd_24100;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam19, 1, 2, (V[]){v_p2_243, v_k_24101});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args) {
  V v_hd_24105 = args[0];
  V v_k_24106 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24105);
  V f_ = v_k_24106;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam22(V self, V *args) {
  V v_x_24113 = args[0];
  V v_x_24107 = heff_env(self)[0];
  V v_xsp_24108 = heff_env(self)[1];
  V v_p2_243 = heff_env(self)[2];
  V v_k_24112 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatAs, 3, (V[]){v_x_24107, v_xsp_24108, v_x_24113}), v_p2_243});
  V f_ = v_k_24112;
  args[0] = v_t_24114;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args) {
  V v_hd_24111 = args[0];
  V v_k_24112 = args[1];
  V v_c_24110 = heff_env(self)[0];
  V v_x_24107 = heff_env(self)[1];
  V v_xsp_24108 = heff_env(self)[2];
  V v_p2_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24110;
  args[0] = v_hd_24111;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam22, 1, 4, (V[]){v_x_24107, v_xsp_24108, v_p2_243, v_k_24112});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_245)));
        v_t_248 = (g_heff_2eelab_2etoplevel_2eflatPat(v_t_247));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str6, 0, "");
Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V v_sp_240, V v_c_241) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009), v_sp_240, v_c_241, ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str0), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str1), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str2), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str3), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str4), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str5), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str6)));
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str5, 0, "");
Clo g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(V v_sp_240, V v_x3_241, V v_cs_242) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str0), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str1), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str2), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str3), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str4), v_sp_240, v_x3_241, v_cs_242, ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str5)));
}
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V v_i_240) {
top: ;
  V v_t_2434;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_x11_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_na(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_241, 0ULL, 3);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_INominal: {
      V v_i_2427 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      v_t_2434 = v_i_2427;
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2434 = heff_dup(v_i_240);
      break;
    }
    default: heff_nomatch(v_x11_241);
    }
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2468;
  switch (heff_tag_of(v_t_2434)) {
  case TAG_At: {
    V v_x11_2435 = heff_field(v_t_2434, 0);
    heff_take_n(v_t_2434, 1ULL, 2);
    switch (heff_tag_of(v_x11_2435)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInt: {
      V v_k_2438 = heff_field(v_x11_2435, 0);
      V v_ru_24x11_2435_24IInt = heff_take_reuse_n(v_x11_2435, 1ULL, 1);
      v_t_2468 = heff_tag_at_n(v_ru_24x11_2435_24IInt, TAG_Just, 1, (V[]){heff_tag_n(TAG_IntNum, 1, (V[]){v_k_2438})});
      break;
    }
    case TAG_IFloat: {
      double v_x_2439 = heff_tflat_f64(v_x11_2435, 0);
      V v_ru_24x11_2435_24IFloat = heff_take_reuse_na(v_x11_2435, 0ULL, 1);
      v_t_2468 = heff_tag_at_n(v_ru_24x11_2435_24IFloat, TAG_Just, 1, (V[]){heff_tag_nf(TAG_FracNum, 1, 1u, (V[]){heff_word_f64(v_x_2439)})});
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2435, 0ULL, 2);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2435, 0ULL, 2);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2435, 0ULL, 4);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2435, 0ULL, 2);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2435, 0ULL, 4);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2435, 0ULL, 3);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2435, 0ULL, 4);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_2435, 0ULL, 1);
      v_t_2468 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2435);
    }
    break;
  }
  default: heff_nomatch(v_t_2434);
  }
  switch (heff_tag_of(v_t_2468)) {
  case TAG_Nothing: {
    V v_c_2469 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_240)));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0, 2, 2, (V[]){v_c_2469, v_i_240});
  }
  case TAG_Just: {
    V v_lit_2475 = heff_field(v_t_2468, 0);
    heff_take_n(v_t_2468, 1ULL, 1);
    V v_t_24109;
    switch (heff_tag_of(v_i_240)) {
    case TAG_At: {
      V v_x11_2476 = heff_dup(heff_field(v_i_240, 0));
      switch (heff_tag_of(v_x11_2476)) {
      case TAG_IVar: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_na(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IBytes: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IPrim: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_x11_2476, 0ULL, 2);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_x11_2476, 0ULL, 2);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_x11_2476, 0ULL, 4);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IUpdate: {
        heff_take_n(v_x11_2476, 0ULL, 2);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_x11_2476, 0ULL, 4);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_x11_2476, 0ULL, 3);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_True);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_x11_2476, 0ULL, 4);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_ILazy: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      case TAG_ITuple: {
        heff_take_n(v_x11_2476, 0ULL, 1);
        v_t_24109 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_2476);
      }
      break;
    }
    default: heff_nomatch(v_i_240);
    }
    V v_t_24117;
    if ((heff_dup(v_t_24109) == NTAG(TAG_True))) {
      heff_drop(v_t_24109);
      V v_t_24112;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_24111 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_24112 = v_s_24111;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      V v_t_24113 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24112, v_lit_2475));
      v_t_24117 = ({ V a_0 = v_t_24113; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_t_24113); r_; });
    } else {
      heff_drop(v_t_24109);
      V v_t_24116;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_24115 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_24116 = v_s_24115;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      v_t_24117 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24116, v_lit_2475));
    }
    V v_x_24118 = ({ V a_0 = v_t_24117; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_24117); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2, 2, 1, (V[]){v_x_24118});
  }
  default: return heff_nomatch(v_t_2468);
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args) {
  V v_x_2472 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_2471 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2473 = ({ V a_0 = v_i_240; V a_1 = v_x_2472; V r_ = (g_heff_2eelab_2etoplevel_2echkHeadOf(a_0, a_1)); heff_drop(v_x_2472); r_; });
  V v_x_2474 = ({ V a_0 = v_t_2473; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_2473); r_; });
  V f_ = v_k_2471;
  args[0] = v_x_2474;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k_2471 = args[1];
  V v_c_2469 = heff_env(self)[0];
  V v_i_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2469;
  args[0] = v_hd_2470;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1, 1, 2, (V[]){v_i_240, v_k_2471});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args) {
  V v_hd_24119 = args[0];
  V v_k_24120 = args[1];
  V v_x_24118 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24119);
  V f_ = v_k_24120;
  args[0] = v_x_24118;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4, 40, "unexpected notation for local definition");
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V v_x2_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_241));
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_240, 0);
    V v_ds_243 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_At: {
      V v_x_244 = heff_field(v_d_242, 0);
      v_t_246 = heff_dup(v_x_244);
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_name_247 = heff_field(v_t_246, 0);
      V v_tyN_2410 = heff_field(v_t_246, 3);
      V v_eqs_2411 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 25ULL, 5);
      V v_c_2412 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_2410));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0, 2, 6, (V[]){v_c_2412, heff_dup(v_d_242), v_name_247, v_eqs_2411, heff_dup(v_ds_243), v_body_241});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_body_241);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8, 2, 1, (V[]){heff_dup(v_d_242)});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2423 = ({ V a_0 = v_name_247; V a_1 = v_x_2415; V a_2 = v_x_2420; V a_3 = v_x_2422; V r_ = (g_heff_2eelab_2erules_2elocalDef(a_0, a_1, a_2, a_3)); heff_drop(v_x_2415); heff_drop(v_x_2420); heff_drop(v_x_2422); r_; });
  V f_ = v_k_2414;
  args[0] = v_t_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_ds_243 = heff_env(self)[0];
  V v_body_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_name_247 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2421 = ({ V a_0 = v_ds_243; V a_1 = v_body_241; V r_ = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a_0, a_1)); heff_drop(v_ds_243); r_; });
  V f_ = v_c_2421;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3, 1, 4, (V[]){v_name_247, v_x_2415, v_x_2420, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_242 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_eqs_2411 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2418;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2417 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2418 = v_s_2417;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_c_2419 = (g_heff_2eelab_2etoplevel_2elocalBody_24s216180691x1646735027(heff_dup(v_name_247), v_eqs_2411, v_t_2418));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2, 1, 6, (V[]){v_ds_243, v_body_241, v_hd_2413, v_name_247, v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_d_242 = heff_env(self)[1];
  V v_name_247 = heff_env(self)[2];
  V v_eqs_2411 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1, 1, 7, (V[]){v_d_242, v_name_247, v_eqs_2411, v_hd_2413, v_ds_243, v_body_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k2_2430 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2432 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2433 = v_s_2432;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0), v_t_2433, NTAG(TAG_Nothing)});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_2429, 2), 1, (V[]){v_t_2436}));
  V f_ = heff_get_n(v_hd_2429, 1, 3);
  args[0] = v_t_2437;
  args[1] = v_k2_2430;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args) {
  V v_hd_2442 = args[0];
  V v_k2_2443 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2446;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2445 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2446 = v_s_2445;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1), v_t_2446, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_2442, 2), 1, (V[]){v_t_2449}));
  V f_ = heff_get_n(v_hd_2442, 1, 3);
  args[0] = v_t_2450;
  args[1] = v_k2_2443;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args) {
  V v_hd_2454 = args[0];
  V v_k2_2455 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2457 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2458 = v_s_2457;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2459 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2), v_t_2458, NTAG(TAG_Nothing)});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tr(heff_call(heff_take_field(v_hd_2454, 2), 1, (V[]){v_t_2461}));
  V f_ = heff_get_n(v_hd_2454, 1, 3);
  args[0] = v_t_2462;
  args[1] = v_k2_2455;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2468 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2469 = v_s_2468;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3), v_t_2469, NTAG(TAG_Nothing)});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tr(heff_call(heff_take_field(v_hd_2465, 2), 1, (V[]){v_t_2472}));
  V f_ = heff_get_n(v_hd_2465, 1, 3);
  args[0] = v_t_2473;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2479;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2478 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2479 = v_s_2478;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4), v_t_2479, NTAG(TAG_Nothing)});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2482}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2483;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eargBinding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eargBinding_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eargBinding(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_sp_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_ExplicitParam: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_t_245 = heff_field(v_x11_241, 2);
      V v_n_248;
      switch (heff_tag_of(v_t_245)) {
      case TAG_At: {
        V v_n_246 = heff_field(v_t_245, 0);
        V v_sp_247 = heff_field(v_t_245, 1);
        v_n_248 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_247), heff_dup(v_n_246)));
        break;
      }
      default: heff_nomatch(v_t_245);
      }
      V v_c_249 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_248));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam0, 2, 3, (V[]){v_c_249, heff_dup(v_sp_242), heff_dup(v_x_243)});
    }
    case TAG_ImplicitParam: {
      V v_x_2414 = heff_field(v_x11_241, 0);
      V v_t_2416 = heff_field(v_x11_241, 2);
      V v_n_2419;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_At: {
        V v_n_2417 = heff_field(v_t_2416, 0);
        V v_sp_2418 = heff_field(v_t_2416, 1);
        v_n_2419 = (g_heff_2esyntax_2epresyntax_2etypNom_24s444911345x1535762087(heff_dup(v_sp_2418), heff_dup(v_n_2417)));
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_c_2420 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_n_2419));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam2, 2, 3, (V[]){v_c_2420, heff_dup(v_sp_242), heff_dup(v_x_2414)});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eargBinding_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eargBinding(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_243, v_x_2412, NTAG(TAG_Expl)});
  V f_ = v_k_2411;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_249;
  args[0] = v_hd_2410;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam1, 1, 3, (V[]){v_sp_242, v_x_243, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_sp_242 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_k_2422 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2424 = heff_rec_n(4, shape_span__name__typ__implicit, (V[]){v_sp_242, v_x_2414, v_x_2423, NTAG(TAG_Impl)});
  V f_ = v_k_2422;
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eargBinding_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_sp_242 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = v_hd_2421;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eargBinding_lam3, 1, 3, (V[]){v_sp_242, v_x_2414, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_str0, 21, "errors recovered from");
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0, 1, 0};
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_240, 2)), 1, (V[]){v_t_244}));
  return heff_tail(heff_dup(heff_rfield(v_hd_240, 1)), 2, (V[]){v_t_245, heff_clo_n(g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1, 1, 2, (V[]){v_k_241, v_hd_240})});
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam0(V self, V *args) {
  V v_c_242 = args[0];
  return heff_get_n(v_c_242, 1, 8);
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_241 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_x_246; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_x_246); r_; });
  if (heff_intEq_c(v_t_247, MK_INT(0LL))) {
    heff_drop_rec(v_hd_240, 3);
    V f_ = v_k_241;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_240, 2), 1, (V[]){v_t_2411}));
    V f_ = heff_get_n(v_hd_240, 1, 3);
    heff_room[0] = v_t_2412;
    heff_room[1] = v_k_241;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
Clo g_heff_2eelab_2etoplevel_2enubInt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enubInt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s193123870x387721583(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2eelab_2etoplevel_2enubInt_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2echeckUnsolved_str0, 21, "`; give it as `{...}`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2echeckUnsolved_str1, 36, "cannot infer the implicit argument `");
Clo g_heff_2eelab_2etoplevel_2echeckUnsolved_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echeckUnsolved_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2echeckUnsolved(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_u_243 = heff_field(v_x1_240, 0);
    V v_t_245 = heff_strAppend(heff_dup(heff_rfield(v_u_243, 0)), ((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str0));
    V v_t_246 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2echeckUnsolved_str1), v_t_245), heff_dup(heff_rfield(v_u_243, 1)), NTAG(TAG_Nothing)});
    V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tr(heff_call(heff_take_field(v_p_241, 2), 1, (V[]){v_t_248}));
    return heff_tail(heff_get_n(v_p_241, 1, 3), 2, (V[]){v_t_249, v_p_242});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2echeckUnsolved_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2echeckUnsolved(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_244;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_241, 0)), MK_INT(-1LL))) {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_244 = NTAG(TAG_Nil);
    } else {
      v_t_244 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    V v_t_245 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_xs_242));
    return (g_heff_2eelab_2etoplevel_2eappendT(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2esameDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2esameDiag_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2esameDiag(V v_a_240, V v_b_241) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0))) && ({ V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_a_240, 3)), 0, 2); int c_ = ({ V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_b_241, 3)), 0, 2); int c_ = (heff_intEq_c_lent(v_t_243, v_t_244, 0) && ({ V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_a_240, 3)), 1, 2); int c_ = ({ V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_b_241, 3)), 1, 2); int c_ = (heff_intEq_c_lent(v_t_246, v_t_247, 0) && heff_strEq_c(heff_dup(heff_rfield(v_a_240, 2)), heff_dup(heff_rfield(v_b_241, 2)))); heff_drop(v_t_247); c_; }); heff_drop(v_t_246); c_; })); heff_drop(v_t_244); c_; }); heff_drop(v_t_243); c_; })));
  heff_drop_rec(v_a_240, 5);
  heff_drop_rec(v_b_241, 5);
  return v_ret_24bool;
}
V g_heff_2eelab_2etoplevel_2esameDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2esameDiag(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0, 21, "errors recovered from");
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V v_k_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_245, 1, 8); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  if (heff_intEq_c(v_t_246, MK_INT(0LL))) {
    return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_241});
  } else {
    heff_drop(v_k_240);
    V v_t_248 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_248}), v_st_241});
  }
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(a[0], a[1]);
}