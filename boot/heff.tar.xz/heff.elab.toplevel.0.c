// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Delayed2 38439
#define TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009 47022
#define TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422 47314
#define TAG_ForNominative 23095
#define TAG_FracNum 48168
#define TAG_Get 18914
#define TAG_IAnn 21211
#define TAG_IAnnLam 5506
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IFloat 36430
#define TAG_IInt 28905
#define TAG_IInvalid 29207
#define TAG_ILazy 55579
#define TAG_ILitEq 53459
#define TAG_INominal 43674
#define TAG_IPrim 59489
#define TAG_IRune 56575
#define TAG_ISpec 15754
#define TAG_IString 21554
#define TAG_ITuple 64404
#define TAG_IUpdate 19608
#define TAG_IVar 40993
#define TAG_IntNum 31256
#define TAG_LNil 57394
#define TAG_Large 60129
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkChk 56962
#define TAG_MkEquation 38417
#define TAG_MkFieldPat 14710
#define TAG_MkSt 48854
#define TAG_MkSyn 7342
#define TAG_N 306
#define TAG_NotInScope 14443
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_Small 51389
#define TAG_Throw 56084
#define TAG_TopL 65516
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_ctx 308385
#define LBL_el 9998
#define LBL_elabFor 712452832
#define LBL_end 310101
#define LBL_globals 352931696
#define LBL_head 9693863
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_level 304224158
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_pats 9928951
#define LBL_places 961367927
#define LBL_recovered 474271923
#define LBL_rhs 322423
#define LBL_scope 310622830
#define LBL_scrutinee 73860976
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_stx 323761
#define LBL_syntax 1059664654
#define LBL_tree 10063973
#define LBL_ty 10476
#define LBL_tySyntax 1405311289
#define LBL_type_5f 312202367
#define LBL_value 313331083
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_syntax__tySyntax__value__type_5f[] = {LBL_syntax, LBL_tySyntax, LBL_value, LBL_type_5f};
V g_co_2ebind_24s491334399x268717303(V, V);
V g_co_2ebind_24s491334399x268717303_entry(V self, V *a);
extern Clo g_co_2ebind_24s491334399x268717303_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(V, V, V, V);
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
HeffT2 g_heff_2eelab_2eclauses_2epat_24cpr(V);
V g_heff_2eelab_2eclauses_2eunreachedAlts(V);
V g_heff_2eelab_2eclauses_2eunreachedAlts_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eunreachedAlts_clo;
V g_heff_2eelab_2eenvironment_2eemptyScope_get(void);
V g_heff_2eelab_2eenvironment_2eseeArms(V, V, V);
V g_heff_2eelab_2eenvironment_2eseeArms_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2eseeArms_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eglobals_2eplacesSaid(V);
V g_heff_2eelab_2eglobals_2eplacesSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eglobals_2eplacesSaid_clo;
HeffT3 g_heff_2eelab_2eglobals_2eresolve_24cpr(V, V);
V g_heff_2eelab_2emeta_2eelabH_get(void);
V g_heff_2eelab_2emeta_2esettleGo(V, V, V, V);
V g_heff_2eelab_2emeta_2esettleGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2esettleGo_clo;
V g_heff_2eelab_2eparams_2enoSpan_get(void);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erules_2eapply(V, V);
V g_heff_2eelab_2erules_2eapply_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapply_clo;
V g_heff_2eelab_2erules_2ecaseLet(V, V, V);
V g_heff_2eelab_2erules_2ecaseLet_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseLet_clo;
V g_heff_2eelab_2erules_2eimplicitLams(V);
V g_heff_2eelab_2erules_2eimplicitLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_clo;
V g_heff_2eelab_2erules_2eimplicitLams_24tok1(V, V);
V g_heff_2eelab_2erules_2eimplicitLams_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eimplicitLams_24tok1_clo;
V g_heff_2eelab_2erules_2elocalDef(V, V, V, V);
V g_heff_2eelab_2erules_2elocalDef_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elocalDef_clo;
V g_heff_2eelab_2erules_2ementionsLocal(V);
V g_heff_2eelab_2erules_2ementionsLocal_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ementionsLocal_clo;
V g_heff_2eelab_2erules_2enumLitChk(V, V);
V g_heff_2eelab_2erules_2enumLitChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enumLitChk_clo;
HeffT1 g_heff_2eelab_2erules_2erecChk_24cpr(V, V);
V g_heff_2eelab_2erules_2esumElim(V, V, V, V);
V g_heff_2eelab_2erules_2esumElim_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumElim_clo;
HeffT2 g_heff_2eelab_2erules_2evarGo_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf(V, V, V, V);
V g_heff_2eelab_2etop_2evalueOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etop_2evalueOf_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V);
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo;
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(V);
V g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875_clo;
V g_heff_2eelab_2etoplevel_2eannotatesData(V);
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo;
V g_heff_2eelab_2etoplevel_2eappendT(V, V);
V g_heff_2eelab_2etoplevel_2eappendT_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eappendT_clo;
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(V);
V g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539_clo;
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo;
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V);
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo;
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(V);
V g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990_clo;
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(V, V, V);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_clo;
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529(V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_clo;
V g_heff_2eelab_2etoplevel_2eflatPat(V);
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eflatPat_clo;
V g_heff_2eelab_2etoplevel_2ehasOpPat(V);
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo;
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(V);
V g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588_clo;
HeffT2 g_heff_2eelab_2etoplevel_2elamsOf_24cpr(V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo;
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle_clo;
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(V, V, V);
V g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288_clo;
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V, V);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo;
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600(V, V, V, V);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_clo;
V g_heff_2eelab_2etoplevel_2enamedTwice(V, V);
V g_heff_2eelab_2etoplevel_2enamedTwice_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enamedTwice_clo;
V g_heff_2eelab_2etoplevel_2enominalChk(V);
V g_heff_2eelab_2etoplevel_2enominalChk_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enominalChk_clo;
V g_heff_2eelab_2etoplevel_2enubInt(V);
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_clo;
V g_heff_2eelab_2etoplevel_2enubInt_24dps(V, V);
V g_heff_2eelab_2etoplevel_2enubInt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2enubInt_24dps_clo;
V g_heff_2eelab_2etoplevel_2eopPat(V, V);
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eopPat_clo;
V g_heff_2eelab_2etoplevel_2eparamsInOrder(V, V, V);
V g_heff_2eelab_2etoplevel_2eparamsInOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2eparamsInOrder_clo;
HeffT2 g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(V, V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267(V, V);
V g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267_clo;
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V, V);
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo;
V g_heff_2eelab_2etoplevel_2estuckAt(V, V, V, V);
V g_heff_2eelab_2etoplevel_2estuckAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2estuckAt_clo;
V g_heff_2eelab_2etoplevel_2etagSpanOf(V, V);
V g_heff_2eelab_2etoplevel_2etagSpanOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpanOf_clo;
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(V, V, V);
V g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2_clo;
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(V, V, V, V);
V g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923_clo;
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(V, V, V);
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_clo;
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(V);
V g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251_clo;
V g_heff_2eelab_2eunify_2ezonker(V);
V g_heff_2eelab_2eunify_2ezonker_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonker_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(V);
V g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708_clo;
V g_heff_2esyntax_2epresyntax_2einfSpineOf(V);
V g_heff_2esyntax_2epresyntax_2einfSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2einfSpineOf_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_heff_2esyntax_2epresyntax_2epatSpineOf(V);
V g_heff_2esyntax_2epresyntax_2epatSpineOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2epatSpineOf_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf_24s512765522x2052101617(V, V);
V g_list_2ekeepIf_24s512765522x2052101617_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s512765522x2052101617_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s839307021x1449425912(V);
V g_list_2emap_24s839307021x1449425912_entry(V self, V *a);
extern Clo g_list_2emap_24s839307021x1449425912_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2eelab_2etoplevel_2eannotatesData_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eannotatesData_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eannotatesData(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      return NTAG(TAG_False);
    }
    case TAG_IInt: {
      return NTAG(TAG_False);
    }
    case TAG_IFloat: {
      return NTAG(TAG_False);
    }
    case TAG_IString: {
      return NTAG(TAG_False);
    }
    case TAG_IBytes: {
      return NTAG(TAG_False);
    }
    case TAG_IPrim: {
      return NTAG(TAG_False);
    }
    case TAG_IRune: {
      return NTAG(TAG_False);
    }
    case TAG_IApp: {
      return NTAG(TAG_False);
    }
    case TAG_IAnn: {
      V v_c_2412 = heff_field(v_x11_241, 0);
      switch (heff_tag_of(v_c_2412)) {
      case TAG_At: {
        V v_c1_2414 = heff_field(v_c_2412, 0);
        switch (heff_tag_of(v_c1_2414)) {
        case TAG_CInf: {
          return NTAG(TAG_False);
        }
        case TAG_CType: {
          return NTAG(TAG_False);
        }
        case TAG_CLam: {
          return NTAG(TAG_False);
        }
        case TAG_CImplicitLam: {
          return NTAG(TAG_False);
        }
        case TAG_CAnnLam: {
          return NTAG(TAG_False);
        }
        case TAG_CTag: {
          return NTAG(TAG_True);
        }
        case TAG_CStruct: {
          return NTAG(TAG_True);
        }
        case TAG_CMatch: {
          return NTAG(TAG_False);
        }
        case TAG_CLetIn: {
          return NTAG(TAG_False);
        }
        case TAG_CLocal: {
          return NTAG(TAG_False);
        }
        case TAG_CAbandon: {
          return NTAG(TAG_False);
        }
        case TAG_CNominal: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_c1_2414);
        }
      }
      default: return heff_nomatch(v_c_2412);
      }
    }
    case TAG_ISpec: {
      return NTAG(TAG_False);
    }
    case TAG_IUpdate: {
      return NTAG(TAG_False);
    }
    case TAG_IAnnLam: {
      return NTAG(TAG_False);
    }
    case TAG_IInvalid: {
      return NTAG(TAG_False);
    }
    case TAG_INominal: {
      return NTAG(TAG_False);
    }
    case TAG_ILitEq: {
      return NTAG(TAG_False);
    }
    case TAG_ILazy: {
      return NTAG(TAG_False);
    }
    case TAG_ITuple: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2eannotatesData_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eannotatesData(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eflatPat_str0, 1, "_");
Clo g_heff_2eelab_2etoplevel_2eflatPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eflatPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eflatPat(V v_gr_240) {
top: ;
  V v_head_241 = heff_take_field(v_gr_240, 0);
  V v_args_242 = heff_get_n(v_gr_240, 1, 2);
  V v_t_245;
  switch (heff_tag_of(v_head_241)) {
  case TAG_At: {
    V v_x_243 = heff_field(v_head_241, 0);
    heff_take_n(v_head_241, 1ULL, 2);
    v_t_245 = v_x_243;
    break;
  }
  default: heff_nomatch(v_head_241);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_PatVar: {
    V v_x_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    V v_ret_24bool = heff_bool((heff_strEq_c_lent(v_x_246, ((V)&g_heff_2eelab_2etoplevel_2eflatPat_str0), 2) && ({ V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_242)); int c_ = heff_intEq_c_lent(v_t_2423, MK_INT(0LL), 2); heff_drop(v_t_2423); c_; })));
    heff_drop(v_args_242);
    heff_drop(v_x_246);
    return v_ret_24bool;
  }
  case TAG_PatTag: {
    heff_take_n(v_t_245, 0ULL, 3);
    return ({ V a_0 = v_args_242; V r_ = (g_heff_2eelab_2etoplevel_2eallL_24s1606298621x549028181(a_0)); heff_drop(v_args_242); r_; });
  }
  case TAG_PatOp: {
    heff_take_n(v_t_245, 0ULL, 3);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatInt: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatFloat: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatString: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatBinary: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatRune: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatRecord: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatWord: {
    heff_take_n(v_t_245, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  case TAG_PatAs: {
    heff_take_n(v_t_245, 0ULL, 3);
    heff_drop(v_args_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eelab_2etoplevel_2eflatPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eflatPat(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2ehasOpPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ehasOpPat_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2ehasOpPat(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_241 = heff_field(v_p_240, 0);
    switch (heff_tag_of(v_p1_241)) {
    case TAG_PatVar: {
      return NTAG(TAG_False);
    }
    case TAG_PatTag: {
      V v_ps_246 = heff_field(v_p1_241, 2);
      V v_x1_247 = (g_heff_2eelab_2etoplevel_2eallL_24s1544135815x1786175187(v_ps_246));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
      heff_drop(v_x1_247);
      return v_ret_24bool;
    }
    case TAG_PatOp: {
      return NTAG(TAG_True);
    }
    case TAG_PatInt: {
      return NTAG(TAG_False);
    }
    case TAG_PatFloat: {
      return NTAG(TAG_False);
    }
    case TAG_PatString: {
      return NTAG(TAG_False);
    }
    case TAG_PatBinary: {
      return NTAG(TAG_False);
    }
    case TAG_PatRune: {
      return NTAG(TAG_False);
    }
    case TAG_PatRecord: {
      V v_fs_2416 = heff_field(v_p1_241, 0);
      V v_x1_2417 = (g_heff_2eelab_2etoplevel_2eallL_24s227348126x1642884875(v_fs_2416));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2417) == NTAG(TAG_True)));
      heff_drop(v_x1_2417);
      return v_ret_24bool;
    }
    case TAG_PatWord: {
      return NTAG(TAG_False);
    }
    case TAG_PatAs: {
      V v_q_2421 = heff_field(v_p1_241, 2);
      V t_0 = v_q_2421;
      v_p_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_p1_241);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2etoplevel_2ehasOpPat_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2ehasOpPat(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str1, 13, "` is defined ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str2, 5, "uses ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str3, 26, ", which does not elaborate");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str4, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str5, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str6, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str7, 1, "`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str8, 105, "` is not another name for a tag, so no pattern can use it: an operator in a pattern is defined as one, `(");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str9, 14, ") x y = C x y`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str10, 17, "no such operator ");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eopPat_str11, 9, " in scope");
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam22(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam23(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam25(V self, V *args);
V g_heff_2eelab_2etoplevel_2eopPat_lam24(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eopPat_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eopPat_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2eopPat(V v_g_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_At: {
    V v_p1_242 = heff_dup(heff_field(v_p_241, 0));
    switch (heff_tag_of(v_p1_242)) {
    case TAG_PatVar: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam0, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatTag: {
      V v_t_247 = heff_field(v_p1_242, 0);
      V v_tsp_248 = heff_field(v_p1_242, 1);
      V v_args_249 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        heff_take_n(v_p_241, 0ULL, 2);
        V v_c_2413 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam1, 1, 1, (V[]){v_g_240}), v_args_249));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam2, 2, 3, (V[]){v_c_2413, v_t_247, v_tsp_248});
      }
      default: return heff_nomatch(v_p_241);
      }
    }
    case TAG_PatOp: {
      V v_x_2424 = heff_field(v_p1_242, 0);
      V v_xsp_2425 = heff_field(v_p1_242, 1);
      V v_args_2426 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_ru_24p_241_24At = heff_take_reuse_n(v_p_241, 0ULL, 2);
        HeffT3 v_t_2429 = (g_heff_2eelab_2eglobals_2eresolve_24cpr(heff_dup(v_g_240), heff_dup(v_x_2424)));
        {
          V v_field_2431 = v_t_2429.f[1];
          V v_field_2432 = v_t_2429.f[2];
          int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
          if ((v_tag_2430 == ((int64_t)0ULL))) {
            heff_drop(v_args_2426);
            heff_drop(v_field_2432);
            V v_ks_2433 = v_field_2431;
            V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str0), v_x_2424), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str1));
            V v_t_2440 = (g_list_2emap_24tok2(v_ru_24p_241_24At, heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam4, 1, 1, (V[]){v_g_240}), v_ks_2433));
            V v_t_2441 = ({ V a_0 = v_t_2440; V r_ = (g_heff_2eelab_2eglobals_2eplacesSaid(a_0)); heff_drop(v_t_2440); r_; });
            V v_msg_2442 = heff_strAppend(v_t_2434, v_t_2441);
            return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam5, 2, 2, (V[]){v_msg_2442, v_xsp_2425});
          } else {
            if ((v_tag_2430 == ((int64_t)1ULL))) {
              heff_drop_rec(v_g_240, 8);
              heff_drop(v_args_2426);
              heff_drop_cell(v_ru_24p_241_24At, 2);
              heff_drop(v_field_2431);
              heff_drop(v_field_2432);
              return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam6, 2, 2, (V[]){v_x_2424, v_xsp_2425});
            } else {
              if ((v_tag_2430 == ((int64_t)2ULL))) {
                V v_x_2460 = v_field_2431;
                heff_drop(v_x_2460);
                V v_ge_2461 = v_field_2432;
                V v_ge_2462 = v_ge_2461;
                V v_tySyntax_2463 = heff_take_field(v_ge_2462, 1);
                V v_syntax_2464 = heff_get_n(v_ge_2462, 0, 4);
                HeffT2 v_t_2465 = (g_heff_2eelab_2etoplevel_2eparamsOf_24cpr(MK_INT(0LL), MK_INT(0LL), v_tySyntax_2463));
                V v_it_24112;
                {
                  V v_field_2467 = v_t_2465.f[1];
                  int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                  if ((v_tag_2466 == ((int64_t)0ULL))) {
                    V v_it1_2468 = v_field_2467;
                    switch (heff_tag_of(v_it1_2468)) {
                    case TAG_MkPair: {
                      V v_i_2469 = heff_field(v_it1_2468, 0);
                      V v_k_2470 = heff_field(v_it1_2468, 1);
                      heff_take_n(v_it1_2468, 3ULL, 2);
                      HeffT2 v_t_2471 = (g_heff_2eelab_2etoplevel_2elamsOf_24cpr(MK_INT(0LL), v_syntax_2464));
                      {
                        V v_field_2472 = v_t_2471.f[0];
                        V v_field_2473 = v_t_2471.f[1];
                        V v_n_2474 = v_field_2472;
                        V v_it2_2475 = v_field_2473;
                        switch (heff_tag_of(v_it2_2475)) {
                        case TAG_SLocal: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SGlobal: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SCode: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SApp: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLam: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SCons: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SProj: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_STag: {
                          V v_t_2486 = heff_field(v_it2_2475, 0);
                          V v_args_2487 = heff_field(v_it2_2475, 1);
                          heff_take_n(v_it2_2475, 3ULL, 2);
                          if (heff_intEq_c(v_n_2474, heff_intAdd(v_i_2469, heff_dup(v_k_2470)))) {
                            V v_t_2488 = ({ V a_0 = heff_dup(v_k_2470); V a_1 = MK_INT(0LL); V b_2 = heff_arrayToList(v_args_2487); V r_ = (g_heff_2eelab_2etoplevel_2eparamsInOrder(a_0, a_1, b_2)); heff_drop(b_2); r_; });
                            if ((heff_dup(v_t_2488) == NTAG(TAG_True))) {
                              heff_drop(v_t_2488);
                              v_it_24112 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24p_241_24At, TAG_MkPair, 2, (V[]){v_t_2486, v_k_2470})});
                            } else {
                              heff_drop_cell(v_ru_24p_241_24At, 2);
                              heff_drop(v_k_2470);
                              heff_drop(v_t_2486);
                              heff_drop(v_t_2488);
                              v_it_24112 = NTAG(TAG_Nothing);
                            }
                          } else {
                            heff_drop_cell(v_ru_24p_241_24At, 2);
                            heff_drop(v_k_2470);
                            heff_drop(v_t_2486);
                            heff_drop(v_args_2487);
                            v_it_24112 = NTAG(TAG_Nothing);
                          }
                          break;
                        }
                        case TAG_SMatch: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SSpecialize: {
                          heff_take_n(v_it2_2475, 0ULL, 3);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SIs: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SOpaque: {
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SAbandon: {
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SRec: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SFix: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SImplicit: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SPrim: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SMetaApp: {
                          heff_take_n(v_it2_2475, 0ULL, 3);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitInt: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitFloat: {
                          heff_take_na(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitString: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitBytes: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitRune: {
                          heff_take_n(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitFixed: {
                          heff_take_n(v_it2_2475, 0ULL, 2);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        case TAG_SLitFloat32: {
                          heff_take_na(v_it2_2475, 0ULL, 1);
                          heff_drop_cell(v_ru_24p_241_24At, 2);
                          heff_drop(v_i_2469);
                          heff_drop(v_k_2470);
                          heff_drop(v_n_2474);
                          v_it_24112 = NTAG(TAG_Nothing);
                          break;
                        }
                        default: heff_nomatch(v_it2_2475);
                        }
                      }
                      break;
                    }
                    default: heff_nomatch(v_it1_2468);
                    }
                  } else {
                    heff_drop_cell(v_ru_24p_241_24At, 2);
                    heff_drop(v_syntax_2464);
                    heff_drop(v_field_2467);
                    v_it_24112 = NTAG(TAG_Nothing);
                  }
                }
                switch (heff_tag_of(v_it_24112)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_g_240, 8);
                  heff_drop(v_args_2426);
                  return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam7, 2, 2, (V[]){v_x_2424, v_xsp_2425});
                }
                case TAG_Just: {
                  V v_it1_24123 = heff_field(v_it_24112, 0);
                  heff_take_n(v_it_24112, 1ULL, 1);
                  switch (heff_tag_of(v_it1_24123)) {
                  case TAG_MkPair: {
                    V v_t_24124 = heff_field(v_it1_24123, 0);
                    V v_k_24125 = heff_field(v_it1_24123, 1);
                    heff_take_n(v_it1_24123, 3ULL, 2);
                    V v_t_24126 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2426));
                    if (heff_intEq_c(v_k_24125, v_t_24126)) {
                      heff_drop(v_x_2424);
                      V v_c_24128 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam8, 1, 1, (V[]){v_g_240}), v_args_2426));
                      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam9, 2, 3, (V[]){v_c_24128, v_t_24124, v_xsp_2425});
                    } else {
                      heff_drop_rec(v_g_240, 8);
                      heff_drop(v_args_2426);
                      heff_drop(v_t_24124);
                      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam11, 2, 2, (V[]){v_x_2424, v_xsp_2425});
                    }
                  }
                  default: return heff_nomatch(v_it1_24123);
                  }
                }
                default: return heff_nomatch(v_it_24112);
                }
              } else {
                heff_drop_rec(v_g_240, 8);
                heff_drop(v_args_2426);
                heff_drop_cell(v_ru_24p_241_24At, 2);
                heff_drop(v_field_2431);
                heff_drop(v_field_2432);
                return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam12, 2, 2, (V[]){v_x_2424, v_xsp_2425});
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_p_241);
      }
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam13, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam14, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatString: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam15, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatBinary: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam16, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam17, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatRecord: {
      V v_fs_24173 = heff_field(v_p1_242, 0);
      heff_take_n(v_p1_242, 1ULL, 1);
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_p2_24175 = heff_field(v_p_241, 1);
        heff_take_n(v_p_241, 2ULL, 2);
        V v_c_24183 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam18, 1, 1, (V[]){v_g_240}), v_fs_24173));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam21, 2, 2, (V[]){v_c_24183, v_p2_24175});
      }
      default: return heff_nomatch(v_p_241);
      }
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_242, 0ULL, 1);
      heff_drop_rec(v_g_240, 8);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam23, 2, 1, (V[]){v_p_241});
    }
    case TAG_PatAs: {
      V v_x_24191 = heff_field(v_p1_242, 0);
      V v_xsp_24192 = heff_field(v_p1_242, 1);
      V v_q_24193 = heff_field(v_p1_242, 2);
      heff_take_n(v_p1_242, 7ULL, 3);
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_p2_24195 = heff_field(v_p_241, 1);
        heff_take_n(v_p_241, 2ULL, 2);
        V v_c_24196 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_q_24193));
        return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam24, 2, 4, (V[]){v_c_24196, v_x_24191, v_xsp_24192, v_p2_24195});
      }
      default: return heff_nomatch(v_p_241);
      }
    }
    default: return heff_nomatch(v_p1_242);
    }
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eopPat(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam1(V self, V *args) {
  V v_m_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_2412));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_t_247 = heff_env(self)[0];
  V v_tsp_248 = heff_env(self)[1];
  V v_k_2415 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_247)}), heff_dup(v_tsp_248)});
  V v_x1_2418 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_2417, v_x_2416));
  V v_t_2421;
  switch (heff_tag_of(v_x1_2418)) {
  case TAG_At: {
    V v_s_2420 = heff_field(v_x1_2418, 1);
    heff_take_n(v_x1_2418, 2ULL, 2);
    v_t_2421 = v_s_2420;
    break;
  }
  default: heff_nomatch(v_x1_2418);
  }
  V v_t_2422 = ({ V rv_0 = heff_dup(heff_rfield(v_tsp_248, 0)); V rr_ = heff_rec_reuse_nf(v_t_2421, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_2423 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_247, v_tsp_248, v_x_2416}), v_t_2422});
  V f_ = v_k_2415;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam2(V self, V *args) {
  V v_hd_2414 = args[0];
  V v_k_2415 = args[1];
  V v_c_2413 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_tsp_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2413;
  args[0] = v_hd_2414;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam3, 1, 3, (V[]){v_t_247, v_tsp_248, v_k_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam4(V self, V *args) {
  V v_k_2435 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_g_240, 5, 8); V a_1 = v_k_2435; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2438 = v_t_2436.f[1];
    int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
    if ((v_tag_2437 == ((int64_t)0ULL))) {
      heff_drop(v_k_2435);
      V v_place_2439 = v_field_2438;
      return v_place_2439;
    } else {
      heff_drop(v_field_2438);
      return v_k_2435;
    }
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_msg_2442 = heff_env(self)[0];
  V v_xsp_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2445 = heff_take_field(v_hd_2443, 1);
  V v_malg_2446 = heff_get_n(v_hd_2443, 2, 3);
  V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(330LL), NTAG(TAG_SError), v_msg_2442, v_xsp_2425, NTAG(TAG_Nothing)});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tr(heff_call(v_malg_2446, 1, (V[]){v_t_2449}));
  V f_ = v_bind_2445;
  args[0] = v_t_2450;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam6(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k2_2452 = args[1];
  V v_x_2424 = heff_env(self)[0];
  V v_xsp_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2453 = heff_take_field(v_hd_2451, 1);
  V v_malg_2454 = heff_get_n(v_hd_2451, 2, 3);
  V v_t_2455 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str2), v_x_2424), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str3));
  V v_t_2456 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), v_t_2455, v_xsp_2425, NTAG(TAG_Nothing)});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tr(heff_call(v_malg_2454, 1, (V[]){v_t_2458}));
  V f_ = v_bind_2453;
  args[0] = v_t_2459;
  args[1] = v_k2_2452;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam7(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k2_24114 = args[1];
  V v_x_2424 = heff_env(self)[0];
  V v_xsp_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_24115 = heff_take_field(v_hd_24113, 1);
  V v_malg_24116 = heff_get_n(v_hd_24113, 2, 3);
  V v_t_24117 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str4), heff_dup(v_x_2424)), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str5));
  V v_t_24118 = heff_strAppend(heff_strAppend(v_t_24117, v_x_2424), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str6));
  V v_t_24119 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_24118, v_xsp_2425, NTAG(TAG_Nothing)});
  V v_t_24120 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24119})});
  V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
  V v_t_24122 = heff_tr(heff_call(v_malg_24116, 1, (V[]){v_t_24121}));
  V f_ = v_bind_24115;
  args[0] = v_t_24122;
  args[1] = v_k2_24114;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam8(V self, V *args) {
  V v_m_24127 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_m_24127));
}
V g_heff_2eelab_2etoplevel_2eopPat_lam10(V self, V *args) {
  V v_x_24131 = args[0];
  V v_t_24124 = heff_env(self)[0];
  V v_xsp_2425 = heff_env(self)[1];
  V v_k_24130 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24132 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){heff_dup(v_t_24124)}), heff_dup(v_xsp_2425)});
  V v_x1_24133 = (g_heff_2esyntax_2epresyntax_2elastOr(v_t_24132, v_x_24131));
  V v_t_24136;
  switch (heff_tag_of(v_x1_24133)) {
  case TAG_At: {
    V v_s_24135 = heff_field(v_x1_24133, 1);
    heff_take_n(v_x1_24133, 2ULL, 2);
    v_t_24136 = v_s_24135;
    break;
  }
  default: heff_nomatch(v_x1_24133);
  }
  V v_t_24137 = ({ V rv_0 = heff_dup(heff_rfield(v_xsp_2425, 0)); V rr_ = heff_rec_reuse_nf(v_t_24136, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V v_x_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatTag, 3, (V[]){v_t_24124, v_xsp_2425, v_x_24131}), v_t_24137});
  V f_ = v_k_24130;
  args[0] = v_x_24138;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam9(V self, V *args) {
  V v_hd_24129 = args[0];
  V v_k_24130 = args[1];
  V v_c_24128 = heff_env(self)[0];
  V v_t_24124 = heff_env(self)[1];
  V v_xsp_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_24128;
  args[0] = v_hd_24129;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam10, 1, 3, (V[]){v_t_24124, v_xsp_2425, v_k_24130});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam11(V self, V *args) {
  V v_hd_24139 = args[0];
  V v_k2_24140 = args[1];
  V v_x_2424 = heff_env(self)[0];
  V v_xsp_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_24141 = heff_take_field(v_hd_24139, 1);
  V v_malg_24142 = heff_get_n(v_hd_24139, 2, 3);
  V v_t_24143 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str7), heff_dup(v_x_2424)), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str8));
  V v_t_24144 = heff_strAppend(heff_strAppend(v_t_24143, v_x_2424), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str9));
  V v_t_24145 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_24144, v_xsp_2425, NTAG(TAG_Nothing)});
  V v_t_24146 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tr(heff_call(v_malg_24142, 1, (V[]){v_t_24147}));
  V f_ = v_bind_24141;
  args[0] = v_t_24148;
  args[1] = v_k2_24140;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam12(V self, V *args) {
  V v_hd_24149 = args[0];
  V v_k2_24150 = args[1];
  V v_x_2424 = heff_env(self)[0];
  V v_xsp_2425 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_24151 = heff_take_field(v_hd_24149, 1);
  V v_malg_24152 = heff_get_n(v_hd_24149, 2, 3);
  V v_t_24153 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eopPat_str10), v_x_2424), ((V)&g_heff_2eelab_2etoplevel_2eopPat_str11));
  V v_t_24154 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), v_t_24153, v_xsp_2425, NTAG(TAG_Nothing)});
  V v_t_24155 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24154})});
  V v_t_24156 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24155})});
  V v_t_24157 = heff_tr(heff_call(v_malg_24152, 1, (V[]){v_t_24156}));
  V f_ = v_bind_24151;
  args[0] = v_t_24157;
  args[1] = v_k2_24150;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam13(V self, V *args) {
  V v_hd_24159 = args[0];
  V v_k_24160 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24159);
  V f_ = v_k_24160;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam14(V self, V *args) {
  V v_hd_24162 = args[0];
  V v_k_24163 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24162);
  V f_ = v_k_24163;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam15(V self, V *args) {
  V v_hd_24165 = args[0];
  V v_k_24166 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24165);
  V f_ = v_k_24166;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam16(V self, V *args) {
  V v_hd_24168 = args[0];
  V v_k_24169 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24168);
  V f_ = v_k_24169;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam17(V self, V *args) {
  V v_hd_24171 = args[0];
  V v_k_24172 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24171);
  V f_ = v_k_24172;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam20(V self, V *args) {
  V v_x_24182 = args[0];
  V v_k_24181 = heff_env(self)[0];
  V v_x_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_24181;
  args[0] = heff_tag_n(TAG_MkFieldPat, 2, (V[]){v_x_24177, v_x_24182});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam19(V self, V *args) {
  V v_hd_24180 = args[0];
  V v_k_24181 = args[1];
  V v_c_24179 = heff_env(self)[0];
  V v_x_24177 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24179;
  args[0] = v_hd_24180;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam20, 1, 2, (V[]){v_k_24181, v_x_24177});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam18(V self, V *args) {
  V v_m_24176 = args[0];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_24176)) {
  case TAG_MkFieldPat: {
    V v_x_24177 = heff_field(v_m_24176, 0);
    V v_p_24178 = heff_field(v_m_24176, 1);
    heff_take_n(v_m_24176, 3ULL, 2);
    V v_c_24179 = (g_heff_2eelab_2etoplevel_2eopPat(v_g_240, v_p_24178));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam19, 2, 2, (V[]){v_c_24179, v_x_24177});
  }
  default: return heff_nomatch(v_m_24176);
  }
}
V g_heff_2eelab_2etoplevel_2eopPat_lam22(V self, V *args) {
  V v_x_24186 = args[0];
  V v_p2_24175 = heff_env(self)[0];
  V v_k_24185 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatRecord, 1, (V[]){v_x_24186}), v_p2_24175});
  V f_ = v_k_24185;
  args[0] = v_t_24187;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam21(V self, V *args) {
  V v_hd_24184 = args[0];
  V v_k_24185 = args[1];
  V v_c_24183 = heff_env(self)[0];
  V v_p2_24175 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_24183;
  args[0] = v_hd_24184;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam22, 1, 2, (V[]){v_p2_24175, v_k_24185});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam23(V self, V *args) {
  V v_hd_24189 = args[0];
  V v_k_24190 = args[1];
  V v_p_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24189);
  V f_ = v_k_24190;
  args[0] = v_p_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam25(V self, V *args) {
  V v_x_24199 = args[0];
  V v_x_24191 = heff_env(self)[0];
  V v_xsp_24192 = heff_env(self)[1];
  V v_p2_24195 = heff_env(self)[2];
  V v_k_24198 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24200 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatAs, 3, (V[]){v_x_24191, v_xsp_24192, v_x_24199}), v_p2_24195});
  V f_ = v_k_24198;
  args[0] = v_t_24200;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eopPat_lam24(V self, V *args) {
  V v_hd_24197 = args[0];
  V v_k_24198 = args[1];
  V v_c_24196 = heff_env(self)[0];
  V v_x_24191 = heff_env(self)[1];
  V v_xsp_24192 = heff_env(self)[2];
  V v_p2_24195 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24196;
  args[0] = v_hd_24197;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eopPat_lam25, 1, 4, (V[]){v_x_24191, v_xsp_24192, v_p2_24195, v_k_24198});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_x_241)) {
    case TAG_At: {
      V v_x11_243 = heff_field(v_x_241, 0);
      switch (heff_tag_of(v_x11_243)) {
      case TAG_MkAlt: {
        V v_p_245 = heff_field(v_x11_243, 0);
        V v_t_247 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(heff_dup(v_p_245)));
        v_t_248 = (g_heff_2eelab_2etoplevel_2eflatPat(v_t_247));
        break;
      }
      default: heff_nomatch(v_x11_243);
      }
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2etoplevel_2eallL_24s1817181561x499983731(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str6, 0, "");
Clo g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(V v_sp_240, V v_c_241) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009), v_sp_240, v_c_241, ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str0), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str1), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str2), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str3), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str4), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str5), ((V)&g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_str6)));
}
V g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str5, 0, "");
Clo g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(V v_sp_240, V v_x3_241, V v_cs_242) {
top: ;
  return (g_heff_2eelab_2etoplevel_2elazyInf_24s1362334744x5848009_24cycle(NTAG(TAG_Enter_24heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str0), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str1), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str2), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str3), ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str4), v_sp_240, v_x3_241, v_cs_242, ((V)&g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_str5)));
}
V g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2etupleInf_24s853332908x1259947422(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam3(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(V v_i_240) {
top: ;
  V v_t_2436;
  switch (heff_tag_of(v_i_240)) {
  case TAG_At: {
    V v_x11_241 = heff_dup(heff_field(v_i_240, 0));
    switch (heff_tag_of(v_x11_241)) {
    case TAG_IVar: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_241, 0ULL, 2);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_241, 0ULL, 3);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_INominal: {
      V v_i_2427 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        v_t_2436 = v_i_2427;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_241, 0ULL, 4);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_241, 0ULL, 1);
      v_t_2436 = heff_dup(v_i_240);
      break;
    }
    default: heff_nomatch(v_x11_241);
    }
    break;
  }
  default: heff_nomatch(v_i_240);
  }
  V v_t_2470;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_At: {
    V v_x11_2437 = heff_field(v_t_2436, 0);
    heff_take_n(v_t_2436, 1ULL, 2);
    switch (heff_tag_of(v_x11_2437)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInt: {
      V v_k_2440 = heff_field(v_x11_2437, 0);
      V v_ru_24x11_2437_24IInt = heff_take_reuse_n(v_x11_2437, 1ULL, 1);
      v_t_2470 = heff_tag_at_n(v_ru_24x11_2437_24IInt, TAG_Just, 1, (V[]){heff_tag_n(TAG_IntNum, 1, (V[]){v_k_2440})});
      break;
    }
    case TAG_IFloat: {
      V v_x_2441 = heff_field(v_x11_2437, 0);
      V v_ru_24x11_2437_24IFloat = heff_take_reuse_n(v_x11_2437, 1ULL, 1);
      v_t_2470 = heff_tag_at_n(v_ru_24x11_2437_24IFloat, TAG_Just, 1, (V[]){heff_tag_n(TAG_FracNum, 1, (V[]){v_x_2441})});
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2437, 0ULL, 2);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2437, 0ULL, 2);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2437, 0ULL, 4);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2437, 0ULL, 2);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2437, 0ULL, 4);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2437, 0ULL, 3);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_INominal: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2437, 0ULL, 4);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_2437, 0ULL, 1);
      v_t_2470 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2437);
    }
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  switch (heff_tag_of(v_t_2470)) {
  case TAG_Nothing: {
    V v_c_2471 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(heff_dup(v_i_240)));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0, 2, 2, (V[]){v_c_2471, v_i_240});
  }
  case TAG_Just: {
    V v_lit_24149 = heff_field(v_t_2470, 0);
    V v_ru_24t_2470_24Just = heff_take_reuse_n(v_t_2470, 1ULL, 1);
    V v_t_24183;
    switch (heff_tag_of(v_i_240)) {
    case TAG_At: {
      V v_x11_24150 = heff_dup(heff_field(v_i_240, 0));
      switch (heff_tag_of(v_x11_24150)) {
      case TAG_IVar: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IInt: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IFloat: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IString: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IBytes: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IPrim: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IRune: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IApp: {
        heff_take_n(v_x11_24150, 0ULL, 2);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnn: {
        heff_take_n(v_x11_24150, 0ULL, 2);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_ISpec: {
        heff_take_n(v_x11_24150, 0ULL, 4);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IUpdate: {
        heff_take_n(v_x11_24150, 0ULL, 2);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IAnnLam: {
        heff_take_n(v_x11_24150, 0ULL, 4);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_IInvalid: {
        heff_take_n(v_x11_24150, 0ULL, 3);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_INominal: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_True);
        break;
      }
      case TAG_ILitEq: {
        heff_take_n(v_x11_24150, 0ULL, 4);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_ILazy: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      case TAG_ITuple: {
        heff_take_n(v_x11_24150, 0ULL, 1);
        v_t_24183 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x11_24150);
      }
      break;
    }
    default: heff_nomatch(v_i_240);
    }
    V v_t_24191;
    if ((heff_dup(v_t_24183) == NTAG(TAG_True))) {
      heff_drop(v_t_24183);
      V v_t_24186;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_24185 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_24186 = v_s_24185;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      V v_t_24187 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24186, v_lit_24149));
      v_t_24191 = ({ V a_0 = v_t_24187; V r_ = (g_heff_2eelab_2etoplevel_2enominalChk(a_0)); heff_drop(v_t_24187); r_; });
    } else {
      heff_drop(v_t_24183);
      V v_t_24190;
      switch (heff_tag_of(v_i_240)) {
      case TAG_At: {
        V v_s_24189 = heff_field(v_i_240, 1);
        heff_take_n(v_i_240, 2ULL, 2);
        v_t_24190 = v_s_24189;
        break;
      }
      default: heff_nomatch(v_i_240);
      }
      v_t_24191 = (g_heff_2eelab_2erules_2enumLitChk(v_t_24190, v_lit_24149));
    }
    V v_x_24192 = ({ V a_0 = v_ru_24t_2470_24Just; V a_1 = v_t_24191; V r_ = (g_heff_2eelab_2erules_2eimplicitLams_24tok1(a_0, a_1)); heff_drop(v_t_24191); r_; });
    return heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam3, 2, 1, (V[]){v_x_24192});
  }
  default: return heff_nomatch(v_t_2470);
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116(a[0]);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2(V self, V *args) {
  V v_e_24126 = args[0];
  V v_a_24127 = args[1];
  V v_x_24121 = heff_env(self)[0];
  V v_c_24125 = heff_env(self)[1];
  V v_sp_24120 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24128 = heff_get_n(heff_dup(heff_rfield(v_e_24126, 0)), 1, 5);
  V v_t_24129 = heff_get_n(heff_dup(heff_rfield(v_e_24126, 0)), 3, 5);
  V v_t_24130 = heff_get_n(heff_dup(heff_rfield(v_e_24126, 0)), 2, 5);
  HeffT2 v_t_24131 = ({ V a_0 = v_x_24121; V a_1 = v_t_24128; V a_2 = v_t_24129; V a_3 = v_t_24130; V a_4 = MK_INT(0LL); V a_5 = MK_INT(0LL); HeffT2 r_ = (g_heff_2eelab_2erules_2evarGo_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_x_24121); heff_drop(v_t_24129); r_; });
  {
    V v_field_24133 = v_t_24131.f[1];
    int64_t v_tag_24132 = ((int64_t)v_t_24131.f[0]);
    if ((v_tag_24132 == ((int64_t)0ULL))) {
      V v_it1_24134 = v_field_24133;
      switch (heff_tag_of(v_it1_24134)) {
      case TAG_NotInScope: {
        heff_drop(v_sp_24120);
        switch (heff_tag_of(v_c_24125)) {
        case TAG_MkChk: {
          V v_f_24135 = heff_field(v_c_24125, 0);
          heff_take_n(v_c_24125, 1ULL, 1);
          V f_ = v_f_24135;
          args[0] = v_e_24126;
          args[1] = v_a_24127;
          if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 2, args);
        }
        default: return heff_nomatch(v_c_24125);
        }
      }
      case TAG_Delayed2: {
        V v_x1_24136 = (g_heff_2eelab_2evalue_2elevelOf(v_a_24127));
        switch (heff_tag_of(v_x1_24136)) {
        case TAG_Small: {
          HeffT1 v_t_24137 = (g_heff_2eelab_2erules_2erecChk_24cpr(v_sp_24120, v_c_24125));
          {
            V v_field_24138 = v_t_24137.f[0];
            V v_f_24139 = v_field_24138;
            V f_ = v_f_24139;
            args[0] = v_e_24126;
            args[1] = v_a_24127;
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
        }
        case TAG_Large: {
          heff_drop(v_sp_24120);
          switch (heff_tag_of(v_c_24125)) {
          case TAG_MkChk: {
            V v_f_24140 = heff_field(v_c_24125, 0);
            heff_take_n(v_c_24125, 1ULL, 1);
            V f_ = v_f_24140;
            args[0] = v_e_24126;
            args[1] = v_a_24127;
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
          default: return heff_nomatch(v_c_24125);
          }
        }
        case TAG_TopL: {
          heff_drop(v_sp_24120);
          switch (heff_tag_of(v_c_24125)) {
          case TAG_MkChk: {
            V v_f_24141 = heff_field(v_c_24125, 0);
            heff_take_n(v_c_24125, 1ULL, 1);
            V f_ = v_f_24141;
            args[0] = v_e_24126;
            args[1] = v_a_24127;
            if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 2, args);
          }
          default: return heff_nomatch(v_c_24125);
          }
        }
        default: return heff_nomatch(v_x1_24136);
        }
      }
      default: return heff_nomatch(v_it1_24134);
      }
    } else {
      heff_drop(v_sp_24120);
      V v_x_24142 = v_field_24133;
      heff_drop(v_x_24142);
      switch (heff_tag_of(v_c_24125)) {
      case TAG_MkChk: {
        V v_f_24143 = heff_field(v_c_24125, 0);
        heff_take_n(v_c_24125, 1ULL, 1);
        V f_ = v_f_24143;
        args[0] = v_e_24126;
        args[1] = v_a_24127;
        if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 2, args);
      }
      default: return heff_nomatch(v_c_24125);
      }
    }
  }
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1(V self, V *args) {
  V v_x_2474 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_2473 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_n_2475 = v_i_240;
  V v_j_2476 = v_x_2474;
  V v_t_24112;
  switch (heff_tag_of(v_n_2475)) {
  case TAG_At: {
    V v_x11_2477 = heff_dup(heff_field(v_n_2475, 0));
    switch (heff_tag_of(v_x11_2477)) {
    case TAG_IVar: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IInt: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IFloat: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IString: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IBytes: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IPrim: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IRune: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IApp: {
      heff_take_n(v_x11_2477, 0ULL, 2);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IAnn: {
      heff_take_n(v_x11_2477, 0ULL, 2);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_ISpec: {
      heff_take_n(v_x11_2477, 0ULL, 4);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IUpdate: {
      heff_take_n(v_x11_2477, 0ULL, 2);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IAnnLam: {
      heff_take_n(v_x11_2477, 0ULL, 4);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_IInvalid: {
      heff_take_n(v_x11_2477, 0ULL, 3);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_INominal: {
      V v_i_24103 = heff_field(v_x11_2477, 0);
      heff_take_n(v_x11_2477, 1ULL, 1);
      switch (heff_tag_of(v_n_2475)) {
      case TAG_At: {
        v_t_24112 = v_i_24103;
        break;
      }
      default: heff_nomatch(v_n_2475);
      }
      break;
    }
    case TAG_ILitEq: {
      heff_take_n(v_x11_2477, 0ULL, 4);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_ILazy: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    case TAG_ITuple: {
      heff_take_n(v_x11_2477, 0ULL, 1);
      v_t_24112 = heff_dup(v_n_2475);
      break;
    }
    default: heff_nomatch(v_x11_2477);
    }
    break;
  }
  default: heff_nomatch(v_n_2475);
  }
  V v_t_24113 = (g_heff_2esyntax_2epresyntax_2einfSpineOf(v_t_24112));
  V v_t_24114 = heff_get_n(v_t_24113, 0, 2);
  V v_t_24147;
  switch (heff_tag_of(v_t_24114)) {
  case TAG_At: {
    V v_it1_24115 = heff_field(v_t_24114, 0);
    heff_take_n(v_t_24114, 1ULL, 2);
    switch (heff_tag_of(v_it1_24115)) {
    case TAG_IVar: {
      V v_x_24117 = heff_field(v_it1_24115, 0);
      V v_ru_24it1_24115_24IVar = heff_take_reuse_n(v_it1_24115, 1ULL, 1);
      V v_sp_24120;
      switch (heff_tag_of(v_n_2475)) {
      case TAG_At: {
        V v_s_24119 = heff_dup(heff_field(v_n_2475, 1));
        v_sp_24120 = v_s_24119;
        break;
      }
      default: heff_nomatch(v_n_2475);
      }
      V v_x_24121 = v_x_24117;
      V v_t_24124;
      switch (heff_tag_of(v_n_2475)) {
      case TAG_At: {
        V v_s_24123 = heff_field(v_n_2475, 1);
        heff_take_n(v_n_2475, 2ULL, 2);
        v_t_24124 = v_s_24123;
        break;
      }
      default: heff_nomatch(v_n_2475);
      }
      V v_c_24125 = ({ V a_0 = v_t_24124; V a_1 = v_j_2476; V r_ = (g_heff_2eelab_2erules_2eapply(a_0, a_1)); heff_drop(v_j_2476); r_; });
      v_t_24147 = heff_tag_at_n(v_ru_24it1_24115_24IVar, TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam2, 2, 3, (V[]){v_x_24121, v_c_24125, v_sp_24120})});
      break;
    }
    default: {
      heff_drop(v_it1_24115);
      V v_t_24146;
      switch (heff_tag_of(v_n_2475)) {
      case TAG_At: {
        V v_s_24145 = heff_field(v_n_2475, 1);
        heff_take_n(v_n_2475, 2ULL, 2);
        v_t_24146 = v_s_24145;
        break;
      }
      default: heff_nomatch(v_n_2475);
      }
      v_t_24147 = ({ V a_0 = v_t_24146; V a_1 = v_j_2476; V r_ = (g_heff_2eelab_2erules_2eapply(a_0, a_1)); heff_drop(v_j_2476); r_; });
      break;
    }
    }
    break;
  }
  default: heff_nomatch(v_t_24114);
  }
  V v_x_24148 = ({ V a_0 = v_t_24147; V r_ = (g_heff_2eelab_2erules_2eimplicitLams(a_0)); heff_drop(v_t_24147); r_; });
  V f_ = v_k_2473;
  args[0] = v_x_24148;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam0(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k_2473 = args[1];
  V v_c_2471 = heff_env(self)[0];
  V v_i_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2471;
  args[0] = v_hd_2472;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam1, 1, 2, (V[]){v_i_240, v_k_2473});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2echkInf_24s2098049844x1115378116_lam3(V self, V *args) {
  V v_hd_24193 = args[0];
  V v_k_24194 = args[1];
  V v_x_24192 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24193);
  V f_ = v_k_24194;
  args[0] = v_x_24192;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_str0, 2, "it");
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam4(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_entry, 4, 0};

V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600(V v_lit_240, V v_sp_241, V v_see_242, V v_scrutN_243) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_lit_240)) {
  case TAG_At: {
    V v_x11_244 = heff_dup(heff_field(v_lit_240, 0));
    switch (heff_tag_of(v_x11_244)) {
    case TAG_MkAlt: {
      V v_p_246 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 2);
      V v_t_248 = (g_heff_2esyntax_2epresyntax_2epatSpineOf(v_p_246));
      v_t_249 = (g_heff_2eelab_2etoplevel_2eflatPat(v_t_248));
      break;
    }
    default: heff_nomatch(v_x11_244);
    }
    break;
  }
  default: heff_nomatch(v_lit_240);
  }
  if (((heff_dup(v_t_249) == NTAG(TAG_True)) && ({ V v_c_2481 = (g_heff_2eelab_2etoplevel_2eannotatesData(v_scrutN_243)); int c_ = !(heff_dup(v_c_2481) == NTAG(TAG_True)); heff_drop(v_c_2481); c_; }))) {
    heff_drop(v_t_249);
    V v_t_2414;
    switch (heff_tag_of(v_lit_240)) {
    case TAG_At: {
      V v_x111_2410 = heff_dup(heff_field(v_lit_240, 0));
      switch (heff_tag_of(v_x111_2410)) {
      case TAG_MkAlt: {
        V v_p_2412 = heff_field(v_x111_2410, 0);
        V v_ru_24x111_2410_24MkAlt = heff_take_reuse_n(v_x111_2410, 1ULL, 2);
        v_t_2414 = (g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(v_ru_24x111_2410_24MkAlt, v_p_2412, NTAG(TAG_Nil)));
        break;
      }
      default: heff_nomatch(v_x111_2410);
      }
      break;
    }
    default: heff_nomatch(v_lit_240);
    }
    V v_t_2415 = (g_heff_2eelab_2etoplevel_2enamedTwice(NTAG(TAG_Nil), v_t_2414));
    return heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam0, 2, 5, (V[]){v_t_2415, v_scrutN_243, v_lit_240, v_see_242, v_sp_241});
  } else {
    heff_drop(v_t_249);
    switch (heff_tag_of(v_lit_240)) {
    case TAG_At: {
      V v_a_2443 = heff_dup(heff_field(v_lit_240, 0));
      switch (heff_tag_of(v_a_2443)) {
      case TAG_MkAlt: {
        V v_a_2445 = heff_field(v_a_2443, 0);
        V v_a_2446 = heff_field(v_a_2443, 1);
        V v_ru_24a_2443_24MkAlt = heff_take_reuse_n(v_a_2443, 3ULL, 2);
        HeffT2 v_t_2447 = (g_heff_2eelab_2eclauses_2epat_24cpr(v_a_2445));
        {
          V v_field_2449 = v_t_2447.f[1];
          int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
          if ((v_tag_2448 == ((int64_t)0ULL))) {
            heff_drop_tag(v_lit_240, 2);
            heff_drop(v_sp_241);
            heff_drop(v_a_2446);
            heff_drop_cell(v_ru_24a_2443_24MkAlt, 2);
            V v_a_2450 = v_field_2449;
            V v_span_2451 = heff_take_field(v_a_2450, 0);
            V v_msg_2452 = heff_get_n(v_a_2450, 1, 2);
            HEFF_LAST return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(v_see_242, v_scrutN_243, v_span_2451, v_msg_2452);
          } else {
            V v_a_2453 = v_field_2449;
            V v_acc_2454 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_a_2446), NTAG(TAG_Nil)));
            V v_acc_2455 = (g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(v_acc_2454, heff_dup(v_a_2453)));
            V v_t_2456 = heff_tag_at_n(v_ru_24a_2443_24MkAlt, TAG_Cons, 2, (V[]){v_a_2453, NTAG(TAG_Nil)});
            V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_t_2456, v_a_2446}), NTAG(TAG_Nil)});
            V v_t_2458 = (g_heff_2eelab_2eclauses_2efresh(v_acc_2455, ((V)&g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_str0)));
            HeffT2 v_t_2459 = (g_heff_2eelab_2eclauses_2ecaseTreeOf_24cpr(v_sp_241, v_t_2457, v_acc_2455, v_t_2458));
            {
              V v_field_2461 = v_t_2459.f[1];
              int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
              if ((v_tag_2460 == ((int64_t)0ULL))) {
                heff_drop_tag(v_lit_240, 2);
                V v_err_2462 = v_field_2461;
                V v_span_2463 = heff_take_field(v_err_2462, 0);
                V v_msg_2464 = heff_get_n(v_err_2462, 1, 2);
                HEFF_LAST return g_heff_2eelab_2etoplevel_2etreeFailed_24s245224179x1927967923(v_see_242, v_scrutN_243, v_span_2463, v_msg_2464);
              } else {
                V v_r_2465 = v_field_2461;
                V v_tree_2466 = heff_take_field(v_r_2465, 1);
                V v_scrutinee_2467 = heff_get_n(v_r_2465, 0, 2);
                V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_240, NTAG(TAG_Nil)});
                V v_t_2469 = (g_heff_2eelab_2eclauses_2eunreachedAlts(v_t_2468));
                V v_t_2470 = (g_list_2emap_24s839307021x1449425912(v_t_2469));
                return heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam4, 2, 5, (V[]){v_t_2470, v_scrutN_243, v_tree_2466, v_see_242, v_scrutinee_2467});
              }
            }
          }
        }
      }
      default: return heff_nomatch(v_a_2443);
      }
    }
    default: return heff_nomatch(v_lit_240);
    }
  }
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam3(V self, V *args) {
  V v_a_2422 = args[0];
  V v_see_242 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2424;
  switch (heff_tag_of(v_see_242)) {
  case TAG_Nothing: {
    v_t_2424 = v_x_2420;
    break;
  }
  case TAG_Just: {
    V v_see_2423 = heff_field(v_see_242, 0);
    heff_take_n(v_see_242, 1ULL, 1);
    v_t_2424 = heff_tr(heff_call(v_see_2423, 1, (V[]){v_x_2420}));
    break;
  }
  default: heff_nomatch(v_see_242);
  }
  V v_t_2429;
  switch (heff_tag_of(v_lit_240)) {
  case TAG_At: {
    V v_x111_2425 = heff_field(v_lit_240, 0);
    V v_ru_24lit_240_24At = heff_take_reuse_n(v_lit_240, 1ULL, 2);
    switch (heff_tag_of(v_x111_2425)) {
    case TAG_MkAlt: {
      V v_p_2427 = heff_field(v_x111_2425, 0);
      heff_take_n(v_x111_2425, 1ULL, 2);
      v_t_2429 = (g_heff_2eelab_2etoplevel_2etagSpanOf_24tok2(v_ru_24lit_240_24At, v_p_2427, NTAG(TAG_Nil)));
      break;
    }
    default: heff_nomatch(v_x111_2425);
    }
    break;
  }
  default: heff_nomatch(v_lit_240);
  }
  V v_t_2432;
  switch (heff_tag_of(v_a_2422)) {
  case TAG_MkPair: {
    V v_x_2430 = heff_dup(heff_field(v_a_2422, 0));
    v_t_2432 = v_x_2430;
    break;
  }
  default: heff_nomatch(v_a_2422);
  }
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
  V v_t_2436;
  switch (heff_tag_of(v_a_2422)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_dup(heff_field(v_a_2422, 0));
    v_t_2436 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), v_x_2434, MK_INT(0LL)));
    break;
  }
  default: heff_nomatch(v_a_2422);
  }
  V v_t_2439;
  switch (heff_tag_of(v_a_2422)) {
  case TAG_MkPair: {
    V v_y_2438 = heff_field(v_a_2422, 1);
    heff_take_n(v_a_2422, 2ULL, 2);
    v_t_2439 = v_y_2438;
    break;
  }
  default: heff_nomatch(v_a_2422);
  }
  V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
  V v_t_2441 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2433), v_t_2436, heff_arrayFromList(v_t_2440)});
  V v_x_2442 = ({ V a_0 = v_sp_241; V a_1 = v_t_2424; V a_2 = v_t_2429; V a_3 = v_t_2441; V r_ = (g_heff_2eelab_2erules_2esumElim(a_0, a_1, a_2, a_3)); heff_drop(v_t_2424); heff_drop(v_t_2429); r_; });
  V f_ = v_k_2417;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_see_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  V v_k_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_a_2421 = (g_heff_2eelab_2etoplevel_2edoCase_24s817603690x1754264990(heff_dup(v_lit_240)));
  V f_ = v_a_2421;
  heff_room[0] = v_hd_2416;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam3, 1, 5, (V[]){v_see_242, v_x_2420, v_lit_240, v_sp_241, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_scrutN_243 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_see_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_k_2417 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2418);
  V v_c_2419 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_243));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_2416);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam2, 1, 5, (V[]){v_lit_240, v_hd_2416, v_see_242, v_sp_241, v_k_2417});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_t_2415 = heff_env(self)[0];
  V v_scrutN_243 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_see_242 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_2415, heff_dup(v_hd_2416), heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam1, 1, 6, (V[]){v_scrutN_243, v_hd_2416, v_lit_240, v_see_242, v_sp_241, v_k_2417})));
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam7(V self, V *args) {
  V v_x_2477 = args[0];
  V v_see_242 = heff_env(self)[0];
  V v_x_2475 = heff_env(self)[1];
  V v_scrutinee_2467 = heff_env(self)[2];
  V v_k_2472 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2479;
  switch (heff_tag_of(v_see_242)) {
  case TAG_Nothing: {
    v_t_2479 = v_x_2475;
    break;
  }
  case TAG_Just: {
    V v_see_2478 = heff_field(v_see_242, 0);
    heff_take_n(v_see_242, 1ULL, 1);
    v_t_2479 = heff_tr(heff_call(v_see_2478, 1, (V[]){v_x_2475}));
    break;
  }
  default: heff_nomatch(v_see_242);
  }
  V v_x_2480 = ({ V a_0 = v_scrutinee_2467; V a_1 = v_t_2479; V a_2 = v_x_2477; V r_ = (g_heff_2eelab_2erules_2ecaseLet(a_0, a_1, a_2)); heff_drop(v_t_2479); heff_drop(v_x_2477); r_; });
  V f_ = v_k_2472;
  args[0] = v_x_2480;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam6(V self, V *args) {
  V v_x_2475 = args[0];
  V v_tree_2466 = heff_env(self)[0];
  V v_hd_2471 = heff_env(self)[1];
  V v_see_242 = heff_env(self)[2];
  V v_scrutinee_2467 = heff_env(self)[3];
  V v_k_2472 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2476 = (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_tree_2466));
  V f_ = v_c_2476;
  heff_room[0] = v_hd_2471;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam7, 1, 4, (V[]){v_see_242, v_x_2475, v_scrutinee_2467, v_k_2472});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam5(V self, V *args) {
  V v_x_2473 = args[0];
  V v_scrutN_243 = heff_env(self)[0];
  V v_hd_2471 = heff_env(self)[1];
  V v_tree_2466 = heff_env(self)[2];
  V v_see_242 = heff_env(self)[3];
  V v_scrutinee_2467 = heff_env(self)[4];
  V v_k_2472 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2473);
  V v_c_2474 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_scrutN_243));
  V f_ = v_c_2474;
  heff_room[0] = heff_dup(v_hd_2471);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam6, 1, 5, (V[]){v_tree_2466, v_hd_2471, v_see_242, v_scrutinee_2467, v_k_2472});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam4(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k_2472 = args[1];
  V v_t_2470 = heff_env(self)[0];
  V v_scrutN_243 = heff_env(self)[1];
  V v_tree_2466 = heff_env(self)[2];
  V v_see_242 = heff_env(self)[3];
  V v_scrutinee_2467 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2eenvironment_2eseeArms(v_t_2470, heff_dup(v_hd_2471), heff_clo_n(g_heff_2eelab_2etoplevel_2ematchF_24s947648025x810826600_lam5, 1, 6, (V[]){v_scrutN_243, v_hd_2471, v_tree_2466, v_see_242, v_scrutinee_2467, v_k_2472})));
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3, 40, "unexpected notation for local definition");
HEFF_LIT(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4, 40, "unexpected notation for local definition");
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam10(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam12(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam11(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam13(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam14(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam15(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam16(V self, V *args);
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam17(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(V v_x2_240, V v_body_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return (g_heff_2eelab_2etoplevel_2echkF_24s1508119325x2082740539(v_body_241));
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x2_240, 0);
    V v_ds_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_d_242)) {
    case TAG_At: {
      V v_x_244 = heff_dup(heff_field(v_d_242, 0));
      v_t_246 = v_x_244;
      break;
    }
    default: heff_nomatch(v_d_242);
    }
    switch (heff_tag_of(v_t_246)) {
    case TAG_DeclEquations: {
      V v_name_247 = heff_field(v_t_246, 0);
      V v_tyN_2410 = heff_field(v_t_246, 3);
      V v_eqs_2411 = heff_field(v_t_246, 4);
      heff_take_n(v_t_246, 25ULL, 5);
      V v_c_2412 = (g_heff_2eelab_2etoplevel_2etypF_24s367360841x1751839251(v_tyN_2410));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0, 2, 6, (V[]){v_c_2412, v_name_247, v_eqs_2411, v_d_242, v_ds_243, v_body_241});
    }
    case TAG_DeclDefine: {
      heff_take_n(v_t_246, 0ULL, 5);
      heff_drop(v_body_241);
      heff_drop(v_ds_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam13, 2, 1, (V[]){v_d_242});
    }
    case TAG_DeclTheory: {
      heff_take_n(v_t_246, 0ULL, 4);
      heff_drop(v_body_241);
      heff_drop(v_ds_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam14, 2, 1, (V[]){v_d_242});
    }
    case TAG_DeclPrimitive: {
      heff_take_n(v_t_246, 0ULL, 3);
      heff_drop(v_body_241);
      heff_drop(v_ds_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam15, 2, 1, (V[]){v_d_242});
    }
    case TAG_DeclTest: {
      heff_take_n(v_t_246, 0ULL, 2);
      heff_drop(v_body_241);
      heff_drop(v_ds_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam16, 2, 1, (V[]){v_d_242});
    }
    case TAG_DeclWatch: {
      heff_take_n(v_t_246, 0ULL, 1);
      heff_drop(v_body_241);
      heff_drop(v_ds_243);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam17, 2, 1, (V[]){v_d_242});
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(a[0], a[1]);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5(V self, V *args) {
  V v_m_2433 = args[0];
  V v_e_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2etoplevel_2eopPat(heff_get_n(v_e_2424, 1, 6), v_m_2433));
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7(V self, V *args) {
  V v_x_2437 = args[0];
  V v_f_2429 = heff_env(self)[0];
  V v_fsp_2430 = heff_env(self)[1];
  V v_rhs_2432 = heff_env(self)[2];
  V v_sp_2428 = heff_env(self)[3];
  V v_k_2436 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkEquation, 4, (V[]){v_f_2429, v_fsp_2430, v_x_2437, v_rhs_2432}), v_sp_2428});
  V f_ = v_k_2436;
  args[0] = v_t_2438;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_f_2429 = heff_env(self)[1];
  V v_fsp_2430 = heff_env(self)[2];
  V v_rhs_2432 = heff_env(self)[3];
  V v_sp_2428 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2434;
  args[0] = v_hd_2435;
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam7, 1, 5, (V[]){v_f_2429, v_fsp_2430, v_rhs_2432, v_sp_2428, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4(V self, V *args) {
  V v_m_2426 = args[0];
  V v_e_2424 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_m_2426)) {
  case TAG_At: {
    V v_x21_2427 = heff_field(v_m_2426, 0);
    V v_sp_2428 = heff_field(v_m_2426, 1);
    heff_take_n(v_m_2426, 3ULL, 2);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_MkEquation: {
      V v_f_2429 = heff_field(v_x21_2427, 0);
      V v_fsp_2430 = heff_field(v_x21_2427, 1);
      V v_ps_2431 = heff_field(v_x21_2427, 2);
      V v_rhs_2432 = heff_field(v_x21_2427, 3);
      heff_take_n(v_x21_2427, 15ULL, 4);
      V v_c_2434 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam5, 1, 1, (V[]){v_e_2424}), v_ps_2431));
      return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam6, 2, 5, (V[]){v_c_2434, v_f_2429, v_fsp_2430, v_rhs_2432, v_sp_2428});
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  default: return heff_nomatch(v_m_2426);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_e_2424 = heff_env(self)[0];
  V v_a_2425 = heff_env(self)[1];
  V v_hd_2440 = heff_env(self)[2];
  V v_k_2441 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2444)) {
  case TAG_MkChk: {
    V v_f_2445 = heff_field(v_x_2444, 0);
    heff_take_n(v_x_2444, 1ULL, 1);
    V f_ = v_f_2445;
    heff_room[0] = v_e_2424;
    heff_room[1] = v_a_2425;
    heff_room[2] = v_hd_2440;
    heff_room[3] = v_k_2441;
    if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
  }
  default: return heff_nomatch(v_x_2444);
  }
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam9(V self, V *args) {
  V v_x_2442 = args[0];
  V v_f_2416 = heff_env(self)[0];
  V v_sp_2420 = heff_env(self)[1];
  V v_hd_2440 = heff_env(self)[2];
  V v_e_2424 = heff_env(self)[3];
  V v_a_2425 = heff_env(self)[4];
  V v_k_2441 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2443 = (g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(v_f_2416, v_x_2442, v_sp_2420));
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_hd_2440);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam10, 1, 4, (V[]){v_e_2424, v_a_2425, v_hd_2440, v_k_2441});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_c_2439 = heff_env(self)[0];
  V v_f_2416 = heff_env(self)[1];
  V v_sp_2420 = heff_env(self)[2];
  V v_e_2424 = heff_env(self)[3];
  V v_a_2425 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2439;
  args[0] = heff_dup(v_hd_2440);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam9, 1, 6, (V[]){v_f_2416, v_sp_2420, v_hd_2440, v_e_2424, v_a_2425, v_k_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3(V self, V *args) {
  V v_e_2424 = args[0];
  V v_a_2425 = args[1];
  V v_eqs_2417 = heff_env(self)[0];
  V v_f_2416 = heff_env(self)[1];
  V v_sp_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_2439 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam4, 1, 1, (V[]){heff_dup(v_e_2424)}), v_eqs_2417));
  return heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam8, 2, 5, (V[]){v_c_2439, v_f_2416, v_sp_2420, v_e_2424, v_a_2425});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_eqs_2417 = heff_env(self)[0];
  V v_f_2416 = heff_env(self)[1];
  V v_sp_2420 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam3, 2, 3, (V[]){v_eqs_2417, v_f_2416, v_sp_2420})});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam12(V self, V *args) {
  V v_x_2449 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_x_2447 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2450 = ({ V a_0 = v_name_247; V a_1 = v_x_2415; V a_2 = v_x_2447; V a_3 = v_x_2449; V r_ = (g_heff_2eelab_2erules_2elocalDef(a_0, a_1, a_2, a_3)); heff_drop(v_x_2415); heff_drop(v_x_2447); heff_drop(v_x_2449); r_; });
  V f_ = v_k_2414;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam11(V self, V *args) {
  V v_x_2447 = args[0];
  V v_ds_243 = heff_env(self)[0];
  V v_body_241 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_name_247 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_k_2414 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2448 = (g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637(v_ds_243, v_body_241));
  V f_ = v_c_2448;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam12, 1, 4, (V[]){v_name_247, v_x_2415, v_x_2447, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_name_247 = heff_env(self)[0];
  V v_eqs_2411 = heff_env(self)[1];
  V v_d_242 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_f_2416 = heff_dup(v_name_247);
  V v_eqs_2417 = v_eqs_2411;
  V v_sp_2420;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2419 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_sp_2420 = v_s_2419;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_x1_2421 = (g_heff_2eelab_2etoplevel_2eallL_24s1215757489x67849123(v_eqs_2417));
  V v_c_2446;
  if (!(heff_dup(v_x1_2421) == NTAG(TAG_True))) {
    heff_drop(v_x1_2421);
    v_c_2446 = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam2, 2, 3, (V[]){v_eqs_2417, v_f_2416, v_sp_2420});
  } else {
    heff_drop(v_x1_2421);
    v_c_2446 = (g_heff_2eelab_2etoplevel_2elocalEqs_24s1862974039x902338288(v_f_2416, v_eqs_2417, v_sp_2420));
  }
  V f_ = v_c_2446;
  heff_room[0] = heff_dup(v_hd_2413);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam11, 1, 6, (V[]){v_ds_243, v_body_241, v_hd_2413, v_name_247, v_x_2415, v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_name_247 = heff_env(self)[1];
  V v_eqs_2411 = heff_env(self)[2];
  V v_d_242 = heff_env(self)[3];
  V v_ds_243 = heff_env(self)[4];
  V v_body_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam1, 1, 7, (V[]){v_name_247, v_eqs_2411, v_d_242, v_hd_2413, v_ds_243, v_body_241, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam13(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k2_2457 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2458 = heff_take_field(v_hd_2456, 1);
  V v_malg_2459 = heff_get_n(v_hd_2456, 2, 3);
  V v_t_2462;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2461 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2462 = v_s_2461;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2463 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str0), v_t_2462, NTAG(TAG_Nothing)});
  V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tr(heff_call(v_malg_2459, 1, (V[]){v_t_2465}));
  V f_ = v_bind_2458;
  args[0] = v_t_2466;
  args[1] = v_k2_2457;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam14(V self, V *args) {
  V v_hd_2471 = args[0];
  V v_k2_2472 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2473 = heff_take_field(v_hd_2471, 1);
  V v_malg_2474 = heff_get_n(v_hd_2471, 2, 3);
  V v_t_2477;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2476 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2477 = v_s_2476;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2478 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str1), v_t_2477, NTAG(TAG_Nothing)});
  V v_t_2479 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tr(heff_call(v_malg_2474, 1, (V[]){v_t_2480}));
  V f_ = v_bind_2473;
  args[0] = v_t_2481;
  args[1] = v_k2_2472;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam15(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k2_2486 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2487 = heff_take_field(v_hd_2485, 1);
  V v_malg_2488 = heff_get_n(v_hd_2485, 2, 3);
  V v_t_2491;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_2490 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_2491 = v_s_2490;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_2492 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str2), v_t_2491, NTAG(TAG_Nothing)});
  V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tr(heff_call(v_malg_2488, 1, (V[]){v_t_2494}));
  V f_ = v_bind_2487;
  args[0] = v_t_2495;
  args[1] = v_k2_2486;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam16(V self, V *args) {
  V v_hd_2498 = args[0];
  V v_k2_2499 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24100 = heff_take_field(v_hd_2498, 1);
  V v_malg_24101 = heff_get_n(v_hd_2498, 2, 3);
  V v_t_24104;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_24103 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_24104 = v_s_24103;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_24105 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str3), v_t_24104, NTAG(TAG_Nothing)});
  V v_t_24106 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tr(heff_call(v_malg_24101, 1, (V[]){v_t_24107}));
  V f_ = v_bind_24100;
  args[0] = v_t_24108;
  args[1] = v_k2_2499;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_d_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_24112 = heff_take_field(v_hd_24110, 1);
  V v_malg_24113 = heff_get_n(v_hd_24110, 2, 3);
  V v_t_24116;
  switch (heff_tag_of(v_d_242)) {
  case TAG_At: {
    V v_s_24115 = heff_field(v_d_242, 1);
    heff_take_n(v_d_242, 2ULL, 2);
    v_t_24116 = v_s_24115;
    break;
  }
  default: heff_nomatch(v_d_242);
  }
  V v_t_24117 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(203LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2elocalsJ_24s16803500x1956300637_str4), v_t_24116, NTAG(TAG_Nothing)});
  V v_t_24118 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24117})});
  V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
  V v_t_24120 = heff_tr(heff_call(v_malg_24113, 1, (V[]){v_t_24119}));
  V f_ = v_bind_24112;
  args[0] = v_t_24120;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2etoplevel_2enubInt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2enubInt_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2enubInt(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2ekeepIf_24s512765522x2052101617(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2eelab_2etoplevel_2enubInt_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2etoplevel_2enubInt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2enubInt(a[0]);
}
Clo g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry, 1, 0};

V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_243;
    if (heff_intEq_c(heff_dup(heff_rfield(v_x_241, 0)), MK_INT(-1LL))) {
      heff_drop_rec(v_x_241, 5);
      heff_drop_cell(v_ru_24x2_240_24Cons, 2);
      v_t_243 = NTAG(TAG_Nil);
    } else {
      v_t_243 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
    }
    V v_t_244 = (g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(v_xs_242));
    return (g_heff_2eelab_2etoplevel_2eappendT(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2econcatMapT_24s821445327x1859155381(a[0]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0, 21, "errors recovered from");
Clo g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry, 2, 0};

V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(V v_k_240, V v_st_241) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_st_241)) {
  case TAG_MkSt: {
    V v_c_242 = heff_dup(heff_field(v_st_241, 0));
    v_t_245 = v_c_242;
    break;
  }
  default: heff_nomatch(v_st_241);
  }
  V v_t_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_t_245, 1, 9); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  if (heff_intEq_c(v_t_246, MK_INT(0LL))) {
    return heff_tail(v_k_240, 2, (V[]){NTAG(TAG_MkUnit), v_st_241});
  } else {
    heff_drop(v_k_240);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(-1LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_str0), heff_dup(g_heff_2eelab_2eparams_2enoSpan_get()), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_st_241});
  }
}
V g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_str0, 34, "the instance's implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_str1, 100, "` is not in what it is an instance of: a search, unifying that with the type wanted, cannot solve it");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_str2, 120, "use it in what the instance is an instance of (`{a : Type} -> {{e : Equality a}} -> Equality (List a)`), or leave it out");
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_entry, 5, 0};

V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529(V v_sp_240, V v_depth_241, V v_conclusion_242, V v_x4_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_sp_240);
    heff_drop(v_depth_241);
    heff_drop(v_conclusion_242);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_b_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_level_247 = heff_take_field(v_b_245, 1);
    V v_name_248 = heff_get_n(v_b_245, 0, 2);
    V v_t_249 = heff_intSub(heff_intSub(heff_dup(v_depth_241), MK_INT(1LL)), v_level_247);
    V v_t_2410 = (g_heff_2eelab_2erules_2ementionsLocal(v_t_249));
    V v_t_2411 = heff_tr(heff_call(heff_get_n(v_t_2410, 1, 3), 2, (V[]){MK_INT(0LL), heff_dup(v_conclusion_242)}));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_name_248);
      heff_drop(v_t_2411);
      V t_0 = v_sp_240;
      V t_1 = v_depth_241;
      V t_2 = v_conclusion_242;
      V t_3 = v_rest_246;
      V t_4 = v_p_244;
      v_sp_240 = t_0;
      v_depth_241 = t_1;
      v_conclusion_242 = t_2;
      v_x4_243 = t_3;
      v_p_244 = t_4;
      goto top;
    } else {
      heff_drop(v_depth_241);
      heff_drop(v_conclusion_242);
      heff_drop(v_p_244);
      heff_drop(v_rest_246);
      heff_drop(v_t_2411);
      return heff_clo_n(g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_lam0, 1, 2, (V[]){v_name_248, v_sp_240});
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_lam0(V self, V *args) {
  V v_st_2412 = args[0];
  V v_name_248 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_str0), v_name_248), ((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_str1));
  V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(350LL), NTAG(TAG_SError), v_t_2413, v_sp_240, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eeveryImplicitIn_24s834049110x556156529_str2)})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2414}), v_st_2412});
}
HEFF_LIT(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str0, 7, "> watch");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str1, 36, "cannot infer the implicit argument `");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str2, 21, "`; give it as `{...}`");
HEFF_LIT(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str3, 54, "a watch must say what type it has: write `>>> (e : T)`");
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam8(V self, V *args); static Clo g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam8, 1, 0};
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam9(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam7(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam6(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam5(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam4(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam3(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam2(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam1(V self, V *args);
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam0(V self, V *args);
Clo g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_entry, 3, 0};

V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(V v_g_240, V v_n_241, V v_z_242) {
top: ;
  V v_w_246;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n_243 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_244 = heff_dup(heff_field(v_n_241, 1));
    V v_t_245 = (g_heff_2esyntax_2epresyntax_2echkNode_24s1161586186x173729708(v_n_243));
    v_w_246 = heff_tag_n(TAG_At, 2, (V[]){v_t_245, v_sp_244});
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_p_2478 = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam0, 1, 2, (V[]){v_g_240, v_n_241});
  switch (heff_tag_of(v_w_246)) {
  case TAG_At: {
    V v_w1_2479 = heff_dup(heff_field(v_w_246, 0));
    switch (heff_tag_of(v_w1_2479)) {
    case TAG_CInf: {
      V v_i_2481 = heff_field(v_w1_2479, 0);
      heff_take_n(v_w1_2479, 1ULL, 1);
      switch (heff_tag_of(v_w_246)) {
      case TAG_At: {
        heff_take_n(v_w_246, 0ULL, 2);
        V v_t_2484 = (g_heff_2eelab_2etoplevel_2einfF_24s1215607005x1282782588(v_i_2481));
        return heff_tail(v_t_2484, 3, (V[]){heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), v_p_2478, v_z_242});
      }
      default: return heff_nomatch(v_w_246);
      }
    }
    default: {
      heff_drop_clo(v_p_2478, 2);
      heff_drop(v_w1_2479);
      V v_t_2487;
      switch (heff_tag_of(v_w_246)) {
      case TAG_At: {
        V v_s_2486 = heff_field(v_w_246, 1);
        heff_take_n(v_w_246, 2ULL, 2);
        v_t_2487 = v_s_2486;
        break;
      }
      default: heff_nomatch(v_w_246);
      }
      V v_t_2488 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(200LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str3), v_t_2487, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2488}), v_z_242});
    }
    }
  }
  default: return heff_nomatch(v_w_246);
  }
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435(a[0], a[1], a[2]);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam8(V self, V *args) {
  V v_c_2436 = args[0];
  return heff_get_n(v_c_2436, 3, 9);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam9(V self, V *args) {
  V v_x_2440 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_t_2416 = heff_env(self)[1];
  V v_ty_2417 = heff_env(self)[2];
  V v_k_2429 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_g_2441 = v_g_2411;
  V v_mc_2442 = v_x_2440;
  V v_t_2443 = v_t_2416;
  V v_ty_2444 = v_ty_2417;
  V v_t_2445 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_2442, v_ty_2444));
  V v_t_2446 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), v_t_2445));
  V v_t_2447 = (g_heff_2eelab_2eunify_2ezonker(v_mc_2442));
  V v_tyStx_2448 = heff_tr(heff_call(heff_get_n(v_t_2447, 1, 2), 1, (V[]){v_t_2446}));
  V v_t_2449 = ({ V a_0 = v_mc_2442; V r_ = (g_heff_2eelab_2eunify_2ezonker(a_0)); heff_drop(v_mc_2442); r_; });
  V v_bodyStx_2450 = heff_tr(heff_call(heff_get_n(v_t_2449, 0, 2), 1, (V[]){heff_get_n(v_t_2443, 0, 2)}));
  V v_t_2451 = (g_heff_2eelab_2etop_2evalueOf(heff_dup(v_g_2441), ((V)&g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str0), heff_dup(v_tyStx_2448), heff_dup(v_bodyStx_2450)));
  HeffT2 v_t_2452 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(v_g_2441, NTAG(TAG_N), heff_dup(v_tyStx_2448), NTAG(TAG_LNil)));
  V v_t_2458;
  {
    V v_field_2454 = v_t_2452.f[1];
    int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
    if ((v_tag_2453 == ((int64_t)0ULL))) {
      V v_x_2455 = v_field_2454;
      v_t_2458 = v_x_2455;
    } else {
      if ((v_tag_2453 == ((int64_t)1ULL))) {
        V v_x11_2456 = v_field_2454;
        heff_drop(v_x11_2456);
        v_t_2458 = heff_abandon();
      } else {
        V v_x_2457 = v_field_2454;
        v_t_2458 = v_x_2457;
      }
    }
  }
  V v_x_2459 = heff_rec_n(4, shape_syntax__tySyntax__value__type_5f, (V[]){v_bodyStx_2450, v_tyStx_2448, v_t_2451, v_t_2458});
  V f_ = v_k_2429;
  args[0] = v_x_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_hd_2428 = heff_env(self)[0];
  V v_g_2411 = heff_env(self)[1];
  V v_t_2416 = heff_env(self)[2];
  V v_ty_2417 = heff_env(self)[3];
  V v_k_2429 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2435);
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam8_clo)})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_2428, 2), 1, (V[]){v_t_2438}));
  V f_ = heff_get_n(v_hd_2428, 1, 3);
  heff_room[0] = v_t_2439;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam9, 1, 4, (V[]){v_g_2411, v_t_2416, v_ty_2417, v_k_2429});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam6(V self, V *args) {
  V v_unsolved_2427 = args[0];
  V v_hd_2428 = args[1];
  V v_k_2429 = args[2];
  V v_z_2430 = args[3];
  V v_g_2411 = heff_env(self)[0];
  V v_t_2416 = heff_env(self)[1];
  V v_ty_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x1_2431 = v_unsolved_2427;
  V v_p_2432 = heff_dup(v_hd_2428);
  V v_bind_2433 = heff_take_field(v_p_2432, 1);
  V v_malg_2434 = heff_get_n(v_p_2432, 2, 3);
  V v_p_2460 = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam7, 1, 5, (V[]){v_hd_2428, v_g_2411, v_t_2416, v_ty_2417, v_k_2429});
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nil: {
    heff_drop(v_bind_2433);
    heff_drop(v_malg_2434);
    V f_ = v_p_2460;
    args[0] = NTAG(TAG_MkUnit);
    args[1] = v_z_2430;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_u_2461 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 2);
    V v_name_2463 = heff_take_field(v_u_2461, 0);
    V v_span_2464 = heff_get_n(v_u_2461, 1, 2);
    V v_t_2465 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str1), v_name_2463), ((V)&g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_str2));
    V v_t_2466 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(328LL), NTAG(TAG_SError), v_t_2465, v_span_2464, NTAG(TAG_Nothing)});
    V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tr(heff_call(v_malg_2434, 1, (V[]){v_t_2468}));
    V f_ = v_bind_2433;
    args[0] = v_t_2469;
    args[1] = v_p_2460;
    args[2] = v_z_2430;
    if (heff_exact(f_, 3, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 3, args);
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_t_2416 = heff_env(self)[1];
  V v_ty_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V f_ = ((V)&g_co_2ebind_24s491334399x268717303_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam6, 4, 3, (V[]){v_g_2411, v_t_2416, v_ty_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_2422 = args[1];
  V v_g_2411 = heff_env(self)[0];
  V v_sp_2414 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_t_2416 = heff_env(self)[3];
  V v_ty_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2421);
  V v_g_2423 = heff_dup(v_g_2411);
  V v_sp_2424 = v_sp_2414;
  V v_x3_2425 = v_x_2418;
  V v_p_2470 = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam5, 1, 3, (V[]){v_g_2411, v_t_2416, v_ty_2417});
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Nil: {
    heff_drop(v_g_2423);
    heff_drop(v_sp_2424);
    V f_ = v_p_2470;
    args[0] = NTAG(TAG_MkUnit);
    args[1] = v_z_2422;
    if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 2, args);
  }
  case TAG_Cons: {
    V v_p_2471 = heff_field(v_x3_2425, 0);
    V v_ru_24x3_2425_24Cons = heff_take_reuse_n(v_x3_2425, 1ULL, 2);
    heff_drop_clo(v_p_2470, 3);
    V v_t_2476;
    switch (heff_tag_of(v_z_2422)) {
    case TAG_MkSt: {
      V v_c_2473 = heff_dup(heff_field(v_z_2422, 0));
      v_t_2476 = v_c_2473;
      break;
    }
    default: heff_nomatch(v_z_2422);
    }
    V v_x_2477 = ({ V a_0 = v_g_2423; V a_1 = v_sp_2424; V a_2 = v_p_2471; V b_3 = heff_get_n(v_t_2476, 3, 9); V r_ = (g_heff_2eelab_2etoplevel_2estuckAt(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
    return heff_tag_at_n(v_ru_24x3_2425_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_x_2477}), v_z_2422});
  }
  default: return heff_nomatch(v_x3_2425);
  }
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_z_2420 = args[1];
  V v_g_2411 = heff_env(self)[0];
  V v_sp_2414 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_t_2416 = heff_env(self)[3];
  V v_ty_2417 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2419);
  return (g_heff_2eelab_2etoplevel_2epoisonedLeft_24s1013608312x2032287267(heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam4, 2, 5, (V[]){v_g_2411, v_sp_2414, v_x_2418, v_t_2416, v_ty_2417}), v_z_2420));
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_2411 = heff_env(self)[0];
  V v_sp_2414 = heff_env(self)[1];
  V v_t_2416 = heff_env(self)[2];
  V v_ty_2417 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = ((V)&g_heff_2eelab_2etoplevel_2erecoveredCheck_24s2077936593x514551889_clo);
  args[0] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam3, 2, 5, (V[]){v_g_2411, v_sp_2414, v_x_2418, v_t_2416, v_ty_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_g_2411 = v_g_240;
  V v_sp_2414;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_s_2413 = heff_field(v_n_241, 1);
    heff_take_n(v_n_241, 2ULL, 2);
    v_sp_2414 = v_s_2413;
    break;
  }
  default: heff_nomatch(v_n_241);
  }
  V v_x3_2415 = v_x_2410;
  switch (heff_tag_of(v_x3_2415)) {
  case TAG_MkPair: {
    V v_t_2416 = heff_field(v_x3_2415, 0);
    V v_ty_2417 = heff_field(v_x3_2415, 1);
    heff_take_n(v_x3_2415, 3ULL, 2);
    return (g_heff_2eelab_2emeta_2esettleGo(heff_dup(v_g_2411), MK_INT(0LL), heff_dup(g_heff_2eelab_2emeta_2eelabH_get()), heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam2, 1, 4, (V[]){v_g_2411, v_sp_2414, v_t_2416, v_ty_2417})));
  }
  default: return heff_nomatch(v_x3_2415);
  }
}
V g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkSyn: {
    V v_f_248 = heff_field(v_x_247, 0);
    heff_take_n(v_x_247, 1ULL, 1);
    V v_t_249 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){heff_dup(g_heff_2eelab_2eenvironment_2eemptyScope_get()), heff_dup(v_g_240), NTAG(TAG_ForNominative), MK_INT(0LL), NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    V f_ = v_f_248;
    heff_room[0] = v_t_249;
    heff_room[1] = heff_dup(g_heff_2eelab_2emeta_2eelabH_get());
    heff_room[2] = heff_clo_n(g_heff_2eelab_2etoplevel_2eelabWatch_24s478298195x2052432435_lam1, 1, 2, (V[]){v_g_240, v_n_241});
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  }
  default: return heff_nomatch(v_x_247);
  }
}