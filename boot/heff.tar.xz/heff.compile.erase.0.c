// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EFix 37759
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936 63224
#define TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145 14377
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_supply 1056026650
#define LBL_ty 10476
#define LBL_tys 324872
#define LBL_values 1123329101
#define LBL_vars 10107635
#define LBL_vs 10532
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_vs__out__tys[] = {LBL_vs, LBL_out, LBL_tys};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2eargTysOf(V, V);
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eargTysOf_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V, V, V);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo;
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo;
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo;
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V, V);
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo;
V g_heff_2ecompile_2eerase_2eeraseOne(V, V, V);
V g_heff_2ecompile_2eerase_2eeraseOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseOne_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2eerase_2efieldTyOr(V, V, V, V);
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo;
HeffT2 g_heff_2ecompile_2eerase_2efieldTyOr_24cpr(V, V, V, V);
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2ematchVariants(V);
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ematchVariants_clo;
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2ecompile_2eerase_2ezipE_24dps(V, V, V);
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(V, V, V);
V g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eisType_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_245;
}
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str0, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str1, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str2, 14, "the type of `.");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str3, 36, "` depends on fields not in hand here");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str4, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str5, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str6, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str7, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str8, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str9, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str10, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str11, 54, "projecting from something that is not of a record type");
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam12, 1, 0};
Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2ecompile_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(heff_dup(v_t_241), v_fs_242, v_l_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_len_240);
      heff_drop(v_t_241);
      heff_drop(v_l_243);
      V v_ty_248 = v_field_246;
      return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam0, 1, 1, (V[]){v_ty_248});
    } else {
      heff_drop(v_field_246);
      V v_t_2410 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_2410, 0ULL, 4);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam2_clo);
      }
      case TAG_LikeRecord: {
        V v_capture_2419 = heff_field(v_t_2410, 1);
        V v_fieldTypes_2420 = heff_field(v_t_2410, 2);
        heff_take_n(v_t_2410, 6ULL, 3);
        HeffT2 v_t_2421 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_fieldTypes_2420, 1), v_l_243));
        V v_t_2426;
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_i_2425 = v_field_2423;
            v_t_2426 = v_i_2425;
          } else {
            heff_drop(v_field_2423);
            v_t_2426 = heff_abandon();
          }
        }
        HeffT2 v_t_2427 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_len_240, v_capture_2419, v_fieldTypes_2420, v_t_2426, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
        {
          V v_field_2429 = v_t_2427.f[1];
          int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
          if ((v_tag_2428 == ((int64_t)0ULL))) {
            heff_drop(v_l_243);
            V v_ty_2431 = v_field_2429;
            return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2431});
          } else {
            heff_drop(v_field_2429);
            return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam4, 1, 1, (V[]){v_l_243});
          }
        }
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo);
      }
      case TAG_LikeInt: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo);
      }
      case TAG_LikeFloat: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo);
      }
      case TAG_LikeString: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo);
      }
      case TAG_LikeRune: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2410, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo);
      }
      case TAG_NoRules: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam12_clo);
      }
      default: return heff_nomatch(v_t_2410);
      }
    }
  }
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2eprojTyInWith(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_249 = args[0];
  V v_ty_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_248, v_n_249})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2417 = args[0];
  heff_drop(v_n_2417);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2432 = args[0];
  V v_ty_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2431, v_n_2432})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2433 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2433);
  V v_t_2434 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str2), heff_strAppend(v_l_243, ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str3)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2434});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2436 = args[0];
  heff_drop(v_n_2436);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2437 = args[0];
  heff_drop(v_n_2437);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2438 = args[0];
  heff_drop(v_n_2438);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2439 = args[0];
  heff_drop(v_n_2439);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2440 = args[0];
  heff_drop(v_n_2440);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2442 = args[0];
  heff_drop(v_n_2442);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args) {
  V v_n_2444 = args[0];
  heff_drop(v_n_2444);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str10)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args) {
  V v_n_2445 = args[0];
  heff_drop(v_n_2445);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str11)});
}
Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2efieldTyOr_entry, 4, 0};

V g_heff_2ecompile_2eerase_2efieldTyOr(V v_len_240, V v_t_241, V v_k_242, V v_x4_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eerase_2efieldTyOr_24cpr(v_len_240, v_t_241, v_k_242, v_x4_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eerase_2efieldTyOr(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eerase_2eargTysOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eargTysOf_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eargTysOf(V v_vs_240, V v_tag_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_vs_240, 1), v_tag_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_i_246 = v_field_244;
      V v_xs_247 = heff_get_n(v_vs_240, 2, 3);
      if (heff_intLe_c_lent(MK_INT(0LL), v_i_246, 1)) {
        if (heff_intLt_c(heff_dup(v_i_246), heff_arrayLength_lent(v_xs_247, 0))) {
          V v_ts_2410 = heff_arrayIndex(v_xs_247, v_i_246);
          return (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_2410)));
        } else {
          heff_drop(v_i_246);
          heff_drop(v_xs_247);
          return NTAG(TAG_Nil);
        }
      } else {
        heff_drop(v_i_246);
        heff_drop(v_xs_247);
        return NTAG(TAG_Nil);
      }
    } else {
      heff_drop_rec(v_vs_240, 3);
      heff_drop(v_field_244);
      return NTAG(TAG_Nil);
    }
  }
}
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eerase_2eargTysOf(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eerase_2ezipE_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE(a[0], a[1]);
}
Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_24dps_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ezipE_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str1, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str3, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str4, 1, "$");
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam3(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2ecompile_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_x_243 = ({ V rv_1 = v_t_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 2, shape_c__vars, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x21_245, 0);
      V v_aty_248 = heff_field(v_x21_245, 1);
      V v_ru_24x21_245_24MkPair = heff_take_reuse_n(v_x21_245, 3ULL, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 2, 4);
      V v_t_2410 = (g_heff_2ecompile_2eerase_2eisType(v_t_249, heff_dup(v_aty_248)));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop(v_t_2410);
        V v_c_2411 = heff_take_field(v_acc_240, 0);
        V v_t_2412 = heff_rec_n(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_aty_248)});
        V v_t_2413 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_dup(heff_rfield(v_c_2411, 0))});
        V v_t_2414 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_2411, 2))});
        V v_v_2416 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2414, heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam1, 1, 1, (V[]){v_aty_248}), NTAG(TAG_Nothing)));
        V v_t_2418 = heff_tag_at_n(v_ru_24x21_245_24MkPair, TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_2411, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam2, 1, 1, (V[]){v_v_2416})});
        V v_t_2419 = heff_intAdd(heff_take_field(v_c_2411, 2), MK_INT(1LL));
        V v_t_2420 = ({ V rv_0 = v_t_2413; V rv_1 = v_t_2418; V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_c_2411, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
        V v_t_2421 = ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_c__vars, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V t_0 = v_t_2421;
        V t_1 = v_rest_246;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop_cell(v_ru_24x21_245_24MkPair, 2);
        heff_drop(v_t_2410);
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam3, 1, 4, (V[]){v_x_247, v_acc_240, v_aty_248, v_rest_246});
      }
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_n_244})});
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_aty_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_aty_248;
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam2(V self, V *args) {
  V v_u_2417 = args[0];
  V v_v_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return v_v_2416;
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam4(V self, V *args) {
  V v_u_2432 = args[0];
  V v_aty_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2432);
  return v_aty_248;
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam5(V self, V *args) {
  V v_u_2434 = args[0];
  V v_v_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2434);
  return v_v_2433;
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam3(V self, V *args) {
  V v_n_2422 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_aty_248 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2425;
  if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str0), 2)) {
    heff_drop(v_x_247);
    v_t_2425 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str1);
  } else {
    if (heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str2), 2)) {
      heff_drop(v_x_247);
      v_t_2425 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str3);
    } else {
      v_t_2425 = v_x_247;
    }
  }
  V v_t_2426 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2earmBindGo_str4), heff_intShow(heff_dup(v_n_2422)));
  V v_t_2427 = heff_strAppend(v_t_2425, v_t_2426);
  V v_c_2428 = heff_take_field(v_acc_240, 0);
  V v_t_2429 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2427)})});
  V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2429, heff_dup(v_aty_248)}), heff_take_field(v_c_2428, 0)});
  V v_t_2431 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_2428, 2))});
  V v_v_2433 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2431, heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam4, 1, 1, (V[]){v_aty_248}), NTAG(TAG_Nothing)));
  V v_t_2435 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_2428, 1), heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam5, 1, 1, (V[]){v_v_2433})});
  V v_t_2436 = heff_intAdd(heff_take_field(v_c_2428, 2), MK_INT(1LL));
  V v_t_2437 = ({ V rv_0 = v_t_2430; V rv_1 = v_t_2435; V rv_2 = v_t_2436; V rr_ = heff_rec_reuse_nf(v_c_2428, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_get_n(v_acc_240, 1, 2)});
  V v_t_2439 = (g_heff_2ecompile_2eerase_2earmBindGo(heff_rec_n(2, shape_c__vars, (V[]){v_t_2437, v_t_2438}), v_rest_246));
  V f_ = v_t_2439;
  args[0] = heff_intAdd(v_n_2422, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0, 27, "this needs an expected type");
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry, 3, 0};

V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V v_c_240, V v_vs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    return ((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        V v_t_2410 = heff_rec_n(2, shape_c__vars, (V[]){heff_dup(v_c_240), NTAG(TAG_Nil)});
        V v_t_2411 = ({ V a_0 = heff_dup(v_vs_241); V a_1 = v_tag_246; V r_ = (g_heff_2ecompile_2eerase_2eargTysOf(a_0, a_1)); heff_drop(v_tag_246); r_; });
        V v_t_2412 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_xs_248), v_t_2411));
        V v_m_2413 = (g_heff_2ecompile_2eerase_2earmBindGo(v_t_2410, v_t_2412));
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1, 1, 5, (V[]){v_m_2413, v_body_249, v_c_240, v_vs_241, v_tail_245});
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0)});
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_body_249 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_tail_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Left = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    heff_drop(v_body_249);
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_tail_245);
    return heff_tag_at_n(v_ru_24x2_2415_24Left, TAG_Left, 1, (V[]){v_e_2416});
  }
  case TAG_Right: {
    V v_x21_2417 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Right = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x21_2417, 0);
      V v_n_2419 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      V v_m_2420 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_get_n(v_x_2418, 0, 2), v_body_249));
      V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){heff_dup(v_n_2419)}));
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Left: {
        heff_take_n(v_x2_2421, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2415_24Right, 1);
        V v_t_2423 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(v_c_240, v_vs_241, v_tail_245));
        V f_ = v_t_2423;
        args[0] = v_n_2419;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Right: {
        V v_x21_2424 = heff_field(v_x2_2421, 0);
        heff_take_n(v_x2_2421, 1ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_vs_241);
        heff_drop(v_tail_245);
        heff_drop(v_n_2419);
        switch (heff_tag_of(v_x21_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x21_2424, 0);
          V v_n_27_2426 = heff_field(v_x21_2424, 1);
          heff_take_n(v_x21_2424, 3ULL, 2);
          switch (heff_tag_of(v_x_2425)) {
          case TAG_MkPair: {
            V v_ty_2428 = heff_field(v_x_2425, 1);
            heff_take_n(v_x_2425, 2ULL, 2);
            return heff_tag_at_n(v_ru_24x2_2415_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2428, v_n_27_2426})});
          }
          default: return heff_nomatch(v_x_2425);
          }
        }
        default: return heff_nomatch(v_x21_2424);
        }
      }
      default: return heff_nomatch(v_x2_2421);
      }
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str0, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str6, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str7, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str8, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str9, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str10, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str11, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str12, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str13, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str14, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str15, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str16, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str17, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str18, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str19, 26, "a type in a value position");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str23, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str24, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str25, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str26, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str27, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str28, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str29, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str30, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str31, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str32, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str33, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str34, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str35, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str36, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str37, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str38, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str39, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str40, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str41, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str42, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str43, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str44, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str45, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str46, 14, "an opaque term");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str47, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str48, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str49, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str50, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str51, 1, "$");
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam50(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam49(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam55(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam56(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam54(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam57(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam58(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam59(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam60(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam61(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam62(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam63(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam64(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam65(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry, 7, 0};

V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V v_tag_240, V v_c_241, V v_abs_242, V v_ty_243, V v_c_244, V v_t_245, V v_ty_246) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145: {
    top_TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145: ;
    heff_drop_rec(v_c_244, 4);
    heff_drop(v_t_245);
    heff_drop(v_ty_246);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0_clo);
    }
    case TAG_LikeFunction: {
      V v_dom_2411 = heff_field(v_t_247, 1);
      V v_cod_2412 = heff_field(v_t_247, 2);
      heff_take_n(v_t_247, 6ULL, 4);
      V v_t_2419;
      switch (heff_tag_of(v_abs_242)) {
      case TAG_MkAbs: {
        V v_n_2414 = heff_field(v_abs_242, 0);
        V v_b_2415 = heff_field(v_abs_242, 1);
        V v_ru_24abs_242_24MkAbs = heff_take_reuse_n(v_abs_242, 3ULL, 2);
        V v_t_2416 = heff_tag_at_n(v_ru_24abs_242_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2414, NTAG(TAG_True)});
        v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_b_2415});
        break;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_abs_242, 0);
        heff_take_n(v_abs_242, 1ULL, 1);
        V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str1), NTAG(TAG_False)});
        v_t_2419 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2418, v_b_2417});
        break;
      }
      default: heff_nomatch(v_abs_242);
      }
      switch (heff_tag_of(v_t_2419)) {
      case TAG_MkPair: {
        V v_it1_2420 = heff_field(v_t_2419, 0);
        V v_body_2421 = heff_field(v_t_2419, 1);
        V v_ru_24t_2419_24MkPair = heff_take_reuse_n(v_t_2419, 3ULL, 2);
        switch (heff_tag_of(v_it1_2420)) {
        case TAG_MkPair: {
          V v_hint_2422 = heff_field(v_it1_2420, 0);
          V v_bound_2423 = heff_field(v_it1_2420, 1);
          V v_ru_24it1_2420_24MkPair = heff_take_reuse_n(v_it1_2420, 3ULL, 2);
          V v_t_2424 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_241, 2)), heff_dup(v_dom_2411)));
          if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
            heff_drop(v_hint_2422);
            heff_drop(v_t_2424);
            V v_c_2433;
            if ((heff_dup(v_bound_2423) == NTAG(TAG_True))) {
              heff_drop(v_bound_2423);
              V v_t_2425 = heff_rec_n(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_2411)});
              V v_t_2426 = heff_tag_at_n(v_ru_24t_2419_24MkPair, TAG_Cons, 2, (V[]){v_t_2425, heff_dup(heff_rfield(v_c_241, 0))});
              V v_t_2427 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_241, 2))});
              V v_v_2429 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2427, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1, 1, 1, (V[]){heff_dup(v_dom_2411)}), NTAG(TAG_Nothing)));
              V v_t_2431 = heff_tag_at_n(v_ru_24it1_2420_24MkPair, TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_241, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2, 1, 1, (V[]){v_v_2429})});
              V v_t_2432 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 2)), MK_INT(1LL));
              v_c_2433 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2426, v_t_2431, v_t_2432, heff_dup(heff_rfield(v_c_241, 3))});
            } else {
              heff_drop_cell(v_ru_24t_2419_24MkPair, 2);
              heff_drop(v_bound_2423);
              heff_drop_cell(v_ru_24it1_2420_24MkPair, 2);
              v_c_2433 = heff_dup(v_c_241);
            }
            V v_x1_2441;
            switch (heff_tag_of(v_cod_2412)) {
            case TAG_MkClo: {
              V v_vs_2435 = heff_field(v_cod_2412, 1);
              V v_body_2436 = heff_field(v_cod_2412, 2);
              heff_take_n(v_cod_2412, 6ULL, 3);
              v_x1_2441 = heff_tr(heff_call(v_body_2436, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2435, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3, 1, 2, (V[]){v_c_241, v_dom_2411})})}));
              break;
            }
            case TAG_CloConst: {
              V v_body_2440 = heff_field(v_cod_2412, 0);
              heff_take_n(v_cod_2412, 1ULL, 1);
              heff_drop_rec(v_c_241, 4);
              heff_drop(v_dom_2411);
              v_x1_2441 = v_body_2440;
              break;
            }
            default: heff_nomatch(v_cod_2412);
            }
            V v_ty_2445;
            switch (heff_tag_of(v_x1_2441)) {
            case TAG_Nom: {
              V v_x_2442 = heff_field(v_x1_2441, 0);
              heff_take_n(v_x1_2441, 1ULL, 1);
              v_ty_2445 = v_x_2442;
              break;
            }
            case TAG_Describe: {
              heff_take_n(v_x1_2441, 0ULL, 1);
              v_ty_2445 = heff_abandon();
              break;
            }
            case TAG_Become: {
              V v_x_2444 = heff_field(v_x1_2441, 0);
              heff_take_n(v_x1_2441, 1ULL, 1);
              v_ty_2445 = v_x_2444;
              break;
            }
            default: heff_nomatch(v_x1_2441);
            }
            V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
            V t_1 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str2);
            V t_2 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str3);
            V t_3 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str4);
            V t_4 = v_c_2433;
            V t_5 = v_body_2421;
            V t_6 = v_ty_2445;
            v_tag_240 = t_0;
            v_c_241 = t_1;
            v_abs_242 = t_2;
            v_ty_243 = t_3;
            v_c_244 = t_4;
            v_t_245 = t_5;
            v_ty_246 = t_6;
            goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
          } else {
            heff_drop_cell(v_ru_24t_2419_24MkPair, 2);
            heff_drop_cell(v_ru_24it1_2420_24MkPair, 2);
            heff_drop(v_t_2424);
            return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5, 1, 6, (V[]){v_hint_2422, v_bound_2423, v_dom_2411, v_c_241, v_cod_2412, v_body_2421});
          }
        }
        default: return heff_nomatch(v_it1_2420);
        }
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10_clo);
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11_clo);
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18_clo);
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936: {
    top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936: ;
    switch (heff_tag_of(v_t_245)) {
    case TAG_SLocal: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_2497 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19, 1, 1, (V[]){v_m_2497});
    }
    case TAG_SGlobal: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24107 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20, 1, 1, (V[]){v_m_24107});
    }
    case TAG_SCode: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21_clo);
    }
    case TAG_SApp: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24120 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22, 1, 1, (V[]){v_m_24120});
    }
    case TAG_SLam: {
      V v_abs_24130 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145);
      V t_1 = v_c_244;
      V t_2 = v_abs_24130;
      V t_3 = v_ty_246;
      V t_4 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str20);
      V t_5 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str21);
      V t_6 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str22);
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145;
    }
    case TAG_SCons: {
      V v_d_24131 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_t_24132 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_246));
      switch (heff_tag_of(v_t_24132)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24132, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_24132, 0ULL, 4);
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24_clo);
      }
      case TAG_LikeRecord: {
        V v_capture_24141 = heff_field(v_t_24132, 1);
        V v_fieldTypes_24142 = heff_field(v_t_24132, 2);
        heff_take_n(v_t_24132, 6ULL, 3);
        V v_t_24143 = heff_rec_n(3, shape_vs__out__tys, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
        V v_t_24144 = heff_arrayToList(heff_take_field(v_d_24131, 0));
        V v_t_24145 = heff_arrayToList(heff_get_n(v_d_24131, 2, 3));
        V v_t_24146 = (g_heff_2eutil_2edict_2ezipKV(v_t_24144, v_t_24145));
        return (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_244, v_capture_24141, v_fieldTypes_24142, v_t_24143, v_t_24146));
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_24132, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25_clo);
      }
      case TAG_LikeInt: {
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26_clo);
      }
      case TAG_LikeFloat: {
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27_clo);
      }
      case TAG_LikeString: {
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28_clo);
      }
      case TAG_LikeRune: {
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24132, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_24132, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31_clo);
      }
      case TAG_NoRules: {
        heff_drop_rec(v_c_244, 4);
        heff_drop_rec(v_d_24131, 3);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32_clo);
      }
      default: return heff_nomatch(v_t_24132);
      }
    }
    case TAG_SProj: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24160 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33, 1, 1, (V[]){v_m_24160});
    }
    case TAG_STag: {
      V v_x_24169 = heff_field(v_t_245, 0);
      V v_args_24170 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_t_24171 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_246));
      switch (heff_tag_of(v_t_24171)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24171, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_24171, 0ULL, 4);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35_clo);
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_24171, 0ULL, 3);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36_clo);
      }
      case TAG_LikeSum: {
        V v_vs_24183 = heff_field(v_t_24171, 0);
        heff_take_n(v_t_24171, 1ULL, 1);
        HeffT2 v_t_24184 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_vs_24183, 1), v_x_24169));
        {
          V v_field_24186 = v_t_24184.f[1];
          int64_t v_tag_24185 = ((int64_t)v_t_24184.f[0]);
          if ((v_tag_24185 == ((int64_t)0ULL))) {
            V v_i_24188 = v_field_24186;
            V v_xs_24189 = heff_get_n(v_vs_24183, 2, 3);
            if (heff_intLe_c_lent(MK_INT(0LL), v_i_24188, 1)) {
              if (heff_intLt_c(heff_dup(v_i_24188), heff_arrayLength_lent(v_xs_24189, 0))) {
                V v_ts_24192 = heff_arrayIndex(v_xs_24189, v_i_24188);
                V v_t_24193 = (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_24192)));
                V v_t_24194 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_args_24170), v_t_24193));
                V v_m_24196 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37, 1, 1, (V[]){v_c_244}), v_t_24194));
                return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38, 1, 2, (V[]){v_m_24196, v_x_24169});
              } else {
                heff_drop_rec(v_c_244, 4);
                heff_drop(v_args_24170);
                heff_drop(v_i_24188);
                heff_drop(v_xs_24189);
                return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39, 1, 1, (V[]){v_x_24169});
              }
            } else {
              heff_drop_rec(v_c_244, 4);
              heff_drop(v_args_24170);
              heff_drop(v_i_24188);
              heff_drop(v_xs_24189);
              return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40, 1, 1, (V[]){v_x_24169});
            }
          } else {
            heff_drop_rec(v_c_244, 4);
            heff_drop(v_args_24170);
            heff_drop_rec(v_vs_24183, 3);
            heff_drop(v_field_24186);
            return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41, 1, 1, (V[]){v_x_24169});
          }
        }
      }
      case TAG_LikeInt: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42_clo);
      }
      case TAG_LikeFloat: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43_clo);
      }
      case TAG_LikeString: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44_clo);
      }
      case TAG_LikeRune: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24171, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_24171, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47_clo);
      }
      case TAG_NoRules: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24169);
        heff_drop(v_args_24170);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48_clo);
      }
      default: return heff_nomatch(v_t_24171);
      }
    }
    case TAG_SMatch: {
      V v_scrut_24220 = heff_field(v_t_245, 0);
      V v_cases_24221 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_m_24222 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_244), v_scrut_24220));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam49, 1, 4, (V[]){v_m_24222, v_cases_24221, v_c_244, v_ty_246});
    }
    case TAG_SSpecialize: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24251 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51, 1, 1, (V[]){v_m_24251});
    }
    case TAG_SIs: {
      V v_t1_24260 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t1_24260;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SOpaque: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52_clo);
    }
    case TAG_SAbandon: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53_clo);
    }
    case TAG_SRec: {
      V v_t1_24264 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t1_24264;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SFix: {
      V v_t2_27_24266 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      switch (heff_tag_of(v_t2_27_24266)) {
      case TAG_MkAbs: {
        V v_x_24267 = heff_field(v_t2_27_24266, 0);
        V v_body_24268 = heff_field(v_t2_27_24266, 1);
        heff_take_n(v_t2_27_24266, 3ULL, 2);
        heff_drop_rec(v_c_241, 4);
        heff_drop(v_abs_242);
        heff_drop(v_ty_243);
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam54, 1, 4, (V[]){v_x_24267, v_ty_246, v_c_244, v_body_24268});
      }
      case TAG_AbsConst: {
        V v_body_24291 = heff_field(v_t2_27_24266, 0);
        heff_take_n(v_t2_27_24266, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
        V t_1 = v_c_241;
        V t_2 = v_abs_242;
        V t_3 = v_ty_243;
        V t_4 = v_c_244;
        V t_5 = v_body_24291;
        V t_6 = v_ty_246;
        v_tag_240 = t_0;
        v_c_241 = t_1;
        v_abs_242 = t_2;
        v_ty_243 = t_3;
        v_c_244 = t_4;
        v_t_245 = t_5;
        v_ty_246 = t_6;
        goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
      }
      default: return heff_nomatch(v_t2_27_24266);
      }
    }
    case TAG_SImplicit: {
      V v_t2_27_24293 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t2_27_24293;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SPrim: {
      V v_x_24294 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam57, 1, 1, (V[]){v_x_24294});
    }
    case TAG_SMetaApp: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24300 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam58, 1, 1, (V[]){v_m_24300});
    }
    case TAG_SLitInt: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24310 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam59, 1, 1, (V[]){v_m_24310});
    }
    case TAG_SLitFloat: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24320 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam60, 1, 1, (V[]){v_m_24320});
    }
    case TAG_SLitString: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24330 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam61, 1, 1, (V[]){v_m_24330});
    }
    case TAG_SLitBytes: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24340 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam62, 1, 1, (V[]){v_m_24340});
    }
    case TAG_SLitRune: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24350 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam63, 1, 1, (V[]){v_m_24350});
    }
    case TAG_SLitFixed: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24361 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam64, 1, 1, (V[]){v_m_24361});
    }
    case TAG_SLitFloat32: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24371 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam65, 1, 1, (V[]){v_m_24371});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0(V self, V *args) {
  V v_n_249 = args[0];
  heff_drop(v_n_249);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str0)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2(V self, V *args) {
  V v_u_2430 = args[0];
  V v_v_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2430);
  return v_v_2429;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4(V self, V *args) {
  V v_u_2439 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2439);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3(V self, V *args) {
  V v_u_2437 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_dom_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2437);
  V v_t_2438 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_241, 2, 4)});
  return (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2438, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4, 1, 1, (V[]){v_dom_2411}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6(V self, V *args) {
  V v_u_2455 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2455);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7(V self, V *args) {
  V v_u_2457 = args[0];
  V v_v_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2457);
  return v_v_2456;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9(V self, V *args) {
  V v_u_2466 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2466);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8(V self, V *args) {
  V v_u_2464 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_dom_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2464);
  V v_t_2465 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_241, 2, 4)});
  return (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2465, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9, 1, 1, (V[]){v_dom_2411}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  V v_hint_2422 = heff_env(self)[0];
  V v_bound_2423 = heff_env(self)[1];
  V v_dom_2411 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  V v_cod_2412 = heff_env(self)[4];
  V v_body_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2449;
  if (heff_strEq_c_lent(v_hint_2422, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str5), 2)) {
    heff_drop(v_hint_2422);
    v_t_2449 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str6);
  } else {
    if (heff_strEq_c_lent(v_hint_2422, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str7), 2)) {
      heff_drop(v_hint_2422);
      v_t_2449 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str8);
    } else {
      v_t_2449 = v_hint_2422;
    }
  }
  V v_t_2450 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str9), heff_intShow(heff_dup(v_n_2446)));
  V v_t_2451 = heff_strAppend(v_t_2449, v_t_2450);
  V v_c_2460;
  if ((heff_dup(v_bound_2423) == NTAG(TAG_True))) {
    heff_drop(v_bound_2423);
    V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2451)})});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2452, heff_dup(v_dom_2411)}), heff_dup(heff_rfield(v_c_241, 0))});
    V v_t_2454 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_241, 2))});
    V v_v_2456 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_2454, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6, 1, 1, (V[]){heff_dup(v_dom_2411)}), NTAG(TAG_Nothing)));
    V v_t_2458 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_241, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7, 1, 1, (V[]){v_v_2456})});
    V v_t_2459 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 2)), MK_INT(1LL));
    v_c_2460 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2453, v_t_2458, v_t_2459, heff_dup(heff_rfield(v_c_241, 3))});
  } else {
    heff_drop(v_bound_2423);
    v_c_2460 = heff_dup(v_c_241);
  }
  V v_x1_2468;
  switch (heff_tag_of(v_cod_2412)) {
  case TAG_MkClo: {
    V v_vs_2462 = heff_field(v_cod_2412, 1);
    V v_body_2463 = heff_field(v_cod_2412, 2);
    heff_take_n(v_cod_2412, 6ULL, 3);
    v_x1_2468 = heff_tr(heff_call(v_body_2463, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2462, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8, 1, 2, (V[]){v_c_241, v_dom_2411})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2467 = heff_field(v_cod_2412, 0);
    heff_take_n(v_cod_2412, 1ULL, 1);
    heff_drop(v_dom_2411);
    heff_drop_rec(v_c_241, 4);
    v_x1_2468 = v_body_2467;
    break;
  }
  default: heff_nomatch(v_cod_2412);
  }
  V v_ty_2472;
  switch (heff_tag_of(v_x1_2468)) {
  case TAG_Nom: {
    V v_x_2469 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_ty_2472 = v_x_2469;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2468, 0ULL, 1);
    v_ty_2472 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2471 = heff_field(v_x1_2468, 0);
    heff_take_n(v_x1_2468, 1ULL, 1);
    v_ty_2472 = v_x_2471;
    break;
  }
  default: heff_nomatch(v_x1_2468);
  }
  V v_m_2473 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_2460, v_body_2421, v_ty_2472));
  V v_x2_2474 = heff_tr(heff_call(v_m_2473, 1, (V[]){heff_intAdd(v_n_2446, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_Left: {
    V v_e_2475 = heff_field(v_x2_2474, 0);
    V v_ru_24x2_2474_24Left = heff_take_reuse_n(v_x2_2474, 1ULL, 1);
    heff_drop(v_t_2451);
    return heff_tag_at_n(v_ru_24x2_2474_24Left, TAG_Left, 1, (V[]){v_e_2475});
  }
  case TAG_Right: {
    V v_x21_2476 = heff_field(v_x2_2474, 0);
    V v_ru_24x2_2474_24Right = heff_take_reuse_n(v_x2_2474, 1ULL, 1);
    switch (heff_tag_of(v_x21_2476)) {
    case TAG_MkPair: {
      V v_x_2477 = heff_field(v_x21_2476, 0);
      V v_n_2478 = heff_field(v_x21_2476, 1);
      V v_ru_24x21_2476_24MkPair = heff_take_reuse_n(v_x21_2476, 3ULL, 2);
      V v_t_2479 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
      V v_t_2480 = heff_tag_at_n(v_ru_24x21_2476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2479, v_x_2477}), v_n_2478});
      return heff_tag_at_n(v_ru_24x2_2474_24Right, TAG_Right, 1, (V[]){v_t_2480});
    }
    default: return heff_nomatch(v_x21_2476);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10(V self, V *args) {
  V v_n_2484 = args[0];
  heff_drop(v_n_2484);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str10)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11(V self, V *args) {
  V v_n_2486 = args[0];
  heff_drop(v_n_2486);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str11)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12(V self, V *args) {
  V v_n_2487 = args[0];
  heff_drop(v_n_2487);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str12)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13(V self, V *args) {
  V v_n_2488 = args[0];
  heff_drop(v_n_2488);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str13)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14(V self, V *args) {
  V v_n_2489 = args[0];
  heff_drop(v_n_2489);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str14)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15(V self, V *args) {
  V v_n_2490 = args[0];
  heff_drop(v_n_2490);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str15)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16(V self, V *args) {
  V v_n_2492 = args[0];
  heff_drop(v_n_2492);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str16)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17(V self, V *args) {
  V v_n_2494 = args[0];
  heff_drop(v_n_2494);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str17)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18(V self, V *args) {
  V v_n_2495 = args[0];
  heff_drop(v_n_2495);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str18)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19(V self, V *args) {
  V v_n_2498 = args[0];
  V v_m_2497 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2499 = heff_tr(heff_call(v_m_2497, 1, (V[]){v_n_2498}));
  switch (heff_tag_of(v_x2_2499)) {
  case TAG_Left: {
    V v_e_24100 = heff_field(v_x2_2499, 0);
    V v_ru_24x2_2499_24Left = heff_take_reuse_n(v_x2_2499, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2499_24Left, TAG_Left, 1, (V[]){v_e_24100});
  }
  case TAG_Right: {
    V v_x21_24101 = heff_field(v_x2_2499, 0);
    V v_ru_24x2_2499_24Right = heff_take_reuse_n(v_x2_2499, 1ULL, 1);
    switch (heff_tag_of(v_x21_24101)) {
    case TAG_MkPair: {
      V v_x_24102 = heff_field(v_x21_24101, 0);
      V v_n_24103 = heff_field(v_x21_24101, 1);
      heff_take_n(v_x21_24101, 3ULL, 2);
      switch (heff_tag_of(v_x_24102)) {
      case TAG_MkPair: {
        V v_t_27_24104 = heff_field(v_x_24102, 0);
        heff_take_n(v_x_24102, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2499_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24104, v_n_24103})});
      }
      default: return heff_nomatch(v_x_24102);
      }
    }
    default: return heff_nomatch(v_x21_24101);
    }
  }
  default: return heff_nomatch(v_x2_2499);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20(V self, V *args) {
  V v_n_24108 = args[0];
  V v_m_24107 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24109 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_n_24108}));
  switch (heff_tag_of(v_x2_24109)) {
  case TAG_Left: {
    V v_e_24110 = heff_field(v_x2_24109, 0);
    V v_ru_24x2_24109_24Left = heff_take_reuse_n(v_x2_24109, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24109_24Left, TAG_Left, 1, (V[]){v_e_24110});
  }
  case TAG_Right: {
    V v_x21_24111 = heff_field(v_x2_24109, 0);
    V v_ru_24x2_24109_24Right = heff_take_reuse_n(v_x2_24109, 1ULL, 1);
    switch (heff_tag_of(v_x21_24111)) {
    case TAG_MkPair: {
      V v_x_24112 = heff_field(v_x21_24111, 0);
      V v_n_24113 = heff_field(v_x21_24111, 1);
      heff_take_n(v_x21_24111, 3ULL, 2);
      switch (heff_tag_of(v_x_24112)) {
      case TAG_MkPair: {
        V v_t_27_24114 = heff_field(v_x_24112, 0);
        heff_take_n(v_x_24112, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24109_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24114, v_n_24113})});
      }
      default: return heff_nomatch(v_x_24112);
      }
    }
    default: return heff_nomatch(v_x21_24111);
    }
  }
  default: return heff_nomatch(v_x2_24109);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21(V self, V *args) {
  V v_n_24117 = args[0];
  heff_drop(v_n_24117);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str19)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22(V self, V *args) {
  V v_n_24121 = args[0];
  V v_m_24120 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24122 = heff_tr(heff_call(v_m_24120, 1, (V[]){v_n_24121}));
  switch (heff_tag_of(v_x2_24122)) {
  case TAG_Left: {
    V v_e_24123 = heff_field(v_x2_24122, 0);
    V v_ru_24x2_24122_24Left = heff_take_reuse_n(v_x2_24122, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24122_24Left, TAG_Left, 1, (V[]){v_e_24123});
  }
  case TAG_Right: {
    V v_x21_24124 = heff_field(v_x2_24122, 0);
    V v_ru_24x2_24122_24Right = heff_take_reuse_n(v_x2_24122, 1ULL, 1);
    switch (heff_tag_of(v_x21_24124)) {
    case TAG_MkPair: {
      V v_x_24125 = heff_field(v_x21_24124, 0);
      V v_n_24126 = heff_field(v_x21_24124, 1);
      heff_take_n(v_x21_24124, 3ULL, 2);
      switch (heff_tag_of(v_x_24125)) {
      case TAG_MkPair: {
        V v_t_27_24127 = heff_field(v_x_24125, 0);
        heff_take_n(v_x_24125, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24122_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24127, v_n_24126})});
      }
      default: return heff_nomatch(v_x_24125);
      }
    }
    default: return heff_nomatch(v_x21_24124);
    }
  }
  default: return heff_nomatch(v_x2_24122);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23(V self, V *args) {
  V v_n_24134 = args[0];
  heff_drop(v_n_24134);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str23)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24(V self, V *args) {
  V v_n_24139 = args[0];
  heff_drop(v_n_24139);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str24)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25(V self, V *args) {
  V v_n_24148 = args[0];
  heff_drop(v_n_24148);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str25)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26(V self, V *args) {
  V v_n_24149 = args[0];
  heff_drop(v_n_24149);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str26)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27(V self, V *args) {
  V v_n_24150 = args[0];
  heff_drop(v_n_24150);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str27)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28(V self, V *args) {
  V v_n_24151 = args[0];
  heff_drop(v_n_24151);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str28)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29(V self, V *args) {
  V v_n_24152 = args[0];
  heff_drop(v_n_24152);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str29)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30(V self, V *args) {
  V v_n_24154 = args[0];
  heff_drop(v_n_24154);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str30)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31(V self, V *args) {
  V v_n_24156 = args[0];
  heff_drop(v_n_24156);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str31)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32(V self, V *args) {
  V v_n_24157 = args[0];
  heff_drop(v_n_24157);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str32)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33(V self, V *args) {
  V v_n_24161 = args[0];
  V v_m_24160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24162 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_n_24161}));
  switch (heff_tag_of(v_x2_24162)) {
  case TAG_Left: {
    V v_e_24163 = heff_field(v_x2_24162, 0);
    V v_ru_24x2_24162_24Left = heff_take_reuse_n(v_x2_24162, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24162_24Left, TAG_Left, 1, (V[]){v_e_24163});
  }
  case TAG_Right: {
    V v_x21_24164 = heff_field(v_x2_24162, 0);
    V v_ru_24x2_24162_24Right = heff_take_reuse_n(v_x2_24162, 1ULL, 1);
    switch (heff_tag_of(v_x21_24164)) {
    case TAG_MkPair: {
      V v_x_24165 = heff_field(v_x21_24164, 0);
      V v_n_24166 = heff_field(v_x21_24164, 1);
      heff_take_n(v_x21_24164, 3ULL, 2);
      switch (heff_tag_of(v_x_24165)) {
      case TAG_MkPair: {
        V v_t_27_24167 = heff_field(v_x_24165, 0);
        heff_take_n(v_x_24165, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24162_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24167, v_n_24166})});
      }
      default: return heff_nomatch(v_x_24165);
      }
    }
    default: return heff_nomatch(v_x21_24164);
    }
  }
  default: return heff_nomatch(v_x2_24162);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34(V self, V *args) {
  V v_n_24173 = args[0];
  heff_drop(v_n_24173);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str33)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35(V self, V *args) {
  V v_n_24178 = args[0];
  heff_drop(v_n_24178);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str34)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36(V self, V *args) {
  V v_n_24182 = args[0];
  heff_drop(v_n_24182);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str35)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37(V self, V *args) {
  V v_p_24195 = args[0];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(v_c_244, v_p_24195));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38(V self, V *args) {
  V v_n_24197 = args[0];
  V v_m_24196 = heff_env(self)[0];
  V v_x_24169 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24198 = heff_tr(heff_call(v_m_24196, 1, (V[]){v_n_24197}));
  switch (heff_tag_of(v_x2_24198)) {
  case TAG_Left: {
    V v_e_24199 = heff_field(v_x2_24198, 0);
    V v_ru_24x2_24198_24Left = heff_take_reuse_n(v_x2_24198, 1ULL, 1);
    heff_drop(v_x_24169);
    return heff_tag_at_n(v_ru_24x2_24198_24Left, TAG_Left, 1, (V[]){v_e_24199});
  }
  case TAG_Right: {
    V v_x21_24200 = heff_field(v_x2_24198, 0);
    V v_ru_24x2_24198_24Right = heff_take_reuse_n(v_x2_24198, 1ULL, 1);
    switch (heff_tag_of(v_x21_24200)) {
    case TAG_MkPair: {
      V v_x_24201 = heff_field(v_x21_24200, 0);
      V v_n_24202 = heff_field(v_x21_24200, 1);
      heff_take_n(v_x21_24200, 3ULL, 2);
      V v_t_24203 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_24201)));
      V v_t_24204 = (g_list_2emap_24s1937570095x2110149801(v_t_24203));
      V v_t_24205 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_24201));
      V v_t_24206 = (g_list_2emap_24s1173914895x100384474(v_t_24205));
      V v_x_24207 = heff_tag_n(TAG_ETag, 3, (V[]){v_x_24169, v_t_24204, v_t_24206});
      return heff_tag_at_n(v_ru_24x2_24198_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24207, v_n_24202})});
    }
    default: return heff_nomatch(v_x21_24200);
    }
  }
  default: return heff_nomatch(v_x2_24198);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39(V self, V *args) {
  V v_n_24208 = args[0];
  V v_x_24169 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24208);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str36), v_x_24169)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40(V self, V *args) {
  V v_n_24209 = args[0];
  V v_x_24169 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24209);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str37), v_x_24169)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41(V self, V *args) {
  V v_n_24210 = args[0];
  V v_x_24169 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24210);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str38), v_x_24169)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42(V self, V *args) {
  V v_n_24211 = args[0];
  heff_drop(v_n_24211);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str39)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43(V self, V *args) {
  V v_n_24212 = args[0];
  heff_drop(v_n_24212);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str40)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44(V self, V *args) {
  V v_n_24213 = args[0];
  heff_drop(v_n_24213);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str41)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45(V self, V *args) {
  V v_n_24214 = args[0];
  heff_drop(v_n_24214);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str42)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46(V self, V *args) {
  V v_n_24216 = args[0];
  heff_drop(v_n_24216);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str43)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47(V self, V *args) {
  V v_n_24218 = args[0];
  heff_drop(v_n_24218);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str44)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48(V self, V *args) {
  V v_n_24219 = args[0];
  heff_drop(v_n_24219);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str45)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam50(V self, V *args) {
  V v_p_24240 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_x_24235 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_244, v_x_24235, v_ty_246, v_p_24240));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam49(V self, V *args) {
  V v_n_24223 = args[0];
  V v_m_24222 = heff_env(self)[0];
  V v_cases_24221 = heff_env(self)[1];
  V v_c_244 = heff_env(self)[2];
  V v_ty_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24224 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_n_24223}));
  switch (heff_tag_of(v_x2_24224)) {
  case TAG_Left: {
    V v_e_24225 = heff_field(v_x2_24224, 0);
    V v_ru_24x2_24224_24Left = heff_take_reuse_n(v_x2_24224, 1ULL, 1);
    heff_drop_rec(v_cases_24221, 3);
    heff_drop_rec(v_c_244, 4);
    heff_drop(v_ty_246);
    return heff_tag_at_n(v_ru_24x2_24224_24Left, TAG_Left, 1, (V[]){v_e_24225});
  }
  case TAG_Right: {
    V v_x21_24226 = heff_field(v_x2_24224, 0);
    V v_ru_24x2_24224_24Right = heff_take_reuse_n(v_x2_24224, 1ULL, 1);
    switch (heff_tag_of(v_x21_24226)) {
    case TAG_MkPair: {
      V v_x_24227 = heff_field(v_x21_24226, 0);
      V v_n_24228 = heff_field(v_x21_24226, 1);
      V v_ru_24x21_24226_24MkPair = heff_take_reuse_n(v_x21_24226, 3ULL, 2);
      switch (heff_tag_of(v_x_24227)) {
      case TAG_MkPair: {
        V v_s_27_24229 = heff_field(v_x_24227, 0);
        V v_sty_24230 = heff_field(v_x_24227, 1);
        heff_take_n(v_x_24227, 3ULL, 2);
        V v_m_24231 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24230));
        V v_x2_24232 = heff_tr(heff_call(v_m_24231, 1, (V[]){v_n_24228}));
        switch (heff_tag_of(v_x2_24232)) {
        case TAG_Left: {
          V v_e_24233 = heff_field(v_x2_24232, 0);
          V v_ru_24x2_24232_24Left = heff_take_reuse_n(v_x2_24232, 1ULL, 1);
          heff_drop_rec(v_cases_24221, 3);
          heff_drop_rec(v_c_244, 4);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24224_24Right, 1);
          heff_drop_cell(v_ru_24x21_24226_24MkPair, 2);
          heff_drop(v_s_27_24229);
          return heff_tag_at_n(v_ru_24x2_24232_24Left, TAG_Left, 1, (V[]){v_e_24233});
        }
        case TAG_Right: {
          V v_x21_24234 = heff_field(v_x2_24232, 0);
          V v_ru_24x2_24232_24Right = heff_take_reuse_n(v_x2_24232, 1ULL, 1);
          switch (heff_tag_of(v_x21_24234)) {
          case TAG_MkPair: {
            V v_x_24235 = heff_field(v_x21_24234, 0);
            V v_n_24236 = heff_field(v_x21_24234, 1);
            heff_take_n(v_x21_24234, 3ULL, 2);
            V v_t_24237 = heff_arrayToList(heff_take_field(v_cases_24221, 0));
            V v_t_24238 = heff_arrayToList(heff_get_n(v_cases_24221, 2, 3));
            V v_t_24239 = (g_heff_2eutil_2edict_2ezipKV(v_t_24237, v_t_24238));
            V v_m_24241 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam50, 1, 3, (V[]){v_c_244, v_x_24235, v_ty_246}), v_t_24239));
            V v_x2_24242 = heff_tr(heff_call(v_m_24241, 1, (V[]){v_n_24236}));
            switch (heff_tag_of(v_x2_24242)) {
            case TAG_Left: {
              V v_e_24243 = heff_field(v_x2_24242, 0);
              heff_take_n(v_x2_24242, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_24224_24Right, 1);
              heff_drop_cell(v_ru_24x21_24226_24MkPair, 2);
              heff_drop(v_s_27_24229);
              return heff_tag_at_n(v_ru_24x2_24232_24Right, TAG_Left, 1, (V[]){v_e_24243});
            }
            case TAG_Right: {
              V v_x21_24244 = heff_field(v_x2_24242, 0);
              heff_take_n(v_x2_24242, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_24232_24Right, 1);
              switch (heff_tag_of(v_x21_24244)) {
              case TAG_MkPair: {
                V v_x_24245 = heff_field(v_x21_24244, 0);
                V v_n_24246 = heff_field(v_x21_24244, 1);
                heff_take_n(v_x21_24244, 3ULL, 2);
                V v_t_24247 = heff_tag_at_n(v_ru_24x21_24226_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_24229, v_x_24245}), v_n_24246});
                return heff_tag_at_n(v_ru_24x2_24224_24Right, TAG_Right, 1, (V[]){v_t_24247});
              }
              default: return heff_nomatch(v_x21_24244);
              }
            }
            default: return heff_nomatch(v_x2_24242);
            }
          }
          default: return heff_nomatch(v_x21_24234);
          }
        }
        default: return heff_nomatch(v_x2_24232);
        }
      }
      default: return heff_nomatch(v_x_24227);
      }
    }
    default: return heff_nomatch(v_x21_24226);
    }
  }
  default: return heff_nomatch(v_x2_24224);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51(V self, V *args) {
  V v_n_24252 = args[0];
  V v_m_24251 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24253 = heff_tr(heff_call(v_m_24251, 1, (V[]){v_n_24252}));
  switch (heff_tag_of(v_x2_24253)) {
  case TAG_Left: {
    V v_e_24254 = heff_field(v_x2_24253, 0);
    V v_ru_24x2_24253_24Left = heff_take_reuse_n(v_x2_24253, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24253_24Left, TAG_Left, 1, (V[]){v_e_24254});
  }
  case TAG_Right: {
    V v_x21_24255 = heff_field(v_x2_24253, 0);
    V v_ru_24x2_24253_24Right = heff_take_reuse_n(v_x2_24253, 1ULL, 1);
    switch (heff_tag_of(v_x21_24255)) {
    case TAG_MkPair: {
      V v_x_24256 = heff_field(v_x21_24255, 0);
      V v_n_24257 = heff_field(v_x21_24255, 1);
      heff_take_n(v_x21_24255, 3ULL, 2);
      switch (heff_tag_of(v_x_24256)) {
      case TAG_MkPair: {
        V v_t_27_24258 = heff_field(v_x_24256, 0);
        heff_take_n(v_x_24256, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24253_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24258, v_n_24257})});
      }
      default: return heff_nomatch(v_x_24256);
      }
    }
    default: return heff_nomatch(v_x21_24255);
    }
  }
  default: return heff_nomatch(v_x2_24253);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52(V self, V *args) {
  V v_n_24261 = args[0];
  heff_drop(v_n_24261);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str46)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53(V self, V *args) {
  V v_n_24262 = args[0];
  V v_t_24263 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24262});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24263});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam55(V self, V *args) {
  V v_u_24278 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24278);
  return v_ty_246;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam56(V self, V *args) {
  V v_u_24280 = args[0];
  V v_v_24279 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24280);
  return v_v_24279;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam54(V self, V *args) {
  V v_n_24269 = args[0];
  V v_x_24267 = heff_env(self)[0];
  V v_ty_246 = heff_env(self)[1];
  V v_c_244 = heff_env(self)[2];
  V v_body_24268 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24272;
  if (heff_strEq_c_lent(v_x_24267, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str47), 2)) {
    heff_drop(v_x_24267);
    v_t_24272 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str48);
  } else {
    if (heff_strEq_c_lent(v_x_24267, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str49), 2)) {
      heff_drop(v_x_24267);
      v_t_24272 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str50);
    } else {
      v_t_24272 = v_x_24267;
    }
  }
  V v_t_24273 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str51), heff_intShow(heff_dup(v_n_24269)));
  V v_t_24274 = heff_strAppend(v_t_24272, v_t_24273);
  V v_t_24275 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24274)})});
  V v_t_24276 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_24275, heff_dup(v_ty_246)}), heff_take_field(v_c_244, 0)});
  V v_t_24277 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_244, 2))});
  V v_v_24279 = (g_heff_2eelab_2evalue_2ereflect_24s1043830207x1714654706(v_t_24277, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam55, 1, 1, (V[]){heff_dup(v_ty_246)}), NTAG(TAG_Nothing)));
  V v_t_24281 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_244, 1), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam56, 1, 1, (V[]){v_v_24279})});
  V v_t_24282 = heff_intAdd(heff_take_field(v_c_244, 2), MK_INT(1LL));
  V v_c_24283 = ({ V rv_0 = v_t_24276; V rv_1 = v_t_24281; V rv_2 = v_t_24282; V rr_ = heff_rec_reuse_nf(v_c_244, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_m_24284 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_24283, v_body_24268, v_ty_246));
  V v_x2_24285 = heff_tr(heff_call(v_m_24284, 1, (V[]){heff_intAdd(v_n_24269, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24285)) {
  case TAG_Left: {
    V v_e_24286 = heff_field(v_x2_24285, 0);
    V v_ru_24x2_24285_24Left = heff_take_reuse_n(v_x2_24285, 1ULL, 1);
    heff_drop(v_t_24274);
    return heff_tag_at_n(v_ru_24x2_24285_24Left, TAG_Left, 1, (V[]){v_e_24286});
  }
  case TAG_Right: {
    V v_x21_24287 = heff_field(v_x2_24285, 0);
    V v_ru_24x2_24285_24Right = heff_take_reuse_n(v_x2_24285, 1ULL, 1);
    switch (heff_tag_of(v_x21_24287)) {
    case TAG_MkPair: {
      V v_x_24288 = heff_field(v_x21_24287, 0);
      V v_n_24289 = heff_field(v_x21_24287, 1);
      V v_ru_24x21_24287_24MkPair = heff_take_reuse_n(v_x21_24287, 3ULL, 2);
      V v_t_24290 = heff_tag_at_n(v_ru_24x21_24287_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_t_24274, v_x_24288}), v_n_24289});
      return heff_tag_at_n(v_ru_24x2_24285_24Right, TAG_Right, 1, (V[]){v_t_24290});
    }
    default: return heff_nomatch(v_x21_24287);
    }
  }
  default: return heff_nomatch(v_x2_24285);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam57(V self, V *args) {
  V v_n_24295 = args[0];
  V v_x_24294 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24296 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24294}), v_n_24295});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24296});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam58(V self, V *args) {
  V v_n_24301 = args[0];
  V v_m_24300 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24302 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_n_24301}));
  switch (heff_tag_of(v_x2_24302)) {
  case TAG_Left: {
    V v_e_24303 = heff_field(v_x2_24302, 0);
    V v_ru_24x2_24302_24Left = heff_take_reuse_n(v_x2_24302, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24302_24Left, TAG_Left, 1, (V[]){v_e_24303});
  }
  case TAG_Right: {
    V v_x21_24304 = heff_field(v_x2_24302, 0);
    V v_ru_24x2_24302_24Right = heff_take_reuse_n(v_x2_24302, 1ULL, 1);
    switch (heff_tag_of(v_x21_24304)) {
    case TAG_MkPair: {
      V v_x_24305 = heff_field(v_x21_24304, 0);
      V v_n_24306 = heff_field(v_x21_24304, 1);
      heff_take_n(v_x21_24304, 3ULL, 2);
      switch (heff_tag_of(v_x_24305)) {
      case TAG_MkPair: {
        V v_t_27_24307 = heff_field(v_x_24305, 0);
        heff_take_n(v_x_24305, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24302_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24307, v_n_24306})});
      }
      default: return heff_nomatch(v_x_24305);
      }
    }
    default: return heff_nomatch(v_x21_24304);
    }
  }
  default: return heff_nomatch(v_x2_24302);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam59(V self, V *args) {
  V v_n_24311 = args[0];
  V v_m_24310 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24312 = heff_tr(heff_call(v_m_24310, 1, (V[]){v_n_24311}));
  switch (heff_tag_of(v_x2_24312)) {
  case TAG_Left: {
    V v_e_24313 = heff_field(v_x2_24312, 0);
    V v_ru_24x2_24312_24Left = heff_take_reuse_n(v_x2_24312, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24312_24Left, TAG_Left, 1, (V[]){v_e_24313});
  }
  case TAG_Right: {
    V v_x21_24314 = heff_field(v_x2_24312, 0);
    V v_ru_24x2_24312_24Right = heff_take_reuse_n(v_x2_24312, 1ULL, 1);
    switch (heff_tag_of(v_x21_24314)) {
    case TAG_MkPair: {
      V v_x_24315 = heff_field(v_x21_24314, 0);
      V v_n_24316 = heff_field(v_x21_24314, 1);
      heff_take_n(v_x21_24314, 3ULL, 2);
      switch (heff_tag_of(v_x_24315)) {
      case TAG_MkPair: {
        V v_t_27_24317 = heff_field(v_x_24315, 0);
        heff_take_n(v_x_24315, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24312_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24317, v_n_24316})});
      }
      default: return heff_nomatch(v_x_24315);
      }
    }
    default: return heff_nomatch(v_x21_24314);
    }
  }
  default: return heff_nomatch(v_x2_24312);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam60(V self, V *args) {
  V v_n_24321 = args[0];
  V v_m_24320 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24322 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_n_24321}));
  switch (heff_tag_of(v_x2_24322)) {
  case TAG_Left: {
    V v_e_24323 = heff_field(v_x2_24322, 0);
    V v_ru_24x2_24322_24Left = heff_take_reuse_n(v_x2_24322, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24322_24Left, TAG_Left, 1, (V[]){v_e_24323});
  }
  case TAG_Right: {
    V v_x21_24324 = heff_field(v_x2_24322, 0);
    V v_ru_24x2_24322_24Right = heff_take_reuse_n(v_x2_24322, 1ULL, 1);
    switch (heff_tag_of(v_x21_24324)) {
    case TAG_MkPair: {
      V v_x_24325 = heff_field(v_x21_24324, 0);
      V v_n_24326 = heff_field(v_x21_24324, 1);
      heff_take_n(v_x21_24324, 3ULL, 2);
      switch (heff_tag_of(v_x_24325)) {
      case TAG_MkPair: {
        V v_t_27_24327 = heff_field(v_x_24325, 0);
        heff_take_n(v_x_24325, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24322_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24327, v_n_24326})});
      }
      default: return heff_nomatch(v_x_24325);
      }
    }
    default: return heff_nomatch(v_x21_24324);
    }
  }
  default: return heff_nomatch(v_x2_24322);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam61(V self, V *args) {
  V v_n_24331 = args[0];
  V v_m_24330 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24332 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_n_24331}));
  switch (heff_tag_of(v_x2_24332)) {
  case TAG_Left: {
    V v_e_24333 = heff_field(v_x2_24332, 0);
    V v_ru_24x2_24332_24Left = heff_take_reuse_n(v_x2_24332, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24332_24Left, TAG_Left, 1, (V[]){v_e_24333});
  }
  case TAG_Right: {
    V v_x21_24334 = heff_field(v_x2_24332, 0);
    V v_ru_24x2_24332_24Right = heff_take_reuse_n(v_x2_24332, 1ULL, 1);
    switch (heff_tag_of(v_x21_24334)) {
    case TAG_MkPair: {
      V v_x_24335 = heff_field(v_x21_24334, 0);
      V v_n_24336 = heff_field(v_x21_24334, 1);
      heff_take_n(v_x21_24334, 3ULL, 2);
      switch (heff_tag_of(v_x_24335)) {
      case TAG_MkPair: {
        V v_t_27_24337 = heff_field(v_x_24335, 0);
        heff_take_n(v_x_24335, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24332_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24337, v_n_24336})});
      }
      default: return heff_nomatch(v_x_24335);
      }
    }
    default: return heff_nomatch(v_x21_24334);
    }
  }
  default: return heff_nomatch(v_x2_24332);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam62(V self, V *args) {
  V v_n_24341 = args[0];
  V v_m_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24342 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_n_24341}));
  switch (heff_tag_of(v_x2_24342)) {
  case TAG_Left: {
    V v_e_24343 = heff_field(v_x2_24342, 0);
    V v_ru_24x2_24342_24Left = heff_take_reuse_n(v_x2_24342, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24342_24Left, TAG_Left, 1, (V[]){v_e_24343});
  }
  case TAG_Right: {
    V v_x21_24344 = heff_field(v_x2_24342, 0);
    V v_ru_24x2_24342_24Right = heff_take_reuse_n(v_x2_24342, 1ULL, 1);
    switch (heff_tag_of(v_x21_24344)) {
    case TAG_MkPair: {
      V v_x_24345 = heff_field(v_x21_24344, 0);
      V v_n_24346 = heff_field(v_x21_24344, 1);
      heff_take_n(v_x21_24344, 3ULL, 2);
      switch (heff_tag_of(v_x_24345)) {
      case TAG_MkPair: {
        V v_t_27_24347 = heff_field(v_x_24345, 0);
        heff_take_n(v_x_24345, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24342_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24347, v_n_24346})});
      }
      default: return heff_nomatch(v_x_24345);
      }
    }
    default: return heff_nomatch(v_x21_24344);
    }
  }
  default: return heff_nomatch(v_x2_24342);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam63(V self, V *args) {
  V v_n_24351 = args[0];
  V v_m_24350 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24352 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_n_24351}));
  switch (heff_tag_of(v_x2_24352)) {
  case TAG_Left: {
    V v_e_24353 = heff_field(v_x2_24352, 0);
    V v_ru_24x2_24352_24Left = heff_take_reuse_n(v_x2_24352, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24352_24Left, TAG_Left, 1, (V[]){v_e_24353});
  }
  case TAG_Right: {
    V v_x21_24354 = heff_field(v_x2_24352, 0);
    V v_ru_24x2_24352_24Right = heff_take_reuse_n(v_x2_24352, 1ULL, 1);
    switch (heff_tag_of(v_x21_24354)) {
    case TAG_MkPair: {
      V v_x_24355 = heff_field(v_x21_24354, 0);
      V v_n_24356 = heff_field(v_x21_24354, 1);
      heff_take_n(v_x21_24354, 3ULL, 2);
      switch (heff_tag_of(v_x_24355)) {
      case TAG_MkPair: {
        V v_t_27_24357 = heff_field(v_x_24355, 0);
        heff_take_n(v_x_24355, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24352_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24357, v_n_24356})});
      }
      default: return heff_nomatch(v_x_24355);
      }
    }
    default: return heff_nomatch(v_x21_24354);
    }
  }
  default: return heff_nomatch(v_x2_24352);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam64(V self, V *args) {
  V v_n_24362 = args[0];
  V v_m_24361 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24363 = heff_tr(heff_call(v_m_24361, 1, (V[]){v_n_24362}));
  switch (heff_tag_of(v_x2_24363)) {
  case TAG_Left: {
    V v_e_24364 = heff_field(v_x2_24363, 0);
    V v_ru_24x2_24363_24Left = heff_take_reuse_n(v_x2_24363, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24363_24Left, TAG_Left, 1, (V[]){v_e_24364});
  }
  case TAG_Right: {
    V v_x21_24365 = heff_field(v_x2_24363, 0);
    V v_ru_24x2_24363_24Right = heff_take_reuse_n(v_x2_24363, 1ULL, 1);
    switch (heff_tag_of(v_x21_24365)) {
    case TAG_MkPair: {
      V v_x_24366 = heff_field(v_x21_24365, 0);
      V v_n_24367 = heff_field(v_x21_24365, 1);
      heff_take_n(v_x21_24365, 3ULL, 2);
      switch (heff_tag_of(v_x_24366)) {
      case TAG_MkPair: {
        V v_t_27_24368 = heff_field(v_x_24366, 0);
        heff_take_n(v_x_24366, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24363_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24368, v_n_24367})});
      }
      default: return heff_nomatch(v_x_24366);
      }
    }
    default: return heff_nomatch(v_x21_24365);
    }
  }
  default: return heff_nomatch(v_x2_24363);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam65(V self, V *args) {
  V v_n_24372 = args[0];
  V v_m_24371 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24373 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_n_24372}));
  switch (heff_tag_of(v_x2_24373)) {
  case TAG_Left: {
    V v_e_24374 = heff_field(v_x2_24373, 0);
    V v_ru_24x2_24373_24Left = heff_take_reuse_n(v_x2_24373, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24373_24Left, TAG_Left, 1, (V[]){v_e_24374});
  }
  case TAG_Right: {
    V v_x21_24375 = heff_field(v_x2_24373, 0);
    V v_ru_24x2_24373_24Right = heff_take_reuse_n(v_x2_24373, 1ULL, 1);
    switch (heff_tag_of(v_x21_24375)) {
    case TAG_MkPair: {
      V v_x_24376 = heff_field(v_x21_24375, 0);
      V v_n_24377 = heff_field(v_x21_24375, 1);
      heff_take_n(v_x21_24375, 3ULL, 2);
      switch (heff_tag_of(v_x_24376)) {
      case TAG_MkPair: {
        V v_t_27_24378 = heff_field(v_x_24376, 0);
        heff_take_n(v_x_24376, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24373_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24378, v_n_24377})});
      }
      default: return heff_nomatch(v_x_24376);
      }
    }
    default: return heff_nomatch(v_x21_24375);
    }
  }
  default: return heff_nomatch(v_x2_24373);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_243, 2, 3)));
    V v_x_247 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_245, v_t_246});
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0, 1, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x61_249 = heff_field(v_x6_244, 0);
    V v_tail_2410 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_249)) {
    case TAG_MkPair: {
      V v_l_2411 = heff_field(v_x61_249, 0);
      V v_fe_2412 = heff_field(v_x61_249, 1);
      heff_take_n(v_x61_249, 3ULL, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_acc_243, 0))));
      V v_t_2414 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_242, 0)), heff_dup(heff_rfield(v_fieldTypes_242, 1)), heff_arrayFromList(v_t_2413)});
      V v_t_2415 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), v_l_2411, v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_MkField: {
        V v_fty_2416 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 2);
        V v_t_2418 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_fty_2416)));
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_l_2411);
          heff_drop(v_fty_2416);
          heff_drop(v_t_2418);
          V v_x1_2419 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2412, heff_dup(heff_rfield(v_c_240, 1))));
          V v_t_2423;
          switch (heff_tag_of(v_x1_2419)) {
          case TAG_Nom: {
            V v_x_2420 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            v_t_2423 = v_x_2420;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2419, 0ULL, 1);
            v_t_2423 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2422 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            v_t_2423 = v_x_2422;
            break;
          }
          default: heff_nomatch(v_x1_2419);
          }
          V v_t_2424 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_dup(heff_rfield(v_acc_243, 0))});
          V v_t_2425 = ({ V rv_0 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_acc_243, 6ULL, 3, shape_vs__out__tys, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2425;
          V t_4 = v_tail_2410;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop(v_t_2418);
          V v_m_2426 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_fe_2412), heff_dup(v_fty_2416)));
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1, 1, 9, (V[]){v_m_2426, v_c_240, v_fe_2412, v_acc_243, v_l_2411, v_fty_2416, v_capture_241, v_fieldTypes_242, v_tail_2410});
        }
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_x61_249);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_n_248})});
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2412 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_l_2411 = heff_env(self)[4];
  V v_fty_2416 = heff_env(self)[5];
  V v_capture_241 = heff_env(self)[6];
  V v_fieldTypes_242 = heff_env(self)[7];
  V v_tail_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Left: {
    V v_e_2429 = heff_field(v_x2_2428, 0);
    V v_ru_24x2_2428_24Left = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fe_2412);
    heff_drop_rec(v_acc_243, 3);
    heff_drop(v_l_2411);
    heff_drop(v_fty_2416);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    heff_drop(v_tail_2410);
    return heff_tag_at_n(v_ru_24x2_2428_24Left, TAG_Left, 1, (V[]){v_e_2429});
  }
  case TAG_Right: {
    V v_x21_2430 = heff_field(v_x2_2428, 0);
    V v_ru_24x2_2428_24Right = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
    switch (heff_tag_of(v_x21_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x21_2430, 0);
      V v_n_2432 = heff_field(v_x21_2430, 1);
      V v_ru_24x21_2430_24MkPair = heff_take_reuse_n(v_x21_2430, 3ULL, 2);
      V v_x1_2433 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2412, heff_dup(heff_rfield(v_c_240, 1))));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_Nom: {
        V v_x_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2437 = v_x_2434;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2433, 0ULL, 1);
        v_t_2437 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2436 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2437 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_take_field(v_acc_243, 0)});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_2430_24MkPair, TAG_MkPair, 2, (V[]){v_l_2411, v_x_2431}), heff_take_field(v_acc_243, 1)});
      V v_x1_2440 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2416));
      V v_t_2452;
      switch (heff_tag_of(v_x1_2440)) {
      case TAG_LikeU: {
        heff_take_n(v_x1_2440, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x1_2440, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_x1_2440, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x1_2440, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeInt: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFloat: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtFloat);
        break;
      }
      case TAG_LikeString: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRune: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x1_2440, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFixed: {
        V v_w_2451 = heff_field(v_x1_2440, 0);
        heff_take_n(v_x1_2440, 1ULL, 1);
        v_t_2452 = heff_tag_at_n(v_ru_24x2_2428_24Right, TAG_FtFixed, 1, (V[]){v_w_2451});
        break;
      }
      case TAG_NoRules: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtAny);
        break;
      }
      default: heff_nomatch(v_x1_2440);
      }
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, heff_get_n(v_acc_243, 2, 3)});
      V v_t_2454 = (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_241, v_fieldTypes_242, heff_rec_n(3, shape_vs__out__tys, (V[]){v_t_2438, v_t_2439, v_t_2453}), v_tail_2410));
      V f_ = v_t_2454;
      args[0] = v_n_2432;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2430);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2, 0, "");
Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  return (g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2), v_c_240, v_t_241, v_ty_242));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244) {
top: ;
  V v_m_246 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0, 1, 4, (V[]){v_c_240, v_ty_241, v_v_242, heff_dup(v_fs_244)}), v_ps_243));
  return heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1, 1, 1, (V[]){v_m_246});
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ty_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_fs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_c_240; V a_1 = v_ty_241; V a_2 = v_v_242; V a_3 = v_fs_244; V a_4 = v_p_245; V r_ = (g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_fs_244); r_; });
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_2411)));
      V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(v_t_2413));
      V v_t_2415 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_2411));
      V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
      V v_x_2417 = heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_ERecord, 2, (V[]){v_t_2414, v_t_2416});
      return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_n_2412})});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1(V self, V *args);

HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V v_g_240) {
top: ;
  V v_t_241 = heff_rec_n(3, shape_defs__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_249 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
  V v_acc_2412 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1, 2, 1, (V[]){v_g_240}); V a_1 = v_t_241; V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  V v_f_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_2412, 0)));
  V v_f_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_2412, 1)));
  V v_f_2415 = heff_get_n(v_acc_2412, 2, 3);
  return ((HeffT3){{v_f_2413, v_f_2414, v_f_2415}});
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_248 = v_field_246;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_243, v_e_248}), v_acc_242});
    } else {
      heff_drop(v_k_243);
      heff_drop(v_field_246);
      return v_acc_242;
    }
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_p_2411 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2eeraseOne(v_g_240, v_acc_2410, v_p_2411));
}