// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EFix 37759
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_env 310119
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_out 319944
#define LBL_ty 10476
#define LBL_tys 324872
#define LBL_values 1123329101
#define LBL_vars 10107635
#define LBL_vs 10532
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_vs__out__tys[] = {LBL_vs, LBL_out, LBL_tys};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2eargTysOf(V, V);
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eargTysOf_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V, V, V);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo;
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo;
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_clo;
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V, V);
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo;
V g_heff_2ecompile_2eerase_2eextend(V, V, V);
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eextend_clo;
V g_heff_2ecompile_2eerase_2efieldTyOr(V, V, V, V);
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2ematchVariants(V);
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ematchVariants_clo;
V g_heff_2ecompile_2eerase_2enthLocal(V, V);
V g_heff_2ecompile_2eerase_2enthLocal_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2enthLocal_clo;
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2etraverseM(V, V);
V g_heff_2ecompile_2eerase_2etraverseM_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2etraverseM_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2ecompile_2eerase_2ezipE_24dps(V, V, V);
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2erules_2efieldTyAt(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2efieldTyAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2efieldTyAt_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2eprojTyWith(V, V, V);
V g_heff_2eelab_2evalue_2eprojTyWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eprojTyWith_clo;
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eextend_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_ir_241, heff_dup(v_ty_242)}), heff_take_field(v_c_240, 0)});
  V v_t_244 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
  V v_v_246 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_244, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam0, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  V v_t_248 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_240, 1), heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam1, 1, 1, (V[]){v_v_246})});
  V v_t_249 = heff_intAdd(heff_take_field(v_c_240, 2), MK_INT(1LL));
  return ({ V rv_0 = v_t_243; V rv_1 = v_t_248; V rv_2 = v_t_249; V rr_ = heff_rec_reuse_nf(v_c_240, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eextend(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_245);
  return v_ty_242;
}
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args) {
  V v_u_247 = args[0];
  V v_v_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_247);
  return v_v_246;
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eisType_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_245;
}
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str0, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str1, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str2, 14, "the type of `.");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str3, 36, "` depends on fields not in hand here");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str4, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str5, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str6, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str7, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str8, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str9, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str10, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str11, 54, "projecting from something that is not of a record type");
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2ecompile_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  V v_t_244 = (g_heff_2eelab_2evalue_2eprojTyWith(heff_dup(v_t_241), v_fs_242, heff_dup(v_l_243)));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_LikeU: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam0_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_245, 0ULL, 4);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2414 = heff_field(v_t_245, 1);
      V v_fieldTypes_2415 = heff_field(v_t_245, 2);
      heff_take_n(v_t_245, 6ULL, 3);
      V v_t_2416 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_l_243), heff_rfield(v_fieldTypes_2415, 1)));
      V v_t_2418;
      switch (heff_tag_of(v_t_2416)) {
      case TAG_Nothing: {
        v_t_2418 = heff_abandon();
        break;
      }
      case TAG_Just: {
        V v_i_2417 = heff_field(v_t_2416, 0);
        heff_take_n(v_t_2416, 1ULL, 1);
        v_t_2418 = v_i_2417;
        break;
      }
      default: heff_nomatch(v_t_2416);
      }
      V v_t_2419 = (g_heff_2eelab_2erules_2efieldTyAt(v_len_240, v_capture_2414, v_fieldTypes_2415, v_t_2418, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam2, 1, 1, (V[]){v_l_243});
      }
      case TAG_Just: {
        V v_ty_2422 = heff_field(v_t_2419, 0);
        heff_take_n(v_t_2419, 1ULL, 1);
        heff_drop(v_l_243);
        return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2422});
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam4_clo);
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo);
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo);
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo);
    }
    case TAG_LikeRune: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo);
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      heff_drop(v_l_243);
      return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo);
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_Just: {
    V v_ty_2435 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    heff_drop(v_l_243);
    return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam12, 1, 1, (V[]){v_ty_2435});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eprojTyInWith(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_247 = args[0];
  heff_drop(v_n_247);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2412 = args[0];
  heff_drop(v_n_2412);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2420 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2420);
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str2), heff_strAppend(v_l_243, ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str3)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2423 = args[0];
  V v_ty_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2422, v_n_2423})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2425 = args[0];
  heff_drop(v_n_2425);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2426 = args[0];
  heff_drop(v_n_2426);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2427 = args[0];
  heff_drop(v_n_2427);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2428 = args[0];
  heff_drop(v_n_2428);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2429 = args[0];
  heff_drop(v_n_2429);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2431 = args[0];
  heff_drop(v_n_2431);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2433 = args[0];
  heff_drop(v_n_2433);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str10)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args) {
  V v_n_2434 = args[0];
  heff_drop(v_n_2434);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str11)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args) {
  V v_n_2436 = args[0];
  V v_ty_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2435, v_n_2436})});
}
Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2efieldTyOr_entry, 4, 0};

V g_heff_2ecompile_2eerase_2efieldTyOr(V v_len_240, V v_t_241, V v_k_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    V v_x3_244 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_LikeU: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_x3_244, 0ULL, 4);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeRecord: {
      V v_capture_2411 = heff_field(v_x3_244, 1);
      V v_fieldTypes_2412 = heff_field(v_x3_244, 2);
      heff_take_n(v_x3_244, 6ULL, 3);
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(v_k_242, heff_rfield(v_fieldTypes_2412, 1)));
      V v_t_2415;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        v_t_2415 = heff_abandon();
        break;
      }
      case TAG_Just: {
        V v_i_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        v_t_2415 = v_i_2414;
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      return (g_heff_2eelab_2erules_2efieldTyAt(v_len_240, v_capture_2411, v_fieldTypes_2412, v_t_2415, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
    }
    case TAG_LikeSum: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeInt: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeFloat: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeString: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeRune: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeArray: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_x3_244, 0ULL, 1);
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_NoRules: {
      heff_drop(v_len_240);
      heff_drop(v_k_242);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_x3_244);
    }
  }
  case TAG_Just: {
    V v_ty_2419 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    heff_drop(v_len_240);
    heff_drop(v_t_241);
    heff_drop(v_k_242);
    return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){v_ty_2419});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2efieldTyOr(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2eerase_2eargTysOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eargTysOf_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eargTysOf(V v_vs_240, V v_tag_241) {
top: ;
  V v_t_242 = (g_map_2elookup_24s1546226666x2146984184(v_tag_241, heff_rfield(v_vs_240, 1)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    heff_drop_rec(v_vs_240, 3);
    return NTAG(TAG_Nil);
  }
  case TAG_Just: {
    V v_i_243 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    V v_xs_244 = heff_get_n(v_vs_240, 2, 3);
    if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_243))) {
      if (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength(heff_dup(v_xs_244)))) {
        V v_ts_247 = heff_arrayIndex(v_xs_244, v_i_243);
        return (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_247)));
      } else {
        heff_drop(v_i_243);
        heff_drop(v_xs_244);
        return NTAG(TAG_Nil);
      }
    } else {
      heff_drop(v_i_243);
      heff_drop(v_xs_244);
      return NTAG(TAG_Nil);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eargTysOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eargTysOf(a[0], a[1]);
}
Clo g_heff_2ecompile_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eerase_2ezipE_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE(a[0], a[1]);
}
Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_24dps_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ezipE_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str1, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str2, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str3, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str4, 1, "$");
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2ecompile_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_x_243 = ({ V rv_1 = v_t_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 2, shape_c__vars, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x21_245, 0);
      V v_aty_248 = heff_field(v_x21_245, 1);
      heff_take_n(v_x21_245, 3ULL, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 2, 4);
      V v_t_2410 = (g_heff_2ecompile_2eerase_2eisType(v_t_249, heff_dup(v_aty_248)));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2ecompile_2eerase_2eextend(heff_take_field(v_acc_240, 0), NTAG(TAG_Nothing), v_aty_248));
        V v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_c__vars, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V t_0 = v_t_2412;
        V t_1 = v_rest_246;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_2410);
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam1, 1, 4, (V[]){v_x_247, v_acc_240, v_aty_248, v_rest_246});
      }
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_n_244})});
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_aty_248 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2416;
  if (heff_strEq_c(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str0))) {
    heff_drop(v_x_247);
    v_t_2416 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str1);
  } else {
    if (heff_strEq_c(heff_dup(v_x_247), ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str2))) {
      heff_drop(v_x_247);
      v_t_2416 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str3);
    } else {
      v_t_2416 = v_x_247;
    }
  }
  V v_t_2417 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2earmBindGo_str4), heff_intShow(heff_dup(v_n_2413)));
  V v_x_2418 = heff_strAppend(v_t_2416, v_t_2417);
  V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2418)})});
  V v_t_2420 = (g_heff_2ecompile_2eerase_2eextend(heff_take_field(v_acc_240, 0), v_t_2419, v_aty_248));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2418, heff_get_n(v_acc_240, 1, 2)});
  V v_t_2422 = (g_heff_2ecompile_2eerase_2earmBindGo(heff_rec_n(2, shape_c__vars, (V[]){v_t_2420, v_t_2421}), v_rest_246));
  V f_ = v_t_2422;
  args[0] = heff_intAdd(v_n_2413, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2eerase_2enthLocal_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2enthLocal_entry, 2, 0};

V g_heff_2ecompile_2eerase_2enthLocal(V v_x1_240, V v_i_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_l_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_intEq_c(heff_dup(v_i_241), MK_INT(0LL))) {
      heff_drop(v_i_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_l_242)});
    } else {
      if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
        heff_drop(v_i_241);
        return NTAG(TAG_Nothing);
      } else {
        V t_0 = v_rest_243;
        V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
        v_x1_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2enthLocal_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eerase_2enthLocal(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0, 27, "this needs an expected type");
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry, 3, 0};

V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V v_c_240, V v_vs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    return ((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        V v_t_2410 = heff_rec_n(2, shape_c__vars, (V[]){heff_dup(v_c_240), NTAG(TAG_Nil)});
        V v_t_2411 = (g_heff_2ecompile_2eerase_2eargTysOf(heff_dup(v_vs_241), v_tag_246));
        V v_t_2412 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_xs_248), v_t_2411));
        V v_m_2413 = (g_heff_2ecompile_2eerase_2earmBindGo(v_t_2410, v_t_2412));
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1, 1, 5, (V[]){v_m_2413, v_body_249, v_c_240, v_vs_241, v_tail_245});
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0)});
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_m_2413 = heff_env(self)[0];
  V v_body_249 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_tail_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2415 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_n_2414}));
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Left: {
    V v_e_2416 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Left = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    heff_drop(v_body_249);
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_tail_245);
    return heff_tag_at_n(v_ru_24x2_2415_24Left, TAG_Left, 1, (V[]){v_e_2416});
  }
  case TAG_Right: {
    V v_x21_2417 = heff_field(v_x2_2415, 0);
    V v_ru_24x2_2415_24Right = heff_take_reuse_n(v_x2_2415, 1ULL, 1);
    switch (heff_tag_of(v_x21_2417)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x21_2417, 0);
      V v_n_2419 = heff_field(v_x21_2417, 1);
      heff_take_n(v_x21_2417, 3ULL, 2);
      V v_m_2420 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_get_n(v_x_2418, 0, 2), v_body_249));
      V v_x2_2421 = heff_tr(heff_call(v_m_2420, 1, (V[]){heff_dup(v_n_2419)}));
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Left: {
        heff_take_n(v_x2_2421, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2415_24Right, 1);
        V v_t_2423 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(v_c_240, v_vs_241, v_tail_245));
        V f_ = v_t_2423;
        args[0] = v_n_2419;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Right: {
        V v_x21_2424 = heff_field(v_x2_2421, 0);
        heff_take_n(v_x2_2421, 1ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_vs_241);
        heff_drop(v_tail_245);
        heff_drop(v_n_2419);
        switch (heff_tag_of(v_x21_2424)) {
        case TAG_MkPair: {
          V v_x_2425 = heff_field(v_x21_2424, 0);
          V v_n_27_2426 = heff_field(v_x21_2424, 1);
          heff_take_n(v_x21_2424, 3ULL, 2);
          switch (heff_tag_of(v_x_2425)) {
          case TAG_MkPair: {
            V v_ty_2428 = heff_field(v_x_2425, 1);
            heff_take_n(v_x_2425, 2ULL, 2);
            return heff_tag_at_n(v_ru_24x2_2415_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2428, v_n_27_2426})});
          }
          default: return heff_nomatch(v_x_2425);
          }
        }
        default: return heff_nomatch(v_x21_2424);
        }
      }
      default: return heff_nomatch(v_x2_2421);
      }
    }
    default: return heff_nomatch(v_x21_2417);
    }
  }
  default: return heff_nomatch(v_x2_2415);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_243, 2, 3)));
    V v_x_247 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_245, v_t_246});
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0, 1, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x61_249 = heff_field(v_x6_244, 0);
    V v_tail_2410 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_249)) {
    case TAG_MkPair: {
      V v_l_2411 = heff_field(v_x61_249, 0);
      V v_fe_2412 = heff_field(v_x61_249, 1);
      heff_take_n(v_x61_249, 3ULL, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_acc_243, 0))));
      V v_t_2414 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_242, 0)), heff_dup(heff_rfield(v_fieldTypes_242, 1)), heff_arrayFromList(v_t_2413)});
      V v_t_2415 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), heff_dup(v_l_2411), v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_MkField: {
        V v_fty_2416 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 2);
        V v_t_2418 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_fty_2416)));
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_l_2411);
          heff_drop(v_fty_2416);
          heff_drop(v_t_2418);
          V v_x1_2419 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2412, heff_dup(heff_rfield(v_c_240, 1))));
          V v_t_2423;
          switch (heff_tag_of(v_x1_2419)) {
          case TAG_Nom: {
            V v_x_2420 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            v_t_2423 = v_x_2420;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2419, 0ULL, 1);
            v_t_2423 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2422 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            v_t_2423 = v_x_2422;
            break;
          }
          default: heff_nomatch(v_x1_2419);
          }
          V v_t_2424 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_dup(heff_rfield(v_acc_243, 0))});
          V v_t_2425 = ({ V rv_0 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_acc_243, 6ULL, 3, shape_vs__out__tys, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2425;
          V t_4 = v_tail_2410;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop(v_t_2418);
          V v_m_2426 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_fe_2412), heff_dup(v_fty_2416)));
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1, 1, 9, (V[]){v_m_2426, v_c_240, v_fe_2412, v_acc_243, v_l_2411, v_fty_2416, v_capture_241, v_fieldTypes_242, v_tail_2410});
        }
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_x61_249);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_n_248})});
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2412 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_l_2411 = heff_env(self)[4];
  V v_fty_2416 = heff_env(self)[5];
  V v_capture_241 = heff_env(self)[6];
  V v_fieldTypes_242 = heff_env(self)[7];
  V v_tail_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Left: {
    V v_e_2429 = heff_field(v_x2_2428, 0);
    V v_ru_24x2_2428_24Left = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fe_2412);
    heff_drop_rec(v_acc_243, 3);
    heff_drop(v_l_2411);
    heff_drop(v_fty_2416);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    heff_drop(v_tail_2410);
    return heff_tag_at_n(v_ru_24x2_2428_24Left, TAG_Left, 1, (V[]){v_e_2429});
  }
  case TAG_Right: {
    V v_x21_2430 = heff_field(v_x2_2428, 0);
    V v_ru_24x2_2428_24Right = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
    switch (heff_tag_of(v_x21_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x21_2430, 0);
      V v_n_2432 = heff_field(v_x21_2430, 1);
      V v_ru_24x21_2430_24MkPair = heff_take_reuse_n(v_x21_2430, 3ULL, 2);
      V v_x1_2433 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2412, heff_dup(heff_rfield(v_c_240, 1))));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_Nom: {
        V v_x_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2437 = v_x_2434;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2433, 0ULL, 1);
        v_t_2437 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2436 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2437 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_take_field(v_acc_243, 0)});
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_2430_24MkPair, TAG_MkPair, 2, (V[]){v_l_2411, v_x_2431}), heff_take_field(v_acc_243, 1)});
      V v_x1_2440 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2416));
      V v_t_2452;
      switch (heff_tag_of(v_x1_2440)) {
      case TAG_LikeU: {
        heff_take_n(v_x1_2440, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x1_2440, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_x1_2440, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x1_2440, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeInt: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFloat: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtFloat);
        break;
      }
      case TAG_LikeString: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRune: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x1_2440, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFixed: {
        V v_w_2451 = heff_field(v_x1_2440, 0);
        heff_take_n(v_x1_2440, 1ULL, 1);
        v_t_2452 = heff_tag_at_n(v_ru_24x2_2428_24Right, TAG_FtFixed, 1, (V[]){v_w_2451});
        break;
      }
      case TAG_NoRules: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2452 = NTAG(TAG_FtAny);
        break;
      }
      default: heff_nomatch(v_x1_2440);
      }
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, heff_get_n(v_acc_243, 2, 3)});
      V v_t_2454 = (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_241, v_fieldTypes_242, heff_rec_n(3, shape_vs__out__tys, (V[]){v_t_2438, v_t_2439, v_t_2453}), v_tail_2410));
      V f_ = v_t_2454;
      args[0] = v_n_2432;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2430);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0, 26, "a type in a value position");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str3, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str4, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str5, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str6, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str7, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str8, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str9, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str10, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str11, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str12, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str13, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str14, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str15, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str16, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str17, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str18, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str19, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str20, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str21, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str22, 14, "an opaque term");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str23, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str24, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str25, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str26, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str27, 1, "$");
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam19(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam20(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam29(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam30(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32, 1, 0};
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam34(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam35(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam36(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam37(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam38(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam39(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam40(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam41(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam42(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam43(V self, V *args);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam44(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  switch (heff_tag_of(v_t_241)) {
  case TAG_SLocal: {
    heff_drop(v_ty_242);
    V v_m_244 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam0, 1, 1, (V[]){v_m_244});
  }
  case TAG_SGlobal: {
    heff_drop(v_ty_242);
    V v_m_2414 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam1, 1, 1, (V[]){v_m_2414});
  }
  case TAG_SCode: {
    heff_take_n(v_t_241, 0ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2_clo);
  }
  case TAG_SApp: {
    heff_drop(v_ty_242);
    V v_m_2427 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam3, 1, 1, (V[]){v_m_2427});
  }
  case TAG_SLam: {
    V v_abs_2437 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    HEFF_LAST return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145(v_c_240, v_abs_2437, v_ty_242);
  }
  case TAG_SCons: {
    V v_d_2438 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V v_t_2439 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2439, 0ULL, 4);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5_clo);
    }
    case TAG_LikeRecord: {
      V v_capture_2448 = heff_field(v_t_2439, 1);
      V v_fieldTypes_2449 = heff_field(v_t_2439, 2);
      heff_take_n(v_t_2439, 6ULL, 3);
      V v_t_2450 = heff_rec_n(3, shape_vs__out__tys, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
      V v_t_2451 = heff_arrayToList(heff_take_field(v_d_2438, 0));
      V v_t_2452 = heff_arrayToList(heff_get_n(v_d_2438, 2, 3));
      V v_t_2453 = (g_heff_2eutil_2edict_2ezipKV(v_t_2451, v_t_2452));
      return (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_2448, v_fieldTypes_2449, v_t_2450, v_t_2453));
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6_clo);
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2439, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_240, 4);
      heff_drop_rec(v_d_2438, 3);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13_clo);
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_SProj: {
    heff_drop(v_ty_242);
    V v_m_2467 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14, 1, 1, (V[]){v_m_2467});
  }
  case TAG_STag: {
    V v_x_2476 = heff_field(v_t_241, 0);
    V v_args_2477 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_t_2478 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_242));
    switch (heff_tag_of(v_t_2478)) {
    case TAG_LikeU: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15_clo);
    }
    case TAG_LikeFunction: {
      heff_take_n(v_t_2478, 0ULL, 4);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16_clo);
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_2478, 0ULL, 3);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17_clo);
    }
    case TAG_LikeSum: {
      V v_vs_2490 = heff_field(v_t_2478, 0);
      V v_ru_24t_2478_24LikeSum = heff_take_reuse_n(v_t_2478, 1ULL, 1);
      V v_t_2491 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_2476), heff_rfield(v_vs_2490, 1)));
      V v_t_2497;
      switch (heff_tag_of(v_t_2491)) {
      case TAG_Nothing: {
        heff_drop_rec(v_vs_2490, 3);
        heff_drop_cell(v_ru_24t_2478_24LikeSum, 1);
        v_t_2497 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_i_2492 = heff_field(v_t_2491, 0);
        heff_take_n(v_t_2491, 1ULL, 1);
        V v_xs_2493 = heff_get_n(v_vs_2490, 2, 3);
        if (heff_intLe_c(MK_INT(0LL), heff_dup(v_i_2492))) {
          if (heff_intLt_c(heff_dup(v_i_2492), heff_arrayLength(heff_dup(v_xs_2493)))) {
            V v_t_2496 = heff_arrayIndex(v_xs_2493, v_i_2492);
            v_t_2497 = heff_tag_at_n(v_ru_24t_2478_24LikeSum, TAG_Just, 1, (V[]){v_t_2496});
          } else {
            heff_drop_cell(v_ru_24t_2478_24LikeSum, 1);
            heff_drop(v_i_2492);
            heff_drop(v_xs_2493);
            v_t_2497 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24t_2478_24LikeSum, 1);
          heff_drop(v_i_2492);
          heff_drop(v_xs_2493);
          v_t_2497 = NTAG(TAG_Nothing);
        }
        break;
      }
      default: heff_nomatch(v_t_2491);
      }
      switch (heff_tag_of(v_t_2497)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_240, 4);
        heff_drop(v_args_2477);
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18, 1, 1, (V[]){v_x_2476});
      }
      case TAG_Just: {
        V v_ts_2499 = heff_field(v_t_2497, 0);
        heff_take_n(v_t_2497, 1ULL, 1);
        V v_t_24100 = (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_2499)));
        V v_t_24101 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_args_2477), v_t_24100));
        V v_m_24103 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam19, 1, 1, (V[]){v_c_240}), v_t_24101));
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam20, 1, 2, (V[]){v_m_24103, v_x_2476});
      }
      default: return heff_nomatch(v_t_2497);
      }
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_2478, 0ULL, 1);
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_240, 4);
      heff_drop(v_x_2476);
      heff_drop(v_args_2477);
      return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27_clo);
    }
    default: return heff_nomatch(v_t_2478);
    }
  }
  case TAG_SMatch: {
    V v_scrut_24124 = heff_field(v_t_241, 0);
    V v_cases_24125 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 3ULL, 2);
    V v_m_24126 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_240), v_scrut_24124));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28, 1, 4, (V[]){v_m_24126, v_cases_24125, v_c_240, v_ty_242});
  }
  case TAG_SSpecialize: {
    heff_drop(v_ty_242);
    V v_m_24155 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam30, 1, 1, (V[]){v_m_24155});
  }
  case TAG_SIs: {
    V v_t_27_24164 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24164;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31_clo);
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32_clo);
  }
  case TAG_SRec: {
    V v_t_27_24168 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24168;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SFix: {
    V v_t2_27_24170 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    switch (heff_tag_of(v_t2_27_24170)) {
    case TAG_MkAbs: {
      V v_x_24171 = heff_field(v_t2_27_24170, 0);
      V v_body_24172 = heff_field(v_t2_27_24170, 1);
      heff_take_n(v_t2_27_24170, 3ULL, 2);
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33, 1, 4, (V[]){v_x_24171, v_ty_242, v_c_240, v_body_24172});
    }
    case TAG_AbsConst: {
      V v_body_24195 = heff_field(v_t2_27_24170, 0);
      heff_take_n(v_t2_27_24170, 1ULL, 1);
      V t_0 = v_c_240;
      V t_1 = v_body_24195;
      V t_2 = v_ty_242;
      v_c_240 = t_0;
      v_t_241 = t_1;
      v_ty_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t2_27_24170);
    }
  }
  case TAG_SImplicit: {
    V v_t_27_24197 = heff_field(v_t_241, 1);
    heff_take_n(v_t_241, 2ULL, 2);
    V t_0 = v_c_240;
    V t_1 = v_t_27_24197;
    V t_2 = v_ty_242;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_ty_242 = t_2;
    goto top;
  }
  case TAG_SPrim: {
    V v_x_24198 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam36, 1, 1, (V[]){v_x_24198});
  }
  case TAG_SMetaApp: {
    heff_drop(v_ty_242);
    V v_m_24204 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam37, 1, 1, (V[]){v_m_24204});
  }
  case TAG_SLitInt: {
    heff_drop(v_ty_242);
    V v_m_24214 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam38, 1, 1, (V[]){v_m_24214});
  }
  case TAG_SLitFloat: {
    heff_drop(v_ty_242);
    V v_m_24224 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam39, 1, 1, (V[]){v_m_24224});
  }
  case TAG_SLitString: {
    heff_drop(v_ty_242);
    V v_m_24234 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam40, 1, 1, (V[]){v_m_24234});
  }
  case TAG_SLitBytes: {
    heff_drop(v_ty_242);
    V v_m_24244 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam41, 1, 1, (V[]){v_m_24244});
  }
  case TAG_SLitRune: {
    heff_drop(v_ty_242);
    V v_m_24254 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam42, 1, 1, (V[]){v_m_24254});
  }
  case TAG_SLitFixed: {
    heff_drop(v_ty_242);
    V v_m_24265 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam43, 1, 1, (V[]){v_m_24265});
  }
  case TAG_SLitFloat32: {
    heff_drop(v_ty_242);
    V v_m_24275 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_240, v_t_241));
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam44, 1, 1, (V[]){v_m_24275});
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam0(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Left: {
    V v_e_247 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Left = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_246_24Left, TAG_Left, 1, (V[]){v_e_247});
  }
  case TAG_Right: {
    V v_x21_248 = heff_field(v_x2_246, 0);
    V v_ru_24x2_246_24Right = heff_take_reuse_n(v_x2_246, 1ULL, 1);
    switch (heff_tag_of(v_x21_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x21_248, 0);
      V v_n_2410 = heff_field(v_x21_248, 1);
      heff_take_n(v_x21_248, 3ULL, 2);
      switch (heff_tag_of(v_x_249)) {
      case TAG_MkPair: {
        V v_t_27_2411 = heff_field(v_x_249, 0);
        heff_take_n(v_x_249, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_246_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2411, v_n_2410})});
      }
      default: return heff_nomatch(v_x_249);
      }
    }
    default: return heff_nomatch(v_x21_248);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_m_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2416 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_n_2415}));
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Left: {
    V v_e_2417 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Left = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2416_24Left, TAG_Left, 1, (V[]){v_e_2417});
  }
  case TAG_Right: {
    V v_x21_2418 = heff_field(v_x2_2416, 0);
    V v_ru_24x2_2416_24Right = heff_take_reuse_n(v_x2_2416, 1ULL, 1);
    switch (heff_tag_of(v_x21_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x21_2418, 0);
      V v_n_2420 = heff_field(v_x21_2418, 1);
      heff_take_n(v_x21_2418, 3ULL, 2);
      switch (heff_tag_of(v_x_2419)) {
      case TAG_MkPair: {
        V v_t_27_2421 = heff_field(v_x_2419, 0);
        heff_take_n(v_x_2419, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2416_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2421, v_n_2420})});
      }
      default: return heff_nomatch(v_x_2419);
      }
    }
    default: return heff_nomatch(v_x21_2418);
    }
  }
  default: return heff_nomatch(v_x2_2416);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam2(V self, V *args) {
  V v_n_2424 = args[0];
  heff_drop(v_n_2424);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam3(V self, V *args) {
  V v_n_2428 = args[0];
  V v_m_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2429 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_n_2428}));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Left: {
    V v_e_2430 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Left = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2429_24Left, TAG_Left, 1, (V[]){v_e_2430});
  }
  case TAG_Right: {
    V v_x21_2431 = heff_field(v_x2_2429, 0);
    V v_ru_24x2_2429_24Right = heff_take_reuse_n(v_x2_2429, 1ULL, 1);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x21_2431, 0);
      V v_n_2433 = heff_field(v_x21_2431, 1);
      heff_take_n(v_x21_2431, 3ULL, 2);
      switch (heff_tag_of(v_x_2432)) {
      case TAG_MkPair: {
        V v_t_27_2434 = heff_field(v_x_2432, 0);
        heff_take_n(v_x_2432, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2429_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2434, v_n_2433})});
      }
      default: return heff_nomatch(v_x_2432);
      }
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam4(V self, V *args) {
  V v_n_2441 = args[0];
  heff_drop(v_n_2441);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam5(V self, V *args) {
  V v_n_2446 = args[0];
  heff_drop(v_n_2446);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam6(V self, V *args) {
  V v_n_2455 = args[0];
  heff_drop(v_n_2455);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str3)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam7(V self, V *args) {
  V v_n_2456 = args[0];
  heff_drop(v_n_2456);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str4)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam8(V self, V *args) {
  V v_n_2457 = args[0];
  heff_drop(v_n_2457);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str5)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam9(V self, V *args) {
  V v_n_2458 = args[0];
  heff_drop(v_n_2458);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str6)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam10(V self, V *args) {
  V v_n_2459 = args[0];
  heff_drop(v_n_2459);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str7)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam11(V self, V *args) {
  V v_n_2461 = args[0];
  heff_drop(v_n_2461);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str8)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam12(V self, V *args) {
  V v_n_2463 = args[0];
  heff_drop(v_n_2463);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str9)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam13(V self, V *args) {
  V v_n_2464 = args[0];
  heff_drop(v_n_2464);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str10)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam14(V self, V *args) {
  V v_n_2468 = args[0];
  V v_m_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2469 = heff_tr(heff_call(v_m_2467, 1, (V[]){v_n_2468}));
  switch (heff_tag_of(v_x2_2469)) {
  case TAG_Left: {
    V v_e_2470 = heff_field(v_x2_2469, 0);
    V v_ru_24x2_2469_24Left = heff_take_reuse_n(v_x2_2469, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2469_24Left, TAG_Left, 1, (V[]){v_e_2470});
  }
  case TAG_Right: {
    V v_x21_2471 = heff_field(v_x2_2469, 0);
    V v_ru_24x2_2469_24Right = heff_take_reuse_n(v_x2_2469, 1ULL, 1);
    switch (heff_tag_of(v_x21_2471)) {
    case TAG_MkPair: {
      V v_x_2472 = heff_field(v_x21_2471, 0);
      V v_n_2473 = heff_field(v_x21_2471, 1);
      heff_take_n(v_x21_2471, 3ULL, 2);
      switch (heff_tag_of(v_x_2472)) {
      case TAG_MkPair: {
        V v_t_27_2474 = heff_field(v_x_2472, 0);
        heff_take_n(v_x_2472, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2469_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_2474, v_n_2473})});
      }
      default: return heff_nomatch(v_x_2472);
      }
    }
    default: return heff_nomatch(v_x21_2471);
    }
  }
  default: return heff_nomatch(v_x2_2469);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam15(V self, V *args) {
  V v_n_2480 = args[0];
  heff_drop(v_n_2480);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str11)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam16(V self, V *args) {
  V v_n_2485 = args[0];
  heff_drop(v_n_2485);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str12)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam17(V self, V *args) {
  V v_n_2489 = args[0];
  heff_drop(v_n_2489);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str13)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam18(V self, V *args) {
  V v_n_2498 = args[0];
  V v_x_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2498);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str14), v_x_2476)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam19(V self, V *args) {
  V v_p_24102 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(v_c_240, v_p_24102));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam20(V self, V *args) {
  V v_n_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_x_2476 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_n_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_Left: {
    V v_e_24106 = heff_field(v_x2_24105, 0);
    V v_ru_24x2_24105_24Left = heff_take_reuse_n(v_x2_24105, 1ULL, 1);
    heff_drop(v_x_2476);
    return heff_tag_at_n(v_ru_24x2_24105_24Left, TAG_Left, 1, (V[]){v_e_24106});
  }
  case TAG_Right: {
    V v_x21_24107 = heff_field(v_x2_24105, 0);
    V v_ru_24x2_24105_24Right = heff_take_reuse_n(v_x2_24105, 1ULL, 1);
    switch (heff_tag_of(v_x21_24107)) {
    case TAG_MkPair: {
      V v_x_24108 = heff_field(v_x21_24107, 0);
      V v_n_24109 = heff_field(v_x21_24107, 1);
      heff_take_n(v_x21_24107, 3ULL, 2);
      V v_t_24110 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_24108)));
      V v_t_24111 = (g_list_2emap_24s1937570095x2110149801(v_t_24110));
      V v_t_24112 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_24108));
      V v_t_24113 = (g_list_2emap_24s1173914895x100384474(v_t_24112));
      V v_x_24114 = heff_tag_n(TAG_ETag, 3, (V[]){v_x_2476, v_t_24111, v_t_24113});
      return heff_tag_at_n(v_ru_24x2_24105_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24114, v_n_24109})});
    }
    default: return heff_nomatch(v_x21_24107);
    }
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam21(V self, V *args) {
  V v_n_24115 = args[0];
  heff_drop(v_n_24115);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str15)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam22(V self, V *args) {
  V v_n_24116 = args[0];
  heff_drop(v_n_24116);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str16)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam23(V self, V *args) {
  V v_n_24117 = args[0];
  heff_drop(v_n_24117);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str17)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam24(V self, V *args) {
  V v_n_24118 = args[0];
  heff_drop(v_n_24118);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str18)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam25(V self, V *args) {
  V v_n_24120 = args[0];
  heff_drop(v_n_24120);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str19)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam26(V self, V *args) {
  V v_n_24122 = args[0];
  heff_drop(v_n_24122);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str20)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam27(V self, V *args) {
  V v_n_24123 = args[0];
  heff_drop(v_n_24123);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str21)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam29(V self, V *args) {
  V v_p_24144 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_x_24139 = heff_env(self)[1];
  V v_ty_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_240, v_x_24139, v_ty_242, v_p_24144));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam28(V self, V *args) {
  V v_n_24127 = args[0];
  V v_m_24126 = heff_env(self)[0];
  V v_cases_24125 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_ty_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_24128 = heff_tr(heff_call(v_m_24126, 1, (V[]){v_n_24127}));
  switch (heff_tag_of(v_x2_24128)) {
  case TAG_Left: {
    V v_e_24129 = heff_field(v_x2_24128, 0);
    V v_ru_24x2_24128_24Left = heff_take_reuse_n(v_x2_24128, 1ULL, 1);
    heff_drop_rec(v_cases_24125, 3);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_ty_242);
    return heff_tag_at_n(v_ru_24x2_24128_24Left, TAG_Left, 1, (V[]){v_e_24129});
  }
  case TAG_Right: {
    V v_x21_24130 = heff_field(v_x2_24128, 0);
    V v_ru_24x2_24128_24Right = heff_take_reuse_n(v_x2_24128, 1ULL, 1);
    switch (heff_tag_of(v_x21_24130)) {
    case TAG_MkPair: {
      V v_x_24131 = heff_field(v_x21_24130, 0);
      V v_n_24132 = heff_field(v_x21_24130, 1);
      V v_ru_24x21_24130_24MkPair = heff_take_reuse_n(v_x21_24130, 3ULL, 2);
      switch (heff_tag_of(v_x_24131)) {
      case TAG_MkPair: {
        V v_s_27_24133 = heff_field(v_x_24131, 0);
        V v_sty_24134 = heff_field(v_x_24131, 1);
        heff_take_n(v_x_24131, 3ULL, 2);
        V v_m_24135 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24134));
        V v_x2_24136 = heff_tr(heff_call(v_m_24135, 1, (V[]){v_n_24132}));
        switch (heff_tag_of(v_x2_24136)) {
        case TAG_Left: {
          V v_e_24137 = heff_field(v_x2_24136, 0);
          V v_ru_24x2_24136_24Left = heff_take_reuse_n(v_x2_24136, 1ULL, 1);
          heff_drop_rec(v_cases_24125, 3);
          heff_drop_rec(v_c_240, 4);
          heff_drop(v_ty_242);
          heff_drop_cell(v_ru_24x2_24128_24Right, 1);
          heff_drop_cell(v_ru_24x21_24130_24MkPair, 2);
          heff_drop(v_s_27_24133);
          return heff_tag_at_n(v_ru_24x2_24136_24Left, TAG_Left, 1, (V[]){v_e_24137});
        }
        case TAG_Right: {
          V v_x21_24138 = heff_field(v_x2_24136, 0);
          V v_ru_24x2_24136_24Right = heff_take_reuse_n(v_x2_24136, 1ULL, 1);
          switch (heff_tag_of(v_x21_24138)) {
          case TAG_MkPair: {
            V v_x_24139 = heff_field(v_x21_24138, 0);
            V v_n_24140 = heff_field(v_x21_24138, 1);
            heff_take_n(v_x21_24138, 3ULL, 2);
            V v_t_24141 = heff_arrayToList(heff_take_field(v_cases_24125, 0));
            V v_t_24142 = heff_arrayToList(heff_get_n(v_cases_24125, 2, 3));
            V v_t_24143 = (g_heff_2eutil_2edict_2ezipKV(v_t_24141, v_t_24142));
            V v_m_24145 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam29, 1, 3, (V[]){v_c_240, v_x_24139, v_ty_242}), v_t_24143));
            V v_x2_24146 = heff_tr(heff_call(v_m_24145, 1, (V[]){v_n_24140}));
            switch (heff_tag_of(v_x2_24146)) {
            case TAG_Left: {
              V v_e_24147 = heff_field(v_x2_24146, 0);
              heff_take_n(v_x2_24146, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_24128_24Right, 1);
              heff_drop_cell(v_ru_24x21_24130_24MkPair, 2);
              heff_drop(v_s_27_24133);
              return heff_tag_at_n(v_ru_24x2_24136_24Right, TAG_Left, 1, (V[]){v_e_24147});
            }
            case TAG_Right: {
              V v_x21_24148 = heff_field(v_x2_24146, 0);
              heff_take_n(v_x2_24146, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_24136_24Right, 1);
              switch (heff_tag_of(v_x21_24148)) {
              case TAG_MkPair: {
                V v_x_24149 = heff_field(v_x21_24148, 0);
                V v_n_24150 = heff_field(v_x21_24148, 1);
                heff_take_n(v_x21_24148, 3ULL, 2);
                V v_t_24151 = heff_tag_at_n(v_ru_24x21_24130_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_24133, v_x_24149}), v_n_24150});
                return heff_tag_at_n(v_ru_24x2_24128_24Right, TAG_Right, 1, (V[]){v_t_24151});
              }
              default: return heff_nomatch(v_x21_24148);
              }
            }
            default: return heff_nomatch(v_x2_24146);
            }
          }
          default: return heff_nomatch(v_x21_24138);
          }
        }
        default: return heff_nomatch(v_x2_24136);
        }
      }
      default: return heff_nomatch(v_x_24131);
      }
    }
    default: return heff_nomatch(v_x21_24130);
    }
  }
  default: return heff_nomatch(v_x2_24128);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam30(V self, V *args) {
  V v_n_24156 = args[0];
  V v_m_24155 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24157 = heff_tr(heff_call(v_m_24155, 1, (V[]){v_n_24156}));
  switch (heff_tag_of(v_x2_24157)) {
  case TAG_Left: {
    V v_e_24158 = heff_field(v_x2_24157, 0);
    V v_ru_24x2_24157_24Left = heff_take_reuse_n(v_x2_24157, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24157_24Left, TAG_Left, 1, (V[]){v_e_24158});
  }
  case TAG_Right: {
    V v_x21_24159 = heff_field(v_x2_24157, 0);
    V v_ru_24x2_24157_24Right = heff_take_reuse_n(v_x2_24157, 1ULL, 1);
    switch (heff_tag_of(v_x21_24159)) {
    case TAG_MkPair: {
      V v_x_24160 = heff_field(v_x21_24159, 0);
      V v_n_24161 = heff_field(v_x21_24159, 1);
      heff_take_n(v_x21_24159, 3ULL, 2);
      switch (heff_tag_of(v_x_24160)) {
      case TAG_MkPair: {
        V v_t_27_24162 = heff_field(v_x_24160, 0);
        heff_take_n(v_x_24160, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24157_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24162, v_n_24161})});
      }
      default: return heff_nomatch(v_x_24160);
      }
    }
    default: return heff_nomatch(v_x21_24159);
    }
  }
  default: return heff_nomatch(v_x2_24157);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam31(V self, V *args) {
  V v_n_24165 = args[0];
  heff_drop(v_n_24165);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str22)});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam32(V self, V *args) {
  V v_n_24166 = args[0];
  V v_t_24167 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24166});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24167});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam34(V self, V *args) {
  V v_u_24182 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24182);
  return v_ty_242;
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam35(V self, V *args) {
  V v_u_24184 = args[0];
  V v_v_24183 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24184);
  return v_v_24183;
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam33(V self, V *args) {
  V v_n_24173 = args[0];
  V v_x_24171 = heff_env(self)[0];
  V v_ty_242 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_body_24172 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24176;
  if (heff_strEq_c(heff_dup(v_x_24171), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str23))) {
    heff_drop(v_x_24171);
    v_t_24176 = ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str24);
  } else {
    if (heff_strEq_c(heff_dup(v_x_24171), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str25))) {
      heff_drop(v_x_24171);
      v_t_24176 = ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str26);
    } else {
      v_t_24176 = v_x_24171;
    }
  }
  V v_t_24177 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str27), heff_intShow(heff_dup(v_n_24173)));
  V v_x_24178 = heff_strAppend(v_t_24176, v_t_24177);
  V v_t_24179 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24178)})});
  V v_t_24180 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_24179, heff_dup(v_ty_242)}), heff_take_field(v_c_240, 0)});
  V v_t_24181 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
  V v_v_24183 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24181, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam34, 1, 1, (V[]){heff_dup(v_ty_242)}), NTAG(TAG_Nothing)));
  V v_t_24185 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_240, 1), heff_clo_n(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam35, 1, 1, (V[]){v_v_24183})});
  V v_t_24186 = heff_intAdd(heff_take_field(v_c_240, 2), MK_INT(1LL));
  V v_c_24187 = ({ V rv_0 = v_t_24180; V rv_1 = v_t_24185; V rv_2 = v_t_24186; V rr_ = heff_rec_reuse_nf(v_c_240, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_m_24188 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_24187, v_body_24172, v_ty_242));
  V v_x2_24189 = heff_tr(heff_call(v_m_24188, 1, (V[]){heff_intAdd(v_n_24173, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24189)) {
  case TAG_Left: {
    V v_e_24190 = heff_field(v_x2_24189, 0);
    V v_ru_24x2_24189_24Left = heff_take_reuse_n(v_x2_24189, 1ULL, 1);
    heff_drop(v_x_24178);
    return heff_tag_at_n(v_ru_24x2_24189_24Left, TAG_Left, 1, (V[]){v_e_24190});
  }
  case TAG_Right: {
    V v_x21_24191 = heff_field(v_x2_24189, 0);
    V v_ru_24x2_24189_24Right = heff_take_reuse_n(v_x2_24189, 1ULL, 1);
    switch (heff_tag_of(v_x21_24191)) {
    case TAG_MkPair: {
      V v_x_24192 = heff_field(v_x21_24191, 0);
      V v_n_24193 = heff_field(v_x21_24191, 1);
      V v_ru_24x21_24191_24MkPair = heff_take_reuse_n(v_x21_24191, 3ULL, 2);
      V v_t_24194 = heff_tag_at_n(v_ru_24x21_24191_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24178, v_x_24192}), v_n_24193});
      return heff_tag_at_n(v_ru_24x2_24189_24Right, TAG_Right, 1, (V[]){v_t_24194});
    }
    default: return heff_nomatch(v_x21_24191);
    }
  }
  default: return heff_nomatch(v_x2_24189);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam36(V self, V *args) {
  V v_n_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24200 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24198}), v_n_24199});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24200});
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam37(V self, V *args) {
  V v_n_24205 = args[0];
  V v_m_24204 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24206 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_n_24205}));
  switch (heff_tag_of(v_x2_24206)) {
  case TAG_Left: {
    V v_e_24207 = heff_field(v_x2_24206, 0);
    V v_ru_24x2_24206_24Left = heff_take_reuse_n(v_x2_24206, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24206_24Left, TAG_Left, 1, (V[]){v_e_24207});
  }
  case TAG_Right: {
    V v_x21_24208 = heff_field(v_x2_24206, 0);
    V v_ru_24x2_24206_24Right = heff_take_reuse_n(v_x2_24206, 1ULL, 1);
    switch (heff_tag_of(v_x21_24208)) {
    case TAG_MkPair: {
      V v_x_24209 = heff_field(v_x21_24208, 0);
      V v_n_24210 = heff_field(v_x21_24208, 1);
      heff_take_n(v_x21_24208, 3ULL, 2);
      switch (heff_tag_of(v_x_24209)) {
      case TAG_MkPair: {
        V v_t_27_24211 = heff_field(v_x_24209, 0);
        heff_take_n(v_x_24209, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24206_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24211, v_n_24210})});
      }
      default: return heff_nomatch(v_x_24209);
      }
    }
    default: return heff_nomatch(v_x21_24208);
    }
  }
  default: return heff_nomatch(v_x2_24206);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam38(V self, V *args) {
  V v_n_24215 = args[0];
  V v_m_24214 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24216 = heff_tr(heff_call(v_m_24214, 1, (V[]){v_n_24215}));
  switch (heff_tag_of(v_x2_24216)) {
  case TAG_Left: {
    V v_e_24217 = heff_field(v_x2_24216, 0);
    V v_ru_24x2_24216_24Left = heff_take_reuse_n(v_x2_24216, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24216_24Left, TAG_Left, 1, (V[]){v_e_24217});
  }
  case TAG_Right: {
    V v_x21_24218 = heff_field(v_x2_24216, 0);
    V v_ru_24x2_24216_24Right = heff_take_reuse_n(v_x2_24216, 1ULL, 1);
    switch (heff_tag_of(v_x21_24218)) {
    case TAG_MkPair: {
      V v_x_24219 = heff_field(v_x21_24218, 0);
      V v_n_24220 = heff_field(v_x21_24218, 1);
      heff_take_n(v_x21_24218, 3ULL, 2);
      switch (heff_tag_of(v_x_24219)) {
      case TAG_MkPair: {
        V v_t_27_24221 = heff_field(v_x_24219, 0);
        heff_take_n(v_x_24219, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24216_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24221, v_n_24220})});
      }
      default: return heff_nomatch(v_x_24219);
      }
    }
    default: return heff_nomatch(v_x21_24218);
    }
  }
  default: return heff_nomatch(v_x2_24216);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam39(V self, V *args) {
  V v_n_24225 = args[0];
  V v_m_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24226 = heff_tr(heff_call(v_m_24224, 1, (V[]){v_n_24225}));
  switch (heff_tag_of(v_x2_24226)) {
  case TAG_Left: {
    V v_e_24227 = heff_field(v_x2_24226, 0);
    V v_ru_24x2_24226_24Left = heff_take_reuse_n(v_x2_24226, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24226_24Left, TAG_Left, 1, (V[]){v_e_24227});
  }
  case TAG_Right: {
    V v_x21_24228 = heff_field(v_x2_24226, 0);
    V v_ru_24x2_24226_24Right = heff_take_reuse_n(v_x2_24226, 1ULL, 1);
    switch (heff_tag_of(v_x21_24228)) {
    case TAG_MkPair: {
      V v_x_24229 = heff_field(v_x21_24228, 0);
      V v_n_24230 = heff_field(v_x21_24228, 1);
      heff_take_n(v_x21_24228, 3ULL, 2);
      switch (heff_tag_of(v_x_24229)) {
      case TAG_MkPair: {
        V v_t_27_24231 = heff_field(v_x_24229, 0);
        heff_take_n(v_x_24229, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24226_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24231, v_n_24230})});
      }
      default: return heff_nomatch(v_x_24229);
      }
    }
    default: return heff_nomatch(v_x21_24228);
    }
  }
  default: return heff_nomatch(v_x2_24226);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam40(V self, V *args) {
  V v_n_24235 = args[0];
  V v_m_24234 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24236 = heff_tr(heff_call(v_m_24234, 1, (V[]){v_n_24235}));
  switch (heff_tag_of(v_x2_24236)) {
  case TAG_Left: {
    V v_e_24237 = heff_field(v_x2_24236, 0);
    V v_ru_24x2_24236_24Left = heff_take_reuse_n(v_x2_24236, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24236_24Left, TAG_Left, 1, (V[]){v_e_24237});
  }
  case TAG_Right: {
    V v_x21_24238 = heff_field(v_x2_24236, 0);
    V v_ru_24x2_24236_24Right = heff_take_reuse_n(v_x2_24236, 1ULL, 1);
    switch (heff_tag_of(v_x21_24238)) {
    case TAG_MkPair: {
      V v_x_24239 = heff_field(v_x21_24238, 0);
      V v_n_24240 = heff_field(v_x21_24238, 1);
      heff_take_n(v_x21_24238, 3ULL, 2);
      switch (heff_tag_of(v_x_24239)) {
      case TAG_MkPair: {
        V v_t_27_24241 = heff_field(v_x_24239, 0);
        heff_take_n(v_x_24239, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24236_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24241, v_n_24240})});
      }
      default: return heff_nomatch(v_x_24239);
      }
    }
    default: return heff_nomatch(v_x21_24238);
    }
  }
  default: return heff_nomatch(v_x2_24236);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam41(V self, V *args) {
  V v_n_24245 = args[0];
  V v_m_24244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24246 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_n_24245}));
  switch (heff_tag_of(v_x2_24246)) {
  case TAG_Left: {
    V v_e_24247 = heff_field(v_x2_24246, 0);
    V v_ru_24x2_24246_24Left = heff_take_reuse_n(v_x2_24246, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24246_24Left, TAG_Left, 1, (V[]){v_e_24247});
  }
  case TAG_Right: {
    V v_x21_24248 = heff_field(v_x2_24246, 0);
    V v_ru_24x2_24246_24Right = heff_take_reuse_n(v_x2_24246, 1ULL, 1);
    switch (heff_tag_of(v_x21_24248)) {
    case TAG_MkPair: {
      V v_x_24249 = heff_field(v_x21_24248, 0);
      V v_n_24250 = heff_field(v_x21_24248, 1);
      heff_take_n(v_x21_24248, 3ULL, 2);
      switch (heff_tag_of(v_x_24249)) {
      case TAG_MkPair: {
        V v_t_27_24251 = heff_field(v_x_24249, 0);
        heff_take_n(v_x_24249, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24246_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24251, v_n_24250})});
      }
      default: return heff_nomatch(v_x_24249);
      }
    }
    default: return heff_nomatch(v_x21_24248);
    }
  }
  default: return heff_nomatch(v_x2_24246);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam42(V self, V *args) {
  V v_n_24255 = args[0];
  V v_m_24254 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24256 = heff_tr(heff_call(v_m_24254, 1, (V[]){v_n_24255}));
  switch (heff_tag_of(v_x2_24256)) {
  case TAG_Left: {
    V v_e_24257 = heff_field(v_x2_24256, 0);
    V v_ru_24x2_24256_24Left = heff_take_reuse_n(v_x2_24256, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24256_24Left, TAG_Left, 1, (V[]){v_e_24257});
  }
  case TAG_Right: {
    V v_x21_24258 = heff_field(v_x2_24256, 0);
    V v_ru_24x2_24256_24Right = heff_take_reuse_n(v_x2_24256, 1ULL, 1);
    switch (heff_tag_of(v_x21_24258)) {
    case TAG_MkPair: {
      V v_x_24259 = heff_field(v_x21_24258, 0);
      V v_n_24260 = heff_field(v_x21_24258, 1);
      heff_take_n(v_x21_24258, 3ULL, 2);
      switch (heff_tag_of(v_x_24259)) {
      case TAG_MkPair: {
        V v_t_27_24261 = heff_field(v_x_24259, 0);
        heff_take_n(v_x_24259, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24256_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24261, v_n_24260})});
      }
      default: return heff_nomatch(v_x_24259);
      }
    }
    default: return heff_nomatch(v_x21_24258);
    }
  }
  default: return heff_nomatch(v_x2_24256);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam43(V self, V *args) {
  V v_n_24266 = args[0];
  V v_m_24265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24267 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_n_24266}));
  switch (heff_tag_of(v_x2_24267)) {
  case TAG_Left: {
    V v_e_24268 = heff_field(v_x2_24267, 0);
    V v_ru_24x2_24267_24Left = heff_take_reuse_n(v_x2_24267, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24267_24Left, TAG_Left, 1, (V[]){v_e_24268});
  }
  case TAG_Right: {
    V v_x21_24269 = heff_field(v_x2_24267, 0);
    V v_ru_24x2_24267_24Right = heff_take_reuse_n(v_x2_24267, 1ULL, 1);
    switch (heff_tag_of(v_x21_24269)) {
    case TAG_MkPair: {
      V v_x_24270 = heff_field(v_x21_24269, 0);
      V v_n_24271 = heff_field(v_x21_24269, 1);
      heff_take_n(v_x21_24269, 3ULL, 2);
      switch (heff_tag_of(v_x_24270)) {
      case TAG_MkPair: {
        V v_t_27_24272 = heff_field(v_x_24270, 0);
        heff_take_n(v_x_24270, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24267_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24272, v_n_24271})});
      }
      default: return heff_nomatch(v_x_24270);
      }
    }
    default: return heff_nomatch(v_x21_24269);
    }
  }
  default: return heff_nomatch(v_x2_24267);
  }
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_lam44(V self, V *args) {
  V v_n_24276 = args[0];
  V v_m_24275 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24277 = heff_tr(heff_call(v_m_24275, 1, (V[]){v_n_24276}));
  switch (heff_tag_of(v_x2_24277)) {
  case TAG_Left: {
    V v_e_24278 = heff_field(v_x2_24277, 0);
    V v_ru_24x2_24277_24Left = heff_take_reuse_n(v_x2_24277, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24277_24Left, TAG_Left, 1, (V[]){v_e_24278});
  }
  case TAG_Right: {
    V v_x21_24279 = heff_field(v_x2_24277, 0);
    V v_ru_24x2_24277_24Right = heff_take_reuse_n(v_x2_24277, 1ULL, 1);
    switch (heff_tag_of(v_x21_24279)) {
    case TAG_MkPair: {
      V v_x_24280 = heff_field(v_x21_24279, 0);
      V v_n_24281 = heff_field(v_x21_24279, 1);
      heff_take_n(v_x21_24279, 3ULL, 2);
      switch (heff_tag_of(v_x_24280)) {
      case TAG_MkPair: {
        V v_t_27_24282 = heff_field(v_x_24280, 0);
        heff_take_n(v_x_24280, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24277_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24282, v_n_24281})});
      }
      default: return heff_nomatch(v_x_24280);
      }
    }
    default: return heff_nomatch(v_x21_24279);
    }
  }
  default: return heff_nomatch(v_x2_24277);
  }
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244) {
top: ;
  V v_m_246 = (g_heff_2ecompile_2eerase_2etraverseM(heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0, 1, 4, (V[]){v_c_240, v_ty_241, v_v_242, v_fs_244}), v_ps_243));
  return heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1, 1, 1, (V[]){v_m_246});
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ty_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_fs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(v_c_240, v_ty_241, v_v_242, v_fs_244, v_p_245));
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_2411)));
      V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(v_t_2413));
      V v_t_2415 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_2411));
      V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
      V v_x_2417 = heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_ERecord, 2, (V[]){v_t_2414, v_t_2416});
      return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_n_2412})});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}