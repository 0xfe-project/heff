// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EFix 37759
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936 63224
#define TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145 14377
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SMatch 27203
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SRec 7538
#define TAG_STag 9340
#define TAG_SpId 35501
#define LBL_body 9524841
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_key 315609
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_supply 1056026650
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_tys 324872
#define LBL_values 1123329101
#define LBL_vars 10107635
#define LBL_vs 10532
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_vs__out__tys[] = {LBL_vs, LBL_out, LBL_tys};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2earmBind(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmBind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBind_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
HeffT3 g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_24cpr(V, V, V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo;
V g_heff_2ecompile_2eerase_2edefinition(V, V, V, V);
V g_heff_2ecompile_2eerase_2edefinition_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2edefinition_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2eerase_2eextend(V, V, V);
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eextend_clo;
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2ecompile_2eerase_2ezipE_24dps(V, V, V);
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo;
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232_clo;
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eextend_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242) {
top: ;
  V v_vs_243 = heff_take_field(v_c_240, 1);
  V v_t_244 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_240, 2))});
  V v_v_246 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_244, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam0, 1, 1, (V[]){heff_dup(v_ty_242)}), NTAG(TAG_Nothing)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_ir_241, v_ty_242}), heff_take_field(v_c_240, 0)});
  V v_t_248 = heff_intAdd(heff_take_field(v_c_240, 2), MK_INT(1LL));
  return ({ V rv_0 = v_t_247; V rv_1 = heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_243, heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam1, 1, 1, (V[]){v_v_246})}); V rv_2 = v_t_248; V rr_ = heff_rec_reuse_nf(v_c_240, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
}
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eextend(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args) {
  V v_u_245 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_drop(v_u_245);
  heff_clo_take(self, 1);
  return v_ty_242;
}
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args) {
  V v_u_249 = args[0];
  V v_v_246 = heff_env(self)[0];
  heff_drop(v_u_249);
  heff_clo_take(self, 1);
  return v_v_246;
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eisType_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_drop(v_u_2412);
  heff_clo_take(self, 1);
  return v_dom_245;
}
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_drop(v_u_2411);
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str0, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str1, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str2, 14, "the type of `.");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str3, 36, "` depends on fields not in hand here");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str4, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str5, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str6, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str7, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str8, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str9, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str10, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str11, 54, "projecting from something that is not of a record type");
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam12, 1, 0};
Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2ecompile_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(heff_dup(v_t_241), v_fs_242, v_l_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_len_240);
      heff_drop(v_t_241);
      heff_drop(v_l_243);
      V v_ty_247 = v_field_246;
      return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam0, 1, 1, (V[]){v_ty_247});
    } else {
      heff_drop(v_field_246);
      V v_t_249 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
      switch (heff_tag_of(v_t_249)) {
      case TAG_LikeU: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_249, 0ULL, 4);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam2_clo);
      }
      case TAG_LikeRecord: {
        V v_capture_2418 = heff_field(v_t_249, 1);
        V v_fieldTypes_2419 = heff_field(v_t_249, 2);
        heff_take_n(v_t_249, 6ULL, 3);
        HeffT2 v_t_2420 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_fieldTypes_2419, 1), v_l_243));
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          V v_t_2424;
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_i_2423 = v_field_2422;
            v_t_2424 = v_i_2423;
          } else {
            heff_drop(v_field_2422);
            v_t_2424 = heff_abandon();
          }
          HeffT2 v_t_2425 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_len_240, v_capture_2418, v_fieldTypes_2419, v_t_2424, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
          {
            V v_field_2427 = v_t_2425.f[1];
            int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
            if ((v_tag_2426 == ((int64_t)0ULL))) {
              heff_drop(v_l_243);
              V v_ty_2428 = v_field_2427;
              return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2428});
            } else {
              heff_drop(v_field_2427);
              return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam4, 1, 1, (V[]){v_l_243});
            }
          }
        }
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo);
      }
      case TAG_LikeInt: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo);
      }
      case TAG_LikeFloat: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo);
      }
      case TAG_LikeString: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo);
      }
      case TAG_LikeRune: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo);
      }
      case TAG_NoRules: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam12_clo);
      }
      default: return heff_nomatch(v_t_249);
      }
    }
  }
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2eprojTyInWith(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_ty_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_247, v_n_248})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  heff_drop(v_n_2411);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2429 = args[0];
  V v_ty_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2428, v_n_2429})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2430 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_drop(v_n_2430);
  heff_clo_take(self, 1);
  V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str2), v_l_243), ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str3));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2433 = args[0];
  heff_drop(v_n_2433);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2434 = args[0];
  heff_drop(v_n_2434);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2435 = args[0];
  heff_drop(v_n_2435);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2436 = args[0];
  heff_drop(v_n_2436);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2437 = args[0];
  heff_drop(v_n_2437);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2439 = args[0];
  heff_drop(v_n_2439);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args) {
  V v_n_2441 = args[0];
  heff_drop(v_n_2441);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str10)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args) {
  V v_n_2442 = args[0];
  heff_drop(v_n_2442);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str11)});
}
Clo g_heff_2ecompile_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eerase_2ezipE_24dps(v_xs_243, v_ys_245, v_cell_246));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE(a[0], a[1]);
}
Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_24dps_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ezipE_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_247);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_u_248;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2ezipE_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str2, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str3, 1, "$");
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2ecompile_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_240, 1)));
    V v_x_243 = ({ V rv_1 = v_t_242; V rr_ = heff_rec_reuse_nf(v_acc_240, 1ULL, 2, shape_c__vars, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_Cons: {
    V v_x21_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_245)) {
    case TAG_MkPair: {
      V v_x_247 = heff_field(v_x21_245, 0);
      V v_aty_248 = heff_field(v_x21_245, 1);
      heff_take_n(v_x21_245, 3ULL, 2);
      V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_acc_240, 0)), 2, 4);
      V v_t_2410 = (g_heff_2ecompile_2eerase_2eisType(v_t_249, heff_dup(v_aty_248)));
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_x_247);
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2ecompile_2eerase_2eextend(heff_take_field(v_acc_240, 0), NTAG(TAG_Nothing), v_aty_248));
        V v_t_2412 = ({ V rv_0 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_acc_240, 2ULL, 2, shape_c__vars, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        V t_0 = v_t_2412;
        V t_1 = v_rest_246;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_2410);
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam1, 1, 4, (V[]){v_x_247, v_acc_240, v_aty_248, v_rest_246});
      }
    }
    default: return heff_nomatch(v_x21_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_n_244})});
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  V v_aty_248 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  V v_t_2414;
  heff_clo_take(self, 4);
  if ((heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str0), 2) || heff_strEq_c_lent(v_x_247, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str1), 2))) {
    heff_drop(v_x_247);
    v_t_2414 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str2);
  } else {
    v_t_2414 = v_x_247;
  }
  V v_t_2415 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str3)), heff_intShow(heff_dup(v_n_2413)));
  V v_t_2416 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2415)})});
  V v_t_2417 = (g_heff_2ecompile_2eerase_2eextend(heff_take_field(v_acc_240, 0), v_t_2416, v_aty_248));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_take_field(v_acc_240, 1)});
  V v_t_2419 = (g_heff_2ecompile_2eerase_2earmBindGo(({ V rv_0 = v_t_2417; V rv_1 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_acc_240, 0ULL, 2, shape_c__vars, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; }), v_rest_246));
  V f_ = v_t_2419;
  args[0] = heff_intAdd(v_n_2413, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
      V t_0 = v_xs_243;
      V t_1 = v_u_246;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str0, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str6, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str7, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str8, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str9, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str10, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str11, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str12, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str13, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str14, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str15, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str16, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str17, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str18, 26, "a type in a value position");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str22, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str23, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str24, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str25, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str26, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str27, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str28, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str29, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str30, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str31, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str32, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str33, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str34, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str35, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str36, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str37, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str38, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str39, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str40, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str41, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str42, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str43, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str44, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str45, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str46, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str47, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str48, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str49, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str50, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str51, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str52, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str53, 47, "matching on something that is not of a sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str54, 14, "an opaque term");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str55, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str56, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str57, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str58, 1, "$");
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry, 7, 0};

V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V v_tag_240, V v_c_241, V v_abs_242, V v_ty_243, V v_c_244, V v_t_245, V v_ty_246) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145: {
    top_TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145: ;
    heff_drop(v_c_244);
    heff_drop(v_t_245);
    heff_drop(v_ty_246);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0_clo);
    }
    case TAG_LikeFunction: {
      V v_dom_2411 = heff_field(v_t_247, 1);
      V v_cod_2412 = heff_field(v_t_247, 2);
      heff_take_n(v_t_247, 6ULL, 4);
      V v_it1_2419;
      V v_body_2420;
      switch (heff_tag_of(v_abs_242)) {
      case TAG_MkAbs: {
        V v_n_2414 = heff_field(v_abs_242, 0);
        V v_b_2415 = heff_field(v_abs_242, 1);
        V v_ru_24abs_242_24MkAbs = heff_take_reuse_n(v_abs_242, 3ULL, 2);
        V v_t_2416 = heff_tag_at_n(v_ru_24abs_242_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2414, NTAG(TAG_True)});
        v_it1_2419 = v_t_2416;
        v_body_2420 = v_b_2415;
        break;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_abs_242, 0);
        heff_take_n(v_abs_242, 1ULL, 1);
        V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str1), NTAG(TAG_False)});
        v_it1_2419 = v_t_2418;
        v_body_2420 = v_b_2417;
        break;
      }
      default: heff_nomatch(v_abs_242);
      }
      switch (heff_tag_of(v_it1_2419)) {
      case TAG_MkPair: {
        V v_hint_2421 = heff_field(v_it1_2419, 0);
        V v_bound_2422 = heff_field(v_it1_2419, 1);
        heff_take_n(v_it1_2419, 3ULL, 2);
        V v_t_2423 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_241, 2)), heff_dup(v_dom_2411)));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_hint_2421);
          heff_drop(v_t_2423);
          V v_c_2424;
          if ((heff_dup(v_bound_2422) == NTAG(TAG_True))) {
            heff_drop(v_bound_2422);
            v_c_2424 = (g_heff_2ecompile_2eerase_2eextend(heff_dup(v_c_241), NTAG(TAG_Nothing), heff_dup(v_dom_2411)));
          } else {
            heff_drop(v_bound_2422);
            v_c_2424 = heff_dup(v_c_241);
          }
          V v_x1_2432;
          switch (heff_tag_of(v_cod_2412)) {
          case TAG_MkClo: {
            V v_vs_2426 = heff_field(v_cod_2412, 1);
            V v_body_2427 = heff_field(v_cod_2412, 2);
            heff_take_n(v_cod_2412, 6ULL, 3);
            v_x1_2432 = heff_tr(heff_call(v_body_2427, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2426, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1, 1, 2, (V[]){v_c_241, v_dom_2411})})}));
            break;
          }
          case TAG_CloConst: {
            V v_body_2431 = heff_field(v_cod_2412, 0);
            heff_take_n(v_cod_2412, 1ULL, 1);
            heff_drop_rec(v_c_241, 4);
            heff_drop(v_dom_2411);
            v_x1_2432 = v_body_2431;
            break;
          }
          default: heff_nomatch(v_cod_2412);
          }
          V v_ty_2436;
          switch (heff_tag_of(v_x1_2432)) {
          case TAG_Nom: {
            V v_x_2433 = heff_field(v_x1_2432, 0);
            heff_take_n(v_x1_2432, 1ULL, 1);
            v_ty_2436 = v_x_2433;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2432, 0ULL, 1);
            v_ty_2436 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2435 = heff_field(v_x1_2432, 0);
            heff_take_n(v_x1_2432, 1ULL, 1);
            v_ty_2436 = v_x_2435;
            break;
          }
          default: heff_nomatch(v_x1_2432);
          }
          V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
          V t_1 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str2);
          V t_2 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str3);
          V t_3 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str4);
          V t_4 = v_c_2424;
          V t_5 = v_body_2420;
          V t_6 = v_ty_2436;
          v_tag_240 = t_0;
          v_c_241 = t_1;
          v_abs_242 = t_2;
          v_ty_243 = t_3;
          v_c_244 = t_4;
          v_t_245 = t_5;
          v_ty_246 = t_6;
          goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
        } else {
          heff_drop(v_t_2423);
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3, 1, 6, (V[]){v_hint_2421, v_bound_2422, v_c_241, v_dom_2411, v_cod_2412, v_body_2420});
        }
      }
      default: return heff_nomatch(v_it1_2419);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6_clo);
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7_clo);
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14_clo);
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936: {
    top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936: ;
    switch (heff_tag_of(v_t_245)) {
    case TAG_SCode: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_c_244);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15_clo);
    }
    case TAG_SLam: {
      V v_abs_2480 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145);
      V t_1 = v_c_244;
      V t_2 = v_abs_2480;
      V t_3 = v_ty_246;
      V t_4 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str19);
      V t_5 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str20);
      V t_6 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str21);
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145;
    }
    case TAG_SCons: {
      V v_d_2481 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_keys_2482 = heff_take_field(v_d_2481, 0);
      V v_values_2483 = heff_get_n(v_d_2481, 2, 3);
      V v_t_2484 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_246));
      switch (heff_tag_of(v_t_2484)) {
      case TAG_LikeU: {
        heff_take_n(v_t_2484, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_2484, 0ULL, 4);
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17_clo);
      }
      case TAG_LikeRecord: {
        V v_capture_2493 = heff_field(v_t_2484, 1);
        V v_fieldTypes_2494 = heff_field(v_t_2484, 2);
        heff_take_n(v_t_2484, 6ULL, 3);
        V v_t_2495 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2482), heff_arrayToList(v_values_2483)));
        V v_t_2496 = heff_rec_n(3, shape_vs__out__tys, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
        return (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_244, v_capture_2493, v_fieldTypes_2494, v_t_2496, v_t_2495));
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_2484, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18_clo);
      }
      case TAG_LikeInt: {
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19_clo);
      }
      case TAG_LikeFloat: {
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20_clo);
      }
      case TAG_LikeString: {
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21_clo);
      }
      case TAG_LikeRune: {
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_2484, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_2484, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24_clo);
      }
      case TAG_NoRules: {
        heff_drop(v_c_244);
        heff_drop(v_keys_2482);
        heff_drop(v_values_2483);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25_clo);
      }
      default: return heff_nomatch(v_t_2484);
      }
    }
    case TAG_STag: {
      V v_x_24108 = heff_field(v_t_245, 0);
      V v_args_24109 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_t_24110 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_246));
      switch (heff_tag_of(v_t_24110)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24110, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_24110, 0ULL, 4);
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27_clo);
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_24110, 0ULL, 3);
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28_clo);
      }
      case TAG_LikeSum: {
        V v_vs_24122 = heff_field(v_t_24110, 0);
        heff_take_n(v_t_24110, 1ULL, 1);
        V v_byName_24123 = heff_take_field(v_vs_24122, 1);
        V v_values_24124 = heff_get_n(v_vs_24122, 2, 3);
        HeffT2 v_t_24125 = ({ V a_0 = v_byName_24123; V a_1 = v_x_24108; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_24123); r_; });
        {
          V v_field_24127 = v_t_24125.f[1];
          int64_t v_tag_24126 = ((int64_t)v_t_24125.f[0]);
          if ((v_tag_24126 == ((int64_t)0ULL))) {
            V v_i_24128 = v_field_24127;
            V v_xs_24129 = v_values_24124;
            if ((heff_intLe_c_lent(MK_INT(0LL), v_i_24128, 1) && heff_intLt_c_lent(v_i_24128, heff_arrayLength_lent(v_xs_24129, 0), 2))) {
              V v_ts_24130 = heff_arrayIndex(v_xs_24129, v_i_24128);
              V v_t_24131 = (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_24130)));
              V v_t_24132 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_args_24109), v_t_24131));
              V v_m_24162 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29, 1, 1, (V[]){v_c_244}), v_t_24132));
              return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32, 1, 2, (V[]){v_m_24162, v_x_24108});
            } else {
              heff_drop(v_c_244);
              heff_drop(v_args_24109);
              heff_drop(v_i_24128);
              heff_drop(v_xs_24129);
              return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33, 1, 1, (V[]){v_x_24108});
            }
          } else {
            heff_drop(v_c_244);
            heff_drop(v_args_24109);
            heff_drop(v_values_24124);
            heff_drop(v_field_24127);
            return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34, 1, 1, (V[]){v_x_24108});
          }
        }
      }
      case TAG_LikeInt: {
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35_clo);
      }
      case TAG_LikeFloat: {
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36_clo);
      }
      case TAG_LikeString: {
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37_clo);
      }
      case TAG_LikeRune: {
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24110, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_24110, 0ULL, 1);
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40_clo);
      }
      case TAG_NoRules: {
        heff_drop(v_c_244);
        heff_drop(v_x_24108);
        heff_drop(v_args_24109);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41_clo);
      }
      default: return heff_nomatch(v_t_24110);
      }
    }
    case TAG_SMatch: {
      V v_scrut_24185 = heff_field(v_t_245, 0);
      V v_cases_24186 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_keys_24187 = heff_take_field(v_cases_24186, 0);
      V v_values_24188 = heff_get_n(v_cases_24186, 2, 3);
      V v_m_24189 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_244), v_scrut_24185));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42, 1, 5, (V[]){v_m_24189, v_keys_24187, v_values_24188, v_c_244, v_ty_246});
    }
    case TAG_SIs: {
      V v_t1_24219 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t1_24219;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SOpaque: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_c_244);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44_clo);
    }
    case TAG_SAbandon: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_c_244);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45_clo);
    }
    case TAG_SRec: {
      V v_t1_24223 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t1_24223;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SFix: {
      V v_t2_27_24225 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      switch (heff_tag_of(v_t2_27_24225)) {
      case TAG_MkAbs: {
        V v_x_24226 = heff_field(v_t2_27_24225, 0);
        V v_body_24227 = heff_field(v_t2_27_24225, 1);
        heff_take_n(v_t2_27_24225, 3ULL, 2);
        heff_drop_rec(v_c_241, 4);
        heff_drop(v_abs_242);
        heff_drop(v_ty_243);
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46, 1, 4, (V[]){v_x_24226, v_c_244, v_ty_246, v_body_24227});
      }
      case TAG_AbsConst: {
        V v_body_24240 = heff_field(v_t2_27_24225, 0);
        heff_take_n(v_t2_27_24225, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
        V t_1 = v_c_241;
        V t_2 = v_abs_242;
        V t_3 = v_ty_243;
        V t_4 = v_c_244;
        V t_5 = v_body_24240;
        V t_6 = v_ty_246;
        v_tag_240 = t_0;
        v_c_241 = t_1;
        v_abs_242 = t_2;
        v_ty_243 = t_3;
        v_c_244 = t_4;
        v_t_245 = t_5;
        v_ty_246 = t_6;
        goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
      }
      default: return heff_nomatch(v_t2_27_24225);
      }
    }
    case TAG_SImplicit: {
      V v_t2_27_24242 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t2_27_24242;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SPrim: {
      V v_x_24243 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_c_244);
      heff_drop(v_ty_246);
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47, 1, 1, (V[]){v_x_24243});
    }
    default: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24246 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48, 1, 1, (V[]){v_m_24246});
    }
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0(V self, V *args) {
  V v_n_249 = args[0];
  heff_drop(v_n_249);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str0)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2(V self, V *args) {
  V v_u_2430 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_drop(v_u_2430);
  heff_clo_take(self, 1);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1(V self, V *args) {
  V v_u_2428 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_dom_2411 = heff_env(self)[1];
  heff_drop(v_u_2428);
  heff_clo_take(self, 2);
  V v_t_2429 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_241, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2429, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2, 1, 1, (V[]){v_dom_2411}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5(V self, V *args) {
  V v_u_2447 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_drop(v_u_2447);
  heff_clo_take(self, 1);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4(V self, V *args) {
  V v_u_2445 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_dom_2411 = heff_env(self)[1];
  heff_drop(v_u_2445);
  heff_clo_take(self, 2);
  V v_t_2446 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_241, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2446, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5, 1, 1, (V[]){v_dom_2411}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3(V self, V *args) {
  V v_n_2437 = args[0];
  V v_hint_2421 = heff_env(self)[0];
  V v_bound_2422 = heff_env(self)[1];
  V v_c_241 = heff_env(self)[2];
  V v_dom_2411 = heff_env(self)[3];
  V v_cod_2412 = heff_env(self)[4];
  V v_body_2420 = heff_env(self)[5];
  V v_t_2438;
  heff_clo_take(self, 6);
  if ((heff_strEq_c_lent(v_hint_2421, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str5), 2) || heff_strEq_c_lent(v_hint_2421, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str6), 2))) {
    heff_drop(v_hint_2421);
    v_t_2438 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str7);
  } else {
    v_t_2438 = v_hint_2421;
  }
  V v_t_2439 = heff_strAppend(heff_strAppend(v_t_2438, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str8)), heff_intShow(heff_dup(v_n_2437)));
  V v_c_2441;
  if ((heff_dup(v_bound_2422) == NTAG(TAG_True))) {
    heff_drop(v_bound_2422);
    V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_2439)})});
    v_c_2441 = (g_heff_2ecompile_2eerase_2eextend(heff_dup(v_c_241), v_t_2440, heff_dup(v_dom_2411)));
  } else {
    heff_drop(v_bound_2422);
    v_c_2441 = heff_dup(v_c_241);
  }
  V v_x1_2449;
  switch (heff_tag_of(v_cod_2412)) {
  case TAG_MkClo: {
    V v_vs_2443 = heff_field(v_cod_2412, 1);
    V v_body_2444 = heff_field(v_cod_2412, 2);
    heff_take_n(v_cod_2412, 6ULL, 3);
    v_x1_2449 = heff_tr(heff_call(v_body_2444, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2443, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4, 1, 2, (V[]){v_c_241, v_dom_2411})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2448 = heff_field(v_cod_2412, 0);
    heff_take_n(v_cod_2412, 1ULL, 1);
    heff_drop_rec(v_c_241, 4);
    heff_drop(v_dom_2411);
    v_x1_2449 = v_body_2448;
    break;
  }
  default: heff_nomatch(v_cod_2412);
  }
  V v_ty_2453;
  switch (heff_tag_of(v_x1_2449)) {
  case TAG_Nom: {
    V v_x_2450 = heff_field(v_x1_2449, 0);
    heff_take_n(v_x1_2449, 1ULL, 1);
    v_ty_2453 = v_x_2450;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2449, 0ULL, 1);
    v_ty_2453 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2452 = heff_field(v_x1_2449, 0);
    heff_take_n(v_x1_2449, 1ULL, 1);
    v_ty_2453 = v_x_2452;
    break;
  }
  default: heff_nomatch(v_x1_2449);
  }
  V v_m_2454 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_2441, v_body_2420, v_ty_2453));
  V v_x2_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){heff_intAdd(v_n_2437, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2455)) {
  case TAG_Left: {
    V v_e_2456 = heff_field(v_x2_2455, 0);
    V v_ru_24x2_2455_24Left = heff_take_reuse_n(v_x2_2455, 1ULL, 1);
    heff_drop(v_t_2439);
    return heff_tag_re_n(v_ru_24x2_2455_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2456});
  }
  case TAG_Right: {
    V v_x21_2457 = heff_field(v_x2_2455, 0);
    V v_ru_24x2_2455_24Right = heff_take_reuse_n(v_x2_2455, 1ULL, 1);
    switch (heff_tag_of(v_x21_2457)) {
    case TAG_MkPair: {
      V v_x_2458 = heff_field(v_x21_2457, 0);
      V v_n_2459 = heff_field(v_x21_2457, 1);
      V v_ru_24x21_2457_24MkPair = heff_take_reuse_n(v_x21_2457, 3ULL, 2);
      V v_t_2460 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
      V v_t_2461 = heff_tag_re_n(v_ru_24x21_2457_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2460, v_x_2458}), v_n_2459});
      return heff_tag_at_n(v_ru_24x2_2455_24Right, TAG_Right, 1, (V[]){v_t_2461});
    }
    default: return heff_nomatch(v_x21_2457);
    }
  }
  default: return heff_nomatch(v_x2_2455);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6(V self, V *args) {
  V v_n_2465 = args[0];
  heff_drop(v_n_2465);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str9)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7(V self, V *args) {
  V v_n_2467 = args[0];
  heff_drop(v_n_2467);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str10)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8(V self, V *args) {
  V v_n_2468 = args[0];
  heff_drop(v_n_2468);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str11)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9(V self, V *args) {
  V v_n_2469 = args[0];
  heff_drop(v_n_2469);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str12)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10(V self, V *args) {
  V v_n_2470 = args[0];
  heff_drop(v_n_2470);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str13)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11(V self, V *args) {
  V v_n_2471 = args[0];
  heff_drop(v_n_2471);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str14)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12(V self, V *args) {
  V v_n_2473 = args[0];
  heff_drop(v_n_2473);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str15)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13(V self, V *args) {
  V v_n_2475 = args[0];
  heff_drop(v_n_2475);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str16)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14(V self, V *args) {
  V v_n_2476 = args[0];
  heff_drop(v_n_2476);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str17)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15(V self, V *args) {
  V v_n_2478 = args[0];
  heff_drop(v_n_2478);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str18)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16(V self, V *args) {
  V v_n_2486 = args[0];
  heff_drop(v_n_2486);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str22)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17(V self, V *args) {
  V v_n_2491 = args[0];
  heff_drop(v_n_2491);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str23)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18(V self, V *args) {
  V v_n_2498 = args[0];
  heff_drop(v_n_2498);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str24)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19(V self, V *args) {
  V v_n_2499 = args[0];
  heff_drop(v_n_2499);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str25)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20(V self, V *args) {
  V v_n_24100 = args[0];
  heff_drop(v_n_24100);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str26)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21(V self, V *args) {
  V v_n_24101 = args[0];
  heff_drop(v_n_24101);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str27)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22(V self, V *args) {
  V v_n_24102 = args[0];
  heff_drop(v_n_24102);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str28)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23(V self, V *args) {
  V v_n_24104 = args[0];
  heff_drop(v_n_24104);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str29)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24(V self, V *args) {
  V v_n_24106 = args[0];
  heff_drop(v_n_24106);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str30)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25(V self, V *args) {
  V v_n_24107 = args[0];
  heff_drop(v_n_24107);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str31)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26(V self, V *args) {
  V v_n_24112 = args[0];
  heff_drop(v_n_24112);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str32)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27(V self, V *args) {
  V v_n_24117 = args[0];
  heff_drop(v_n_24117);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str33)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28(V self, V *args) {
  V v_n_24121 = args[0];
  heff_drop(v_n_24121);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str34)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30(V self, V *args) {
  V v_n_24139 = args[0];
  V v_t_24140 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_n_24139});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24140});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31(V self, V *args) {
  V v_n_24142 = args[0];
  V v_m_24141 = heff_env(self)[0];
  V v_aty_24137 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24143 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_n_24142}));
  switch (heff_tag_of(v_x2_24143)) {
  case TAG_Left: {
    V v_e_24144 = heff_field(v_x2_24143, 0);
    V v_ru_24x2_24143_24Left = heff_take_reuse_n(v_x2_24143, 1ULL, 1);
    heff_drop(v_aty_24137);
    return heff_tag_re_n(v_ru_24x2_24143_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24144});
  }
  case TAG_Right: {
    V v_x21_24145 = heff_field(v_x2_24143, 0);
    V v_ru_24x2_24143_24Right = heff_take_reuse_n(v_x2_24143, 1ULL, 1);
    switch (heff_tag_of(v_x21_24145)) {
    case TAG_MkPair: {
      V v_x_24146 = heff_field(v_x21_24145, 0);
      V v_n_24147 = heff_field(v_x21_24145, 1);
      V v_ru_24x21_24145_24MkPair = heff_take_reuse_n(v_x21_24145, 3ULL, 2);
      V v_x1_24148 = (g_heff_2eelab_2evalue_2ebehavior(v_aty_24137));
      V v_t_24160;
      switch (heff_tag_of(v_x1_24148)) {
      case TAG_LikeU: {
        heff_take_n(v_x1_24148, 0ULL, 1);
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x1_24148, 0ULL, 4);
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_x1_24148, 0ULL, 3);
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x1_24148, 0ULL, 1);
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeInt: {
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFloat: {
        v_t_24160 = NTAG(TAG_FtFloat);
        break;
      }
      case TAG_LikeString: {
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRune: {
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x1_24148, 0ULL, 1);
        v_t_24160 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFixed: {
        V v_w_24159 = heff_field(v_x1_24148, 0);
        V v_ru_24x1_24148_24LikeFixed = heff_take_reuse_n(v_x1_24148, 1ULL, 1);
        v_t_24160 = heff_tag_at_n(v_ru_24x1_24148_24LikeFixed, TAG_FtFixed, 1, (V[]){v_w_24159});
        break;
      }
      case TAG_NoRules: {
        v_t_24160 = NTAG(TAG_FtAny);
        break;
      }
      default: heff_nomatch(v_x1_24148);
      }
      V v_x_24161 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_re_n(v_ru_24x21_24145_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_x_24146, v_t_24160})});
      return heff_tag_at_n(v_ru_24x2_24143_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24161, v_n_24147})});
    }
    default: return heff_nomatch(v_x21_24145);
    }
  }
  default: return heff_nomatch(v_x2_24143);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29(V self, V *args) {
  V v_p_24133 = args[0];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_c_24134 = v_c_244;
  V v_x3_24135 = v_p_24133;
  switch (heff_tag_of(v_x3_24135)) {
  case TAG_MkPair: {
    V v_a_24136 = heff_field(v_x3_24135, 0);
    V v_aty_24137 = heff_field(v_x3_24135, 1);
    heff_take_n(v_x3_24135, 3ULL, 2);
    V v_t_24138 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_24134, 2)), heff_dup(v_aty_24137)));
    if ((heff_dup(v_t_24138) == NTAG(TAG_True))) {
      heff_drop_rec(v_c_24134, 4);
      heff_drop(v_a_24136);
      heff_drop(v_aty_24137);
      heff_drop(v_t_24138);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30_clo);
    } else {
      heff_drop(v_t_24138);
      V v_m_24141 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_24134, v_a_24136, heff_dup(v_aty_24137)));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31, 1, 2, (V[]){v_m_24141, v_aty_24137});
    }
  }
  default: return heff_nomatch(v_x3_24135);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32(V self, V *args) {
  V v_n_24163 = args[0];
  V v_m_24162 = heff_env(self)[0];
  V v_x_24108 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24164 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_n_24163}));
  switch (heff_tag_of(v_x2_24164)) {
  case TAG_Left: {
    V v_e_24165 = heff_field(v_x2_24164, 0);
    V v_ru_24x2_24164_24Left = heff_take_reuse_n(v_x2_24164, 1ULL, 1);
    heff_drop(v_x_24108);
    return heff_tag_re_n(v_ru_24x2_24164_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24165});
  }
  case TAG_Right: {
    V v_x21_24166 = heff_field(v_x2_24164, 0);
    V v_ru_24x2_24164_24Right = heff_take_reuse_n(v_x2_24164, 1ULL, 1);
    switch (heff_tag_of(v_x21_24166)) {
    case TAG_MkPair: {
      V v_x_24167 = heff_field(v_x21_24166, 0);
      V v_n_24168 = heff_field(v_x21_24166, 1);
      V v_ru_24x21_24166_24MkPair = heff_take_reuse_n(v_x21_24166, 3ULL, 2);
      V v_t_24169 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_24167)));
      V v_t_24170 = (g_list_2emap_24s1937570095x2110149801(v_t_24169));
      V v_t_24171 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_24167));
      V v_t_24172 = (g_list_2emap_24s1173914895x100384474(v_t_24171));
      V v_x_24173 = heff_tag_n(TAG_ETag, 3, (V[]){v_x_24108, v_t_24170, v_t_24172});
      return heff_tag_at_n(v_ru_24x2_24164_24Right, TAG_Right, 1, (V[]){heff_tag_re_n(v_ru_24x21_24166_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_x_24173, v_n_24168})});
    }
    default: return heff_nomatch(v_x21_24166);
    }
  }
  default: return heff_nomatch(v_x2_24164);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33(V self, V *args) {
  V v_n_24174 = args[0];
  V v_x_24108 = heff_env(self)[0];
  heff_drop(v_n_24174);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str35), v_x_24108)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34(V self, V *args) {
  V v_n_24175 = args[0];
  V v_x_24108 = heff_env(self)[0];
  heff_drop(v_n_24175);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str36), v_x_24108)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35(V self, V *args) {
  V v_n_24176 = args[0];
  heff_drop(v_n_24176);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str37)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36(V self, V *args) {
  V v_n_24177 = args[0];
  heff_drop(v_n_24177);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str38)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37(V self, V *args) {
  V v_n_24178 = args[0];
  heff_drop(v_n_24178);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str39)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38(V self, V *args) {
  V v_n_24179 = args[0];
  heff_drop(v_n_24179);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str40)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39(V self, V *args) {
  V v_n_24181 = args[0];
  heff_drop(v_n_24181);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str41)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40(V self, V *args) {
  V v_n_24183 = args[0];
  heff_drop(v_n_24183);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str42)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41(V self, V *args) {
  V v_n_24184 = args[0];
  heff_drop(v_n_24184);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str43)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43(V self, V *args) {
  V v_p_24209 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_vs_24207 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_244, v_vs_24207, v_ty_246, v_p_24209));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42(V self, V *args) {
  V v_n_24190 = args[0];
  V v_m_24189 = heff_env(self)[0];
  V v_keys_24187 = heff_env(self)[1];
  V v_values_24188 = heff_env(self)[2];
  V v_c_244 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24191 = heff_tr(heff_call(v_m_24189, 1, (V[]){v_n_24190}));
  switch (heff_tag_of(v_x2_24191)) {
  case TAG_Left: {
    V v_e_24192 = heff_field(v_x2_24191, 0);
    V v_ru_24x2_24191_24Left = heff_take_reuse_n(v_x2_24191, 1ULL, 1);
    heff_drop(v_keys_24187);
    heff_drop(v_values_24188);
    heff_drop(v_c_244);
    heff_drop(v_ty_246);
    return heff_tag_re_n(v_ru_24x2_24191_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24192});
  }
  case TAG_Right: {
    V v_x21_24193 = heff_field(v_x2_24191, 0);
    V v_ru_24x2_24191_24Right = heff_take_reuse_n(v_x2_24191, 1ULL, 1);
    switch (heff_tag_of(v_x21_24193)) {
    case TAG_MkPair: {
      V v_x_24194 = heff_field(v_x21_24193, 0);
      V v_n_24195 = heff_field(v_x21_24193, 1);
      V v_ru_24x21_24193_24MkPair = heff_take_reuse_n(v_x21_24193, 3ULL, 2);
      switch (heff_tag_of(v_x_24194)) {
      case TAG_MkPair: {
        V v_s_27_24196 = heff_field(v_x_24194, 0);
        V v_sty_24197 = heff_field(v_x_24194, 1);
        V v_ru_24x_24194_24MkPair = heff_take_reuse_n(v_x_24194, 3ULL, 2);
        V v_t_24198 = (g_heff_2eelab_2evalue_2ebehavior(v_sty_24197));
        switch (heff_tag_of(v_t_24198)) {
        case TAG_LikeU: {
          V v_ru_24t_24198_24LikeU = heff_take_reuse_n(v_t_24198, 0ULL, 1);
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_24198_24LikeU, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str44)});
        }
        case TAG_LikeFunction: {
          heff_take_n(v_t_24198, 0ULL, 4);
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str45)});
        }
        case TAG_LikeRecord: {
          heff_take_n(v_t_24198, 0ULL, 3);
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str46)});
        }
        case TAG_LikeSum: {
          V v_vs_24207 = heff_field(v_t_24198, 0);
          V v_ru_24t_24198_24LikeSum = heff_take_reuse_n(v_t_24198, 1ULL, 1);
          V v_t_24208 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_24187), heff_arrayToList(v_values_24188)));
          V v_t_24210 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43, 1, 3, (V[]){v_c_244, v_vs_24207, v_ty_246}), v_t_24208));
          V v_x2_24211 = heff_tr(heff_call(v_t_24210, 1, (V[]){v_n_24195}));
          switch (heff_tag_of(v_x2_24211)) {
          case TAG_Left: {
            V v_e_24212 = heff_field(v_x2_24211, 0);
            heff_take_n(v_x2_24211, 1ULL, 1);
            heff_drop_cell(v_ru_24x2_24191_24Right, 1);
            heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
            heff_drop(v_s_27_24196);
            heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
            return heff_tag_at_n(v_ru_24t_24198_24LikeSum, TAG_Left, 1, (V[]){v_e_24212});
          }
          case TAG_Right: {
            V v_x21_24213 = heff_field(v_x2_24211, 0);
            heff_take_n(v_x2_24211, 1ULL, 1);
            heff_drop_cell(v_ru_24t_24198_24LikeSum, 1);
            switch (heff_tag_of(v_x21_24213)) {
            case TAG_MkPair: {
              V v_x_24214 = heff_field(v_x21_24213, 0);
              V v_n_24215 = heff_field(v_x21_24213, 1);
              heff_take_n(v_x21_24213, 3ULL, 2);
              V v_t_24216 = heff_tag_at_n(v_ru_24x21_24193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x_24194_24MkPair, TAG_EMatch, 2, (V[]){v_s_27_24196, v_x_24214}), v_n_24215});
              return heff_tag_at_n(v_ru_24x2_24191_24Right, TAG_Right, 1, (V[]){v_t_24216});
            }
            default: return heff_nomatch(v_x21_24213);
            }
          }
          default: return heff_nomatch(v_x2_24211);
          }
        }
        case TAG_LikeInt: {
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str47)});
        }
        case TAG_LikeFloat: {
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str48)});
        }
        case TAG_LikeString: {
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str49)});
        }
        case TAG_LikeRune: {
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str50)});
        }
        case TAG_LikeArray: {
          V v_ru_24t_24198_24LikeArray = heff_take_reuse_n(v_t_24198, 0ULL, 1);
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_24198_24LikeArray, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str51)});
        }
        case TAG_LikeFixed: {
          V v_ru_24t_24198_24LikeFixed = heff_take_reuse_n(v_t_24198, 0ULL, 1);
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_at_n(v_ru_24t_24198_24LikeFixed, TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str52)});
        }
        case TAG_NoRules: {
          heff_drop(v_keys_24187);
          heff_drop(v_values_24188);
          heff_drop(v_c_244);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24191_24Right, 1);
          heff_drop(v_n_24195);
          heff_drop_cell(v_ru_24x21_24193_24MkPair, 2);
          heff_drop(v_s_27_24196);
          heff_drop_cell(v_ru_24x_24194_24MkPair, 2);
          return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str53)});
        }
        default: return heff_nomatch(v_t_24198);
        }
      }
      default: return heff_nomatch(v_x_24194);
      }
    }
    default: return heff_nomatch(v_x21_24193);
    }
  }
  default: return heff_nomatch(v_x2_24191);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44(V self, V *args) {
  V v_n_24220 = args[0];
  heff_drop(v_n_24220);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str54)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45(V self, V *args) {
  V v_n_24221 = args[0];
  V v_t_24222 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24221});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24222});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46(V self, V *args) {
  V v_n_24228 = args[0];
  V v_x_24226 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  V v_body_24227 = heff_env(self)[3];
  V v_t_24229;
  heff_clo_take(self, 4);
  if ((heff_strEq_c_lent(v_x_24226, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str55), 2) || heff_strEq_c_lent(v_x_24226, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str56), 2))) {
    heff_drop(v_x_24226);
    v_t_24229 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str57);
  } else {
    v_t_24229 = v_x_24226;
  }
  V v_t_24230 = heff_strAppend(heff_strAppend(v_t_24229, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str58)), heff_intShow(heff_dup(v_n_24228)));
  V v_t_24231 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_t_24230)})});
  V v_c_24232 = (g_heff_2ecompile_2eerase_2eextend(v_c_244, v_t_24231, heff_dup(v_ty_246)));
  V v_m_24233 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_24232, v_body_24227, v_ty_246));
  V v_x2_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){heff_intAdd(v_n_24228, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24234)) {
  case TAG_Left: {
    V v_e_24235 = heff_field(v_x2_24234, 0);
    V v_ru_24x2_24234_24Left = heff_take_reuse_n(v_x2_24234, 1ULL, 1);
    heff_drop(v_t_24230);
    return heff_tag_re_n(v_ru_24x2_24234_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24235});
  }
  case TAG_Right: {
    V v_x21_24236 = heff_field(v_x2_24234, 0);
    V v_ru_24x2_24234_24Right = heff_take_reuse_n(v_x2_24234, 1ULL, 1);
    switch (heff_tag_of(v_x21_24236)) {
    case TAG_MkPair: {
      V v_x_24237 = heff_field(v_x21_24236, 0);
      V v_n_24238 = heff_field(v_x21_24236, 1);
      V v_ru_24x21_24236_24MkPair = heff_take_reuse_n(v_x21_24236, 3ULL, 2);
      V v_t_24239 = heff_tag_re_n(v_ru_24x21_24236_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_t_24230, v_x_24237}), v_n_24238});
      return heff_tag_at_n(v_ru_24x2_24234_24Right, TAG_Right, 1, (V[]){v_t_24239});
    }
    default: return heff_nomatch(v_x21_24236);
    }
  }
  default: return heff_nomatch(v_x2_24234);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47(V self, V *args) {
  V v_n_24244 = args[0];
  V v_x_24243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24245 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24243}), v_n_24244});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24245});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48(V self, V *args) {
  V v_n_24247 = args[0];
  V v_m_24246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24248 = heff_tr(heff_call(v_m_24246, 1, (V[]){v_n_24247}));
  switch (heff_tag_of(v_x2_24248)) {
  case TAG_Left: {
    V v_e_24249 = heff_field(v_x2_24248, 0);
    V v_ru_24x2_24248_24Left = heff_take_reuse_n(v_x2_24248, 1ULL, 1);
    return heff_tag_re_n(v_ru_24x2_24248_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24249});
  }
  case TAG_Right: {
    V v_x21_24250 = heff_field(v_x2_24248, 0);
    V v_ru_24x2_24248_24Right = heff_take_reuse_n(v_x2_24248, 1ULL, 1);
    switch (heff_tag_of(v_x21_24250)) {
    case TAG_MkPair: {
      V v_x_24251 = heff_field(v_x21_24250, 0);
      V v_n_24252 = heff_field(v_x21_24250, 1);
      V v_ru_24x21_24250_24MkPair = heff_take_reuse_n(v_x21_24250, 3ULL, 2);
      switch (heff_tag_of(v_x_24251)) {
      case TAG_MkPair: {
        V v_t_27_24253 = heff_field(v_x_24251, 0);
        heff_take_n(v_x_24251, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24248_24Right, TAG_Right, 1, (V[]){heff_tag_re_n(v_ru_24x21_24250_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_27_24253, v_n_24252})});
      }
      default: return heff_nomatch(v_x_24251);
      }
    }
    default: return heff_nomatch(v_x21_24250);
    }
  }
  default: return heff_nomatch(v_x2_24248);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 1)));
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_acc_243, 2, 3)));
    V v_x_247 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_245, v_t_246});
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0, 1, 1, (V[]){v_x_247});
  }
  case TAG_Cons: {
    V v_x61_249 = heff_field(v_x6_244, 0);
    V v_tail_2410 = heff_field(v_x6_244, 1);
    V v_ru_24x6_244_24Cons = heff_take_reuse_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_249)) {
    case TAG_MkPair: {
      V v_l_2411 = heff_field(v_x61_249, 0);
      V v_fe_2412 = heff_field(v_x61_249, 1);
      heff_take_n(v_x61_249, 3ULL, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_acc_243, 0))));
      V v_t_2414 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_242, 0)), heff_dup(heff_rfield(v_fieldTypes_242, 1)), heff_arrayFromList(v_t_2413)});
      V v_t_2415 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), v_l_2411, v_t_2414));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_MkField: {
        V v_fty_2416 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 2);
        V v_t_2418 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_fty_2416)));
        if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
          heff_drop(v_l_2411);
          heff_drop(v_fty_2416);
          heff_drop(v_t_2418);
          V v_x1_2419 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2412, heff_dup(heff_rfield(v_c_240, 1))));
          V v_t_2423;
          switch (heff_tag_of(v_x1_2419)) {
          case TAG_Nom: {
            V v_x_2420 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            v_t_2423 = v_x_2420;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2419, 0ULL, 1);
            v_t_2423 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2422 = heff_field(v_x1_2419, 0);
            heff_take_n(v_x1_2419, 1ULL, 1);
            v_t_2423 = v_x_2422;
            break;
          }
          default: heff_nomatch(v_x1_2419);
          }
          V v_t_2424 = heff_tag_at_n(v_ru_24x6_244_24Cons, TAG_Cons, 2, (V[]){v_t_2423, heff_dup(heff_rfield(v_acc_243, 0))});
          V v_t_2425 = ({ V rv_0 = v_t_2424; V rr_ = heff_rec_reuse_nf(v_acc_243, 6ULL, 3, shape_vs__out__tys, 60u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2425;
          V t_4 = v_tail_2410;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        } else {
          heff_drop_cell(v_ru_24x6_244_24Cons, 2);
          heff_drop(v_t_2418);
          V v_m_2426 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_fe_2412), heff_dup(v_fty_2416)));
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1, 1, 9, (V[]){v_m_2426, v_c_240, v_fe_2412, v_fty_2416, v_acc_243, v_l_2411, v_capture_241, v_fieldTypes_242, v_tail_2410});
        }
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    default: return heff_nomatch(v_x61_249);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_n_248})});
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args) {
  V v_n_2427 = args[0];
  V v_m_2426 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2412 = heff_env(self)[2];
  V v_fty_2416 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_l_2411 = heff_env(self)[5];
  V v_capture_241 = heff_env(self)[6];
  V v_fieldTypes_242 = heff_env(self)[7];
  V v_tail_2410 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x2_2428 = heff_tr(heff_call(v_m_2426, 1, (V[]){v_n_2427}));
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Left: {
    V v_e_2429 = heff_field(v_x2_2428, 0);
    V v_ru_24x2_2428_24Left = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fe_2412);
    heff_drop(v_fty_2416);
    heff_drop_rec(v_acc_243, 3);
    heff_drop(v_l_2411);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    heff_drop(v_tail_2410);
    return heff_tag_re_n(v_ru_24x2_2428_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2429});
  }
  case TAG_Right: {
    V v_x21_2430 = heff_field(v_x2_2428, 0);
    V v_ru_24x2_2428_24Right = heff_take_reuse_n(v_x2_2428, 1ULL, 1);
    switch (heff_tag_of(v_x21_2430)) {
    case TAG_MkPair: {
      V v_x_2431 = heff_field(v_x21_2430, 0);
      V v_n_2432 = heff_field(v_x21_2430, 1);
      V v_ru_24x21_2430_24MkPair = heff_take_reuse_n(v_x21_2430, 3ULL, 2);
      V v_x1_2433 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF_24s1951400957x375540232(heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2412, heff_dup(heff_rfield(v_c_240, 1))));
      V v_t_2437;
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_Nom: {
        V v_x_2434 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2437 = v_x_2434;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2433, 0ULL, 1);
        v_t_2437 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2436 = heff_field(v_x1_2433, 0);
        heff_take_n(v_x1_2433, 1ULL, 1);
        v_t_2437 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x1_2433);
      }
      V v_x1_2438 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2416));
      V v_t_2450;
      switch (heff_tag_of(v_x1_2438)) {
      case TAG_LikeU: {
        heff_take_n(v_x1_2438, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x1_2438, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_x1_2438, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x1_2438, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeInt: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFloat: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtFloat);
        break;
      }
      case TAG_LikeString: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRune: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x1_2438, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFixed: {
        V v_w_2449 = heff_field(v_x1_2438, 0);
        heff_take_n(v_x1_2438, 1ULL, 1);
        v_t_2450 = heff_tag_at_n(v_ru_24x2_2428_24Right, TAG_FtFixed, 1, (V[]){v_w_2449});
        break;
      }
      case TAG_NoRules: {
        heff_drop_cell(v_ru_24x2_2428_24Right, 1);
        v_t_2450 = NTAG(TAG_FtAny);
        break;
      }
      default: heff_nomatch(v_x1_2438);
      }
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, heff_take_field(v_acc_243, 0)});
      V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_2430_24MkPair, TAG_MkPair, 2, (V[]){v_l_2411, v_x_2431}), heff_take_field(v_acc_243, 1)});
      V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, heff_take_field(v_acc_243, 2)});
      V v_t_2454 = (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_241, v_fieldTypes_242, ({ V rv_0 = v_t_2451; V rv_1 = v_t_2452; V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_acc_243, 0ULL, 3, shape_vs__out__tys, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; }), v_tail_2410));
      V f_ = v_t_2454;
      args[0] = v_n_2432;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2430);
    }
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_24cpr_str0, 27, "this needs an expected type");

HeffT3 g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_24cpr(V v_c_240, V v_vs_241, V v_x4_242, V v_z_243) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_z_243);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_24cpr_str0), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        V v_m_2410 = (g_heff_2ecompile_2eerase_2earmBind(heff_dup(v_c_240), heff_dup(v_vs_241), v_tag_246, heff_arrayToList(heff_dup(v_xs_248))));
        V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_243}));
        switch (heff_tag_of(v_x2_2411)) {
        case TAG_Left: {
          V v_e_2412 = heff_field(v_x2_2411, 0);
          heff_take_n(v_x2_2411, 1ULL, 1);
          heff_drop(v_c_240);
          heff_drop(v_vs_241);
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_e_2412, MK_INT(0LL)}});
        }
        case TAG_Right: {
          V v_x21_2413 = heff_field(v_x2_2411, 0);
          heff_take_n(v_x2_2411, 1ULL, 1);
          switch (heff_tag_of(v_x21_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x21_2413, 0);
            V v_n_2415 = heff_field(v_x21_2413, 1);
            heff_take_n(v_x21_2413, 3ULL, 2);
            V v_t_2416 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_get_n(v_x_2414, 0, 2), heff_dup(v_body_249)));
            V v_x2_2417 = heff_tr(heff_call(v_t_2416, 1, (V[]){heff_dup(v_n_2415)}));
            switch (heff_tag_of(v_x2_2417)) {
            case TAG_Left: {
              heff_take_n(v_x2_2417, 0ULL, 1);
              V t_0 = v_c_240;
              V t_1 = v_vs_241;
              V t_2 = v_tail_245;
              V t_3 = v_n_2415;
              v_c_240 = t_0;
              v_vs_241 = t_1;
              v_x4_242 = t_2;
              v_z_243 = t_3;
              goto top;
            }
            case TAG_Right: {
              V v_x21_2419 = heff_field(v_x2_2417, 0);
              heff_take_n(v_x2_2417, 1ULL, 1);
              heff_drop(v_c_240);
              heff_drop(v_vs_241);
              heff_drop(v_n_2415);
              switch (heff_tag_of(v_x21_2419)) {
              case TAG_MkPair: {
                V v_x_2420 = heff_field(v_x21_2419, 0);
                V v_n_27_2421 = heff_field(v_x21_2419, 1);
                heff_take_n(v_x21_2419, 3ULL, 2);
                switch (heff_tag_of(v_x_2420)) {
                case TAG_MkPair: {
                  V v_ty_2423 = heff_field(v_x_2420, 1);
                  heff_take_n(v_x_2420, 2ULL, 2);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_ty_2423, v_n_27_2421}});
                }
                default: return ((HeffT3){{heff_nomatch(v_x_2420)}});
                }
              }
              default: return ((HeffT3){{heff_nomatch(v_x21_2419)}});
              }
            }
            default: return ((HeffT3){{heff_nomatch(v_x2_2417)}});
            }
          }
          default: return ((HeffT3){{heff_nomatch(v_x21_2413)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x2_2411)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x412_247)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x41_244)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x4_242)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2, 0, "");
Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  return (g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2), v_c_240, v_t_241, v_ty_242));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_str0, 2, ": ");
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1(V self, V *args);

HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V v_g_240) {
top: ;
  V v_t_247 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
  V v_t_248 = heff_rec_n(3, shape_defs__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_acc_2425 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1, 2, 1, (V[]){v_g_240}); V a_1 = v_t_248; V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_defs_2426 = heff_take_field(v_acc_2425, 0);
  V v_errors_2427 = heff_take_field(v_acc_2425, 1);
  V v_supply_2428 = heff_get_n(v_acc_2425, 2, 3);
  V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2426));
  V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_errors_2427));
  V v_f_2431 = v_supply_2428;
  return ((HeffT3){{v_t_2429, v_t_2430, v_f_2431}});
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0(V self, V *args) {
  V v_acc_241 = args[0];
  V v_k_242 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_243 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_242; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_e_246 = v_field_245;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_242, v_e_246}), v_acc_241});
    } else {
      heff_drop(v_k_242);
      heff_drop(v_field_245);
      return v_acc_241;
    }
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1(V self, V *args) {
  V v_acc_249 = args[0];
  V v_p_2410 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_g_2411 = v_g_240;
  V v_acc_2412 = v_acc_249;
  V v_x3_2413 = v_p_2410;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_MkPair: {
    V v_key_2414 = heff_field(v_x3_2413, 0);
    V v_e_2415 = heff_field(v_x3_2413, 1);
    V v_ru_24x3_2413_24MkPair = heff_take_reuse_n(v_x3_2413, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eerase_2eisType(MK_INT(0LL), heff_dup(heff_rfield(v_e_2415, 3))));
    if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
      heff_drop(v_g_2411);
      heff_drop(v_key_2414);
      heff_drop_rec(v_e_2415, 4);
      heff_drop_cell(v_ru_24x3_2413_24MkPair, 2);
      heff_drop(v_t_2416);
      return v_acc_2412;
    } else {
      heff_drop(v_t_2416);
      V v_it_2417 = heff_tr(g_heff_2ecompile_2eerase_2edefinition(v_g_2411, heff_dup(v_key_2414), v_e_2415, heff_dup(heff_rfield(v_acc_2412, 2))));
      switch (heff_tag_of(v_it_2417)) {
      case TAG_Left: {
        V v_err_2418 = heff_field(v_it_2417, 0);
        heff_take_n(v_it_2417, 1ULL, 1);
        V v_t_2419 = heff_strAppend(heff_strAppend(v_key_2414, ((V)&g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_str0)), v_err_2418);
        V v_t_2420 = heff_tag_at_n(v_ru_24x3_2413_24MkPair, TAG_Cons, 2, (V[]){v_t_2419, heff_dup(heff_rfield(v_acc_2412, 1))});
        return ({ V rv_1 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_acc_2412, 5ULL, 3, shape_defs__errors__supply, 51u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      }
      case TAG_Right: {
        V v_it1_2421 = heff_field(v_it_2417, 0);
        heff_take_n(v_it_2417, 1ULL, 1);
        switch (heff_tag_of(v_it1_2421)) {
        case TAG_MkPair: {
          V v_body_2422 = heff_field(v_it1_2421, 0);
          V v_n_2423 = heff_field(v_it1_2421, 1);
          heff_take_n(v_it1_2421, 3ULL, 2);
          V v_t_2424 = heff_tag_at_n(v_ru_24x3_2413_24MkPair, TAG_Cons, 2, (V[]){heff_rec_n(3, shape_key__name__body, (V[]){heff_dup(v_key_2414), v_key_2414, v_body_2422}), heff_dup(heff_rfield(v_acc_2412, 0))});
          return ({ V rv_0 = v_t_2424; V rv_2 = v_n_2423; V rr_ = heff_rec_reuse_nf(v_acc_2412, 2ULL, 3, shape_defs__errors__supply, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
        default: return heff_nomatch(v_it1_2421);
        }
      }
      default: return heff_nomatch(v_it_2417);
      }
    }
  }
  default: return heff_nomatch(v_x3_2413);
  }
}