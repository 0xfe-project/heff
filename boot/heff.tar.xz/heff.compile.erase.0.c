// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_EAbandon 62759
#define TAG_EFix 37759
#define TAG_ELam 43266
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_ERecord 5518
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936 63224
#define TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145 14377
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_HLocal 25864
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpId 35501
#define LBL_byName 571997869
#define LBL_c 317
#define LBL_defs 9574869
#define LBL_entries 787768015
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_ir 10128
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_supply 1056026650
#define LBL_ty 10476
#define LBL_tys 324872
#define LBL_values 1123329101
#define LBL_vars 10107635
#define LBL_vs 10532
static uint32_t shape_c__vars[] = {LBL_c, LBL_vars};
static uint32_t shape_defs__errors__supply[] = {LBL_defs, LBL_errors, LBL_supply};
static uint32_t shape_ir__ty[] = {LBL_ir, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_locals__env__len__globals[] = {LBL_locals, LBL_env, LBL_len, LBL_globals};
static uint32_t shape_vs__out__tys[] = {LBL_vs, LBL_out, LBL_tys};
V g_array_2eempty_get(void);
V g_heff_2ecompile_2eerase_2earmBind(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmBind_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBind_clo;
V g_heff_2ecompile_2eerase_2earmBindGo(V, V);
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmBindGo_clo;
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(V, V, V, V);
V g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708_clo;
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V, V, V);
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE(V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_clo;
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V, V);
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo;
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616_clo;
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo;
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V, V, V);
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo;
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo;
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V, V, V, V, V, V, V);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo;
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(V, V);
V g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513_clo;
V g_heff_2ecompile_2eerase_2eeraseOne(V, V, V);
V g_heff_2ecompile_2eerase_2eeraseOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseOne_clo;
HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V);
V g_heff_2ecompile_2eerase_2eextend(V, V, V);
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eextend_clo;
V g_heff_2ecompile_2eerase_2efieldTyOr(V, V, V, V);
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo;
HeffT2 g_heff_2ecompile_2eerase_2efieldTyOr_24cpr(V, V, V, V);
V g_heff_2ecompile_2eerase_2eisType(V, V);
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eisType_clo;
V g_heff_2ecompile_2eerase_2ematchVariants(V);
V g_heff_2ecompile_2eerase_2ematchVariants_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ematchVariants_clo;
V g_heff_2ecompile_2eerase_2eprojTyInWith(V, V, V, V);
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo;
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(V, V);
V g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618_clo;
V g_heff_2ecompile_2eerase_2ezipE(V, V);
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_clo;
V g_heff_2ecompile_2eerase_2ezipE_24dps(V, V, V);
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
HeffT2 g_heff_2eelab_2erules_2efieldTyAt_24cpr(V, V, V, V, V, V);
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
HeffT2 g_heff_2eelab_2evalue_2eprojTyWith_24cpr(V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection(V, V, V, V);
V g_heff_2eelab_2evalue_2etypeForProjection_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2etypeForProjection_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24s1990719097x1419059608(V);
V g_list_2emap_24s1990719097x1419059608_entry(V self, V *a);
extern Clo g_list_2emap_24s1990719097x1419059608_clo;
V g_prelude_2etraverse_24s352965232x546119438(V, V);
V g_prelude_2etraverse_24s352965232x546119438_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s352965232x546119438_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eextend_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eextend_entry, 3, 0};

V g_heff_2ecompile_2eerase_2eextend(V v_c_240, V v_ir_241, V v_ty_242) {
top: ;
  V v_locals_243 = heff_take_field(v_c_240, 0);
  V v_len_244 = heff_take_field(v_c_240, 2);
  V v_env_245 = heff_take_field(v_c_240, 1);
  V v_globals_246 = heff_get_n(v_c_240, 3, 4);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_ir_241, heff_dup(v_ty_242)}), v_locals_243});
  V v_v_249 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(v_len_244)}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam0, 1, 1, (V[]){v_ty_242}), NTAG(TAG_Nothing)));
  return heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_247, heff_tag_n(TAG_LSnoc, 2, (V[]){v_env_245, heff_clo_n(g_heff_2ecompile_2eerase_2eextend_lam1, 1, 1, (V[]){v_v_249})}), heff_intAdd(v_len_244, MK_INT(1LL)), v_globals_246});
}
V g_heff_2ecompile_2eerase_2eextend_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eextend(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2eextend_lam0(V self, V *args) {
  V v_u_248 = args[0];
  V v_ty_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return v_ty_242;
}
V g_heff_2ecompile_2eerase_2eextend_lam1(V self, V *args) {
  V v_u_2410 = args[0];
  V v_v_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2410);
  return v_v_249;
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args);
Clo g_heff_2ecompile_2eerase_2eisType_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eisType_entry, 2, 0};

V g_heff_2ecompile_2eerase_2eisType(V v_lvl_240, V v_t_241) {
top: ;
  V v_t_242 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_LikeU: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_True);
  }
  case TAG_LikeFunction: {
    V v_dom_245 = heff_field(v_t_242, 1);
    V v_cod_246 = heff_field(v_t_242, 2);
    heff_take_n(v_t_242, 6ULL, 4);
    V v_x1_2414;
    switch (heff_tag_of(v_cod_246)) {
    case TAG_MkClo: {
      V v_vs_249 = heff_field(v_cod_246, 1);
      V v_body_2410 = heff_field(v_cod_246, 2);
      heff_take_n(v_cod_246, 6ULL, 3);
      v_x1_2414 = heff_tr(heff_call(v_body_2410, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_249, heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam0, 1, 2, (V[]){heff_dup(v_lvl_240), v_dom_245})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2413 = heff_field(v_cod_246, 0);
      heff_take_n(v_cod_246, 1ULL, 1);
      heff_drop(v_dom_245);
      v_x1_2414 = v_body_2413;
      break;
    }
    default: heff_nomatch(v_cod_246);
    }
    V v_t_2418;
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_Nom: {
      V v_x_2415 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2415;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2414, 0ULL, 1);
      v_t_2418 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2417 = heff_field(v_x1_2414, 0);
      heff_take_n(v_x1_2414, 1ULL, 1);
      v_t_2418 = v_x_2417;
      break;
    }
    default: heff_nomatch(v_x1_2414);
    }
    V t_0 = heff_intAdd(v_lvl_240, MK_INT(1LL));
    V t_1 = v_t_2418;
    v_lvl_240 = t_0;
    v_t_241 = t_1;
    goto top;
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeSum: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeInt: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFloat: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeString: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeRune: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeArray: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_LikeFixed: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  case TAG_NoRules: {
    heff_drop(v_lvl_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eerase_2eisType_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2eisType(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2eisType_lam1(V self, V *args) {
  V v_u_2412 = args[0];
  V v_dom_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2412);
  return v_dom_245;
}
V g_heff_2ecompile_2eerase_2eisType_lam0(V self, V *args) {
  V v_u_2411 = args[0];
  V v_lvl_240 = heff_env(self)[0];
  V v_dom_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2411);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_lvl_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2eisType_lam1, 1, 1, (V[]){v_dom_245}), NTAG(TAG_Nothing)));
}
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str0, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str1, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str2, 14, "the type of `.");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str3, 36, "` depends on fields not in hand here");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str4, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str5, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str6, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str7, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str8, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str9, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str10, 54, "projecting from something that is not of a record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2eprojTyInWith_str11, 54, "projecting from something that is not of a record type");
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam1, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam2, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam5, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam6, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam7, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam8, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam9, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2eprojTyInWith_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_lam12, 1, 0};
Clo g_heff_2ecompile_2eerase_2eprojTyInWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2eprojTyInWith_entry, 4, 0};

V g_heff_2ecompile_2eerase_2eprojTyInWith(V v_len_240, V v_t_241, V v_fs_242, V v_l_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2eelab_2evalue_2eprojTyWith_24cpr(heff_dup(v_t_241), v_fs_242, v_l_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      heff_drop(v_len_240);
      heff_drop(v_t_241);
      heff_drop(v_l_243);
      V v_ty_247 = v_field_246;
      return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam0, 1, 1, (V[]){v_ty_247});
    } else {
      heff_drop(v_field_246);
      V v_t_249 = (g_heff_2eelab_2evalue_2ebehavior(v_t_241));
      switch (heff_tag_of(v_t_249)) {
      case TAG_LikeU: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam1_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_249, 0ULL, 4);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam2_clo);
      }
      case TAG_LikeRecord: {
        V v_capture_2418 = heff_field(v_t_249, 1);
        V v_fieldTypes_2419 = heff_field(v_t_249, 2);
        heff_take_n(v_t_249, 6ULL, 3);
        HeffT2 v_t_2420 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_fieldTypes_2419, 1), v_l_243));
        V v_t_2424;
        {
          V v_field_2422 = v_t_2420.f[1];
          int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
          if ((v_tag_2421 == ((int64_t)0ULL))) {
            V v_i_2423 = v_field_2422;
            v_t_2424 = v_i_2423;
          } else {
            heff_drop(v_field_2422);
            v_t_2424 = heff_abandon();
          }
        }
        HeffT2 v_t_2425 = (g_heff_2eelab_2erules_2efieldTyAt_24cpr(v_len_240, v_capture_2418, v_fieldTypes_2419, v_t_2424, heff_dup(g_array_2eempty_get()), MK_INT(0LL)));
        {
          V v_field_2427 = v_t_2425.f[1];
          int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
          if ((v_tag_2426 == ((int64_t)0ULL))) {
            heff_drop(v_l_243);
            V v_ty_2428 = v_field_2427;
            return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam3, 1, 1, (V[]){v_ty_2428});
          } else {
            heff_drop(v_field_2427);
            return heff_clo_n(g_heff_2ecompile_2eerase_2eprojTyInWith_lam4, 1, 1, (V[]){v_l_243});
          }
        }
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam5_clo);
      }
      case TAG_LikeInt: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam6_clo);
      }
      case TAG_LikeFloat: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam7_clo);
      }
      case TAG_LikeString: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam8_clo);
      }
      case TAG_LikeRune: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam9_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam10_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_249, 0ULL, 1);
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam11_clo);
      }
      case TAG_NoRules: {
        heff_drop(v_len_240);
        heff_drop(v_l_243);
        return ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_lam12_clo);
      }
      default: return heff_nomatch(v_t_249);
      }
    }
  }
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eerase_2eprojTyInWith(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam0(V self, V *args) {
  V v_n_248 = args[0];
  V v_ty_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_247, v_n_248})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  heff_drop(v_n_2411);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str0)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam2(V self, V *args) {
  V v_n_2416 = args[0];
  heff_drop(v_n_2416);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str1)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam3(V self, V *args) {
  V v_n_2429 = args[0];
  V v_ty_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2428, v_n_2429})});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam4(V self, V *args) {
  V v_n_2430 = args[0];
  V v_l_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_2430);
  V v_t_2431 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str2), heff_strAppend(v_l_243, ((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str3)));
  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2431});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam5(V self, V *args) {
  V v_n_2433 = args[0];
  heff_drop(v_n_2433);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str4)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam6(V self, V *args) {
  V v_n_2434 = args[0];
  heff_drop(v_n_2434);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str5)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam7(V self, V *args) {
  V v_n_2435 = args[0];
  heff_drop(v_n_2435);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str6)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam8(V self, V *args) {
  V v_n_2436 = args[0];
  heff_drop(v_n_2436);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str7)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam9(V self, V *args) {
  V v_n_2437 = args[0];
  heff_drop(v_n_2437);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str8)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam10(V self, V *args) {
  V v_n_2439 = args[0];
  heff_drop(v_n_2439);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str9)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam11(V self, V *args) {
  V v_n_2441 = args[0];
  heff_drop(v_n_2441);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str10)});
}
V g_heff_2ecompile_2eerase_2eprojTyInWith_lam12(V self, V *args) {
  V v_n_2442 = args[0];
  heff_drop(v_n_2442);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2eprojTyInWith_str11)});
}
Clo g_heff_2ecompile_2eerase_2efieldTyOr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2efieldTyOr_entry, 4, 0};

V g_heff_2ecompile_2eerase_2efieldTyOr(V v_len_240, V v_t_241, V v_k_242, V v_x4_243) {
top: ;
  HeffT2 v_t_244 = (g_heff_2ecompile_2eerase_2efieldTyOr_24cpr(v_len_240, v_t_241, v_k_242, v_x4_243));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_246});
    } else {
      heff_drop(v_field_246);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eerase_2efieldTyOr_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ecompile_2eerase_2efieldTyOr(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eerase_2ezipE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ezipE(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_242);
      heff_drop(v_xs_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_y_244 = heff_field(v_x2_241, 0);
      V v_ys_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_242, v_y_244}), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eerase_2ezipE_24dps(v_xs_243, v_ys_245, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE(a[0], a[1]);
}
Clo g_heff_2ecompile_2eerase_2ezipE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ezipE_24dps_entry, 3, 0};

V g_heff_2ecompile_2eerase_2ezipE_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_y_245 = heff_field(v_x2_241, 0);
      V v_ys_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_y_245}), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_xs_244;
      V t_1 = v_ys_246;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ezipE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ezipE_24dps(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str2, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2earmBindGo_str3, 1, "$");
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmBindGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmBindGo_entry, 2, 0};

V g_heff_2ecompile_2eerase_2earmBindGo(V v_acc_240, V v_x2_241) {
top: ;
  V v_c_242 = heff_take_field(v_acc_240, 0);
  V v_vars_243 = heff_get_n(v_acc_240, 1, 2);
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vars_243));
    V v_x_245 = heff_rec_n(2, shape_c__vars, (V[]){v_c_242, v_t_244});
    return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam0, 1, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_x21_247 = heff_field(v_x2_241, 0);
    V v_rest_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_247)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x21_247, 0);
      V v_aty_2410 = heff_field(v_x21_247, 1);
      heff_take_n(v_x21_247, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_242, 2)), heff_dup(v_aty_2410)));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_x_249);
        heff_drop(v_t_2411);
        V v_t_2412 = (g_heff_2ecompile_2eerase_2eextend(v_c_242, NTAG(TAG_Nothing), v_aty_2410));
        V t_0 = heff_rec_n(2, shape_c__vars, (V[]){v_t_2412, v_vars_243});
        V t_1 = v_rest_248;
        v_acc_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_2411);
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmBindGo_lam1, 1, 5, (V[]){v_x_249, v_c_242, v_aty_2410, v_vars_243, v_rest_248});
      }
    }
    default: return heff_nomatch(v_x21_247);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eerase_2earmBindGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmBindGo(a[0], a[1]);
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam0(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_245, v_n_246})});
}
V g_heff_2ecompile_2eerase_2earmBindGo_lam1(V self, V *args) {
  V v_n_2413 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_aty_2410 = heff_env(self)[2];
  V v_vars_243 = heff_env(self)[3];
  V v_rest_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2414;
  if ((heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str0), 2) || heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str1), 2))) {
    heff_drop(v_x_249);
    v_t_2414 = ((V)&g_heff_2ecompile_2eerase_2earmBindGo_str2);
  } else {
    v_t_2414 = v_x_249;
  }
  V v_t_2415 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2earmBindGo_str3), heff_intShow(heff_dup(v_n_2413)));
  V v_x_2416 = heff_strAppend(v_t_2414, v_t_2415);
  V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2416)})});
  V v_t_2418 = (g_heff_2ecompile_2eerase_2eextend(v_c_242, v_t_2417, v_aty_2410));
  V v_t_2419 = heff_rec_n(2, shape_c__vars, (V[]){v_t_2418, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2416, v_vars_243})});
  V v_t_2420 = (g_heff_2ecompile_2eerase_2earmBindGo(v_t_2419, v_rest_248));
  V f_ = v_t_2420;
  args[0] = heff_intAdd(v_n_2413, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry, 2, 0};

V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_xs_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eerase_2ecatMaybesE_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2ecatMaybesE_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str0, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str1, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str6, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str7, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str8, 1, "$");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str9, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str10, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str11, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str12, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str13, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str14, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str15, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str16, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str17, 46, "a function checked against a non-function type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str18, 26, "a type in a value position");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str20, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str21, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str22, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str23, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str24, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str25, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str26, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str27, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str28, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str29, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str30, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str31, 42, "a record checked against a non-record type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str32, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str33, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str34, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str35, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str36, 7, "no tag ");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str37, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str38, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str39, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str40, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str41, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str42, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str43, 36, "a tag checked against a non-sum type");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str44, 14, "an opaque term");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str45, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str46, 1, "_");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str47, 1, "x");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str48, 1, "$");
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam49(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam50(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52(V self, V *args); static Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52, 1, 0};
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam54(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam55(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam56(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam57(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam58(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam59(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam60(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam61(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam62(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam63(V self, V *args);
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam64(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry, 7, 0};

V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(V v_tag_240, V v_c_241, V v_abs_242, V v_ty_243, V v_c_244, V v_t_245, V v_ty_246) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145: {
    top_TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145: ;
    heff_drop_rec(v_c_244, 4);
    heff_drop(v_t_245);
    heff_drop(v_ty_246);
    V v_t_247 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_243));
    switch (heff_tag_of(v_t_247)) {
    case TAG_LikeU: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0_clo);
    }
    case TAG_LikeFunction: {
      V v_dom_2411 = heff_field(v_t_247, 1);
      V v_cod_2412 = heff_field(v_t_247, 2);
      heff_take_n(v_t_247, 6ULL, 4);
      V v_it1_2419;
      V v_body_2420;
      switch (heff_tag_of(v_abs_242)) {
      case TAG_MkAbs: {
        V v_n_2414 = heff_field(v_abs_242, 0);
        V v_b_2415 = heff_field(v_abs_242, 1);
        V v_ru_24abs_242_24MkAbs = heff_take_reuse_n(v_abs_242, 3ULL, 2);
        V v_t_2416 = heff_tag_at_n(v_ru_24abs_242_24MkAbs, TAG_MkPair, 2, (V[]){v_n_2414, NTAG(TAG_True)});
        v_it1_2419 = v_t_2416;
        v_body_2420 = v_b_2415;
        break;
      }
      case TAG_AbsConst: {
        V v_b_2417 = heff_field(v_abs_242, 0);
        heff_take_n(v_abs_242, 1ULL, 1);
        V v_t_2418 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str1), NTAG(TAG_False)});
        v_it1_2419 = v_t_2418;
        v_body_2420 = v_b_2417;
        break;
      }
      default: heff_nomatch(v_abs_242);
      }
      switch (heff_tag_of(v_it1_2419)) {
      case TAG_MkPair: {
        V v_hint_2421 = heff_field(v_it1_2419, 0);
        V v_bound_2422 = heff_field(v_it1_2419, 1);
        V v_ru_24it1_2419_24MkPair = heff_take_reuse_n(v_it1_2419, 3ULL, 2);
        V v_t_2423 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_241, 2)), heff_dup(v_dom_2411)));
        if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
          heff_drop(v_hint_2421);
          heff_drop(v_t_2423);
          V v_c_2432;
          if ((heff_dup(v_bound_2422) == NTAG(TAG_True))) {
            heff_drop(v_bound_2422);
            V v_t_2424 = heff_rec_n(2, shape_ir__ty, (V[]){NTAG(TAG_Nothing), heff_dup(v_dom_2411)});
            V v_t_2425 = heff_tag_at_n(v_ru_24it1_2419_24MkPair, TAG_Cons, 2, (V[]){v_t_2424, heff_dup(heff_rfield(v_c_241, 0))});
            V v_t_2426 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_241, 2))});
            V v_v_2428 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2426, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1, 1, 1, (V[]){heff_dup(v_dom_2411)}), NTAG(TAG_Nothing)));
            V v_t_2430 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_241, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2, 1, 1, (V[]){v_v_2428})});
            V v_t_2431 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 2)), MK_INT(1LL));
            v_c_2432 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2425, v_t_2430, v_t_2431, heff_dup(heff_rfield(v_c_241, 3))});
          } else {
            heff_drop(v_bound_2422);
            heff_drop_cell(v_ru_24it1_2419_24MkPair, 2);
            v_c_2432 = heff_dup(v_c_241);
          }
          V v_x1_2440;
          switch (heff_tag_of(v_cod_2412)) {
          case TAG_MkClo: {
            V v_vs_2434 = heff_field(v_cod_2412, 1);
            V v_body_2435 = heff_field(v_cod_2412, 2);
            heff_take_n(v_cod_2412, 6ULL, 3);
            v_x1_2440 = heff_tr(heff_call(v_body_2435, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2434, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3, 1, 2, (V[]){v_c_241, v_dom_2411})})}));
            break;
          }
          case TAG_CloConst: {
            V v_body_2439 = heff_field(v_cod_2412, 0);
            heff_take_n(v_cod_2412, 1ULL, 1);
            heff_drop_rec(v_c_241, 4);
            heff_drop(v_dom_2411);
            v_x1_2440 = v_body_2439;
            break;
          }
          default: heff_nomatch(v_cod_2412);
          }
          V v_ty_2444;
          switch (heff_tag_of(v_x1_2440)) {
          case TAG_Nom: {
            V v_x_2441 = heff_field(v_x1_2440, 0);
            heff_take_n(v_x1_2440, 1ULL, 1);
            v_ty_2444 = v_x_2441;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2440, 0ULL, 1);
            v_ty_2444 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2443 = heff_field(v_x1_2440, 0);
            heff_take_n(v_x1_2440, 1ULL, 1);
            v_ty_2444 = v_x_2443;
            break;
          }
          default: heff_nomatch(v_x1_2440);
          }
          V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
          V t_1 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str2);
          V t_2 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str3);
          V t_3 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str4);
          V t_4 = v_c_2432;
          V t_5 = v_body_2420;
          V t_6 = v_ty_2444;
          v_tag_240 = t_0;
          v_c_241 = t_1;
          v_abs_242 = t_2;
          v_ty_243 = t_3;
          v_c_244 = t_4;
          v_t_245 = t_5;
          v_ty_246 = t_6;
          goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
        } else {
          heff_drop_cell(v_ru_24it1_2419_24MkPair, 2);
          heff_drop(v_t_2423);
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5, 1, 6, (V[]){v_hint_2421, v_bound_2422, v_dom_2411, v_c_241, v_cod_2412, v_body_2420});
        }
      }
      default: return heff_nomatch(v_it1_2419);
      }
    }
    case TAG_LikeRecord: {
      heff_take_n(v_t_247, 0ULL, 3);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10_clo);
    }
    case TAG_LikeSum: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11_clo);
    }
    case TAG_LikeInt: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12_clo);
    }
    case TAG_LikeFloat: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13_clo);
    }
    case TAG_LikeString: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14_clo);
    }
    case TAG_LikeRune: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15_clo);
    }
    case TAG_LikeArray: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16_clo);
    }
    case TAG_LikeFixed: {
      heff_take_n(v_t_247, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17_clo);
    }
    case TAG_NoRules: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18_clo);
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936: {
    top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936: ;
    switch (heff_tag_of(v_t_245)) {
    case TAG_SLocal: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_2494 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19, 1, 1, (V[]){v_m_2494});
    }
    case TAG_SGlobal: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24104 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20, 1, 1, (V[]){v_m_24104});
    }
    case TAG_SCode: {
      heff_take_n(v_t_245, 0ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21_clo);
    }
    case TAG_SApp: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24117 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22, 1, 1, (V[]){v_m_24117});
    }
    case TAG_SLam: {
      V v_abs_24127 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145);
      V t_1 = v_c_244;
      V t_2 = v_abs_24127;
      V t_3 = v_ty_246;
      V t_4 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str19);
      V t_5 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str20);
      V t_6 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str21);
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145;
    }
    case TAG_SCons: {
      V v_d_24128 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_keys_24129 = heff_take_field(v_d_24128, 0);
      V v_values_24130 = heff_get_n(v_d_24128, 2, 3);
      V v_t_24131 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_246));
      switch (heff_tag_of(v_t_24131)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24131, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_24131, 0ULL, 4);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24_clo);
      }
      case TAG_LikeRecord: {
        V v_capture_24140 = heff_field(v_t_24131, 1);
        V v_fieldTypes_24141 = heff_field(v_t_24131, 2);
        heff_take_n(v_t_24131, 6ULL, 3);
        V v_t_24142 = heff_rec_n(3, shape_vs__out__tys, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
        V v_t_24143 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_24129), heff_arrayToList(v_values_24130)));
        return (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_244, v_capture_24140, v_fieldTypes_24141, v_t_24142, v_t_24143));
      }
      case TAG_LikeSum: {
        heff_take_n(v_t_24131, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25_clo);
      }
      case TAG_LikeInt: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26_clo);
      }
      case TAG_LikeFloat: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27_clo);
      }
      case TAG_LikeString: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28_clo);
      }
      case TAG_LikeRune: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24131, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_24131, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31_clo);
      }
      case TAG_NoRules: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_keys_24129);
        heff_drop(v_values_24130);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32_clo);
      }
      default: return heff_nomatch(v_t_24131);
      }
    }
    case TAG_SProj: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24157 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33, 1, 1, (V[]){v_m_24157});
    }
    case TAG_STag: {
      V v_x_24166 = heff_field(v_t_245, 0);
      V v_args_24167 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_t_24168 = (g_heff_2eelab_2evalue_2ebehavior(v_ty_246));
      switch (heff_tag_of(v_t_24168)) {
      case TAG_LikeU: {
        heff_take_n(v_t_24168, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34_clo);
      }
      case TAG_LikeFunction: {
        heff_take_n(v_t_24168, 0ULL, 4);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35_clo);
      }
      case TAG_LikeRecord: {
        heff_take_n(v_t_24168, 0ULL, 3);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36_clo);
      }
      case TAG_LikeSum: {
        V v_vs_24180 = heff_field(v_t_24168, 0);
        heff_take_n(v_t_24168, 1ULL, 1);
        V v_byName_24181 = heff_take_field(v_vs_24180, 1);
        V v_values_24182 = heff_get_n(v_vs_24180, 2, 3);
        HeffT2 v_t_24183 = ({ V a_0 = v_byName_24181; V a_1 = v_x_24166; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_byName_24181); r_; });
        {
          V v_field_24185 = v_t_24183.f[1];
          int64_t v_tag_24184 = ((int64_t)v_t_24183.f[0]);
          if ((v_tag_24184 == ((int64_t)0ULL))) {
            V v_i_24186 = v_field_24185;
            V v_xs_24187 = v_values_24182;
            if ((heff_intLe_c_lent(MK_INT(0LL), v_i_24186, 1) && heff_intLt_c(heff_dup(v_i_24186), heff_arrayLength_lent(v_xs_24187, 0)))) {
              V v_ts_24188 = heff_arrayIndex(v_xs_24187, v_i_24186);
              V v_t_24189 = (g_list_2emap_24s1990719097x1419059608(heff_arrayToList(v_ts_24188)));
              V v_t_24190 = (g_heff_2ecompile_2eerase_2ezipE(heff_arrayToList(v_args_24167), v_t_24189));
              V v_m_24192 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37, 1, 1, (V[]){v_c_244}), v_t_24190));
              return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38, 1, 2, (V[]){v_m_24192, v_x_24166});
            } else {
              heff_drop_rec(v_c_244, 4);
              heff_drop(v_args_24167);
              heff_drop(v_i_24186);
              heff_drop(v_xs_24187);
              return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39, 1, 1, (V[]){v_x_24166});
            }
          } else {
            heff_drop_rec(v_c_244, 4);
            heff_drop(v_args_24167);
            heff_drop(v_values_24182);
            heff_drop(v_field_24185);
            return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40, 1, 1, (V[]){v_x_24166});
          }
        }
      }
      case TAG_LikeInt: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41_clo);
      }
      case TAG_LikeFloat: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42_clo);
      }
      case TAG_LikeString: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43_clo);
      }
      case TAG_LikeRune: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44_clo);
      }
      case TAG_LikeArray: {
        heff_take_n(v_t_24168, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45_clo);
      }
      case TAG_LikeFixed: {
        heff_take_n(v_t_24168, 0ULL, 1);
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46_clo);
      }
      case TAG_NoRules: {
        heff_drop_rec(v_c_244, 4);
        heff_drop(v_x_24166);
        heff_drop(v_args_24167);
        return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47_clo);
      }
      default: return heff_nomatch(v_t_24168);
      }
    }
    case TAG_SMatch: {
      V v_scrut_24215 = heff_field(v_t_245, 0);
      V v_cases_24216 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      V v_keys_24217 = heff_take_field(v_cases_24216, 0);
      V v_values_24218 = heff_get_n(v_cases_24216, 2, 3);
      V v_m_24219 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_dup(v_c_244), v_scrut_24215));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48, 1, 5, (V[]){v_m_24219, v_keys_24217, v_values_24218, v_c_244, v_ty_246});
    }
    case TAG_SSpecialize: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24246 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam50, 1, 1, (V[]){v_m_24246});
    }
    case TAG_SIs: {
      V v_t1_24255 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t1_24255;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SOpaque: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51_clo);
    }
    case TAG_SAbandon: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52_clo);
    }
    case TAG_SRec: {
      V v_t1_24259 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t1_24259;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SFix: {
      V v_t2_27_24261 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      switch (heff_tag_of(v_t2_27_24261)) {
      case TAG_MkAbs: {
        V v_x_24262 = heff_field(v_t2_27_24261, 0);
        V v_body_24263 = heff_field(v_t2_27_24261, 1);
        heff_take_n(v_t2_27_24261, 3ULL, 2);
        heff_drop_rec(v_c_241, 4);
        heff_drop(v_abs_242);
        heff_drop(v_ty_243);
        return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53, 1, 4, (V[]){v_x_24262, v_ty_246, v_c_244, v_body_24263});
      }
      case TAG_AbsConst: {
        V v_body_24284 = heff_field(v_t2_27_24261, 0);
        heff_take_n(v_t2_27_24261, 1ULL, 1);
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
        V t_1 = v_c_241;
        V t_2 = v_abs_242;
        V t_3 = v_ty_243;
        V t_4 = v_c_244;
        V t_5 = v_body_24284;
        V t_6 = v_ty_246;
        v_tag_240 = t_0;
        v_c_241 = t_1;
        v_abs_242 = t_2;
        v_ty_243 = t_3;
        v_c_244 = t_4;
        v_t_245 = t_5;
        v_ty_246 = t_6;
        goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
      }
      default: return heff_nomatch(v_t2_27_24261);
      }
    }
    case TAG_SImplicit: {
      V v_t2_27_24286 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936);
      V t_1 = v_c_241;
      V t_2 = v_abs_242;
      V t_3 = v_ty_243;
      V t_4 = v_c_244;
      V t_5 = v_t2_27_24286;
      V t_6 = v_ty_246;
      v_tag_240 = t_0;
      v_c_241 = t_1;
      v_abs_242 = t_2;
      v_ty_243 = t_3;
      v_c_244 = t_4;
      v_t_245 = t_5;
      v_ty_246 = t_6;
      goto top_TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936;
    }
    case TAG_SPrim: {
      V v_x_24287 = heff_field(v_t_245, 0);
      heff_take_n(v_t_245, 1ULL, 1);
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop_rec(v_c_244, 4);
      heff_drop(v_ty_246);
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam56, 1, 1, (V[]){v_x_24287});
    }
    case TAG_SMetaApp: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24293 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam57, 1, 1, (V[]){v_m_24293});
    }
    case TAG_SLitInt: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24303 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam58, 1, 1, (V[]){v_m_24303});
    }
    case TAG_SLitFloat: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24313 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam59, 1, 1, (V[]){v_m_24313});
    }
    case TAG_SLitString: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24323 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam60, 1, 1, (V[]){v_m_24323});
    }
    case TAG_SLitBytes: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24333 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam61, 1, 1, (V[]){v_m_24333});
    }
    case TAG_SLitRune: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24343 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam62, 1, 1, (V[]){v_m_24343});
    }
    case TAG_SLitFixed: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24354 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam63, 1, 1, (V[]){v_m_24354});
    }
    case TAG_SLitFloat32: {
      heff_drop_rec(v_c_241, 4);
      heff_drop(v_abs_242);
      heff_drop(v_ty_243);
      heff_drop(v_ty_246);
      V v_m_24364 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(v_c_244, v_t_245));
      return heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam64, 1, 1, (V[]){v_m_24364});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam0(V self, V *args) {
  V v_n_249 = args[0];
  heff_drop(v_n_249);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str0)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam1(V self, V *args) {
  V v_u_2427 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2427);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam2(V self, V *args) {
  V v_u_2429 = args[0];
  V v_v_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  return v_v_2428;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4(V self, V *args) {
  V v_u_2438 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2438);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam3(V self, V *args) {
  V v_u_2436 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_dom_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2436);
  V v_t_2437 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_241, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2437, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam4, 1, 1, (V[]){v_dom_2411}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6(V self, V *args) {
  V v_u_2452 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2452);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7(V self, V *args) {
  V v_u_2454 = args[0];
  V v_v_2453 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2454);
  return v_v_2453;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9(V self, V *args) {
  V v_u_2463 = args[0];
  V v_dom_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2463);
  return v_dom_2411;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8(V self, V *args) {
  V v_u_2461 = args[0];
  V v_c_241 = heff_env(self)[0];
  V v_dom_2411 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2461);
  V v_t_2462 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_c_241, 2, 4)});
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2462, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam9, 1, 1, (V[]){v_dom_2411}), NTAG(TAG_Nothing)));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam5(V self, V *args) {
  V v_n_2445 = args[0];
  V v_hint_2421 = heff_env(self)[0];
  V v_bound_2422 = heff_env(self)[1];
  V v_dom_2411 = heff_env(self)[2];
  V v_c_241 = heff_env(self)[3];
  V v_cod_2412 = heff_env(self)[4];
  V v_body_2420 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2446;
  if ((heff_strEq_c_lent(v_hint_2421, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str5), 2) || heff_strEq_c_lent(v_hint_2421, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str6), 2))) {
    heff_drop(v_hint_2421);
    v_t_2446 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str7);
  } else {
    v_t_2446 = v_hint_2421;
  }
  V v_t_2447 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str8), heff_intShow(heff_dup(v_n_2445)));
  V v_x_2448 = heff_strAppend(v_t_2446, v_t_2447);
  V v_c_2457;
  if ((heff_dup(v_bound_2422) == NTAG(TAG_True))) {
    heff_drop(v_bound_2422);
    V v_t_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_2448)})});
    V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_2449, heff_dup(v_dom_2411)}), heff_dup(heff_rfield(v_c_241, 0))});
    V v_t_2451 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_241, 2))});
    V v_v_2453 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2451, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam6, 1, 1, (V[]){heff_dup(v_dom_2411)}), NTAG(TAG_Nothing)));
    V v_t_2455 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_dup(heff_rfield(v_c_241, 1)), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam7, 1, 1, (V[]){v_v_2453})});
    V v_t_2456 = heff_intAdd(heff_dup(heff_rfield(v_c_241, 2)), MK_INT(1LL));
    v_c_2457 = heff_rec_n(4, shape_locals__env__len__globals, (V[]){v_t_2450, v_t_2455, v_t_2456, heff_dup(heff_rfield(v_c_241, 3))});
  } else {
    heff_drop(v_bound_2422);
    v_c_2457 = heff_dup(v_c_241);
  }
  V v_x1_2465;
  switch (heff_tag_of(v_cod_2412)) {
  case TAG_MkClo: {
    V v_vs_2459 = heff_field(v_cod_2412, 1);
    V v_body_2460 = heff_field(v_cod_2412, 2);
    heff_take_n(v_cod_2412, 6ULL, 3);
    v_x1_2465 = heff_tr(heff_call(v_body_2460, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2459, heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam8, 1, 2, (V[]){v_c_241, v_dom_2411})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2464 = heff_field(v_cod_2412, 0);
    heff_take_n(v_cod_2412, 1ULL, 1);
    heff_drop(v_dom_2411);
    heff_drop_rec(v_c_241, 4);
    v_x1_2465 = v_body_2464;
    break;
  }
  default: heff_nomatch(v_cod_2412);
  }
  V v_ty_2469;
  switch (heff_tag_of(v_x1_2465)) {
  case TAG_Nom: {
    V v_x_2466 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_ty_2469 = v_x_2466;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2465, 0ULL, 1);
    v_ty_2469 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2468 = heff_field(v_x1_2465, 0);
    heff_take_n(v_x1_2465, 1ULL, 1);
    v_ty_2469 = v_x_2468;
    break;
  }
  default: heff_nomatch(v_x1_2465);
  }
  V v_m_2470 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_2457, v_body_2420, v_ty_2469));
  V v_x2_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){heff_intAdd(v_n_2445, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_2471)) {
  case TAG_Left: {
    V v_e_2472 = heff_field(v_x2_2471, 0);
    V v_ru_24x2_2471_24Left = heff_take_reuse_n(v_x2_2471, 1ULL, 1);
    heff_drop(v_x_2448);
    return heff_tag_at_n(v_ru_24x2_2471_24Left, TAG_Left, 1, (V[]){v_e_2472});
  }
  case TAG_Right: {
    V v_x21_2473 = heff_field(v_x2_2471, 0);
    V v_ru_24x2_2471_24Right = heff_take_reuse_n(v_x2_2471, 1ULL, 1);
    switch (heff_tag_of(v_x21_2473)) {
    case TAG_MkPair: {
      V v_x_2474 = heff_field(v_x21_2473, 0);
      V v_n_2475 = heff_field(v_x21_2473, 1);
      V v_ru_24x21_2473_24MkPair = heff_take_reuse_n(v_x21_2473, 3ULL, 2);
      V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2448, NTAG(TAG_Nil)});
      V v_t_2477 = heff_tag_at_n(v_ru_24x21_2473_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_t_2476, v_x_2474}), v_n_2475});
      return heff_tag_at_n(v_ru_24x2_2471_24Right, TAG_Right, 1, (V[]){v_t_2477});
    }
    default: return heff_nomatch(v_x21_2473);
    }
  }
  default: return heff_nomatch(v_x2_2471);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam10(V self, V *args) {
  V v_n_2481 = args[0];
  heff_drop(v_n_2481);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str9)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam11(V self, V *args) {
  V v_n_2483 = args[0];
  heff_drop(v_n_2483);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str10)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam12(V self, V *args) {
  V v_n_2484 = args[0];
  heff_drop(v_n_2484);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str11)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam13(V self, V *args) {
  V v_n_2485 = args[0];
  heff_drop(v_n_2485);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str12)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam14(V self, V *args) {
  V v_n_2486 = args[0];
  heff_drop(v_n_2486);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str13)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam15(V self, V *args) {
  V v_n_2487 = args[0];
  heff_drop(v_n_2487);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str14)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam16(V self, V *args) {
  V v_n_2489 = args[0];
  heff_drop(v_n_2489);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str15)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam17(V self, V *args) {
  V v_n_2491 = args[0];
  heff_drop(v_n_2491);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str16)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam18(V self, V *args) {
  V v_n_2492 = args[0];
  heff_drop(v_n_2492);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str17)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam19(V self, V *args) {
  V v_n_2495 = args[0];
  V v_m_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2496 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_n_2495}));
  switch (heff_tag_of(v_x2_2496)) {
  case TAG_Left: {
    V v_e_2497 = heff_field(v_x2_2496, 0);
    V v_ru_24x2_2496_24Left = heff_take_reuse_n(v_x2_2496, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_2496_24Left, TAG_Left, 1, (V[]){v_e_2497});
  }
  case TAG_Right: {
    V v_x21_2498 = heff_field(v_x2_2496, 0);
    V v_ru_24x2_2496_24Right = heff_take_reuse_n(v_x2_2496, 1ULL, 1);
    switch (heff_tag_of(v_x21_2498)) {
    case TAG_MkPair: {
      V v_x_2499 = heff_field(v_x21_2498, 0);
      V v_n_24100 = heff_field(v_x21_2498, 1);
      heff_take_n(v_x21_2498, 3ULL, 2);
      switch (heff_tag_of(v_x_2499)) {
      case TAG_MkPair: {
        V v_t_27_24101 = heff_field(v_x_2499, 0);
        heff_take_n(v_x_2499, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2496_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24101, v_n_24100})});
      }
      default: return heff_nomatch(v_x_2499);
      }
    }
    default: return heff_nomatch(v_x21_2498);
    }
  }
  default: return heff_nomatch(v_x2_2496);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam20(V self, V *args) {
  V v_n_24105 = args[0];
  V v_m_24104 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24106 = heff_tr(heff_call(v_m_24104, 1, (V[]){v_n_24105}));
  switch (heff_tag_of(v_x2_24106)) {
  case TAG_Left: {
    V v_e_24107 = heff_field(v_x2_24106, 0);
    V v_ru_24x2_24106_24Left = heff_take_reuse_n(v_x2_24106, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24106_24Left, TAG_Left, 1, (V[]){v_e_24107});
  }
  case TAG_Right: {
    V v_x21_24108 = heff_field(v_x2_24106, 0);
    V v_ru_24x2_24106_24Right = heff_take_reuse_n(v_x2_24106, 1ULL, 1);
    switch (heff_tag_of(v_x21_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x21_24108, 0);
      V v_n_24110 = heff_field(v_x21_24108, 1);
      heff_take_n(v_x21_24108, 3ULL, 2);
      switch (heff_tag_of(v_x_24109)) {
      case TAG_MkPair: {
        V v_t_27_24111 = heff_field(v_x_24109, 0);
        heff_take_n(v_x_24109, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24106_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24111, v_n_24110})});
      }
      default: return heff_nomatch(v_x_24109);
      }
    }
    default: return heff_nomatch(v_x21_24108);
    }
  }
  default: return heff_nomatch(v_x2_24106);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam21(V self, V *args) {
  V v_n_24114 = args[0];
  heff_drop(v_n_24114);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str18)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam22(V self, V *args) {
  V v_n_24118 = args[0];
  V v_m_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24119 = heff_tr(heff_call(v_m_24117, 1, (V[]){v_n_24118}));
  switch (heff_tag_of(v_x2_24119)) {
  case TAG_Left: {
    V v_e_24120 = heff_field(v_x2_24119, 0);
    V v_ru_24x2_24119_24Left = heff_take_reuse_n(v_x2_24119, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24119_24Left, TAG_Left, 1, (V[]){v_e_24120});
  }
  case TAG_Right: {
    V v_x21_24121 = heff_field(v_x2_24119, 0);
    V v_ru_24x2_24119_24Right = heff_take_reuse_n(v_x2_24119, 1ULL, 1);
    switch (heff_tag_of(v_x21_24121)) {
    case TAG_MkPair: {
      V v_x_24122 = heff_field(v_x21_24121, 0);
      V v_n_24123 = heff_field(v_x21_24121, 1);
      heff_take_n(v_x21_24121, 3ULL, 2);
      switch (heff_tag_of(v_x_24122)) {
      case TAG_MkPair: {
        V v_t_27_24124 = heff_field(v_x_24122, 0);
        heff_take_n(v_x_24122, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24119_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24124, v_n_24123})});
      }
      default: return heff_nomatch(v_x_24122);
      }
    }
    default: return heff_nomatch(v_x21_24121);
    }
  }
  default: return heff_nomatch(v_x2_24119);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam23(V self, V *args) {
  V v_n_24133 = args[0];
  heff_drop(v_n_24133);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str22)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam24(V self, V *args) {
  V v_n_24138 = args[0];
  heff_drop(v_n_24138);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str23)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam25(V self, V *args) {
  V v_n_24145 = args[0];
  heff_drop(v_n_24145);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str24)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam26(V self, V *args) {
  V v_n_24146 = args[0];
  heff_drop(v_n_24146);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str25)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam27(V self, V *args) {
  V v_n_24147 = args[0];
  heff_drop(v_n_24147);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str26)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam28(V self, V *args) {
  V v_n_24148 = args[0];
  heff_drop(v_n_24148);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str27)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam29(V self, V *args) {
  V v_n_24149 = args[0];
  heff_drop(v_n_24149);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str28)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam30(V self, V *args) {
  V v_n_24151 = args[0];
  heff_drop(v_n_24151);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str29)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam31(V self, V *args) {
  V v_n_24153 = args[0];
  heff_drop(v_n_24153);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str30)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam32(V self, V *args) {
  V v_n_24154 = args[0];
  heff_drop(v_n_24154);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str31)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam33(V self, V *args) {
  V v_n_24158 = args[0];
  V v_m_24157 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24159 = heff_tr(heff_call(v_m_24157, 1, (V[]){v_n_24158}));
  switch (heff_tag_of(v_x2_24159)) {
  case TAG_Left: {
    V v_e_24160 = heff_field(v_x2_24159, 0);
    V v_ru_24x2_24159_24Left = heff_take_reuse_n(v_x2_24159, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24159_24Left, TAG_Left, 1, (V[]){v_e_24160});
  }
  case TAG_Right: {
    V v_x21_24161 = heff_field(v_x2_24159, 0);
    V v_ru_24x2_24159_24Right = heff_take_reuse_n(v_x2_24159, 1ULL, 1);
    switch (heff_tag_of(v_x21_24161)) {
    case TAG_MkPair: {
      V v_x_24162 = heff_field(v_x21_24161, 0);
      V v_n_24163 = heff_field(v_x21_24161, 1);
      heff_take_n(v_x21_24161, 3ULL, 2);
      switch (heff_tag_of(v_x_24162)) {
      case TAG_MkPair: {
        V v_t_27_24164 = heff_field(v_x_24162, 0);
        heff_take_n(v_x_24162, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24159_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24164, v_n_24163})});
      }
      default: return heff_nomatch(v_x_24162);
      }
    }
    default: return heff_nomatch(v_x21_24161);
    }
  }
  default: return heff_nomatch(v_x2_24159);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam34(V self, V *args) {
  V v_n_24170 = args[0];
  heff_drop(v_n_24170);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str32)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam35(V self, V *args) {
  V v_n_24175 = args[0];
  heff_drop(v_n_24175);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str33)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam36(V self, V *args) {
  V v_n_24179 = args[0];
  heff_drop(v_n_24179);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str34)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam37(V self, V *args) {
  V v_p_24191 = args[0];
  V v_c_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2echkTagArg_24s1845141771x1473377513(v_c_244, v_p_24191));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam38(V self, V *args) {
  V v_n_24193 = args[0];
  V v_m_24192 = heff_env(self)[0];
  V v_x_24166 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24194 = heff_tr(heff_call(v_m_24192, 1, (V[]){v_n_24193}));
  switch (heff_tag_of(v_x2_24194)) {
  case TAG_Left: {
    V v_e_24195 = heff_field(v_x2_24194, 0);
    V v_ru_24x2_24194_24Left = heff_take_reuse_n(v_x2_24194, 1ULL, 1);
    heff_drop(v_x_24166);
    return heff_tag_at_n(v_ru_24x2_24194_24Left, TAG_Left, 1, (V[]){v_e_24195});
  }
  case TAG_Right: {
    V v_x21_24196 = heff_field(v_x2_24194, 0);
    V v_ru_24x2_24194_24Right = heff_take_reuse_n(v_x2_24194, 1ULL, 1);
    switch (heff_tag_of(v_x21_24196)) {
    case TAG_MkPair: {
      V v_x_24197 = heff_field(v_x21_24196, 0);
      V v_n_24198 = heff_field(v_x21_24196, 1);
      V v_ru_24x21_24196_24MkPair = heff_take_reuse_n(v_x21_24196, 3ULL, 2);
      V v_t_24199 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_24197)));
      V v_t_24200 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x21_24196_24MkPair, v_t_24199));
      V v_t_24201 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_24197));
      V v_t_24202 = (g_list_2emap_24s1173914895x100384474(v_t_24201));
      V v_x_24203 = heff_tag_n(TAG_ETag, 3, (V[]){v_x_24166, v_t_24200, v_t_24202});
      return heff_tag_at_n(v_ru_24x2_24194_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_24203, v_n_24198})});
    }
    default: return heff_nomatch(v_x21_24196);
    }
  }
  default: return heff_nomatch(v_x2_24194);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam39(V self, V *args) {
  V v_n_24204 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24204);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str35), v_x_24166)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam40(V self, V *args) {
  V v_n_24205 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_n_24205);
  return heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str36), v_x_24166)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam41(V self, V *args) {
  V v_n_24206 = args[0];
  heff_drop(v_n_24206);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str37)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam42(V self, V *args) {
  V v_n_24207 = args[0];
  heff_drop(v_n_24207);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str38)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam43(V self, V *args) {
  V v_n_24208 = args[0];
  heff_drop(v_n_24208);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str39)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam44(V self, V *args) {
  V v_n_24209 = args[0];
  heff_drop(v_n_24209);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str40)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam45(V self, V *args) {
  V v_n_24211 = args[0];
  heff_drop(v_n_24211);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str41)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam46(V self, V *args) {
  V v_n_24213 = args[0];
  heff_drop(v_n_24213);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str42)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam47(V self, V *args) {
  V v_n_24214 = args[0];
  heff_drop(v_n_24214);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str43)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam49(V self, V *args) {
  V v_p_24235 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_x_24232 = heff_env(self)[1];
  V v_ty_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ecompile_2eerase_2earmOf_24s1119496647x675252708(v_c_244, v_x_24232, v_ty_246, v_p_24235));
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam48(V self, V *args) {
  V v_n_24220 = args[0];
  V v_m_24219 = heff_env(self)[0];
  V v_keys_24217 = heff_env(self)[1];
  V v_values_24218 = heff_env(self)[2];
  V v_c_244 = heff_env(self)[3];
  V v_ty_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_24221 = heff_tr(heff_call(v_m_24219, 1, (V[]){v_n_24220}));
  switch (heff_tag_of(v_x2_24221)) {
  case TAG_Left: {
    V v_e_24222 = heff_field(v_x2_24221, 0);
    V v_ru_24x2_24221_24Left = heff_take_reuse_n(v_x2_24221, 1ULL, 1);
    heff_drop(v_keys_24217);
    heff_drop(v_values_24218);
    heff_drop_rec(v_c_244, 4);
    heff_drop(v_ty_246);
    return heff_tag_at_n(v_ru_24x2_24221_24Left, TAG_Left, 1, (V[]){v_e_24222});
  }
  case TAG_Right: {
    V v_x21_24223 = heff_field(v_x2_24221, 0);
    V v_ru_24x2_24221_24Right = heff_take_reuse_n(v_x2_24221, 1ULL, 1);
    switch (heff_tag_of(v_x21_24223)) {
    case TAG_MkPair: {
      V v_x_24224 = heff_field(v_x21_24223, 0);
      V v_n_24225 = heff_field(v_x21_24223, 1);
      V v_ru_24x21_24223_24MkPair = heff_take_reuse_n(v_x21_24223, 3ULL, 2);
      switch (heff_tag_of(v_x_24224)) {
      case TAG_MkPair: {
        V v_s_27_24226 = heff_field(v_x_24224, 0);
        V v_sty_24227 = heff_field(v_x_24224, 1);
        heff_take_n(v_x_24224, 3ULL, 2);
        V v_m_24228 = (g_heff_2ecompile_2eerase_2ematchVariants(v_sty_24227));
        V v_x2_24229 = heff_tr(heff_call(v_m_24228, 1, (V[]){v_n_24225}));
        switch (heff_tag_of(v_x2_24229)) {
        case TAG_Left: {
          V v_e_24230 = heff_field(v_x2_24229, 0);
          V v_ru_24x2_24229_24Left = heff_take_reuse_n(v_x2_24229, 1ULL, 1);
          heff_drop(v_keys_24217);
          heff_drop(v_values_24218);
          heff_drop_rec(v_c_244, 4);
          heff_drop(v_ty_246);
          heff_drop_cell(v_ru_24x2_24221_24Right, 1);
          heff_drop_cell(v_ru_24x21_24223_24MkPair, 2);
          heff_drop(v_s_27_24226);
          return heff_tag_at_n(v_ru_24x2_24229_24Left, TAG_Left, 1, (V[]){v_e_24230});
        }
        case TAG_Right: {
          V v_x21_24231 = heff_field(v_x2_24229, 0);
          V v_ru_24x2_24229_24Right = heff_take_reuse_n(v_x2_24229, 1ULL, 1);
          switch (heff_tag_of(v_x21_24231)) {
          case TAG_MkPair: {
            V v_x_24232 = heff_field(v_x21_24231, 0);
            V v_n_24233 = heff_field(v_x21_24231, 1);
            heff_take_n(v_x21_24231, 3ULL, 2);
            V v_t_24234 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_24217), heff_arrayToList(v_values_24218)));
            V v_m_24236 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam49, 1, 3, (V[]){v_c_244, v_x_24232, v_ty_246}), v_t_24234));
            V v_x2_24237 = heff_tr(heff_call(v_m_24236, 1, (V[]){v_n_24233}));
            switch (heff_tag_of(v_x2_24237)) {
            case TAG_Left: {
              V v_e_24238 = heff_field(v_x2_24237, 0);
              heff_take_n(v_x2_24237, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_24221_24Right, 1);
              heff_drop_cell(v_ru_24x21_24223_24MkPair, 2);
              heff_drop(v_s_27_24226);
              return heff_tag_at_n(v_ru_24x2_24229_24Right, TAG_Left, 1, (V[]){v_e_24238});
            }
            case TAG_Right: {
              V v_x21_24239 = heff_field(v_x2_24237, 0);
              heff_take_n(v_x2_24237, 1ULL, 1);
              heff_drop_cell(v_ru_24x2_24229_24Right, 1);
              switch (heff_tag_of(v_x21_24239)) {
              case TAG_MkPair: {
                V v_x_24240 = heff_field(v_x21_24239, 0);
                V v_n_24241 = heff_field(v_x21_24239, 1);
                heff_take_n(v_x21_24239, 3ULL, 2);
                V v_t_24242 = heff_tag_at_n(v_ru_24x21_24223_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_27_24226, v_x_24240}), v_n_24241});
                return heff_tag_at_n(v_ru_24x2_24221_24Right, TAG_Right, 1, (V[]){v_t_24242});
              }
              default: return heff_nomatch(v_x21_24239);
              }
            }
            default: return heff_nomatch(v_x2_24237);
            }
          }
          default: return heff_nomatch(v_x21_24231);
          }
        }
        default: return heff_nomatch(v_x2_24229);
        }
      }
      default: return heff_nomatch(v_x_24224);
      }
    }
    default: return heff_nomatch(v_x21_24223);
    }
  }
  default: return heff_nomatch(v_x2_24221);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam50(V self, V *args) {
  V v_n_24247 = args[0];
  V v_m_24246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24248 = heff_tr(heff_call(v_m_24246, 1, (V[]){v_n_24247}));
  switch (heff_tag_of(v_x2_24248)) {
  case TAG_Left: {
    V v_e_24249 = heff_field(v_x2_24248, 0);
    V v_ru_24x2_24248_24Left = heff_take_reuse_n(v_x2_24248, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24248_24Left, TAG_Left, 1, (V[]){v_e_24249});
  }
  case TAG_Right: {
    V v_x21_24250 = heff_field(v_x2_24248, 0);
    V v_ru_24x2_24248_24Right = heff_take_reuse_n(v_x2_24248, 1ULL, 1);
    switch (heff_tag_of(v_x21_24250)) {
    case TAG_MkPair: {
      V v_x_24251 = heff_field(v_x21_24250, 0);
      V v_n_24252 = heff_field(v_x21_24250, 1);
      heff_take_n(v_x21_24250, 3ULL, 2);
      switch (heff_tag_of(v_x_24251)) {
      case TAG_MkPair: {
        V v_t_27_24253 = heff_field(v_x_24251, 0);
        heff_take_n(v_x_24251, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24253, v_n_24252})});
      }
      default: return heff_nomatch(v_x_24251);
      }
    }
    default: return heff_nomatch(v_x21_24250);
    }
  }
  default: return heff_nomatch(v_x2_24248);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam51(V self, V *args) {
  V v_n_24256 = args[0];
  heff_drop(v_n_24256);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str44)});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam52(V self, V *args) {
  V v_n_24257 = args[0];
  V v_t_24258 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_EAbandon), v_n_24257});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24258});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam54(V self, V *args) {
  V v_u_24271 = args[0];
  V v_ty_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24271);
  return v_ty_246;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam55(V self, V *args) {
  V v_u_24273 = args[0];
  V v_v_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24273);
  return v_v_24272;
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam53(V self, V *args) {
  V v_n_24264 = args[0];
  V v_x_24262 = heff_env(self)[0];
  V v_ty_246 = heff_env(self)[1];
  V v_c_244 = heff_env(self)[2];
  V v_body_24263 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24265;
  if ((heff_strEq_c_lent(v_x_24262, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str45), 2) || heff_strEq_c_lent(v_x_24262, ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str46), 2))) {
    heff_drop(v_x_24262);
    v_t_24265 = ((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str47);
  } else {
    v_t_24265 = v_x_24262;
  }
  V v_t_24266 = heff_strAppend(((V)&g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_str48), heff_intShow(heff_dup(v_n_24264)));
  V v_x_24267 = heff_strAppend(v_t_24265, v_t_24266);
  V v_t_24268 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){heff_dup(v_x_24267)})});
  V v_t_24269 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_ir__ty, (V[]){v_t_24268, heff_dup(v_ty_246)}), heff_take_field(v_c_244, 0)});
  V v_t_24270 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_c_244, 2))});
  V v_v_24272 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24270, NTAG(TAG_SpId), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam54, 1, 1, (V[]){heff_dup(v_ty_246)}), NTAG(TAG_Nothing)));
  V v_t_24274 = heff_tag_n(TAG_LSnoc, 2, (V[]){heff_take_field(v_c_244, 1), heff_clo_n(g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam55, 1, 1, (V[]){v_v_24272})});
  V v_t_24275 = heff_intAdd(heff_take_field(v_c_244, 2), MK_INT(1LL));
  V v_c_24276 = ({ V rv_0 = v_t_24269; V rv_1 = v_t_24274; V rv_2 = v_t_24275; V rr_ = heff_rec_reuse_nf(v_c_244, 8ULL, 4, shape_locals__env__len__globals, 192u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_m_24277 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(v_c_24276, v_body_24263, v_ty_246));
  V v_x2_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){heff_intAdd(v_n_24264, MK_INT(1LL))}));
  switch (heff_tag_of(v_x2_24278)) {
  case TAG_Left: {
    V v_e_24279 = heff_field(v_x2_24278, 0);
    V v_ru_24x2_24278_24Left = heff_take_reuse_n(v_x2_24278, 1ULL, 1);
    heff_drop(v_x_24267);
    return heff_tag_at_n(v_ru_24x2_24278_24Left, TAG_Left, 1, (V[]){v_e_24279});
  }
  case TAG_Right: {
    V v_x21_24280 = heff_field(v_x2_24278, 0);
    V v_ru_24x2_24278_24Right = heff_take_reuse_n(v_x2_24278, 1ULL, 1);
    switch (heff_tag_of(v_x21_24280)) {
    case TAG_MkPair: {
      V v_x_24281 = heff_field(v_x21_24280, 0);
      V v_n_24282 = heff_field(v_x21_24280, 1);
      V v_ru_24x21_24280_24MkPair = heff_take_reuse_n(v_x21_24280, 3ULL, 2);
      V v_t_24283 = heff_tag_at_n(v_ru_24x21_24280_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EFix, 2, (V[]){v_x_24267, v_x_24281}), v_n_24282});
      return heff_tag_at_n(v_ru_24x2_24278_24Right, TAG_Right, 1, (V[]){v_t_24283});
    }
    default: return heff_nomatch(v_x21_24280);
    }
  }
  default: return heff_nomatch(v_x2_24278);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam56(V self, V *args) {
  V v_n_24288 = args[0];
  V v_x_24287 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24289 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrim, 1, (V[]){v_x_24287}), v_n_24288});
  return heff_tag_n(TAG_Right, 1, (V[]){v_t_24289});
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam57(V self, V *args) {
  V v_n_24294 = args[0];
  V v_m_24293 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24295 = heff_tr(heff_call(v_m_24293, 1, (V[]){v_n_24294}));
  switch (heff_tag_of(v_x2_24295)) {
  case TAG_Left: {
    V v_e_24296 = heff_field(v_x2_24295, 0);
    V v_ru_24x2_24295_24Left = heff_take_reuse_n(v_x2_24295, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24295_24Left, TAG_Left, 1, (V[]){v_e_24296});
  }
  case TAG_Right: {
    V v_x21_24297 = heff_field(v_x2_24295, 0);
    V v_ru_24x2_24295_24Right = heff_take_reuse_n(v_x2_24295, 1ULL, 1);
    switch (heff_tag_of(v_x21_24297)) {
    case TAG_MkPair: {
      V v_x_24298 = heff_field(v_x21_24297, 0);
      V v_n_24299 = heff_field(v_x21_24297, 1);
      heff_take_n(v_x21_24297, 3ULL, 2);
      switch (heff_tag_of(v_x_24298)) {
      case TAG_MkPair: {
        V v_t_27_24300 = heff_field(v_x_24298, 0);
        heff_take_n(v_x_24298, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24295_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24300, v_n_24299})});
      }
      default: return heff_nomatch(v_x_24298);
      }
    }
    default: return heff_nomatch(v_x21_24297);
    }
  }
  default: return heff_nomatch(v_x2_24295);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam58(V self, V *args) {
  V v_n_24304 = args[0];
  V v_m_24303 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24305 = heff_tr(heff_call(v_m_24303, 1, (V[]){v_n_24304}));
  switch (heff_tag_of(v_x2_24305)) {
  case TAG_Left: {
    V v_e_24306 = heff_field(v_x2_24305, 0);
    V v_ru_24x2_24305_24Left = heff_take_reuse_n(v_x2_24305, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24305_24Left, TAG_Left, 1, (V[]){v_e_24306});
  }
  case TAG_Right: {
    V v_x21_24307 = heff_field(v_x2_24305, 0);
    V v_ru_24x2_24305_24Right = heff_take_reuse_n(v_x2_24305, 1ULL, 1);
    switch (heff_tag_of(v_x21_24307)) {
    case TAG_MkPair: {
      V v_x_24308 = heff_field(v_x21_24307, 0);
      V v_n_24309 = heff_field(v_x21_24307, 1);
      heff_take_n(v_x21_24307, 3ULL, 2);
      switch (heff_tag_of(v_x_24308)) {
      case TAG_MkPair: {
        V v_t_27_24310 = heff_field(v_x_24308, 0);
        heff_take_n(v_x_24308, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24305_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24310, v_n_24309})});
      }
      default: return heff_nomatch(v_x_24308);
      }
    }
    default: return heff_nomatch(v_x21_24307);
    }
  }
  default: return heff_nomatch(v_x2_24305);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam59(V self, V *args) {
  V v_n_24314 = args[0];
  V v_m_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24315 = heff_tr(heff_call(v_m_24313, 1, (V[]){v_n_24314}));
  switch (heff_tag_of(v_x2_24315)) {
  case TAG_Left: {
    V v_e_24316 = heff_field(v_x2_24315, 0);
    V v_ru_24x2_24315_24Left = heff_take_reuse_n(v_x2_24315, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24315_24Left, TAG_Left, 1, (V[]){v_e_24316});
  }
  case TAG_Right: {
    V v_x21_24317 = heff_field(v_x2_24315, 0);
    V v_ru_24x2_24315_24Right = heff_take_reuse_n(v_x2_24315, 1ULL, 1);
    switch (heff_tag_of(v_x21_24317)) {
    case TAG_MkPair: {
      V v_x_24318 = heff_field(v_x21_24317, 0);
      V v_n_24319 = heff_field(v_x21_24317, 1);
      heff_take_n(v_x21_24317, 3ULL, 2);
      switch (heff_tag_of(v_x_24318)) {
      case TAG_MkPair: {
        V v_t_27_24320 = heff_field(v_x_24318, 0);
        heff_take_n(v_x_24318, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24315_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24320, v_n_24319})});
      }
      default: return heff_nomatch(v_x_24318);
      }
    }
    default: return heff_nomatch(v_x21_24317);
    }
  }
  default: return heff_nomatch(v_x2_24315);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam60(V self, V *args) {
  V v_n_24324 = args[0];
  V v_m_24323 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24325 = heff_tr(heff_call(v_m_24323, 1, (V[]){v_n_24324}));
  switch (heff_tag_of(v_x2_24325)) {
  case TAG_Left: {
    V v_e_24326 = heff_field(v_x2_24325, 0);
    V v_ru_24x2_24325_24Left = heff_take_reuse_n(v_x2_24325, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24325_24Left, TAG_Left, 1, (V[]){v_e_24326});
  }
  case TAG_Right: {
    V v_x21_24327 = heff_field(v_x2_24325, 0);
    V v_ru_24x2_24325_24Right = heff_take_reuse_n(v_x2_24325, 1ULL, 1);
    switch (heff_tag_of(v_x21_24327)) {
    case TAG_MkPair: {
      V v_x_24328 = heff_field(v_x21_24327, 0);
      V v_n_24329 = heff_field(v_x21_24327, 1);
      heff_take_n(v_x21_24327, 3ULL, 2);
      switch (heff_tag_of(v_x_24328)) {
      case TAG_MkPair: {
        V v_t_27_24330 = heff_field(v_x_24328, 0);
        heff_take_n(v_x_24328, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24325_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24330, v_n_24329})});
      }
      default: return heff_nomatch(v_x_24328);
      }
    }
    default: return heff_nomatch(v_x21_24327);
    }
  }
  default: return heff_nomatch(v_x2_24325);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam61(V self, V *args) {
  V v_n_24334 = args[0];
  V v_m_24333 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24335 = heff_tr(heff_call(v_m_24333, 1, (V[]){v_n_24334}));
  switch (heff_tag_of(v_x2_24335)) {
  case TAG_Left: {
    V v_e_24336 = heff_field(v_x2_24335, 0);
    V v_ru_24x2_24335_24Left = heff_take_reuse_n(v_x2_24335, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24335_24Left, TAG_Left, 1, (V[]){v_e_24336});
  }
  case TAG_Right: {
    V v_x21_24337 = heff_field(v_x2_24335, 0);
    V v_ru_24x2_24335_24Right = heff_take_reuse_n(v_x2_24335, 1ULL, 1);
    switch (heff_tag_of(v_x21_24337)) {
    case TAG_MkPair: {
      V v_x_24338 = heff_field(v_x21_24337, 0);
      V v_n_24339 = heff_field(v_x21_24337, 1);
      heff_take_n(v_x21_24337, 3ULL, 2);
      switch (heff_tag_of(v_x_24338)) {
      case TAG_MkPair: {
        V v_t_27_24340 = heff_field(v_x_24338, 0);
        heff_take_n(v_x_24338, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24335_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24340, v_n_24339})});
      }
      default: return heff_nomatch(v_x_24338);
      }
    }
    default: return heff_nomatch(v_x21_24337);
    }
  }
  default: return heff_nomatch(v_x2_24335);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam62(V self, V *args) {
  V v_n_24344 = args[0];
  V v_m_24343 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24345 = heff_tr(heff_call(v_m_24343, 1, (V[]){v_n_24344}));
  switch (heff_tag_of(v_x2_24345)) {
  case TAG_Left: {
    V v_e_24346 = heff_field(v_x2_24345, 0);
    V v_ru_24x2_24345_24Left = heff_take_reuse_n(v_x2_24345, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24345_24Left, TAG_Left, 1, (V[]){v_e_24346});
  }
  case TAG_Right: {
    V v_x21_24347 = heff_field(v_x2_24345, 0);
    V v_ru_24x2_24345_24Right = heff_take_reuse_n(v_x2_24345, 1ULL, 1);
    switch (heff_tag_of(v_x21_24347)) {
    case TAG_MkPair: {
      V v_x_24348 = heff_field(v_x21_24347, 0);
      V v_n_24349 = heff_field(v_x21_24347, 1);
      heff_take_n(v_x21_24347, 3ULL, 2);
      switch (heff_tag_of(v_x_24348)) {
      case TAG_MkPair: {
        V v_t_27_24350 = heff_field(v_x_24348, 0);
        heff_take_n(v_x_24348, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24345_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24350, v_n_24349})});
      }
      default: return heff_nomatch(v_x_24348);
      }
    }
    default: return heff_nomatch(v_x21_24347);
    }
  }
  default: return heff_nomatch(v_x2_24345);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam63(V self, V *args) {
  V v_n_24355 = args[0];
  V v_m_24354 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24356 = heff_tr(heff_call(v_m_24354, 1, (V[]){v_n_24355}));
  switch (heff_tag_of(v_x2_24356)) {
  case TAG_Left: {
    V v_e_24357 = heff_field(v_x2_24356, 0);
    V v_ru_24x2_24356_24Left = heff_take_reuse_n(v_x2_24356, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24356_24Left, TAG_Left, 1, (V[]){v_e_24357});
  }
  case TAG_Right: {
    V v_x21_24358 = heff_field(v_x2_24356, 0);
    V v_ru_24x2_24356_24Right = heff_take_reuse_n(v_x2_24356, 1ULL, 1);
    switch (heff_tag_of(v_x21_24358)) {
    case TAG_MkPair: {
      V v_x_24359 = heff_field(v_x21_24358, 0);
      V v_n_24360 = heff_field(v_x21_24358, 1);
      heff_take_n(v_x21_24358, 3ULL, 2);
      switch (heff_tag_of(v_x_24359)) {
      case TAG_MkPair: {
        V v_t_27_24361 = heff_field(v_x_24359, 0);
        heff_take_n(v_x_24359, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24356_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24361, v_n_24360})});
      }
      default: return heff_nomatch(v_x_24359);
      }
    }
    default: return heff_nomatch(v_x21_24358);
    }
  }
  default: return heff_nomatch(v_x2_24356);
  }
}
V g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle_lam64(V self, V *args) {
  V v_n_24365 = args[0];
  V v_m_24364 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_24366 = heff_tr(heff_call(v_m_24364, 1, (V[]){v_n_24365}));
  switch (heff_tag_of(v_x2_24366)) {
  case TAG_Left: {
    V v_e_24367 = heff_field(v_x2_24366, 0);
    V v_ru_24x2_24366_24Left = heff_take_reuse_n(v_x2_24366, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_24366_24Left, TAG_Left, 1, (V[]){v_e_24367});
  }
  case TAG_Right: {
    V v_x21_24368 = heff_field(v_x2_24366, 0);
    V v_ru_24x2_24366_24Right = heff_take_reuse_n(v_x2_24366, 1ULL, 1);
    switch (heff_tag_of(v_x21_24368)) {
    case TAG_MkPair: {
      V v_x_24369 = heff_field(v_x21_24368, 0);
      V v_n_24370 = heff_field(v_x21_24368, 1);
      heff_take_n(v_x21_24368, 3ULL, 2);
      switch (heff_tag_of(v_x_24369)) {
      case TAG_MkPair: {
        V v_t_27_24371 = heff_field(v_x_24369, 0);
        heff_take_n(v_x_24369, 1ULL, 2);
        return heff_tag_at_n(v_ru_24x2_24366_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_27_24371, v_n_24370})});
      }
      default: return heff_nomatch(v_x_24369);
      }
    }
    default: return heff_nomatch(v_x21_24368);
    }
  }
  default: return heff_nomatch(v_x2_24366);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0, 27, "this needs an expected type");
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args); static Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0, 1, 0};
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry, 3, 0};

V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(V v_c_240, V v_vs_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    return ((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0_clo);
  }
  case TAG_Cons: {
    V v_x41_244 = heff_field(v_x4_242, 0);
    V v_tail_245 = heff_field(v_x4_242, 1);
    heff_take_n(v_x4_242, 3ULL, 2);
    switch (heff_tag_of(v_x41_244)) {
    case TAG_MkPair: {
      V v_tag_246 = heff_field(v_x41_244, 0);
      V v_x412_247 = heff_field(v_x41_244, 1);
      heff_take_n(v_x41_244, 3ULL, 2);
      switch (heff_tag_of(v_x412_247)) {
      case TAG_MkPair: {
        V v_xs_248 = heff_field(v_x412_247, 0);
        V v_body_249 = heff_field(v_x412_247, 1);
        heff_take_n(v_x412_247, 3ULL, 2);
        V v_m_2410 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_vs_241); V a_2 = v_tag_246; V a_3 = heff_arrayToList(v_xs_248); V r_ = (g_heff_2ecompile_2eerase_2earmBind(a_0, a_1, a_2, a_3)); heff_drop(v_tag_246); r_; });
        return heff_clo_n(g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1, 1, 5, (V[]){v_m_2410, v_body_249, v_c_240, v_vs_241, v_tail_245});
      }
      default: return heff_nomatch(v_x412_247);
      }
    }
    default: return heff_nomatch(v_x41_244);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam0(V self, V *args) {
  V v_n_243 = args[0];
  heff_drop(v_n_243);
  return heff_tag_n(TAG_Left, 1, (V[]){((V)&g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_str0)});
}
V g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430_lam1(V self, V *args) {
  V v_n_2411 = args[0];
  V v_m_2410 = heff_env(self)[0];
  V v_body_249 = heff_env(self)[1];
  V v_c_240 = heff_env(self)[2];
  V v_vs_241 = heff_env(self)[3];
  V v_tail_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x2_2412 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_2411}));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Left: {
    V v_e_2413 = heff_field(v_x2_2412, 0);
    V v_ru_24x2_2412_24Left = heff_take_reuse_n(v_x2_2412, 1ULL, 1);
    heff_drop(v_body_249);
    heff_drop(v_c_240);
    heff_drop(v_vs_241);
    heff_drop(v_tail_245);
    return heff_tag_at_n(v_ru_24x2_2412_24Left, TAG_Left, 1, (V[]){v_e_2413});
  }
  case TAG_Right: {
    V v_x21_2414 = heff_field(v_x2_2412, 0);
    V v_ru_24x2_2412_24Right = heff_take_reuse_n(v_x2_2412, 1ULL, 1);
    switch (heff_tag_of(v_x21_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x21_2414, 0);
      V v_n_2416 = heff_field(v_x21_2414, 1);
      heff_take_n(v_x21_2414, 3ULL, 2);
      V v_m_2417 = (g_heff_2ecompile_2eerase_2esynF_24s34873658x1566606618(heff_get_n(v_x_2415, 0, 2), v_body_249));
      V v_x2_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){heff_dup(v_n_2416)}));
      switch (heff_tag_of(v_x2_2418)) {
      case TAG_Left: {
        heff_take_n(v_x2_2418, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2412_24Right, 1);
        V v_t_2420 = (g_heff_2ecompile_2eerase_2earmsTy_24s156007495x1009302430(v_c_240, v_vs_241, v_tail_245));
        V f_ = v_t_2420;
        args[0] = v_n_2416;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Right: {
        V v_x21_2421 = heff_field(v_x2_2418, 0);
        heff_take_n(v_x2_2418, 1ULL, 1);
        heff_drop(v_c_240);
        heff_drop(v_vs_241);
        heff_drop(v_tail_245);
        heff_drop(v_n_2416);
        switch (heff_tag_of(v_x21_2421)) {
        case TAG_MkPair: {
          V v_x_2422 = heff_field(v_x21_2421, 0);
          V v_n_27_2423 = heff_field(v_x21_2421, 1);
          heff_take_n(v_x21_2421, 3ULL, 2);
          switch (heff_tag_of(v_x_2422)) {
          case TAG_MkPair: {
            V v_ty_2425 = heff_field(v_x_2422, 1);
            heff_take_n(v_x_2422, 2ULL, 2);
            return heff_tag_at_n(v_ru_24x2_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_ty_2425, v_n_27_2423})});
          }
          default: return heff_nomatch(v_x_2422);
          }
        }
        default: return heff_nomatch(v_x21_2421);
        }
      }
      default: return heff_nomatch(v_x2_2418);
      }
    }
    default: return heff_nomatch(v_x21_2414);
    }
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(V v_c_240, V v_capture_241, V v_fieldTypes_242, V v_acc_243, V v_x6_244) {
top: ;
  V v_out_245 = heff_take_field(v_acc_243, 1);
  V v_tys_246 = heff_take_field(v_acc_243, 2);
  V v_vs_247 = heff_get_n(v_acc_243, 0, 3);
  switch (heff_tag_of(v_x6_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    heff_drop(v_vs_247);
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_out_245));
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_tys_246));
    V v_x_2410 = heff_tag_n(TAG_ERecord, 2, (V[]){v_t_248, v_t_249});
    return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0, 1, 1, (V[]){v_x_2410});
  }
  case TAG_Cons: {
    V v_x61_2412 = heff_field(v_x6_244, 0);
    V v_tail_2413 = heff_field(v_x6_244, 1);
    heff_take_n(v_x6_244, 3ULL, 2);
    switch (heff_tag_of(v_x61_2412)) {
    case TAG_MkPair: {
      V v_l_2414 = heff_field(v_x61_2412, 0);
      V v_fe_2415 = heff_field(v_x61_2412, 1);
      heff_take_n(v_x61_2412, 3ULL, 2);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_247)));
      V v_t_2417 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_dup(heff_rfield(v_fieldTypes_242, 0)), heff_dup(heff_rfield(v_fieldTypes_242, 1)), heff_arrayFromList(v_t_2416)});
      V v_t_2418 = heff_tr(g_heff_2eelab_2evalue_2etypeForProjection(heff_dup(v_capture_241), heff_dup(v_fieldTypes_242), v_l_2414, v_t_2417));
      switch (heff_tag_of(v_t_2418)) {
      case TAG_MkField: {
        V v_fty_2419 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 2);
        V v_t_2421 = (g_heff_2ecompile_2eerase_2eisType(heff_dup(heff_rfield(v_c_240, 2)), heff_dup(v_fty_2419)));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_l_2414);
          heff_drop(v_fty_2419);
          heff_drop(v_t_2421);
          V v_x1_2422 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2415, heff_dup(heff_rfield(v_c_240, 1))));
          V v_t_2426;
          switch (heff_tag_of(v_x1_2422)) {
          case TAG_Nom: {
            V v_x_2423 = heff_field(v_x1_2422, 0);
            heff_take_n(v_x1_2422, 1ULL, 1);
            v_t_2426 = v_x_2423;
            break;
          }
          case TAG_Describe: {
            heff_take_n(v_x1_2422, 0ULL, 1);
            v_t_2426 = heff_abandon();
            break;
          }
          case TAG_Become: {
            V v_x_2425 = heff_field(v_x1_2422, 0);
            heff_take_n(v_x1_2422, 1ULL, 1);
            v_t_2426 = v_x_2425;
            break;
          }
          default: heff_nomatch(v_x1_2422);
          }
          V v_t_2427 = heff_rec_n(3, shape_vs__out__tys, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_vs_247}), v_out_245, v_tys_246});
          V t_0 = v_c_240;
          V t_1 = v_capture_241;
          V t_2 = v_fieldTypes_242;
          V t_3 = v_t_2427;
          V t_4 = v_tail_2413;
          v_c_240 = t_0;
          v_capture_241 = t_1;
          v_fieldTypes_242 = t_2;
          v_acc_243 = t_3;
          v_x6_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2421);
          V v_m_2428 = (g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(heff_dup(v_c_240), heff_dup(v_fe_2415), heff_dup(v_fty_2419)));
          return heff_clo_n(g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1, 1, 11, (V[]){v_m_2428, v_c_240, v_fe_2415, v_l_2414, v_out_245, v_fty_2419, v_vs_247, v_tys_246, v_capture_241, v_fieldTypes_242, v_tail_2413});
        }
      }
      default: return heff_nomatch(v_t_2418);
      }
    }
    default: return heff_nomatch(v_x61_2412);
    }
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam0(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_n_2411})});
}
V g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532_lam1(V self, V *args) {
  V v_n_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_fe_2415 = heff_env(self)[2];
  V v_l_2414 = heff_env(self)[3];
  V v_out_245 = heff_env(self)[4];
  V v_fty_2419 = heff_env(self)[5];
  V v_vs_247 = heff_env(self)[6];
  V v_tys_246 = heff_env(self)[7];
  V v_capture_241 = heff_env(self)[8];
  V v_fieldTypes_242 = heff_env(self)[9];
  V v_tail_2413 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_Left: {
    V v_e_2431 = heff_field(v_x2_2430, 0);
    V v_ru_24x2_2430_24Left = heff_take_reuse_n(v_x2_2430, 1ULL, 1);
    heff_drop_rec(v_c_240, 4);
    heff_drop(v_fe_2415);
    heff_drop(v_l_2414);
    heff_drop(v_out_245);
    heff_drop(v_fty_2419);
    heff_drop(v_vs_247);
    heff_drop(v_tys_246);
    heff_drop(v_capture_241);
    heff_drop_rec(v_fieldTypes_242, 3);
    heff_drop(v_tail_2413);
    return heff_tag_at_n(v_ru_24x2_2430_24Left, TAG_Left, 1, (V[]){v_e_2431});
  }
  case TAG_Right: {
    V v_x21_2432 = heff_field(v_x2_2430, 0);
    V v_ru_24x2_2430_24Right = heff_take_reuse_n(v_x2_2430, 1ULL, 1);
    switch (heff_tag_of(v_x21_2432)) {
    case TAG_MkPair: {
      V v_x_2433 = heff_field(v_x21_2432, 0);
      V v_n_2434 = heff_field(v_x21_2432, 1);
      V v_ru_24x21_2432_24MkPair = heff_take_reuse_n(v_x21_2432, 3ULL, 2);
      V v_x1_2435 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), heff_dup(heff_rfield(v_c_240, 3)), NTAG(TAG_N), v_fe_2415, heff_dup(heff_rfield(v_c_240, 1))));
      V v_t_2439;
      switch (heff_tag_of(v_x1_2435)) {
      case TAG_Nom: {
        V v_x_2436 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        v_t_2439 = v_x_2436;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2435, 0ULL, 1);
        v_t_2439 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2438 = heff_field(v_x1_2435, 0);
        heff_take_n(v_x1_2435, 1ULL, 1);
        v_t_2439 = v_x_2438;
        break;
      }
      default: heff_nomatch(v_x1_2435);
      }
      V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_2432_24MkPair, TAG_MkPair, 2, (V[]){v_l_2414, v_x_2433}), v_out_245});
      V v_x1_2441 = (g_heff_2eelab_2evalue_2ebehavior(v_fty_2419));
      V v_t_2453;
      switch (heff_tag_of(v_x1_2441)) {
      case TAG_LikeU: {
        heff_take_n(v_x1_2441, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFunction: {
        heff_take_n(v_x1_2441, 0ULL, 4);
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRecord: {
        heff_take_n(v_x1_2441, 0ULL, 3);
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeSum: {
        heff_take_n(v_x1_2441, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeInt: {
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFloat: {
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtFloat);
        break;
      }
      case TAG_LikeString: {
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeRune: {
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeArray: {
        heff_take_n(v_x1_2441, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtOther);
        break;
      }
      case TAG_LikeFixed: {
        V v_w_2452 = heff_field(v_x1_2441, 0);
        heff_take_n(v_x1_2441, 1ULL, 1);
        v_t_2453 = heff_tag_at_n(v_ru_24x2_2430_24Right, TAG_FtFixed, 1, (V[]){v_w_2452});
        break;
      }
      case TAG_NoRules: {
        heff_drop_cell(v_ru_24x2_2430_24Right, 1);
        v_t_2453 = NTAG(TAG_FtAny);
        break;
      }
      default: heff_nomatch(v_x1_2441);
      }
      V v_t_2454 = heff_rec_n(3, shape_vs__out__tys, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, v_vs_247}), v_t_2440, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_tys_246})});
      V v_t_2455 = (g_heff_2ecompile_2eerase_2echkFieldsGo_24s1781685199x1613889532(v_c_240, v_capture_241, v_fieldTypes_242, v_t_2454, v_tail_2413));
      V f_ = v_t_2455;
      args[0] = v_n_2434;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x21_2432);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2, 0, "");
Clo g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry, 3, 0};

V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(V v_c_240, V v_t_241, V v_ty_242) {
top: ;
  return (g_heff_2ecompile_2eerase_2echkLam_24s1850506848x2107608145_24cycle(NTAG(TAG_Enter_24heff_2ecompile_2eerase_2echkF_24s551822187x1584934936), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str0), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str1), ((V)&g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_str2), v_c_240, v_t_241, v_ty_242));
}
V g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eerase_2echkF_24s551822187x1584934936(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args);
Clo g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry, 5, 0};

V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(V v_c_240, V v_ty_241, V v_v_242, V v_ps_243, V v_fs_244) {
top: ;
  V v_m_246 = (g_prelude_2etraverse_24s352965232x546119438(heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0, 1, 4, (V[]){v_c_240, v_ty_241, v_v_242, heff_dup(v_fs_244)}), v_ps_243));
  return heff_clo_n(g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1, 1, 1, (V[]){v_m_246});
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_ty_241 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_fs_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_c_240; V a_1 = v_ty_241; V a_2 = v_v_242; V a_3 = v_fs_244; V a_4 = v_p_245; V r_ = (g_heff_2ecompile_2eerase_2echkDField_24s1465294645x1345088616(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_fs_244); r_; });
}
V g_heff_2ecompile_2eerase_2echkDFields_24s1675946293x924467255_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Left = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    return heff_tag_at_n(v_ru_24x2_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_x21_2410 = heff_field(v_x2_248, 0);
    V v_ru_24x2_248_24Right = heff_take_reuse_n(v_x2_248, 1ULL, 1);
    switch (heff_tag_of(v_x21_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x21_2410, 0);
      V v_n_2412 = heff_field(v_x21_2410, 1);
      V v_ru_24x21_2410_24MkPair = heff_take_reuse_n(v_x21_2410, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eerase_2ecatMaybesE(heff_dup(v_x_2411)));
      V v_t_2414 = (g_list_2emap_24s1937570095x2110149801(v_t_2413));
      V v_t_2415 = (g_heff_2ecompile_2eerase_2ecatMaybesE(v_x_2411));
      V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
      V v_x_2417 = heff_tag_at_n(v_ru_24x21_2410_24MkPair, TAG_ERecord, 2, (V[]){v_t_2414, v_t_2416});
      return heff_tag_at_n(v_ru_24x2_248_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2417, v_n_2412})});
    }
    default: return heff_nomatch(v_x21_2410);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1(V self, V *args);

HeffT3 g_heff_2ecompile_2eerase_2eeraseProgram_24cpr(V v_g_240) {
top: ;
  V v_t_241 = heff_rec_n(3, shape_defs__errors__supply, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_248 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0, 2, 1, (V[]){heff_dup(v_g_240)}), NTAG(TAG_Nil), heff_rfield(v_g_240, 0)));
  V v_acc_2411 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1, 2, 1, (V[]){v_g_240}); V a_1 = v_t_241; V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_defs_2412 = heff_take_field(v_acc_2411, 0);
  V v_errors_2413 = heff_take_field(v_acc_2411, 1);
  V v_supply_2414 = heff_get_n(v_acc_2411, 2, 3);
  V v_f_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_defs_2412));
  V v_f_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_errors_2413));
  V v_f_2417 = v_supply_2414;
  return ((HeffT3){{v_f_2415, v_f_2416, v_f_2417}});
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = ({ V b_0 = heff_get_n(v_g_240, 1, 8); V a_1 = v_k_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_e_247 = v_field_246;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_243, v_e_247}), v_acc_242});
    } else {
      heff_drop(v_k_243);
      heff_drop(v_field_246);
      return v_acc_242;
    }
  }
}
V g_heff_2ecompile_2eerase_2eeraseProgram_24cpr_lam1(V self, V *args) {
  V v_acc_249 = args[0];
  V v_p_2410 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ecompile_2eerase_2eeraseOne(v_g_240, v_acc_249, v_p_2410));
}