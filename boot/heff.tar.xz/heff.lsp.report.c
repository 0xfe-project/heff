// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Added 2732
#define TAG_Removed 39854
#define TAG_Same 22203
#define LBL_diff 9578700
#define LBL_expected 956903529
#define LBL_got 312070
static uint32_t shape_expected__got__diff[] = {LBL_expected, LBL_got, LBL_diff};
V g_heff_2elsp_2ereport_2econtext_get(void);
V g_heff_2elsp_2ereport_2ecut(V, V, V);
V g_heff_2elsp_2ereport_2ecut_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2ecut_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_heff_2elsp_2ereport_2emismatchGo(V, V, V, V, V);
V g_heff_2elsp_2ereport_2emismatchGo_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatchGo_clo;
V g_heff_2eutil_2ediff_2ediffBy(V, V, V);
V g_heff_2eutil_2ediff_2ediffBy_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ediffBy_clo;
V g_heff_2eutil_2ediff_2ejoinRunsGo(V, V);
V g_heff_2eutil_2ediff_2ejoinRunsGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ejoinRunsGo_clo;
V g_heff_2eutil_2ediff_2ewordsFrom(V, V, V);
V g_heff_2eutil_2ediff_2ewordsFrom_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ewordsFrom_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_strEq_get(void);

static V g_heff_2elsp_2ereport_2econtext_val;
static int g_heff_2elsp_2ereport_2econtext_st;
static V g_heff_2elsp_2ereport_2econtext_init(void) {
  return MK_INT(20LL);
}
V g_heff_2elsp_2ereport_2econtext_get(void) {
  if (g_heff_2elsp_2ereport_2econtext_st == 2) return g_heff_2elsp_2ereport_2econtext_val;
  if (g_heff_2elsp_2ereport_2econtext_st == 1) heff_fail("defined by itself");
  g_heff_2elsp_2ereport_2econtext_st = 1;
  g_heff_2elsp_2ereport_2econtext_val = heff_tr(g_heff_2elsp_2ereport_2econtext_init());
  g_heff_2elsp_2ereport_2econtext_st = 2;
  return g_heff_2elsp_2ereport_2econtext_val;
}
HEFF_STR(g_heff_2elsp_2ereport_2ecut_str0, 1, (8230), 3, (226, 128, 166));
HEFF_STR(g_heff_2elsp_2ereport_2ecut_str1, 1, (8230), 3, (226, 128, 166));
HEFF_STR(g_heff_2elsp_2ereport_2ecut_str2, 1, (8230), 3, (226, 128, 166));
Clo g_heff_2elsp_2ereport_2ecut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereport_2ecut_entry, 3, 0};

V g_heff_2elsp_2ereport_2ecut(V v_s_240, V v_first_241, V v_last_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_intMul(MK_INT(2LL), heff_dup(g_heff_2elsp_2ereport_2econtext_get())), MK_INT(1LL));
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), v_t_243)) {
    return v_s_240;
  } else {
    switch (heff_tag_of(v_first_241)) {
    case TAG_True: {
      V v_t_245 = heff_intSub(heff_strLength(heff_dup(v_s_240)), heff_dup(g_heff_2elsp_2ereport_2econtext_get()));
      V v_t_246 = heff_strSlice(heff_dup(v_s_240), v_t_245, heff_strLength(v_s_240));
      return heff_strAppend(((V)&g_heff_2elsp_2ereport_2ecut_str0), v_t_246);
    }
    case TAG_False: {
      switch (heff_tag_of(v_last_242)) {
      case TAG_True: {
        return heff_strAppend(heff_strSlice(v_s_240, MK_INT(0LL), heff_dup(g_heff_2elsp_2ereport_2econtext_get())), ((V)&g_heff_2elsp_2ereport_2ecut_str1));
      }
      case TAG_False: {
        V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_s_240)), heff_dup(g_heff_2elsp_2ereport_2econtext_get()));
        V v_t_248 = heff_strSlice(heff_dup(v_s_240), v_t_247, heff_strLength(heff_dup(v_s_240)));
        return heff_strAppend(heff_strSlice(v_s_240, MK_INT(0LL), heff_dup(g_heff_2elsp_2ereport_2econtext_get())), heff_strAppend(((V)&g_heff_2elsp_2ereport_2ecut_str2), v_t_248));
      }
      default: return heff_nomatch(v_last_242);
      }
    }
    default: return heff_nomatch(v_first_241);
    }
  }
}
V g_heff_2elsp_2ereport_2ecut_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2ereport_2ecut(a[0], a[1], a[2]); heff_drop(a[1]); heff_drop(a[2]); return r;
}
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str0, 4, (91, 51, 49, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str1, 3, (91, 48, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str2, 2, (91, 45));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str3, 2, (45, 93));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str4, 4, (91, 51, 49, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str5, 3, (91, 48, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str6, 4, (91, 51, 50, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str7, 3, (91, 48, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str8, 2, (123, 43));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str9, 2, (43, 125));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str10, 4, (91, 51, 50, 109));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatchGo_str11, 3, (91, 48, 109));
Clo g_heff_2elsp_2ereport_2emismatchGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereport_2emismatchGo_entry, 5, 0};

V g_heff_2elsp_2ereport_2emismatchGo(V v_color_240, V v_i_241, V v_n_242, V v_x4_243, V v_m_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return v_m_244;
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_t_2430;
    switch (heff_tag_of(v_p_245)) {
    case TAG_Same: {
      V v_v_247 = heff_field(v_p_245, 0);
      V v_t_248 = heff_intEq(heff_dup(v_i_241), heff_intSub(heff_dup(v_n_242), MK_INT(1LL)));
      V v_e_249 = heff_strAppend(heff_take_field(v_m_244, 0), ({ V a_0 = heff_dup(v_v_247); V b_1 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL)); V a_2 = v_t_248; V r_ = (g_heff_2elsp_2ereport_2ecut(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_t_248); r_; }));
      V v_t_2410 = heff_intEq(heff_dup(v_i_241), heff_intSub(heff_dup(v_n_242), MK_INT(1LL)));
      V v_g_2411 = heff_strAppend(heff_take_field(v_m_244, 1), ({ V a_0 = heff_dup(v_v_247); V b_1 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL)); V a_2 = v_t_2410; V r_ = (g_heff_2elsp_2ereport_2ecut(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_t_2410); r_; }));
      V v_t_2412 = heff_intEq(heff_dup(v_i_241), heff_intSub(heff_dup(v_n_242), MK_INT(1LL)));
      V v_d_2413 = heff_strAppend(heff_get_n(v_m_244, 2, 3), ({ V a_0 = heff_dup(v_v_247); V b_1 = heff_intEq(heff_dup(v_i_241), MK_INT(0LL)); V a_2 = v_t_2412; V r_ = (g_heff_2elsp_2ereport_2ecut(a_0, b_1, a_2)); heff_drop(b_1); heff_drop(v_t_2412); r_; }));
      v_t_2430 = heff_rec_n(3, shape_expected__got__diff, (V[]){v_e_249, v_g_2411, v_d_2413});
      break;
    }
    case TAG_Removed: {
      V v_v_2414 = heff_field(v_p_245, 0);
      V v_t_2416;
      switch (heff_tag_of(v_color_240)) {
      case TAG_True: {
        V v_t_2415 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str0));
        v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(heff_dup(v_v_2414), heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str1))));
        break;
      }
      case TAG_False: {
        v_t_2416 = heff_dup(v_v_2414);
        break;
      }
      default: heff_nomatch(v_color_240);
      }
      V v_e_2417 = heff_strAppend(heff_take_field(v_m_244, 0), v_t_2416);
      V v_s_2418 = heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_str2), heff_strAppend(heff_dup(v_v_2414), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str3)));
      V v_t_2420;
      switch (heff_tag_of(v_color_240)) {
      case TAG_True: {
        V v_t_2419 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str4));
        v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(v_s_2418, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str5))));
        break;
      }
      case TAG_False: {
        v_t_2420 = v_s_2418;
        break;
      }
      default: heff_nomatch(v_color_240);
      }
      V v_d_2421 = heff_strAppend(heff_take_field(v_m_244, 2), v_t_2420);
      v_t_2430 = ({ V rv_0 = v_e_2417; V rv_2 = v_d_2421; V rr_ = heff_rec_reuse_n(v_m_244, 2ULL, 3, shape_expected__got__diff); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    case TAG_Added: {
      V v_v_2422 = heff_field(v_p_245, 0);
      V v_t_2424;
      switch (heff_tag_of(v_color_240)) {
      case TAG_True: {
        V v_t_2423 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str6));
        v_t_2424 = heff_strAppend(v_t_2423, heff_strAppend(heff_dup(v_v_2422), heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str7))));
        break;
      }
      case TAG_False: {
        v_t_2424 = heff_dup(v_v_2422);
        break;
      }
      default: heff_nomatch(v_color_240);
      }
      V v_g_2425 = heff_strAppend(heff_take_field(v_m_244, 1), v_t_2424);
      V v_s_2426 = heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_str8), heff_strAppend(heff_dup(v_v_2422), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str9)));
      V v_t_2428;
      switch (heff_tag_of(v_color_240)) {
      case TAG_True: {
        V v_t_2427 = heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str10));
        v_t_2428 = heff_strAppend(v_t_2427, heff_strAppend(v_s_2426, heff_strAppend(heff_strFromCharCode(MK_INT(27LL)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_str11))));
        break;
      }
      case TAG_False: {
        v_t_2428 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_color_240);
      }
      V v_d_2429 = heff_strAppend(heff_take_field(v_m_244, 2), v_t_2428);
      v_t_2430 = ({ V rv_1 = v_g_2425; V rv_2 = v_d_2429; V rr_ = heff_rec_reuse_n(v_m_244, 1ULL, 3, shape_expected__got__diff); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
      break;
    }
    default: heff_nomatch(v_p_245);
    }
    V t_0 = v_color_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_n_242;
    V t_3 = v_rest_246;
    V t_4 = v_t_2430;
    v_color_240 = t_0;
    v_i_241 = t_1;
    v_n_242 = t_2;
    v_x4_243 = t_3;
    v_m_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2elsp_2ereport_2emismatchGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2ereport_2emismatchGo(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[0]); heff_drop(a[3]); return r;
}
HEFF_STRA(g_heff_2elsp_2ereport_2emismatch_str0, 0, (0));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatch_str1, 0, (0));
HEFF_STRA(g_heff_2elsp_2ereport_2emismatch_str2, 0, (0));
Clo g_heff_2elsp_2ereport_2emismatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereport_2emismatch_entry, 3, 0};

V g_heff_2elsp_2ereport_2emismatch(V v_color_240, V v_expected_241, V v_got_242) {
top: ;
  V v_t_243 = (g_heff_2eutil_2ediff_2ewordsFrom(heff_dup(v_expected_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_244 = (g_heff_2eutil_2ediff_2ewordsFrom(heff_dup(v_got_242), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_245 = (g_heff_2eutil_2ediff_2ediffBy(heff_dup(g_strEq_get()), v_t_243, v_t_244));
  V v_xs_248;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_xs_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_e_246 = heff_field(v_x1_245, 0);
    V v_rest_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    v_xs_248 = (g_heff_2eutil_2ediff_2ejoinRunsGo(v_e_246, v_rest_247));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s1116451536x2100070357(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
  V v_t_2410 = (g_heff_2eutil_2ediff_2ewordsFrom(v_expected_241, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2411 = (g_heff_2eutil_2ediff_2ewordsFrom(v_got_242, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2412 = (g_heff_2eutil_2ediff_2ediffBy(heff_dup(g_strEq_get()), v_t_2410, v_t_2411));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nil: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_e_2413 = heff_field(v_x1_2412, 0);
    V v_rest_2414 = heff_field(v_x1_2412, 1);
    heff_take_n(v_x1_2412, 3ULL, 2);
    v_t_2415 = (g_heff_2eutil_2ediff_2ejoinRunsGo(v_e_2413, v_rest_2414));
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return ({ V a_0 = v_color_240; V a_1 = MK_INT(0LL); V a_2 = v_t_249; V a_3 = v_t_2415; V a_4 = heff_rec_n(3, shape_expected__got__diff, (V[]){((V)&g_heff_2elsp_2ereport_2emismatch_str0), ((V)&g_heff_2elsp_2ereport_2emismatch_str1), ((V)&g_heff_2elsp_2ereport_2emismatch_str2)}); V r_ = (g_heff_2elsp_2ereport_2emismatchGo(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2415); r_; });
}
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2elsp_2ereport_2emismatch(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}