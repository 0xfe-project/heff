// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Added 2732
#define TAG_Removed 39854
#define TAG_Same 22203
#define LBL_diff 9578700
#define LBL_expected 956903529
#define LBL_got 312070
static uint32_t shape_expected__got__diff[] = {LBL_expected, LBL_got, LBL_diff};
V g_heff_2elsp_2ereport_2ecut(V, V, V);
V g_heff_2elsp_2ereport_2ecut_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2ecut_clo;
HeffT3 g_heff_2elsp_2ereport_2emismatch_24cpr(V, V, V);
HeffT3 g_heff_2elsp_2ereport_2emismatchGo_24cpr(V, V, V, V, V);
HeffT3 g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr(V, V, V, V, V, V, V);
V g_heff_2eutil_2ediff_2ediffBy(V, V, V);
V g_heff_2eutil_2ediff_2ediffBy_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ediffBy_clo;
V g_heff_2eutil_2ediff_2ejoinRunsGo(V, V);
V g_heff_2eutil_2ediff_2ejoinRunsGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ejoinRunsGo_clo;
V g_heff_2eutil_2ediff_2ewordsFrom(V, V, V);
V g_heff_2eutil_2ediff_2ewordsFrom_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ewordsFrom_clo;
V g_heff_2eutil_2erune_2eruneStartGo(V, V, V);
V g_heff_2eutil_2erune_2eruneStartGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2erune_2eruneStartGo_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_strEq_get(void);
HEFF_LIT(g_heff_2elsp_2ereport_2ecut_str0, 3, "\342\200\246");
HEFF_LIT(g_heff_2elsp_2ereport_2ecut_str1, 3, "\342\200\246");
HEFF_LIT(g_heff_2elsp_2ereport_2ecut_str2, 3, "\342\200\246");
Clo g_heff_2elsp_2ereport_2ecut_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elsp_2ereport_2ecut_entry, 3, 0};

V g_heff_2elsp_2ereport_2ecut(V v_s_240, V v_first_241, V v_last_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= ((int64_t)41ULL))) {
    return v_s_240;
  } else {
    if ((heff_dup(v_first_241) == NTAG(TAG_True))) {
      int64_t v_k_243 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)20ULL));
      V v_t_244 = (g_heff_2eutil_2erune_2eruneStartGo(v_s_240, MK_INT(0LL), heff_box_word(v_k_243)));
      V v_t_245 = heff_strSlice(heff_dup(v_s_240), v_t_244, heff_strLength(v_s_240));
      return heff_strAppend(((V)&g_heff_2elsp_2ereport_2ecut_str0), v_t_245);
    } else {
      if ((heff_dup(v_last_242) == NTAG(TAG_True))) {
        V v_t_246 = (g_heff_2eutil_2erune_2eruneStartGo(v_s_240, MK_INT(0LL), MK_INT(20LL)));
        return heff_strAppend(heff_strSlice(v_s_240, MK_INT(0LL), v_t_246), ((V)&g_heff_2elsp_2ereport_2ecut_str1));
      } else {
        V v_t_247 = (g_heff_2eutil_2erune_2eruneStartGo(v_s_240, MK_INT(0LL), MK_INT(20LL)));
        int64_t v_k_248 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)20ULL));
        V v_t_249 = (g_heff_2eutil_2erune_2eruneStartGo(v_s_240, MK_INT(0LL), heff_box_word(v_k_248)));
        V v_t_2410 = heff_strAppend(heff_strSlice_lent(v_s_240, MK_INT(0LL), v_t_247, 6), ((V)&g_heff_2elsp_2ereport_2ecut_str2));
        V v_t_2411 = heff_strSlice(heff_dup(v_s_240), v_t_249, heff_strLength(v_s_240));
        return heff_strAppend(v_t_2410, v_t_2411);
      }
    }
  }
}
V g_heff_2elsp_2ereport_2ecut_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2elsp_2ereport_2ecut(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str0, 5, "\033[31m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str1, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str2, 2, "[-");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str3, 2, "-]");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str4, 5, "\033[31m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str5, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str6, 2, "{+");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str7, 2, "+}");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str8, 5, "\033[32m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str9, 4, "\033[0m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str10, 5, "\033[32m");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str11, 4, "\033[0m");

HeffT3 g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr(V v_color_240, V v_i_241, V v_n_242, V v_x4_243, V v_expected_244, V v_got_245, V v_diff_246) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_i_241);
    heff_drop(v_n_242);
    return ((HeffT3){{v_expected_244, v_got_245, v_diff_246}});
  }
  case TAG_Cons: {
    V v_x41_247 = heff_field(v_x4_243, 0);
    V v_rest_248 = heff_field(v_x4_243, 1);
    switch (heff_tag_of(v_x41_247)) {
    case TAG_Same: {
      V v_v_249 = heff_field(v_x41_247, 0);
      V v_t_2410 = heff_bool(heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2));
      V v_t_2411 = heff_bool(heff_intEq_c_lent(v_i_241, heff_intSub_lent(v_n_242, MK_INT(1LL), 2), 2));
      V v_t_2412 = ({ V a_0 = heff_dup(v_v_249); V a_1 = v_t_2410; V a_2 = v_t_2411; V r_ = (g_heff_2elsp_2ereport_2ecut(a_0, a_1, a_2)); heff_drop(v_t_2410); heff_drop(v_t_2411); r_; });
      V v_e_2413 = heff_strAppend(v_expected_244, v_t_2412);
      V v_t_2414 = heff_bool(heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2));
      V v_t_2415 = heff_bool(heff_intEq_c_lent(v_i_241, heff_intSub_lent(v_n_242, MK_INT(1LL), 2), 2));
      V v_t_2416 = ({ V a_0 = heff_dup(v_v_249); V a_1 = v_t_2414; V a_2 = v_t_2415; V r_ = (g_heff_2elsp_2ereport_2ecut(a_0, a_1, a_2)); heff_drop(v_t_2414); heff_drop(v_t_2415); r_; });
      V v_g_2417 = heff_strAppend(v_got_245, v_t_2416);
      V v_t_2418 = heff_bool(heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2));
      V v_t_2419 = heff_bool(heff_intEq_c_lent(v_i_241, heff_intSub_lent(v_n_242, MK_INT(1LL), 2), 2));
      V v_t_2420 = ({ V a_0 = heff_dup(v_v_249); V a_1 = v_t_2418; V a_2 = v_t_2419; V r_ = (g_heff_2elsp_2ereport_2ecut(a_0, a_1, a_2)); heff_drop(v_t_2418); heff_drop(v_t_2419); r_; });
      V v_d_2421 = heff_strAppend(v_diff_246, v_t_2420);
      V t_0 = v_color_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_rest_248;
      V t_4 = v_e_2413;
      V t_5 = v_g_2417;
      V t_6 = v_d_2421;
      v_color_240 = t_0;
      v_i_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      v_expected_244 = t_4;
      v_got_245 = t_5;
      v_diff_246 = t_6;
      goto top;
    }
    case TAG_Removed: {
      V v_v_2422 = heff_field(v_x41_247, 0);
      V v_t_2423;
      if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
        v_t_2423 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str0), heff_dup(v_v_2422)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str1));
      } else {
        v_t_2423 = heff_dup(v_v_2422);
      }
      V v_e_2424 = heff_strAppend(v_expected_244, v_t_2423);
      V v_s_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str2), heff_dup(v_v_2422)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str3));
      V v_t_2426;
      if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
        v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str4), v_s_2425), ((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str5));
      } else {
        v_t_2426 = v_s_2425;
      }
      V v_d_2427 = heff_strAppend(v_diff_246, v_t_2426);
      V t_0 = v_color_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_rest_248;
      V t_4 = v_e_2424;
      V t_5 = v_got_245;
      V t_6 = v_d_2427;
      v_color_240 = t_0;
      v_i_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      v_expected_244 = t_4;
      v_got_245 = t_5;
      v_diff_246 = t_6;
      goto top;
    }
    case TAG_Added: {
      V v_v_2428 = heff_field(v_x41_247, 0);
      V v_s_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str6), heff_dup(v_v_2428)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str7));
      V v_t_2430;
      if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
        v_t_2430 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str8), v_s_2429), ((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str9));
      } else {
        v_t_2430 = v_s_2429;
      }
      V v_d_2431 = heff_strAppend(v_diff_246, v_t_2430);
      V v_t_2432;
      if ((heff_dup(v_color_240) == NTAG(TAG_True))) {
        v_t_2432 = heff_strAppend(heff_strAppend(((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str10), heff_dup(v_v_2428)), ((V)&g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr_str11));
      } else {
        v_t_2432 = heff_dup(v_v_2428);
      }
      V t_0 = v_color_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = v_n_242;
      V t_3 = v_rest_248;
      V t_4 = v_expected_244;
      V t_5 = heff_strAppend(v_got_245, v_t_2432);
      V t_6 = v_d_2431;
      v_color_240 = t_0;
      v_i_241 = t_1;
      v_n_242 = t_2;
      v_x4_243 = t_3;
      v_expected_244 = t_4;
      v_got_245 = t_5;
      v_diff_246 = t_6;
      goto top;
    }
    default: return ((HeffT3){{heff_nomatch(v_x41_247)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x4_243)}});
  }
}

HeffT3 g_heff_2elsp_2ereport_2emismatchGo_24cpr(V v_color_240, V v_i_241, V v_n_242, V v_x4_243, V v_m_244) {
top: ;
  V v_expected_245 = heff_take_field(v_m_244, 0);
  V v_got_246 = heff_take_field(v_m_244, 1);
  V v_diff_247 = heff_get_n(v_m_244, 2, 3);
  return (g_heff_2elsp_2ereport_2emismatchGo_24scalars_24cpr(v_color_240, v_i_241, v_n_242, v_x4_243, v_expected_245, v_got_246, v_diff_247));
}
HEFF_LIT(g_heff_2elsp_2ereport_2emismatch_24cpr_str0, 0, "");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatch_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2elsp_2ereport_2emismatch_24cpr_str2, 0, "");

HeffT3 g_heff_2elsp_2ereport_2emismatch_24cpr(V v_color_240, V v_expected_241, V v_got_242) {
top: ;
  V v_t_243 = (g_heff_2eutil_2ediff_2ewordsFrom(v_expected_241, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_244 = (g_heff_2eutil_2ediff_2ewordsFrom(v_got_242, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_245 = (g_heff_2eutil_2ediff_2ediffBy(heff_dup(g_strEq_get()), v_t_243, v_t_244));
  V v_xs_248;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    v_xs_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_e_246 = heff_field(v_x1_245, 0);
    V v_rest_247 = heff_field(v_x1_245, 1);
    heff_take_n(v_x1_245, 3ULL, 2);
    v_xs_248 = (g_heff_2eutil_2ediff_2ejoinRunsGo(v_e_246, v_rest_247));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_t_249 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_xs_248; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
  V v_t_2410 = (g_heff_2eutil_2ediff_2ewordsFrom(v_expected_241, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2411 = (g_heff_2eutil_2ediff_2ewordsFrom(v_got_242, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2412 = (g_heff_2eutil_2ediff_2ediffBy(heff_dup(g_strEq_get()), v_t_2410, v_t_2411));
  V v_t_2415;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nil: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    V v_e_2413 = heff_field(v_x1_2412, 0);
    V v_rest_2414 = heff_field(v_x1_2412, 1);
    heff_take_n(v_x1_2412, 3ULL, 2);
    v_t_2415 = (g_heff_2eutil_2ediff_2ejoinRunsGo(v_e_2413, v_rest_2414));
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  return ({ V a_0 = v_color_240; V a_1 = MK_INT(0LL); V a_2 = v_t_249; V a_3 = v_t_2415; V a_4 = heff_rec_n(3, shape_expected__got__diff, (V[]){((V)&g_heff_2elsp_2ereport_2emismatch_24cpr_str0), ((V)&g_heff_2elsp_2ereport_2emismatch_24cpr_str1), ((V)&g_heff_2elsp_2ereport_2emismatch_24cpr_str2)}); HeffT3 r_ = (g_heff_2elsp_2ereport_2emismatchGo_24cpr(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2415); r_; });
}